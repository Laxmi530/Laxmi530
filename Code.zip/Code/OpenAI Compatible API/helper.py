import time
from typing import List, Optional, Union, Dict, Any
from pydantic import BaseModel

class ModelCard(BaseModel):
    id: str
    object: str = "model"
    created: int = int(time.time())
    owned_by: str = "local"

class ModelList(BaseModel):
    object: str = "list"
    data: List[ModelCard]

# /v1/chat/completions
class ChatMessage(BaseModel):
    role: str
    content: Union[str, List[Dict[str, Any]]]

class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[ChatMessage]
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 4096
    stream: Optional[bool] = False

# /v1/embeddings
class EmbeddingRequest(BaseModel):
    model: str
    input: Union[str, List[str]]

class EmbeddingData(BaseModel):
    object: str = "embedding"
    embedding: List[float]
    index: int

class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: List[EmbeddingData]
    model: str

# /v1/audio/speech
class TTSRequest(BaseModel):
    model: str
    input: str
    voice: Optional[str] = "alloy" # OpenAI-compatible field, not used by local model

# /v1/audio/transcriptions
class TranscriptionResponse(BaseModel):
    text: str