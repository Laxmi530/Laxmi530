# from contextlib import asynccontextmanager
# import torch
# from fastapi import FastAPI
# from sentence_transformers import SentenceTransformer
# from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline, AutoProcessor, Qwen2_5_VLForConditionalGeneration
# from voxcpm import VoxCPM

# device = "cuda" if torch.cuda.is_available() else "cpu"

# MODELS_CONFIG = {
#     "text-generation": {
#         "model_id": r"D:\AI Models\Qwen3-0.6B",
#         "hf_class": AutoModelForCausalLM,
#         "tokenizer_class": AutoTokenizer,
#     },
#     "vision": {
#         "model_id": r"D:\AI Models\Qwen2.5-VL-3B-Instruct",
#         "hf_class": Qwen2_5_VLForConditionalGeneration,
#         "tokenizer_class": AutoProcessor,
#     },
#     "embedding": {
#         "model_id": r"D:\AI Models\Qwen3-Embedding-0.6B",
#         "hf_class": SentenceTransformer,
#     },
#     "tts": {
#         "model_id": r"D:\AI Models\TTS openbmb VoxCPM-0.5B",
#         "hf_class": VoxCPM,
#         # "processor_class": KPipeline,
#     },
#     "stt": {
#         "model_id": r"D:\AI Models\openai-whisper-large-v3",
#         "hf_class": pipeline,
#     },
# }

# # Global dictionary to hold the loaded models
# models = {}

# # --- Model Loading ---
# def load_models():
#     """Loads all models from the config into the global `models` dictionary."""
#     device = "cuda" if torch.cuda.is_available() else "cpu"
#     print(f"Using device: {device}")

#     # Text Generation Model
#     print(f"Loading...⏳ text-generation model: {MODELS_CONFIG['text-generation']['model_id']}")
#     text_model_id = MODELS_CONFIG['text-generation']['model_id']
#     models['text_model'] = AutoModelForCausalLM.from_pretrained(text_model_id, dtype=torch.bfloat16, device_map="auto")
#     models['text_tokenizer'] = AutoTokenizer.from_pretrained(text_model_id)
#     print("Text-generation model loaded. ✅")

#     # Vision Model
#     print(f"Loading...⏳ vision model: {MODELS_CONFIG['vision']['model_id']}")
#     vision_model_id = MODELS_CONFIG['vision']['model_id']
#     models['vision_model'] = Qwen2_5_VLForConditionalGeneration.from_pretrained(vision_model_id, dtype=torch.bfloat16, device_map="auto")
#     models['vision_tokenizer'] = AutoProcessor.from_pretrained(vision_model_id)
#     print("Vision model loaded. ✅")

#     # Embedding Model
#     print(f"Loading...⏳ embedding model: {MODELS_CONFIG['embedding']['model_id']}")
#     embedding_model_id = MODELS_CONFIG['embedding']['model_id']
#     models['embedding_model'] = SentenceTransformer(embedding_model_id, device=device)
#     print("Embedding model loaded. ✅")

#     # Text-to-Speech (TTS) Model
#     print(f"Loading...⏳ TTS model: {MODELS_CONFIG['tts']['model_id']}")
#     tts_model_id = MODELS_CONFIG['tts']['model_id']
#     # VOICE_TENSOR = torch.load(f"{tts_model_id}/voices/am_adam.pt", map_location=device, weights_only=True)
#     models['tts_model'] = VoxCPM(tts_model_id)
#     # models['tts_processor'] = KPipeline(lang_code="en-gb", repo_id='hexgrad/Kokoro-82M', model=models['tts_model'])
#     print("TTS model loaded. ✅")

#     # Speech-to-Text (STT) / Whisper
#     print(f"Loading...⏳ STT model: {MODELS_CONFIG['stt']['model_id']}")
#     stt_model_id = MODELS_CONFIG['stt']['model_id']
#     models['stt_pipeline'] = pipeline("automatic-speech-recognition", model=stt_model_id, dtype=torch.float16, device=device)
#     print("STT model loaded. ✅")

# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     # Load the models at startup
#     load_models()
#     yield
#     # Clean up resources if needed
#     models.clear()



import torch
import asyncio
import collections
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline, AutoProcessor, Qwen2_5_VLForConditionalGeneration
from voxcpm import VoxCPM

# This config remains the same
MODELS_CONFIG = {
    "text-generation": {
        "model_id": r"D:\AI Models\Qwen3-0.6B",
    },
    "vision": {
        "model_id": r"D:\AI Models\Qwen2.5-VL-3B-Instruct",
    },
    "embedding": {
        "model_id": r"D:\AI Models\Qwen3-Embedding-0.6B",
    },
    "tts": {
        "model_id": r"D:\AI Models\TTS openbmb VoxCPM-0.5B",
    },
    "stt": {
        "model_id": r"D:\AI Models\openai-whisper-large-v3",
    },
}

class ModelManager:
    """
    Manages loading and unloading models to/from GPU memory using an LRU cache strategy.
    """
    def __init__(self, max_loaded_models=2):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.max_loaded_models = max_loaded_models
        self.loaded_models = {}
        self.lru_tracker = collections.OrderedDict()
        self.lock = asyncio.Lock()
        print(f"ModelManager initialized. Device: {self.device}. Max models in VRAM: {self.max_loaded_models}")

    async def get_model(self, model_type: str):
        async with self.lock:
            if model_type in self.lru_tracker:
                self.lru_tracker.move_to_end(model_type)
                print(f"Model '{model_type}' is already loaded. ✅")
                return self.loaded_models[model_type]

            print(f"Model '{model_type}' not in memory. Loading...⏳")
            if len(self.lru_tracker) >= self.max_loaded_models:
                # Unload the least recently used model
                oldest_model_type = next(iter(self.lru_tracker))
                self._unload_model(oldest_model_type)

            # Load the new model
            model_components = await self._load_model(model_type)
            self.loaded_models[model_type] = model_components
            self.lru_tracker[model_type] = True
            print(f"Model '{model_type}' loaded successfully. ✅")
            return model_components

    def _unload_model(self, model_type: str):
        print(f"Unloading model '{model_type}' to free up VRAM...🗑️")
        if model_type in self.loaded_models:
            del self.loaded_models[model_type]
        if model_type in self.lru_tracker:
            del self.lru_tracker[model_type]
        torch.cuda.empty_cache()

    async def _load_model(self, model_type: str):
        model_id = MODELS_CONFIG[model_type]['model_id']

        # Use asyncio.to_thread to run blocking I/O (model loading) in a separate thread
        def load_sync():
            if model_type == "text-generation":
                model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, device_map=self.device)
                tokenizer = AutoTokenizer.from_pretrained(model_id)
                return {"model": model, "tokenizer": tokenizer}
            elif model_type == "vision":
                model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_id, dtype=torch.bfloat16, device_map=self.device)
                processor = AutoProcessor.from_pretrained(model_id)
                return {"model": model, "processor": processor}
            elif model_type == "embedding":
                model = SentenceTransformer(model_id, device=self.device)
                return {"model": model}
            elif model_type == "tts":
                model = VoxCPM(model_id)
                return {"model": model}
            elif model_type == "stt":
                stt_pipeline = pipeline("automatic-speech-recognition", model=model_id, dtype=torch.float16, device=self.device)
                return {"pipeline": stt_pipeline}
            else:
                raise ValueError(f"Unknown model type: {model_type}")

        return await asyncio.to_thread(load_sync)

# Instantiate a single manager for the whole application
# You can change max_loaded_models based on your VRAM capacity.
model_manager = ModelManager(max_loaded_models=2)