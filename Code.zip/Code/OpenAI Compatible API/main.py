# import io
# import time
# import uuid
# import torch
# import uvicorn
# from fastapi import FastAPI, File, UploadFile, HTTPException
# from fastapi.responses import StreamingResponse
# import librosa
# from qwen_vl_utils import process_vision_info
# import soundfile as sf

# from models_loader import lifespan, models, MODELS_CONFIG
# from helper import (ModelCard, 
#                     ModelList, 
#                     ChatCompletionRequest, 
#                     EmbeddingResponse, 
#                     EmbeddingRequest, 
#                     EmbeddingData, 
#                     TTSRequest, 
#                     TranscriptionResponse)

# device = "cuda" if torch.cuda.is_available() else "cpu"

# app = FastAPI(lifespan=lifespan)

# def transform_openai_to_qwen_vl(messages: list) -> list:
#     """
#     Transforms messages from the standard OpenAI vision format to the format 
#     expected by Qwen-VL's process_vision_info utility.
#     """
#     transformed_messages = []
#     for msg in messages:
#         if isinstance(msg.get("content"), list):
#             new_content = []
#             for item in msg["content"]:
#                 if item.get("type") == "image_url" and "image_url" in item:
#                     new_content.append({"type": "image", "image": item["image_url"]["url"]})
#                 else:
#                     new_content.append(item)
#             transformed_messages.append({"role": msg["role"], "content": new_content})
#         else:
#             transformed_messages.append(msg)
#     return transformed_messages

# @app.get("/v1/models", response_model=ModelList)
# async def list_models():
#     """Lists the available models."""
#     model_cards = [
#         ModelCard(id="Qwen3-0.6B"),
#         ModelCard(id="Qwen2.5-VL-3B-Instruct"),
#         ModelCard(id="Qwen3-Embedding-0.6B"),
#         ModelCard(id="VoxCPM-0.5B"),
#         ModelCard(id="openai-whisper-large-v3"),
#     ]
#     return ModelList(data=model_cards)

# @app.post("/v1/chat/completions")
# async def create_chat_completion(request: ChatCompletionRequest):
#     """Handles both text-only and vision chat completions."""
#     if request.stream:
#         raise HTTPException(status_code=400, detail="Streaming is not yet supported.")

#     is_vision_request = any(isinstance(msg.content, list) for msg in request.messages)
    
#     # Convert Pydantic models to a list of dictionaries for processing
#     messages_dict = [msg.model_dump() for msg in request.messages]

#     if is_vision_request:
#         # --- Vision Model Logic ---
#         model = models['vision_model']
#         processor = models['vision_tokenizer']
#         qwen_vl_messages = transform_openai_to_qwen_vl(messages_dict)
#         print("Message transformed")
#         text = processor.apply_chat_template(qwen_vl_messages, tokenize=False, add_generation_prompt=True)
#         print("Text input is ready")
#         image_inputs, video_inputs = process_vision_info(qwen_vl_messages)
#         print("Image input is ready")
#         inputs = processor(text=[text], images=image_inputs, videos=video_inputs, padding=True, return_tensors="pt").to(model.device)
#         print("All Input is ready")
#         decoder = processor
#         # inputs = inputs.to(device)
#         # # Inference: Generation of the output
#         # generated_ids = model.generate(**inputs, max_new_tokens=128)
#         # generated_ids_trimmed = [out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)]
#         # response_text = processor.batch_decode(generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
#     else:
#         # --- Text-Only Model Logic ---
#         model = models['text_model']
#         tokenizer = models['text_tokenizer']
#         text = tokenizer.apply_chat_template(messages_dict, tokenize=False, add_generation_prompt=True, enable_thinking = True)
#         inputs = tokenizer([text], return_tensors="pt").to(model.device)
#         decoder = tokenizer
#         # generated_ids = model.generate(**model_inputs, max_new_tokens=32768)
#         # output_ids = generated_ids[0][len(model_inputs.input_ids[0]):].tolist()
#         # response_text = tokenizer.decode(output_ids, skip_special_tokens=True)


#     gen_kwargs = {"max_new_tokens": request.max_tokens, "temperature":request.temperature} 
#     generated_ids = model.generate(**inputs, **gen_kwargs)
#     print("Output ID generated ✅")
#     response_ids = generated_ids[0][len(inputs.input_ids[0]):]
#     response_text = decoder.decode(response_ids, skip_special_tokens=True).strip()
#     print("Response generated ✅")
#     # This 'usage' block now works for both cases
#     return {
#         "id": f"chatcmpl-{uuid.uuid4()}",
#         "object": "chat.completion",
#         "created": int(time.time()),
#         "model": request.model,
#         "choices": [
#             {
#                 "index": 0,
#                 "message": {
#                     "role": "assistant",
#                     "content": response_text,
#                 },
#                 "finish_reason": "stop",
#             }
#         ],
#         "usage": {
#             "prompt_tokens": len(inputs.input_ids[0]),
#             "completion_tokens": len(response_ids),
#             "total_tokens": len(inputs.input_ids[0]) + len(response_ids.tolist()),
#         },
#     }

# @app.post("/v1/embeddings", response_model=EmbeddingResponse)
# async def create_embedding(request: EmbeddingRequest):
#     """Handles text embedding requests."""
#     embedding_model = models['embedding_model']
    
#     embeddings = embedding_model.encode(request.input)
    
#     data = []
#     if isinstance(request.input, str):
#         data.append(EmbeddingData(embedding=embeddings.tolist(), index=0))
#     else:
#         for i, emb in enumerate(embeddings):
#             data.append(EmbeddingData(embedding=emb.tolist(), index=i))
            
#     return EmbeddingResponse(data=data, model=request.model)

# @app.post("/v1/audio/speech")
# async def create_speech(request: TTSRequest):
#     """Handles text-to-speech requests."""
#     tts_model = models['tts_model']
#     # tts_processor = models['tts_processor']
#     # device = tts_model.device
#     # inputs = tts_processor(text=request.input, return_tensors="pt").to(device)
#     # with torch.no_grad():
#     #     speech = tts_model(**inputs).waveform[0]
#     buffer = io.BytesIO()
#     # sampling_rate = tts_model.config.sampling_rate
#     input_text = request.input
#     wav = tts_model.generate(
#             text=input_text,
#             prompt_wav_path=None,      # optional: path to a prompt speech for voice cloning
#             prompt_text=None,          # optional: reference text
#             cfg_value=2.0,             # LM guidance on LocDiT, higher for better adherence to the prompt, but maybe worse
#             inference_timesteps=10,   # LocDiT inference timesteps, higher for better result, lower for fast speed
#             normalize=True,           # enable external TN tool
#             denoise=True,             # enable external Denoise tool
#             retry_badcase=True,        # enable retrying mode for some bad cases (unstoppable)
#             retry_badcase_max_times=3,  # maximum retrying times
#             retry_badcase_ratio_threshold=6.0, # maximum length restriction for bad case detection (simple but effective), it could be adjusted for slow pace speech
#             )
#     sf.write(buffer, wav, 16000, format='WAV')
#     buffer.seek(0)
#     return StreamingResponse(buffer, media_type="audio/wav")

# @app.post("/v1/audio/transcriptions", response_model=TranscriptionResponse)
# async def create_transcription(file: UploadFile = File(...)):
#     """Handles audio transcription requests (speech-to-text)."""
#     if not file.content_type.startswith("audio/"):
#         raise HTTPException(status_code=400, detail="Invalid file type. Please upload an audio file.")

#     stt_pipeline = models['stt_pipeline']
#     audio_bytes = await file.read()
    
#     # Use librosa to load and resample the audio for Whisper
#     audio, sr = librosa.load(io.BytesIO(audio_bytes), sr=16000, mono=True)
    
#     result = stt_pipeline(audio)
    
#     return TranscriptionResponse(text=result["text"])

# if __name__ == "__main__":
#     uvicorn.run(app, host="0.0.0.0", port=8000)


import io
import time
import uuid
import torch
import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import StreamingResponse
import librosa
from qwen_vl_utils import process_vision_info
import soundfile as sf

# Import the manager instance instead of the lifespan and models dict
from models_loader import model_manager
from helper import (ModelCard, 
                    ModelList, 
                    ChatCompletionRequest, 
                    EmbeddingResponse, 
                    EmbeddingRequest, 
                    EmbeddingData, 
                    TTSRequest, 
                    TranscriptionResponse)

# Remove lifespan from the app initialization
app = FastAPI()

# The transform_openai_to_qwen_vl helper function remains the same...
def transform_openai_to_qwen_vl(messages: list) -> list:
    """
    Transforms messages from the standard OpenAI vision format to the format 
    expected by Qwen-VL's process_vision_info utility.
    """
    transformed_messages = []
    for msg in messages:
        if isinstance(msg.get("content"), list):
            new_content = []
            for item in msg["content"]:
                if item.get("type") == "image_url" and "image_url" in item:
                    new_content.append({"type": "image", "image": item["image_url"]["url"]})
                else:
                    new_content.append(item)
            transformed_messages.append({"role": msg["role"], "content": new_content})
        else:
            transformed_messages.append(msg)
    return transformed_messages


@app.get("/v1/models", response_model=ModelList)
async def list_models():
    model_cards = [
        ModelCard(id="Qwen3-0.6B"),
        ModelCard(id="Qwen2.5-VL-3B-Instruct"),
        ModelCard(id="Qwen3-Embedding-0.6B"),
        ModelCard(id="VoxCPM-0.5B"),
        ModelCard(id="openai-whisper-large-v3"),
    ]
    return ModelList(data=model_cards)

@app.post("/v1/chat/completions")
async def create_chat_completion(request: ChatCompletionRequest):
    if request.stream:
        raise HTTPException(status_code=400, detail="Streaming is not yet supported.")

    is_vision_request = any(isinstance(msg.content, list) for msg in request.messages)
    messages_dict = [msg.model_dump() for msg in request.messages]

    if is_vision_request:
        loaded = await model_manager.get_model("vision")
        model = loaded['model']
        processor = loaded['processor']
        qwen_vl_messages = transform_openai_to_qwen_vl(messages_dict)
        text = processor.apply_chat_template(qwen_vl_messages, tokenize=False, add_generation_prompt=True)
        image_inputs, video_inputs = process_vision_info(qwen_vl_messages)
        inputs = processor(text=[text], images=image_inputs, videos=video_inputs, padding=True, return_tensors="pt").to(model.device)
        decoder = processor
    else:
        loaded = await model_manager.get_model("text-generation")
        model = loaded['model']
        tokenizer = loaded['tokenizer']
        text = tokenizer.apply_chat_template(messages_dict, tokenize=False, add_generation_prompt=True, enable_thinking = True)
        inputs = tokenizer([text], return_tensors="pt").to(model.device)
        decoder = tokenizer

    gen_kwargs = {"max_new_tokens": request.max_tokens, "temperature": request.temperature} 
    generated_ids = model.generate(**inputs, **gen_kwargs)
    response_ids = generated_ids[0][len(inputs.input_ids[0]):]
    response_text = decoder.decode(response_ids, skip_special_tokens=True).strip()
    
    # ... (return block is the same)
    return {
        "id": f"chatcmpl-{uuid.uuid4()}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": request.model,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": response_text}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": len(inputs.input_ids[0]), "completion_tokens": len(response_ids), "total_tokens": len(inputs.input_ids[0]) + len(response_ids.tolist())},
    }

@app.post("/v1/embeddings", response_model=EmbeddingResponse)
async def create_embedding(request: EmbeddingRequest):
    loaded = await model_manager.get_model("embedding")
    embedding_model = loaded['model']
    
    embeddings = embedding_model.encode(request.input)
    
    data = []
    if isinstance(request.input, str):
        data.append(EmbeddingData(embedding=embeddings.tolist(), index=0))
    else:
        for i, emb in enumerate(embeddings):
            data.append(EmbeddingData(embedding=emb.tolist(), index=i))
            
    return EmbeddingResponse(data=data, model=request.model)

@app.post("/v1/audio/speech")
async def create_speech(request: TTSRequest):
    loaded = await model_manager.get_model("tts")
    tts_model = loaded['model']
    buffer = io.BytesIO()
    input_text = request.input
    wav = tts_model.generate(
            text=input_text,
            prompt_wav_path=None,      # optional: path to a prompt speech for voice cloning
            prompt_text=None,          # optional: reference text
            cfg_value=2.0,             # LM guidance on LocDiT, higher for better adherence to the prompt, but maybe worse
            inference_timesteps=10,   # LocDiT inference timesteps, higher for better result, lower for fast speed
            normalize=True,           # enable external TN tool
            denoise=True,             # enable external Denoise tool
            retry_badcase=True,        # enable retrying mode for some bad cases (unstoppable)
            retry_badcase_max_times=3,  # maximum retrying times
            retry_badcase_ratio_threshold=6.0, # maximum length restriction for bad case detection (simple but effective), it could be adjusted for slow pace speech
            )
    sf.write(buffer, wav, 16000, format='WAV')
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="audio/wav")

@app.post("/v1/audio/transcriptions", response_model=TranscriptionResponse)
async def create_transcription(file: UploadFile = File(...)):
    if not file.content_type.startswith("audio/"):
        raise HTTPException(status_code=400, detail="Invalid file type.")

    loaded = await model_manager.get_model("stt")
    stt_pipeline = loaded['pipeline']
    
    audio_bytes = await file.read()
    audio, sr = librosa.load(io.BytesIO(audio_bytes), sr=16000, mono=True)
    
    result = stt_pipeline(audio)
    
    return TranscriptionResponse(text=result["text"])

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)