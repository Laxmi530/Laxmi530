import os
import yaml
import json
from pathlib import Path

def load_config_details(file):
    try:
        with open(file, 'r', encoding = "utf-8") as read_data:
            config_data = yaml.safe_load(read_data)
            return config_data
    except yaml.YAMLError as exc:
        return str(exc)

def correct_path():
    possible_paths = [Path(os.path.join(os.getcwd(), "config.yml")), Path(os.path.join(os.getcwd(), "config", "config.yml"))]  
    for paath in possible_paths:
        if os.path.exists(paath):
            return paath
    return None

load_config_data = load_config_details(correct_path())

# def load_yml_config_details(file):
#     try:
#         with open(file, 'r', encoding = "utf-8") as read_data:
#             config_data = yaml.safe_load(read_data)
#             return config_data
#     except yaml.YAMLError as exc:
#         return str(exc)

# def correct_path():
#     config_folder = Path(os.path.join(os.getcwd(), "config"))
#     file_name = "config.yml"
#     for dir, _, list_file_name in os.walk(config_folder):
#         if file_name in list_file_name:
#             config_file_path = os.path.join(dir, list_file_name[list_file_name.index(file_name)])
#             if os.path.exists(config_file_path):
#                 return config_file_path
#         else:
#             return "No config file found."

# load_yaml_config_data = load_yml_config_details(correct_path())
# # print(correct_path())



# def load_json_config_details(file_path):
#     """Loads JSON data from a given file path."""
#     if not file_path or not os.path.exists(file_path):
#         return None
#     try:
#         with open(file_path, 'r', encoding="utf-8") as read_data:
#             config_data = json.load(read_data)
#             return config_data
#     except json.JSONDecodeError as exc: 
#         return None 
#     except Exception as e:
#         return None

# def find_config_file():
#     """Finds the config.json file in standard locations."""
#     config_folder = Path(os.path.join(os.getcwd(), "config"))
#     file_name = "config.json"
#     for dir, _, list_file_name in os.walk(config_folder):
#         if file_name in list_file_name:
#             config_file_path = os.path.join(dir, list_file_name[list_file_name.index(file_name)])
#             if os.path.exists(config_file_path):
#                 return config_file_path
#         else:
#             return "No config file found."

# load_json_config_data = load_json_config_details(find_config_file())
