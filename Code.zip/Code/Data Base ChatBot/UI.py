import streamlit as st

from chat_bot import create_sql_agent_executor, get_streaming_response

# --- Page Configuration ---
st.set_page_config(page_title="SQL Chatbot Pro", page_icon="🤖", layout="centered")

# --- State Management Initialization ---
def initialize_session_state():
    if "chat_sessions" not in st.session_state:
        st.session_state.chat_sessions = {"Chat 1": []}
    if "active_session" not in st.session_state:
        st.session_state.active_session = "Chat 1"

initialize_session_state()

# --- Caching the Agent Executor ---
@st.cache_resource
def load_agent():
    try:
        return create_sql_agent_executor(db_uri="sqlite:///company.db")
    except (ValueError, Exception) as e:
        st.error(str(e))
        st.stop()

# --- Sidebar ---
with st.sidebar:
    st.image("./UI asset/logo_1.png", width=150)
    st.title("🤖 SQL Chatbot")
    st.markdown("---")

    if st.button("New Chat Session"):
        session_count = len(st.session_state.chat_sessions) + 1
        new_session_name = f"Chat session {session_count}"
        st.session_state.chat_sessions[new_session_name] = []
        st.session_state.active_session = new_session_name
        st.rerun()

    active_chat_messages = st.session_state.chat_sessions[st.session_state.active_session]

    st.button(
        "Clear Chat History",
        on_click=lambda: st.session_state.chat_sessions.update({st.session_state.active_session: []}),
        disabled=not active_chat_messages,
    )

    st.markdown("---")
    st.markdown("### Chat Sessions")

    st.session_state.active_session = st.radio(
        "Select a chat:",
        options=sorted(st.session_state.chat_sessions.keys()),
        key="session_selector",
        label_visibility="collapsed"
    )
    
    st.markdown("---")
    st.markdown("Ask questions like:")
    st.markdown("- *How many employees are there?*")
    st.markdown("- *Who are the employees in the Engineering department?*")
    st.markdown("- *Who is getting highest salary?*")

# --- Main Chat Interface ---
st.header(f"Chat Session: {st.session_state.active_session}")

agent_executor = load_agent()

for message in active_chat_messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if prompt := st.chat_input("Ask me about your data..."):
    active_chat_messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        response_generator = get_streaming_response(prompt, agent_executor)
        full_response = st.write_stream(response_generator)
    
    active_chat_messages.append({"role": "assistant", "content": full_response})