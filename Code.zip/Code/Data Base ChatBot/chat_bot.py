from langchain_openai import ChatOpenAI
from langchain_community.utilities import SQLDatabase
from langchain.agents import create_react_agent, AgentExecutor
from langchain_community.agent_toolkits import SQLDatabaseToolkit

from config import load_config_data
from prompt import PROMPT

api_key = load_config_data["GROQ_API_KEY"]
base_url = load_config_data["GROQ_BASE_URL"]
chat_model = load_config_data["GROQ_QWEN_3_32B"]

def create_sql_agent_executor(db_uri="sqlite:///company.db") -> AgentExecutor:
    """
    Creates and returns a LangChain SQL Agent Executor using the ReAct framework.

    This function is now more flexible and suitable for OpenAI-compatible APIs
    and models that may not support tool calling.

    Args:
        db_uri (str): The URI for the database connection.

    Returns:
        An AgentExecutor object capable of querying the SQL database.
    """

    llm = ChatOpenAI(model = chat_model, temperature = 0.5, base_url = base_url, api_key = api_key, streaming = True)

    db = SQLDatabase.from_uri(db_uri)
    toolkit = SQLDatabaseToolkit(db=db, llm=llm)
    tools = toolkit.get_tools()
    agent = create_react_agent(llm, tools, PROMPT)

    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True, max_iterations=5)
    
    return agent_executor

def get_streaming_response(prompt, agent_executor):
    """
    Invokes the agent and yields the streaming response chunks for the final answer.
    This is a generator function.
    """
    for chunk in agent_executor.stream({"input": prompt}):
        if "output" in chunk:
            yield chunk["output"]