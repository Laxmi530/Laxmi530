import streamlit as st
import os
import torch

from chat_bot import data_inject_DB, chat_response
from config import load_config_data

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
torch.classes.__path__ = []

FILE_PROCESSING_DIR = load_config_data["FILE_PROCESSING_PATH"]
os.makedirs(FILE_PROCESSING_DIR, exist_ok=True)

st.set_page_config(page_title="Demo ChatBot", layout="wide", initial_sidebar_state="auto", page_icon="💬")

with st.sidebar:
    # st.image("logo.png")#, width=220)    
    uploaded_file = st.file_uploader("Upload a PDF, DOCX or PPTX file", type=["pdf", "docx", "pptx"])
    if uploaded_file:
        st.write(f"✅ **Uploaded File:** {uploaded_file.name}")
        raw_data = uploaded_file.getvalue()
        file_path = os.path.join(FILE_PROCESSING_DIR, uploaded_file.name)
        with open(file_path, mode="wb") as writer:
            writer.write(raw_data)
        inject_data = data_inject_DB(file_path)
        st.spinner("Injecting data....⏳", show_time=True)
        st.success("✅ Data injection successful")
        os.remove(file_path)

    # domain = st.selectbox("**Choose a domain to start conversation**", options=choices, index=len(choices)-1)

    selected_session = st.radio("**Select a chat session**", ["Session 1", "Session 2", "Session 3"], index=0)

    if st.button("🗑️ Clear Chat History", type="primary", help="It will clear the chat history"):
        st.session_state["chat_histories"][selected_session] = [{"role": "assistant", "content": "How can I help you?"}]
        # st.session_state.clear()  # Completely resets the session state → All stored variables (including uploaded files, domain selection, and chat history) are erased. It clears everything, including file uploads, session selections, and domain choices. Users have to re-upload files and re-select options.
        # st.rerun()                # Ensures a full UI refresh → Everything restarts as if the app was just launched.
        st.success("Chat history cleared!")

if "chat_histories" not in st.session_state:
    st.session_state["chat_histories"] = {
        "Session 1": [{"role": "assistant", "content": "How can I help you?"}],
        "Session 2": [{"role": "assistant", "content": "How can I help you?"}],
        "Session 3": [{"role": "assistant", "content": "How can I help you?"}]
    }

chat_history = st.session_state["chat_histories"][selected_session]
        
st.caption("🚀 Your AI, Your Domain – Smart Responses for Every Query! 🤖✨")

for msg in chat_history:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

if prompt := st.chat_input(placeholder=f"Please type your query: "):
    chat_history.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)

    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        full_response = ""
        for chunk in chat_response(prompt):
            full_response += chunk
            response_placeholder.write(full_response)

    chat_history.append({"role": "assistant", "content": full_response})
    st.session_state["chat_histories"][selected_session] = chat_history
