from __future__ import absolute_import, division, print_function, unicode_literals
from docx.document import Document as _Document
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl
from docx.table import _Cell, Table
from docx.text.paragraph import Paragraph
from docx import Document
import pypdf 
import pdfplumber 
import os
import fitz
import base64
import io
from openai import OpenAI
from typing import Optional, Union, Dict
from pdfminer.pdfpage import PDFPage
from langchain_community.document_loaders import UnstructuredPowerPointLoader, UnstructuredExcelLoader, UnstructuredCSVLoader
import extract_msg


from config import load_config_data

MISTRAL_BASE_URL = load_config_data["MISTRAL_BASE_URL"]
MISTRAL_API_KEY = load_config_data["MISTRAL_API_KEY"]
MISTRAL_VISION_MODEL = load_config_data["MISTRAL_VISION_MEDIUM_LATEST"]

client = OpenAI(base_url=MISTRAL_BASE_URL, api_key=MISTRAL_API_KEY)

def iter_block_item(parent):
    if isinstance(parent, _Document):
        parent_elm = parent.element.body
    elif isinstance(parent, _Cell):
        parent_elm = parent._tc
    else:
        raise ValueError("Something's not right")
    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, parent)
        elif isinstance(child, CT_Tbl):
            yield Table(child, parent)

def table_print(block):
    table_text = str()
    # table = block
    for row in block.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                table_text += f'{paragraph.text} \n'
    return table_text

def docx_para_table(file):
    text = str()
    document = Document(file)
    for block in iter_block_item(document):
        if isinstance(block, Paragraph):
            text += f'{block.text} \n'
        elif isinstance(block, Table):
            text += table_print(block)
    return text

def text_extract_pypdf(file: str) -> str:
    """
    Extracts text from a PDF file using PyPDF.

    Args:
        file (str): Path to the PDF file.

    Returns:
        str: Extracted text from the PDF or an error message if extraction fails.
    """
    try:
        text = ""
        pdf = pypdf.PdfReader(file)
        for page in pdf.pages:
            text += page.extract_text()
        return text
    except Exception as ep:
        return f"Something went wrong: {ep}"
    
def text_extract_pdfplumber(file: str) -> str:
    """
    Extracts text from a PDF file using pdfplumber.

    Args:
        file (str): Path to the PDF file.

    Returns:
        str: Extracted text from the PDF or an error message if extraction fails.
    """
    try:
        text = ""
        with pdfplumber.open(file) as pdf_pages:
            for page in pdf_pages.pages:
                text += page.extract_text(x_tolerance=1, y_tolerance=1)
        return text
    except Exception as el:
        return f"Something went wrong: {el}"

def PDF_is_scanned(pdf_path: str) -> bool:
    """
    Determines if a PDF contains at least one scanned page.
    
    A scanned page is defined as a page that does not contain any selectable text, 
    meaning it consists primarily of images rather than digital text.

    Args:
        pdf_path (str): Path to the PDF file.

    Returns:
        bool: True if at least one page is scanned, False otherwise.
    """
    try:
        doc = fitz.open(pdf_path)
        for page in doc:
            text = page.get_text("text")
            if not text.strip():
                return True
        return False
    except Exception as e:
        return str(f"Error occured: {e}")
    
def pptx_extractor(file_path: str) -> str:
    """
    Extracts text from a PPTX file using UnstructuredPowerPointLoader from langchain.

    Args:
        file (str): Path to the PPTX file.

    Returns:
        str: Extracted text from the PPTX or an error message if extraction fails.
    """
    data = UnstructuredPowerPointLoader(file_path)
    raw_text = data.load()
    return raw_text[0].page_content

def excel_extractor(file_path: str) -> str:
    """
    Extracts text from a Excel file using UnstructuredExcelLoader from langchain.

    Args:
        file (str): Path to the Excel file.

    Returns:
        str: Extracted text from the Excel or an error message if extraction fails.
    """
    data = UnstructuredExcelLoader(file_path)
    raw_text = data.load()
    return raw_text[0].page_content

def csv_extractor(file_path: str) -> str:
    """
    Extracts text from a CSV file using UnstructuredCSVLoader from langchain.

    Args:
        file (str): Path to the CSV file.

    Returns:
        str: Extracted text from the CSV or an error message if extraction fails.
    """
    data = UnstructuredCSVLoader(file_path)
    raw_text = data.load()
    return raw_text[0].page_content

def encode_image(image_input: Union[str, io.BufferedReader, bytes, io.BytesIO]) -> str:
    """
    Encodes image data to a base64 string.

    Args:
        image_input: Path to an image file (str), an open BufferedReader object,
                     raw image bytes, or an io.BytesIO stream.

    Returns:
        A base64 encoded string of the image.
    """
    if isinstance(image_input, str):                    # File path
        with open(image_input, "rb") as image_file:
            img_data = image_file.read()
    elif isinstance(image_input, io.BytesIO):           # In-memory bytes stream
        img_data = image_input.getvalue()               # Use getvalue() for BytesIO
    elif isinstance(image_input, io.BufferedReader):    # General buffered reader (e.g., from open())
        img_data = image_input.read()
    elif isinstance(image_input, bytes):                # Raw bytes
        img_data = image_input
    else:
        raise ValueError(
            "Invalid input: image_input must be a file path string, an io.BytesIO object, "
            "a BufferedReader object, or bytes"
        )
    return base64.b64encode(img_data).decode("utf-8")

def image_to_text_using_LLM(image_path: str) -> Optional[str]:
    """
    Extracts all the text from an image using a vision-enabled Large Language Model (LLM).

    Args:
        image_path (str): The file path of the image to be processed.

    Returns:
        Optional[str]: The extracted text content from the image, or None if no content is found.
    """
    try:
        base64_image = encode_image(image_path)
        response = client.chat.completions.create(
            model=MISTRAL_VISION_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Extract all the text from this image."},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}},
                    ],
                }
            ],
        )
        if response.choices and response.choices[0].message and response.choices[0].message.content:
            return response.choices[0].message.content
        return None
    except Exception as e:
        return f"Error in image_to_text_using_LLM: {e}"
    
def pdf_page_details(file_path: str) -> Union[Dict[int, str], str]: # Corrected return type hint
    """
    Determines whether each page in a PDF file is scanned or searchable.

    Args:
        file_path (str): Path to the PDF file.

    Returns:
        Union[Dict[int, str], str]: A dictionary mapping page numbers (1-indexed)
                                     to "Scanned" or "Searchable", or an error message string.
    """
    try:
        page_details: Dict[int, str] = {}
        with open(file_path, 'rb') as infile:
            for page_num, page in enumerate(PDFPage.get_pages(infile, check_extractable=True), 1):
                if 'Font' not in page.resources:
                    page_details[page_num] = "Scanned"
                else:
                    page_details[page_num] = "Searchable"
        if not page_details: # Handle empty PDF or PDF with no processable pages
             return "No pages found or processed in PDF."
        return page_details
    
    except Exception as eps:
        return f"Error getting PDF page details: {eps}"

def all_pdf_extraction(pdf_file_path: str) -> str:
    """
    Extracts text from all pages of a PDF file.
    Uses pdfplumber for searchable pages and an LLM for scanned pages.

    Args:
        pdf_file_path (str): The path to the PDF file.

    Returns:
        str: The concatenated text extracted from all pages.
             Includes error messages for problematic pages or processes.
    """
    text_parts = []
    page_details_result = pdf_page_details(pdf_file_path)

    if isinstance(page_details_result, str):
        return f"Could not process PDF: {page_details_result}"

    page_details_map: Dict[int, str] = page_details_result

    try:
        with pdfplumber.open(pdf_file_path) as pdf:
            if not pdf.pages:
                return "The PDF has no pages."
                
            for i, pdf_page_obj in enumerate(pdf.pages):
                page_no = i + 1
                page_type = page_details_map.get(page_no)

                if page_type == "Searchable":
                    extracted_text = pdf_page_obj.extract_text(x_tolerance=2, y_tolerance=2, keep_blank_chars=True)
                    if extracted_text:
                        text_parts.append(f"Page no: {page_no} (Searchable)\n{extracted_text.strip()}\n\n")
                    else:
                        text_parts.append(f"Page no: {page_no} (Searchable)\n[No text extracted by pdfplumber]\n\n")
                
                elif page_type == "Scanned":
                    text_parts.append(f"Page no: {page_no} (Scanned)\n")
                    try:
                        pix = pdf_page_obj.to_image(resolution=144) 
                        pil_image = pix.original
                        img_byte_arr = io.BytesIO()
                        pil_image.save(img_byte_arr, format="PNG") # PNG is lossless and good for OCR
                        img_bytes = img_byte_arr.getvalue()
                        ocr_text = image_to_text_using_LLM(img_bytes)
                        if ocr_text:
                            text_parts.append(f"{ocr_text.strip()}\n\n")
                        else:
                            text_parts.append("[No text extracted by LLM or LLM error]\n\n")
                    except Exception as e:
                        text_parts.append(f"[Error processing scanned page {page_no}: {e}]\n\n")
                
                elif page_type is None:
                    # This might happen if pdf_page_details couldn't classify a page
                    # or if page numbering is inconsistent.
                    text_parts.append(f"Page no: {page_no}\n[Page type not determined by pdf_page_details]\n\n")
                
                else: # Should not happen if page_type is only "Searchable" or "Scanned"
                    text_parts.append(f"Page no: {page_no}\n[Unknown page type: {page_type}]\n\n")
    
    except Exception as e:
        error_message = f"An critical error occurred during PDF extraction: {e}"
        text_parts.append(error_message + "\n")

    final_text = "".join(text_parts)
    return final_text
    
def unwrapAttachments(msg):
    """
    Processes the attachments and outputs two arrays. The first contains regular
    attachments while the second contains embedded messages.
    """
    attachments = []
    msgFiles = []
    toProcess = [msg]
    while len(toProcess) > 0: # While we still have work to do.
        currentItem = toProcess.pop()
        for att in currentItem.attachments:
            if att.type == extract_msg.enums.AttachmentType.DATA:
                attachments.append(att)
            elif att.type ==extract_msg.enums.AttachmentType.MSG:
                msgFiles.append(att.data)
                toProcess.append(att.data)
    return attachments, msgFiles

def e_mail_msg(file):
    '''To get the msg body'''
    try:
        msg_data = extract_msg.open_msg(file)
        _attachments, msg_file = unwrapAttachments(msg_data)
        text = msg_data.body
        for _index, msg in enumerate(msg_file):
            text += msg.body
        return text
    except Exception as e:
        return e

def raw_text_from_file(file_path: str) -> str:
    """
    Extracts raw text from a given file, supporting DOCX and PDF formats.

    Args:
        file_path (str): The path to the input file.

    Returns:
        str: Extracted text from the file, or an error message if an issue occurs.
    """
    try:
        if os.path.basename(file_path).lower().endswith(".docx"):
            text = docx_para_table(file_path)
        elif os.path.basename(file_path).lower().endswith(".pdf"):
            text = all_pdf_extraction(file_path)
        elif os.path.basename(file_path).lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")):
            text = image_to_text_using_LLM(file_path)
        elif os.path.basename(file_path).lower().endswith(".pptx"):    
            text = pptx_extractor(file_path)
        elif os.path.basename(file_path).lower().endswith(".xlsx"):    
            text = excel_extractor(file_path)
        elif os.path.basename(file_path).lower().endswith(".csv"):
            text = csv_extractor(file_path)
        elif os.path.basename(file_path).lower().endswith(".msg"):
            text = e_mail_msg(file_path)
        else:
            raise ValueError(f"Unsupported file type {os.path.basename(file_path)}")
        return text
    except Exception as ex:
        return str(f"Error occurred {ex}")