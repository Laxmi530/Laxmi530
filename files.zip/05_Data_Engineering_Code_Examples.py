"""
=======================================================================
  DATA ENGINEERING - PYTHON CODE EXAMPLES
  For SQL Developers Transitioning to Data Engineering
=======================================================================
  This file contains practical, well-commented code examples covering
  key data engineering tasks. Each section includes explanations so
  you can understand the "why" behind the code, not just the "how".
=======================================================================
"""

# =====================================================================
# SECTION 1: BASIC ETL PIPELINE IN PYTHON
# =====================================================================
# This is the simplest form of a data pipeline. As a SQL developer,
# think of it as: SELECT → transform in Python → INSERT.

import pandas as pd
import json
import os
from datetime import datetime

def simple_etl_pipeline():
    """
    A basic ETL pipeline that:
    1. Extracts data from a CSV file
    2. Transforms it (cleaning, filtering, adding columns)
    3. Loads it into a new file (simulating a warehouse load)
    """
    
    # --- EXTRACT ---
    # In real life, this could be reading from a database, API, or cloud storage
    # For a SQL developer: this is like SELECT * FROM source_table
    print("Step 1: Extracting data...")
    
    # Sample data (in real projects, you'd read from a file or database)
    data = {
        'order_id': [1, 2, 3, 4, 5, 6],
        'customer_name': ['Alice', 'Bob', None, 'Diana', 'Eve', 'Frank'],
        'amount': [150.00, 200.50, 75.00, None, 320.00, 45.00],
        'order_date': ['2024-01-15', '2024-01-15', '2024-01-16', 
                       '2024-01-16', '2024-01-17', '2024-01-17'],
        'status': ['completed', 'completed', 'pending', 
                   'completed', 'cancelled', 'completed']
    }
    df = pd.DataFrame(data)
    print(f"  Extracted {len(df)} rows")
    print(df.to_string(index=False))
    
    # --- TRANSFORM ---
    # This is where you apply business logic, similar to CASE WHEN, WHERE, etc.
    print("\nStep 2: Transforming data...")
    
    # 2a. Handle NULL values (like COALESCE in SQL)
    df['customer_name'] = df['customer_name'].fillna('Unknown')
    df['amount'] = df['amount'].fillna(0.0)
    
    # 2b. Filter rows (like WHERE status = 'completed')
    df = df[df['status'] == 'completed']
    
    # 2c. Add computed columns (like SELECT ..., amount * 0.18 AS tax)
    df['tax'] = df['amount'] * 0.18
    df['total'] = df['amount'] + df['tax']
    
    # 2d. Convert data types (like CAST in SQL)
    df['order_date'] = pd.to_datetime(df['order_date'])
    
    # 2e. Add audit columns (common in data engineering)
    df['loaded_at'] = datetime.now()
    
    print(f"  After transformation: {len(df)} rows")
    print(df.to_string(index=False))
    
    # --- LOAD ---
    # In real life, you'd load this into a data warehouse
    # For now, we'll save to a Parquet file (industry standard format)
    print("\nStep 3: Loading data...")
    output_path = '/tmp/orders_fact.parquet'
    df.to_parquet(output_path, index=False)
    print(f"  Loaded {len(df)} rows to {output_path}")
    
    return df


# =====================================================================
# SECTION 2: READING DATA FROM MULTIPLE SOURCES
# =====================================================================
# Data engineers regularly pull from APIs, databases, and files.

def extract_from_api_example():
    """
    Example: Extracting data from a REST API.
    In real life, you'd use this to pull data from services like
    Stripe, Salesforce, or internal microservices.
    """
    import requests  # pip install requests
    
    # Example: Fetching data from a public API
    # (This simulates what you'd do with any REST API)
    url = "https://jsonplaceholder.typicode.com/posts"
    
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()  # Raises an error for 4xx/5xx status codes
        
        data = response.json()  # Parse JSON response
        df = pd.DataFrame(data)
        
        print(f"Fetched {len(df)} records from API")
        print(f"Columns: {list(df.columns)}")
        return df
        
    except requests.exceptions.RequestException as e:
        # Always handle errors gracefully in pipelines!
        print(f"API request failed: {e}")
        return pd.DataFrame()  # Return empty DataFrame on failure


def extract_from_database_example():
    """
    Example: Extracting data from a SQL database.
    As a SQL developer, this should feel very familiar!
    
    NOTE: This is pseudocode — you'd need an actual database to run it.
    """
    # pip install sqlalchemy psycopg2-binary  (for PostgreSQL)
    # pip install sqlalchemy pymssql           (for SQL Server)
    
    from sqlalchemy import create_engine
    
    # Connection string format:
    # PostgreSQL: postgresql://user:password@host:port/database
    # SQL Server: mssql+pymssql://user:password@host:port/database
    # MySQL:      mysql+pymysql://user:password@host:port/database
    
    connection_string = "postgresql://user:password@localhost:5432/mydb"
    engine = create_engine(connection_string)
    
    # You can write ANY SQL query here — just like you do today!
    query = """
        SELECT 
            o.order_id,
            c.customer_name,
            o.amount,
            o.order_date
        FROM orders o
        JOIN customers c ON o.customer_id = c.customer_id
        WHERE o.order_date >= '2024-01-01'
    """
    
    # pandas reads the query result directly into a DataFrame
    df = pd.read_sql(query, engine)
    print(f"Extracted {len(df)} rows from database")
    return df


# =====================================================================
# SECTION 3: DATA QUALITY CHECKS
# =====================================================================
# Data quality is a core responsibility of data engineers.
# These checks run BETWEEN pipeline stages.

def run_data_quality_checks(df, table_name="unknown"):
    """
    A simple data quality framework.
    In production, you'd use tools like Great Expectations or dbt tests,
    but understanding the logic is essential for interviews.
    """
    print(f"\n{'='*50}")
    print(f"DATA QUALITY REPORT: {table_name}")
    print(f"{'='*50}")
    
    issues = []
    
    # Check 1: Row count (alert if table is empty or suspiciously small)
    row_count = len(df)
    if row_count == 0:
        issues.append("CRITICAL: Table is empty!")
    print(f"Row Count: {row_count}")
    
    # Check 2: Null values per column
    print("\nNull Counts:")
    for col in df.columns:
        null_count = df[col].isnull().sum()
        null_pct = (null_count / row_count * 100) if row_count > 0 else 0
        status = "FAIL" if null_pct > 5 else "PASS"
        print(f"  {col}: {null_count} nulls ({null_pct:.1f}%) [{status}]")
        if null_pct > 5:
            issues.append(f"Column '{col}' has {null_pct:.1f}% null values")
    
    # Check 3: Duplicate check on primary key
    if 'order_id' in df.columns:
        dup_count = df['order_id'].duplicated().sum()
        status = "FAIL" if dup_count > 0 else "PASS"
        print(f"\nDuplicate order_ids: {dup_count} [{status}]")
        if dup_count > 0:
            issues.append(f"{dup_count} duplicate order_ids found")
    
    # Check 4: Value range validation
    if 'amount' in df.columns:
        negative = (df['amount'] < 0).sum()
        status = "FAIL" if negative > 0 else "PASS"
        print(f"Negative amounts: {negative} [{status}]")
        if negative > 0:
            issues.append(f"{negative} records have negative amounts")
    
    # Summary
    print(f"\n{'─'*50}")
    if issues:
        print(f"RESULT: FAILED — {len(issues)} issue(s) found:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("RESULT: ALL CHECKS PASSED")
    print(f"{'='*50}\n")
    
    return len(issues) == 0


# =====================================================================
# SECTION 4: INCREMENTAL LOADING (VERY COMMON IN INTERVIEWS)
# =====================================================================
# Instead of reloading all data every time (full load), incremental
# loading only processes NEW or CHANGED records.

def incremental_load_example():
    """
    Demonstrates incremental loading using a watermark (last_loaded_at).
    
    SQL Developer analogy:
    - Full load = TRUNCATE + INSERT
    - Incremental load = INSERT WHERE modified_date > @last_run
    """
    
    # Simulate: watermark tracking (in production, store this in a metadata table)
    watermark_file = '/tmp/watermark.json'
    
    # Get last loaded timestamp
    if os.path.exists(watermark_file):
        with open(watermark_file) as f:
            last_loaded = datetime.fromisoformat(json.load(f)['last_loaded'])
    else:
        last_loaded = datetime(2000, 1, 1)  # First run: load everything
    
    print(f"Last loaded at: {last_loaded}")
    
    # In real life, you'd query the source with a WHERE clause:
    # SELECT * FROM orders WHERE modified_at > '{last_loaded}'
    
    # Simulate new data arriving
    new_data = pd.DataFrame({
        'order_id': [101, 102],
        'amount': [250.00, 180.00],
        'modified_at': [datetime.now(), datetime.now()]
    })
    
    print(f"Found {len(new_data)} new/modified records")
    
    # Load only new records (MERGE/UPSERT in production)
    # In SQL terms: MERGE INTO target USING new_data ON order_id ...
    output_path = '/tmp/orders_incremental.parquet'
    
    if os.path.exists(output_path):
        existing = pd.read_parquet(output_path)
        # UPSERT: Remove old versions of updated records, then append new ones
        existing = existing[~existing['order_id'].isin(new_data['order_id'])]
        combined = pd.concat([existing, new_data], ignore_index=True)
    else:
        combined = new_data
    
    combined.to_parquet(output_path, index=False)
    
    # Update watermark
    with open(watermark_file, 'w') as f:
        json.dump({'last_loaded': datetime.now().isoformat()}, f)
    
    print(f"Loaded {len(new_data)} records. Total: {len(combined)}")


# =====================================================================
# SECTION 5: SLOWLY CHANGING DIMENSIONS (SCD TYPE 2)
# =====================================================================
# This is one of the MOST ASKED topics in data engineering interviews.
# SCD Type 2 tracks historical changes by adding new rows.

def scd_type2_example():
    """
    Implements SCD Type 2 logic in Python.
    
    Scenario: A customer changes their city from "Mumbai" to "Pune".
    Instead of overwriting (Type 1), we keep both records with
    effective dates so we can see the history.
    """
    
    # Current dimension table
    dim_customer = pd.DataFrame({
        'customer_key': [1],            # Surrogate key
        'customer_id': ['C001'],         # Natural/business key
        'name': ['Rajesh Kumar'],
        'city': ['Mumbai'],
        'effective_start': [datetime(2023, 1, 1)],
        'effective_end': [datetime(9999, 12, 31)],  # Open-ended = current
        'is_current': [True]
    })
    
    print("BEFORE UPDATE:")
    print(dim_customer.to_string(index=False))
    
    # Incoming change: Rajesh moved to Pune
    incoming = pd.DataFrame({
        'customer_id': ['C001'],
        'name': ['Rajesh Kumar'],
        'city': ['Pune']   # <-- Changed!
    })
    
    # Step 1: Find matching records
    merged = dim_customer[dim_customer['is_current']].merge(
        incoming, on='customer_id', suffixes=('_old', '_new')
    )
    
    # Step 2: Detect changes (compare relevant columns)
    changed = merged[merged['city_old'] != merged['city_new']]
    
    if len(changed) > 0:
        now = datetime.now()
        
        # Step 3: Close the old record (set end date and is_current = False)
        for idx, row in changed.iterrows():
            mask = (
                (dim_customer['customer_id'] == row['customer_id']) & 
                (dim_customer['is_current'] == True)
            )
            dim_customer.loc[mask, 'effective_end'] = now
            dim_customer.loc[mask, 'is_current'] = False
        
        # Step 4: Insert new record with updated values
        new_key = dim_customer['customer_key'].max() + 1
        new_row = pd.DataFrame({
            'customer_key': [new_key],
            'customer_id': ['C001'],
            'name': ['Rajesh Kumar'],
            'city': ['Pune'],               # <-- New value
            'effective_start': [now],
            'effective_end': [datetime(9999, 12, 31)],
            'is_current': [True]
        })
        
        dim_customer = pd.concat([dim_customer, new_row], ignore_index=True)
    
    print("\nAFTER UPDATE (SCD Type 2):")
    print(dim_customer.to_string(index=False))
    print("\nNotice: Both records exist. The old one is closed (is_current=False)")
    print("and the new one is active. This preserves complete history.")


# =====================================================================
# SECTION 6: WORKING WITH PARQUET FILES
# =====================================================================
# Parquet is THE standard file format in data engineering.
# As a SQL developer, think of it as a highly optimised table on disk.

def parquet_examples():
    """
    Demonstrates why Parquet is preferred over CSV in data engineering.
    
    Key advantages:
    - Columnar storage (only reads needed columns — like covering indexes!)
    - Built-in compression (Snappy, Gzip)
    - Schema embedded in file
    - Supports complex types (arrays, maps, structs)
    """
    
    # Create sample data
    df = pd.DataFrame({
        'order_id': range(1, 10001),
        'customer_id': [f'C{i%100:03d}' for i in range(10000)],
        'amount': [round(50 + i * 0.5, 2) for i in range(10000)],
        'category': ['Electronics', 'Clothing', 'Food', 'Books', 'Sports'] * 2000,
        'order_date': pd.date_range('2024-01-01', periods=10000, freq='h')
    })
    
    # Save as CSV vs Parquet and compare
    csv_path = '/tmp/sample_data.csv'
    parquet_path = '/tmp/sample_data.parquet'
    
    df.to_csv(csv_path, index=False)
    df.to_parquet(parquet_path, index=False, compression='snappy')
    
    csv_size = os.path.getsize(csv_path)
    parquet_size = os.path.getsize(parquet_path)
    
    print(f"Row count:    {len(df):,}")
    print(f"CSV size:     {csv_size:,} bytes ({csv_size/1024:.1f} KB)")
    print(f"Parquet size: {parquet_size:,} bytes ({parquet_size/1024:.1f} KB)")
    print(f"Compression:  {(1 - parquet_size/csv_size)*100:.1f}% smaller")
    
    # Reading specific columns from Parquet (column pruning)
    # This is like SELECT amount, category FROM table (no full scan!)
    df_subset = pd.read_parquet(parquet_path, columns=['amount', 'category'])
    print(f"\nColumn pruning: Read only 2 of {len(df.columns)} columns")
    print(f"Average amount by category:")
    print(df_subset.groupby('category')['amount'].mean().to_string())


# =====================================================================
# SECTION 7: PARTITIONED DATA (DATA LAKE PATTERN)
# =====================================================================
# In data lakes, data is stored in folders by partition (e.g., date).
# This is like table partitioning in SQL Server or PostgreSQL.

def partitioned_write_example():
    """
    Writes data partitioned by date, mimicking how data is stored
    in S3/ADLS data lakes.
    
    Directory structure:
    /data/orders/order_date=2024-01-15/part-0.parquet
    /data/orders/order_date=2024-01-16/part-0.parquet
    """
    
    df = pd.DataFrame({
        'order_id': range(1, 7),
        'amount': [100, 200, 150, 300, 250, 175],
        'order_date': ['2024-01-15', '2024-01-15', '2024-01-16',
                       '2024-01-16', '2024-01-17', '2024-01-17']
    })
    
    base_path = '/tmp/data_lake/orders'
    
    # Write each partition separately (this is what Spark does automatically)
    for date, group in df.groupby('order_date'):
        partition_path = f"{base_path}/order_date={date}"
        os.makedirs(partition_path, exist_ok=True)
        group.drop('order_date', axis=1).to_parquet(
            f"{partition_path}/part-0.parquet", index=False
        )
        print(f"Written {len(group)} rows to {partition_path}/")
    
    print(f"\nPartitioned structure:")
    for root, dirs, files in os.walk(base_path):
        for f in files:
            print(f"  {os.path.join(root, f)}")
    
    # Reading a specific partition (partition pruning)
    # This only reads data for Jan 16 — not the entire dataset!
    target_date = '2024-01-16'
    partition_df = pd.read_parquet(
        f"{base_path}/order_date={target_date}/part-0.parquet"
    )
    print(f"\nPartition pruning: Read only date={target_date}")
    print(f"Rows: {len(partition_df)} (instead of {len(df)} total)")


# =====================================================================
# SECTION 8: ERROR HANDLING & LOGGING IN PIPELINES
# =====================================================================
# Production pipelines MUST handle errors gracefully.

import logging

def setup_pipeline_logger(name):
    """Set up structured logging for a data pipeline."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        '%(asctime)s | %(name)s | %(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


def robust_pipeline_example():
    """
    A pipeline with proper error handling, logging, and retry logic.
    This is what production-grade pipelines look like.
    """
    import time
    
    logger = setup_pipeline_logger('orders_pipeline')
    
    def retry_with_backoff(func, max_retries=3, initial_delay=1):
        """Retry a function with exponential backoff."""
        for attempt in range(max_retries):
            try:
                return func()
            except Exception as e:
                wait_time = initial_delay * (2 ** attempt)
                logger.warning(
                    f"Attempt {attempt+1}/{max_retries} failed: {e}. "
                    f"Retrying in {wait_time}s..."
                )
                time.sleep(wait_time)
        raise Exception(f"All {max_retries} attempts failed")
    
    # Pipeline execution with error handling
    pipeline_start = datetime.now()
    logger.info("Pipeline started")
    
    try:
        # Extract
        logger.info("EXTRACT: Reading source data...")
        df = pd.DataFrame({
            'order_id': [1, 2, 3],
            'amount': [100, 200, 300]
        })
        logger.info(f"EXTRACT: Read {len(df)} rows")
        
        # Transform
        logger.info("TRANSFORM: Applying business logic...")
        df['tax'] = df['amount'] * 0.18
        df['total'] = df['amount'] + df['tax']
        logger.info(f"TRANSFORM: Processed {len(df)} rows")
        
        # Quality check
        logger.info("QUALITY: Running checks...")
        assert len(df) > 0, "DataFrame is empty!"
        assert df['amount'].isnull().sum() == 0, "Null amounts found!"
        logger.info("QUALITY: All checks passed")
        
        # Load
        logger.info("LOAD: Writing to target...")
        df.to_parquet('/tmp/output.parquet', index=False)
        logger.info("LOAD: Complete")
        
        duration = (datetime.now() - pipeline_start).total_seconds()
        logger.info(f"Pipeline completed in {duration:.1f}s. Rows: {len(df)}")
        
    except AssertionError as e:
        logger.error(f"DATA QUALITY FAILURE: {e}")
        raise
    except Exception as e:
        logger.error(f"PIPELINE FAILURE: {e}")
        raise


# =====================================================================
# MAIN: Run all examples
# =====================================================================
if __name__ == "__main__":
    print("\n" + "="*60)
    print("  EXAMPLE 1: Simple ETL Pipeline")
    print("="*60)
    result_df = simple_etl_pipeline()
    
    print("\n" + "="*60)
    print("  EXAMPLE 2: Data Quality Checks")
    print("="*60)
    run_data_quality_checks(result_df, "orders_fact")
    
    print("\n" + "="*60)
    print("  EXAMPLE 3: Incremental Loading")
    print("="*60)
    incremental_load_example()
    
    print("\n" + "="*60)
    print("  EXAMPLE 4: SCD Type 2")
    print("="*60)
    scd_type2_example()
    
    print("\n" + "="*60)
    print("  EXAMPLE 5: Parquet File Operations")
    print("="*60)
    parquet_examples()
    
    print("\n" + "="*60)
    print("  EXAMPLE 6: Partitioned Data (Data Lake Pattern)")
    print("="*60)
    partitioned_write_example()
    
    print("\n" + "="*60)
    print("  EXAMPLE 7: Robust Pipeline with Error Handling")
    print("="*60)
    robust_pipeline_example()
    
    print("\n" + "="*60)
    print("  ALL EXAMPLES COMPLETE!")
    print("="*60)
