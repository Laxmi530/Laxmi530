# Senior Business Analyst — Interview Preparation Guide
### US Healthcare Benefits · APIs · SQL · Agile Delivery

*Tailored for a candidate with 7+ years of BA experience targeting a Senior BA role in India working on US healthcare payer systems.*

---

## How to position yourself (read this first)

At 7+ years and a "Senior" title, interviewers are no longer testing whether you *know* what a use case or a JOIN is. They are testing three things:

1. **Judgment** — can you make lifecycle, scoping, and trade-off decisions, not just document what you're told?
2. **Bridging** — can you sit between a benefits business owner who talks in "copay tiers" and an engineer who talks in "FHIR resources and payload size," and make both sides feel understood?
3. **Domain depth** — do you actually understand US healthcare (payers, benefits, claims, EDI, HIPAA), or have you only worked adjacent to it?

Anchor almost every answer in a real example using **STAR** (Situation, Task, Action, Result) and quantify the result wherever you can ("reduced claim-mapping defects by ~30%," "cut eligibility-API response payload by half"). Seniors tell stories with outcomes; juniors recite definitions.

---

# PART 1 — Answers Mapped to the Job Responsibilities

Each responsibility below has: *what they're really assessing*, a *model answer*, and *talking points* you can redeploy.

---

### 1. "Gather and analyze healthcare benefits business requirements"

**What they're assessing:** Do you know how to elicit requirements in a regulated, jargon-heavy domain, and can you separate a stated want from the underlying business need?

**Model answer:**
> "My starting point is always to understand *who consumes the benefit outcome* — the member, the provider, the employer group, or a downstream system. For benefits work I use a mix of techniques: stakeholder interviews with product and compliance owners, reviewing existing plan documents like the Summary of Benefits and Coverage, analyzing the current-state data in the claims and eligibility systems, and running collaborative workshops to walk through member journeys.
>
> The critical part in benefits is precision on the *rules*. If a stakeholder says 'members should see their deductible,' I dig into whether that's the individual or family deductible, in-network vs out-of-network accumulators, whether it resets on plan year or calendar year, and how it interacts with the out-of-pocket maximum. I document these as explicit business rules with examples, because in healthcare an ambiguous rule becomes a wrong claim payment or a compliance issue. I always validate my understanding back to the stakeholders using concrete scenarios rather than abstract statements."

**Talking points / vocabulary to weave in:** premium, deductible (individual/family), copay, coinsurance, out-of-pocket maximum, accumulators, in-network vs out-of-network, plan year vs calendar year, formulary, prior authorization, Summary of Benefits and Coverage (SBC), plan tiers (HMO/PPO/EPO/POS/HDHP). Mention elicitation techniques by name: interviews, workshops, document analysis, observation, prototyping, current-state data analysis.

---

### 2. "Translate requirements into functional/system and API specifications"

**What they're assessing:** Can you produce artifacts an engineer can build from without a dozen follow-up questions, and do you understand what an API spec actually contains?

**Model answer:**
> "I treat translation as a layered process. I start with the business requirement, decompose it into functional requirements, then into system behavior, and where an integration is involved, into an API contract.
>
> For a functional spec I define the actors, preconditions, the main and alternate flows, business rules, validations, and error handling. For the API layer specifically, I define the endpoint and method, the request and response schema field-by-field with data types and whether each field is mandatory or optional, the authentication method, expected HTTP status and error codes, and the non-functional requirements — expected volume, latency, and pagination. I document this in an OpenAPI/Swagger-style structure so the spec is directly consumable by the API developers and by QA.
>
> A concrete example: for an eligibility-check feature, the business need was 'let the portal show real-time coverage.' I translated that into a functional spec for the member-facing behavior, and an API spec describing a call that takes a member ID and date of service and returns coverage status, plan details, and accumulator balances — essentially the business meaning of an X12 270/271 eligibility inquiry and response, exposed as a modern REST/JSON contract."

**Talking points:** functional requirement vs non-functional requirement, request/response schema, field-level data dictionary, mandatory vs optional fields, HTTP methods and status codes, OpenAPI/Swagger, error handling, idempotency, pagination, mapping legacy EDI transactions (270/271, 278, 837) to REST/FHIR contracts.

---

### 3. "Analyze API inventory, usage, data volume, and lifecycle decisions"

**What they're assessing:** This is the most senior/technical bullet. They want someone who can look across a portfolio of APIs and make rationalization and retirement decisions backed by data — not just document one API.

**Model answer:**
> "I approach this as portfolio rationalization. First I build or refresh the **API inventory** — a catalog of every API with its owner, consumers, the business capability it serves, the data domains it touches (member, claims, provider, benefits), its version, and its integration pattern.
>
> Then I bring in **usage data** — call volumes over time, per-consumer traffic, peak vs average load, error rates, and latency. This tells me which APIs are load-bearing, which are barely used, and which are duplicative. I pull a lot of this from API gateway logs and analytics, and I'll write SQL against the logging/metrics store to segment usage by consumer, endpoint, and time window.
>
> **Data volume** analysis feeds design decisions: an eligibility API that returns a huge payload but where consumers only use three fields is a candidate for a slimmer response or field filtering; a high-volume claims-status API might need caching or pagination.
>
> Finally, **lifecycle decisions** — for each API I recommend one of: invest/enhance, maintain as-is, consolidate with a duplicate, deprecate with a migration path, or retire. I document deprecation timelines, notify consumers, provide the target replacement, and track migration. In a healthcare payer context this is topical right now because CMS interoperability rules are pushing payers toward standardized FHIR-based APIs, so part of lifecycle planning is deciding what proprietary APIs get replaced by standards-based ones."

**Talking points:** API catalog/inventory, API consumers, call volume, error rate, latency, API gateway analytics, deprecation vs retirement, versioning strategy (URI vs header), backward compatibility, migration path, duplicate/overlapping API consolidation, payload optimization, caching, rate limiting. Bonus senior signal: tie it to **CMS-0057-F** driving standardized FHIR APIs (Patient Access, Provider Access, Payer-to-Payer, Prior Authorization).

---

### 4. "Collaborate with business and technical teams to validate solutions"

**What they're assessing:** Facilitation and conflict-resolution skills; can you get two groups who speak different languages to agree a solution is correct?

**Model answer:**
> "Validation for me happens continuously, not just at the end. During design I run walkthroughs where I present the proposed solution back to the business in their language — using real member scenarios — and to engineering in system terms, and I make the two views reconcile. I use techniques like requirement traceability, where every requirement maps to a design element and a test case, so nothing silently drops.
>
> When business and technical teams disagree — which is normal — I don't referee on opinion. I reframe the disagreement around the actual constraint: is it feasibility, cost, timeline, compliance, or member impact? Then I put options on the table with trade-offs and let the accountable owner decide, documenting the decision and rationale. A recent example: the business wanted a new benefits field surfaced in real time, engineering flagged that the source system only refreshed nightly. Rather than force a position, I surfaced the gap, proposed a phased option — nightly now, real time later — and both sides aligned because the trade-off was explicit."

**Talking points:** requirement traceability matrix, solution walkthroughs, proof-of-concept, prototypes, feasibility vs desirability, documented decisions and rationale, RACI, managing conflicting stakeholders, "disagree and commit."

---

### 5. "Support data-driven and AI-enabled solution initiatives"

**What they're assessing:** Can you contribute meaningfully to analytics/AI work — mainly by getting the *data and use case* right — without overstating that you're a data scientist?

**Model answer:**
> "My role on data and AI initiatives is to make sure we solve the right problem with trustworthy data. On the data-driven side, I define the metrics and KPIs the business actually needs, make sure the underlying data is available and clean, and I profile it with SQL to check completeness, duplicates, and outliers before anyone builds a dashboard or model on it.
>
> On AI-enabled work, I focus on three things. First, **use-case framing** — is this a genuine prediction/automation problem with clear value, like flagging claims likely to be denied, or predicting prior-authorization outcomes? Second, **data readiness and features** — I help identify which data elements are relevant and check for gaps, bias, and PHI handling, because in healthcare the governance bar is high. Third, **success criteria and guardrails** — what accuracy or business outcome defines success, and where does a human stay in the loop, especially for anything touching coverage or medical decisions.
>
> I'm candid that I'm not the model builder — my value is translating the business problem into something the data science team can execute, and translating their output back into a decision the business trusts."

**Talking points:** data profiling, data quality dimensions (completeness, accuracy, consistency, timeliness), KPI definition, use-case prioritization, feature relevance, bias, PHI/PII governance, human-in-the-loop, model success criteria, explainability. Healthcare AI examples: denial prediction, prior-auth automation, fraud-waste-abuse detection, member risk stratification, claims auto-adjudication. Show awareness that AI touching clinical/coverage decisions carries regulatory and ethical weight.

---

### 6. "Drive requirement documentation, testing support, and release planning"

**What they're assessing:** End-to-end ownership — can you carry a requirement from documentation through testing to a controlled release?

**Model answer:**
> "I own the requirement through its whole life. On documentation, I maintain the source of truth — user stories with acceptance criteria in the backlog, plus supporting functional and interface specs and a data dictionary where needed. I keep a traceability matrix so we can prove coverage.
>
> On testing support, I write or review acceptance criteria before development starts so QA and dev share the same definition of done. I help define test scenarios, support QA in interpreting requirements, participate in triaging defects to decide whether something is a bug or a requirement gap, and I lead or coordinate UAT with business users — building test scripts around real member and claims scenarios and getting formal sign-off.
>
> On release planning, I help sequence features by dependency and business priority, define what's in each release, coordinate cutover and data-migration considerations, prepare release notes for stakeholders, and plan for validation in production. In a healthcare setting I pay special attention to regulatory deadlines — for example a compliance-driven API go-live has a hard date, so I plan backwards from it and protect that scope."

**Talking points:** user stories, acceptance criteria (Given/When/Then), definition of ready/done, requirement traceability matrix, test scenarios, UAT, defect triage, sign-off, release scope, dependency sequencing, cutover, rollback plan, release notes, regulatory deadline-driven planning.

---

# PART 2 — US Healthcare & Benefits Domain Q&A

> This is where India-based candidates win or lose the interview. Depth here signals you've genuinely worked US payer systems.

**Q: Walk me through the main players in US healthcare and how money and data flow.**
The core actors are the **member/patient** (the insured person), the **payer** (the health insurance plan — commercial insurers, or government programs like Medicare and Medicaid), the **provider** (doctor, hospital, lab), and often an **employer/plan sponsor** who buys group coverage. Money flow: the member/employer pays **premiums** to the payer; the provider delivers care and submits a **claim** to the payer; the payer **adjudicates** the claim against the member's benefits and pays the provider (minus the member's share); the member pays their portion via **copay, deductible, and coinsurance**. Data flows through standardized **EDI transactions** and, increasingly, APIs.

**Q: Explain the key benefits/cost-share concepts.**
- **Premium** — the fixed amount paid (usually monthly) to have coverage, regardless of usage.
- **Deductible** — the amount the member pays out of pocket before the plan starts paying. Can be individual or family, and often separate in-network vs out-of-network.
- **Copay** — a fixed dollar amount for a service (e.g., $30 per office visit).
- **Coinsurance** — a percentage the member pays after the deductible (e.g., plan pays 80%, member pays 20%).
- **Out-of-pocket (OOP) maximum** — the annual cap on member spending; once hit, the plan pays 100% of covered services.
- **Accumulators** — running totals that track how much of the deductible and OOP max a member has used; they drive real-time cost-share calculation.
- **Formulary** — the list of drugs the plan covers, usually organized in tiers.

**Q: What are the main types of US health plans?**
- **HMO** (Health Maintenance Organization) — must use in-network providers, needs a primary care physician (PCP) and referrals; cheapest, least flexible.
- **PPO** (Preferred Provider Organization) — flexible, can go out of network at higher cost, no referral needed.
- **EPO** (Exclusive Provider Organization) — in-network only like an HMO, but usually no referral requirement.
- **POS** (Point of Service) — hybrid of HMO and PPO.
- **HDHP** (High-Deductible Health Plan) — low premium, high deductible, usually paired with an **HSA** (Health Savings Account).
- Government programs: **Medicare** (65+ and certain disabilities), **Medicaid** (low income, state-administered), **CHIP** (children), and **ACA/Marketplace** plans (individual coverage via exchanges).

**Q: Walk me through the claims lifecycle.**
Provider delivers care → provider (or their billing system/clearinghouse) submits a claim (**837**) → the claim passes through a **clearinghouse** that validates and scrubs it → payer receives and **adjudicates** it (checks eligibility, benefits, medical necessity, coding, duplicates, coordination of benefits) → payer issues a payment and an electronic remittance advice (**835**) explaining what was paid, adjusted, or denied → provider posts the payment; member gets an Explanation of Benefits (EOB). Denials come back with reason codes (CARC/RARC), and providers can correct and resubmit or appeal.

**Q: Explain the key HIPAA EDI transactions a benefits BA should know.**
- **270 / 271** — Eligibility & Benefit **Inquiry / Response**. The 270 asks "is this member covered and what are their benefits?"; the 271 answers with coverage status, plan details, copays, deductible, and accumulator balances.
- **834** — Benefit **Enrollment and Maintenance**. Sends member enrollment data from the employer/sponsor to the health plan (adds, changes, terminations).
- **837** — Health Care **Claim**. Comes in 837P (professional), 837I (institutional/hospital), and 837D (dental). It replaced the paper CMS-1500 and UB-04 forms.
- **835** — **Remittance Advice** (ERA). Tells the provider how the claim was paid, adjusted, or denied, and drives auto-posting.
- **276 / 277** — Claim **Status Request / Response**.
- **278** — **Prior Authorization / referral** request and response.
- **820** — Premium **payment**.
All of these are ASC X12 standards mandated under HIPAA's Administrative Simplification rules, and they travel in envelopes (ISA/GS/ST) with acknowledgments (999/997, 277CA).

**Q: What is HIPAA and why does it matter to a BA?**
HIPAA is the US law governing health data. Two parts matter most: the **Privacy/Security Rules**, which protect **PHI** (Protected Health Information) and dictate how it's stored, transmitted, and accessed — so as a BA you must design for encryption, access controls, audit trails, and minimum-necessary data exposure — and **Administrative Simplification**, which mandates the standard EDI transactions and code sets above. Any requirement or API touching member data has to respect these constraints.

**Q: What's happening with healthcare interoperability right now (2026)? (High-value, current)**
The major driver is the **CMS Interoperability and Prior Authorization Final Rule (CMS-0057-F)**. It requires impacted payers — Medicare Advantage, Medicaid/CHIP, and ACA Marketplace (QHP) plans — to implement standardized **HL7 FHIR** APIs: a **Patient Access API**, a **Provider Access API**, a **Payer-to-Payer API**, and a **Prior Authorization API**. Key timeline: several operational requirements (faster prior-authorization decisions — 72 hours for urgent, 7 calendar days for standard — and public reporting of prior-auth metrics) began **January 1, 2026**, and the required FHIR APIs must be in production by **January 1, 2027**. Payers must also give a specific reason for prior-authorization denials. Mentioning this shows you're current and understand the direction of the industry (moving from fax/X12-only workflows toward standards-based FHIR APIs).

**Q: What's the difference between HL7 v2, FHIR, and X12?**
**X12** is the older EDI standard for administrative/financial transactions (claims, eligibility, payments). **HL7 v2** is legacy clinical messaging (still very common in hospitals). **FHIR** (Fast Healthcare Interoperability Resources) is the modern, REST/JSON-based standard for exchanging both clinical and administrative data over web APIs — it's what CMS interoperability rules are built on. As a BA you'll increasingly map legacy X12/HL7 data into FHIR resources.

---

# PART 3 — API Q&A

**Q: What is an API and how do you explain it to a business stakeholder?**
An API is a contract that lets two software systems exchange data in a defined, predictable way. To a business person I'd say: "It's like a waiter — the business system places an order (request) in a standard format, and the kitchen (another system) returns exactly what was asked for (response), without either side needing to know how the other works internally."

**Q: Explain REST, HTTP methods, and status codes.**
**REST** is an architectural style for web APIs using standard HTTP. The main methods: **GET** (read), **POST** (create), **PUT/PATCH** (update), **DELETE** (remove). Common status codes: **200** OK, **201** Created, **400** Bad Request (client sent something invalid), **401** Unauthorized, **403** Forbidden, **404** Not Found, **429** Too Many Requests (rate limited), **500** Internal Server Error. Knowing these lets you write meaningful error-handling requirements.

**Q: What belongs in an API specification you'd hand to a developer?**
Endpoint URL and HTTP method; purpose; authentication/authorization method; request parameters and body schema (each field with name, data type, mandatory/optional, description, validation); response schema for success; all error responses with status codes and messages; non-functional requirements (expected volume, latency, pagination, rate limits); and example request/response payloads. I document this in an **OpenAPI/Swagger** structure so it's machine-readable and directly usable by dev and QA.

**Q: How do you handle API authentication and security in specs?**
Most modern APIs use **OAuth 2.0** (token-based) or API keys. In healthcare, the FHIR ecosystem uses **SMART on FHIR** (OAuth2/OpenID Connect) for app authorization and patient consent. Security requirements I always specify: encryption in transit (TLS), authentication method, authorization/scopes (who can access what), PHI handling and the minimum-necessary principle, and audit logging.

**Q: How do you analyze API usage and decide on lifecycle? (ties to JD bullet 3)**
See the detailed answer in Part 1 #3 — inventory → usage/volume/error metrics → rationalization decision (enhance / maintain / consolidate / deprecate / retire) → migration plan. Key metrics: call volume per consumer and endpoint, peak vs average, error rate, latency, payload size, and business value. Deprecation needs a communicated timeline, a replacement/target, and consumer migration tracking.

**Q: What is API versioning and why does it matter?**
When you change an API in a way that could break existing consumers, you version it (e.g., `/v1/`, `/v2/` in the URL, or via headers). Backward compatibility means old consumers keep working; a breaking change forces a new version and a migration plan. This directly feeds lifecycle decisions.

**Q: How would you map a legacy EDI transaction to a modern API?**
Take a **270/271 eligibility** transaction: the business meaning is "check whether a member is covered and return benefits." I'd design a REST endpoint like `GET /eligibility` that accepts member ID and date of service and returns coverage status, plan, copays, deductible, and accumulators as JSON — capturing the same business content as the X12 271, but in a modern, consumable contract (or as a FHIR `CoverageEligibilityRequest`/`CoverageEligibilityResponse` if aligning to FHIR).

---

# PART 4 — SQL Q&A (strong SQL was explicitly called out)

> Expect to be asked to *write* queries, not just define terms. Practice on paper. Below are the concepts plus healthcare-flavored examples.

**Q: Explain the types of JOINs.**
- **INNER JOIN** — only rows matching in both tables.
- **LEFT (OUTER) JOIN** — all rows from the left table, plus matches from the right (NULLs where no match). Useful to find members *with no* claims.
- **RIGHT JOIN** — mirror of left.
- **FULL OUTER JOIN** — all rows from both, matched where possible.
- **CROSS JOIN** — every combination (Cartesian product).

**Q: Difference between WHERE and HAVING?**
`WHERE` filters rows *before* aggregation; `HAVING` filters *after* aggregation (on grouped results). Example: `WHERE claim_status = 'Denied'` filters individual claims; `HAVING COUNT(*) > 100` filters groups.

**Q: GROUP BY example — count denied claims by payer.**
```sql
SELECT payer_id,
       COUNT(*) AS denied_claims
FROM claims
WHERE claim_status = 'Denied'
GROUP BY payer_id
HAVING COUNT(*) > 100
ORDER BY denied_claims DESC;
```

**Q: Find members who have no claims (LEFT JOIN + NULL).**
```sql
SELECT m.member_id, m.member_name
FROM members m
LEFT JOIN claims c ON m.member_id = c.member_id
WHERE c.member_id IS NULL;
```

**Q: What are window functions and when do you use them?**
They compute across a set of rows *without collapsing* them (unlike GROUP BY). Common ones: `ROW_NUMBER()`, `RANK()`, `DENSE_RANK()`, `LAG()/LEAD()`, and running totals with `SUM() OVER (...)`. Example — rank each member's claims by amount:
```sql
SELECT member_id,
       claim_id,
       claim_amount,
       ROW_NUMBER() OVER (PARTITION BY member_id
                          ORDER BY claim_amount DESC) AS rn
FROM claims;
```
To get each member's single highest claim, wrap it in a subquery/CTE and filter `WHERE rn = 1`.

**Q: What is a CTE and why use it over a subquery?**
A **Common Table Expression** (`WITH ... AS`) is a named, temporary result set that makes complex queries readable and reusable within the statement. Example — members whose total paid claims exceed $10,000:
```sql
WITH member_totals AS (
    SELECT member_id, SUM(paid_amount) AS total_paid
    FROM claims
    GROUP BY member_id
)
SELECT member_id, total_paid
FROM member_totals
WHERE total_paid > 10000
ORDER BY total_paid DESC;
```

**Q: How do you find and handle duplicates? (common in claims/member data)**
```sql
-- Find duplicate claims by natural key
SELECT member_id, service_date, procedure_code, COUNT(*)
FROM claims
GROUP BY member_id, service_date, procedure_code
HAVING COUNT(*) > 1;
```
Then decide the dedup rule with the business (keep latest by timestamp, etc.). This connects to your data-profiling story for AI/analytics work.

**Q: How do you profile data quality with SQL for an analytics initiative?**
Check completeness (`COUNT(*)` vs `COUNT(column)` for NULLs), distinct values and cardinality (`COUNT(DISTINCT ...)`), ranges/outliers (`MIN/MAX/AVG`), and referential integrity (orphan rows via LEFT JOIN). This is exactly the kind of prep work a BA does before a dashboard or model is built.

**Q: DELETE vs TRUNCATE vs DROP?**
`DELETE` removes rows (can filter with WHERE, logged, can roll back); `TRUNCATE` removes all rows fast (no WHERE, minimal logging); `DROP` removes the entire table structure.

**Q: UNION vs UNION ALL?**
`UNION` combines two result sets and removes duplicates (slower); `UNION ALL` keeps duplicates (faster). Use UNION ALL when you know rows are already distinct.

---

# PART 5 — Agile, Delivery & Stakeholder Q&A

**Q: What is the BA's role in an Agile/Scrum team?**
The BA is the bridge between the Product Owner/business and the development team. I refine the backlog, write user stories with acceptance criteria, clarify requirements during the sprint, participate in all ceremonies, support the PO on prioritization, and help validate that what's built matches intent. In some teams the BA effectively acts as a proxy Product Owner.

**Q: Explain the main Scrum ceremonies.**
- **Sprint Planning** — decide what the team commits to this sprint.
- **Daily Standup** — short sync on progress and blockers.
- **Sprint Review** — demo completed work to stakeholders.
- **Retrospective** — inspect and improve the team's process.
- **Backlog Refinement/Grooming** — ongoing clarification and estimation of upcoming work.

**Q: What makes a good user story and acceptance criteria?**
A good story follows **INVEST** (Independent, Negotiable, Valuable, Estimable, Small, Testable) and the format "As a [role], I want [goal], so that [benefit]." Acceptance criteria I write in **Given/When/Then** form so they're directly testable. Example: *"Given a member with an active plan, when they open the benefits page, then the current in-network deductible balance is displayed."*

**Q: How do you handle conflicting requirements from different stakeholders?**
I make the conflict explicit and objective. I map each requirement to its business value, cost, and any compliance driver, then facilitate a prioritization conversation — often using MoSCoW (Must/Should/Could/Won't) — and escalate to the accountable owner for the final call. I document the decision and the rationale so it doesn't get re-litigated. The key is I don't pick sides on opinion; I frame trade-offs and let the owner decide.

**Q: How do you support testing and UAT?**
I ensure acceptance criteria exist before development, help QA translate requirements into test scenarios (including edge cases and negative paths), participate in defect triage to distinguish bugs from requirement gaps, and lead UAT with business users — preparing test scripts based on real member/claims scenarios and securing formal sign-off before release.

**Q: How do you approach release planning, especially with a regulatory deadline?**
I sequence features by dependency and priority, define release scope, and plan backwards from any hard regulatory date (like a CMS API compliance deadline) to protect the must-have scope. I coordinate cutover, data migration, and rollback plans, prepare stakeholder release notes, and plan post-release production validation.

---

# PART 6 — Behavioral / Senior-Level Q&A

Use **STAR** and quantify results.

**Q: Tell me about a complex requirement you gathered where stakeholders initially disagreed.**
> *Structure:* the situation (competing needs), what you did (workshops, options with trade-offs, MoSCoW, escalation), and the measurable outcome (aligned scope, on-time delivery, reduced rework).

**Q: Describe a time you bridged a serious gap between business and engineering.**
> *Structure:* business asked for X, engineering said it wasn't feasible as-is, you reframed around the real constraint and proposed a phased solution both accepted.

**Q: Tell me about a project that failed or slipped — what did you learn?**
> Show ownership, not blame. Name the root cause (e.g., a requirement gap discovered in UAT), what you changed afterward (earlier acceptance criteria, better traceability), and the improved result next time.

**Q: How do you manage a demanding stakeholder who keeps changing scope?**
> Change control: acknowledge the request, assess impact on timeline/cost/scope, present the trade-off, and let the owner formally accept or defer. Protect the team while keeping the stakeholder informed.

**Q: Why do you want to move into a senior healthcare BA role?**
> Connect your domain depth, your enjoyment of the bridging role, and the current industry momentum (interoperability, AI-enabled solutions) to why this specific role excites you.

---

# PART 7 — Questions to Ask the Interviewer

Asking sharp questions signals seniority:
- Which lines of business does this role support — Medicare Advantage, Medicaid, commercial, or Marketplace?
- Where is the team on the CMS interoperability journey (FHIR API build-out, prior-auth automation)?
- Is the API work greenfield, or modernizing legacy X12/HL7 integrations?
- How mature is the data/AI initiative — early exploration or production models?
- What does the delivery model look like — pure Scrum, SAFe, or a hybrid?
- What does success in this role look like in the first 6–12 months?

---

# Quick-Reference Glossary

| Term | Meaning |
|---|---|
| Payer | The insurance plan that pays claims (insurer / Medicare / Medicaid) |
| Provider | Doctor, hospital, lab delivering care |
| Member / Subscriber | The insured individual (and dependents) |
| Premium | Recurring cost to hold coverage |
| Deductible | Member pays this before the plan starts paying |
| Copay | Fixed fee per service |
| Coinsurance | Member's % share after deductible |
| OOP Max | Annual cap on member spending |
| Accumulators | Running totals of deductible/OOP usage |
| Formulary | Covered drug list, tiered |
| Prior Authorization | Payer approval required before a service |
| Adjudication | The payer's process of deciding how to pay a claim |
| COB | Coordination of Benefits (multiple payers) |
| Clearinghouse | Intermediary that validates/routes EDI between providers and payers |
| EOB | Explanation of Benefits (to the member) |
| ERA (835) | Electronic Remittance Advice (to the provider) |
| 270/271 | Eligibility inquiry / response |
| 834 | Enrollment |
| 837 (P/I/D) | Claim: Professional / Institutional / Dental |
| 835 | Remittance advice |
| 276/277 | Claim status request / response |
| 278 | Prior authorization / referral |
| HIPAA | US health data privacy/security + transaction standards law |
| PHI | Protected Health Information |
| HL7 / FHIR | Clinical data standards; FHIR is the modern REST/JSON one |
| X12 EDI | The mandated administrative/financial transaction standard |
| CMS-0057-F | 2024 rule mandating FHIR interoperability & prior-auth APIs (ops from Jan 2026, APIs by Jan 2027) |
| SMART on FHIR | OAuth2/OIDC authorization for FHIR apps |
| OpenAPI / Swagger | Standard for documenting REST APIs |

---

*Prepare 4–5 STAR stories from your own experience and map each to multiple questions above. Practice writing 3–4 SQL queries by hand. Be ready to talk fluently about at least the 270/271, 837, 835, and 278 transactions, and to explain CMS-0057-F in two sentences. Good luck.*
