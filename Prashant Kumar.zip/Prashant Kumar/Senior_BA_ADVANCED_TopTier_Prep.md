# Senior BA — Advanced / Top-Tier Interview Prep
### The depth that separates a "senior BA" from a candidate a FAANG-health division, Optum/UHG, Elevance, Cigna-Evernorth, or an elite consulting firm actually fights to hire

*Companion to the foundational guide. Everything here assumes you already know the basics (benefits, EDI, REST, JOINs) cold. This is about judgment, systems thinking, business economics, and being current.*

---

## What "top-tier" interviews actually test

At elite shops the bar shifts from *"can you document requirements"* to five higher-order signals:

1. **Systems thinking** — you reason about architecture, data flow, and failure modes, not just screens and fields.
2. **Business economics** — you understand how the payer actually makes and loses money (MLR, risk adjustment, VBC), so your requirements optimize the right thing.
3. **Trade-off fluency** — you quantify cost/benefit and defend a recommendation, then change it when the data changes.
4. **Currency** — you can speak to the 2026-2027 regulatory and AI landscape without being coached.
5. **Influence at scale** — you drive alignment across directors/VPs and engineering leadership without formal authority.

Below, each section is built to hit those signals.

---

# PART 1 — The Full Regulatory Board (know all of it, not just CMS-0057-F)

Junior candidates know one rule. Seniors at top companies can place any initiative on the whole regulatory map. Here's the board, current as of mid-2026.

### CMS Interoperability & Prior Authorization Final Rule (CMS-0057-F)
The headline rule. Impacted payers (Medicare Advantage, Medicaid/CHIP, ACA Marketplace plans) must stand up standardized HL7 **FHIR** APIs — Patient Access, Provider Access, Payer-to-Payer, and Prior Authorization. Operational rules (72-hour urgent / 7-day standard prior-auth decisions, denial-reason transparency, public metrics) began **Jan 1, 2026**; the FHIR APIs must be in production by **Jan 1, 2027**. A **2026 proposed rule (CMS-0062-P)** would extend this to prescription-drug prior auth and add API-endpoint reporting and newer implementation guides — good to mention as "what's coming."

### TEFCA (Trusted Exchange Framework and Common Agreement)
The national "network of networks" for clinical data exchange, administered by ONC/ASTP via the Sequoia Project (the RCE). Data flows through **QHINs** — Qualified Health Information Networks. By 2026 there are roughly a dozen designated QHINs (eHealth Exchange, Epic Nexus, Health Gorilla, CommonWell, MedAllies, KONZA, Oracle Health, Surescripts, and others), and hundreds of millions of records now move across the network annually. A notable 2026 milestone: the Social Security Administration connected via a QHIN to pull records for disability determinations. **Why a BA should care:** TEFCA is increasingly a default procurement question ("Are you TEFCA-connected? Through which QHIN? What exchange purposes?"), and it forces attention to identity matching (EMPI), consent enforcement, and FHIR mapping fidelity.

### Transparency in Coverage (TiC) — payer price transparency
Health plans must publish **machine-readable files (MRFs)** — in-network negotiated rates and out-of-network allowed amounts (a third file for prescription drugs) — as public JSON, updated monthly, plus a **consumer cost-estimator tool** covering shoppable services. A **December 2025 proposed rule** would tighten this: require actual dollar amounts (not just percentages/algorithms), add change-log/utilization/taxonomy context files, lower the privacy suppression threshold, and improve file findability. Parallel **hospital price transparency** changes for 2026 require median and 10th/90th-percentile allowed amounts derived from **835 ERA data**, effective Jan 1 with enforcement from Apr 1, 2026. This is a rich BA problem: the files are enormous, so requirements around generation, validation, and consumption are non-trivial.

### No Surprises Act (NSA)
Protects patients from surprise out-of-network bills, mandates **Good Faith Estimates** for the uninsured, and (not yet fully implemented) the **Advanced Explanation of Benefits (AEOB)** for insured patients — an area top companies are actively building toward.

### 21st Century Cures Act — information blocking
Prohibits practices that unreasonably block access, exchange, or use of electronic health information. It's the legal backbone under a lot of the interoperability push. Know the term "info blocking."

### HIPAA (the constant)
Privacy/Security Rules for PHI and Administrative Simplification (the X12 transaction mandate). Everything above sits on top of HIPAA.

**How to deploy this in an interview:** when asked about any initiative, locate it on this board. "A Payer-to-Payer API isn't just a build — it's CMS-0057-F compliance, it intersects TEFCA for the clinical-data side, and consent handling has to satisfy HIPAA and info-blocking rules." That sentence alone signals senior.

---

# PART 2 — System Design Literacy for a BA

You won't design the system, but at top companies you must *reason* about it well enough to write realistic requirements and challenge engineering intelligently.

**Q: A stakeholder wants "real-time" eligibility on the member portal. Walk me through how you'd pressure-test that requirement.**
> "First I'd challenge the word 'real-time.' Real-time usually means sub-second synchronous; near-real-time might mean a few minutes; and many benefit/accumulator systems only settle nightly. So I'd ask: what decision does the member make with this data, and what staleness is tolerable? Then I'd look at the source-of-truth. If accumulators update as claims adjudicate in a batch cycle, true real-time is impossible without re-architecting adjudication. I'd frame options: (a) synchronous call to the source system — accurate but adds latency and load, (b) a cached/materialized view refreshed on a schedule — fast but potentially stale, (c) event-driven updates where adjudication publishes an event that updates a read model. Each has a cost/latency/accuracy trade-off, and I'd document the NFRs — expected volume, peak concurrency, acceptable latency, and staleness tolerance — because those drive the architecture choice."

**Concepts to be fluent in (and drop naturally):**
- **Synchronous vs asynchronous / event-driven** integration; message queues; publish-subscribe.
- **Batch vs near-real-time vs streaming**; **CDC** (change data capture).
- **Idempotency** (why a retried claim submission mustn't create a duplicate) and **exactly-once vs at-least-once** delivery.
- **Eventual consistency** and why a distributed system may briefly show stale data.
- **Canonical / enterprise data model** — one internal representation that many source formats (X12, HL7, FHIR) map into, so you're not doing N×N mappings.
- **EMPI** (Enterprise Master Patient Index) and identity matching — the hard problem behind Provider Access APIs and TEFCA.
- **API gateway** responsibilities — auth, rate limiting, throttling, routing, logging, versioning.
- **Data lake vs warehouse vs lakehouse**; **star schema** and dimensional modeling for analytics.
- **Master Data Management (MDM)** for provider, member, and plan reference data.
- **Non-functional requirements** as first-class: latency, throughput, availability/SLA, scalability, security, auditability, disaster recovery.

**Q: How would you handle a Provider Access API where provider-to-patient matching is imperfect?**
> "Matching is the make-or-break. I'd define the attribution logic explicitly — what constitutes a treatment relationship, what data sources feed the panel (claims history, referrals, enrollment), and the match confidence thresholds. I'd design for the failure modes: false positives (a provider sees a patient they shouldn't — a privacy incident) are far costlier than false negatives, so I'd bias thresholds conservatively, require consent/opt-out handling, and build audit logging on every access. I'd also define a reconciliation and dispute process for bad matches. This is a requirements problem as much as a technical one."

---

# PART 3 — Payer Economics (this is what makes you sound like an insider)

Most BAs never learn how the payer *business* works. Knowing this lets you tie requirements to money, which is the top-company differentiator.

**Q: How does a health plan actually make or lose money?**
> "At the simplest level, premiums in minus claims and admin costs out. The core lever is the **Medical Loss Ratio (MLR)** — the share of premium spent on medical care. The ACA requires large group plans to spend at least 85% (individual/small group 80%) on care or rebate the difference, so plans operate in a tight band: too high MLR erodes margin, too low triggers rebates and regulatory scrutiny. So almost every payer initiative is really about influencing MLR — reducing avoidable medical spend (care management, fraud-waste-abuse, prior auth) or reducing admin cost (automation, interoperability)."

**Q: Explain risk adjustment and why it matters.**
> "For Medicare Advantage and ACA plans, CMS pays the plan more for sicker members via **risk adjustment**. Diagnoses map to **HCCs (Hierarchical Condition Categories)**, which roll up into a member **RAF (Risk Adjustment Factor)** score that scales payment. So accurate, complete, and *compliant* diagnosis capture directly drives revenue — but over-coding is fraud (there's active enforcement here). A BA on a risk-adjustment initiative is balancing revenue accuracy, compliance, and audit defensibility. This is one of the highest-value analytics/AI areas in the industry."

**Q: Fee-for-service vs value-based care — what changes for systems and requirements?**
> "**FFS** pays per service — volume-driven, and the data model is claim-centric. **Value-based care / capitation** pays for outcomes or a per-member-per-month amount, shifting risk to the provider. VBC needs totally different data: attribution, quality measures, total cost of care, and gaps-in-care tracking. So the reporting and API requirements change fundamentally — you're measuring populations and outcomes, not just adjudicating transactions."

**Other terms to have ready:** **HEDIS** (the standardized quality measure set), **Star Ratings** (CMS quality/bonus program for MA plans — drives significant bonus revenue), **ACO** (Accountable Care Organization), **PBM** (Pharmacy Benefit Manager), **TPA** (Third-Party Administrator), **capitation vs shared savings vs full risk**, **COB** (coordination of benefits), **accumulator crossover** (medical/pharmacy deductible sharing).

---

# PART 4 — Advanced FHIR & Interoperability

Going one level deeper than "FHIR is REST/JSON for health data" reads as real experience.

- **FHIR resources** — data is modeled as resources: `Patient`, `Coverage`, `Claim`, `ExplanationOfBenefit`, `CoverageEligibilityRequest/Response`, `Practitioner`, `Organization`. Knowing that eligibility maps to `CoverageEligibilityRequest/Response` and a paid claim to `ExplanationOfBenefit` is a strong signal.
- **US Core & USCDI** — US Core is the baseline FHIR profile set; **USCDI** is the mandated data-element standard (v3 is the current bar for much of TEFCA/CMS exchange). FHIR **R4 (4.0.1)** is the deployed version.
- **Implementation Guides (IGs)** — the payer-specific playbooks:
  - **CARIN Blue Button** — consumer access to claims/EOB (Patient Access API).
  - **Da Vinci PDex** — payer-to-payer and payer-to-provider data exchange.
  - **Da Vinci CRD / DTR / PAS** — the electronic prior-authorization trio: **Coverage Requirements Discovery** (is auth needed?), **Documentation Templates & Rules** (what docs are required), **Prior Authorization Support** (submit and get a decision). Naming these when discussing prior-auth modernization is a top-tier signal.
  - **Plan-Net** — provider directory.
- **SMART on FHIR** — OAuth2/OpenID Connect authorization with **scopes** (e.g., `patient/*.read`) and patient consent; **Backend Services Authorization** for system-to-system.
- **Bulk Data / "Flat FHIR"** — for pulling large populations (e.g., Provider Access panels) via NDJSON exports rather than one resource at a time.
- **X12 ↔ FHIR coexistence** — CMS allows FHIR-only, X12-only, or hybrid for prior auth (X12 **278** is the legacy transaction). Real payers run both and translate; that migration is a genuine lifecycle/requirements problem.

---

# PART 5 — Advanced SQL & Data Modeling

Top companies will hand you a messy schema and a vague question. They're testing whether you optimize, model history, and think in cohorts.

**Q: A claims query over 500M rows is slow. How do you reason about it?**
> "I'd look at the execution plan first — is it a full table scan where an index seek should happen? Then: are the JOIN and WHERE columns indexed; is the table **partitioned** (e.g., by service month) so the engine can prune; am I pulling columns I don't need; can I pre-aggregate into a **materialized view** or a summary table for a repeated report; and are statistics current? I'd also question whether this belongs in the transactional store at all versus an analytics warehouse with a **star schema** built for it."

**Q: How do you track a member's benefit changes over time in a data model?**
> "That's a **Slowly Changing Dimension (SCD)** problem. For history I'd use **SCD Type 2** — each change creates a new row with effective-start and effective-end dates and a current-flag — so I can answer 'what were this member's benefits *on the date of service*,' which is essential for correct claim adjudication and audits. SCD Type 1 (overwrite) loses history and would give wrong answers for back-dated claims."

**Q: Write a query to find members who lapsed — active last quarter, no claims this quarter (retention/cohort thinking).**
```sql
WITH last_q AS (
    SELECT DISTINCT member_id
    FROM claims
    WHERE service_date >= '2026-01-01' AND service_date < '2026-04-01'
),
this_q AS (
    SELECT DISTINCT member_id
    FROM claims
    WHERE service_date >= '2026-04-01' AND service_date < '2026-07-01'
)
SELECT l.member_id
FROM last_q l
LEFT JOIN this_q t ON l.member_id = t.member_id
WHERE t.member_id IS NULL;
```

**Q: Rank providers by denial rate, but only those with meaningful volume (window function + guardrail).**
```sql
SELECT provider_id,
       COUNT(*) AS total_claims,
       SUM(CASE WHEN claim_status = 'Denied' THEN 1 ELSE 0 END) AS denied,
       ROUND(100.0 * SUM(CASE WHEN claim_status = 'Denied' THEN 1 ELSE 0 END)
             / COUNT(*), 2) AS denial_rate_pct,
       RANK() OVER (ORDER BY 1.0 * SUM(CASE WHEN claim_status = 'Denied' THEN 1 ELSE 0 END)
                    / COUNT(*) DESC) AS rank_by_denial
FROM claims
GROUP BY provider_id
HAVING COUNT(*) >= 100          -- avoid tiny-sample noise
ORDER BY denial_rate_pct DESC;
```
Mentioning the `HAVING COUNT(*) >= 100` guardrail unprompted signals analytical maturity — you know a 100% denial rate on 2 claims is noise.

**Also be ready to discuss:** normalization vs denormalization (and why analytics denormalizes), fact vs dimension tables, grain of a fact table, data-quality profiling as a pre-model step, and CTE vs temp table vs subquery trade-offs on large data.

---

# PART 6 — Production-Grade AI / Data Judgment

This is the fastest-moving, highest-signal area in 2026 payer interviews. Adoption is real and so is the risk — you must show you understand both.

**Where payers actually use AI now (2026):** industry surveys show the large majority of health insurers use AI operationally — for claims adjudication, utilization management, prior authorization, fraud-waste-abuse detection, risk adjustment/coding, member service (AI voice agents handling millions of calls), and appeal-letter drafting. Generative AI is used to summarize clinical documentation, draft authorization and appeal narratives, and compare submissions against guidelines like InterQual/MCG to auto-approve routine cases. The CMS 2027 FHIR prior-auth mandate is concentrating investment here.

**Q: You're the BA on an AI initiative to auto-approve routine prior authorizations. How do you frame it?**
> "I'd frame value and risk together. Value: manual review runs 20-45 minutes per case; auto-approving clearly-eligible requests cuts turnaround and cost. But this touches a coverage decision, so risk governance is central. My requirements would cover: (1) **scope discipline** — AI *auto-approves*, but a denial or medical-necessity determination requires a licensed human reviewer, because several states now mandate human review and there's active litigation over AI-driven denials. (2) **explainability and audit trail** — every decision must be traceable and defensible under regulatory scrutiny. (3) **bias and fairness testing** across demographics. (4) **success metrics and guardrails** — target auto-approval rate, false-approval tolerance, and a fallback to human when confidence is low. (5) **PHI governance** — HIPAA-compliant data handling. My job is to make the value case *and* keep the human-in-the-loop where it legally and ethically must be."

**Q: What's the single biggest risk in payer AI, and how does a BA mitigate it?**
> "Using AI to *deny* care without adequate human oversight — it's both an ethical failure and a legal and reputational one; there's a prominent class action alleging an AI model with a very high error rate drove Medicare Advantage denials, and multiple states have passed laws requiring independent human review before an AI-based denial. As a BA I mitigate this by writing the human-in-the-loop requirement as non-negotiable for adverse decisions, defining clear accountability, and insisting on model monitoring for **drift** and documented evaluation before and after deployment."

**Vocabulary that signals depth:** human-in-the-loop, model drift, data/label leakage, feature relevance, ground-truth/evaluation set, precision vs recall trade-off (and which matters for the use case — e.g., high recall to catch fraud, high precision to avoid false denials), bias/fairness auditing, model governance, explainability, RAG (retrieval-augmented generation) for grounding LLMs on plan documents, hallucination risk, PHI/de-identification, SOC 2 / HIPAA compliance for vendors.

---

# PART 7 — Case / Whiteboard Questions (with structures)

Top firms give open-ended prompts. They're grading your *structure*, not a "right" answer. Think out loud.

**"Design the requirements for a Payer-to-Payer API."**
Structure: (1) Clarify — which regulation drives it (CMS-0057-F), which members, what data (claims, encounters, USCDI clinical, prior-auth history excluding drugs and denials). (2) Stakeholders — old payer, new payer, member (consent/opt-in). (3) Functional — trigger on enrollment, identity matching across payers, data-scope rules, consent capture. (4) Technical — FHIR resources, PDex IG, SMART/OAuth auth, bulk vs individual. (5) NFRs — volume, latency, security, audit. (6) Edge cases — member declines, no match, partial data, deadline (Jan 2027). (7) Success metrics.

**"We have ~400 APIs and no one knows what's used. Where do you start?"**
Structure: inventory → instrument usage (gateway logs: volume, consumers, errors, latency) → classify (load-bearing / low-use / duplicate / orphaned) → assess each against business value and regulatory need → recommend enhance/maintain/consolidate/deprecate/retire → migration plan with consumer comms and timelines → track. Tie to the CMS-driven shift toward standardized FHIR APIs replacing proprietary ones.

**"Prior-auth turnaround is too slow. How would you cut it?"**
Structure: map the current process and find the bottleneck (intake, clinical review, documentation back-and-forth) → quantify with data → options: electronic submission (Da Vinci PAS/CRD/DTR), auto-approve routine cases with AI (human-in-loop for denials), documentation templates to cut rework, SLA/routing rules → balance speed vs accuracy vs compliance (72hr/7day mandate) → define metrics (median decision time, auto-approval rate, rework rate).

**Estimation prompt ("How many eligibility calls per day for a 5M-member plan?")** — they want to see you decompose, state assumptions, and sanity-check magnitude, not nail a number.

---

# PART 8 — Leadership-Level Behavioral

At senior level these probe influence, ambiguity, and judgment. Use STAR, and pick stories where *you drove alignment*, not just did tasks.

- **"Tell me about a time you drove a decision across teams that didn't report to you."** → influence without authority: data, framing trade-offs, building coalition, escalating cleanly.
- **"A senior stakeholder insisted on a requirement you believed was wrong. What did you do?"** → disagree respectfully with evidence, offer alternatives, know when to commit; show you can be overruled gracefully and still own the outcome.
- **"Describe the most ambiguous project you've owned."** → how you created structure from nothing: hypotheses, a discovery plan, incremental validation.
- **"When did you make a call with incomplete data?"** → framing risk, reversible vs irreversible decisions, and revisiting when data arrived.
- **"How do you mentor junior BAs / raise the team's bar?"** → shows scope beyond your own tickets, which is what "senior/lead" pay grades expect.
- **"Tell me about a requirement that shipped and caused a production problem."** → ownership, root cause, and the systemic fix (traceability, earlier acceptance criteria, better NFRs).

---

# PART 9 — Sharp Questions to Ask (senior signaling)

- Where are you on the CMS-0057-F build — which of the four FHIR APIs are live, and how are you handling the X12-278-to-FHIR prior-auth migration?
- Are you TEFCA-connected, and does interoperability strategy sit with a central platform team or per-product?
- How mature is your AI governance — is there a human-in-the-loop policy for coverage decisions, and who owns model risk?
- What's the analytics data foundation — warehouse/lakehouse, and how clean is the claims/member data BAs work from?
- How do you measure a BA's impact here beyond delivery — do requirement-quality or defect-leakage metrics exist?
- Is this role closer to product-owner-adjacent discovery, or spec-and-deliver execution?

---

# One-Page "Sound Senior" Cheat Layer

| If they ask about… | Elevate by mentioning… |
|---|---|
| Interoperability | CMS-0057-F + TEFCA/QHINs + info blocking, not just "FHIR APIs" |
| Prior authorization | Da Vinci CRD/DTR/PAS, 72hr/7day mandate, AI auto-approve with human-in-loop for denials |
| Eligibility | 270/271 ↔ `CoverageEligibilityRequest/Response`, sync vs cached trade-off |
| "Real-time" anything | Challenge the term; source-of-truth refresh cadence; NFRs |
| APIs at scale | Inventory → usage metrics → rationalization lifecycle → migration |
| A slow query | Execution plan, indexing, partitioning, materialized view, star schema |
| Member history | SCD Type 2, effective dating, adjudicate as-of service date |
| AI | Value + governance together; drift, bias, human-in-loop, litigation/state-law risk |
| Any payer initiative | Tie it to MLR, risk adjustment/RAF, or Star Ratings — the money |
| Price/cost features | Transparency in Coverage MRFs, consumer cost tool, No Surprises Act/AEOB |

---

*Preparation strategy: pick 3 payer initiatives from your real experience and be able to place each on the regulatory board, explain the data/architecture, name the metric it moved, and tell the influence story behind it. If you can do that fluently for three projects, you'll interview above your level.*
