"""
Resilient data fetch: retries, last-known-good cache fallback, and a source
status the data-quality gate consumes.

A reviewer's point: "a weak prediction can come from bad fetch behaviour, not
model weakness." Since the app fetches live from yfinance, a transient empty
response or rate-limit should not silently produce a degraded forecast that
looks the same as a healthy one. So this wraps the fetch with:

* bounded retries with exponential backoff,
* empty / error-string detection (``get_whole_stock_data`` returns a string on
  failure),
* a persistent **last-known-good** disk cache (pickle, preserving ``attrs``),
* partial-data detection (a live result far shorter than the cached one),

and tags every result with ``df.attrs['source']`` = one of
``live`` / ``partial`` / ``cached_fallback`` / ``failed`` (plus timestamps and
the failure reason), which ``data_quality`` turns into a reason code and serving
mode and the UI surfaces ("Using cached data from …; forecast downgraded").

Pure-ish: the only side effect is the on-disk cache under ``.data_cache/``. The
network call is injected (``fetch_fn``) so tests run offline, and ``sleep_fn``
is injectable so they run instantly.
"""

import os
import pickle
import re
import time

import pandas as pd

_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".data_cache")
_PARTIAL_FRACTION = 0.5      # live rows < this * cached rows => "partial"


def _safe_key(company_name, interval):
    slug = re.sub(r"[^A-Za-z0-9]+", "_", f"{company_name}_{interval}").strip("_")
    return slug.lower()[:120]


def _cache_file(company_name, interval):
    return os.path.join(_CACHE_DIR, f"{_safe_key(company_name, interval)}.pkl")


def _save_cache(company_name, interval, df):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        df.to_pickle(_cache_file(company_name, interval))
    except Exception as exc:                     # caching must never break a run
        print(f"safe_fetch: cache save skipped ({exc})")


def _load_cache(company_name, interval):
    path = _cache_file(company_name, interval)
    try:
        if os.path.exists(path):
            df = pd.read_pickle(path)
            if isinstance(df, pd.DataFrame) and not df.empty:
                age_days = (time.time() - os.path.getmtime(path)) / 86400.0
                return df, age_days
    except Exception as exc:
        print(f"safe_fetch: cache load skipped ({exc})")
    return None, None


def _is_valid(df):
    return isinstance(df, pd.DataFrame) and not df.empty


def fetch_with_fallback(company_name, interval, fetch_fn,
                        max_retries=3, backoff_base=0.5, sleep_fn=time.sleep,
                        now_iso=None):
    """
    Fetch with retries; fall back to the last-known-good cache on failure.

    Parameters
    ----------
    company_name, interval : str
        Passed through to ``fetch_fn``.
    fetch_fn : callable
        ``fetch_fn(company_name, interval)`` -> DataFrame (or an error string,
        as ``get_whole_stock_data`` does). Injected so tests run offline.
    max_retries : int
        Attempts before falling back to cache.
    backoff_base : float
        Base seconds for exponential backoff (``base * 2**attempt``).
    sleep_fn : callable
        Sleep function (injectable; pass ``lambda _: None`` in tests).
    now_iso : str, optional
        Timestamp to stamp on the result (defaults to UTC now).

    Returns
    -------
    pd.DataFrame or None
        The data with ``attrs['source']`` set, or None if both live and cache
        failed (status recorded on a tiny empty frame is not returned — None
        signals total failure to the caller).
    """
    if now_iso is None:
        now_iso = pd.Timestamp.now("UTC").isoformat()
    last_reason = None

    for attempt in range(max_retries):
        try:
            df = fetch_fn(company_name, interval)
            if _is_valid(df):
                cached, _ = _load_cache(company_name, interval)
                status = "live"
                # Partial-data detection vs the last-known-good size.
                if cached is not None and len(df) < _PARTIAL_FRACTION * len(cached):
                    status = "partial"
                    last_reason = (f"live result short ({len(df)} rows vs "
                                   f"{len(cached)} cached)")
                _save_cache(company_name, interval, df)
                df.attrs["source"] = {
                    "status": status, "attempts": attempt + 1,
                    "fetched_at": now_iso, "reason": last_reason,
                }
                return df
            last_reason = f"empty/invalid result: {str(df)[:80]}"
        except Exception as exc:
            last_reason = f"{type(exc).__name__}: {str(exc)[:100]}"
        if attempt < max_retries - 1 and backoff_base > 0:
            sleep_fn(backoff_base * (2 ** attempt))

    # Live fetch exhausted — fall back to the last-known-good cache.
    cached, age_days = _load_cache(company_name, interval)
    if cached is not None:
        cached.attrs["source"] = {
            "status": "cached_fallback", "attempts": max_retries,
            "fetched_at": now_iso, "cache_age_days": round(age_days, 2),
            "reason": last_reason,
        }
        return cached

    print(f"safe_fetch: live + cache both failed for {company_name} "
          f"[{interval}] — {last_reason}")
    return None
