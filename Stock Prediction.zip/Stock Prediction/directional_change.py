"""
Directional Change (DC): an event-based alternative to fixed-interval sampling.

Tsang, *AI for Finance* (CRC Press, 2023), Chapter 6. Of that book's seven
chapters this is the only one carrying an algorithm; the rest is commentary.

The idea
--------
A time series records a price every fixed interval, whether or not anything
happened. DC inverts that: **the price decides when to record**. Fix a
threshold ``theta``. Starting from the last extreme price, do nothing until the
price reverses by ``theta``; at that moment a *Directional Change event* is
confirmed and the trend direction flips. The market becomes a sequence of
alternating up- and down-trends, each split into two legs:

* the **DC leg**, from the previous extreme to the confirmation point -- a move
  of exactly ``theta`` by construction, and
* the **overshoot (OS) leg**, from the confirmation point to the next extreme --
  a move of *whatever the market felt like*, and therefore the only part that
  carries information.

This is the same motivation as López de Prado's information-driven bars
(AFML Ch. 2), but with one decisive practical difference: tick bars need tick
data, which this project does not have. DC needs only a price path. It runs on
the daily closes already in the panel.

The lookahead trap, which the book waves away
---------------------------------------------
Tsang notes that DC events are "recognized in hindsight" and then argues this
"changes nothing". For analysis of the past that is true. For *feature
construction* it is the single most dangerous property of the representation,
because the natural way to write the code is also wrong.

The extreme that starts a trend is at time ``t_ext``, but nobody knows it is an
extreme until the confirmation at ``t_confirm``. Label the bars in between with
the new trend's direction -- which is what you get from a groupby on the event
table, the obvious implementation -- and every one of those bars now carries a
fact from its own future. The effect is not subtle: the model learns to buy at
the exact bottom.

So this module separates the two uses rather than trusting the caller to
remember:

* :func:`dc_events` is the hindsight view -- event tables, scaling laws,
  volatility measurement, anything that looks backward over a finished period.
* :func:`dc_state` is the causal view -- per-bar features where every value at
  bar *i* is computed from ``prices[:i+1]`` and nothing else.

:func:`dc_state` is what feeds a model. The guarantee is tested directly, by
recomputing on truncated prefixes and requiring the overlap to match exactly
(``test_dc_state_is_invariant_to_future_bars``). Section 41 of the README is
this project's standing reminder of what the untested version of this
assumption costs: an open-interest signal at t = +2.88 became t = -0.27 once
the publication lag was honoured.

What is worth measuring
-----------------------
:func:`scaling_laws` tests the two empirical claims of Chapter 6.5, found by
Olsen's group in FX across all major pairs and all thresholds:

1. a trend ends, on average, when it reaches **twice** the threshold --
   equivalently ``mean(|OS move|) / theta ~ 1``;
2. if the DC leg takes time *t*, the OS leg takes about **2t**.

Both are stated for foreign exchange. Whether they survive on Indian equities
at daily resolution is an open question, and ``tests/validation/
run_directional_change.py`` answers it rather than assuming it. The book adds
a caveat worth honouring: the mean "is significantly biased by extreme values",
so every statistic here is reported as mean *and* median.

:func:`dc_volatility` implements the two DC volatility measures of Chapter 6.3
-- event frequency and mean trend magnitude -- which Tsang claims are
"independent of the volatility measures under Time Series". That is a testable
claim, not a given, and the driver tests it.
"""

import numpy as np
import pandas as pd

#: Thresholds spanning a day-trader's view to a long-term investor's.
#: Tsang's own framing: "A long-term investor may consider 10% as a significant
#: change, but a day trader may consider a 0.2% change significant."
DEFAULT_THETAS = (0.02, 0.03, 0.05, 0.10)

#: Columns of the :func:`dc_events` table.
EVENT_COLUMNS = (
    "direction", "ext_index", "ext_time", "ext_price",
    "confirm_index", "confirm_time", "confirm_price",
    "end_index", "end_time", "end_price",
    "dc_move", "os_move", "total_move",
    "dc_bars", "os_bars", "total_bars",
    "tmv", "time_adjusted_return",
)

#: Columns of the :func:`dc_state` table.
STATE_COLUMNS = (
    "direction", "bars_since_confirm", "bars_in_trend",
    "move_from_ext", "overshoot", "retrace",
)


def _as_series(prices):
    """Coerce to a float Series with a usable index, dropping non-positive bars."""
    if isinstance(prices, pd.Series):
        s = prices.astype(float)
    elif isinstance(prices, pd.DataFrame):
        col = "adj_close" if "adj_close" in prices.columns else "close"
        s = prices[col].astype(float)
        if "datetime" in prices.columns:
            s.index = pd.to_datetime(prices["datetime"])
    else:
        s = pd.Series(np.asarray(prices, dtype=float))
    # A zero or negative price makes every ratio meaningless; bhavcopy has none,
    # but yfinance occasionally returns a 0.0 row for a halted session.
    return s[np.isfinite(s.to_numpy()) & (s.to_numpy() > 0)]


def _empty(columns):
    return pd.DataFrame({c: pd.Series(dtype="float64") for c in columns})


def dc_events(prices, theta):
    """
    Decompose a price path into completed Directional Change trends.

    Each row is one **completed** trend: it runs from the extreme that started
    it, through the confirmation point where the market announced it, to the
    extreme that ended it. A trend is only emitted once the *following*
    confirmation has fixed its end point, so the final incomplete trend is
    deliberately absent -- reporting it would mean treating the running extreme
    as if it were known to be final.

    Parameters
    ----------
    prices : pd.Series, pd.DataFrame or array-like
        A price path. A DataFrame uses ``adj_close`` when present, else
        ``close``; adjusted prices are strongly preferred, because a 1:10 split
        is a -90% move and will fabricate a DC event at any threshold.
    theta : float
        The DC threshold as a fraction, e.g. ``0.05`` for 5%.

    Returns
    -------
    pd.DataFrame
        Columns :data:`EVENT_COLUMNS`. ``direction`` is ``+1`` for an uptrend
        (starts at a trough, ends at a peak) and ``-1`` for a downtrend.
        ``dc_move``/``os_move``/``total_move`` are signed simple returns over
        the three spans; ``tmv`` is the total move in threshold units, and
        ``time_adjusted_return`` is ``tmv / total_bars``.
    """
    s = _as_series(prices)
    p = s.to_numpy(dtype=float)
    n = len(p)
    if n < 2 or not np.isfinite(theta) or theta <= 0:
        return _empty(EVENT_COLUMNS)

    up, dn = 1.0 + theta, 1.0 - theta
    rows = []

    # --- initialisation -----------------------------------------------------
    # The first direction is not assumed: a running high and a running low are
    # carried forward together and whichever breaches theta first defines it.
    # Guessing "start in an uptrend" instead would plant an artificial first
    # event whose legs are measured from an arbitrary point.
    hi = lo = p[0]
    hi_i = lo_i = 0
    mode = 0
    i = 1
    while i < n and mode == 0:
        if p[i] > hi:
            hi, hi_i = p[i], i
        if p[i] < lo:
            lo, lo_i = p[i], i
        if p[i] <= hi * dn:
            mode, ext_i, ext_p = -1, hi_i, hi
        elif p[i] >= lo * up:
            mode, ext_i, ext_p = 1, lo_i, lo
        if mode != 0:
            conf_i, conf_p = i, p[i]
            run_i, run_p = i, p[i]
        i += 1
    if mode == 0:
        return _empty(EVENT_COLUMNS)

    # --- main sweep ---------------------------------------------------------
    for j in range(i, n):
        price = p[j]
        if mode == -1:
            if price < run_p:
                run_i, run_p = j, price
                continue
            if price < run_p * up:
                continue
        else:
            if price > run_p:
                run_i, run_p = j, price
                continue
            if price > run_p * dn:
                continue

        # A reversal of theta from the running extreme: the trend just ended at
        # (run_i, run_p), and this bar starts the next one.
        rows.append((mode, ext_i, ext_p, conf_i, conf_p, run_i, run_p))
        mode = -mode
        ext_i, ext_p = run_i, run_p
        conf_i, conf_p = j, price
        run_i, run_p = j, price

    if not rows:
        return _empty(EVENT_COLUMNS)

    out = pd.DataFrame(rows, columns=["direction", "ext_index", "ext_price",
                                      "confirm_index", "confirm_price",
                                      "end_index", "end_price"])
    idx = s.index
    out["ext_time"] = idx[out["ext_index"].to_numpy()]
    out["confirm_time"] = idx[out["confirm_index"].to_numpy()]
    out["end_time"] = idx[out["end_index"].to_numpy()]

    out["dc_move"] = out["confirm_price"] / out["ext_price"] - 1.0
    out["os_move"] = out["end_price"] / out["confirm_price"] - 1.0
    out["total_move"] = out["end_price"] / out["ext_price"] - 1.0
    out["dc_bars"] = out["confirm_index"] - out["ext_index"]
    out["os_bars"] = out["end_index"] - out["confirm_index"]
    out["total_bars"] = out["end_index"] - out["ext_index"]
    out["tmv"] = out["total_move"].abs() / theta
    out["time_adjusted_return"] = np.where(
        out["total_bars"].to_numpy() > 0,
        out["tmv"].to_numpy() / out["total_bars"].to_numpy().clip(min=1), np.nan)
    return out.loc[:, list(EVENT_COLUMNS)].reset_index(drop=True)


def dc_state(prices, theta):
    """
    Per-bar DC features that are safe to feed a model.

    Every value at bar *i* is a function of ``prices[:i+1]`` alone. In
    particular ``direction`` flips at the **confirmation** bar, not at the
    extreme -- the extreme is only recognised later, and backdating the flip to
    it is the lookahead bug described in the module docstring.

    The last two columns are the nowcasting inputs of Chapter 6.6. Tsang's
    worked example -- a downtrend already 6x past a 5% threshold, now reversed
    by 4% -- reads directly off them as ``overshoot ~ 5`` (the DC leg accounts
    for the sixth) and ``retrace ~ 0.8``. When ``retrace`` reaches 1.0 a new DC
    confirms, so it is literally the distance to the next event.

    Parameters
    ----------
    prices : pd.Series, pd.DataFrame or array-like
    theta : float

    Returns
    -------
    pd.DataFrame
        Indexed like the (cleaned) input, columns :data:`STATE_COLUMNS`.

        direction
            ``+1``/``-1`` for the confirmed trend, ``0`` before the first
            confirmation -- an honest "not yet known" rather than a guess.
        bars_since_confirm
            Bars since the current trend was confirmed.
        bars_in_trend
            Bars since the extreme that started it. Larger than
            ``bars_since_confirm`` because the extreme is in the past; both are
            known at confirmation time, so neither peeks.
        move_from_ext
            Signed return from that extreme to this bar.
        overshoot
            ``|return since the confirmation point| / theta``, signed by
            direction. The trend's progress beyond the threshold.
        retrace
            Reversal from the running extreme of the current trend, in
            threshold units, clipped to ``[0, 1]``. Hits 1.0 exactly when the
            next DC confirms.
    """
    s = _as_series(prices)
    p = s.to_numpy(dtype=float)
    n = len(p)
    cols = {c: np.full(n, np.nan) for c in STATE_COLUMNS}
    cols["direction"] = np.zeros(n)
    if n == 0 or not np.isfinite(theta) or theta <= 0:
        return pd.DataFrame(cols, index=s.index).loc[:, list(STATE_COLUMNS)]

    up, dn = 1.0 + theta, 1.0 - theta
    hi = lo = p[0]
    hi_i = lo_i = 0
    mode = 0
    ext_i, ext_p = 0, p[0]
    conf_i, conf_p = 0, p[0]
    run_i, run_p = 0, p[0]

    # This is the same state machine as dc_events, stepped one bar at a time and
    # emitting a row instead of accumulating a trend. Keeping them identical is
    # the point: if the causal view and the hindsight view disagreed about where
    # a trend started, one of them would be wrong, and it would be this one.
    for j in range(n):
        price = p[j]
        if mode == 0:
            # Pre-confirmation. Carry both extremes and emit direction 0 --
            # an honest "not yet known" rather than a guessed initial trend.
            if price > hi:
                hi, hi_i = price, j
            if price < lo:
                lo, lo_i = price, j
            if price <= hi * dn:
                mode, ext_i, ext_p = -1, hi_i, hi
            elif price >= lo * up:
                mode, ext_i, ext_p = 1, lo_i, lo
            if mode == 0:
                continue
            conf_i, conf_p = j, price
            run_i, run_p = j, price
        else:
            flip = False
            if mode == -1:
                if price < run_p:
                    run_i, run_p = j, price
                elif price >= run_p * up:
                    flip = True
            else:
                if price > run_p:
                    run_i, run_p = j, price
                elif price <= run_p * dn:
                    flip = True
            if flip:
                mode = -mode
                ext_i, ext_p = run_i, run_p
                conf_i, conf_p = j, price
                run_i, run_p = j, price

        cols["direction"][j] = mode
        cols["bars_since_confirm"][j] = j - conf_i
        cols["bars_in_trend"][j] = j - ext_i
        cols["move_from_ext"][j] = price / ext_p - 1.0
        cols["overshoot"][j] = (price / conf_p - 1.0) / theta * mode
        rel = ((run_p - price) / run_p if mode == 1
               else (price - run_p) / run_p)
        cols["retrace"][j] = min(max(rel / theta, 0.0), 1.0)

    return pd.DataFrame(cols, index=s.index).loc[:, list(STATE_COLUMNS)]


def scaling_laws(events, theta):
    """
    Test Chapter 6.5's two stylised facts on an event table.

    The claims, from Olsen's FX work and reproduced as Figure 6.2:

    1. ``mean(|os_move|) / theta == 1`` -- the trend ends at twice the
       threshold, since the DC leg already supplied one theta.
    2. ``mean(os_bars) / mean(dc_bars) == 2`` -- the overshoot takes twice as
       long as the move that confirmed it.

    Both are reported as mean **and** median, because the book's own caveat is
    that "the average is significantly biased by extreme values... the majority
    of trends ended far sooner than reaching twice the threshold". A law that
    holds only in the mean is a statement about the tail, not about the typical
    trend, and the two should not be confused.

    Returns
    -------
    dict
        ``os_over_theta_mean``, ``os_over_theta_median``, ``time_ratio_mean``,
        ``time_ratio_median``, ``n_events``, plus the raw leg statistics.
    """
    if events is None or len(events) == 0:
        return {"n_events": 0}
    os_abs = events["os_move"].abs().to_numpy(dtype=float)
    dc_b = events["dc_bars"].to_numpy(dtype=float)
    os_b = events["os_bars"].to_numpy(dtype=float)
    ok = np.isfinite(os_abs) & np.isfinite(dc_b) & np.isfinite(os_b)
    os_abs, dc_b, os_b = os_abs[ok], dc_b[ok], os_b[ok]
    if len(os_abs) == 0:
        return {"n_events": 0}

    dc_mean = float(np.mean(dc_b))
    # Per-trend time ratios are undefined when the DC leg lands in a single bar,
    # which is common on daily data. The ratio-of-means is the quantity the law
    # is actually stated about, so it leads; the median of the defined per-trend
    # ratios is reported beside it rather than in place of it.
    per = os_b[dc_b > 0] / dc_b[dc_b > 0]
    # The DC leg is theta *by construction* only under continuous monitoring.
    # On daily bars a single session can jump well past the threshold, so the
    # realised DC leg is larger than theta and the ratio below says by how much.
    # Without it, `os_over_theta` silently compares the overshoot against a
    # threshold the data never actually stopped at.
    dc_abs = events["dc_move"].abs().to_numpy(dtype=float)[ok]
    return {
        "n_events": int(len(os_abs)),
        "dc_over_theta_mean": float(np.mean(dc_abs) / theta),
        "os_over_theta_mean": float(np.mean(os_abs) / theta),
        "os_over_theta_median": float(np.median(os_abs) / theta),
        "os_over_dc_mean": float(np.mean(os_abs) / np.mean(dc_abs)),
        "time_ratio_mean": float(np.mean(os_b) / dc_mean) if dc_mean > 0 else np.nan,
        "time_ratio_median": float(np.median(per)) if len(per) else np.nan,
        "dc_bars_mean": dc_mean,
        "os_bars_mean": float(np.mean(os_b)),
        "total_move_mean": float(np.mean(np.abs(
            events["total_move"].to_numpy(dtype=float)))),
    }


#: What a **driftless random walk** produces, so the scaling laws have a
#: reference point instead of only a number.
#:
#: These are not calibration constants; they are the limits the statistics
#: converge to under continuous monitoring of driftless Brownian motion. Law 1
#: has a closed form: the running maximum reached before a ``theta`` drawdown is
#: Exponential with mean ``theta``, so ``OS/theta`` has mean 1 and median ln 2.
#: Law 2 is reproduced to within 0.01 by simulation at 25 steps per threshold.
#:
#: Olsen's "striking discoveries" -- that a trend ends at twice the threshold
#: and the overshoot takes twice as long -- are these numbers. Tsang (6.5)
#: reports them as unexplained observations across all major FX pairs. They are
#: what noise does, and a market that obeys them is saying it is a random walk.
#: Tsang's own caveat that "the majority of trends ended far sooner" is the
#: exponential's mean-median gap, not a property of currencies.
DRIFTLESS_THEORY = {
    "dc_over_theta_mean": 1.0,
    "os_over_theta_mean": 1.0,
    "os_over_theta_median": 0.6931471805599453,   # ln 2
    "os_over_dc_mean": 1.0,
    "time_ratio_mean": 2.0,
}


def sign_flip_path(log_returns, rng):
    """
    A price path with ``|r_t|`` held bar for bar and the signs randomised.

    The null for anything DC claims to see. Because the magnitudes are
    untouched, volatility clustering and the tail shape are identical to the
    original rather than merely matched, so neither can explain a deviation.
    Shared by :func:`scaling_law_test` and the panel test in
    ``tests/validation/run_directional_change.py`` so the two cannot drift
    apart.
    """
    signs = rng.choice((-1.0, 1.0), size=len(log_returns))
    return pd.Series(np.exp(np.cumsum(np.r_[0.0, log_returns * signs])))


def scaling_law_test(prices, theta, n_null=25, demean=True, seed=0):
    """
    Compare a series' scaling statistics against its **own** sign-flipped null.

    Why a bare :func:`scaling_laws` number is not enough
    ---------------------------------------------------
    Every statistic it returns has a non-obvious reference point
    (:data:`DRIFTLESS_THEORY`), so "OS/DC = 1.07" reads as a finding when 1.00
    is what noise gives. This wraps the comparison so the reference travels
    with the measurement.

    The null resamples the series' own log returns with randomised signs.
    ``|r_t|`` is held fixed bar for bar, so volatility clustering and the tail
    shape are not merely matched but *identical*; only direction is destroyed.
    That rules out the two obvious objections to a Gaussian null.

    Why ``demean`` defaults to True
    -------------------------------
    **This is the trap this function exists for.** The null is driftless. A
    drifting series spends longer in up-trends, so its overshoot leg runs
    further than the null's for no reason connected to Directional Change at
    all -- and the test reports a large, replicable, entirely spurious
    deviation. On 395 NSE names over 2022-2024, drifting at +16.7%/yr, the
    raw comparison reached **t = +6.2** at four separate thresholds; with each
    name measured against its own drift it was **+0.15**, and the sign reversed
    at the widest threshold (README §44).

    Passing ``demean=False`` measures the drift. It is offered because a
    caller may genuinely want the raw number, not because it is safe.

    Parameters
    ----------
    prices : pd.Series, pd.DataFrame or array-like
    theta : float
    n_null : int, optional
        Sign-flip replications. The null statistics are stable by ~25; more
        buys precision in ``z`` rather than a different answer.
    demean : bool, optional
        Remove the series' mean log return before measuring it, so it is
        compared against a null of its own drift. Default True.
    seed : int, optional

    Returns
    -------
    dict
        ``observed``/``null_mean``/``null_sd``/``z`` per statistic, plus
        ``theory``, ``drift_annual``, ``n_events`` and ``demeaned``. ``z`` is
        the observed value in null standard deviations; |z| > 2 is a deviation
        from noise. Empty ``{'n_events': 0}`` if no trend completes.
    """
    s = _as_series(prices)
    p = s.to_numpy(dtype=float)
    if len(p) < 3 or not np.isfinite(theta) or theta <= 0:
        return {"n_events": 0}
    r = np.diff(np.log(p))
    mu = float(np.mean(r))
    if demean:
        r_obs = r - mu
        obs_path = pd.Series(np.exp(np.cumsum(np.r_[0.0, r_obs])))
    else:
        r_obs, obs_path = r, s
    obs = scaling_laws(dc_events(obs_path, theta), theta)
    if not obs.get("n_events"):
        return {"n_events": 0}

    keys = tuple(DRIFTLESS_THEORY)
    rng = np.random.default_rng(seed)
    draws = {k: [] for k in keys}
    for _ in range(max(int(n_null), 2)):
        nl = scaling_laws(dc_events(sign_flip_path(r_obs, rng), theta), theta)
        if not nl.get("n_events"):
            continue
        for k in keys:
            draws[k].append(nl.get(k, np.nan))

    out = {"n_events": obs["n_events"], "theta": float(theta),
           "demeaned": bool(demean), "drift_annual": mu * 252.0,
           "n_null": len(draws[keys[0]]), "theory": dict(DRIFTLESS_THEORY)}
    for k in keys:
        a = np.asarray(draws[k], dtype=float)
        a = a[np.isfinite(a)]
        m = float(np.mean(a)) if len(a) else np.nan
        sd = float(np.std(a, ddof=1)) if len(a) > 1 else np.nan
        o = float(obs.get(k, np.nan))
        out[k] = {"observed": o, "null_mean": m, "null_sd": sd,
                  "theory": DRIFTLESS_THEORY[k],
                  "z": (o - m) / sd if np.isfinite(sd) and sd > 0 else np.nan}
    return out


def format_law_test(result):
    """Render :func:`scaling_law_test` with its null and its theory side by side."""
    if not result.get("n_events"):
        return "no completed trends"
    lines = [
        "=" * 70,
        f"SCALING LAWS vs SIGN-FLIPPED NULL  (theta {result['theta']:.1%}, "
        f"{result['n_events']} events)",
        "=" * 70,
        f"  drift {result['drift_annual']:+.1%}/yr | "
        + ("measured against its own drift (demeaned)" if result["demeaned"]
           else "NOT demeaned -- z below also measures the drift"),
        "",
        f"{'statistic':>22s}{'observed':>11s}{'null':>9s}{'sd':>8s}"
        f"{'z':>8s}{'theory':>9s}",
    ]
    for k in DRIFTLESS_THEORY:
        d = result.get(k, {})
        lines.append(f"{k:>22s}{d.get('observed', float('nan')):11.3f}"
                     f"{d.get('null_mean', float('nan')):9.3f}"
                     f"{d.get('null_sd', float('nan')):8.3f}"
                     f"{d.get('z', float('nan')):8.2f}"
                     f"{d.get('theory', float('nan')):9.3f}")
    lines.append("")
    lines.append("  |z| > 2 is a deviation from noise. 'theory' is what a")
    lines.append("  driftless random walk gives under continuous monitoring.")
    return "\n".join(lines)


def dc_volatility(events, freq="ME"):
    """
    The two DC volatility measures of Chapter 6.3, resampled to a period.

    1. **Event frequency** -- how often the market changed direction.
    2. **Mean trend magnitude** -- how far it went each time.

    Tsang calls these "orthogonal" to each other and says the first is
    "independent of the volatility measures under Time Series". Both are
    empirical claims about a particular market; see
    ``tests/validation/run_directional_change.py``, which measures the
    correlations rather than repeating the assertion.

    Events are attributed to the period containing their **end extreme**, the
    point at which the trend is complete and its magnitude known.

    Parameters
    ----------
    events : pd.DataFrame
        From :func:`dc_events`, with datetime-like ``end_time``.
    freq : str, optional
        Any pandas offset alias; ``"ME"`` (month end) by default.

    Returns
    -------
    pd.DataFrame
        Indexed by period, columns ``dc_count`` and ``mean_move``.
    """
    if events is None or len(events) == 0:
        return pd.DataFrame({"dc_count": pd.Series(dtype="int64"),
                             "mean_move": pd.Series(dtype="float64")})
    ev = pd.DataFrame({
        "end_time": pd.to_datetime(events["end_time"]),
        "move": events["total_move"].abs().to_numpy(dtype=float),
    }).set_index("end_time")
    g = ev.resample(freq)
    return pd.DataFrame({"dc_count": g["move"].count().astype("int64"),
                         "mean_move": g["move"].mean()})


def summary(prices, theta):
    """One-call event table, scaling-law test and bar count for a price path."""
    s = _as_series(prices)
    ev = dc_events(s, theta)
    out = {"theta": float(theta), "bars": int(len(s))}
    out.update(scaling_laws(ev, theta))
    out["events_per_year"] = (float(out.get("n_events", 0)) * 252.0 / len(s)
                              if len(s) else np.nan)
    return out


def format_report(rows, title="DIRECTIONAL CHANGE"):
    """Render a list of :func:`summary` dicts as a fixed-width table."""
    lines = ["=" * 78, title, "=" * 78,
             f"{'theta':>7s}{'events':>8s}{'/yr':>7s}{'OS/theta':>11s}"
             f"{'median':>9s}{'t_OS/t_DC':>12s}{'median':>9s}"]
    for r in rows:
        if not r.get("n_events"):
            lines.append(f"{r.get('theta', float('nan')):7.1%}"
                         f"{0:8d}      -          -        -           -        -")
            continue
        lines.append(
            f"{r['theta']:7.1%}{r['n_events']:8d}{r['events_per_year']:7.1f}"
            f"{r['os_over_theta_mean']:11.2f}{r['os_over_theta_median']:9.2f}"
            f"{r['time_ratio_mean']:12.2f}{r['time_ratio_median']:9.2f}")
    lines.append("")
    lines.append("  Olsen's FX scaling laws predict OS/theta = 1 and "
                 "t_OS/t_DC = 2.")
    return "\n".join(lines)
