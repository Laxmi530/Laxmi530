"""
Point-in-time NSE prices from bhavcopy: closing the survivorship hole.

The problem this exists to fix
------------------------------
Every cross-sectional result in this project — the rank-IC probe, the abstention
classifier, the Fama-MacBeth t-statistic — was computed on the 40 names
hardcoded in :data:`cross_sectional_panel.DEFAULT_UNIVERSE`, and every one of
them was **underpowered**: real cross-sectional ICs are 0.02-0.05 and need
hundreds of names to detect. 39 is not hundreds, so those nulls measured sample
size, not the absence of signal.

The obvious fix is to add names. The obvious *source* for names is NSE's
``EQUITY_L.csv`` (already fetched by ``get_data.get_bse_nse_data``) — and it is a
trap. That file lists **currently active** equities. Measured against Wayback
Machine snapshots of the same URL:

===========  =============  ==========================
Snapshot     EQ names then  Absent from today's list
===========  =============  ==========================
2017-07      1,465          **392 (26.8%)**
2018-12      1,456          306 (21.0%)
2021-05      1,563          209 (13.4%)
===========  =============  ==========================

A quarter of the 2017 universe is gone. Building a 2017-2026 panel from today's
roster selects companies *on the basis of having survived the window*, then asks
a model to predict their returns over that window. And the missing names cannot
be recovered from yfinance: of 30 sampled vanished symbols, 23 returned no data
at all, 6 partial, 1 usable.

The fix: bhavcopy
-----------------
NSE publishes a **daily bhavcopy** — one file per trading day, containing every
instrument that traded that day. This is point-in-time *by construction*. There
is no membership list to get wrong and no survivorship correction to apply:
whatever traded on 2 January 2018 is in the 2 January 2018 file, including
companies that no longer exist. Verified: ``3IINFOTECH``, ``ADANITRANS``,
``ADLABS`` and ``ADHUNIK`` are all present with full OHLCV.

Two formats, one overlap
------------------------
NSE retired the legacy zipped-CSV bhavcopy in **July 2024** and replaced it with
the UDiFF format. Probed boundaries:

* legacy — works 2017-01 through **2024-07-01**; 404 from 2024-07-08 onward
* UDiFF (via ``nselib.capital_market.bhav_copy_equities``) — works from
  **2024-01** onward

The six-month overlap is not a nuisance, it is a **free cross-validation**: the
two independent sources must agree on the same day, and
``test_legacy_and_udiff_agree_on_overlapping_dates`` pins that they do.
:func:`fetch_day` tries legacy first and falls back, so no cutover date is
hardcoded into the control flow — if NSE moves the boundary again, the fallback
absorbs it.

Raw prices, and why that is the harder half
-------------------------------------------
Bhavcopy carries **raw traded prices**. yfinance was silently handling splits and
bonuses for us; bhavcopy will not. An unadjusted 1:10 split reads as a -90%
return and would poison every momentum feature and every ranking built on one.
``PREVCLOSE`` does not help — measured on seven 2019 split/bonus ex-dates, it
equals the prior day's raw close exactly (ratio 1.000), so NSE does not adjust it
either.

So the adjustment is ours to make, from
``nselib.capital_market.corporate_actions_for_equity`` (coverage verified back to
January 2017). :func:`parse_action` reads the free-text ``subject`` field:

* ``Bonus 1:4``                                          -> x1.25
* ``Face Value Split From Rs 10/- ... To Rs 2/- ...``     -> x5
* ``Bonus 1:2/Face Value Split ... Rs 2/- To Re 1/-``     -> x3 (compound)
* ``Interim Dividend Rs 2/- Per Share``                   -> Rs 2 cash

Validated against the actual ex-date price drop on 18 random 2018/2021 events:
**17 parsed correctly**; the one residual (AVANTIFEED, -13%) is a genuine market
move, not a parse error.

**Multiple actions can share an ex-date and must be multiplied, not deduplicated.**
GPIL on 2021-10-26 filed a 10->5 split *and* a 1:1 bonus as two separate records,
true factor 4.0. Treating them as one event gives 2.0 and an 82% error — this was
a real bug caught during validation, and ``test_same_day_actions_compound``
exists so it cannot come back.

Dividends are handled because the pipeline models log returns off ``adj_close``
(see ``get_data`` line ~352), which is yfinance's *fully* back-adjusted series.
Adjusting only for splits would make the new panel's returns incomparable with
every figure already published here.

The point-in-time bonus
-----------------------
``tests/audit_price_adjustment.py`` documented a small look-ahead in the
walk-forward backtest: yfinance's ``Adj Close`` bakes in adjustment factors from
actions that happen *after* a given origin. Because this module adjusts from an
explicit event list, :func:`adjust_prices` takes an ``as_of`` argument and
applies **only actions known by that date** — so a backtest origin can see the
series exactly as it looked then. That leak is closable here, which it was not
before.

No new dependency
-----------------
``requests``, ``pandas`` and ``nselib`` are all already pinned.
"""

import io
import os
import re
import time
import zipfile

import numpy as np
import pandas as pd
import requests

# ==========================================
# 0. Constants
# ==========================================
_MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
           "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

_LEGACY_ROOT = "https://archives.nseindia.com/content/historical/EQUITIES"

# NSE serves these only to browser-shaped requests; a bare urllib UA gets a 403.
_HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "*/*",
    "Referer": "https://www.nseindia.com/",
}

#: Where fetched days are cached. One file per trading day, written once.
CACHE_DIR = os.environ.get("STOCKAPP_BHAV_CACHE", ".bhav_cache")

#: Normalised schema every loader returns, whatever the upstream format.
COLUMNS = ["datetime", "symbol", "open", "high", "low", "close",
           "prevclose", "volume", "turnover"]

#: Schema of the parsed corporate-action table.
ACTION_COLUMNS = ["symbol", "ex_date", "factor", "dividend",
                  "rights_ratio", "rights_price", "subject"]

#: Last date the legacy archive is known to serve (probed, not documented by NSE).
LEGACY_LAST = pd.Timestamp("2024-07-01")

_FETCH_PAUSE = 0.25   # polite delay between live requests, seconds


# ==========================================
# 1. Fetch layer
# ==========================================
def legacy_url(day):
    """
    Build the legacy zipped-CSV bhavcopy URL for ``day``.

    Parameters
    ----------
    day : datetime-like
        Trading date.

    Returns
    -------
    str
    """
    ts = pd.Timestamp(day)
    mon = _MONTHS[ts.month - 1]
    return (f"{_LEGACY_ROOT}/{ts.year}/{mon}/"
            f"cm{ts.strftime('%d')}{mon}{ts.year}bhav.csv.zip")


def _norm(df, day):
    """Order, type and stamp a normalised frame."""
    df = df.copy()
    df["datetime"] = pd.Timestamp(day).normalize()
    for c in ("open", "high", "low", "close", "prevclose", "volume", "turnover"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df[COLUMNS]
    # A zero or negative close is not a price; it is a data error.
    df = df[df["close"] > 0]
    return df.reset_index(drop=True)


def read_legacy(content, day):
    """
    Parse legacy bhavcopy zip bytes into the normalised schema.

    Keeps ``SERIES == 'EQ'`` only. The legacy file also carries government
    securities (``GS``), treasury bills (``TB``) and the trade-for-trade /
    surveillance segments (``BE``, ``BZ``) — none of which belong in a
    cross-sectional equity panel.

    Parameters
    ----------
    content : bytes
        Raw ``.zip`` payload.
    day : datetime-like
        Trading date to stamp onto the rows.

    Returns
    -------
    pd.DataFrame
        Columns :data:`COLUMNS`.
    """
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        raw = pd.read_csv(z.open(z.namelist()[0]))
    raw.columns = [c.strip() for c in raw.columns]
    raw["SYMBOL"] = raw["SYMBOL"].astype(str).str.strip()
    raw["SERIES"] = raw["SERIES"].astype(str).str.strip()
    eq = raw[raw["SERIES"] == "EQ"]
    out = pd.DataFrame({
        "symbol": eq["SYMBOL"].values,
        "open": eq["OPEN"].values,
        "high": eq["HIGH"].values,
        "low": eq["LOW"].values,
        "close": eq["CLOSE"].values,
        "prevclose": eq["PREVCLOSE"].values,
        "volume": eq["TOTTRDQTY"].values,
        "turnover": eq["TOTTRDVAL"].values,
    })
    return _norm(out, day)


def read_udiff(raw, day):
    """
    Parse a UDiFF-format frame (as returned by ``nselib``) into the normalised
    schema.

    Filters to cash-segment stocks: ``FinInstrmTp == 'STK'`` and
    ``SctySrs == 'EQ'``. The UDiFF file spans every segment NSE publishes,
    derivatives included, so both filters are load-bearing.

    Parameters
    ----------
    raw : pd.DataFrame
        UDiFF frame.
    day : datetime-like

    Returns
    -------
    pd.DataFrame
        Columns :data:`COLUMNS`.
    """
    raw = raw.copy()
    raw.columns = [c.strip() for c in raw.columns]
    for c in ("TckrSymb", "SctySrs", "FinInstrmTp"):
        if c in raw.columns:
            raw[c] = raw[c].astype(str).str.strip()
    m = (raw["SctySrs"] == "EQ")
    if "FinInstrmTp" in raw.columns:
        m &= (raw["FinInstrmTp"] == "STK")
    eq = raw[m]
    out = pd.DataFrame({
        "symbol": eq["TckrSymb"].values,
        "open": eq["OpnPric"].values,
        "high": eq["HghPric"].values,
        "low": eq["LwPric"].values,
        "close": eq["ClsPric"].values,
        "prevclose": eq["PrvsClsgPric"].values,
        "volume": eq["TtlTradgVol"].values,
        "turnover": eq["TtlTrfVal"].values,
    })
    return _norm(out, day)


def _cache_path(day, cache_dir):
    ts = pd.Timestamp(day)
    return os.path.join(cache_dir, f"bhav_{ts.strftime('%Y%m%d')}.csv.gz")


def fetch_day(day, cache_dir=CACHE_DIR, session=None, retries=3,
              use_cache=True):
    """
    Return one trading day's equity bhavcopy, or ``None`` if NSE has no file.

    ``None`` is the correct answer for a weekend or exchange holiday, and the
    caller cannot distinguish those from a fetch failure by date arithmetic
    alone — NSE holidays are irregular. Missing days are therefore *skipped*,
    never interpolated.

    Tries the legacy archive first and falls back to UDiFF via ``nselib``, so
    the format cutover is discovered rather than hardcoded.

    Parameters
    ----------
    day : datetime-like
    cache_dir : str, optional
        Directory for the one-file-per-day cache. Created on demand.
    session : requests.Session, optional
        Injected in tests; a live session is created if omitted.
    retries : int, optional
        Attempts per transport, with exponential backoff.
    use_cache : bool, optional
        Set ``False`` to force a live fetch.

    Returns
    -------
    pd.DataFrame or None
    """
    ts = pd.Timestamp(day).normalize()
    path = _cache_path(ts, cache_dir)
    if use_cache and os.path.exists(path):
        cached = pd.read_csv(path, parse_dates=["datetime"])
        return cached if len(cached) else None

    frame = None
    sess = session or requests.Session()

    # --- transport 1: legacy zipped CSV -------------------------------------
    for attempt in range(retries):
        try:
            r = sess.get(legacy_url(ts), headers=_HEADERS, timeout=45)
            if r.status_code == 200 and len(r.content) > 1000:
                frame = read_legacy(r.content, ts)
            break              # a clean 404 means "no legacy file", not "retry"
        except Exception:
            if attempt == retries - 1:
                break
            time.sleep(0.5 * (2 ** attempt))

    # --- transport 2: UDiFF via nselib --------------------------------------
    if frame is None:
        try:
            from nselib import capital_market as _cm
            raw = _cm.bhav_copy_equities(ts.strftime("%d-%m-%Y"))
            if raw is not None and len(raw):
                frame = read_udiff(raw, ts)
        except Exception:
            frame = None

    if use_cache:
        os.makedirs(cache_dir, exist_ok=True)
        # An empty file is a real answer ("market shut"), cached so the next run
        # does not re-request a holiday.
        (frame if frame is not None
         else pd.DataFrame(columns=COLUMNS)).to_csv(path, index=False)

    time.sleep(_FETCH_PAUSE)
    return frame


def fetch_range(start, end, cache_dir=CACHE_DIR, session=None,
                fetch_fn=None, verbose=True):
    """
    Fetch every trading day in ``[start, end]`` and stack them.

    Weekends are skipped without a request; holidays are discovered (the fetch
    returns ``None``) and skipped.

    Parameters
    ----------
    start, end : datetime-like
    cache_dir : str, optional
    session : requests.Session, optional
    fetch_fn : callable, optional
        ``fetch_fn(day) -> DataFrame | None``. Injected in tests so they run
        offline.
    verbose : bool, optional

    Returns
    -------
    (pd.DataFrame, dict)
        ``(frame, report)`` where ``report`` carries ``n_days``, ``n_missing``,
        ``n_rows`` and ``n_symbols``.
    """
    days = pd.bdate_range(pd.Timestamp(start).normalize(),
                          pd.Timestamp(end).normalize())
    # One session for the whole range. Creating one per day (which is what
    # fetch_day does when handed None) throws away connection reuse and TLS
    # session resumption -- across ~2,500 days that is the dominant cost.
    sess = session if session is not None else requests.Session()
    get = fetch_fn or (lambda d: fetch_day(d, cache_dir=cache_dir,
                                           session=sess))
    frames, missing = [], 0
    for i, d in enumerate(days):
        f = get(d)
        if f is None or not len(f):
            missing += 1
        else:
            frames.append(f)
        if verbose and (i + 1) % 100 == 0:
            print(f"  bhavcopy {i + 1}/{len(days)} days "
                  f"({len(frames)} with data)")
    out = (pd.concat(frames, ignore_index=True) if frames
           else pd.DataFrame(columns=COLUMNS))
    report = {"n_days": len(days), "n_missing": missing, "n_rows": len(out),
              "n_symbols": int(out["symbol"].nunique()) if len(out) else 0}
    return out, report


# ==========================================
# 2. Corporate actions
# ==========================================
_RE_BONUS = re.compile(r"Bonus\s+(\d+)\s*:\s*(\d+)", re.I)
_RE_SPLIT = re.compile(
    r"From\s+(?:Rs|Re)\.?\s*([\d.]+).*?To\s+(?:Rs|Re)\.?\s*([\d.]+)", re.I)
_RE_DIV = re.compile(
    r"Dividend\b[\s\-:]*(?:of\s+)?(?:Rs|Re)\.?\s*([\d.]+)", re.I)
# 'Rights 19:67 @ Premium Rs 215 Per Share', 'Rights 588:1000@ Premium Rs 2/-',
# 'Rights - 4:25 Fully Paid Up Shares @ Premium Rs 500/- Per Share'. The words
# between the ratio and the '@' vary, hence [^@]*.
_RE_RIGHTS = re.compile(
    r"Rights[\s\-]*(\d+)\s*:\s*(\d+)[^@]*@\s*Premium\s*(?:Rs|Re)\.?\s*([\d.]+)",
    re.I)


def _f(text):
    """float() that tolerates a trailing '.' from 'Rs 6/-' style strings."""
    try:
        return float(str(text).rstrip("."))
    except (TypeError, ValueError):
        return None


def parse_action(subject):
    """
    Read NSE's free-text corporate-action ``subject`` into numeric adjustments.

    Three kinds of adjustment, deliberately kept separate because they act
    differently on the price:

    * a **price factor** — splits and bonuses rescale the share count, so the
      historical price divides by the factor;
    * a **cash dividend** — reduces the price by an absolute amount, not a ratio;
    * a **rights ratio and premium** — dilution at a discount, whose effect
      depends on the prevailing price and so cannot be reduced to a number here.

    ``Bonus a:b`` means *a* new shares for every *b* held, so the share count
    grows by ``(a + b) / b`` and that is the factor. A face-value split from
    Rs X to Rs Y has factor ``X / Y``. A single subject may contain several, in
    which case the factors **multiply**.

    Rights were added after the yfinance audit: reconstructed returns matched
    yfinance at correlation 1.00000 for 22 of 24 names, and **both** exceptions
    (BHARTIARTL 2019, TATASTEEL 2018) turned out to be rights issues rather than
    anything wrong with the split/dividend logic. They are rare — 12 of 789
    records in the sampled windows — and individually large, which is the worst
    combination for a silent gap.

    NSE quotes the **premium over face value**, not the subscription price:
    Bharti Airtel's 2019 issue reads ``@ Premium Rs 215`` against a Rs 5 face
    value, for a true subscription price of Rs 220. The face value therefore has
    to come from the feed's ``faceVal`` column, which is why this function
    returns the premium and :func:`corporate_actions` does the addition.

    Parameters
    ----------
    subject : str

    Returns
    -------
    dict
        ``{'factor': float, 'dividend': float, 'rights_ratio': float,
        'rights_premium': float}``. Neutral values (1.0, 0.0, 0.0, 0.0) when
        nothing parseable is present, so the result is always safe to apply.
    """
    s = "" if subject is None else str(subject)
    factor, dividend = 1.0, 0.0
    rights_ratio, rights_premium = 0.0, 0.0

    for a, b in _RE_BONUS.findall(s):
        a, b = int(a), int(b)
        if b > 0:
            factor *= (a + b) / b

    m = _RE_SPLIT.search(s)
    if m:
        old, new = _f(m.group(1)), _f(m.group(2))
        if old and new and new > 0:
            factor *= old / new

    for d in _RE_DIV.findall(s):
        v = _f(d)
        if v and v > 0:
            dividend += v

    # Only the first rights tranche is taken. Tata Steel's 2018 subject carries a
    # fully-paid AND a partly-paid tranche; a partly-paid share is a separate
    # instrument with its own price, and folding it into the ordinary series
    # would be wrong in a way that is worse than ignoring it.
    r = _RE_RIGHTS.search(s)
    if r:
        a, b, prem = int(r.group(1)), int(r.group(2)), _f(r.group(3))
        if b > 0 and prem is not None:
            rights_ratio = a / b
            rights_premium = float(prem)

    return {"factor": float(factor), "dividend": float(dividend),
            "rights_ratio": float(rights_ratio),
            "rights_premium": float(rights_premium)}


def corporate_actions(start, end, fetch_fn=None, chunk_months=6):
    """
    Fetch and parse corporate actions over ``[start, end]``.

    NSE's endpoint refuses very long ranges, so the window is requested in
    chunks and concatenated.

    Rows with no parseable adjustment (``factor == 1`` and ``dividend == 0``)
    are dropped — announcements, AGM notices and the like.

    Parameters
    ----------
    start, end : datetime-like
    fetch_fn : callable, optional
        ``fetch_fn(from_str, to_str) -> DataFrame`` in ``nselib`` shape.
        Injected in tests.
    chunk_months : int, optional

    Returns
    -------
    pd.DataFrame
        Columns ``['symbol', 'ex_date', 'factor', 'dividend', 'subject']``,
        sorted by ``(symbol, ex_date)``.
    """
    if fetch_fn is None:
        from nselib import capital_market as _cm

        def fetch_fn(a, b):
            return _cm.corporate_actions_for_equity(from_date=a, to_date=b)

    s, e = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
    bounds = pd.date_range(s, e + pd.DateOffset(months=chunk_months),
                           freq=pd.DateOffset(months=chunk_months))
    frames = []
    for i in range(len(bounds) - 1):
        a, b = bounds[i], min(bounds[i + 1] - pd.Timedelta(days=1), e)
        if a > e:
            break
        try:
            d = fetch_fn(a.strftime("%d-%m-%Y"), b.strftime("%d-%m-%Y"))
        except Exception:
            continue
        if d is not None and len(d):
            frames.append(d)
    if not frames:
        return pd.DataFrame(columns=ACTION_COLUMNS)

    raw = pd.concat(frames, ignore_index=True)
    ex = pd.to_datetime(raw["exDate"], format="%d-%b-%Y", errors="coerce")
    parsed = [parse_action(x) for x in raw["subject"]]

    # NSE quotes rights as a premium over face value, so the subscription price
    # is face value + premium. 'faceVal' is the only place the face value is
    # available, which is why the addition happens here and not in parse_action.
    face = (pd.to_numeric(raw["faceVal"], errors="coerce")
            if "faceVal" in raw.columns
            else pd.Series(np.nan, index=raw.index)).fillna(0.0).to_numpy()
    prem = np.array([p["rights_premium"] for p in parsed], dtype=float)
    ratio = np.array([p["rights_ratio"] for p in parsed], dtype=float)

    out = pd.DataFrame({
        "symbol": raw["symbol"].astype(str).str.strip(),
        "ex_date": ex,
        "factor": [p["factor"] for p in parsed],
        "dividend": [p["dividend"] for p in parsed],
        "rights_ratio": ratio,
        "rights_price": np.where(ratio > 0, face + prem, 0.0),
        "subject": raw["subject"].astype(str),
    })
    out = out.dropna(subset=["ex_date"])
    # Identical (symbol, ex_date, subject) rows are NSE re-broadcasts of one
    # event; distinct subjects on the same date are distinct events and must
    # both survive to be compounded downstream.
    out = out.drop_duplicates(subset=["symbol", "ex_date", "subject"])
    out = out[(out["factor"] != 1.0) | (out["dividend"] != 0.0) |
              (out["rights_ratio"] > 0.0)]
    return out[ACTION_COLUMNS].sort_values(
        ["symbol", "ex_date"]).reset_index(drop=True)


# ==========================================
# 3. Back-adjustment
# ==========================================
def adjust_prices(prices, actions, as_of=None):
    """
    Add an ``adj_close`` column: raw closes back-adjusted for splits, bonuses
    and dividends.

    Convention matches yfinance's ``Adj Close`` — the **most recent** price is
    left untouched and history is scaled backwards — so a series built here is
    directly comparable with every figure already published from ``adj_close``.

    For each action with ex-date *E*, prices strictly **before** *E* are
    multiplied by::

        (1 / factor) * (1 - dividend / P) * (TERP / P)

    where ``P`` is the last raw close before *E* and ``TERP``, the theoretical
    ex-rights price, is ``(P + ratio * subscription) / (1 + ratio)``.

    All three corrections have the same shape — the ratio of the theoretical
    post-event price to the cum price — so they are multiplicative and compose.
    Multiple actions on one ex-date therefore compound naturally rather than
    needing a special case, which is what makes the GPIL split-plus-bonus
    situation correct by construction rather than by patch.

    Parameters
    ----------
    prices : pd.DataFrame
        Long panel with ``['datetime', 'symbol', 'close']`` at minimum.
    actions : pd.DataFrame
        As returned by :func:`corporate_actions`.
    as_of : datetime-like, optional
        Apply only actions whose ex-date is **at or before** this date. This is
        the point-in-time switch: a backtest origin passes its own date and sees
        the series as it looked then, with no future adjustment baked in. When
        ``None`` (the default) every action is applied, which is correct for
        live serving and matches yfinance.

    Returns
    -------
    pd.DataFrame
        ``prices`` with an added ``adj_close`` column, sorted by
        ``(symbol, datetime)``.
    """
    out = prices.sort_values(["symbol", "datetime"]).reset_index(drop=True)
    out["adj_close"] = out["close"].astype(float)
    if actions is None or not len(actions):
        return out

    acts = actions.copy()
    if as_of is not None:
        acts = acts[acts["ex_date"] <= pd.Timestamp(as_of)]
    if not len(acts):
        return out

    by_symbol = {s: g for s, g in acts.groupby("symbol")}
    pieces = []
    for sym, grp in out.groupby("symbol", sort=False):
        ev = by_symbol.get(sym)
        if ev is None or not len(ev):
            pieces.append(grp)
            continue
        g = grp.reset_index(drop=True)
        dates = g["datetime"].values
        close = g["close"].to_numpy(dtype=float)
        cum = np.ones(len(g), dtype=float)
        for _, e in ev.iterrows():
            ex = np.datetime64(pd.Timestamp(e["ex_date"]).to_datetime64())
            before = dates < ex
            if not before.any():
                # Ex-date precedes this symbol's history: nothing to adjust.
                continue
            step = 1.0 / float(e["factor"]) if e["factor"] else 1.0
            prev = close[before][-1]         # last raw close before the ex-date
            div = float(e["dividend"])
            if div > 0 and prev > 0:
                step *= max(1.0 - div / prev, 1e-6)
            ratio = float(e.get("rights_ratio", 0.0) or 0.0)
            sub = float(e.get("rights_price", 0.0) or 0.0)
            if ratio > 0 and sub > 0 and prev > 0:
                # Theoretical ex-rights price: the value of one old share plus
                # `ratio` new shares bought at `sub`, spread over the enlarged
                # holding. Same shape as the dividend correction -- the ratio of
                # the theoretical post-event price to the cum price.
                terp = (prev + ratio * sub) / (1.0 + ratio)
                if terp > 0:
                    step *= terp / prev
            cum[before] *= step
        g["adj_close"] = close * cum
        pieces.append(g)
    return pd.concat(pieces, ignore_index=True).sort_values(
        ["symbol", "datetime"]).reset_index(drop=True)


# ==========================================
# 4. Universe construction
# ==========================================
def liquidity_screen(prices, as_of, lookback_days=250, n=200,
                     min_turnover=5e7, min_days=200):
    """
    Choose the universe by turnover measured in a window that **ends before**
    the study period.

    This is the subtle half of universe construction. Screening on liquidity
    measured *over the study window* selects names using information from inside
    the test period — a cousin of survivorship bias, and just as capable of
    manufacturing a result. The screen therefore looks only at
    ``[as_of - lookback_days, as_of)`` and the panel starts at ``as_of``.

    Parameters
    ----------
    prices : pd.DataFrame
        Long panel with ``['datetime', 'symbol', 'turnover', 'volume']``.
    as_of : datetime-like
        First date of the study period. The screen uses data strictly before it.
    lookback_days : int, optional
        Calendar days of history to measure over.
    n : int, optional
        Universe size to return.
    min_turnover : float, optional
        Minimum *median* daily turnover in rupees. The default, Rs 5 crore, was
        chosen from a 20-name sample whose median was Rs 6.6 crore and whose
        illiquid tail (Rs 0.05-0.26 crore) carried 14-19% zero-volume days —
        unusable in a cross-section, where a stock that did not trade has no
        meaningful rank against one that did.
    min_days : int, optional
        Minimum trading days present in the lookback window.

    Returns
    -------
    (list of str, pd.DataFrame)
        ``(symbols, table)`` — the chosen universe and the full screen table, so
        the selection is auditable rather than asserted.
    """
    end = pd.Timestamp(as_of).normalize()
    start = end - pd.Timedelta(days=int(lookback_days))
    w = prices[(prices["datetime"] >= start) & (prices["datetime"] < end)]
    if not len(w):
        return [], pd.DataFrame(columns=["symbol", "median_turnover", "n_days",
                                         "zero_vol_frac"])

    g = w.groupby("symbol")
    table = pd.DataFrame({
        "median_turnover": g["turnover"].median(),
        "n_days": g["close"].size(),
        "zero_vol_frac": g["volume"].apply(lambda v: float((v == 0).mean())),
    }).reset_index()

    ok = table[(table["median_turnover"] >= min_turnover) &
               (table["n_days"] >= min_days) &
               (table["zero_vol_frac"] <= 0.05)]
    ok = ok.sort_values("median_turnover", ascending=False)
    return (ok["symbol"].head(int(n)).tolist(),
            table.sort_values("median_turnover",
                              ascending=False).reset_index(drop=True))


# ==========================================
# 5. Cache loading and the assembled panel
# ==========================================
def load_cache(start, end, symbols=None, cache_dir=CACHE_DIR):
    """
    Read cached bhavcopy days back into one long panel.

    Filtering to ``symbols`` happens **per day, before concatenation**. A decade
    of the full market is ~4.8M rows; loading it whole and subsetting afterwards
    is the difference between a few hundred MB and several GB.

    Parameters
    ----------
    start, end : datetime-like
    symbols : iterable of str, optional
        Restrict to these tickers. ``None`` loads everything, which is what the
        liquidity screen needs.
    cache_dir : str, optional

    Returns
    -------
    pd.DataFrame
        Columns :data:`COLUMNS`, sorted by ``(symbol, datetime)``.
    """
    keep = set(symbols) if symbols is not None else None
    frames = []
    for d in pd.bdate_range(pd.Timestamp(start).normalize(),
                            pd.Timestamp(end).normalize()):
        p = _cache_path(d, cache_dir)
        if not os.path.exists(p):
            continue
        day = pd.read_csv(p, parse_dates=["datetime"])
        if not len(day):
            continue                       # weekend or exchange holiday
        if keep is not None:
            day = day[day["symbol"].isin(keep)]
        if len(day):
            frames.append(day)
    if not frames:
        return pd.DataFrame(columns=COLUMNS)
    out = pd.concat(frames, ignore_index=True)
    return out.sort_values(["symbol", "datetime"]).reset_index(drop=True)


def build_panel(start, end, n=200, lookback_days=365, cache_dir=CACHE_DIR,
                actions=None, min_turnover=5e7, min_days=200, verbose=True):
    """
    Assemble a survivorship-free, corporate-action-adjusted panel.

    The order of operations is the whole point, and each step exists to close a
    specific way of cheating:

    1. **Screen the universe on a pre-window lookback.** Liquidity measured
       inside the study period would select names on test-period information.
    2. **Load only those names, from the daily files.** Membership is whatever
       actually traded, so delisted companies are present for exactly the span
       they existed.
    3. **Adjust for corporate actions.** Raw bhavcopy prices make a 1:10 split
       look like a -90% return.

    Parameters
    ----------
    start, end : datetime-like
        Study period. The liquidity lookback ends at ``start``.
    n : int, optional
        Universe size.
    lookback_days : int, optional
        Calendar days before ``start`` used for the screen.
    cache_dir : str, optional
    actions : pd.DataFrame, optional
        Pre-fetched corporate actions. Fetched live if omitted; injected in
        tests.
    min_turnover, min_days : optional
        Passed to :func:`liquidity_screen`.
    verbose : bool, optional

    Returns
    -------
    (pd.DataFrame, dict)
        ``(panel, report)``. The panel has ``adj_close``; the report carries the
        universe, the screen table and row/name counts.
    """
    s, e = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
    look_start = s - pd.Timedelta(days=int(lookback_days))

    if verbose:
        print(f"[1/3] liquidity screen on {look_start.date()} .. {s.date()}")
    screen_px = load_cache(look_start, s, cache_dir=cache_dir)
    universe, table = liquidity_screen(screen_px, s, lookback_days=lookback_days,
                                       n=n, min_turnover=min_turnover,
                                       min_days=min_days)
    del screen_px
    if verbose:
        print(f"      {len(table)} names screened -> {len(universe)} selected")

    if verbose:
        print(f"[2/3] loading {s.date()} .. {e.date()} for {len(universe)} names")
    panel = load_cache(s, e, symbols=universe, cache_dir=cache_dir)

    if verbose:
        print("[3/3] corporate-action adjustment")
    if actions is None:
        actions = corporate_actions(look_start, e)
    panel = adjust_prices(panel, actions)

    report = {
        "universe": universe,
        "n_universe": len(universe),
        "screen_table": table,
        "n_rows": len(panel),
        "n_dates": int(panel["datetime"].nunique()) if len(panel) else 0,
        "n_symbols": int(panel["symbol"].nunique()) if len(panel) else 0,
        "n_actions": len(actions) if actions is not None else 0,
    }
    return panel, report


def bhav_fetcher(panel):
    """
    Adapt an adjusted bhavcopy panel into the ``fetch_fn`` that
    ``cross_sectional_panel.build_panel`` already accepts.

    This is the whole integration. ``cross_sectional_panel`` was written with an
    injectable fetcher so its tests could run offline; that same seam lets a
    survivorship-free source replace yfinance with **no change to the module and
    no change to any feature, split or model**. Whatever the expanded universe
    shows is therefore attributable to the universe, not to a rebuilt pipeline —
    which is the only way the comparison against the published 39-name results
    means anything.

    Accepts tickers with or without the ``.NS`` suffix, so an existing
    ``DEFAULT_UNIVERSE`` list works unmodified.

    Parameters
    ----------
    panel : pd.DataFrame
        Long panel carrying ``adj_close`` — the output of :func:`build_panel`.

    Returns
    -------
    callable
        ``fetch_fn(ticker) -> DataFrame`` with columns
        ``['datetime', 'open', 'high', 'low', 'close', 'adj_close', 'volume']``.
        Returns an empty frame for an unknown ticker, which ``build_panel``
        already records as a drop rather than treating as an error.
    """
    keep = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    by_symbol = {s: g for s, g in panel.groupby("symbol")}

    def fetch_fn(ticker):
        sym = str(ticker)
        # Explicit None checks: `a or b` on DataFrames raises "truth value of a
        # DataFrame is ambiguous".
        g = by_symbol.get(sym)
        if g is None:
            g = by_symbol.get(sym.replace(".NS", ""))
        if g is None or not len(g):
            return pd.DataFrame(columns=keep)
        out = g.sort_values("datetime").reset_index(drop=True)
        return out[[c for c in keep if c in out.columns]].copy()

    return fetch_fn
