import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

from model_utils import normalize_interval, generate_future_dates
from ML_model import create_features
from direct_forecast import (
    horizon_feature_cols, make_horizon_targets, training_frame,
    compute_origin_row, conformal_halfwidth,
)


# ==========================================
# 1. Base Model Definitions
# ==========================================
def _get_base_models():
    """
    Create the three base learners for the stacking ensemble.

    Returns XGBoost (pseudo-Huber loss), LightGBM (Huber loss), and
    Ridge regression. All gradient-boosting models are configured with
    early-stopping-compatible settings.

    Returns
    -------
    list of tuple
        Each tuple is (name: str, model: estimator, engine: str).
    """
    xgb_model = xgb.XGBRegressor(
        objective='reg:pseudohubererror',
        n_estimators=1000,
        learning_rate=0.03,
        max_depth=5,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        min_child_weight=5,
        n_jobs=-1,
        random_state=42,
        early_stopping_rounds=50,
    )
    lgb_model = lgb.LGBMRegressor(
        objective='huber',
        n_estimators=1000,
        learning_rate=0.03,
        num_leaves=31,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        min_child_samples=20,
        n_jobs=-1,
        random_state=42,
        verbose=-1,
    )
    ridge_model = Ridge(alpha=1.0)

    return [
        ('xgboost', xgb_model, 'xgboost'),
        ('lightgbm', lgb_model, 'lightgbm'),
        ('ridge', ridge_model, 'ridge'),
    ]


# ==========================================
# 2. Out-of-Fold Prediction Generation
# ==========================================
def _train_and_predict_oof(features_df, feature_cols, target_col):
    """
    Train base models and generate out-of-fold meta-features.

    Splits data temporally into three chunks:
    - 60 % for base model training
    - 20 % for meta-feature generation (OOF predictions)
    - 20 % held out as final validation

    Each base model is trained on the first chunk, then predicts on
    the second chunk.  The stacked OOF predictions become meta-features
    for the meta-learner.

    Parameters
    ----------
    features_df : pd.DataFrame
        Engineered features with datetime index.
    feature_cols : list of str
        Ordered list of feature column names.
    target_col : str
        Target column name in features_df.

    Returns
    -------
    meta_X : np.ndarray
        (n_oof, 3) stacked OOF predictions from base models.
    meta_y : np.ndarray
        (n_oof,) true target values for OOF portion.
    trained_base : list of tuple
        (name, fitted_model, engine) for each base model, retrained
        on the combined train+OOF data for final prediction.
    feature_cols : list of str
        Feature columns used.
    val_mae : dict
        Base-model-name -> MAE on the final validation chunk.
    """
    X_all = features_df[feature_cols].values
    y_all = features_df[target_col].values

    n = len(X_all)
    split_1 = int(n * 0.6)
    split_2 = int(n * 0.8)

    X_base = X_all[:split_1]
    y_base = y_all[:split_1]
    X_oof = X_all[split_1:split_2]
    y_oof = y_all[split_1:split_2]
    X_val = X_all[split_2:]
    y_val = y_all[split_2:]

    base_defs = _get_base_models()
    oof_preds = []
    val_mae = {}

    for name, model, engine in base_defs:
        if engine == 'xgboost':
            model.fit(
                X_base, y_base,
                eval_set=[(X_oof, y_oof)],
                verbose=False,
            )
        elif engine == 'lightgbm':
            callbacks = [
                lgb.early_stopping(stopping_rounds=50, verbose=False),
                lgb.log_evaluation(0),
            ]
            model.fit(
                X_base, y_base,
                eval_set=[(X_oof, y_oof)],
                eval_metric='rmse',
                callbacks=callbacks,
            )
        else:
            model.fit(X_base, y_base)

        oof_preds.append(model.predict(X_oof))
        pred_val = model.predict(X_val)
        val_mae[name] = mean_absolute_error(y_val, pred_val)
        print(f"  {name} val MAE: {val_mae[name]:.6f}")

    meta_X = np.column_stack(oof_preds)
    meta_y = y_oof

    retrained = []
    X_retrain = X_all[:split_2]
    y_retrain = y_all[:split_2]

    for name, _, engine in base_defs:
        if engine == 'xgboost':
            m = xgb.XGBRegressor(
                objective='reg:pseudohubererror',
                n_estimators=1000, learning_rate=0.03, max_depth=5,
                subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1,
                reg_lambda=1.0, min_child_weight=5, n_jobs=-1,
                random_state=42, early_stopping_rounds=50,
            )
            m.fit(
                X_retrain, y_retrain,
                eval_set=[(X_val, y_val)],
                verbose=False,
            )
        elif engine == 'lightgbm':
            m = lgb.LGBMRegressor(
                objective='huber', n_estimators=1000, learning_rate=0.03,
                num_leaves=31, subsample=0.8, subsample_freq=1,
                colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
                min_child_samples=20, n_jobs=-1, random_state=42,
                verbose=-1,
            )
            cbs = [
                lgb.early_stopping(stopping_rounds=50, verbose=False),
                lgb.log_evaluation(0),
            ]
            m.fit(
                X_retrain, y_retrain,
                eval_set=[(X_val, y_val)],
                eval_metric='rmse',
                callbacks=cbs,
            )
        else:
            m = Ridge(alpha=1.0)
            m.fit(X_retrain, y_retrain)

        retrained.append((name, m, engine))

    return meta_X, meta_y, retrained, feature_cols, val_mae


# ==========================================
# 3. Meta-Learner Training
# ==========================================
def _train_meta_learner(meta_X, meta_y):
    """
    Train a Ridge meta-learner on stacked base-model predictions.

    Ridge regression is chosen for its stability and resistance to
    overfitting when the meta-feature space is very small (3 columns).

    Parameters
    ----------
    meta_X : np.ndarray
        (n_oof, 3) stacked OOF predictions.
    meta_y : np.ndarray
        (n_oof,) true target values.

    Returns
    -------
    Ridge
        Fitted meta-learner.
    """
    meta = Ridge(alpha=1.0)
    meta.fit(meta_X, meta_y)
    meta_pred = meta.predict(meta_X)
    mae = mean_absolute_error(meta_y, meta_pred)
    print(f"  Meta-learner OOF MAE: {mae:.6f}")
    return meta


# ==========================================
# 4. Main Orchestrator (Direct Multi-Horizon)
# ==========================================
def run_ensemble_prediction(df, interval, horizon):
    """
    Main function to run the stacking ensemble prediction.

    Uses **direct multi-horizon** forecasting: for each step ``h`` a full
    stacking ensemble (XGBoost + LightGBM + Ridge base learners with a Ridge
    meta-learner, trained on temporally-honest out-of-fold predictions) targets
    the *cumulative* log return ``log(P[t+h]/P[t])`` and forecasts directly from
    the observed features at the last bar. This removes the recursive error
    accumulation (and one-bar origin offset) that made the recursive ensemble a
    bottom performer in the walk-forward backtest, while preserving the
    leakage-aware OOF stacking design. Distribution-free **conformal**
    prediction intervals are added per horizon via a temporal split-conformal
    calibration of the full stack.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with datetime, OHLCV columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps.

    Returns
    -------
    pd.DataFrame
        Columns: ['datetime', 'predicted_price', 'lower_bound',
        'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Stacking Ensemble Prediction ({interval}) ---")

    df = df.copy()
    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.iloc[-max_obs:]

    features_df = create_features(df, interval)
    feature_cols = horizon_feature_cols(features_df)
    targets = make_horizon_targets(features_df, horizon)

    origin_X, last_price, last_date = compute_origin_row(
        df, feature_cols, interval,
    )
    origin_vals = origin_X.values   # base models are trained on numpy arrays
    future_dates = generate_future_dates(last_date, horizon, interval)

    print(f"Training {horizon} direct stacking-ensemble horizon models...")

    def _stack_fit_predict(proper_df, X_cal, target_name):
        """Train the full stack on proper-train rows, predict calibration rows."""
        mX, mY, base, _, _ = _train_and_predict_oof(
            proper_df, feature_cols, target_name,
        )
        meta = _train_meta_learner(mX, mY)
        cal_vals = X_cal.values
        base_stack = np.column_stack([m.predict(cal_vals) for _, m, _ in base])
        return meta.predict(base_stack)

    rows = []
    for i, h in enumerate(range(1, horizon + 1)):
        target_name = f'target_h{h}'
        train_df = training_frame(
            features_df, feature_cols, targets[h], target_name,
        )

        meta_X, meta_y, trained_base, _, _ = _train_and_predict_oof(
            train_df, feature_cols, target_name,
        )
        meta_learner = _train_meta_learner(meta_X, meta_y)

        base_preds = [model.predict(origin_vals)[0] for _, model, _ in trained_base]
        cum_return = float(
            meta_learner.predict(np.array(base_preds).reshape(1, -1))[0]
        )

        half = conformal_halfwidth(
            train_df, feature_cols, target_name,
            lambda p, xc, _tn=target_name: _stack_fit_predict(p, xc, _tn),
            embargo=h,
        )
        if half is None:
            half = 1.96 * float(np.std(train_df[target_name].values))

        median = last_price * np.exp(cum_return)
        lower = last_price * np.exp(cum_return - half)
        upper = last_price * np.exp(cum_return + half)
        rows.append({
            'datetime': future_dates[i],
            'predicted_price': float(median),
            'lower_bound': float(lower),
            'upper_bound': float(upper),
            'volatility': float((upper - lower) / (2 * 1.96)),
        })

    print("Stacking Ensemble Prediction Complete.")
    return pd.DataFrame(rows)
