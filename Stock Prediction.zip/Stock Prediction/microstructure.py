"""
Microstructural features from daily OHLCV (López de Prado, AFML Ch. 19).

Why this module exists
----------------------
[Section 39] costed the short-term reversal signal and concluded it does not
survive transaction costs -- breakeven 6.1 bp round trip. That conclusion rests
on **assumed** cost scenarios (10 / 25 / 50 / 100 bp). The assumption is
defensible, and it is still an assumption, which makes it the weakest link in an
otherwise measured argument.

AFML Ch. 19 supplies the fix. Corwin & Schultz (2012) estimate the **bid-ask
spread from high and low prices alone** -- no tick data, no quotes, nothing this
project does not already fetch. That turns §39's central assumption into a
measurement.

The rest of Ch. 19 needs data this project does not have. VPIN, order-flow
imbalance and the sequential-trade models all require **tick-level signed
volume**; they are not implemented here rather than approximated badly. What
*is* computable from daily OHLCV is implemented, and nothing else.

What Corwin-Schultz does
------------------------
Two observations drive it:

1. A bar's **high** is almost always transacted at the ask and its **low** at
   the bid, so the high-low ratio contains the spread plus fundamental
   volatility.
2. The volatility component scales with **elapsed time**, while the spread
   component does not.

Comparing a single bar's range against a two-bar range therefore separates the
two. With

.. math::
    \\beta = E\\left[\\sum_{j=0}^{1}\\left(\\ln\\frac{H_{t+j}}{L_{t+j}}\\right)^2\\right],
    \\qquad
    \\gamma = \\left(\\ln\\frac{H_{t-1,t}}{L_{t-1,t}}\\right)^2

where :math:`H_{t-1,t}` and :math:`L_{t-1,t}` are the high and low **across two
bars**, the spread as a fraction of price is

.. math::
    \\alpha = \\frac{\\sqrt{2\\beta}-\\sqrt{\\beta}}{3-2\\sqrt{2}}
              - \\sqrt{\\frac{\\gamma}{3-2\\sqrt{2}}},
    \\qquad
    S = \\frac{2(e^{\\alpha}-1)}{1+e^{\\alpha}}

Negative :math:`\\alpha` implies a negative spread, which is meaningless; Corwin
& Schultz (2012, p. 727) recommend flooring it at zero, and :func:`corwin_schultz`
reports **how often that floor binds** rather than hiding it -- a high floor rate
means the estimator is struggling on that name, and the user should know.

Becker-Parkinson volatility falls out of the same :math:`\\beta` and
:math:`\\gamma` as a byproduct, which is why it lives here rather than in
:mod:`range_volatility`.

A property this shares with the range estimators
------------------------------------------------
Every quantity below is built from **ratios within or across adjacent bars**, so
a pure rescaling of prices cancels. Corwin-Schultz and Becker-Parkinson are
therefore **immune to split and dividend adjustment** and can be computed from
raw OHLC -- the same property ``range_volatility`` relies on, and for the same
reason. Amihud and Kyle use returns and so are **not** immune; they take an
adjusted close.

No new dependency: NumPy and pandas only.
"""

import numpy as np
import pandas as pd

_EPS = 1e-12

#: 3 - 2*sqrt(2), the constant in the Corwin-Schultz alpha.
_DEN = 3.0 - 2.0 * np.sqrt(2.0)

#: sqrt(8/pi), the constant in the Becker-Parkinson volatility.
_K2 = np.sqrt(8.0 / np.pi)


def _log_ratio(a, b):
    """log(a / b), NaN where either price is non-positive."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    out = np.full(a.shape, np.nan)
    ok = (a > 0) & (b > 0) & np.isfinite(a) & np.isfinite(b)
    out[ok] = np.log(a[ok] / b[ok])
    return out


def overnight_adjust(high, low, close):
    """
    Shift each bar's range to remove the overnight gap (Corwin & Schultz 2012).

    Why this is not optional
    ------------------------
    The estimator contrasts a **two-bar** range (gamma) against the sum of two
    **one-bar** ranges (beta). A gap between one close and the next bar sits
    inside the two-bar range and inside neither one-bar range, so it inflates
    gamma alone -- which pushes alpha down and the estimated spread with it.

    Measured on NSE daily bars, ``gamma/beta`` runs **1.08 to 2.62** against
    **1.015** for a gapless random walk of the same range. Without this
    correction Corwin-Schultz systematically **under-reads** on daily equity
    data, and every name tested here floored at a zero spread.

    AFML's Snippet 19.1 omits this step; the original paper (Corwin & Schultz
    2012, p. 727) specifies it. The paper's rule: when a bar lies entirely
    above the previous close, slide it down so its low meets that close; when
    entirely below, slide it up. The bar's own height -- which is what carries
    the spread -- is preserved either way.

    Parameters
    ----------
    high, low, close : array-like

    Returns
    -------
    (np.ndarray, np.ndarray)
        Gap-adjusted ``(high, low)``. The first bar is returned unchanged,
        having no previous close.
    """
    h = np.array(high, dtype=float, copy=True)
    l = np.array(low, dtype=float, copy=True)
    c = np.asarray(close, dtype=float)
    if len(h) < 2:
        return h, l
    prev = np.r_[np.nan, c[:-1]]

    gap_up = np.isfinite(prev) & (l > prev)
    h[gap_up] -= (l[gap_up] - prev[gap_up])
    l[gap_up] = prev[gap_up]

    gap_dn = np.isfinite(prev) & (h < prev)
    l[gap_dn] += (prev[gap_dn] - h[gap_dn])
    h[gap_dn] = prev[gap_dn]
    return h, l


# ==========================================
# 1. Corwin-Schultz spread
# ==========================================
def cs_beta(high, low, window=1):
    """
    The two-bar squared log-range sum, averaged over ``window`` bars.

    Parameters
    ----------
    high, low : array-like
    window : int, optional
        Bars to average beta over. AFML's ``sl``. 1 uses each pair on its own;
        larger values trade responsiveness for stability.

    Returns
    -------
    np.ndarray
    """
    hl = pd.Series(_log_ratio(high, low) ** 2)
    beta = hl.rolling(2).sum()
    if window and window > 1:
        beta = beta.rolling(int(window)).mean()
    return beta.to_numpy()


def cs_gamma(high, low):
    """
    The squared log-range measured **across two bars**.

    The contrast between this and :func:`cs_beta` is what separates spread from
    volatility: the volatility component grows with elapsed time, the spread
    component does not.

    Returns
    -------
    np.ndarray
    """
    h2 = pd.Series(np.asarray(high, dtype=float)).rolling(2).max()
    l2 = pd.Series(np.asarray(low, dtype=float)).rolling(2).min()
    return _log_ratio(h2.to_numpy(), l2.to_numpy()) ** 2


def corwin_schultz(df, window=1, floor_negative=True, gap_adjust=True):
    """
    Bid-ask spread as a fraction of price, from high and low only.

    Parameters
    ----------
    df : pd.DataFrame
        Needs ``high`` and ``low``. Raw (unadjusted) prices are fine -- the
        estimator is built from within-bar and adjacent-bar ratios, so
        corporate-action rescaling cancels.
    window : int, optional
        Averaging window for beta (AFML's ``sl``).
    floor_negative : bool, optional
        Floor negative alpha at zero, per Corwin & Schultz (2012, p. 727).
        Setting this ``False`` returns the raw (sometimes negative) estimate,
        which is useful for diagnosing how often the model breaks down.
    gap_adjust : bool, optional
        Apply :func:`overnight_adjust` first. On by default because daily
        equity bars gap, and an unadjusted gap inflates gamma alone and drives
        the estimate to zero. Pass ``False`` only to reproduce AFML's snippet
        verbatim.

    Returns
    -------
    (np.ndarray, dict)
        ``(spread, info)``. ``spread`` is a per-bar fraction of price -- multiply
        by 10,000 for basis points. ``info`` carries ``n_valid``, ``floor_rate``
        (share of valid bars where alpha was negative, i.e. the estimator
        failed), ``median`` and ``mean``.

    Raises
    ------
    ValueError
        If ``high``/``low`` are absent. Silently returning zeros would make a
        cost study read as free trading.
    """
    for c in ("high", "low"):
        if c not in df.columns:
            raise ValueError(f"corwin_schultz needs a {c!r} column")

    hi, lo = df["high"].values, df["low"].values
    if gap_adjust:
        if "close" not in df.columns:
            raise ValueError("gap_adjust=True needs a 'close' column; pass "
                             "gap_adjust=False to skip the overnight correction")
        hi, lo = overnight_adjust(hi, lo, df["close"].values)

    beta = cs_beta(hi, lo, window=window)
    gamma = cs_gamma(hi, lo)

    with np.errstate(invalid="ignore"):
        alpha = ((np.sqrt(2.0 * beta) - np.sqrt(beta)) / _DEN
                 - np.sqrt(np.maximum(gamma, 0.0) / _DEN))
    negative = np.isfinite(alpha) & (alpha < 0)
    if floor_negative:
        alpha = np.where(negative, 0.0, alpha)

    spread = 2.0 * (np.exp(alpha) - 1.0) / (1.0 + np.exp(alpha))
    valid = np.isfinite(spread)
    info = {
        "n_valid": int(valid.sum()),
        "floor_rate": (float(negative[valid].mean()) if valid.any()
                       else float("nan")),
        "median": float(np.nanmedian(spread)) if valid.any() else float("nan"),
        "mean": float(np.nanmean(spread)) if valid.any() else float("nan"),
    }
    return spread, info


def spread_null(sigma, n_bars=2000, steps=1000, seed=0, window=1):
    """
    The Corwin-Schultz estimate on a **zero-spread** series of matching
    volatility -- i.e. the estimator's own bias.

    Why this is needed
    ------------------
    Corwin-Schultz is biased upward, and the bias is **proportional to
    volatility**: the estimator attributes part of the price range to a spread
    that is not there. Measured on simulated driftless bars with a true spread
    of exactly zero:

    ========  ==================
    sigma     CS median reported
    ========  ==================
    0.5%      13.1 bp
    1.0%      26.1 bp
    2.0%      52.3 bp
    4.0%      104.5 bp
    ========  ==================

    -- a bias of ``0.26 * sigma`` across two orders of magnitude, while the
    slope against a *true* spread is ~0.93. So the estimator tracks real spread
    almost one-for-one and adds a volatility-sized offset on top.

    Quoting the raw figure as a transaction cost would therefore overstate
    costs, which for [Section 39] would make an existing negative conclusion
    look stronger than the evidence supports. Calibrating the null and
    subtracting it is the same permutation-null discipline
    ``feature_drift.psi_null`` already uses for PSI.

    The residual limitation, stated rather than hidden: the bias depends weakly
    on how finely the intraday path is sampled (0.22 * sigma at 200 steps,
    0.29 at 5000), because observed highs and lows understate the extremes of a
    continuous path. ``steps`` is therefore an assumption about trade frequency,
    and the correction is good to roughly +/-15%, not to the basis point.

    Parameters
    ----------
    sigma : float
        Daily volatility of the series being corrected, as a decimal.
    n_bars, steps : int, optional
        Simulated bars, and intraday steps per bar.
    seed : int, optional
    window : int, optional
        Must match the ``window`` used for the observed estimate.

    Returns
    -------
    dict
        ``{'null_median', 'null_mean', 'sigma', 'steps'}`` -- spreads as
        fractions of price.
    """
    if not np.isfinite(sigma) or sigma <= 0:
        return {"null_median": 0.0, "null_mean": 0.0, "sigma": sigma,
                "steps": steps}
    rng = np.random.default_rng(seed)
    z = rng.standard_normal((int(n_bars), int(steps))) * sigma / np.sqrt(steps)
    path = np.cumsum(z, axis=1)
    c, h, l = np.exp(path[:, -1]), np.exp(path.max(axis=1)), np.exp(path.min(axis=1))
    lvl = np.cumprod(np.r_[1.0, c])[:-1]
    sim = pd.DataFrame({"high": lvl * h, "low": lvl * l, "close": lvl * c})
    _, info = corwin_schultz(sim, window=window)
    return {"null_median": info["median"], "null_mean": info["mean"],
            "sigma": float(sigma), "steps": int(steps)}


def corwin_schultz_adjusted(df, window=1, steps=1000, seed=0):
    """
    Corwin-Schultz with its volatility-driven bias calibrated away.

    Estimates the series' own daily volatility from the high-low range
    (Parkinson), simulates the estimator's null at that volatility with a true
    spread of zero (:func:`spread_null`), and subtracts it.

    Returns
    -------
    dict
        ``raw_bp``, ``null_bp``, ``adjusted_bp`` (floored at zero),
        ``sigma_daily``, ``floor_rate``, ``n_valid``. Basis points throughout,
        because that is the unit a cost study argues in.
    """
    spread, info = corwin_schultz(df, window=window)
    # Volatility for the null must be measured on the SAME bars the estimator
    # saw -- gap-adjusted, intraday only -- because the simulated null has no
    # overnight gaps either. Using raw bars here would calibrate the null at a
    # volatility the estimator never observed.
    hi, lo = (overnight_adjust(df["high"].values, df["low"].values,
                               df["close"].values)
              if "close" in df.columns else (df["high"].values, df["low"].values))
    hl = _log_ratio(hi, lo)
    var = np.nanmean(hl ** 2) / (4.0 * np.log(2.0))      # Parkinson variance
    sigma = float(np.sqrt(var)) if np.isfinite(var) and var > 0 else float("nan")
    null = spread_null(sigma, steps=steps, seed=seed, window=window)
    raw = info["median"]
    adj = max(raw - null["null_median"], 0.0) if np.isfinite(raw) else float("nan")
    return {"raw_bp": 1e4 * raw, "null_bp": 1e4 * null["null_median"],
            "adjusted_bp": 1e4 * adj, "sigma_daily": sigma,
            "floor_rate": info["floor_rate"], "n_valid": info["n_valid"]}


def becker_parkinson_vol(df, window=1):
    """
    Becker-Parkinson volatility, a byproduct of the Corwin-Schultz decomposition.

    Shares beta and gamma with :func:`corwin_schultz`, which is why it lives
    here rather than beside the estimators in :mod:`range_volatility`. It is a
    *volatility* (standard-deviation) scale, not a variance.

    Returns
    -------
    np.ndarray
    """
    beta = cs_beta(df["high"].values, df["low"].values, window=window)
    gamma = cs_gamma(df["high"].values, df["low"].values)
    with np.errstate(invalid="ignore"):
        sigma = (2.0 ** -0.5 - 1.0) * np.sqrt(beta) / (_K2 * _DEN)
        sigma = sigma + np.sqrt(np.maximum(gamma, 0.0) / (_K2 ** 2 * _DEN))
    return np.where(np.isfinite(sigma) & (sigma > 0), sigma, np.nan)


# ==========================================
# 2. Roll (1984)
# ==========================================
def roll_spread(close, window=21):
    """
    Roll's (1984) effective spread from the serial covariance of price changes.

    Under Roll's model a bid-ask bounce induces **negative** first-order
    autocovariance in price changes, and ``S = 2*sqrt(-Cov)``. The model's
    well-known weakness is that the covariance is frequently **positive** in
    real data -- momentum and drift overwhelm the bounce -- in which case the
    spread is undefined. Those bars return NaN rather than zero, because zero
    would read as a free trade.

    Parameters
    ----------
    close : array-like
    window : int, optional
        Rolling window for the covariance.

    Returns
    -------
    (np.ndarray, dict)
        ``(spread, info)`` with ``info['undefined_rate']`` -- the share of
        windows where the covariance came out positive. On daily equity data
        this is typically large, which is the honest reason Corwin-Schultz is
        preferred.
    """
    c = pd.Series(np.asarray(close, dtype=float))
    dp = c.diff()
    cov = dp.rolling(int(window)).cov(dp.shift(1))
    ok = cov.notna()
    spread = np.where(cov < 0, 2.0 * np.sqrt(np.maximum(-cov, 0.0)), np.nan)
    # Express as a fraction of price so it is comparable with Corwin-Schultz.
    with np.errstate(invalid="ignore", divide="ignore"):
        spread = spread / c.to_numpy()
    info = {
        "n_valid": int(np.isfinite(spread).sum()),
        "undefined_rate": (float((cov[ok] >= 0).mean()) if ok.any()
                           else float("nan")),
    }
    return spread, info


# ==========================================
# 3. Illiquidity: Amihud and Kyle
# ==========================================
def amihud_lambda(df, window=21, price_col="adj_close"):
    """
    Amihud (2002) illiquidity: average ``|return| / rupee volume``.

    Interpreted as price impact per unit of traded value -- how far the price
    moves for a given amount of money. Unlike the spread estimators above this
    uses **returns**, so it needs a corporate-action-adjusted price; feeding it
    a raw close makes a split look like enormous impact.

    Returns
    -------
    np.ndarray
    """
    if price_col not in df.columns:
        raise ValueError(f"amihud_lambda needs a {price_col!r} column")
    p = pd.Series(np.asarray(df[price_col], dtype=float))
    r = np.abs(np.log(p / p.shift(1)))
    if "turnover" in df.columns:
        val = pd.Series(np.asarray(df["turnover"], dtype=float))
    else:
        val = p * pd.Series(np.asarray(df["volume"], dtype=float))
    ill = (r / val.replace(0.0, np.nan)).replace([np.inf, -np.inf], np.nan)
    return ill.rolling(int(window)).mean().to_numpy()


def kyle_lambda(df, window=21, price_col="adj_close"):
    """
    Kyle's (1985) lambda: price impact per unit of **signed** volume.

    True signed volume needs tick data. The standard daily proxy is the **tick
    rule** -- sign the bar by the direction of its close-to-close move -- and
    that is what is used here. It is a proxy, and a coarse one: a bar that
    closes up on balanced two-way flow is signed as a buy. Reported as such
    rather than presented as Kyle's lambda proper.

    Returns
    -------
    np.ndarray
    """
    p = pd.Series(np.asarray(df[price_col], dtype=float))
    dp = p.diff()
    sign = np.sign(dp).replace(0.0, np.nan).ffill().fillna(1.0)
    vol = pd.Series(np.asarray(df["volume"], dtype=float))
    signed = sign * vol
    num = dp.rolling(int(window)).cov(signed)
    den = signed.rolling(int(window)).var()
    with np.errstate(invalid="ignore", divide="ignore"):
        lam = num / den.replace(0.0, np.nan)
    return lam.to_numpy()


# ==========================================
# 4. Reporting
# ==========================================
def spread_summary(df, window=1):
    """
    Corwin-Schultz and Roll side by side for one OHLC frame.

    Returns
    -------
    dict
        Spreads in **basis points**, plus the diagnostics that say how far to
        trust each: Corwin-Schultz's ``cs_floor_rate`` and Roll's
        ``roll_undefined_rate``.
    """
    cs, cs_info = corwin_schultz(df, window=window)
    out = {
        "cs_median_bp": 1e4 * cs_info["median"],
        "cs_mean_bp": 1e4 * cs_info["mean"],
        "cs_floor_rate": cs_info["floor_rate"],
        "n_valid": cs_info["n_valid"],
    }
    if "close" in df.columns:
        rl, rl_info = roll_spread(df["close"].values)
        out["roll_median_bp"] = 1e4 * float(np.nanmedian(rl)) if rl_info[
            "n_valid"] else float("nan")
        out["roll_undefined_rate"] = rl_info["undefined_rate"]
    return out


def format_report(rows, title="Estimated bid-ask spreads (Corwin-Schultz)"):
    """Render a list of per-symbol :func:`spread_summary` dicts."""
    lines = [title, "=" * len(title),
             f"{'symbol':14s}{'CS median':>11s}{'CS mean':>10s}"
             f"{'floored':>9s}{'Roll med':>10s}{'bars':>8s}"]
    for r in rows:
        lines.append(
            f"{str(r.get('symbol', ''))[:13]:14s}"
            f"{r.get('cs_median_bp', float('nan')):10.1f}bp"
            f"{r.get('cs_mean_bp', float('nan')):9.1f}bp"
            f"{r.get('cs_floor_rate', float('nan')):9.3f}"
            f"{r.get('roll_median_bp', float('nan')):9.1f}bp"
            f"{int(r.get('n_valid', 0)):8d}")
    lines += [
        "",
        "'floored' is the share of bars where Corwin-Schultz produced a negative",
        "alpha and was clipped to zero -- the estimator breaking down, not a",
        "genuinely zero spread. A high rate means treat that name's figure as a",
        "lower bound.",
    ]
    return "\n".join(lines)
