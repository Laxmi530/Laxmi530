import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout
import os
import warnings

from model_utils import (
    normalize_interval,
    reset_keras_seeds,
    temporal_train_val_split,
    default_keras_callbacks,
    forecast_nn_direct,
)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


# ==========================================
# 1. Build & Train Model
# ==========================================
def train_dl_model(X, y, model_type='LSTM', output_dim=1):
    """
    Build and train a 3-layer stacked LSTM or GRU model.

    Architecture: three recurrent layers (64, 64, 32 units) with
    output dropout (0.3, 0.3, 0.2) and recurrent dropout (0.1) for
    hidden-to-hidden regularisation, followed by a Dense bottleneck
    (16 units, ReLU) and an ``output_dim``-wide linear output. Trained
    with Huber loss, Adam optimiser with gradient clipping, learning-rate
    scheduling, and early stopping on a temporal validation set (last 10%).

    Parameters
    ----------
    X : np.ndarray
        Input sequences of shape (n_samples, look_back, n_features).
    y : np.ndarray
        Targets of shape (n_samples,) or (n_samples, output_dim) — the
        per-horizon cumulative log returns for direct multi-horizon output.
    model_type : str, optional
        'LSTM' or 'GRU' (default: 'LSTM').
    output_dim : int, optional
        Number of outputs (= forecast horizon for direct multi-horizon).
        Default 1.

    Returns
    -------
    tf.keras.Model
        Trained Keras model.
    """
    reset_keras_seeds()

    n_features = X.shape[2]
    look_back = X.shape[1]

    X_train, X_val, y_train, y_val = temporal_train_val_split(X, y)

    model = Sequential()

    # Layer sizes come from architectures.SPECS rather than literals here, so the
    # network is a declared, JSON-overridable object that the run manifest can
    # record. The defaults reproduce the previous hardcoded stack exactly
    # (64/64/32 recurrent, 0.3/0.3/0.2 dropout, Dense(16)) — see
    # tests/test_architectures.py, which pins that equivalence.
    import architectures as arch
    sp = arch.spec('DL')
    units = list(sp.get('recurrent_units', [64, 64, 32]))
    drops = list(sp.get('dropout', [0.3, 0.3, 0.2]))
    rec_drop = float(sp.get('recurrent_dropout', 0.1))

    print(f"Building {model_type} model ({look_back} steps x {n_features} "
          f"features, units={units})...")

    layer = LSTM if model_type == 'LSTM' else GRU

    for i, n_units in enumerate(units):
        is_last = (i == len(units) - 1)
        kwargs = dict(return_sequences=not is_last, recurrent_dropout=rec_drop)
        if i == 0:
            kwargs['input_shape'] = (look_back, n_features)
        model.add(layer(n_units, **kwargs))
        # A dropout list shorter than the unit list simply stops applying
        # dropout, rather than raising: an over-ridden spec should degrade
        # predictably, not crash a forecast.
        if i < len(drops):
            model.add(Dropout(drops[i]))

    model.add(Dense(int(sp.get('dense_units', 16)),
                    activation=sp.get('dense_activation', 'relu')))
    model.add(Dense(output_dim))

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3, clipnorm=1.0),
        loss='huber',
    )

    print("Training Model...")
    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        batch_size=32,
        epochs=100,
        callbacks=default_keras_callbacks(),
        shuffle=True,
        verbose=0,
    )

    return model


# ==========================================
# 2. Main Orchestrator
# ==========================================
def run_DL_prediction(df: pd.DataFrame, interval: str, horizon: int,
                      model_type='LSTM'):
    """
    Main function to run LSTM or GRU prediction.

    Orchestrates data preparation (9-feature engineering with RSI,
    momentum, dual-window volatility, z-score, and acceleration),
    model training with recurrent dropout and temporal validation,
    and direct multi-horizon forecasting (one output per step, no
    recursive feedback) with distribution-free conformal prediction
    intervals. Training data is limited to recent observations to
    focus on the current market regime.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.
    model_type : str, optional
        'LSTM' (default) or 'GRU'.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting {model_type} Prediction ({interval}) ---")

    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])

    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.tail(max_obs).reset_index(drop=True)

    look_back = 90 if interval == 'daily' else 48

    results_df = forecast_nn_direct(
        df, interval, horizon, look_back,
        build_train_fn=lambda X, Y, od: train_dl_model(X, Y, model_type, output_dim=od),
        model_name='DL',
    )

    print(f"{model_type} Prediction Complete.")
    return results_df
