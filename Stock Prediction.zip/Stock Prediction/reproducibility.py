"""
Reproducibility helpers: pin every RNG and record an auditable run manifest.

A reviewer's point: pinning seeds and capturing a per-run manifest does not make
markets predictable — it makes your *experiments auditable*. Two pieces:

* ``set_all_seeds`` — seeds Python's ``random``, NumPy, TensorFlow and (if
  present) PyTorch from one call, so a model run is reproducible given the seed.
  The NN path already seeded TF/NumPy via ``model_utils.reset_keras_seeds``; this
  centralises it and adds the two that were missing (``random`` and torch).
* ``run_manifest`` — a plain dict recording the seed, interpreter and key
  package versions, the run parameters, and a timestamp, so any forecast can be
  reproduced and traced. Pure (no Streamlit); the timestamp is injectable.
"""

import os
import platform
import random
import re

import numpy as np

GLOBAL_SEED = 42

# Packages whose versions are worth recording in the manifest.
_TRACKED_PACKAGES = (
    "numpy", "pandas", "scikit-learn", "xgboost", "lightgbm", "statsmodels",
    "arch", "pmdarima", "tensorflow", "prophet", "yfinance", "streamlit",
    "pandas_market_calendars",
)


def set_all_seeds(seed=GLOBAL_SEED):
    """
    Seed every RNG we might touch: ``random``, NumPy, TensorFlow, PyTorch.

    TensorFlow and PyTorch are seeded only if importable (both are optional at
    call time), and their import errors are swallowed so this never breaks a run
    on a machine without them. Returns the seed actually applied.
    """
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except Exception:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass
    return seed


def _package_versions():
    """Best-effort {package: version} for the tracked libraries (missing -> skip)."""
    try:
        from importlib import metadata
    except Exception:                                  # pragma: no cover
        return {}
    out = {}
    for pkg in _TRACKED_PACKAGES:
        try:
            out[pkg] = metadata.version(pkg)
        except Exception:
            pass
    return out


#: Distribution names where the import name and the PyPI name differ.
_DIST_ALIASES = {
    "scikit-learn": "scikit-learn",
    "pandas_market_calendars": "pandas-market-calendars",
}


def read_pins(path=None):
    """
    Parse ``requirements.txt`` into ``{package: pinned_version}``.

    Only exact ``==`` pins are returned; ranges and comments are skipped,
    because a range cannot drift in the sense :func:`check_pins` cares about.

    Parameters
    ----------
    path : str, optional
        Defaults to ``requirements.txt`` beside this module.

    Returns
    -------
    dict
    """
    if path is None:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "requirements.txt")
    pins = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                m = re.match(r"^([A-Za-z0-9_.\-]+)==([^\s;#]+)$", line)
                if m:
                    pins[m.group(1)] = m.group(2)
    except Exception:
        return {}
    return pins


def check_pins(path=None):
    """
    Compare installed versions against the ``requirements.txt`` pins.

    Why this exists
    ---------------
    This module already *recorded* package versions in every manifest, and that
    turned out to be only half a reproducibility guarantee: it was **write-only**.
    A manifest would faithfully record ``scikit-learn 1.9.0`` while the pin file
    said ``1.8.0``, and nothing anywhere compared the two.

    The consequence was not hypothetical. The environment drifted to numpy
    1.26.4 against a pin of 2.4.6, and because scipy >= 1.14 is built against
    numpy 2.x, **eight libraries stopped importing** -- scipy, sklearn,
    statsmodels, arch, pmdarima, lightgbm, xgboost. Some failures were loud;
    ``fracdiff.adf_pvalue`` swallowed its exception and returned NaN, so the
    stationarity tests silently reported nothing at all.

    Recording state is not the same as checking it. This closes that gap.

    Returns
    -------
    dict
        ``{'drift': {pkg: {'pinned', 'installed'}}, 'missing': [...],
        'checked': int, 'clean': bool}``. ``drift`` covers packages installed at
        a version other than the pin; ``missing`` covers pinned packages that
        are not installed at all.
    """
    pins = read_pins(path)
    try:
        from importlib import metadata
    except Exception:                                  # pragma: no cover
        return {"drift": {}, "missing": [], "checked": 0, "clean": True}

    drift, missing = {}, []
    for pkg, pinned in pins.items():
        try:
            got = metadata.version(_DIST_ALIASES.get(pkg, pkg))
        except Exception:
            missing.append(pkg)
            continue
        if got != pinned:
            drift[pkg] = {"pinned": pinned, "installed": got}
    return {"drift": drift, "missing": missing, "checked": len(pins),
            "clean": not drift and not missing}


def format_pin_report(report):
    """Render :func:`check_pins` output for a console or a log."""
    if report.get("clean"):
        return (f"environment matches all {report.get('checked', 0)} pins")
    lines = [f"ENVIRONMENT DRIFT: {len(report['drift'])} of "
             f"{report['checked']} pinned packages differ"]
    for pkg, d in sorted(report["drift"].items()):
        lines.append(f"  {pkg:24s} pinned {d['pinned']:10s} "
                     f"installed {d['installed']}")
    for pkg in report.get("missing", []):
        lines.append(f"  {pkg:24s} PINNED BUT NOT INSTALLED")
    lines.append("  Published figures are only reproducible on the pinned set.")
    return "\n".join(lines)


def run_manifest(ticker=None, interval=None, horizon=None, seed=GLOBAL_SEED,
                 fetched_at=None, now=None, **extra):
    """
    Build an auditable manifest dict for a single forecast/backtest run.

    Parameters
    ----------
    ticker, interval, horizon : optional
        The run's request parameters.
    seed : int
        The seed applied via :func:`set_all_seeds`.
    fetched_at : str/Timestamp, optional
        When the underlying data was fetched (from the data layer's audit tag).
    now : Timestamp, optional
        Reference "now" (defaults to ``pd.Timestamp.now('UTC')``); injectable for
        tests so the manifest is deterministic.
    **extra
        Any additional fields to record (e.g. training_rows, feature_config).

    Returns
    -------
    dict
        Seed, interpreter + package versions, params, timestamps, and extras.
    """
    import pandas as pd
    ts = pd.Timestamp.now("UTC") if now is None else pd.Timestamp(now)
    manifest = {
        "seed": int(seed),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": _package_versions(),
        # Recording versions is only half a guarantee -- the manifest was
        # write-only until this line. `pin_drift` is None when the environment
        # matches requirements.txt, and a {pkg: {pinned, installed}} map when it
        # does not, so a run on a drifted stack says so in its own audit record.
        "pin_drift": (lambda r: r["drift"] or None)(check_pins()),
        "ticker": ticker,
        "interval": interval,
        "horizon": horizon,
        "fetched_at": str(fetched_at) if fetched_at is not None else None,
        "run_at_utc": ts.isoformat(),
    }
    manifest.update(extra)
    return manifest
