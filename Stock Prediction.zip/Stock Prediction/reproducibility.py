"""
Reproducibility helpers: pin every RNG and record an auditable run manifest.

A reviewer's point: pinning seeds and capturing a per-run manifest does not make
markets predictable — it makes your *experiments auditable*. Two pieces:

* ``set_all_seeds`` — seeds Python's ``random``, NumPy, TensorFlow and (if
  present) PyTorch from one call, so a model run is reproducible given the seed.
  The NN path already seeded TF/NumPy via ``model_utils.reset_keras_seeds``; this
  centralises it and adds the two that were missing (``random`` and torch).
* ``run_manifest`` — a plain dict recording the seed, interpreter and key
  package versions, the run parameters, and a timestamp, so any forecast can be
  reproduced and traced. Pure (no Streamlit); the timestamp is injectable.
"""

import platform
import random

import numpy as np

GLOBAL_SEED = 42

# Packages whose versions are worth recording in the manifest.
_TRACKED_PACKAGES = (
    "numpy", "pandas", "scikit-learn", "xgboost", "lightgbm", "statsmodels",
    "arch", "pmdarima", "tensorflow", "prophet", "yfinance", "streamlit",
    "pandas_market_calendars",
)


def set_all_seeds(seed=GLOBAL_SEED):
    """
    Seed every RNG we might touch: ``random``, NumPy, TensorFlow, PyTorch.

    TensorFlow and PyTorch are seeded only if importable (both are optional at
    call time), and their import errors are swallowed so this never breaks a run
    on a machine without them. Returns the seed actually applied.
    """
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except Exception:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass
    return seed


def _package_versions():
    """Best-effort {package: version} for the tracked libraries (missing -> skip)."""
    try:
        from importlib import metadata
    except Exception:                                  # pragma: no cover
        return {}
    out = {}
    for pkg in _TRACKED_PACKAGES:
        try:
            out[pkg] = metadata.version(pkg)
        except Exception:
            pass
    return out


def run_manifest(ticker=None, interval=None, horizon=None, seed=GLOBAL_SEED,
                 fetched_at=None, now=None, **extra):
    """
    Build an auditable manifest dict for a single forecast/backtest run.

    Parameters
    ----------
    ticker, interval, horizon : optional
        The run's request parameters.
    seed : int
        The seed applied via :func:`set_all_seeds`.
    fetched_at : str/Timestamp, optional
        When the underlying data was fetched (from the data layer's audit tag).
    now : Timestamp, optional
        Reference "now" (defaults to ``pd.Timestamp.now('UTC')``); injectable for
        tests so the manifest is deterministic.
    **extra
        Any additional fields to record (e.g. training_rows, feature_config).

    Returns
    -------
    dict
        Seed, interpreter + package versions, params, timestamps, and extras.
    """
    import pandas as pd
    ts = pd.Timestamp.now("UTC") if now is None else pd.Timestamp(now)
    manifest = {
        "seed": int(seed),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": _package_versions(),
        "ticker": ticker,
        "interval": interval,
        "horizon": horizon,
        "fetched_at": str(fetched_at) if fetched_at is not None else None,
        "run_at_utc": ts.isoformat(),
    }
    manifest.update(extra)
    return manifest
