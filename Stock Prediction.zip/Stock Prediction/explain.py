"""
Which inputs led to which prediction? Exact TreeSHAP, no new dependency.

The gap this fills
------------------
Twenty models, and until now no way to answer Klaas Ch. 8's question: *"Why did
your model make the prediction it made?"* The project could say **whether** a
model beat a random walk and **how uncertain** it was, but nothing about what
drove any individual number.

That matters here for a specific reason beyond curiosity. This project's central
claim is that most apparent edge is noise. An attribution layer is the cheapest
way to *check* that claim from the inside: if a model's forecasts are driven by
a feature that has no economic reading, or if attribution is spread thinly and
inconsistently across forty features, that is corroboration from a new
direction. Concentrated, stable attribution on economically sensible features
would be the opposite — and would deserve a closer look.

Why not LIME (the book's choice)
---------------------------------
Klaas Ch. 8 uses LIME, which is model-agnostic and therefore **approximate**: it
fits a local surrogate linear model to perturbed samples. For tree ensembles
there is something strictly better — **TreeSHAP** gives *exact* Shapley values
in polynomial time, and both LightGBM and XGBoost implement it natively
(``pred_contrib`` / ``pred_contribs``). So this module needs **no new
dependency**: not the ``shap`` package, not ``lime``.

Exactness matters more than it usually would. A surrogate's disagreement with
the model is indistinguishable from a genuine attribution, so an approximate
explainer applied to a near-noise model produces confident-looking nonsense.

What the numbers mean
---------------------
A SHAP value is the contribution of one feature to *this* prediction, measured
against the model's base value, in the units of the model's output. They sum
exactly: ``base_value + sum(shap_values) == prediction``. That identity is
checked, not assumed — :func:`explain_prediction` reports the reconstruction
error, and a non-trivial one means the values are being misread.
"""

import numpy as np
import pandas as pd

_EPS = 1e-9


def _booster_kind(model):
    """Identify a tree model this module can explain exactly."""
    name = type(model).__name__
    mod = type(model).__module__ or ""
    if "lightgbm" in mod or name.startswith("LGBM"):
        return "lightgbm"
    if "xgboost" in mod or name.startswith("XGB"):
        return "xgboost"
    return None


def supports(model):
    """Whether exact TreeSHAP is available for this model."""
    return _booster_kind(model) is not None


def shap_values(model, X):
    """
    Exact TreeSHAP contributions for every row of ``X``.

    Returns
    -------
    (values, base) : ndarray of shape (n_rows, n_features), float
        Or ``(None, None)`` when the model is not a supported tree ensemble.
        Returning None rather than falling back to a permutation approximation
        is deliberate: an approximate explanation presented in the same shape as
        an exact one is a trap, and this project would rather report "not
        available" than a number whose error is unknown.
    """
    kind = _booster_kind(model)
    if kind is None:
        return None, None

    X = X if isinstance(X, pd.DataFrame) else pd.DataFrame(X)
    try:
        if kind == "lightgbm":
            raw = np.asarray(model.predict(X, pred_contrib=True), dtype=float)
        else:
            import xgboost as xgb
            booster = getattr(model, "get_booster", lambda: model)()
            raw = np.asarray(
                booster.predict(xgb.DMatrix(X), pred_contribs=True), dtype=float)
    except Exception:
        return None, None

    # Both libraries append the base value as a final column. Multiclass models
    # return one block per class; this module reports the mean absolute
    # contribution across classes, since "which feature mattered" is a
    # class-agnostic question for a ranking use.
    n_feat = X.shape[1]
    if raw.ndim == 2 and raw.shape[1] == n_feat + 1:
        return raw[:, :n_feat], raw[:, n_feat]
    if raw.ndim == 2 and raw.shape[1] % (n_feat + 1) == 0:
        n_class = raw.shape[1] // (n_feat + 1)
        blocks = raw.reshape(raw.shape[0], n_class, n_feat + 1)
        return np.abs(blocks[:, :, :n_feat]).mean(axis=1), blocks[:, :, n_feat].mean(axis=1)
    if raw.ndim == 3 and raw.shape[2] == n_feat + 1:
        return np.abs(raw[:, :, :n_feat]).mean(axis=1), raw[:, :, n_feat].mean(axis=1)
    return None, None


def importance(model, X, feature_names=None, top=None):
    """
    Global feature importance as mean |SHAP| across rows.

    Preferred over a tree's built-in ``feature_importances_`` (split counts or
    gain), which is biased towards high-cardinality features and says nothing
    about the *direction* or size of the effect on the output scale.

    Returns
    -------
    pandas.DataFrame
        ``feature``, ``mean_abs_shap``, ``share`` (fraction of total attribution)
        and ``cumulative_share``, sorted descending. Empty if unsupported.
    """
    values, _ = shap_values(model, X)
    if values is None:
        return pd.DataFrame(columns=["feature", "mean_abs_shap", "share",
                                     "cumulative_share"])
    names = list(feature_names) if feature_names is not None else (
        list(X.columns) if isinstance(X, pd.DataFrame)
        else [f"f{i}" for i in range(values.shape[1])])

    mean_abs = np.abs(values).mean(axis=0)
    total = float(mean_abs.sum())
    out = pd.DataFrame({"feature": names, "mean_abs_shap": mean_abs})
    out["share"] = out["mean_abs_shap"] / total if total > _EPS else np.nan
    out = out.sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)
    out["cumulative_share"] = out["share"].cumsum()
    return out.head(top) if top else out


def explain_prediction(model, X, row=-1, feature_names=None, top=8):
    """
    Attribution for a single forecast, with the additivity identity checked.

    ``base_value + sum(shap) == prediction`` holds exactly for TreeSHAP. It is
    verified here rather than trusted, because a silent shape mismatch between
    the library's output layout and this module's parsing would otherwise
    produce plausible-looking attributions that do not correspond to the model.
    """
    values, base = shap_values(model, X)
    if values is None:
        return {"available": False, "note": "model is not a supported tree ensemble"}

    X = X if isinstance(X, pd.DataFrame) else pd.DataFrame(X)
    names = list(feature_names) if feature_names is not None else list(X.columns)
    v = values[row]
    b = float(base[row])

    try:
        pred = float(np.asarray(model.predict(X.iloc[[row]]))[0])
    except Exception:
        pred = float("nan")
    recon = b + float(v.sum())
    err = abs(recon - pred) if np.isfinite(pred) else float("nan")

    order = np.argsort(-np.abs(v))[:top]
    contributions = [{"feature": names[i], "value": float(X.iloc[row, i]),
                      "shap": float(v[i])} for i in order]
    return {
        "available": True,
        "base_value": b,
        "prediction": pred,
        "reconstruction": recon,
        "additivity_error": err,
        "additivity_ok": bool(np.isfinite(err) and err < 1e-4),
        "contributions": contributions,
    }


def concentration(imp):
    """
    How concentrated is the attribution?

    Reports the number of features covering 50% and 90% of total attribution,
    plus a normalised Herfindahl index. This is the number that speaks to the
    project's thesis: a model driven by a handful of features is making a
    structured claim, while attribution spread thinly across dozens is closer to
    what fitting noise looks like.
    """
    if imp is None or imp.empty:
        return {"n_features": 0}
    share = imp["share"].fillna(0.0).values
    cum = np.cumsum(share)
    n = len(share)
    hhi = float(np.sum(share ** 2))
    return {
        "n_features": int(n),
        "n_for_50pct": int(np.searchsorted(cum, 0.50) + 1),
        "n_for_90pct": int(np.searchsorted(cum, 0.90) + 1),
        "top_feature": str(imp.iloc[0]["feature"]),
        "top_share": float(share[0]),
        # 1/n = perfectly uniform, 1 = one feature explains everything.
        "herfindahl": round(hhi, 4),
        "uniform_herfindahl": round(1.0 / n, 4) if n else float("nan"),
    }


def format_report(imp, conc, title="Feature attribution (exact TreeSHAP)"):
    """Plain-text report for the validation drivers."""
    if imp is None or imp.empty:
        return f"=== {title} ===\n  not available (model is not a tree ensemble)"
    lines = [f"=== {title} ===",
             f"  Features            : {conc['n_features']}",
             f"  Top feature         : {conc['top_feature']} "
             f"({conc['top_share']:.1%} of attribution)",
             f"  Features for 50%    : {conc['n_for_50pct']}",
             f"  Features for 90%    : {conc['n_for_90pct']}",
             f"  Herfindahl          : {conc['herfindahl']} "
             f"(uniform would be {conc['uniform_herfindahl']})",
             "",
             "  rank  feature                        mean|SHAP|    share"]
    for i, r in imp.head(12).iterrows():
        lines.append(f"  {i+1:>4}  {str(r['feature'])[:28]:<28} "
                     f"{r['mean_abs_shap']:>11.6f} {r['share']:>8.1%}")
    return "\n".join(lines)
