import yfinance as yf
import pandas as pd
import requests
from nselib import capital_market
from datetime import datetime

# Console output goes through console._write, which degrades on a legacy
# Windows code page instead of raising. The status messages below contain
# emoji, and an unguarded print of them raised UnicodeEncodeError inside
# the currency-conversion try/except - turning a cosmetic line into a
# caught 'Error processing data' that masked what actually happened.
from console import _write as _cprint

def get_ticker_from_company_name(company_name: str) -> str | None:
    """
    Search for a stock ticker, prioritizing Indian exchanges (NSE/BSE) to ensure INR pricing.

    Parameters
    ----------
    company_name : str
        The full or partial name of the company to search for.

    Returns
    -------
    str or None
        The best matching ticker symbol, or None if no symbol is found.
    """
    try:
        search_results = yf.Search(company_name)
        if not search_results.quotes:
            return None

        # 1. Try to find an NSE (.NS) or BSE (.BO) match first
        for quote in search_results.quotes:
            symbol = quote.get("symbol", "")
            if symbol.endswith(".NS") or symbol.endswith(".BO"):
                return symbol

        # 2. If no Indian match is found, return the best global match (likely USD/EUR)
        return search_results.quotes[0].get("symbol")

    except Exception as e:
        print(f"An error occurred during search: {e}")
        return None

def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """
    Strip and normalize whitespace in DataFrame column names.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame whose column names are to be cleaned.

    Returns
    -------
    pd.DataFrame
        DataFrame with cleaned column names (in-place modification also applied).
    """
    df.columns = (df.columns.str.strip().str.replace(r'\s+', ' ', regex=True))
    return df

def get_bse_nse_data():
    """
    Fetch and merge NSE and BSE equity listings into a single DataFrame.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['NAME OF COMPANY', 'SYMBOL'] containing merged
        active equity listings from both exchanges.
    """
    nse_url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
    nse_df = pd.read_csv(nse_url)
    nse_df = clean_column_names(nse_df)
    nse_df_final = nse_df[["NAME OF COMPANY", "SYMBOL"]]
    # nse_df_final.head()
    bse_url = (
    "https://api.bseindia.com/BseIndiaAPI/api/ListofScripData/w"
    "?Group=&Scripcode=&industry=&segment=Equity&status=Active"
    )

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
        "Referer": "https://www.bseindia.com/",
        "Origin": "https://www.bseindia.com"
    }

    response = requests.get(bse_url, headers=headers, timeout=30)
    response.raise_for_status()
    data = response.json()
    bse_df = pd.DataFrame(data)
    bse_df = clean_column_names(bse_df)
    bse_df_final = bse_df.loc[bse_df["Status"].str.lower() == "active", ["Issuer_Name", "scrip_id"]].reset_index(drop=True)
    bse_df_final = bse_df_final.rename(columns={"Issuer_Name":"NAME OF COMPANY","scrip_id":"SYMBOL"})
    bse_nse_df = pd.concat([nse_df_final, bse_df_final]).drop_duplicates().reset_index(drop=True)
    bse_nse_df = bse_nse_df.drop_duplicates(subset=['SYMBOL'])
    bse_nse_df = bse_nse_df.sort_values(by='NAME OF COMPANY').reset_index(drop=True)
    return bse_nse_df

def company_list():
    """
    Return a list of all company names from BSE and NSE equity listings.

    Returns
    -------
    list of str
        Sorted list of company names available in the merged BSE/NSE data.
    """
    list_of_company = get_bse_nse_data()["NAME OF COMPANY"].to_list()
    return list_of_company

def get_ticker(company_name):
    """
    Look up the ticker symbol for a company name from BSE/NSE data.

    Parameters
    ----------
    company_name : str
        Exact company name as it appears in the BSE/NSE listings.

    Returns
    -------
    str or None
        The ticker symbol for the company, or None if not found.
    """
    df = get_bse_nse_data()
    company_to_symbol = dict(zip(df['NAME OF COMPANY'], df['SYMBOL']))
    symbol = company_to_symbol.get(company_name)
    return symbol

def _clean_stock_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean and normalize a stock price DataFrame for consistent downstream use.

    Resets index, normalizes column names to lowercase with underscores,
    renames 'date' to 'datetime', removes timezone info, and drops dividend/split columns.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock price DataFrame (typically from yfinance or similar).

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame with standardized column names and no timezone info.
    """
    df = df.reset_index()
    df.columns = [c.lower().replace(" ", "_") for c in df.columns]
    if "date" in df.columns:
        df = df.rename(columns={"date": "datetime"})
    df["datetime"] = pd.to_datetime(df["datetime"]).dt.tz_localize(None)
    drop_cols = [c for c in ["dividends", "stock_splits"] if c in df.columns]
    df = df.drop(columns=drop_cols)
    return df

def get_exchange_rate_to_inr(source_currency: str) -> float:
    """
    Returns the current exchange rate from source_currency to INR.
    Source: https://open.er-api.com/v6/latest/{currency} (no API key needed)

    Parameters
    ----------
    source_currency : str
        Currency code (e.g., 'USD', 'EUR', 'GBP')

    Returns
    -------
    float
        1 unit of source_currency in INR.
    """
    url = f"https://open.er-api.com/v6/latest/{source_currency.upper()}"

    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        data = r.json()

        if data.get("result") != "success":
            raise RuntimeError(f"API did not return success: {data}")

        rate = data["rates"]["INR"]
        _cprint(f"⚠️ Using fallback API rate: 1 {source_currency} = {rate} INR")
        return float(rate)

    except (requests.RequestException, KeyError, ValueError) as e:
        raise RuntimeError(f"Failed to fetch {source_currency}->INR rate: {e}") from e

def _convert_to_inr(df: pd.DataFrame, source_currency: str) -> pd.DataFrame:
    """
    Convert all price columns from source_currency to INR using historical exchange rates.

    Uses yfinance for historical forex data; falls back to live API rate if unavailable.

    Parameters
    ----------
    df : pd.DataFrame
        Stock DataFrame with price columns (open, high, low, close, adj_close).
    source_currency : str
        Currency code of the source prices (e.g., 'USD', 'EUR').

    Returns
    -------
    pd.DataFrame
        DataFrame with all price columns converted to INR.
    """

    forex_ticker = f"{source_currency}INR=X"
    print(f"Fetching historical exchange rate: {forex_ticker}")

    price_cols = ["open", "high", "low", "close", "adj_close"]

    try:
        # Fetch exchange rate for the date range of the stock data
        start_date = df["datetime"].min() - pd.Timedelta(days=5)  # buffer for holidays
        end_date = df["datetime"].max() + pd.Timedelta(days=1)

        forex = yf.Ticker(forex_ticker)
        forex_df = forex.history(start=start_date, end=end_date, interval="1d", auto_adjust=False)

        if forex_df.empty:
            raise ValueError(f"No historical forex data for {forex_ticker}")

        # Clean forex data
        forex_df = forex_df.reset_index()
        forex_df.columns = [c.lower().replace(" ", "_") for c in forex_df.columns]

        if "date" in forex_df.columns:
            forex_df = forex_df.rename(columns={"date": "datetime"})

        forex_df["datetime"] = pd.to_datetime(forex_df["datetime"]).dt.tz_localize(None)
        forex_df["datetime"] = forex_df["datetime"].dt.normalize()
        forex_df = forex_df[["datetime", "close"]].rename(columns={"close": "fx_rate"})
        forex_df = forex_df.drop_duplicates(subset="datetime", keep="last")

        # Merge exchange rate with stock data on date
        df["_date_key"] = df["datetime"].dt.normalize()
        df = df.merge(forex_df, left_on="_date_key", right_on="datetime", how="left", suffixes=("", "_fx"))

        # Forward-fill & back-fill missing rates (weekends/holidays)
        df["fx_rate"] = df["fx_rate"].ffill().bfill()

        # ✅ If still any NaN (very old dates), use live API fallback for
        # those rows only. Record how many rows used the live rate so the UI
        # can be honest about it (these specific dates are converted at today's
        # rate, not their own).
        n_filled_live = int(df["fx_rate"].isna().sum())
        if n_filled_live:
            fallback_rate = get_exchange_rate_to_inr(source_currency)
            df["fx_rate"] = df["fx_rate"].fillna(fallback_rate)

        latest_rate = float(df["fx_rate"].iloc[-1]) if len(df) else float("nan")

        # Multiply price columns by exchange rate
        for col in price_cols:
            if col in df.columns:
                df[col] = (df[col] * df["fx_rate"]).round(2)

        # Clean up temporary columns
        df = df.drop(columns=["_date_key", "fx_rate", "datetime_fx"], errors="ignore")

        # Audit tag: which conversion path produced these prices (see UI caption).
        df.attrs["fx_conversion"] = {
            "method": "historical",
            "source_currency": source_currency,
            "rows_filled_live": n_filled_live,
            "latest_rate": round(latest_rate, 4),
            "status": "ok" if n_filled_live == 0 else "ok_with_gaps",
        }
        _cprint(f"✅ Successfully converted {source_currency} → INR (historical rates)")
        return df

    except Exception as e:
        # ✅ Fallback: Use live API rate for ALL rows
        print(f"Historical forex failed: {e}")
        _cprint(f"Falling back to live API rate for {source_currency} → INR...")

        try:
            fallback_rate = get_exchange_rate_to_inr(source_currency)
            for col in price_cols:
                if col in df.columns:
                    df[col] = (df[col] * fallback_rate).round(2)

            # Clean up any leftover temp columns from failed merge
            df = df.drop(columns=["_date_key", "fx_rate", "datetime_fx"], errors="ignore")

            # Degraded path: the WHOLE history is rescaled by today's rate, so
            # historical levels are distorted (returns are preserved, but prices
            # are not period-accurate). The UI surfaces this prominently.
            df.attrs["fx_conversion"] = {
                "method": "live_uniform",
                "source_currency": source_currency,
                "rate": round(float(fallback_rate), 4),
                "status": "degraded",
            }
            _cprint(f"✅ Converted {source_currency} → INR using live rate: {fallback_rate}")
            return df

        except RuntimeError as api_error:
            _cprint(f"❌ Both historical and API fallback failed: {api_error}")
            _cprint("⚠️ Returning prices in original currency without conversion.")
            # Clean up any leftover temp columns
            df = df.drop(columns=["_date_key", "fx_rate", "datetime_fx"], errors="ignore")
            df.attrs["fx_conversion"] = {
                "method": "unconverted",
                "source_currency": source_currency,
                "status": "failed",
            }
            return df

def get_stock_data_using_yfinance(company_name: str, interval: str = "1d"):
    """
    Fetch stock data (Daily or Hourly) and return as a dataframe in INR.
    Auto-detects if prices are in a foreign currency and converts to INR.

    Parameters
    ----------
    company_name : str
        The full or partial name of the company (e.g., 'Apple' or 'Microsoft').
    interval : str, optional
        '1d' (default) or '1h'

    Returns
    -------
    pd.DataFrame or str
        DataFrame with prices in INR, or an error string if no data is found.
    """

    if interval not in ["1d", "1h"]:
        print(f"Invalid interval: {interval}")
        return []

    period = "730d" if interval == "1h" else "max"

    ticker_strategies = [(get_ticker, "Local Lookup"), (get_ticker_from_company_name, "API Search")]

    df_result = pd.DataFrame()
    found_ticker = None
    stock_currency = None

    for strategy_func, strategy_name in ticker_strategies:
        try:
            candidate_ticker = strategy_func(company_name)

            if not candidate_ticker:
                continue

            ticker_obj = yf.Ticker(candidate_ticker)
            # auto_adjust=False keeps a separate raw 'Close' and back-adjusted
            # 'Adj Close'. The whole pipeline models LOG RETURNS off 'adj_close'
            # (the total-return series) on purpose: raw close would inject fake
            # ~2-3% jumps at every ex-dividend/split date as if they were real
            # returns, corrupting volatility/RSI. Using the adjusted series is the
            # correct choice for return modeling. The only residual look-ahead is
            # that, in a *backtest*, a past origin's adjusted history embeds the
            # size of corporate actions that occur after it -- but that touches
            # only the handful of action bars (~0.4-1.6% of bars) and cancels in
            # every scale-invariant comparison (DM/SPA/MASE). Live serving has no
            # leak (latest bar's adjustment factor is 1.0). Quantified in
            # tests/audit_price_adjustment.py; see README "Caveats and limitations".
            temp_df = ticker_obj.history(period=period, interval=interval, auto_adjust=False)

            if not temp_df.empty:
                df_result = temp_df
                found_ticker = candidate_ticker

                # Detect the currency of the stock
                try:
                    stock_currency = ticker_obj.info.get("currency", None)
                    print(f"Stock '{found_ticker}' listed currency: {stock_currency}")
                except Exception:
                    stock_currency = None

                break

        except Exception as e:
            print(f"Error trying {strategy_name} for '{company_name}': {e}")
            continue

    if df_result.empty:
        return f"No data found for '{company_name}' after trying all methods."

    try:
        df_result = df_result.reset_index()
        df_result.columns = [c.lower().replace(" ", "_") for c in df_result.columns]

        if "date" in df_result.columns:
            df_result = df_result.rename(columns={"date": "datetime"})

        if "datetime" in df_result.columns:
            df_result["datetime"] = pd.to_datetime(df_result["datetime"]).dt.tz_localize(None)

        cols_to_drop = ["dividends", "stock_splits", "capital_gains"]
        # NOTE: pandas raises if both `columns=` and `axis=` are given; `columns=`
        # already implies axis=1. (This previously threw, silently skipping the
        # currency conversion below and returning foreign prices labelled as INR.)
        df_result = df_result.drop(columns=[c for c in cols_to_drop if c in df_result.columns])

        # ✅ Auto-detect and convert to INR if needed
        if stock_currency and stock_currency.upper() != "INR":
            print(f"Prices are in {stock_currency}. Converting to INR...")
            df_result = _convert_to_inr(df_result, source_currency=stock_currency.upper())
        else:
            _cprint("✅ Prices already in INR. No conversion needed.")
            df_result.attrs["fx_conversion"] = {
                "method": "none",
                "source_currency": (stock_currency or "INR"),
                "status": "ok",
            }

        return df_result

    except Exception as e:
        print(f"Error processing data: {e}")
        # If post-processing failed for a foreign-currency stock, the prices were
        # NOT converted — say so rather than letting the safety net mislabel them
        # as native INR.
        if isinstance(df_result, pd.DataFrame) and stock_currency and stock_currency.upper() != "INR":
            df_result.attrs["fx_conversion"] = {
                "method": "unconverted",
                "source_currency": stock_currency.upper(),
                "status": "failed",
            }
        return df_result

def get_stock_data_using_nselib(company_name, adjust=True):
    """
    Fetch daily stock data from NSE using nselib as a fallback source.

    This path fires only when yfinance returns nothing for a **daily** request,
    which is not hypothetical: NSE renames (``TATAMOTORS`` -> ``TMPV``) leave
    yfinance with no quote at all.

    Because it is a fallback, it was also the least-exercised code in the
    fetch layer, and it carried four defects that the primary path does not:

    1. ``AveragePrice`` was mapped to ``adj_close``. That column is **VWAP**,
       and it is **unadjusted** - across CESC's 10:1 split it yields a
       **-89.5%** one-day return in the column the pipeline models log returns
       off. Now ``close`` comes from ``ClosePrice`` and ``adj_close`` is built
       from NSE's corporate-action feed; VWAP is kept as its own ``vwap``
       column rather than thrown away.
    2. No ``Series`` filter, so pre-2003 dual-listed names returned **two rows
       per date** (442 of RELIANCE's 6,863).
    3. The frame arrived unsorted - not monotonic in either direction.
    4. ``datetime`` was returned as a *string* while the yfinance path returns
       ``datetime64``.

    Parameters
    ----------
    company_name : str
        Exact company name as it appears in BSE/NSE listings.
    adjust : bool, optional
        Build ``adj_close`` from the corporate-action feed (one request, ~4 s).
        When ``False`` - or when the feed fails - ``adj_close`` falls back to
        the raw close and ``attrs['price_adjustment']['adjusted']`` is
        ``False``, so a degraded series is always **declared** rather than
        passed off as adjusted.

    Accuracy
    --------
    Measured against yfinance's ``Adj Close`` on RELIANCE over 2,879 overlapping
    days: return correlation **0.99611**, mean absolute return difference
    **0.000035**. The same comparison against the old VWAP mapping scores
    **0.527** with a worst-day gap of 69%.

    The one residual disagreement is **2023-07-20** (8%), the Jio Financial
    demerger. Demergers are deliberately not handled by
    :func:`bhavcopy.parse_action` - the correct adjustment depends on the
    listed value of the spun-off entity, which the corporate-action feed does
    not carry - so they remain a known, documented gap rather than a guess.

    Returns
    -------
    pd.DataFrame or str
        Columns ``[datetime, open, high, low, close, vwap, volume, adj_close]``
        with ``attrs['price_adjustment']`` describing the adjustment, or an
        error string if fetching fails.
    """
    try:
        _cprint("Fetching price by using nselib please wait....")
        symbol = get_ticker(company_name)
        if not symbol:
            return f"No NSE symbol found for '{company_name}'."

        raw = capital_market.price_volume_data(
            symbol=symbol, from_date="01-01-2000",
            to_date=datetime.today().strftime("%d-%m-%Y"))
        if raw is None or not len(raw):
            return f"No data found for '{company_name}'."

        df = raw.copy()
        # One NSE column is literally named 'Turnover<rupee sign>'; stripping and
        # never printing raw column names keeps this off legacy Windows consoles.
        df.columns = [str(c).strip() for c in df.columns]

        # --- 1. one trading series only -------------------------------------
        # NSE returns EQ alongside BE/BL/etc. Before ~2003 several names traded
        # in two series at once, so an unfiltered pull carries TWO ROWS PER DATE
        # with different volumes - 442 of RELIANCE's 6,863 rows. Duplicate dates
        # silently corrupt every rolling window downstream.
        if "Series" in df.columns:
            df = df[df["Series"].astype(str).str.strip() == "EQ"]

        cols = {"Date": "datetime", "OpenPrice": "open", "HighPrice": "high",
                "LowPrice": "low", "ClosePrice": "close",
                "AveragePrice": "vwap", "TotalTradedQuantity": "volume"}
        df = df[[c for c in cols if c in df.columns]].rename(columns=cols)

        # --- 2. real dtypes -------------------------------------------------
        # datetime64, not a formatted string: the yfinance path returns
        # datetime64 and a type mismatch between the two sources is a
        # train/serve inconsistency waiting to happen.
        df["datetime"] = pd.to_datetime(df["datetime"], format="%d-%b-%Y",
                                        errors="coerce")
        df = df.dropna(subset=["datetime"])
        for c in ("open", "high", "low", "close", "vwap", "volume"):
            if c in df.columns:
                df[c] = pd.to_numeric(
                    df[c].astype(str).str.replace(",", "", regex=False),
                    errors="coerce")
        df = df[df["close"] > 0]

        # --- 3. de-duplicate and sort ---------------------------------------
        # Where a date still repeats, keep the higher-volume row: that is the
        # primary series. The frame arrives unsorted (and not even monotonic in
        # one direction), so sort explicitly rather than trusting the feed.
        if "volume" in df.columns:
            df = df.sort_values(["datetime", "volume"], na_position="first")
        df = df.drop_duplicates("datetime", keep="last")
        df = df.sort_values("datetime").reset_index(drop=True)

        # --- 4. a genuine adjusted close ------------------------------------
        # This used to map AveragePrice -> adj_close. AveragePrice is VWAP, and
        # it is UNADJUSTED: across CESC's 10:1 split it produces a -89.5%
        # one-day return in the exact column the whole pipeline models log
        # returns off. Adjust properly from NSE's corporate-action feed
        # instead - one request covering the full span, ~4 s.
        df["adj_close"] = df["close"]
        adj_status = {"source": "nselib", "adjusted": False,
                      "reason": "not attempted"}
        if adjust and len(df):
            try:
                import bhavcopy as _bc
                acts = _bc.corporate_actions(df["datetime"].min(),
                                             df["datetime"].max(),
                                             chunk_months=360)
                acts = acts[acts["symbol"].astype(str).str.strip() == symbol]
                if len(acts):
                    tmp = df[["datetime", "close"]].copy()
                    tmp["symbol"] = symbol
                    out = _bc.adjust_prices(tmp, acts)
                    df = df.drop(columns=["adj_close"]).merge(
                        out[["datetime", "adj_close"]], on="datetime", how="left")
                    df["adj_close"] = df["adj_close"].fillna(df["close"])
                adj_status = {"source": "nselib", "adjusted": True,
                              "n_actions": int(len(acts)),
                              "method": "bhavcopy.corporate_actions"}
            except Exception as exc:
                # Degrade to raw close and SAY SO. Silently serving unadjusted
                # prices as 'adj_close' is the bug this block replaces.
                adj_status = {"source": "nselib", "adjusted": False,
                              "reason": f"{type(exc).__name__}: {str(exc)[:80]}"}
        df.attrs["price_adjustment"] = adj_status
        return df
    except Exception as er:
        return f"No data found for '{company_name}'. \nError occured {er}"
    
def get_whole_stock_data(company_name, interval: str = "1d"):
    """
    Main entry point to fetch stock data; tries yfinance first, falls back to nselib for daily data.

    Cleans string-formatted numbers in price/volume columns before returning.

    Parameters
    ----------
    company_name : str
        Full or partial company name (e.g., 'Infosys Limited').
    interval : str, optional
        '1d' (default) for daily or '1h' for hourly. nselib fallback only applies to daily.

    Returns
    -------
    pd.DataFrame or str
        DataFrame with cleaned numeric columns, or an error string if all methods fail.
    """
    try:
        stock_data = get_stock_data_using_yfinance(company_name, interval)
        if interval == "1d" and not isinstance(stock_data, pd.DataFrame):
            stock_data = get_stock_data_using_nselib(company_name)
        stock_data["open"] = stock_data["open"].apply(lambda x: float(x.replace(",", "")) if type(x) is str else x)
        stock_data["high"] = stock_data["high"].apply(lambda x: float(x.replace(",", "")) if type(x) is str else x)
        stock_data["low"] = stock_data["low"].apply(lambda x: float(x.replace(",", "")) if type(x) is str else x)
        stock_data["close"] = stock_data["close"].apply(lambda x: float(x.replace(",", "")) if type(x) is str else x)
        stock_data["adj_close"] = stock_data["adj_close"].apply(lambda x: float(x.replace(",", "")) if type(x) is str else x)
        stock_data["volume"] = stock_data["volume"].apply(lambda x: int(x.replace(",", "")) if type(x) is str else x)
        # Safety net: the nselib fallback (and any path that didn't tag) returns
        # native-INR prices — record that so the UI always has an audit field.
        if isinstance(stock_data, pd.DataFrame) and "fx_conversion" not in stock_data.attrs:
            stock_data.attrs["fx_conversion"] = {
                "method": "none", "source_currency": "INR", "status": "ok",
            }
        # History-span audit. yfinance limits intraday history (hourly is
        # provider-capped — often ~1-2 years, and shorter than daily), so hourly
        # models can train on far less data; surface the actual span rather than
        # letting it pass silently.
        if isinstance(stock_data, pd.DataFrame) and "datetime" in stock_data.columns:
            dts = pd.to_datetime(stock_data["datetime"], errors="coerce").dropna()
            if len(dts):
                span = int((dts.max() - dts.min()).days)
                stock_data.attrs["history"] = {
                    "interval": interval,
                    "rows": int(len(stock_data)),
                    "start": dts.min().date().isoformat(),
                    "end": dts.max().date().isoformat(),
                    "span_days": span,
                }
        return stock_data
    except Exception as et:
        return f"Error Occured: {et}"

if __name__ == "__main__":
    print(get_stock_data_using_yfinance("Infosys Limited", "1h"))