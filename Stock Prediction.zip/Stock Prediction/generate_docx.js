// Generates Stock_Prediction_Documentation.docx — a detailed, concept-first
// technical document mirroring README.md. Run: node generate_docx.js
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType,
  ShadingType, TableOfContents, PageBreak, PageNumber, Header, Footer,
} = require("docx");

const CONTENT_W = 9360;            // US Letter, 1" margins
const BLUE = "1F4E79", LIGHT = "D9E2F3", GREY = "CCCCCC";

// ---- helpers ----------------------------------------------------------
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)] });

function P(runs) {
  if (typeof runs === "string") runs = [new TextRun(runs)];
  return new Paragraph({ spacing: { after: 120 }, children: runs });
}
const B = (t) => new TextRun({ text: t, bold: true });
const T = (t) => new TextRun(t);
const Code = (t) => new TextRun({ text: t, font: "Consolas", size: 20 });

function bullet(runs) {
  if (typeof runs === "string") runs = [new TextRun(runs)];
  return new Paragraph({ numbering: { reference: "bullets", level: 0 },
    spacing: { after: 60 }, children: runs });
}
function num(runs) {
  if (typeof runs === "string") runs = [new TextRun(runs)];
  return new Paragraph({ numbering: { reference: "numbers", level: 0 },
    spacing: { after: 60 }, children: runs });
}

const border = { style: BorderStyle.SINGLE, size: 1, color: GREY };
const borders = { top: border, bottom: border, left: border, right: border };
function cell(text, w, { head = false, bold = false } = {}) {
  return new TableCell({
    borders, width: { size: w, type: WidthType.DXA },
    shading: head ? { fill: LIGHT, type: ShadingType.CLEAR } : undefined,
    margins: { top: 60, bottom: 60, left: 110, right: 110 },
    children: [new Paragraph({ children: [
      new TextRun({ text: text, bold: head || bold, size: 20 }) ] })],
  });
}
function table(widths, rows) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, ri) => new TableRow({
      children: r.map((c, ci) => cell(c, widths[ci], { head: ri === 0 })),
    })),
  });
}

// ---- document content -------------------------------------------------
const children = [];

// Title block
children.push(new Paragraph({ spacing: { before: 2400, after: 120 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Stock Price Forecasting App", bold: true, size: 56, color: BLUE })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
  children: [new TextRun({ text: "Technical Documentation — Models, Concepts & Robustness", size: 28, color: "555555" })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 2400 },
  children: [new TextRun({ text: "16-model forecasting toolkit · walk-forward backtested · conformal uncertainty", italics: true, size: 22 })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Disclaimer: Educational and research purposes only. Not financial advice.", italics: true, size: 20, color: "888888" })] }));
children.push(new Paragraph({ children: [new PageBreak()] }));

// TOC
children.push(H1("Table of Contents"));
children.push(new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }));
children.push(new Paragraph({ children: [new PageBreak()] }));

// 1. What this project does
children.push(H1("1. What This Project Does"));
children.push(P("A multi-model stock-price forecasting toolkit built with Streamlit, targeting Indian markets (NSE/BSE) with global-ticker support. It runs 20 forecasting models in parallel — statistical, machine-learning, deep-learning, ensemble, volatility, and foundation-model approaches — and ships a walk-forward backtesting harness that measures every model against the only honest yardstick for stock prices: the naive random walk, on both statistical and economic terms."));
children.push(P([B("Capabilities: "), T("India-first company search (merged NSE + BSE listings); INR normalisation for non-INR tickers; daily and hourly forecasting with a configurable horizon; 20 selectable side-by-side models, most with calibrated 95% bands; an uncertainty-first UI (per-model confidence gate, abstention banner, and a probability/risk panel); two dedicated volatility models (HAR-RV and Vol-LSTM); automatic GPU/CPU selection; interactive Plotly charts; a model-agnostic backtesting harness with baselines and a Diebold-Mariano significance test; economic evaluation (Sharpe / Sortino / information ratio / drawdown, net of transaction costs); and a validated Value-at-Risk layer with Kupiec and Christoffersen backtests.")]));
children.push(H2("1.1 Robustness work baked in"));
children.push(P("This codebase went through a deliberate robustness pass:"));
children.push(bullet([B("Predict returns, not prices "), T("— neural nets forecast log returns with the scaler fit on training data only (no look-ahead).")]));
children.push(bullet([B("Direct multi-horizon forecasting "), T("— tree/ML models and neural nets forecast each step directly rather than feeding predictions back recursively, removing large multi-step error accumulation.")]));
children.push(bullet([B("Conformal prediction intervals "), T("— 12 of 14 base models now carry calibrated uncertainty.")]));
children.push(bullet([B("Cross-family meta-ensemble "), T("— combines the most reliable models robustly via the median.")]));
children.push(bullet([B("Cross-sectional market context "), T("— market/sector/VIX features (market_context.py) can be fed to every family (trees, neural nets, ARIMAX), but a controlled backtest showed they did not improve 5-day forecasts, so they ship off by default (opt-in). See Section 6.")]));
children.push(bullet([B("Purged/embargoed validation "), T("— removes the multi-horizon label overlap that was quietly inflating early-stopping and conformal-coverage numbers.")]));
children.push(bullet([B("NSE-exchange-calendar-aware horizons "), T("— forecast timestamps come from the real NSE trading calendar (pandas_market_calendars), so future dates skip weekends and exchange holidays; hourly forecasts land on genuine session bars (09:15-15:15, ~7 per trading day) instead of a naive 9-16h grid. The horizon is chosen in trading days for both frequencies (hourly maps to days x 7 session bars internally), so '5 days' means the same thing whether forecasting daily or hourly.")]));
children.push(bullet([B("Intraday NSE-session features (hourly) "), T("— the tree/ML models get bar-in-session, first/last-bar flags, return-since-open, overnight gap, and same-bar-yesterday return; leak-free and train/serve-consistent, toggleable via USE_INTRADAY_FEATURES.")]));
children.push(bullet([B("History-span surfacing "), T("— the app reports the actual hourly lookback (bars/sessions/dates) and warns when it is short, since intraday history is provider-capped and hourly models train on far less data than daily.")]));
children.push(bullet([B("Stronger baselines + significance testing "), T("— the backtest grades against drift and AR(1), not just the random walk, and runs a Diebold-Mariano test so an apparent edge is checked for statistical significance.")]));
children.push(bullet([B("Uncertainty as the deliverable "), T("— after the evidence showed point forecasts are mostly within noise, the app added a confidence/abstention gate, a probability/risk panel, distribution-first charts, and a dedicated HAR-RV volatility model with a conformalized (distribution-free, per-horizon) cone.")]));
children.push(bullet([B("Automatic GPU/CPU selection "), T("— deep models and Chronos use a GPU when present (with TF memory growth) and fall back to CPU; tree models stay on CPU on purpose (faster on these small windows).")]));
children.push(bullet([B("Economic evaluation, not just statistical "), T("— strategy_metrics.py answers the question RMSE never did: would acting on this forecast have made money, after costs? Sharpe, Sortino, information ratio, maximum drawdown and the information coefficient, charged for transaction costs on every position change, wired into walk_forward_backtest as a strategy block (Section 3.23).")]));
children.push(bullet([B("VaR estimation AND validation "), T("— var_models.py adds five estimators (Gaussian, historical simulation, Cornish-Fisher, Filtered Historical Simulation, a block-bootstrap generative sampler) plus Kupiec's proportion-of-failures and Christoffersen's independence / conditional-coverage tests. The app reported a VaR before; it never validated one — and clustered breaches, which only the independence test catches, are the failure mode that actually matters (Section 3.25).")]));
children.push(bullet([B("Two model additions where the evidence says value can exist "), T("— Vol-LSTM (a deep counterpart to HAR-RV that can express non-linear variance dynamics and the leverage effect, same flat-point / conformal-cone contract) and CNN-LSTM (causal convolutions feeding recurrence — the one architectural corner the zoo lacked). Section 3.24.")]));
children.push(bullet([B("A regime-novelty gate "), T("— autoencoder_regime.py plus gating.apply_novelty_gate: a denoising autoencoder's reconstruction error detects when the current market state is off-manifold relative to what the models were fitted on, and withholds the directional call. This closes a real blind spot — a backtest-derived confidence bucket describes the past regime and says nothing about a novel present (Section 3.26).")]));
children.push(bullet([B("A latent HAR-RV bias, found and fixed "), T("— scoring the raw variance forecast (not just the interval) revealed HAR-RV over-stating volatility by ~1.9x: it converted log-variance to a level with the log-normal Jensen correction, which assumes a Gaussian residual, but a regression on log(r^2) has a log-chi-squared residual. The conformal layer had been silently cancelling the error — coverage was fine, the reported volatility was not. Now fixed with a data-estimated offset (har_level_offset); coverage- and width-neutral, and it moves HAR-RV from last to second on QLIKE (Section 6.10).")]));
children.push(bullet([B("Shared, de-duplicated infrastructure "), T("— common logic consolidated into model_utils.py, direct_forecast.py, market_context.py, HAR_RV_model.py, vol_lstm_model.py, strategy_metrics.py, var_models.py and autoencoder_regime.py.")]));

// 2. Models
children.push(H1("2. The 20 Models"));
children.push(P("Every model exposes the same entry point, run_*_prediction(df, interval, horizon), and returns a DataFrame with datetime and predicted_price (plus lower_bound, upper_bound, volatility where intervals exist)."));
children.push(table([520, 1700, 3300, 2340, 1500], [
  ["#", "Category", "Model", "Forecast strategy", "Intervals?"],
  ["1", "Statistical", "Auto-ARIMA + GARCH (Monte Carlo)", "Simulation", "Yes"],
  ["2", "Statistical", "ARIMAX + GARCH (exogenous + market context)", "Simulation", "Yes"],
  ["3", "Statistical", "Markov Regime-Switching AR", "Simulation", "Yes"],
  ["4", "Prophet", "Facebook Prophet", "Additive decomposition", "Yes"],
  ["5", "Machine Learning", "XGBoost", "Direct multi-horizon", "Yes (conformal)"],
  ["6", "Machine Learning", "LightGBM", "Direct multi-horizon", "Yes (conformal)"],
  ["7", "Ensemble", "XGB + LGB + Ridge stacking", "Direct multi-horizon", "Yes (conformal)"],
  ["8", "Quantile", "LightGBM quantile regression", "Direct multi-horizon", "Yes (native)"],
  ["9", "Deep Learning", "LSTM", "Direct multi-horizon", "Yes (conformal)"],
  ["10", "Deep Learning", "GRU", "Direct multi-horizon", "Yes (conformal)"],
  ["11", "Deep Learning", "Transformer", "Direct multi-horizon", "Yes (conformal)"],
  ["12", "Deep Learning", "N-BEATS (capacity-reduced)", "Direct multi-horizon", "Yes (conformal)"],
  ["13", "Deep Learning", "Temporal Convolutional Network", "Direct multi-horizon", "Yes (conformal)"],
  ["14", "Hybrid", "ARIMA + LSTM on residuals", "Recursive", "No"],
  ["15", "Foundation", "Amazon Chronos-2 (+ covariates)", "Native multi-step", "Yes"],
  ["16", "Volatility", "HAR-RV (flat price + conformal cone)", "Variance forecast", "Yes (conformal)"],
  ["17", "Meta-ensemble", "Median of Quantile-LGBM + XGBoost + ARIMAX", "Combination", "Yes"],
  ["18", "Deep Learning", "CNN-LSTM (LSTM over a causal conv stack)", "Direct multi-horizon", "Yes (conformal)"],
  ["19", "Volatility", "Vol-LSTM (deep counterpart to HAR-RV)", "Variance forecast", "Yes (conformal + ACI)"],
  ["20", "State-space", "Kalman damped local linear trend", "Filtered state, damped extrapolation", "Yes (native + conformal)"],
]));
children.push(P([B("HAR-RV and Vol-LSTM are deliberately different: "), T("they make no directional claim (their point forecast is the random walk) and their deliverable is the volatility cone — see Sections 3.12 and 3.24. They will show “No edge” in the confidence column by design; their value is the calibrated interval, not the price line.")]));

// 3. Concepts
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(H1("3. Concepts Explained"));
children.push(P("This section explains every important idea from first principles. No finance or ML background is assumed."));

children.push(H2("3.1 The forecasting problem and what “robust” means"));
children.push(P("A time series is a sequence of values ordered in time (a stock's daily or hourly price). Forecasting predicts future values from past ones. Stock prices are hard because they behave close to a random walk: the best naive guess for tomorrow is today's price. Markets are largely efficient — predictable patterns are mostly already priced in."));
children.push(P([B("Consequence: "), T("chasing a lower price error (RMSE) is often a losing game — a model can look accurate simply by echoing the last price. So here, “robust” does not mean “lowest RMSE.” It means:")]));
children.push(num("Never blow up — no catastrophic forecasts on any ticker."));
children.push(num("Consistently match or beat the random walk out-of-sample, across stocks."));
children.push(num("Quantify uncertainty honestly — intervals that contain the truth ~95% of the time."));

children.push(H2("3.2 Predict log returns, not prices"));
children.push(P([T("A log return is r = ln(P_t / P_{t-1}) — the percentage change between consecutive prices in log space. We forecast returns, not raw prices, for two reasons: "), B("stationarity "), T("(raw prices trend and drift, violating model assumptions; returns have a stable mean near zero) and "), B("scale-invariance "), T("(a ₹50 and a ₹5,000 stock have comparable return distributions).")]));
children.push(P([T("Recover price from return: P_t = P_{t-1} · exp(r). For multi-step we predict a cumulative log return ln(P_{t+h}/P_t) and reconstruct the price. The neural nets were changed from predicting the scaled price level to predicting returns, because predicting the level on random-walk-like data makes the network echo the last price (the “persistence trap”).")]));

children.push(H2("3.3 Feature engineering"));
children.push(P("Tabular and sequence models are fed engineered features derived only from past data (no peeking ahead), all scale-invariant so they generalise across price levels:"));
children.push(bullet("Log returns over several lags (1,2,3,5,10) — short-term momentum."));
children.push(bullet("Moving-average ratios and SMA-short / SMA-long — trend direction."));
children.push(bullet("Rolling volatility at multiple windows — recent risk."));
children.push(bullet("RSI (Wilder) — momentum oscillator (0–100) balancing up- vs down-moves."));
children.push(bullet("MACD (normalised) — fast vs slow EMA difference; trend/momentum."));
children.push(bullet("Bollinger-band position & price z-score — distance from recent mean (mean-reversion)."));
children.push(bullet("ATR / range — normalised volatility proxy."));
children.push(bullet("Volume ratio / change — unusual activity."));
children.push(bullet("Calendar features — day-of-week, month, hour — seasonality."));
children.push(bullet([B("Intraday NSE-session features (hourly only) "), T("— bar_in_session (0-6), is_first_bar/is_last_bar, ret_since_open, overnight_gap (today's open vs the previous session's close) and same_hour_prev_day_ret (vs the same bar one session ago). They capture open/close auction effects, the overnight gap, and intraday seasonality that day-level features miss. Leak-free (current-and-past only) and train/serve-consistent — computed identically in vectorized create_features and scalar _features_from_buffers (NSE sessions are 7 contiguous hourly bars, so 'N bars back = same bar of an earlier session' is exact). Tree/ML family only; toggle via ML_model.USE_INTRADAY_FEATURES.")]));
children.push(P("The neural nets use a compact 9-feature matrix computable from a price buffer, so identical definitions apply at training and prediction time. (The intraday-session features are tree/ML-only; the NN feature matrix is datetime-less by construction.)"));
children.push(P([B("Cross-sectional market context (market_context.py). "), T("The features above are all self-referential — derived from the stock alone. But short-horizon returns are dominated by the market: a stock's next move is mostly its beta times the index move plus a smaller stock-specific (alpha) component. So the pipeline fetches a market index (NIFTY 50 by default) and a volatility index (India VIX) and attaches eight causal context columns once, up front: contemporaneous and trailing index return, excess return (alpha proxy), 20-period relative strength, rolling 60-period beta and correlation, and VIX change and z-score.")]));
children.push(P([T("Because create_features carries extra columns through, the tree, ensemble and meta models consume these automatically; the neural nets get them concatenated onto their feature matrix inside forecast_nn_direct; and ARIMAX takes the market return and VIX change as exogenous regressors. Every feature is contemporaneous or trailing (no look-ahead), missing index data is filled with a neutral 0 so context never truncates history, and if the index can't be fetched the data passes through unchanged. For a non-Indian ticker the NIFTY/India-VIX defaults are only an approximate proxy.")]));
children.push(P([B("Empirical caveat — off by default. "), T("A controlled A/B backtest on Indian tickers (where NIFTY is the correct proxy) showed these features did not improve 5-day forecasts and made the single tree models worse (extra overfitting surface at this horizon — see Section 6). They therefore ship disabled (USE_MARKET_CONTEXT in UI.py; the --with-context flag on the backtest drivers).")]));
children.push(P([B("Excess-return reframing was also tried, and also did not help. "), T("The deeper idea was to predict the excess return (stock minus market) instead of the absolute return (add_market_index attaches an mkt_index column; the direct target builders then subtract the market's cumulative return). A controlled A/B showed no improvement in absolute-price RMSE — expected, because the expected short-horizon market move is ~0, so reconstruction re-injects the unforecastable market noise. It is off by default too. The broader lesson: market data helps cross-sectional / ranking problems, not single-stock absolute-price forecasting at this horizon.")]));

children.push(H2("3.4 Robustness to outliers"));
children.push(P("Financial returns have fat tails (extreme moves are common). Three defences:"));
children.push(bullet([B("Winsorization "), T("— clip values at the 1st/99th percentiles so one crash/spike can't dominate training. The clip bounds can be fit on the training block only (winsorize_bounds) and reused, keeping the preprocessing free of look-ahead bias.")]));
children.push(bullet([B("Huber loss "), T("— squared-error-like for small errors, absolute-error-like for large ones, so outliers don't dominate gradients.")]));
children.push(bullet([B("Fat-tailed GARCH innovations "), T("— Student-t / skewed-t volatility distributions.")]));

children.push(H2("3.5 Recursive vs. direct multi-horizon forecasting"));
children.push(P([B("Recursive: "), T("predict one step, append it, recompute features, repeat. Simple, but errors compound and the forecast can drift.")]));
children.push(P([B("Direct: "), T("train the model to predict step h directly from the observed origin (no feedback), using the cumulative-return target ln(P_{t+h}/P_t). Either one model per horizon (tree models) or one network with h outputs (neural nets).")]));
children.push(P([B("Impact: "), T("switching the tree/ML models and neural nets to direct forecasting was the single biggest robustness win — gradient-boosted models improved ~25–34% in RMSE and moved from worse-than-naive to beating it. It also fixed a one-bar origin offset present in the recursive path.")]));

children.push(H2("3.6 Avoiding data leakage (look-ahead bias)"));
children.push(P("Data leakage is when future information sneaks into training, inflating apparent accuracy. Two fixes:"));
children.push(bullet([B("Scaler fit on training rows only "), T("— a MinMaxScaler learns each feature's min/max; fitting it on the whole series leaks the future range. It is now fit on the training portion only.")]));
children.push(bullet([B("Future-only targets, past-only features "), T("— model selection uses walk-forward splits, not random k-fold (which leaks across the time boundary).")]));
children.push(bullet([B("Purged/embargoed validation "), T("— the direct multi-horizon target ln(P_{t+h}/P_t) spans h future bars, so the last training samples and the first held-out samples share overlapping future windows, quietly making early-stopping and conformal coverage look better than reality. An embargo gap of h samples is now dropped between the train and held-out blocks at all three internal split points: temporal_train_val_split (NN early stopping), forecast_nn_direct (NN conformal), and conformal_halfwidth (tree conformal).")]));

children.push(H2("3.7 Volatility and uncertainty: GARCH + Monte Carlo"));
children.push(P("Volatility clusters — calm and turbulent periods come in runs. GARCH models tomorrow's variance from recent squared shocks and recent variance. The statistical models fit GARCH on residuals and pick the best variant by BIC among GARCH, GJR-GARCH and EGARCH (asymmetric: bad news raises volatility more), with Normal/Student-t/skewed-t/GED innovations."));
children.push(P("Forecasts come from Monte Carlo simulation: simulate thousands of future return paths, build price paths, and read off the median (point forecast) and the 2.5th/97.5th percentiles (95% interval). Intervals widen naturally in volatile regimes."));

children.push(H2("3.8 Quantile regression"));
children.push(P("Instead of the mean, quantile regression predicts a percentile. The Quantile model trains three LightGBM models per horizon — 2.5th, 50th, 97.5th percentiles of the cumulative return — via the pinball loss. The median is the point forecast; the outer two form a native 95% interval that makes no normality assumption."));

children.push(H2("3.9 Conformal prediction (distribution-free intervals)"));
children.push(P("Conformal prediction wraps any point model to produce a calibrated interval with minimal assumptions. The split-conformal recipe:"));
children.push(num("Hold out a recent calibration block the model didn't train on."));
children.push(num("Measure the model's absolute errors on that block, per horizon step."));
children.push(num("The (1−α) quantile of those errors is the interval half-width; the band is forecast · exp(±half-width) in return space."));
children.push(P("Because stock data isn't exchangeable (trend, changing volatility), the split is temporal — with an embargo gap of h bars before the calibration block so the future-spanning labels don't overlap (see 3.6) — and the half-width is computed per horizon, so intervals widen with horizon. Added to the tree/ML models (direct_forecast.conformal_halfwidth) and the neural nets (inside model_utils.forecast_nn_direct). Coverage is then checked empirically by the backtest."));

children.push(H2("3.10 The cross-family meta-ensemble"));
children.push(P("The multi-ticker backtest showed no universal winner — tree models won some stocks, statistical models others. The meta-ensemble combines different families (Quantile-LGBM and XGBoost from the tree family, ARIMAX+GARCH from the statistical family) and aggregates them with the median of per-horizon point forecasts. The median is robust to a single model misfiring (the exact failure mode), bounds are averaged across constituents, and the ensemble degrades gracefully if a constituent fails."));

children.push(H2("3.11 Model-by-model summary"));
children.push(bullet([B("ARIMA + GARCH "), T("— Auto-ARIMA for linear autocorrelation, GARCH for volatility, Monte Carlo for the forecast/interval. Stable, near-flat point forecasts.")]));
children.push(bullet([B("ARIMAX + GARCH "), T("— ARIMA plus exogenous regressors (volume, range, RSI, momentum, calendar). Often the best statistical model.")]));
children.push(bullet([B("Regime Switching "), T("— Markov model with hidden bull/bear states, each with its own mean/variance; regime-aware simulation.")]));
children.push(bullet([B("Prophet "), T("— additive trend + seasonality + holidays (log-space). Easy but can over-extrapolate trends.")]));
children.push(bullet([B("XGBoost / LightGBM "), T("— gradient-boosted trees on engineered features; direct multi-horizon with conformal intervals. Among the most robust.")]));
children.push(bullet([B("Stacking Ensemble "), T("— XGB + LGB + Ridge combined by a Ridge meta-learner on out-of-fold predictions; direct + conformal.")]));
children.push(bullet([B("Quantile-LGBM "), T("— native probabilistic intervals; consistently the most robust single model in the backtest.")]));
children.push(bullet([B("LSTM / GRU "), T("— recurrent nets; now direct multi-horizon (multi-output) with conformal bands.")]));
children.push(bullet([B("Transformer "), T("— self-attention with causal masking; direct + conformal.")]));
children.push(bullet([B("TCN "), T("— dilated causal convolutions with skip connections; direct + conformal.")]));
children.push(bullet([B("N-BEATS "), T("— fully-connected residual stack; capacity-reduced (64 units × 2 blocks) after the 256-unit version overfit; direct + conformal.")]));
children.push(bullet([B("Hybrid ARIMA + LSTM "), T("— ARIMA for the linear part, LSTM for the non-linear residual.")]));
children.push(bullet([B("Chronos-2 "), T("— Amazon's pretrained foundation model, run zero-shot with engineered covariates.")]));
children.push(bullet([B("HAR-RV "), T("— a volatility model (Section 3.12); flat point forecast plus a conformalized risk cone.")]));
children.push(bullet([B("Meta-Ensemble "), T("— the robust median combination above.")]));

children.push(H2("3.12 Volatility forecasting with HAR-RV"));
children.push(P("The backtest taught the central lesson of this domain: at single-name daily/hourly horizons the return (the price direction) is essentially a random walk — no feature set reliably beat it. But the second moment is different: volatility clusters and is genuinely forecastable (the same property GARCH exploits). So HAR_RV_model.py adds a model that stops pretending to predict the price and instead forecasts the risk."));
children.push(P("HAR-RV (Heterogeneous AutoRegressive model of Realized Volatility, Corsi 2009) explains today's log realized variance with its own daily, weekly and monthly lagged averages — three horizons of memory capturing volatility's long persistence with just four OLS parameters. It builds a realized-variance series from bar returns, rolls the fit forward to a per-step log-variance forecast, converts log to level, sums the step variances (variance is additive) to the cumulative variance at each horizon, and wraps a flat (random-walk) price path in a last_price * exp(±k * sqrt(cum_var)) band."));
children.push(P([B("The log-to-level step is subtler than it looks, and was originally wrong. "), T("Exponentiating the mean of log(r^2) does not give the variance: writing r = sigma*z, log(r^2) = log(sigma^2) + log(z^2), and E[log z^2] = -1.27 for Gaussian z. The textbook repair — the log-normal Jensen correction exp(mu + resid_var/2) — assumes a Gaussian residual, but this residual is log-chi-squared with variance pi^2/2 ~ 4.93, so the correction over-shot and inflated volatility by a measured ~1.9x. The offset is now estimated from the data instead (har_level_offset: c = log(mean RV) - mean(log RV)), which recovers 1.27 on Gaussian returns and self-adjusts for the percentile clipping and for genuinely fat tails (on RELIANCE it lands at ~1.45-1.55, correctly higher than Gaussian). The bug survived a long time because the conformal layer below cancels it — coverage stayed correct while the reported per-step volatility did not. See Section 6.10.")]));
children.push(P([T("It makes "), B("no directional claim"), T(" — embodying the honest position that the point forecast is unforecastable but the cone is not. The multiplier k is "), B("conformalized per horizon"), T(": instead of the textbook normal 1.96 (which under-covers because returns are fat-tailed), k_h is the empirical quantile of recent cumulative standardized residuals, so the band is distribution-free and calibrated to the realized h-step move. A free diagnostic falls out of this: if the fitted k_h sits far below 1.96, the variance forecast it is correcting is probably biased high — which is precisely how the level bug announced itself.")]));
children.push(P([B("Adaptive (ACI) refinement, default on. "), T("A static k_h is the quantile of the whole calibration pool — it can't tell that the recent stretch has been systematically under-covering (a volatility regime shift), the exact failure the backtest exposed. So the cone applies Adaptive Conformal Inference (Gibbs & Candès, 2021): walking the calibration residuals in time order it updates the miscoverage level (alpha_{t+1} = alpha_t + gamma*(alpha* - err_t)). A run of misses drives alpha down toward a higher quantile and a wider cone; a run of easy covers tightens it. Because alpha carries memory, its value at the end of the stream is recency-weighted, so the live multiplier reflects the current regime rather than the long-run average. It is a parameter (adaptive=True, aci_gamma) on run_har_rv_prediction so the calibration harness can A/B it (Section 6.4). On a calm window it can slightly over-tighten an already-well-calibrated name; its upside is regime response (see caveats).")]));

children.push(H2("3.13 Confidence, abstention, and risk outputs"));
children.push(P("Because the backtest showed most point wins are within noise, the app treats uncertainty as the deliverable, not the price line:"));
children.push(bullet([B("Confidence gate "), T("— at request time the app runs a quick walk-forward backtest per model and labels it High / Medium / Low / No edge from its RMSE improvement over the best naive baseline, the Diebold-Mariano p-value, and interval coverage. The rule is backtest.confidence_bucket — the single source of truth shared with the offline validation harness (Section 3.15). Low/No-edge means: use the range, not the point.")]));
children.push(bullet([B("Abstention banner "), T("— when no model reliably beats the random walk for the chosen ticker/horizon, the app says so prominently instead of presenting a confident-looking line.")]));
children.push(bullet([B("Gated directional call "), T("— the Sentiment/Direction columns are withheld (“No edge”, “–”) for any model the gate rates “No edge”, so the app never asserts a Bullish/Bearish view off a point forecast its own test says is no better than a coin flip.")]));
children.push(bullet([B("Risk & Probability panel (empirical, fat-tailed) "), T("— P(up), P(gain > +X%), P(loss > X%), the VaR-style 5% downside and the 95% range are counted directly from HAR-RV's conformal residual sample (the genuine fat-tailed distribution), not from a normal approximation. Earlier versions re-imposed a log-normal at this last step, discarding exactly the tails the conformal machinery had estimated; that is fixed. When no fat-tailed model (HAR-RV) is in the run, the panel falls back to a log-normal read of each model's interval and says so explicitly in the caption.")]));
children.push(bullet([B("Distribution-first charts "), T("— every chart draws the naive random-walk baseline next to the forecast and frames the band as the plausible-outcome cone.")]));

children.push(H2("3.14 The app: model selection, caching, and GPU"));
children.push(P("The Streamlit UI lets the user pick a company (NSE/BSE only), interval, horizon (in trading days; hourly maps it to ~7 session bars per day), and which subset of models to run. The summary table shows, per model: Predicted Price, Change, Signal Score (% — the value the bull/bear call is made on), Conviction (the move ÷ half the model's own 95% band), Confidence (the walk-forward bucket above), Sentiment (Bullish/Bearish, or “No edge” when the gate withholds the call), and Direction (▲/▼, or “–” when withheld)."));
children.push(P([B("Performance & infrastructure: "), T("results are cached per (ticker, interval, horizon, model) and the run parameters are snapshotted at Submit, so interacting with a control does not silently recompute the suite. GPU/CPU detection (model_utils.configure_compute) puts the deep models and Chronos on a GPU when present and falls back to CPU; the gradient-boosted trees stay on CPU on purpose (GPU tree training is slower on these small windows). The active device is shown in the sidebar.")]));

children.push(H2("3.15 Validating the uncertainty (calibration)"));
children.push(P("A probabilistic product is only honest if its probabilities are calibrated — a “95%” interval that covers 80% of the time, or a “P(up)=70%” that is right 55% of the time, is worse than silence. calibration.py (driver run_calibration.py) validates the claims the app already makes (it does not add a model), with standard proper tools:"));
children.push(bullet([B("CRPS "), T("(Continuous Ranked Probability Score) — the gold-standard proper score for a full predictive distribution; it jointly rewards calibration and sharpness (lower is better, and it generalises MAE to distributions). Reported per horizon, and — crucially — empirical-sample CRPS vs log-normal-approximation CRPS side by side for HAR-RV, so the value of the fat tails is measured, not asserted.")]));
children.push(bullet([B("PIT "), T("(Probability Integral Transform) — F_pred(actual) should be Uniform(0,1) if the predictive distribution is calibrated; a U-shape means over-confident (too narrow), a hump means too wide. Summarised by a KS distance to uniform.")]));
children.push(bullet([B("Reliability / ECE "), T("— bins the predicted P(up) and P(move > X%) and compares them to the realised frequency; the Expected Calibration Error says whether “70%” really means 70%. P(up) reliability is meaningful for directional models; HAR-RV's is approximately 0.5 by design.")]));
children.push(bullet([B("Coverage quality, not just coverage "), T("— coverage and mean interval width, their efficiency ratio, and the lower/upper tail-miss balance (misses skewed downside means the cone underestimates crash risk).")]));
children.push(bullet([B("Gate validation "), T("— a nested walk-forward assigns each origin a confidence bucket from past-only data (the same backtest.confidence_bucket the UI ships) and measures the realised next-horizon skill, so you can check that “High” actually beats “No edge” out-of-sample rather than being theatre.")]));
children.push(P("An illustrative single-ticker run (RELIANCE.NS, 5-day horizon) found HAR-RV's empirical fat-tailed CRPS beating its log-normal approximation (about 24.6 vs 25.3) — confirming the Section 3.13 risk-panel fix helps the proper score, not just in principle — with PIT consistent with calibration (KS p ≈ 0.39) and XGBoost's P(up) reliability poor (ECE ≈ 0.31), the honest reason directional calls are withheld when the gate says “No edge”. See Section 6.4."));

children.push(H2("3.16 Data-snooping-robust model selection (Reality Check & SPA)"));
children.push(P("The Diebold-Mariano test is pairwise — it asks whether one model beats the random walk. But the app compares 17 models across several tickers, and picking the best-looking one reintroduces the very bias DM guards against: with enough candidates, one wins by luck. multiple_testing.py (driver run_spa.py) closes that gap with the standard data-snooping corrections, both over a stationary bootstrap (Politis-Romano) of the aligned loss differentials, with the block length chosen automatically from the data (Politis-White 2004):"));
children.push(bullet([B("White's Reality Check (2000) "), T("— bootstraps max_k sqrt(T)*mean(loss_benchmark - loss_model_k) under the least-favourable null. Conservative; the headline verdict.")]));
children.push(bullet([B("Hansen's SPA (2005) "), T("— studentizes (Newey-West HAC) and applies the consistent recentering that drops hopeless models from the null, so it is more powerful. Reported as a companion; it can be mildly liberal at small sample, so a borderline SPA rejection the Reality Check does not confirm is treated as unconfirmed.")]));
children.push(P("H0 for both: no model in the set beats the benchmark. The experiment unit is the forecast origin (one mean loss per origin), not the within-horizon step, so the bootstrapped events are near-independent. This is the rigorous capstone to the DM work: it answers the honest question — after trying K models, is there evidence that ANY of them genuinely beats the random walk? (Result in Section 6.4.)"));

children.push(H2("3.17 Currency conversion to INR and its audit trail"));
children.push(P("The app is INR-centric but can forecast foreign-listed names, so prices are converted to INR in get_data.py. The conversion is period-accurate by default: it fetches the historical FX series (USDINR=X, EURINR=X, ...) and converts each bar at its own date's rate — a 2019 price uses the 2019 rate, a 2026 price uses the 2026 rate. This matters: converting the whole history at one current rate would leave day-to-day returns unchanged but distort the level path the volatility models see. Weekend/holiday gaps are forward/back-filled from the nearest trading day."));
children.push(P("Two fallbacks are used only when the historical series cannot cover the data: a few un-coverable early dates are filled with today's rate, and if the whole historical fetch fails the entire series is rescaled by today's rate (a degraded mode). If even the live rate fails, prices are left unconverted."));
children.push(P([T("Because those fallbacks change what the rupee numbers mean, every fetch carries an "), B("audit tag"), T(" (df.attrs['fx_conversion']) recording the path taken, and the UI renders it above the results: historical -> a quiet caption (converted at each date's own rate); live-uniform -> a warning that historical levels are rescaled and not period-accurate; unconverted -> an error that the rupee labels do not apply. This makes the conversion reviewer-auditable rather than invisible. Building this audit trail also surfaced and fixed a latent bug where a DataFrame.drop call threw before the conversion ran, silently returning foreign prices labelled as INR.")]));
children.push(P([B("Scope note - this is a dormant safety net. "), T("The company selector is built only from NSE + BSE listings (get_data.company_list), so every selectable stock is quoted in INR already and the conversion path is never taken in normal use (the audit tag reads 'none'). _convert_to_inr can only fire for a foreign ticker reached via the API-search fallback for a name not in the dropdown - an edge case the UI does not expose. Consequently there is no FX applied to an Indian hourly series at all, so intraday-FX granularity is moot for this product; it would only matter if the universe were widened to foreign listings. The audit tag exists precisely so that, if that dormant path ever fires, it is surfaced loudly rather than silently mislabelling prices.")]));

children.push(H2("3.18 Input data-quality gating"));
children.push(P("A forecast is only as trustworthy as the data feeding it, and the source here is yfinance — which can serve stale candles, missing bars, zero-volume rows, or (rarely) inconsistent OHLC. A weak prediction caused by bad data is indistinguishable, in the output, from one caused by a weak model — unless you check. So data_quality.py scores every fetched series BEFORE any model output is trusted, making data quality part of the gate."));
children.push(P("assess_data_quality(df, interval, horizon) runs a battery of pure checks and returns a structured report — a 0-100 score, a tier, a serving mode, and a list of reason codes (each with a severity and a human message):"));
children.push(bullet([B("Insufficient / thin history "), T("— fewer bars than needed to fit and walk-forward-assess a horizon-step forecast (interval-aware floor); and a short hourly window (provider-capped intraday history below ~100 sessions).")]));
children.push(bullet([B("Duplicate / unsorted timestamps "), T("— would corrupt feature construction.")]));
children.push(bullet([B("Missing / non-positive prices "), T("— NaNs or <= 0 levels that break log-return modeling.")]));
children.push(bullet([B("Bad OHLC bars "), T("— high < low, or close outside the bar's range; and zero-volume bars (illiquidity / halts).")]));
children.push(bullet([B("Stale last candle "), T("— the feed hasn't updated within the expected cadence.")]));
children.push(bullet([B("Calendar gap "), T("— a genuine data hole, measured in calendar days against an interval-aware threshold so normal overnight/weekend/holiday gaps don't false-flag.")]));
children.push(bullet([B("Abnormal recent jump "), T("— a large robust-z return spike in the last few bars (possible unadjusted corporate action or event risk).")]));
children.push(bullet([B("Currency status "), T("— reads get_data's fx_conversion audit tag (degraded -> warn, unconverted -> critical).")]));
children.push(P("The reason codes drive a serving mode, not just a number:"));
children.push(table([2200, 3680, 3480], [
  ["Mode", "When", "UI behaviour"],
  ["normal", "clean data", "forecast as usual"],
  ["warn", "minor caveats", "forecast with a data-quality warning"],
  ["risk_cone_only", "a non-fatal critical (illiquidity, bad bars)", "withhold directional calls, steer to the risk cone"],
  ["abstain", "a fatal flaw (insufficient history, stale feed, unconverted currency, non-positive prices)", "don't present a directional forecast"],
]));
children.push(P([T("In the app, a degraded gate forces every model's confidence bucket to "), B("No edge"), T(", reusing the existing abstention machinery so directional calls vanish consistently, and a banner plus an expandable per-check list make the verdict auditable. This is wired alongside the existing skill gate and the SPA/Reality-Check framing: every model row now shows a plain-language "), B("Basis"), T(" reason code (e.g. \"no edge vs random walk (DM p=0.42)\", \"withheld — data quality\"), and a standing notice states that the data-snooping-robust tests found no confirmed winner — so the comparison table is never read as crowning a best model. The gate's behaviour is covered by test_data_quality.py.")]));

children.push(H2("3.19 Price-adjustment hygiene (adjusted vs. raw close)"));
children.push(P("A reviewer flagged a subtle potential leak: yfinance retro-adjusts its Adj Close series for ALL splits and dividends, including ones that occur after a given bar, and this whole pipeline models log returns off adj_close. Could a past bar therefore know about a future corporate action? audit_price_adjustment.py measures it directly on real NSE names, and the answer is no — it is immaterial for this pipeline, for three concrete reasons:"));
children.push(num([B("Live serving has zero leak. "), T("At serve time the latest bar's adjustment factor is 1.0, so only actions that have already happened are baked in — exactly the information a real user would have.")]));
children.push(num([B("The leak is confined to corporate-action bars "), T("(approx 0.4-1.6% of bars in the audited sample). On those exact bars the adjusted return is the economically-correct value (it removes the artificial split/dividend price jump); on every other bar the adjusted and raw returns are identical, so every scale-invariant feature (returns, ratios, RSI, volatility, z-scores) is unchanged.")]));
children.push(num([B("The level distortion cancels where it matters. "), T("Past price levels can be rescaled by up to ~10-18% at the oldest origin, but the models forecast log returns and the metrics that drive the gate (Diebold-Mariano, SPA, MASE) are scale-invariant, so a piecewise rescale of levels cancels in every model-vs-baseline comparison.")]));
children.push(P("Switching to raw close would be worse: it would inject fake ~2-3% jumps at every ex-dividend/split date as if they were real returns, corrupting volatility and RSI. Using the adjusted (total-return) series is the correct choice for return modeling; the residual look-ahead is documented rather than fixed because fixing it (point-in-time re-adjustment per origin) would buy nothing measurable here. The audit script is kept so the claim is reproducible."));

children.push(H3("The fallback path was a different story"));
children.push(P("All of the above concerns the PRIMARY yfinance path, which was correct. The nselib DAILY FALLBACK - which fires only when yfinance returns nothing, and does fire, because NSE renames leave yfinance with no quote at all (TATAMOTORS -> TMPV) - was not. Being the least-exercised code in the fetch layer and the only module with NO TEST COVERAGE, it had accumulated four defects:"));
children.push(num("AveragePrice was mapped to adj_close. That column is VWAP, not a close, and it is completely UNADJUSTED. Across CESC's 10:1 split it yields a -89.5% one-day return in the exact column this section argues so carefully about - a far worse version of the 'fake 2-3% jump' the design explicitly rejects."));
children.push(num("No Series filter. Before ~2003 several names traded in two series simultaneously, so the pull returned TWO ROWS PER DATE - 442 of RELIANCE's 6,863 rows. Duplicate dates corrupt every rolling window downstream."));
children.push(num("Unsorted output, not monotonic in either direction."));
children.push(num("datetime returned as a string where the yfinance path returns datetime64."));
children.push(P("Measured against yfinance's Adj Close on RELIANCE over 2,879 overlapping days:"));
children.push(table([4200, 3000, 2660], [
  ["Mapping", "Return correlation", "Worst-day gap"],
  ["Before (VWAP as adj_close)", "0.527", "69%"],
  ["After (corporate-action adjusted)", "0.996", "8%"],
]));
children.push(P("Mean absolute return difference is now 0.000035. close comes from ClosePrice, VWAP is retained as its own vwap column rather than discarded, and adj_close is built from NSE's corporate-action feed via the bhavcopy module of Section 3.39 - one request, ~4 s for 26 years, measured before committing to the design."));
children.push(P([B("The residual 8% is a single day: 2023-07-20, the Jio Financial demerger. "), T("Demergers are deliberately not handled - the correct adjustment depends on the listed value of the spun-off entity, which the action feed does not carry - so this is a named gap rather than a guess.")]));
children.push(P([B("Degradation is declared, not hidden. "), T("If the action feed is unreachable, adj_close falls back to the raw close AND attrs['price_adjustment']['adjusted'] is set False with the reason. Serving unadjusted prices under the name adj_close without saying so was the original bug; failing silently would have recreated it in a new form. 14 offline tests in tests/test_nselib_fallback.py pin all of it.")]));
children.push(P("This is also where the Section 3.39 research module pays back into the product: bhavcopy.corporate_actions and adjust_prices were built to measure model skill honestly, and they are what makes the fallback correct."));

children.push(H2("3.20 Forward-looking volatility from India VIX"));
children.push(P("HAR-RV's cone is built entirely on realized (backward-looking) variance — it forecasts future risk from how volatile the recent past was. The one thing it structurally cannot see is what the market expects next, which is what option-implied volatility encodes. Injecting implied vol was a reviewer's strongest remaining idea, precisely because it targets volatility (where skill exists) rather than direction (where the SPA/Reality-Check tests proved there is none)."));
children.push(P([B("The honest data-feed finding. "), T("True single-name NSE option-chain IV is not freely or reliably available: NSE's own API is bot-protected (HTTP 403 without a real browser session; empty bodies from data centres), nselib's wrapper fails the same way, and yfinance serves no options for .NS tickers. Building a single-name IV scraper would be fragile, frequently-empty dead code — so, consistent with this project's discipline, it was not built. What is reliably free is India VIX (^INDIAVIX), NSE's forward-looking implied-vol index for NIFTY — a plain quote, already referenced by the market-context module.")]));
children.push(P("So iv_data.py uses India VIX to tilt the cone with the systematic slice of forward vol: F = (VIX-implied market daily vol) / (NIFTY recently-realized daily vol) is the implied/realized ratio (F > 1 means the market prices in more forward vol than recently realized — widen the cone; F < 1 — tighten); w = R^2 of the stock vs NIFTY is its systematic variance share (beta cancels in F); and m = clip(1 + w*(F - 1), [0.85, 1.30]) is the multiplier applied to the cone's cumulative sigma, so the band AND the empirical risk distribution stay consistent. It is leak-free (every VIX/NIFTY lookup is as-of the last bar of the passed frame, verified in test_iv_data.py) and every failure path returns a no-op multiplier of 1.0."));
children.push(P([B("The honest A/B verdict (ships off). "), T("Run through the calibration harness (compare_iv_adjust) on RELIANCE / TCS / INFY, the tilt was coverage-neutral on the calm 2021-2026 window (RELIANCE slightly worse, the other two unchanged), because in calm regimes implied ~ realized so the multiplier barely moves. Even with origins concentrated in the 2020 COVID crash it stayed coverage-neutral while correctly widening the cone (~1.4 pp) as VIX spiked — the right direction, but no measurable coverage payoff on the available data. So, like market-context and excess-return, it ships off by default (USE_IV_ADJUST = False, or iv_adjust= on run_har_rv_prediction): a principled, forward-looking, opt-in research feature, not a claimed win (Section 6.6).")]));

children.push(H2("3.21 Downside risk: semivariance, expected shortfall, and the asymmetric cone"));
children.push(P("A risk user does not care equally about both tails — they care about how bad the bad case is. Symmetric volatility treats a +5% and a -5% move as the same; for a risk instrument that is the wrong emphasis. This project adds three left-tail-specific reads, all built on HAR-RV's existing empirical conformal residual sample (so they inherit its fat tails, no Gaussian)."));
children.push(P([B("Realized semivariance (the foundation). "), T("Realized variance splits into a downside and an upside half — RS- = sum r^2 1{r<0}, RS+ = sum r^2 1{r>0}, with RS- + RS+ = RV (Barndorff-Nielsen, Kinnebrock & Shephard 2010). Patton & Sheppard (2015, Good Volatility, Bad Volatility) show the downside half carries most of the predictive content for future volatility. HAR-RV exposes the recent downside share (attrs['downside_share']) for transparency.")]));
children.push(P([B("Always-on downside reporting (the user-facing win). "), T("The Risk & Probability panel now adds, alongside VaR and the 95% range: Expected shortfall (CVaR, worst 5%) — the average outcome given you are already in the worst 5% tail (if it's a bad day, how bad on average), a more honest left-tail number than VaR; Downside vol / upside vol — the realized semideviation split (dispersion of down-moves vs up-moves); and Vol skew — their ratio, which exceeds 1 when the downside is the fatter side of the distribution. These are pure reporting of the distribution HAR-RV already estimates (no model change, no skill claim), so they are always on whenever a fat-tailed model is in the run. The math lives in the Streamlit-free risk_metrics.py and is covered by test_har_downside.py.")]));
children.push(P([B("The asymmetric cone (opt-in, A/B-gated). "), T("Going further, the cone itself can be made asymmetric (asymmetric=True): instead of a symmetric exp(+/- k*sigma) band, the lower and upper edges get separate multipliers from the left- and right-tail quantiles of the signed residuals (each at the one-sided level, static or via one-sided ACI), so a fatter loss tail produces a wider downside edge. On a single recent RELIANCE fit this correctly pushed the downside to -8.1% while pulling the upside to +4.7% (vs a symmetric +/- ~8%). But an A/B on calm 2021-26 data was mixed on tail-miss balance (better for INFY, worse for RELIANCE/TCS): splitting the calibration into two half-size per-side samples adds estimation noise when the residuals are near-symmetric, the calm-regime norm. So the asymmetric cone ships off by default (USE_ASYMMETRIC_CONE = False); it is a principled opt-in that should pay off under genuine, persistent skew (Section 6.7).")]));
children.push(P([B("Why not a full HAR-RS forecast? "), T("Feeding downside semivariance into the HAR regression (a good-vol/bad-vol forecast) is the natural extension, but it requires forecasting the semivariance components forward recursively, and — as the IV and asymmetric-cone A/Bs both showed — changes to the central variance forecast move the empirically-conformalized cone's coverage very little. So it is deliberately left as documented future work rather than built speculatively.")]));

children.push(H2("3.22 Operational robustness: reproducibility, resilient fetch, event-risk gating"));
children.push(P("Two independent reviews converged: the forecasting question is closed (the four killed experiments — market context, excess returns, IV tilt, asymmetric cone — collectively confirm the SPA wall), so the remaining robustness is operational and presentational, not more modeling. This section is that layer — making the app reliable, auditable, and honest about its serving behaviour."));
children.push(P([B("Seed-pinned reproducibility + run manifest (reproducibility.py). "), T("set_all_seeds pins every RNG (random, NumPy, TensorFlow, PyTorch-if-present) from one call at the start of each run, so a forecast is reproducible given the seed — and the NN path now goes through the same call (it previously seeded only TF/NumPy). run_manifest records the seed, interpreter and key package versions, the run parameters, the data's as-of date, and a UTC timestamp; the UI surfaces it in a Run details (reproducibility) expander. This doesn't make markets predictable — it makes experiments auditable.")]));
children.push(P([B("Resilient data fetch (safe_fetch.py). "), T("Because the app fetches live from yfinance, a transient empty response or rate-limit must not silently produce a degraded forecast that looks healthy (a weak prediction can come from bad fetch behaviour, not model weakness). fetch_with_fallback wraps the fetch with bounded retries + exponential backoff, empty/error detection, partial-data detection, and a persistent last-known-good disk cache. Every result carries attrs['source'] in {live, partial, cached_fallback}, which the data-quality gate turns into a reason code: a cache-fallback serve is downgraded to risk-cone-only (the directional call is withheld until live data returns), surfaced as 'Live fetch failed; using cached data (~N days old). Forecast downgraded to risk-cone-only.'")]));
children.push(P([B("Structured event-risk reason codes (data_quality.py). "), T("Beyond the earlier abnormal-jump check, the gate now also flags an abnormal recent volume spike (latest bar far above its 20-bar median). Both are price/volume-only event-risk signals (no fragile news/earnings scraping). When either fires, event_risk is set and the serving mode drops to risk-cone-only — a known event makes the direction especially unreliable while the cone, widened around the event, is exactly what should be shown. The UI banner reads 'Event risk detected — showing the risk cone, not directional calls.'")]));
children.push(P([B("The serving gates are a pure, tested module (gating.py). "), T("The product's trust lives in the gates, not the models, so the gate rules were extracted from the UI into a Streamlit-free module and unit-tested directly (test_gates.py): the directional call is withheld when the bucket is No edge; degraded/event-risk/cache-fallback data forces every model to No edge; conviction is the move measured in units of the model's own band (so a wide interval mechanically yields |conviction| < 1, inside the band); and a weak Diebold-Mariano p-value can never produce a High confidence. The controlled-serving contract: good data + validated edge -> directional forecast; good data + no edge -> random-walk price + risk cone; bad data -> abstain or cone-only; event / cache-fallback -> widen + withhold direction; many models but SPA no winner -> never imply a best model.")]));

children.push(H2("3.23 Economic evaluation: does the forecast make money?"));
children.push(P("Every metric up to this point is statistical — RMSE, MASE, CRPS, Diebold-Mariano, SPA. None of them answers the only question a user of a forecast actually has: would acting on it have made money, after costs? strategy_metrics.py closes that gap with the metric set from Hands-On Deep Learning for Finance Chapter 3 (Evaluating investment strategy): cumulative and monthly returns, the information coefficient, the information ratio, Sharpe and Sortino, and maximum drawdown."));
children.push(P("The distinction is not cosmetic. RMSE is dominated by the magnitude of quiet periods; P&L is dominated by the sign on the few large moves. Neither is a monotone function of the other, so a model can win on RMSE and lose money — or the reverse. And transaction costs act as a hard filter no statistical metric applies: a 52% directional hit rate at a 5-day horizon is worthless once you pay ~10 bps per round trip."));
children.push(P([B("How the conversion works. "), T("evaluate_strategy takes the per-origin (predicted, realised) horizon-end log returns, maps the forecast to a position (sign, deadband, or scaled), computes gross P&L, then charges cost on |change in position| — so a long-to-short flip costs two one-way trades and staying put costs nothing. Everything downstream (Sharpe, Sortino, drawdown, information ratio versus buy-and-hold over the identical periods) is computed on the net stream, with the gross figures reported alongside so the cost drag is visible.")]));
children.push(bullet([B("deadband mode is the economic twin of the abstention gate "), T("— only trade when the claimed move clears the round-trip cost hurdle. Same logic as gating.conviction applies to the interval: don't act on a signal smaller than your uncertainty.")]));
children.push(bullet([B("Sortino, not just Sharpe "), T("— Sharpe punishes upside and downside dispersion equally, the wrong penalty for an asymmetric return distribution; the same reasoning that motivated the semivariance work in Section 3.21.")]));
children.push(bullet([B("Overlap is flagged, not hidden "), T("— walk_forward_backtest returns a strategy block, and if the origin spacing is shorter than the horizon the trades overlap, the return stream is serially dependent, and every risk-adjusted figure is optimistic. The harness sets overlapping_origins = True and prints a caveat rather than reporting a prettier Sharpe.")]));
children.push(bullet([B("Every Sharpe travels with its standard error "), T("— sharpe_standard_error uses Lo (2002), SE ~ sqrt((1 + SR^2/2)/n) per period, annualised by sqrt(periods/year), and sharpe_significant reports whether the estimate clears 2 SE. The annualisation is load-bearing: a bare 1/sqrt(n) understates the error by sqrt(periods/year), so at 8 weekly trades it would report +/-0.35 when the true figure is +/-2.5 — the difference between 'Sharpe 3.2 looks great' and 'Sharpe 3.2 is 1.3 SE from zero'.")]));
children.push(P([B("Expected result, stated up front. "), T("Given run_spa.py's verdict (Reality Check p = 0.899, SPA p = 0.874 — no model has a selection-bias-free edge), the honest expectation is Sharpe near zero, negative after costs, and nothing statistically distinguishable. That is the metrics working, not failing. A strongly positive Sharpe on a handful of origins is a red flag to investigate — overlapping trades, too few origins, a leak — before it is a discovery. The measured outcome is in Section 6.8.")]));

children.push(H2("3.24 Deep volatility forecasting (Vol-LSTM) and CNN-LSTM"));
children.push(P("Two model additions drawn from the book, chosen to sit where this project's evidence says value can exist."));
children.push(P([B("Vol-LSTM (vol_lstm_model.py) — Chapter 5, Volatility Forecasting by LSTM. "), T("The chapter builds an LSTM on realized volatility and benchmarks it against a plain RNN and GARCH using the cumulative squared error. That is the right place to spend a neural network here: the first moment is a random walk at these horizons (Section 3.16), but volatility clusters and is genuinely forecastable — which is why HAR-RV and the GARCH layer earn their place. Vol-LSTM is therefore the deep counterpart to HAR-RV, honouring the same contract: flat random-walk point path, conformalized cone as the deliverable, and the standard run_*_prediction signature so it is directly A/B-able.")]));
children.push(P("What it can express that HAR-RV cannot: HAR-RV reads three linear lags of log-RV (day/week/month) through four OLS parameters — extremely hard to beat, but strictly linear and symmetric in the sign of returns. Vol-LSTM reads a 60-bar window of five causal channels through two stacked LSTM layers (48/24 units), so it can learn non-linear variance dynamics and, via a signed-return channel, the leverage effect — a -3% day implying more future variance than a +3% day — which the symmetric HAR regression cannot express and which GJR/EGARCH only capture with a hand-specified term. A downside-share channel supplies Patton-Sheppard 'bad volatility' as an input. The HAR averages are handed to the network as explicit channels rather than left to be rediscovered from raw lags — a cheap inductive bias that matters a lot on ~1000 rows — and capacity is deliberately modest, because N-BEATS already taught this codebase what an over-parameterised network does to a ~700-row window."));
children.push(P([B("The level-transform detail. "), T("Vol-LSTM estimates the log-to-level offset from the training block directly (c = log(mean RV) - mean(log RV)) rather than applying the Gaussian Jensen correction. This is not hypothetical hygiene: running the comparison driver showed HAR-RV, which used the Jensen form, over-stating volatility by ~1.9x (Section 6.10). The tell-tale is visible in the conformal multipliers — a debiased level yields k(h) straddling 1.96, a biased one yields k(h) near 1.0.")]));
children.push(P([B("CNN-LSTM (CNN_LSTM_model.py) — Chapter 7, Asset Allocation by LSTM over a CNN. "), T("The zoo already had four sequence architectures, but each reads the look-back window one particular way: LSTM/GRU step through every bar equally; the Transformer attends globally (the most data-hungry option on ~1000 rows); the TCN is all convolution and no recurrence; N-BEATS flattens the window and discards ordering. CNN-LSTM occupies the remaining corner — local translation-invariant pattern extraction, then temporal state. The Conv1D stack acts as a learned multi-scale indicator bank (a filter can key on 'three rising bars then a gap' wherever it appears in the window), and one max-pool halves the sequence so the LSTM models a handful of pattern activations over 45 steps rather than 90 raw bars: fewer recurrent parameters and a shorter gradient path, which is what a small-sample series wants.")]));
children.push(P([B("A leak that would have been easy to ship. "), T("The convolutions use padding='causal', not 'same'. With 'same' padding a filter reaches forward, leaking future bars of the window into earlier timesteps — harmless for an image classifier, wrong for a time series, and precisely the kind of leak that quietly inflates a validation score. test_new_models_smoke.py asserts the padding so it cannot regress.")]));
children.push(P("Both models reuse the shared engines (forecast_nn_direct for CNN-LSTM; HAR-RV's conformal + ACI machinery for Vol-LSTM's cone), so they inherit direct multi-horizon targets, training-block-only scaling, embargoed validation and per-horizon conformal intervals for free — and any future improvement to those layers lands in them automatically."));

children.push(H2("3.25 Value-at-Risk estimation and VaR backtesting"));
children.push(P("Chapter 9 (Risk Measurement Using GAN) opens with 'Estimating value at risk' and 'Computing methods and drawbacks' and closes with 'Benchmarking results'. var_models.py implements that arc, and in doing so fixes a real gap: the app already reported a 5% VaR and expected shortfall off HAR-RV's conformal residuals (Section 3.13), but nothing ever validated a VaR number. Interval coverage checks the two-sided 95% cone — a different question from 'does the left tail break exactly 5% of the time, and are the breaks independent?' That second clause is the one that matters: a VaR model can have textbook-perfect unconditional coverage and still be useless because every breach arrives in the same week, and clustered breaches are what actually destroy a position."));
children.push(P("The estimators, and the drawback each one answers:"));
children.push(table([2700, 3400, 3260], [
  ["Method", "Idea", "Known drawback"],
  ["variance-covariance", "Gaussian quantile of mu, sigma", "equity returns are leptokurtic, so it systematically under-reserves; sqrt-t scaling assumes i.i.d."],
  ["historical simulation", "empirical quantile of past returns", "unconditional — a calm estimate persists into a crisis; noisy tail (5% of 250 bars = 12 points)"],
  ["cornish-fisher", "Gaussian quantile shifted by sample skew/kurtosis", "asymptotic in the moments, and it moves the WRONG way at alpha = 5% (see below)"],
  ["FHS (filtered historical simulation)", "standardise by EWMA sigma, bootstrap the residuals, rescale by the current sigma", "needs a volatility filter; Monte Carlo noise"],
  ["generative", "block-bootstrap sampler (contiguous blocks preserve clustering and autocorrelation)", "not a marginal-only sampler; a GAN arm is available but see below"],
]));
children.push(P([B("The Cornish-Fisher trap. "), T("The expansion's kurtosis term scales with z^3 - 3z, which is positive for |z| < sqrt(3) ~ 1.732 — and the 5% quantile sits at z = -1.645, inside that range. So when excess kurtosis dominates the skew term, the 'fat-tail correction' makes the 5% quantile less negative and reduces the reserve, the opposite of the intuition. On RELIANCE's full history (excess kurtosis ~50) this drove the 5% exception rate to 10.8% against a 1.45% average reserve — comfortably the worst method in the table — while at alpha = 0.5% the sign flips and the same expansion widens dramatically. It ships as a documented cautionary reference point, not a recommendation, with both halves of the behaviour pinned by tests.")]));
children.push(P([B("On the GAN. "), T("The chapter's technique is a GAN over returns. The idea is sound but, applied to a single stock, it hits a hard data limit worth stating plainly: a GAN on ~1000 daily returns is fitting a distribution from a sample that is small even for a histogram. In practice it mode-collapses or memorises, and its tail — the only region VaR cares about — is where it is least trustworthy. That is a bad trade for a risk number. So the default generator is the stationary block bootstrap (Politis & Romano): generative in the sense that matters (novel paths with the right dependence), no training, cannot mode-collapse, reproducible. prefer_gan=True opts into a compact 1-D GAN for comparison, imports TensorFlow lazily, and falls back silently on any failure, so enabling it can never break a caller.")]));
children.push(P([B("Expected Shortfall is backtested too. "), T("Every estimator reports es_return next to var_return, and an early version of this module validated only the VaR — repeating, one level down, exactly the criticism it was written to answer. acerbi_szekely_z2 (Acerbi & Szekely 2014) closes that. ES is famously not elicitable, so it has no scoring function that pins it down the way a quantile loss pins down VaR; the Z2 test sidesteps this by conditioning on the breaches actually observed. Z2 < 0 means realised tail losses were worse than the ES promised (the dangerous direction); Z2 > 0 means the model was conservative. backtest_es and compare_es_methods mirror the VaR harness. Read the two tables together: a method can pass Kupiec (right breach frequency) while failing Z2 (breaches far worse than promised), and that combination is precisely the one that quietly under-reserves a portfolio.")]));
children.push(P([B("A bug worth recording. "), T("The first Z2 implementation built its H0 bootstrap by resampling the OBSERVED exceedance severities — which already encode the model's mis-calibration. The null therefore centred on the observed failure (measured: -1.045 instead of ~0), so the test could never reject on severity and reported p = 1.00 for a model whose realised tail was 1.9x its predicted ES. The pool is now re-centred to unit mean, imposing H0 while preserving the observed dispersion. After the fix, on fat-tailed data the Gaussian ES is correctly rejected (severity ratio 1.88, p = 0.0015) while historical simulation passes (severity ratio 1.01, p = 0.16); on genuinely Gaussian data all methods pass. A regression test pins it.")]));
children.push(P([B("The VaR backtests. "), T("kupiec_pof_test (proportion of failures, chi-squared with 1 df) asks whether the breach rate is right. christoffersen_independence_test (chi-squared, 1 df) asks whether the breaches are clustered, by testing pi_01 = pi_11 in a first-order Markov chain on the exception indicator. christoffersen_conditional_coverage sums the two on 2 df for the joint verdict. backtest_var runs a rolling out-of-sample harness (each estimate sees only past bars) and compare_var_methods ranks every method on one history. avg_var_loss is printed next to every p-value on purpose: a model can pass coverage by simply reserving an enormous amount, and the width is what that safety cost.")]));

children.push(H2("3.26 Regime novelty from a denoising autoencoder"));
children.push(P("Chapter 4 (Index Replication by Autoencoders) builds a vanilla autoencoder and then explores the denoising and sparse variants. autoencoder_regime.py implements all three on one architecture — but not for the obvious purpose."));
children.push(P([B("What it deliberately does not do. "), T("The tempting use of an autoencoder in a forecasting pipeline is dimensionality reduction: compress the feature window to a latent code and feed that to the predictor. This project has already run that experiment in a different guise and reported the answer honestly — market-context features and excess-return reframing both hurt or did nothing (Section 6.3), because at a 5-day single-name horizon the first moment is a random walk and extra representation capacity is mostly extra overfitting surface. Adding a learned compression in front of a model that cannot beat a random walk would be more of the same. So latent_codes() exists as an available research function and is wired into no forecaster.")]));
children.push(P([B("What it does instead. "), T("An autoencoder trained on one regime reconstructs that regime well and anything else badly, so reconstruction error is a distribution-shift detector — and that plugs straight into the layer that carries this project's value, the serving gate. The app already abstains on degraded data (data_quality) and on models with no measured edge (gating). What it could not see is 'today's market state is unlike anything these models were fitted on'. A backtest-derived confidence bucket is a statement about the past regime; it says nothing about a novel present. That blind spot is what this closes.")]));
children.push(P("regime_novelty returns a verdict from the reconstruction error's percentile in a held-out reference distribution:"));
children.push(table([2600, 2400, 4360], [
  ["Percentile", "Verdict", "Gate action"],
  ["below 95th", "familiar", "none — normal confidence machinery applies"],
  ["95th to 99.5th", "unusual", "annotated only ('unusual regime' in the Basis column)"],
  ["above 99.5th", "unprecedented", "gating.apply_novelty_gate forces every model to 'No edge'"],
]));
children.push(P("The split is deliberately conservative: equity data is fat-tailed and a 95th-percentile window is a normal monthly occurrence, so gating on it would abstain far too often to be useful."));
children.push(P([B("It is wired into the app "), T("behind USE_REGIME_NOVELTY in UI.py (cached per company/interval, since the answer is identical for every model in a run) and applied immediately after the data-quality gate. It ships off by default for the same reason the IV tilt and the asymmetric cone do — on the calm 2021-26 window it should almost never fire, so its value cannot be demonstrated there, and an unvalidated feature does not ship on in this project. Every failure path returns verdict='unknown', a no-op for the gate, so turning it on can only ever make the app more conservative.")]));
children.push(P([B("Three properties keep it honest. "), T("(1) Leak-free by construction — the AE is fitted on the earliest 70% of windows, its reference error distribution is measured on a held-out middle 20% it never saw (in-sample errors are systematically too small and would make everything look novel), and only then is the latest window scored; inside a walk-forward backtest an origin-truncated frame yields a genuinely out-of-sample read. (2) Scale-free — windows come from the shared compute_price_features matrix and are standardised on training statistics, so a Rs.100 and a Rs.4000 stock give comparable numbers. (3) Never fatal — TensorFlow is imported lazily and every failure path returns verdict='unknown', a no-op for the gate.")]));
children.push(P([B("Why denoising is the load-bearing variant. "), T("With a generous bottleneck a vanilla AE happily learns a near-identity map, which makes it a poor novelty detector. Injecting Gaussian noise during training only (and reconstructing the clean input) forces the network onto the data manifold, which is what makes an off-manifold window's error large. cone_multiplier (bounded 1.0-1.5) is offered as a widening suggestion but applied nowhere automatically — the HAR-RV/Vol-LSTM cones are conformally calibrated, and silently multiplying a calibrated interval by an uncalibrated factor would break the guarantee that makes it useful. Treat it as a research knob to A/B, like the India-VIX tilt.")]));

children.push(H2("3.27 Book coverage: what was taken, what was left, and why"));
children.push(P("The additions in Sections 3.23-3.26 came from Hands-On Deep Learning for Finance (Troiano et al.). That book has 13 chapters and only five fed into this codebase, so this section records the whole triage — including the items that are still open, because a partial reading presented as a complete one is the same failure mode this project spends the rest of its documentation avoiding."));
children.push(table([700, 3600, 5060], [
  ["Ch.", "Topic", "Status here"],
  ["1", "Deep learning for finance 101, autoencoder warm-up", "Folded into Section 3.26"],
  ["2", "Designing neural network architectures (MLP, CNN, RNN, LSTM, GRU)", "Already covered by the existing model zoo"],
  ["3", "Evaluating investment strategy (IC, IR, Sharpe, Sortino, drawdown)", "IMPLEMENTED — Section 3.23"],
  ["3", "Tuning the model (grid / random / Bayesian search)", "IMPLEMENTED — Section 3.28, nested; found no generalising gain"],
  ["3", "Going live (paper portfolios, benchmarking live vs model)", "IMPLEMENTED — Section 3.29"],
  ["4", "Index replication by autoencoders (vanilla / denoising / sparse)", "IMPLEMENTED, repurposed as a novelty gate — Section 3.26"],
  ["5", "Volatility forecasting by LSTM (vs RNN, vs GARCH)", "IMPLEMENTED — Section 3.24"],
  ["6", "Trading rule identification by CNN (3-class, asset-stratified)", "IMPLEMENTED — Section 3.30 (tabular GBM, not a CNN; reason given there)"],
  ["7", "Asset allocation by LSTM over a CNN", "IMPLEMENTED — Section 3.24"],
  ["8", "Digesting news using NLP with BLSTM", "Skipped — needs a licensed news feed; the same fragile, frequently-empty dead code argument that killed single-name option IV"],
  ["9", "Risk measurement using GAN", "IMPLEMENTED via FHS + block bootstrap rather than a GAN — Section 3.25"],
  ["10", "Chart visual analysis by transfer learning (ResNet50)", "Skipped — rendering price windows as images to reuse ImageNet features discards numeric precision the models already have"],
  ["11", "Better chart analysis using CapsNets", "Skipped — exotic, little independent replication, and this project's evidence is that more capacity is the wrong direction"],
  ["12", "Training trader robots using deep RL (DQN)", "Skipped — needs a simulator or far more data, and optimises a directional policy where SPA says there is no edge"],
  ["13", "What next? (AutoML, distributed training, HFT)", "AutoML overlaps the tuning gap; the rest is infrastructure, not modelling"],
]));
children.push(P("All three of the genuine gaps flagged in the original triage have since been closed: hyperparameter tuning in Section 3.28, the forward paper-portfolio log in Section 3.29, and cross-sectional classification in Section 3.30. The original reasoning is kept below, because WHY each was deprioritised is as much a part of the record as the eventual result."));
children.push(P([B("1. Hyperparameter tuning (Ch. 3, pp. 128-135) — since closed, see Section 3.28. "), T("Every model in this repo carried hardcoded hyperparameters: XGBoost's max_depth=5 and learning_rate=0.03, the LSTM's 64/64/32, Vol-LSTM's 48/24, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search. The book covers grid search, random search — noting that random beats grid at equal budget, because a regular lattice re-tests irrelevant factors — and Bayesian optimisation (SMBO/TPE), which directs the search with a surrogate model instead of treating each trial as independent.")]));
children.push(P([B("Why it was deprioritised rather than forgotten: "), T("with the SPA verdict at p = 0.87, tuning is very likely to buy a better-FIT model rather than a PREDICTIVE one, and a search run against a walk-forward objective on ~40 origins is an efficient way to manufacture exactly the data-snooped edge Section 3.16 exists to detect. If it is built it must be nested (inner search on past data only, outer evaluation untouched — the structure calibration.validate_gate already uses) and its winner must be run through run_spa.py before any improvement is believed. The place it is most likely to genuinely pay is Vol-LSTM and HAR-RV's window lengths, since volatility IS forecastable and those windows were picked by convention, not measurement.")]));
children.push(P([B("2. Classification + asset stratification (Ch. 6) — since closed, see Section 3.30. "), T("The chapter frames trading as 3-class classification (buy / do nothing / short) over a 30-day horizon, trained across 2,700 NASDAQ stocks with an asset-stratified split — fit on 700 names, validate on 300 entirely different ones. Two things there are absent from this project.")]));
children.push(bullet([B("There is no classifier at all. "), T("Every model regresses a price or a variance, and P(up) is derived second-hand from a regression interval. The calibration harness measured that derived probability at ECE ~ 0.31 — badly overconfident. A purpose-built classifier with isotonic or Platt calibration is the standard fix, and an explicit 'do nothing' class is a natural fit for a product whose central feature is abstention.")]));
children.push(bullet([B("Pooling across a universe attacks the actual binding constraint. "), T("Every 'no edge' result here rests on ~1000 rows for one ticker. The book's stratification turns that into millions of rows and validates on unseen ASSETS, a stronger generalisation claim than unseen TIME. This project's own cross-sectional probe found 12-1 momentum with the right sign but t ~ 1, and explicitly concluded it needs hundreds of names — Chapter 6 is the recipe for exactly that. It is a deliberate product fork (rank a universe, don't forecast one name), which is why it was not slipped in as a tweak.")]));
children.push(P([B("3. Going live: paper portfolios and live-vs-model benchmarking (Ch. 3, pp. 135-142) — since closed, see Section 3.29. "), T("The book's deployment arc is prototype, transition, paper portfolio, soft launch, live, with continuous benchmarking of live results against model diagnostics. strategy_metrics simulates a portfolio BACKWARDS over historical origins; there is no FORWARD prediction log, no realised-outcome tracking, and no calibration-drift monitor. This is already listed in the caveats as deferred, and it stays the right first thing to build the moment this stops being a single-user, train-on-demand app — a cone calibrated at fit time decays silently as the regime moves, and nothing here would currently notice.")]));

children.push(H2("3.28 Hyperparameter search, nested so it cannot cheat"));
children.push(P("Book Ch. 3's 'Tuning the model' (pp. 128-135) covers grid search, random search — noting that random beats grid at equal budget, because a regular lattice keeps re-testing values of parameters that turn out not to matter — and Bayesian optimisation (SMBO/TPE), which directs the search with a surrogate model instead of treating every trial as independent. tuning.py implements all three."));
children.push(P("Until now, every model here carried hardcoded hyperparameters: XGBoost's max_depth=5 and learning_rate=0.03, the LSTM's 64/64/32, Vol-LSTM's 48/24, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search."));
children.push(P([B("Why a naive search would have been worse than none. "), T("With the SPA verdict at p = 0.87, a search over N configurations evaluated on the same origins you later report is an efficient machine for manufacturing exactly the snooped edge Section 3.16 exists to detect: 50 configurations is 50 more chances for noise to look like skill. So the module has two structural guards, not optional ones.")]));
children.push(num([B("nested_search is the only entry point that produces a reportable number. "), T("The search sees a training prefix (default 70%); the tail is untouched during the search and scored exactly twice at the end — once for the tuned config, once for the default. The output therefore answers 'did tuning help out of sample?', not 'what fit best in-sample?', and an inner win with a holdout loss — the signature of overfitting the search itself — is made visible rather than hidden behind a single best-score number.")]));
children.push(num([B("Every result carries its own selection-bias warning, "), T("naming the number of configurations tried and pointing at run_spa.py as the required next step. A search result is a hypothesis, not a finding.")]));
children.push(P([B("TPE, and a bug worth recording. "), T("The Bayesian sampler is a ~40-line Tree-structured Parzen Estimator (no GP library, replacing the book's hyperopt import): split the trials into a good set (best gamma fraction) and a bad set, model p(param | good) and p(param | bad) as smoothed histograms, then sample from the good distribution and keep the candidate maximising l(x)/g(x) — equivalent to maximising Expected Improvement. The first version took the deterministic argmax over sampled candidates and COLLAPSED: once a configuration looked best it was proposed again and again. Measured on a 10x10 space it burned 12 of 30 trials on a single point and finished worse than random search (-1.845 vs -1.296). Suppressing already-evaluated candidates (with a random unseen fallback) restores the exploration a continuous-space TPE gets for free.")]));
children.push(table([3400, 2600, 3360], [
  ["Sampler", "Budget", "Mean best score over 6 seeds"],
  ["Random", "30 trials", "-1.429"],
  ["TPE (after the fix)", "30 trials", "-0.001"],
  ["Grid (exhaustive)", "100 trials", "-0.092"],
]));
children.push(P("TPE at 30 trials now beats an exhaustive 100-trial grid, because the grid can only ever land on lattice points. A regression test pins the ordering."));
children.push(P([B("What it was pointed at, and what happened. "), T("Not the price models — the honest expectation there is a better-fitting model with the same absent edge. The promising target is the volatility side, where signal demonstrably exists and the windows were picked by convention: HAR-RV's canonical Corsi lags (1, 5, 22) have never been measured on NSE names. qlike_objective_har scores the VARIANCE forecast (not the cone — the conformal layer adapts to whatever the variance does, which is how the 1.9x level bias hid for so long) using QLIKE, the loss robust to r^2 proxy noise. The result is in Section 6.12.")]));

children.push(H2("3.29 Going live: the forward prediction log and paper portfolio"));
children.push(P("Book Ch. 3's 'Going live' (pp. 135-142) walks prototype, transition, PAPER PORTFOLIO, soft launch, live, with continuous benchmarking of live results against model diagnostics. prediction_log.py implements the parts that apply to a single-user app."));
children.push(P([B("Every evaluation before this one was backward. "), T("Pick historical origins, re-fit, score against what already happened. That is the right way to BUILD a model and an inadequate way to OPERATE one, because it can only tell you how the model would have done on data that already existed when you tested it. Nothing recorded what the app actually served, leaving three questions unanswerable: is the cone still calibrated on what we served; did the confidence gate sort realised skill; and would trading the served signals have made money.")]));
children.push(P([B("Why append-only is the whole point. "), T("A prediction is written before its outcome exists and is never rewritten — only annotated with the realised price once that price is knowable. That single property makes the resulting numbers immune to the data-snooping the rest of this project works hard to correct: no origin selection, no re-fitting, no choice of which forecasts to count. Every served forecast is in the sample, including the embarrassing ones.")]));
children.push(P([B("What it records. "), T("One JSONL row per (run, model, horizon step), including the GATE VERDICTS in force at serve time — confidence bucket, data-quality mode, novelty verdict. Without that context the log could say whether forecasts were accurate but not whether the gates were doing their job, which is the more valuable question for a product whose central feature is abstention.")]));
children.push(P([B("Alerting that can be trusted. "), T("drift_report compares live coverage to the nominal 95% with a binomial confidence interval and fires ONLY when the CI excludes the target. Below that bar the sample cannot distinguish drift from noise, and an alert that fires on noise teaches people to ignore alerts. It also isolates the most recent N predictions per model, so a year of good coverage cannot bury five misses in the last ten. Verified end to end: an honest cone (0.933, CI [0.87, 1.00]) stays silent; a deliberately over-confident one (0.083, CI [0.01, 0.15]) fires with a 'recalibrate before trusting it' message.")]));
children.push(P([B("A third self-inflicted bug, caught the same way. "), T("gate_validation's monotonicity check was hits[i] <= hits[i+1] — which EVERY TIE satisfies. An end-to-end run where both buckets had identical realised accuracy (0.517 vs 0.517) was duly reported as 'the gate IS informative'. A gate that discriminates nothing being declared a success is precisely the over-claim this project exists to avoid. It now requires a strict spread and reports 'FLAT — the labels are not discriminating yet' otherwise, with a regression test that fails against the old behaviour.")]));
children.push(P([B("It ships ON "), T("(USE_PREDICTION_LOG in UI.py), unlike every other toggle — because it changes no forecast and makes no claim, it only records what already happened, and a log that is off by default records nothing and is therefore worthless. Writing is best-effort and wrapped: a log failure is not a forecast failure. Read it with run_drift_report.py --resolve.")]));

children.push(H2("3.30 Cross-sectional classification: pooling the universe"));
children.push(P("Book Ch. 6 ('Trading Rule Identification by CNN') frames trading as 3-class classification — buy / do nothing / short — trained across 2,700 NASDAQ stocks with an ASSET-STRATIFIED split: fit on 700 names, validate on 300 entirely different ones. cross_sectional_panel.py builds that panel; cross_sectional_model.py is the model."));
children.push(P([B("Why this was the highest-upside item in the book for this project. "), T("Every 'no edge' verdict here — SPA p = 0.87, MASE > 1 almost everywhere, six of seven models losing money — was measured on ~1000 rows of a SINGLE ticker. That is the binding constraint, and no additional architecture fixes it. Pooling changes both the sample size and the question: not 'what will this stock do?' (absolute, and the evidence says random walk) but 'which of these will outperform the others?' (relative, with a far better documented empirical basis). This project's own earlier probe found 12-1 momentum with the right sign at t ~ 1 and concluded it needed hundreds of names.")]));
children.push(P([B("The asset split is a stronger claim than the walk-forward split used everywhere else. "), T("A temporal split asks 'does this survive into next month?'; an asset split asks 'does this exist in stocks the model has never seen?' — much harder to satisfy by memorisation, since there is no shared price level, regime history, or idiosyncratic noise to latch onto. The default combined mode requires BOTH: unseen names and unseen dates.")]));
children.push(P([B("Three leakage traps it is built against. "), T("(1) Survivorship — the universe is an explicit literal list, not a live index scrape, because an index API returns TODAY's constituents and back-testing those over ten years silently selects the winners; every dropped ticker is recorded with a reason. (2) Cross-sectional look-ahead — every rank is computed within a single date's cross-section, never from full-history statistics, and a test proves truncating the panel does not change a past date's rank. (3) Forward columns as features — one fwd_return left in the feature list and the classifier scores ~100% on a near-random problem, so the exclusion list is centralised and asserted directly.")]));
children.push(P([B("Why a gradient-boosted tree, not the book's CNN. "), T("The book renders indicator windows as 2-D images because traders read charts as pictures. Here the features are already a tabular cross-section, and convolution's inductive bias — translation invariance over adjacent pixels — is not merely unhelpful but wrong: the adjacency between rank_mom_21 and rank_vol_21 is an artifact of column order. This project has also already paid twice for the 'add capacity' lesson (N-BEATS, Vol-LSTM). The interesting variable is the pooling and the split, so the architecture is held boring on purpose.")]));
children.push(P([B("The calibration step is the part that matters most. "), T("A classifier's raw predict_proba is a score that happens to lie in [0, 1], and gradient boosting is systematically overconfident. The model is fit on a proper-train block and its probabilities mapped through a per-class isotonic regression fitted on a separate, TEMPORALLY-split calibration block (temporal, not random — names on the same day share the market move, so a random split would not be independent of the fit). Isotonic rather than Platt because it is non-parametric and can correct an arbitrary monotone distortion. ECE is reported before AND after, so the effect is measured rather than asserted.")]));

// 4. Evaluation
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(H2("3.31 Testing the abstention claim: class weighting, and a t-statistic that was wrong"));
children.push(P("Section 3.30 reported that the cross-sectional classifier called “do nothing” for 99.6% of validation rows, and read that as EMERGENT ABSTENTION - a model volunteering that it had no view. That reading had an obvious duller rival which had not been ruled out: the neutral class is the largest by construction (42.3%), the classifier was fitted with class_weight=None, and an unweighted multiclass objective has a standing incentive to drift toward the majority class. “Concluded it had no view” and “took the cheapest route to a good log-loss” produce IDENTICAL accuracy columns. run_class_weight_ab.py settles it: same panel, same split, same seed, same hyperparameters, one variable changed."));
children.push(table([3600, 1500, 1400, 1400, 1460], [
  ["Arm", "Abstention", "Macro F1", "Val ECE", "Rank IC (FM t)"],
  ["A - class_weight=None (shipped)", "0.9970", "0.2021", "0.0116", "+0.0203 (t=1.10)"],
  ["B - class_weight='balanced'", "0.9895", "0.2073", "0.0091", "+0.0194 (t=1.01)"],
]));
children.push(P("Mean of three seeds (42 / 7 / 2024), 39 NSE names, 74,704 labelled rows, 12 unseen validation tickers, 574 validation dates."));
children.push(P([B("The abstention survives. "), T("Balanced weighting raises the payoff for calling short or buy by roughly 1.4x relative to neutral, and the model still declines on 98.95% of rows - a shift of 0.74 percentage points. It abstains EVEN WHEN THE OBJECTIVE ACTIVELY PAYS IT TO CALL. That makes the original reading stronger rather than weaker, and it is now a measured claim instead of an inference. Skill remains null in both arms (no seed reaches |t| > 2), so this is abstention without hidden signal, exactly as reported. class_weight is now a parameter of build_classifier, defaulting to None so every previously published figure remains the shipped configuration.")]));
children.push(P([B("Bug one: the IC t-statistic assumed independent observations. "), T("ic_t_stat(ic, n) is the ordinary correlation t-test - valid for a single ticker's time series and wrong for a pooled panel, because names on the same date share the market move, so 6,884 rows across 574 dates carry nothing like 6,884 independent observations. The fix is the factor-research standard (Fama-MacBeth): compute the IC WITHIN each date's cross-section, then t-test that series across dates, with a Newey-West correction because a 5-day forward return sampled daily makes consecutive dates' ICs overlap by four days. strategy_metrics.ic_by_date, newey_west_se and fama_macbeth_ic implement it, and evaluate now reports the Fama-MacBeth figure as the headline with the pooled one labelled as overstated.")]));
children.push(P([B("Honesty about magnitude: on this data the two mostly agree. "), T("The labels are already market-neutral and dispersion-scaled, so much of the date effect is removed before the IC is computed - which is why the originally reported t = 0.92 was not badly wrong. But the correction changed one verdict in three: at seed 2024 the pooled statistic gives t = 2.43, over the conventional threshold and reportable as a finding, while the honest one gives t = 1.69, which is noise. One false positive in three seeds is the whole argument for the correction. test_pooled_t_stat_is_inflated_by_a_shared_market_effect builds a panel with a pure daily shock and zero cross-sectional signal, where the pooled read returns IC > 0.5 at t > 20 and the Fama-MacBeth read correctly returns nothing.")]));
children.push(P([B("Bug two: the classifier was not reproducible. "), T("Two runs of the SAME SEED gave abstention 0.9461 and 0.9552. LightGBM's multi-threaded histogram construction is not bit-reproducible by default - float addition order varies with thread scheduling. A project that ships a seed-pinned reproducibility manifest was quietly failing to reproduce this model, and an A/B is unreadable when an arm does not reproduce ITSELF. Fixed with deterministic=True, force_col_wise=True, n_jobs=1, pinned by test_classifier_is_bit_reproducible_across_fits. It costs fit time; that is the correct trade for a research model.")]));
children.push(P("Both bugs came out of the same exercise, and neither was the thing being tested - which is the argument for running the counterfactual rather than defending the original reading."));

children.push(H2("3.32 Architecture as configuration, and the hole it closed in the manifest"));
children.push(P("This project ships an auditable per-run manifest (Section 3.22) recording the seed, package versions and request parameters - and it did NOT record the network shape. That is a reproducibility claim with a hole in it: pinning the seed reproduces a fit only if the architecture is also fixed, and the layer stacks lived as literals inside DL_model.py, CNN_LSTM_model.py and vol_lstm_model.py. Change a hidden size and every earlier manifest silently describes a model that no longer exists, while still presenting itself as complete. architectures.py closes it, with two mechanisms doing deliberately different jobs."));
children.push(P([B("Declared specs drive the build. "), T("SPECS holds each network as a JSON-serialisable object - recurrent units, dropout schedule, filters, kernel and pool sizes - and the builders read from it. Override with an architectures.json (or STOCKAPP_ARCH_FILE) to change a network without touching model code. The defaults reproduce the previous hardcoded stacks EXACTLY, and test_defaults_match_the_previously_hardcoded_stacks pins that: introducing the module had to change no forecast, or every published figure would silently refer to a different model.")]));
children.push(P([B("The manifest records the realised architecture, not the declared one. "), T("describe() reads layer types, output shapes, parameter counts, optimizer and loss back off the COMPILED KERAS OBJECT. This is the load-bearing choice. A spec merely stored beside a run is decoration - the same “configuration theatre” config.py's tests exist to prevent - whereas introspection cannot drift from the fit it describes, and it covers models whose builders are not spec-driven.")]));
children.push(P("A run now carries a compact block per model, for example: CNN-LSTM = { n_layers: 14, n_params: 36677, optimizer: Adam, loss: huber, fingerprint: 6d57343ffa8b, spec_driven: true }."));
children.push(P([B("The fingerprint "), T("is a stable 12-character hash of the realised layer stack, so “was this the same network?” is answerable in one token instead of a nested diff. manifest_block deliberately stores only the summary: a six-model layer dump would bury the seed and versions sitting beside it in the Run-details expander.")]));
children.push(P([B("Honest scope, reported rather than glossed. "), T("Spec-driven today: DL (LSTM/GRU), CNN-LSTM, Vol-LSTM - the three whose builders take their sizes as arguments. N-BEATS, TCN and Transformer are INTROSPECTION-ONLY: their shapes are recorded faithfully but not yet controlled from here. The spec_driven field says which is which on every record, and test_spec_driven_flag_is_honest_about_coverage fails if a model claims control it does not have.")]));
children.push(P([B("A bug this caught in its own wiring. "), T("The first version passed forecast_nn_direct's desc string (“CNN-LSTM forecasts”) where the registry key (“CNN-LSTM”) was expected, so the lookup missed and the manifest reported spec_driven=false for a model that IS spec-driven. Under-claiming is still misreporting, and it was invisible until a real end-to-end run was inspected. Every deep model now passes its key explicitly, checked statically by test_every_deep_model_passes_its_registry_key_not_its_display_string so the guard costs no training time.")]));
children.push(P("Architecture overrides are surfaced in the console startup banner alongside feature-flag overrides, because a run on a non-default network is not the shipped configuration and its numbers need reading that way. Running python architectures.py dumps every spec with its fingerprint."));

children.push(H2("3.33 Fundamentals: the right experiment, blocked by data - the seventh negative result"));
children.push(P("Every model here transforms the same OHLCV series, and six negative results point at the INFORMATION, not the architecture, as the binding constraint. Fundamentals are the cheapest second axis available - unlike news/NLP they need no licensed feed - so the obvious next experiment was to add valuation, margin and leverage features to the pooled panel (Section 3.30) and re-run the classifier at a horizon where such signals plausibly act: a year, not five days. fundamentals.py implements the machinery; run_fundamentals_audit.py establishes that the experiment CANNOT CURRENTLY BE RUN, and that finding - not a model result - is the deliverable."));
children.push(P([B("Feasibility first, deliberately. "), T("Building the panel and discovering the coverage problem afterwards would have meant reporting a null that was really a data artefact. That is exactly the confusion Section 3.31 had to disentangle for the abstention result, and having paid for that lesson once, the audit came first.")]));
children.push(table([4600, 4760], [
  ["Measure", "Result (12 NSE names, quarterly statements)"],
  ["Tickers with any data", "12 / 12"],
  ["Median reporting periods per ticker", "5 (max 6)"],
  ["Median first knowable date", "2025-05-15"],
  ["Covered span", "1.28 years of a 7.99-year panel - 16%"],
  ["Independent 1-year label dates", "~1"],
]));
children.push(P("For scale: Section 3.31's null result had 574 validation dates and still only reached t = 0.45. One label date cannot detect an effect of any size. yfinance returns a handful of recent filings, not a decade of restated history, so any cross-sectional fundamental result built on it would measure coverage rather than signal."));
children.push(P([B("The trap this module is built around. "), T("Ticker.info returns TODAY's trailing P/E, margins and book value, and it is available for every ticker over any date range - which makes it the single most inviting mistake in the field. Joining it onto a 2019 panel row gives that row information that did not exist for another six years, and the resulting classifier looks excellent while measuring nothing.")]));
children.push(bullet([B("The join refuses. "), T("current_snapshot tags its output point_in_time=False, and as_of_join RAISES on such a frame rather than warning. Being unable to make the mistake beats being told not to.")]));
children.push(bullet([B("Features are stamped by publication, not period end. "), T("A quarter ending 31 March is not public on 31 March - SEBI LODR allows 45 days. Dating features by period end leaks up to a quarter of forward information, so available_from adds the lag and the merge is a backward as-of on that date. Where the true availability date is uncertain the module errs LATE: assuming publication earlier than reality leaks, assuming it later merely delays a feature.")]));
children.push(P("test_as_of_join_never_shows_a_row_a_future_statement and test_as_of_join_refuses_a_non_point_in_time_frame pin both. Ratios are derived from raw line items rather than read off info, for the same reason."));
children.push(P([B("What would change the answer. "), T("A point-in-time vendor with restated history (Compustat, CapitalIQ, Refinitiv) - or, at no cost but time, an archive built forward from today. prediction_log.py (Section 3.29) already demonstrates that pattern: record now, evaluate when the sample matures. Recording quarterly statements from this point on would make the experiment runnable in a few years, which is unsatisfying and is the honest timescale.")]));
children.push(P([B("This stacks with the power problem, it does not replace it. "), T("Section 3.31 showed 39 names are too few to detect a cross-sectional IC even when one exists; roughly 55-60 validation names are needed for t = 2. Fundamentals would have to clear BOTH bars. Running them on the current universe, even with perfect history, would produce another underpowered null. The module ships complete and tested so that the day a data source appears, the experiment is a configuration change rather than a rewrite.")]));

children.push(H2("3.34 Epistemic uncertainty and psychological tolerance (Klaas) - the eighth negative result"));
children.push(P("Two ideas taken from Machine Learning for Finance (Klaas). One works and ships; one FAILED ITS OWN TEST and is documented as a failure."));

children.push(H3("The diagnostic that came free"));
children.push(P("Chapter 8 offers a rule of thumb: “You should have 10 times as many samples as there are features.” Applied to the five deep models on ~1000 daily bars:"));
children.push(table([2600, 1500, 1500, 1400, 1200, 1160], [
  ["Model", "look-back", "input dim", "samples", "ratio", ""],
  ["DL (LSTM/GRU)", "90", "9", "910", "101:1", "OK"],
  ["CNN-LSTM", "90", "9", "910", "101:1", "OK"],
  ["TCN", "90", "9", "910", "101:1", "OK"],
  ["Transformer", "90", "9", "910", "101:1", "OK"],
  ["N-BEATS", "60", "540", "940", "1.7:1", "UNDER-DETERMINED"],
]));
children.push(P("N-BEATS uses flatten=True, so its window becomes 540 independent inputs against 940 samples - about one sixth of the threshold. The recurrent and convolutional models share weights across time and see 9 inputs per step. This project had already documented N-BEATS underperforming and filed it as a behavioural lesson (“the add-capacity lesson”); it has a STRUCTURAL explanation, and one that was measurable all along."));

children.push(H3("Time under water (Chapter 4) - shipped"));
children.push(P("The book lists four backtest biases. Three - look-ahead, survivorship, overfitting - this project already guards against. The fourth it did not measure: “Consider an algorithm that loses money for four months in a row before making it all back in a backtest... if the algorithm loses money for four months in a row in real life and we don't know whether it will make that amount back, then will we sit tight or pull the plug?”"));
children.push(P([B("max_drawdown answers HOW DEEP. "), T("Depth is what you lose; DURATION is what makes someone abandon a strategy before it recovers - and a backtest reader knows the recovery happened, which is exactly the knowledge a live operator lacks. strategy_metrics.time_under_water adds longest_underwater, currently_underwater, fraction_underwater and longest_losing_streak, in years when a period count is supplied. currently_underwater is reported separately on purpose: a backtest that ends mid-drawdown looks calmer than it was, and the run still open at the end is the one an investor would actually be sitting in.")]));

children.push(H3("MC-dropout epistemic uncertainty (Chapter 4) - built, tested, FAILED"));
children.push(P("Every interval this project ships is ALEATORIC: the conformal cone measures how wrong the fitted model has BEEN and takes the model as given. It cannot say how much a forecast would move under a different plausible fit - EPISTEMIC uncertainty, which is large exactly when data is scarce. Since Sections 3.31 and 3.33 established sample size as the binding constraint, that silence is on the one axis that matters most. epistemic.py implements the book's method: activate dropout at prediction time, run n passes, take the spread. Cheap - no retraining, and every deep model already carries dropout."));
children.push(P([B("Adding an uncertainty number is easy; showing it means something is not. "), T("So the module shipped with a prediction that could fail: if this measures parameter uncertainty, N-BEATS - the 1.7:1 model - should be the most uncertain.")]));
children.push(table([2600, 2000, 2400, 2360], [
  ["Model", "dropout", "epistemic share", "data/input"],
  ["DL (LSTM)", "0.30", "0.104", "101"],
  ["CNN-LSTM", "0.20", "0.294", "101"],
  ["TCN", "0.15", "0.539", "101"],
  ["N-BEATS", "0.20", "0.331", "1.7"],
]));
children.push(P([B("It failed. "), T("Rank correlation between data-per-input and uncertainty: -0.26 - the predicted sign, but weak - and the most uncertain model is TCN, not N-BEATS.")]));
children.push(P([B("The check also caught a genuine bug on the way. "), T("The first version normalised the spread by the mean prediction; since the target is a cumulative log return centred near zero, that denominator was arbitrary (implied values spanned 0.0015 to 0.0147 across four models) and produced a rank correlation of +0.77 - confidently backwards. Dividing by the model's own conformal sigma is the right comparison and was determinable in advance: both are in log-return units, and the ratio asks what share of this model's uncertainty is parameter uncertainty rather than residual noise. Correcting a broken denominator is legitimate; tuning further until the test passed would be the data-snooping this project exists to avoid, so the corrected result stands as the answer.")]));
children.push(P([B("Why it fails is identifiable, and it is not the data. "), T("The lowest-dropout model (TCN, 0.15) has the HIGHEST spread and the highest-dropout model (DL, 0.30) the LOWEST, so the rate is not driving it either. What drives it is TOPOLOGY: TCN puts dropout inside every dilated residual block, so variance compounds across many stochastic layers, while DL's dropout sits between recurrent layers whose 90-step state averages the noise away. MC-dropout spread is not comparable across architectures unless the dropout rate is itself calibrated per model - the known limitation that motivated Concrete Dropout.")]));
children.push(P([B("So it ships off "), T("(USE_EPISTEMIC), documented as a failed cross-model comparison rather than quietly presented with a plausible story. It may still be meaningful WITHIN one model across dates or regimes - but that has not been tested, so it is not claimed. It is reported separately from the 95% band and never folded into it: trading a measured coverage guarantee for an unvalidated one would be a bad exchange.")]));
children.push(P([B("Two implementation details worth keeping. "), T("Sampling uses the per-call training=True argument rather than the book's TF 1.x set_learning_phase(1), because the global flag STAYS SET and silently makes every later predict stochastic - test_sampling_does_not_leave_inference_stochastic pins that. And a model without dropout reports available=False rather than a spread of zero, since every pass through a deterministic network is identical and zero would read as supreme confidence rather than the absence of a measurement.")]));

children.push(H3("What the book confirms rather than adds"));
children.push(P("Chapter 4 endorses the forward log directly - “deploy models silently and test them in the future... executes only virtual trades” - which is Section 3.29. Chapter 8's “Unit testing data” is data_quality.py. Both predate reading it. Deliberately not taken: NLP (Ch. 5) needs the licensed feed already parked in Section 3.27; RL (Ch. 7) hits the power wall Section 3.31 measured; computer vision (Ch. 3) is the wrong inductive bias for a tabular cross-section (Section 3.30). Kalman filters (Ch. 4) were the one item left genuinely open by that review, and have since been built - see Section 3.35."));

children.push(H2("3.35 The Kalman filter: the model class that was missing"));
children.push(P("The nineteen models here all did the same thing structurally: fit FIXED parameters over a training window, freeze them, forecast. A Kalman filter carries a STATE re-estimated at every bar, so the level and slope it extrapolates from are the ones implied by the most recent data, continuously reweighted against their own uncertainty. That is a different answer to non-stationarity than refitting on a rolling window, and it was the one gap Machine Learning for Finance left genuinely open (Section 3.34)."));
children.push(P("kalman_model.py implements a DAMPED LOCAL LINEAR TREND on log prices: level_t = level_{t-1} + phi*slope_{t-1} + w_level; slope_t = phi*slope_{t-1} + w_slope; y_t = level_t + v. phi in [0,1] damps the trend, so the h-step forecast adds slope * (phi + phi^2 + ... + phi^h) - a geometric sum that CONVERGES rather than extrapolating a straight line. That matters more here than usual: an undamped slope fitted to a recent run-up would project it indefinitely, which is precisely the failure the evaluation layer exists to catch. The model is also allowed to conclude it is a random walk, and the fitted parameters are surfaced so it is visible when it does."));

children.push(H3("The result, on 7,696 real RELIANCE bars over 40 walk-forward origins"));
children.push(table([3000, 2400, 2200, 1760], [
  ["Band", "Coverage (target 0.95)", "95% CI", "Mean width"],
  ["Native (Kalman Gaussian)", "0.985", "[0.968, 1.002]", "46.60"],
  ["Conformal (shipped default)", "0.975", "[0.953, 0.997]", "43.70"],
]));
children.push(P("Both OVER-cover - conservative rather than broken - and at 200 observations the two are NOT DISTINGUISHABLE; their confidence intervals overlap heavily. Conformal is about 6% narrower, which is why it stays the default, but this should not be reported as a win."));
children.push(P([B("The genuinely interesting finding is the one the book advertised: "), T("the native interval reaches near-nominal coverage with NO CALIBRATION SET AT ALL. No held-out residuals, no quantile, nothing tuned - it falls straight out of the state covariance. Not one of the other nineteen models can do that. On this evidence the Gaussian assumption survives contact with fat-tailed equity data better than expected, though 200 observations is not enough to say it survives the tails specifically.")]));
children.push(P([B("Point forecast: "), T("RMSE 11.33 against the random walk's 11.15 - 1.6% worse, i.e. parity. That is the EXPECTED result, not a disappointment: 70% of origins fitted a degenerate slope, mean phi = 0.32. On a near-efficient price series a local-level Kalman fit IS an adaptive random walk, and it says so instead of manufacturing a trend. Its value here is the interval and the fitted structure, not the point forecast - the same honest position HAR-RV occupies.")]));

children.push(H3("A bug the tests caught, which would otherwise have been invisible"));
children.push(P("The first implementation fixed r = 1 and scored the RAW Gaussian likelihood over the noise ratios. On log-price data of scale ~0.02 that rewards whichever ratio pushes the innovation variance towards 1, so it drove q -> 0 regardless of the truth: a simulated process with a known q/r of 4.0 was fitted as 0.000, and the likelihood fell monotonically across the whole grid."));
children.push(P([B("Nothing downstream looked wrong. "), T("The model produced a flat forecast with a widening cone and plausible prices - exactly what a correct fit on a random walk produces. Only test_fit_recovers_a_known_signal_to_noise_ratio, run against a SIMULATED process with known parameters, exposed it. The fix is the concentrated (profile) likelihood: sigma^2 is profiled out analytically, leaving a likelihood in the ratios alone.")]));
children.push(table([3200, 3080, 3080], [
  ["True q/r", "Fitted (after fix)", "Verdict"],
  ["4.00", "5.00", "within grid resolution"],
  ["0.25", "0.20", "within grid resolution"],
  ["100.00", "160.00", "within grid resolution"],
]));
children.push(P([B("The lesson generalises past this model: "), T("a state-space fit that cannot recover known parameters from simulated data is not fitting anything, and no amount of plausible-looking output on real data will reveal that. It is the same shape as the silent bugs found across the sample repositories - a no-op normaliser, a leaky interpolator, a callback that could never fire.")]));

children.push(H3("Implementation notes"));
children.push(P("Estimation is a coarse grid over (q_level/r, q_slope/r, phi) with a local refinement - grid rather than an optimiser because state-space likelihoods are notoriously multi-modal and flat in places, and three parameters are cheap. Pure NumPy, no SciPy, consistent with var_models.py. The 2x2 covariance algebra is written out rather than delegated to numpy.linalg, which keeps the scalar Kalman gain visible to a reader checking it. use_conformal=True is the shipped default and the native half-width is recorded alongside in attrs either way, so the comparison above can be re-run at any time. The model appears in the app as “Kalman (local trend)” - the suite is now 20 models."));

children.push(H2("3.36 Feature drift and attribution - the ninth negative result, arriving from a new direction"));
children.push(P("Two more items from Klaas Chapter 8, both answering questions this project could not previously answer. Neither improves accuracy; one improves OPERATIONS, the other improves DIAGNOSIS. The second produced a genuine finding."));

children.push(H3("Feature-distribution drift: the leading indicator"));
children.push(P("prediction_log.drift_report monitors OUTCOME drift - live interval coverage against nominal 95%, binomial-CI-gated (Section 3.29). That is the right headline, but it is a LAGGING indicator: at a 5-day horizon it needs weeks of matured forecasts before it can say anything. If the INPUTS have moved away from what a model was fitted on, its forecasts are extrapolations regardless of how the last few intervals happened to land. feature_drift.py measures that directly."));
children.push(P([B("The design choice worth explaining is why it does NOT use the conventional PSI thresholds. "), T("Those bands - 0.10 “moderate”, 0.25 “significant” - are folklore, and PSI is biased upward on small samples: two halves of the SAME distribution show non-zero PSI purely from binning noise, and the smaller the sample, the larger that floor. Measured:")]));
children.push(table([2400, 4200, 2760], [
  ["n", "PSI between two samples of the SAME distribution", "Folklore verdict"],
  ["50", "0.3044", "'significant drift'"],
  ["100", "0.1465", "'moderate drift'"],
  ["300", "0.0713", "stable"],
  ["1,000", "0.0077", "stable"],
  ["5,000", "0.0038", "stable"],
]));
children.push(P([B("At n = 50 the folklore declares significant drift on IDENTICAL distributions. "), T("Applying a fixed cut-off to short windows fires constantly, which is how monitoring gets switched off. So significance is established by PERMUTATION: pool both samples, reshuffle the labels, recompute PSI many times. That gives the PSI attributable to binning noise at these exact sample sizes and this exact binning, and a feature is flagged only when it exceeds it. Same discipline as the binomial-CI gate - an alert that fires on noise teaches people to ignore alerts. The conventional bands are still reported, because a risk function will ask for them; they simply never decide. The aggregate verdict also corrects for MULTIPLE TESTING: 40 features at alpha = 0.05 yields ~2 false positives by construction, so “some feature drifted” is not news.")]));
children.push(P([B("On real data "), T("(RELIANCE, 750-bar reference vs 250-bar current, 26 features): 10 features flagged - WIDESPREAD DRIFT, against 1.3 expected by chance. And they are coherently themed: volatility_50, volatility_20, volatility_10, atr_norm, plus macd_norm, ma_ratio_50, rsi_14. The volatility and trend-regime family has moved; the raw return distribution, volume and calendar features have not. One honest note: at 750/250 the permutation test and the folklore bands happened to agree (both flagged 10). The calibration matters at SMALL samples, which is exactly where a monitor gets run in practice - not at this one.")]));

children.push(H3("Attribution: exact TreeSHAP, and what it says about the project"));
children.push(P("Klaas Chapter 8 asks “why did your model make the prediction it made?” and reaches for LIME. For tree ensembles there is something strictly better: TreeSHAP is EXACT rather than a local surrogate, and both LightGBM and XGBoost implement it natively via pred_contrib / pred_contribs. So explain.py needs NO NEW DEPENDENCY - not shap, not lime. Exactness matters more than usual here: a surrogate's disagreement with the model is indistinguishable from a genuine attribution, so an approximate explainer applied to a near-noise model produces confident-looking nonsense. Unsupported models return None rather than falling back to an approximation."));
children.push(P([B("But the reason to run it is sharper than interpretability. "), T("This project's central claim is that most apparent edge is noise. Attribution checks that from the inside: a model driven by a few economically sensible features is making a structured claim; attribution spread thinly across dozens is what fitting noise looks like. The Herfindahl index makes it concrete - near 1/n is uniform, near 1 is one feature explaining everything. The method demonstrably detects concentration when it exists: on a synthetic model where only two of six features matter, those two took 95.6% of attribution, Herfindahl 3.8x uniform.")]));
children.push(table([3400, 2400, 1800, 1760], [
  ["Model", "Top feature", "Features for 50%", "Herfindahl vs uniform"],
  ["Single-ticker GBM (26 features)", "volatility_10 - 9.0%", "8", "0.0525 vs 0.04 (1.3x)"],
  ["Cross-sectional classifier (30 features)", "atr_norm - 6.9%", "11", "0.039 vs 0.0333 (1.2x)"],
]));
children.push(P([B("Attribution is nearly uniform in both. "), T("No feature carries the prediction. It takes 8 and 11 features respectively to reach half the attribution, and the top feature carries under 10%. This is the ninth documented negative result, and the one that arrives from the most independent direction. (Superseded in part: Section 3.39 re-ran this measurement on 400 names and attribution DOES concentrate there - top feature 14.8% against ~3% uniform. The near-uniform result here is a property of the 39-name universe, not of the problem.) Every previous null came from MEASURING OUTCOMES - RMSE against a random walk, SPA p-values, rank IC t-statistics. This one comes from looking INSIDE the model and finding no driver to look at. It could easily have come out the other way: a concentrated attribution on economically sensible features would have been a genuine lead, and the synthetic control proves the method would have found it.")]));
children.push(P("Additivity is verified rather than assumed (base_value + sum(SHAP) == prediction, error 4.3e-17 on real data), because a silently mis-parsed contribution layout would still produce plausible-looking attributions. One caveat stated in the driver itself: attribution explains what the model DID, not whether it was right. A confidently-attributed forecast from a model with no measured edge is still a forecast with no measured edge."));

children.push(H2("3.37 Fractional differentiation: measuring a choice made by convention - the tenth negative result"));
children.push(P("From Kaabar, Deep Learning for Finance, Chapter 9 (Lopez de Prado's method). The one item in that book touching something this project does BY CONVENTION rather than by measurement."));

children.push(H3("The choice that was never tested"));
children.push(P("Every model here sees d = 1 data. prepare_log_returns computes log(price / price.shift(1)); the features are log_return_1..10; the target is a cumulative log return. That guarantees stationarity - and it is MAXIMALLY DESTRUCTIVE, removing not just the trend but every trace of long-range dependence in the level. If prices carry persistent structure, d = 1 discards it before any model sees the data, and no architecture downstream can recover it."));
children.push(P("Fractional differencing expands (1 - B)^d for non-integer d into an infinite binomial series: w0 = 1, wk = -w(k-1) * (d - k + 1) / k. At d = 1 the weights terminate at [1, -1] - an ordinary difference. At 0 < d < 1 they decay slowly and never terminate, and THAT NON-TERMINATION IS THE RETAINED MEMORY. fracdiff.py implements it. The book uses pip install fracdiff; the weights are a four-line recurrence, so this is a no-new-dependency implementation - ADF/KPSS come from statsmodels, already pinned."));

children.push(H3("What d = 1 actually costs, on real data"));
children.push(P("Minimum-d scan on RELIANCE, 7,697 bars (tolerance 1e-4):"));
children.push(table([1400, 1900, 2600, 1700, 1760], [
  ["d", "ADF p", "corr with level", "window", "stationary"],
  ["0.00", "0.5816", "1.0000", "1", "no"],
  ["0.30", "0.3577", "0.9779", "388", "no"],
  ["0.40", "0.1580", "0.9464", "282", "no"],
  ["0.50", "0.0292", "0.8823", "200", "YES (minimum)"],
  ["0.70", "0.0001", "0.5848", "97", "yes"],
  ["1.00", "0.0000", "0.0039", "2", "yes (current)"],
]));
children.push(P([B("At the minimum stationary order d = 0.50 the series still correlates 0.88 with the price level. At d = 1 - what this project uses - the correlation is 0.004. "), T("Stationarity is achieved either way; the difference is roughly all the memory. That is the sharpest available statement of what the pipeline throws away.")]));

children.push(H3("Does the retained memory forecast anything? No."));
children.push(P("run_fracdiff_eval.py runs the A/B: identical models, identical walk-forward origins, one arm with the existing feature set and one with frac-diff log-price columns at d = 0.50. 40 origins on 7,325 usable rows."));
children.push(table([3000, 3000, 3360], [
  ["Arm", "RMSE", "vs random walk"],
  ["random walk", "0.048694", "-"],
  ["baseline (d = 1)", "0.048897", "-0.42%"],
  ["frac-diff (d = 0.50)", "0.046358", "+4.80%"],
]));
children.push(P([B("Frac-diff is 5.19% better than baseline in point estimate - and Diebold-Mariano gives p = 0.436 on 40 origins. Not significant. The honest reading is NO DIFFERENCE. "), T("This is the tenth documented negative result, and a cleaner one than most: frac-diff adds NO PARAMETERS, so unlike N-BEATS and Vol-LSTM this null cannot be blamed on capacity. It changes the REPRESENTATION, and Section 3.33 established the constraint is INFORMATION. A representation change cannot create signal that is not there.")]));
children.push(P([B("One practical constraint worth recording: "), T("the window length is a function of d. At tolerance 1e-5, d = 0.4 needs 1,458 bars - longer than the 1,000-bar cap the single-ticker models use, which would produce an all-NaN column. Loosening to 1e-4 gives 282 bars, which is workable. That tension is real: a looser tolerance truncates the memory sooner, partially defeating the purpose.")]));

children.push(H3("Two bugs found - one mine, one pre-existing"));
children.push(P([B("Mine, and it mattered. "), T("The first version of the A/B trained on rows up to o-1 while evaluating y[o]. Row o-1's target spans [o-1, o-1+h], which OVERLAPS the evaluation target - the overlapping-label leak our own embargo exists to prevent. It reported the baseline at +20.20% vs the random walk. That number is what gave it away: a 20% RMSE improvement over a naive baseline is flatly inconsistent with every other result in this project. With the embargo applied, the same arm scores -0.42% - parity, as expected. The leak was worth roughly 20 percentage points of imaginary skill, and the only thing that caught it was the result disagreeing with the rest of the evidence.")]));
children.push(P([B("Pre-existing, in get_data.py. "), T("Running the scan surfaced “Error processing data: 'charmap' codec can't encode character”. Seven status messages in the currency-conversion path contain emoji, and an unguarded print of them raises UnicodeEncodeError on a legacy Windows code page - INSIDE a try/except, so it was caught and re-reported as a generic data error that masked what actually happened. This is exactly the exposure flagged when console.py was built and deferred as out of scope; it has now fired for real. All seven now route through console._write, which degrades instead of raising.")]));

children.push(H3("One inconsistency noted, deliberately not fixed"));
children.push(P("The DM test on baseline-vs-random-walk returned NaN. That is diebold_mariano's own guard firing correctly: it computes the Newey-West long-run variance with UNWEIGHTED autocovariances, which can come out negative, and it returns NaN rather than a bogus p-value. Worth recording that strategy_metrics.newey_west_se - added in Section 3.31 - DOES apply a Bartlett kernel, which cannot go negative. The two are inconsistent. Adding the kernel to diebold_mariano would be a genuine improvement, and it would change every DM p-value published in this document. That is not a change to make silently as a side effect of a frac-diff experiment, so it is recorded here as a known issue rather than applied."));

children.push(H3("What else was in the book"));
children.push(P("Nothing else worth taking. Forecasting threshold (p270) is the Conviction column and the abstention gate. Multiperiod forecasting (p277) is direct multi-horizon. Time-series cross-validation (p275) is walk-forward with embargo. Continuous retraining (p272) is train-on-demand. COT data (p307) is US futures positioning and does not exist for NSE equities. Chapters 1-6 are foundations; Chapters 7-8 the model zoo already built; Chapter 10 deep RL, blocked by the power wall Section 3.31 measured."));

children.push(H2("3.38 The Diebold-Mariano kernel fix, and the Windows race it uncovered"));
children.push(P("Section 3.37 recorded an inconsistency rather than fixing it: diebold_mariano computed its Newey-West long-run variance with UNWEIGHTED autocovariances, while strategy_metrics.newey_west_se (added in Section 3.31) applied a BARTLETT kernel. Fixing it would move every published DM p-value, so it was flagged rather than changed silently. This section is that fix, done properly - with the before/after measured."));

children.push(H3("The bug"));
children.push(P("An unweighted sum of autocovariances is a truncated (rectangular) kernel, and it is NOT positive semi-definite. On short samples the estimated variance can come out NEGATIVE, and the function then returns NaN rather than a p-value. That guard is correct - a p-value from a negative variance would be nonsense - but it is a silent loss of power: a test that declines to run is a test that never rejects. Bartlett weights (1 - k/h) are PSD by construction, so the variance cannot go negative."));

children.push(H3("How often it actually fired"));
children.push(P("Simulated, 400 comparisons per cell:"));
children.push(table([1000, 1200, 1900, 1900, 1900, 1460], [
  ["h", "n", "NaN (old)", "NaN (new)", "mean |dp|", "flips @0.05"],
  ["1", "20-120", "0", "0", "0.0000", "0"],
  ["3", "20", "25", "0", "0.0492", "27"],
  ["5", "20", "81", "0", "0.0691", "24"],
  ["5", "40", "28", "0", "0.0567", "30"],
  ["10", "20", "190", "2", "0.0945", "15"],
]));
children.push(P([B("Two things stand out. "), T("At h = 1 the change is EXACTLY ZERO - the lag loop never executes - which bounds the blast radius: every single-step DM figure ever published here is bit-identical. And at h = 5, n = 20 the old version refused to produce a p-value in 20% of cases; at h = 10, n = 20, in 48%. That regime is not hypothetical: the serve-time confidence gate runs 3 origins at h = horizon, so a 5-day forecast gives about 15 error points - squarely inside it.")]));
children.push(P([B("The failure was conservative, which is why it was never noticed. "), T("confidence_bucket treats a NaN p-value as “not significant”, so an affected model could never reach High or Medium - it capped at Low. The app was UNDER-rating models, not over-rating them. That is the safe direction, and still wrong.")]));

children.push(H3("What changed in the published figures"));
children.push(P("Measured on IDENTICAL real error series, captured from walk_forward_backtest and scored under both kernels (6 splits, h = 5, n = 30):"));
children.push(table([2600, 2600, 1700, 1700, 1760], [
  ["Ticker", "Model", "old p", "new p", "delta"],
  ["TCS.NS", "ARIMA+GARCH", "0.1920", "0.2155", "+0.0235"],
  ["TCS.NS", "Ensemble-Stack", "0.8679", "0.8451", "-0.0228"],
  ["TCS.NS", "XGBoost", "0.7761", "0.7829", "+0.0068"],
  ["RELIANCE.NS", "ARIMA+GARCH", "0.3836", "0.3637", "-0.0199"],
  ["RELIANCE.NS", "Ensemble-Stack", "0.4233", "0.4029", "-0.0204"],
  ["RELIANCE.NS", "XGBoost", "0.8379", "0.8126", "-0.0253"],
]));
children.push(P([B("Maximum movement: 0.025. "), T("No verdict changes at the 0.05 or 0.10 thresholds. ONE changes at 0.20 - TCS ARIMA+GARCH crosses from 0.1920 to 0.2155, dropping that configuration from Medium to Low, again in the conservative direction. So the fix is correct and necessary, and NO CONCLUSION IN THIS DOCUMENT CHANGES. The empirical findings, the SPA verdict and the “no confirmed winner” framing all stand.")]));

children.push(H3("The Windows race the fix uncovered"));
children.push(P("Re-running the suite after the change produced an intermittent failure - and, tellingly, in a DIFFERENT TEST EACH TIME: three separate drift-report tests failed across runs, each passing in isolation. That pattern says shared non-determinism, not a broken assertion. The tests already used isolated temp directories, so it was not file contamination."));
children.push(P([B("The cause was found only after hardening the test harness. "), T("log_forecast swallows every exception on purpose (a logging failure must never break a forecast), which in a test converts a transient write failure into a SHORT LOG, surfacing several assertions later as an unexplained coverage number. Asserting that every write succeeded turned the puzzle into a named failure, and the named failure pointed at _rewrite: PermissionError [WinError 5] Access is denied, on os.replace of predictions.jsonl.tmp.")]));
children.push(P([B("This is a production bug, not a test artefact. "), T("os.replace is atomic on POSIX; on Windows it raises whenever another process holds even a momentary handle on the destination - an antivirus scanner or the search indexer touching a just-written file is enough. It is a race, failing roughly one run in ten. resolve_outcomes is what run_drift_report.py --resolve calls on the real log, so hitting this would crash the resolve and leave a stray .tmp beside the log. Fixed with retry-and-exponential-backoff - the standard Windows-safe pattern - and the temporary file is removed if every attempt fails, so a failed resolve cannot leave litter a later run mistakes for data.")]));
children.push(P("The general lesson is the one this project keeps rediscovering: the deliberate swallow that makes a system robust in production is the same swallow that makes it undiagnosable in testing. The fix is not to remove it, but to make the test harness refuse to tolerate it."));

children.push(H2("3.39 Universe expansion: point-in-time data, and the first positive result"));
children.push(P("Ten negative results in this project point at the same suspect. The cross-sectional null in Section 3.30 - rank IC +0.0111 at t = 0.92 - was read at the time as a POWER result rather than evidence against the approach: real cross-sectional ICs are 0.02-0.05, and detecting one needs roughly 55-60 validation names where 39 were available. Section 3.32 deferred to the same wall. Breadth was the one lever never pulled. This section pulls it - and most of the work turned out to be in the DATA SOURCE, not the experiment."));

children.push(H3("The obvious source is a trap"));
children.push(P("NSE publishes EQUITY_L.csv, and get_data.get_bse_nse_data already fetches it: 2,565 listings, 2,302 with SERIES == EQ, and 1,154 listed early enough to have full history. Ample to draw 400 names from. It is also A LIST OF COMPANIES THAT STILL EXIST. Measured against Wayback Machine snapshots of the identical URL - the current archives.nseindia.com domain has only two, but the pre-2020 nseindia.com URL has 33 going back to 2006:"));
children.push(table([2600, 3200, 4060], [
  ["Snapshot", "EQ names then", "Absent from today's list"],
  ["2017-07", "1,465", "392 (26.8%)"],
  ["2018-12", "1,456", "306 (21.0%)"],
  ["2021-05", "1,563", "209 (13.4%)"],
]));
children.push(P([B("A quarter of the 2017 universe is gone. "), T("Drawing a 2018-2026 panel from today's roster selects companies ON THE BASIS OF HAVING SURVIVED THE WINDOW, then asks a model to predict their returns over it. A larger biased sample is worse than a small honest one, because it produces a confident answer. The gap cannot be patched from the existing feed: of 30 randomly sampled vanished symbols fetched from yfinance, 23 returned no data at all, 6 partial, 1 usable. yfinance discards delisted history.")]));
children.push(P([B("This is not hypothetical for this project. "), T("TATAMOTORS.NS - one of the 40 names in DEFAULT_UNIVERSE - now returns ZERO BARS from yfinance after the 2025 demerger, while bhavcopy still carries all 490 of its 2018-2019 sessions. That is precisely why the published cross-sectional work ran on 39 usable names rather than 40. The bias had already started eating the universe.")]));

children.push(H3("Bhavcopy: point-in-time by construction"));
children.push(P("NSE publishes a DAILY BHAVCOPY - one file per trading day listing every instrument that traded. There is no membership list to get wrong and no survivorship correction to apply: whatever traded on 2 January 2018 is in the 2 January 2018 file. 3IINFOTECH, ADANITRANS, ADLABS and ADHUNIK are all there with full OHLCV."));
children.push(P("bhavcopy.py is that loader. Two formats, found by probing rather than assumed: the legacy zipped CSV serves 2017-01 through 2024-07-01 and 404s from 2024-07-08; UDiFF via nselib serves 2024-01 onward. fetch_day tries legacy and falls back, so the cutover is absorbed rather than hardcoded. The six-month overlap is a FREE CROSS-VALIDATION, and test_readers_agree_on_the_normalised_schema pins that downstream code cannot tell which source produced a row. The cache is one gzipped file per day - 2,376 trading days plus 145 holidays, ~105 MB, 62 minutes once. A missing day is stored as an EMPTY file, because a weekend and an exchange holiday are indistinguishable from date arithmetic and must be discovered, never interpolated."));

children.push(H3("The harder half: raw prices"));
children.push(P("Bhavcopy carries RAW TRADED PRICES. yfinance was silently handling splits and bonuses; bhavcopy does not, and an unadjusted 1:10 split reads as a -90% return that would poison every momentum feature in the panel. PREVCLOSE is no help - checked on seven 2019 split/bonus ex-dates it equals the prior day's raw close exactly (ratio 1.000). NSE does not adjust it either. So the adjustment is ours, parsed from nselib's corporate-action feed (coverage verified back to January 2017):"));
children.push(table([5600, 4260], [
  ["Subject line", "Adjustment"],
  ["Bonus 1:4", "x1.25"],
  ["Face Value Split From Rs 10/- ... To Rs 2/- ...", "x5"],
  ["Bonus 1:2/Face Value Split ... Rs 2/- To Re 1/-", "x3 (compound)"],
  ["Interim Dividend Rs 2/- Per Share", "Rs 2 cash"],
  ["Rights 19:67 @ Premium Rs 215 Per Share", "via TERP"],
]));
children.push(P("Dividends are included because the pipeline models log returns off adj_close (get_data ~line 352), yfinance's FULLY back-adjusted series. Adjusting only for splits would make the new panel incomparable with every figure already published here."));
children.push(P([B("A bug caught during validation. "), T("GPIL filed a 10->5 split AND a 1:1 bonus as two separate records on 2021-10-26 - true factor 4.0. An early version deduplicated by (symbol, ex_date) and parsed 2.0, an 82% error. Same-day actions must COMPOUND; test_same_day_actions_compound exists so it cannot return. Every correction is expressed as the ratio of theoretical post-event price to cum price, so compounding is correct by construction rather than by patch.")]));

children.push(H3("Validated against yfinance, which found the one thing left out"));
children.push(P("A per-event check (does the price drop by the parsed factor?) is confounded by the stock's genuine move that day - which is why one of 18 hand-checked events came in 13% off with a perfectly correct factor. The stronger test compares the WHOLE RETURN SERIES against an independent adjusted source. run_bhavcopy_audit.py does that over 2018-2019:"));
children.push(table([4600, 5260], [
  ["Measure", "Result"],
  ["Median return correlation", "1.00000"],
  ["Names above 0.999", "24 / 24"],
  ["Names bit-identical", "14"],
  ["Worst single-day gap", "0.83%"],
]));
children.push(P([B("It did not start there. "), T("The first run gave 22/24, with BHARTIARTL (0.98507) and TATASTEEL (0.99537) failing - and both turned out to be RIGHTS ISSUES, which the parser did not handle. Adding theoretical-ex-rights-price adjustment moved them to 0.99986 and 0.99999. Worth recording: NSE quotes the PREMIUM OVER FACE VALUE, not the subscription price, so Bharti's 'Rs 215' is really Rs 220 against a Rs 5 face value, and the face value has to come from the feed's faceVal column. Tata Steel's subject carries a fully-paid AND a partly-paid tranche; only the first is taken, because a partly-paid share is a separate instrument and folding it in would be wrong in a worse way than ignoring it.")]));
children.push(P("adjust_prices(as_of=...) applies ONLY actions known by that date, which closes the back-adjustment look-ahead Section 3.19 documented and yfinance cannot avoid."));

children.push(H3("The experiment"));
children.push(P("run_universe_expansion.py runs the IDENTICAL experiment at four universe sizes - same features, labels, split rule, model and horizon. Only breadth varies. The integration is one function, deliberately: cross_sectional_panel.build_panel already accepted an injected fetch_fn so its tests could run offline, and bhavcopy.bhav_fetcher slots into that seam. NOT ONE LINE of cross_sectional_panel.py, cross_sectional_model.py or the feature code changed. Had the pipeline been rebuilt alongside the data source, no comparison with the published 39-name result would have meant anything."));
children.push(P("Window 2018-01-01 to 2024-06-30, horizon 5 days, mode='combined' (unseen names AND unseen dates), seed 42:"));
children.push(table([1300, 1400, 1700, 1500, 1800, 1200, 1060], [
  ["Requested", "Usable", "Val names", "IC dates", "Rank IC", "FM t", "Abstain"],
  ["39", "39", "12", "464", "+0.0283", "1.31", "0.968"],
  ["100", "100", "30", "464", "+0.0048", "0.24", "0.956"],
  ["200", "197", "59", "464", "+0.0375", "2.37", "0.937"],
  ["400", "332", "100", "464", "+0.0396", "2.24", "0.922"],
]));
children.push(P("The 39-name row reproduces the project's own history - t = 1.31 against the published 0.92 - on a different window and a differently-selected universe. That is the control."));

children.push(H3("It was not reported until it survived being attacked"));
children.push(P([B("The table is not monotonic. "), T("Under a pure power story t should climb roughly with the square root of the validation count; instead 1.31 -> 0.24 -> 2.37 -> 2.24. The dip at 100 is larger than sampling noise should comfortably allow, and every row is ONE SEED. Section 3.30 already recorded a case where one seed gave a reportable t = 2.43 where the honest read gave 1.69.")]));
children.push(P("run_universe_seeds.py builds the panel once (it does not depend on the seed) and re-splits, re-fits and re-evaluates, then repeats the whole thing on two DISJOINT periods:"));
children.push(table([2700, 1300, 1900, 1700, 1200, 1160], [
  ["Window", "IC dates", "Rank IC median", "FM t median", "t > 2", "IC < 0"],
  ["Full 2018-01 .. 2024-06", "464", "+0.0367", "+2.42", "7 / 8", "0 / 8"],
  ["A: 2018-01 .. 2021-06", "~230", "+0.0336", "+1.92", "2 / 6", "0 / 6"],
  ["B: 2021-07 .. 2024-12", "240", "+0.0328", "+2.70", "6 / 6", "0 / 6"],
]));
children.push(P([B("Twenty of twenty seed-runs are positive, "), T("and the effect SIZE is near-identical across two non-overlapping periods: 0.0367 / 0.0336 / 0.0328. Period A's weaker t is not a weaker effect - its IC is the same size, measured over half the dates with more than double the dispersion (sd 0.0145 vs 0.0065), which is what a window containing the COVID crash should look like. So the n = 100 dip was a single-draw artefact, and THE CROSS-SECTIONAL NULL IN SECTION 3.30 WAS A POWER RESULT EXACTLY AS CLAIMED. This is the project's FIRST POSITIVE RESULT after ten negatives.")]));

children.push(H3("What this result is not"));
children.push(P([B("1. The long-short spread is not usable; the rank IC is. "), T("The spread looks large (+0.017 to +0.061 of 5-day excess log return) and rests on almost nothing:")]));
children.push(table([2400, 2400, 2500, 2560], [
  ["Universe", "Long calls", "Short calls", "of predictions"],
  ["39", "0", "143", "4,405"],
  ["100", "26", "499", "11,813"],
  ["200", "18", "1,573", "25,085"],
  ["400", "148", "2,978", "39,844"],
]));
children.push(P("148 longs out of 39,844 is 0.37%, against 20x as many shorts. That is not a balanced portfolio, the mean of 148 observations is dominated by a handful of moves, and no transaction costs appear anywhere in it. At n = 39 there were ZERO long calls, which is why that spread is undefined. Quote the IC, not the spread."));
children.push(P([B("2. The classifier still barely classifies. "), T("Accuracy 0.510 against a 0.501 majority baseline; macro F1 0.288. The rank IC carries the entire result - the model ORDERS names better than chance while its discrete calls stay close to worthless. Abstention holds at 92% even at 400 names, so Section 3.30's emergent-abstention behaviour is not a small-sample artefact. Calibration is genuinely good, though: ECE 0.0204 -> 0.0026.")]));
children.push(P([B("3. A residual survivorship filter remains, smaller but real. "), T("build_panel requires 300 rows per name, so companies trading for under ~14 months inside the window are dropped - 68 of 400 at the largest size. And a company that fails simply stops appearing; its final observed return is not -100%, so genuine wipeouts are under-represented. Both push optimistic. Far weaker than 'must still exist in 2026', and not zero.")]));
children.push(P([B("4. One market, one model family, gross of costs. "), T("No capacity analysis, and no borrow cost on a book that is 95% short by count.")]));
children.push(H3("What the signal is made of - and why the model is not the finding"));
children.push(P("A statistical result whose mechanism is unknown is one step away from an artefact nobody has found yet. run_universe_attribution.py asks what the 400-name model is actually keying on, with the decisive measurement being the UNIVARIATE IC: for every raw feature, the Fama-MacBeth IC of that feature ALONE against forward excess return - same rows, same 464 dates, same machinery as the model."));
children.push(table([2400, 2100, 1500, 1800, 2060], [
  ["Feature", "Univariate IC", "FM t", "Hit rate", "SHAP share"],
  ["log_return_5", "-0.0524", "-4.34", "0.388", "1.6%"],
  ["rank_rev_5", "-0.0524", "-4.34", "0.388", "4.2%"],
  ["ma_ratio_10", "-0.0490", "-4.00", "0.386", "1.6%"],
  ["macd_hist_norm", "-0.0469", "-3.67", "0.373", "3.1%"],
  ["log_return_3", "-0.0442", "-4.08", "0.397", "0.9%"],
  ["rank_mom_63", "+0.0276", "+2.24", "0.595", "7.1%"],
  ["the model", "+0.0396", "+2.24", "0.565", "-"],
]));
children.push(P([B("A single raw feature beats the model - 1.32x the IC and nearly double the t. "), T("And the sign is unambiguous: a negative IC on recent returns means recent winners underperform, which is SHORT-TERM REVERSAL, one of the most documented effects in equities. The hit rate of 0.388 says the IC is negative on 61% of dates, so it is consistent rather than carried by a handful of them. The whole top of the table is the same effect wearing different names.")]));
children.push(P([B("A second textbook effect appears with the correct opposite sign. "), T("rank_mom_63 scores +0.0276 at t = +2.24 - positive IC at a 63-day lookback. Short-horizon reversal AND medium-horizon momentum, both present, both correctly signed, in a survivorship-free panel built from scratch. That is a strong independent check on the entire data pipeline: if the bhavcopy loader or the corporate-action adjustment were subtly wrong, these two effects would not both emerge at their textbook signs and horizons.")]));
children.push(P([B("The SHAP explains why the model underperforms. "), T("Its top three features by attribution are volatility_50 (14.8%), atr_norm (9.0%) and rank_vol_21 (7.3%) - all volatility. rank_rev_5, which carries the actual edge, ranks SEVENTH at 4.2%. The model spends its capacity deciding WHEN TO STAY OUT rather than WHICH WAY TO LEAN, which is coherent with the 92% abstention and is exactly what it was punished for.")]));
children.push(P([B("This also reverses Section 3.36's reading. "), T("Attribution there was near-uniform (Herfindahl 1.3x uniform) and was recorded as 'no driver to look at'. At 400 names it concentrates: the top feature takes 14.8% where uniform would be ~3%. THERE WAS A DRIVER; THE 39-NAME UNIVERSE WAS HIDING IT, in the same way and for the same reason it hid the IC.")]));
children.push(H3("The honest summary"));
children.push(P("There is a REAL, REPLICABLE cross-sectional ordering signal in liquid NSE equities at a 5-day horizon, invisible at 39 names and detectable at 200+. That part of Section 3.30's prediction is confirmed."));
children.push(P([B("But the model is not the finding - the factor is. "), T("This section is a known effect REDISCOVERED, not learned cross-sectional skill, and a naive 5-day reversal sort is the benchmark any model here has to beat. This one does not beat it. Anyone reporting the +0.0396 without the -0.0524 beside it would be overstating what the machine learning contributed, which is: nothing yet.")]));
children.push(P("That is a better outcome than an unexplained edge. An edge you cannot explain is one you cannot reason about when it stops working - and short-term reversal has a known mechanism (liquidity provision, bid-ask bounce, over-reaction), known decay, and known capacity limits. Whether it survives costs is answered in Section 3.40: IT DOES NOT. Breakeven is 6.1 bp round trip against an STT of 20 bp, and no holding period or tail width in the sweep clears even 25 bp."));

children.push(H2("3.40 Costing the reversal signal - the eleventh negative result, and the end of the arc"));
children.push(P("Section 3.39 closed with an open question: the cross-sectional signal is real, replicable and identified as short-term reversal, but 'whether it survives costs is a different question this project has not asked.' This asks it, and the answer closes the arc."));
children.push(P("run_reversal_costs.py builds the tradeable version: long the bottom decile of 5-day past return (recent losers), short the top decile (recent winners), equal-weighted, dollar-neutral, rebalanced every 5 trading days so holding periods do not overlap. 339 names, 1,601 dates, 319 rebalances. The signal is a cross-sectional sort on a raw feature with NO FREE PARAMETERS - nothing is fitted - so the whole 2018-2024 panel is fair game and there is no train/test split to respect."));
children.push(H3("It was already thin before costs"));
children.push(table([5000, 4860], [
  ["Measure", "Gross (no costs)"],
  ["Annual return", "+5.30%"],
  ["Annual volatility", "22.49%"],
  ["Sharpe", "+0.24"],
  ["Periods positive", "0.517"],
]));
children.push(P([B("An IC of -0.052 sounds respectable and converts to a Sharpe of 0.24. "), T("The decile spread carries 22% annualised volatility, so the risk-adjusted edge was small before a single rupee of cost. Section 3.39's statistical significance came from having 464 dates, not from a large effect - which is exactly the distinction the Fama-MacBeth machinery exists to expose, and it cuts both ways.")]));
children.push(H3("Costs remove it several times over"));
children.push(P("The book turns over 3.47 of a possible 4.00 notional per rebalance - an 87% refresh, every five days."));
children.push(table([2000, 2200, 1500, 4160], [
  ["Round trip", "Annual return", "Sharpe", "Scenario"],
  ["10 bp", "-3.44%", "-0.15", "institutional, futures, top liquidity"],
  ["25 bp", "-16.56%", "-0.74", "liquid cash equity, modest size"],
  ["50 bp", "-38.43%", "-1.71", "realistic incl. mid-cap impact"],
  ["100 bp", "-82.16%", "-3.66", "retail delivery, STT both sides"],
]));
children.push(P([B("Breakeven: 6.1 bp round trip. "), T("That is the number to argue with, because it assumes nothing - it is simply where gross return equals cost drag. For scale, STT ALONE IS 20 bp ROUND TRIP on Indian delivery, before brokerage, exchange fees, stamp duty or market impact.")]));
children.push(H3("The obvious rescue does not work, and the reason is interesting"));
children.push(P("A turnover-driven null invites one objection: rebalance more slowly. Tested across holding periods and tail widths:"));
children.push(table([1200, 1200, 2200, 1900, 1500, 1860], [
  ["Hold", "Tail", "Notional traded", "Gross annual", "Sharpe", "Breakeven"],
  ["5d", "1/10", "3.471", "+5.30%", "+0.24", "6.1 bp"],
  ["5d", "1/5", "3.159", "+4.06%", "+0.25", "5.1 bp"],
  ["10d", "1/10", "3.471", "-1.82%", "-0.09", "-4.2 bp"],
  ["21d", "1/10", "3.485", "-2.54%", "-0.14", "-12.1 bp"],
  ["42d", "1/10", "3.455", "-9.15%", "-0.55", "-88.3 bp"],
]));
children.push(P([B("Only the 5-day book has a positive gross return at all. "), T("At 10 days and beyond the effect is gone and the sign flips - consistent with the reversal literature, where the effect lives at days-to-weeks and decays fast.")]));
children.push(P([B("The unexpected part is the middle column: turnover barely moves. "), T("Holding for 42 days instead of 5 still trades ~3.46 of 4.00. That is because the signal has NO PERSISTENCE - a 5-day return is close to uncorrelated with the 5-day return measured 42 days later, so decile membership is redrawn essentially from scratch at every rebalance regardless of spacing. Slowing down therefore buys NO turnover reduction while forfeiting all of the return. That is the mechanism, and it is why this particular null cannot be engineered around: the horizon at which the signal exists and the horizon at which it would be cheap to trade are disjoint.")]));
children.push(H3("A second, independent blocker"));
children.push(P([B("Indian cash equity has no overnight short selling. "), T("A 5-day short leg needs single-stock futures, and those exist for only 129 of the 339 universe names (38%) - on TODAY'S F&O list, which is an upper bound since the list was narrower historically. So the short side - where Section 3.39's model made 95% of its calls - is unimplementable for nearly two-thirds of the universe. Restricting to F&O names would cut breadth by that much, and breadth is precisely what generated the IC in the first place. Two independent reasons for failure is a sturdier conclusion than one.")]));
children.push(H3("The arc, complete"));
children.push(table([2200, 7660], [
  ["Stage", "Finding"],
  ["Section 3.30", "No cross-sectional skill at 39 names (t = 0.92) - diagnosed as UNDERPOWERED, not absent"],
  ["Section 3.39", "At 400 survivorship-free names the signal IS there: IC +0.0396, t = 2.24, 20/20 seeds"],
  ["Section 3.39 attribution", "It is SHORT-TERM REVERSAL - and one raw feature beats the model"],
  ["Section 3.40", "It is NOT TRADEABLE: breakeven 6.1 bp, no configuration clears 25 bp"],
]));
children.push(P([B("The eleventh negative result, and the one that completes the story rather than deferring it. "), T("The honest summary of this project's central question is now a single sentence: there is a small, real, statistically solid cross-sectional signal in liquid NSE equities, it is a long-known effect rather than anything learned, and it is worth less than the cost of trading it.")]));
children.push(P("That is a more useful place to stop than an unresolved positive. A statistically significant result left uncosted would have been the most misleading thing this repository could ship."));

children.push(H2("3.41 Range-based volatility (Sharma & Mehta Ch. 18) - the twelfth negative result"));
children.push(P("Deep Learning Tools for Predicting Stock Market Movements (Sharma & Mehta, eds., 2024) is mostly surveys, bibliometrics and questionnaire-based behavioural studies - Chapters 4, 7, 8, 10-15 and 17 contain nothing implementable, Chapters 2 and 5 are quantum computing, and Chapter 1's LSTM+ARIMA+sentiment stack is already here minus the sentiment feed Section 3.27 rejected as licensed."));
children.push(P([B("Chapter 18 "), T("(Kaur & Chaudhary, 'Volatility Transmission Role of Indian Equity and Commodity Markets') is the exception, and its useful contribution is NOT the Diebold-Yilmaz spillover model in the title. It is one line of methodology: sigma^2 = 0.361 * [ln(P_high) - ln(P_low)]^2, with the note that 'literature has proven the advantage of using a range-based volatility estimator as compared to the traditional method'. That constant is 1/(4 ln 2) = 0.3607 - the PARKINSON (1980) estimator.")]));

children.push(H3("The gap it pointed at"));
children.push(P("HAR_RV_model builds its variance series as RV_t = r_t^2, and its own docstring calls that 'the standard proxy WHEN SUB-BAR DATA IS UNAVAILABLE'. Sub-bar data is not unavailable: every bar the app fetches carries open, high and low, used for features and never for the variance estimate that drives the uncertainty cone - which this document names as the actual product. The motivating case is stark: a bar that opens at 100, runs to 108, falls to 94 and closes at 100 has r_t = 0 and therefore ZERO estimated variance. The range saw all of it."));
children.push(P("range_volatility.py implements Parkinson, Garman-Klass, Rogers-Satchell and Yang-Zhang. Against a synthetic process with known variance the efficiency gains land on theory: Parkinson 5.07x (theory 5.2), Garman-Klass 6.77x (7.4). On real NSE bars the gain is 1.6-2.5x, NOT 5x - real bars trade discretely, so the observed high and low understate the true extremes. The measured number is the one reported."));

children.push(H3("A trap, hit and then pinned"));
children.push(P([B("Range estimators are within-bar ratios, "), T("so they are invariant to any rescaling of a bar's prices and therefore immune to split and dividend adjustment. Close-to-close returns are not. scale_to_total compares the two, to restore the overnight variance an intraday estimator misses. Measured with RAW closes, TATASTEEL's scale factor came out at 8.32 (level ratio 0.120); with adjusted closes, 1.26 (0.794). Four of six names were corrupted this way - only the two without splits in the window were unaffected. The function now flags implausible factors, and test_scale_to_total_flags_an_unadjusted_close exists so it cannot recur.")]));
children.push(P("The honest level ratios: the intraday range captures 64-85% of close-to-close variance. The rest happens overnight, when earnings and news land - which is why a naive substitution would have understated the cone and caused under-coverage."));

children.push(H3("The A/B, and two corrections to the analysis"));
children.push(P("12 names, 24 walk-forward origins, horizon 5, measuring COVERAGE AND WIDTH TOGETHER - width alone is meaningless because the conformal layer rescales the cone to target and would absorb a constant bias in the variance estimate."));
children.push(table([2600, 2400, 1600, 1900, 1360], [
  ["Estimator", "Mean width delta", "sd", "Paired t", "Wins"],
  ["parkinson", "+0.48%", "5.51%", "0.30", "6/12"],
  ["garman_klass", "-0.17%", "5.44%", "-0.11", "6/12"],
  ["rogers_satchell", "-1.11%", "5.87%", "-0.65", "7/12"],
]));
children.push(P("Every |t| < 1, win rates are coin flips, and the per-ticker spread runs -8.5% to +10%. NO ESTIMATOR CHANGES THE CONE. Getting there required correcting the work twice, and both corrections are the point."));
children.push(P([B("1. The first run was underpowered and said the opposite. "), T("At 8 origins the range estimators looked 8-12% WORSE; at 24 origins the sign flipped to 1.4% BETTER. A result that reverses when power is added was never a result. Section 3.30 published an underpowered null that Section 3.39 later overturned; applying that lesson to THIS measurement rather than only to the older ones is what caught it.")]));
children.push(P([B("2. The verdict logic was over-claiming. "), T("It declared 'rogers_satchell wins at -1.4% width' from a paired t of -0.65 - precisely the error the rest of this project exists to prevent, written into the new driver. Replaced with a PAIRED test that compares each ticker against itself, so the large between-name variation is differenced out instead of averaged into a decisive-looking mean, and that requires |t| > 2 before naming a winner.")]));

children.push(H3("Why it fails - a more precise measurement of the wrong quantity"));
children.push(P("scale_to_total restores the missing overnight variance with a CONSTANT factor, but the intraday/overnight split is not constant - it moves with the news and earnings cycle. The range estimators therefore trade sampling noise for a time-varying bias. They are genuinely better at measuring the LAST bar's variance (2x more precise, measured) and no better at forecasting the NEXT one, which is the only thing the cone needs. That distinction is the finding, and it generalises: an estimator's efficiency at describing history is not the same property as its usefulness in a forecast."));
children.push(P("range_volatility.py ships complete, tested (18 tests) and wired into run_har_rv_prediction(rv_estimator=...). The shipped default stays 'squared', per this project's standing rule that an unvalidated change does not ship."));
children.push(P("A note on the coverage column: every arm, baseline included, covers ~0.919 against a 0.95 target in this walk-forward configuration. That is a property of the configuration, not of the estimator choice, and it does not affect the comparison - but it is worth not glossing."));

children.push(H2("3.42 Open interest, and a look-ahead worth 2.9 sigma - the thirteenth negative result"));
children.push(P("Every negative result before this one was measured on a TRANSFORMATION OF OHLCV: more models, more architectures, fractional differencing, range volatility, cross-sectional ranks. Section 3.33 was the single attempt at a second data axis and it died on COVERAGE, not on evidence."));
children.push(P([B("Open interest is the first genuinely orthogonal, obtainable data source this project has found. "), T("It measures POSITIONING - how many contracts are open - and is not derived from price at all. nselib.derivatives.future_price_volume_data serves it historically and free. So the question is different in kind from 'does another function of price help', which has now been answered twelve times.")]));

children.push(H3("The claim, reduced"));
children.push(P("Chapter 3 (Bakshi, 'Analyzing Open Interest') gives a 2x2 interpretation table with NO backtest, NO statistics and NO validation anywhere in the chapter:"));
children.push(table([1800, 1800, 6260], [
  ["Price", "OI", "The chapter's claim"],
  ["Rising", "Rising", "Strongly bullish; trend continues"],
  ["Rising", "Falling", "Short-covering rally; downtrend next"],
  ["Falling", "Rising", "Aggressive short-selling; bearish continues"],
  ["Falling", "Falling", "Forced liquidation; upward move may start"],
]));
children.push(P("Read as a predicted sign, that table is exactly signal = sign(delta price) x sign(delta OI): +1 when the two agree, -1 when they diverge. The whole chapter collapses to one product of two signs, which is convenient - it turns four rules into a single testable signal. Tested on 60 liquid F&O names over 2023-2024 (479 dates), with delta OI from the NEAR-MONTH contract and both delta price and the forward return from the survivorship-free, corporate-action-adjusted bhavcopy panel of Section 3.39."));

children.push(H3("It looked real"));
children.push(table([3200, 3200, 3460], [
  ["Horizon", "Mean IC", "FM t"],
  ["1 day", "+0.0198", "+2.88"],
  ["5 day", "+0.0078", "+1.12"],
]));
children.push(P("At one day that clears the conventional threshold, on a genuinely orthogonal data source, with all four quadrants leaning the direction the chapter predicts. It would have been the project's second positive finding."));

children.push(H3("It was a publication-timing look-ahead"));
children.push(P([B("NSE publishes the F&O bhavcopy - and therefore open interest for date t - AFTER the close of t. "), T("You cannot trade at the close of t on a number that does not exist until afterwards. The earliest possible entry is the close of t+1, so the honest forward return runs from t+1.")]));
children.push(table([5200, 2400, 2260], [
  ["Variant", "Mean IC", "FM t"],
  ["1d, trade at close t - NOT tradeable", "+0.0198", "+2.88"],
  ["1d, TRADEABLE (one-day lag)", "-0.0018", "-0.27"],
  ["5d, trade at close t", "+0.0078", "+1.12"],
  ["5d, TRADEABLE", "+0.0004", "+0.05"],
]));
children.push(P([B("The effect does not decay under the lag - it vanishes, "), T("and flips sign. Out of period it is nothing in both halves: 2023 t = +0.11, 2024 t = -0.50. The entire 2.9-sigma result was one day of hindsight.")]));

children.push(H3("Why this one is worth a section"));
children.push(P("Nothing here was a modelling choice. The features, the horizon, the universe and the statistic were all fixed before the number appeared; the only thing that changed was WHETHER THE DATA EXISTED WHEN THE TRADE WOULD HAVE BEEN PLACED. A one-day misalignment on a daily signal manufactured an IC of +0.02 at t = 2.88 out of an effect of exactly zero."));
children.push(P("That is a useful calibration on every 'significant' daily-frequency result in this literature, and on the chapter itself - which asserts its table confidently and never tests it at all. The driver now prints BOTH rows, labelled, so the gap is visible rather than reconstructible."));
children.push(P("Two further reasons the tradeable version was never going to survive even if it had held: only 38% of a liquid NSE universe is F&O-eligible (Section 3.40), so breadth is cut by two-thirds; and a ONE-DAY signal implies ~100% daily turnover against the ~20 bp of STT alone that Section 3.40 measured, where a 5-day signal at 6.1 bp breakeven already failed."));
children.push(P([B("The thirteenth negative result, and the first to rule out an orthogonal data source rather than another feature of the same one. "), T("The book's only empirically testable claim does not survive contact with its own publication schedule.")]));

children.push(H1("4. Reading the Screen: A Decision Guide"));
children.push(P("The app puts a lot of numbers on one page, and they are NOT equally load-bearing. This chapter is the user's guide to them: what each one is, what value counts as strong or weak, and — the part that matters — which decision it can actually support."));
children.push(P([B("The one-sentence version. "), T("This app is built to tell you HOW UNCERTAIN the next move is, and WHETHER ANY MODEL HAS DEMONSTRABLE SKILL on this ticker right now. It is not built to tell you where the price is going. The decisions it genuinely supports are therefore abstain / size / set a stop — not buy / sell. Every design choice below follows from that, including the ones that deliberately withhold a number you might want.")]));

children.push(H2("4.1 Read it in this order"));
children.push(P("The layout is deliberately top-down: each block gates the one below it. Reading it out of order is the single most common way to reach a wrong conclusion from a correct screen."));
children.push(num("Data-quality banner — is the INPUT sound? If this is red, stop here; nothing below it is meaningful."));
children.push(num("Abstention banner — how many of the selected models beat a random walk on this ticker and horizon."));
children.push(num("Consensus cards — median forecast, and the bullish / bearish / abstained split."));
children.push(num("Confidence and Basis columns — the per-model verdict and WHY it got that verdict."));
children.push(num("Risk & Probability panel — the actual deliverable: range, VaR, expected shortfall, probabilities."));
children.push(num("Signal Score and Conviction — worth reading only for rows that cleared step 4."));
children.push(num("Per-model charts — the 95% band against the grey dotted random-walk line."));
children.push(P([B("Row order in the Model Comparison table is not a ranking. "), T("The table is sorted for display, not by merit, and the lowest-error model is not a winner: across the full set, White's Reality Check and Hansen's SPA found no selection-bias-free edge over a random walk (p ~ 0.9; Section 6.5). Reading the top row as “the best model” is exactly the data-snooping error the whole evaluation layer exists to prevent.")]));

children.push(H2("4.2 Step 1 — the data-quality banner decides whether to continue"));
children.push(table([2900, 1500, 4960], [
  ["Banner", "Mode", "What to do"],
  ["Data quality OK (score n/100)", "ok", "Continue."],
  ["Data-quality caveats", "warn", "Continue, but widen your margin — something in the feed is imperfect."],
  ["Event risk detected — showing the risk cone", "risk_cone_only", "NO DIRECTIONAL CALL. An earnings date or a gap is inside the window; the range is the only output."],
  ["Forecast withheld — data quality insufficient", "abstain", "STOP. Directional calls are already suppressed. Refetch, or pick another ticker."],
]));
children.push(P("Open “Data-quality details” for the reason codes. This gate runs on the fetched series at request time and catches a broken INPUT; it says nothing about whether the model is any good — that is step 2. (Mechanics: Section 3.18.)"));

children.push(H2("4.3 Step 2 — the abstention banner is the honest headline"));
children.push(table([3100, 3100, 3160], [
  ["Banner", "Meaning", "Decision"],
  ["No model showed a statistically reliable edge", "zero of n models reached High or Medium", "Treat the RANGE as the entire output. Do not act on the point forecast."],
  ["Only k of n models beat the baseline", "fewer than half", "Weight the range heavily; the point line is weak evidence."],
  ["k of n models showed a measurable edge", "at least half", "The strongest state this app produces — and still small-sample (see 4.5)."],
]));
children.push(P("The red banner is the EXPECTED state for most tickers at short horizons. It is a finding, not a malfunction."));

children.push(H2("4.4 Step 3 — consensus cards, and why the vote count is not a vote"));
children.push(P("Median Forecast is the median across selected models, with its percentage change. Models Bullish / Bearish counts the directional calls that survived gating, and a caption reports how many were withheld."));
children.push(P("Two cautions that matter more than the numbers:"));
children.push(bullet([B("The models are not independent voters. "), T("They share the same OHLCV history, largely the same engineered features, and in several cases the same family. “14 of 19 bullish” is emphatically NOT fourteen independent opinions — it is closer to one opinion, computed fourteen ways, with correlated errors. Treat agreement as weak corroboration, never as a probability.")]));
children.push(bullet([B("The median is more robust than any single row, "), T("which is precisely why it is the headline. If the median and your chosen model disagree sharply, the model is the outlier, not the median.")]));

children.push(H2("4.5 Step 4 — Confidence and Basis: the only skill claim on the page"));
children.push(P("Confidence comes from a walk-forward backtest run at request time on recent history, and it is the single most decision-relevant column. The rule (backtest.confidence_bucket) is fixed and auditable:"));
children.push(table([1500, 4200, 3660], [
  ["Bucket", "Rule", "How to read it"],
  ["High", "RMSE improvement > 5% over the best naive baseline, AND Diebold-Mariano p < 0.10, AND 95% coverage within 0.85-0.99", "A measurable edge with trustworthy bands."],
  ["Medium", "improvement > 2% and DM p < 0.20", "A modest, weakly significant edge."],
  ["Low", "improvement > 0, but not significant", "Better than the random walk WITHIN NOISE. Not evidence."],
  ["No edge", "no improvement", "No better than assuming the price stays put. The directional call is WITHHELD."],
  ["No data", "insufficient history for the check", "Unassessed — treat as No edge."],
]));
children.push(P([B("The honest caveat, which belongs next to every High you ever see. "), T("This gate runs 3 ORIGINS on at most 600 rows (_GATE_SPLITS = 3), because it must return while a user waits. Three origins is enough to catch a model that is clearly broken; it is NOT enough to establish skill. A High here means “worth a closer look with run_backtest.py on more origins”, not “proven”. Conversely, No edge on three origins is quite reliable — it is much easier to fail to beat a random walk convincingly than to beat one by luck three times.")]));
children.push(P("Basis is the plain-language reason, so no row shows a bare verdict:"));
children.push(table([4200, 5160], [
  ["Basis text", "What happened"],
  ["beats random walk (DM p=..., cov ...%)", "High — with the actual p-value and coverage shown."],
  ["weak edge (DM p=...)", "Medium."],
  ["within noise (+...% vs RW, DM p=...)", "Low — the improvement is stated so you can see how small it is."],
  ["no edge vs random walk (DM p=...)", "No edge."],
  ["withheld — data quality", "The data-quality gate overrode the skill test."],
  ["withheld — unseen market regime", "The novelty gate fired: current conditions are off-manifold, so a backtest-derived bucket would be an extrapolation (Section 3.26; ships off by default)."],
  ["... · unusual regime", "An advisory suffix — conditions are unusual but not unprecedented; the verdict stands, with a caveat."],
]));
children.push(P([B("HAR-RV always reads No edge, and that is correct. "), T("It makes no point-forecast claim by design; its entire output is the calibrated risk cone (Section 3.12). Do not read its bucket as failure — and do not deselect it, because the fat-tailed risk panel depends on it.")]));

children.push(H2("4.6 Step 5 — the Risk & Probability panel is the deliverable"));
children.push(table([2600, 3200, 3560], [
  ["Metric", "What it is", "What decision it supports"],
  ["Likely range (95%)", "the calibrated interval at the horizon", "THE PRIMARY OUTPUT. Stop placement, position sizing, whether the trade you had in mind is even distinguishable from noise."],
  ["P(price up)", "probability of finishing above today", "Direction only if it is far from 50% — see the calibration warning below."],
  ["P(gain > +x%) / P(loss > x%)", "probability of a move beyond your threshold (set it yourself)", "“Is my target plausible at this horizon?” Often the most useful number on the page."],
  ["95% downside (VaR)", "the 5th-percentile price", "A worst-case-but-not-extreme reference for sizing."],
  ["Expected shortfall", "the AVERAGE outcome in that worst 5%", "What a bad day actually costs, not just where it starts. Always worse than VaR."],
  ["Downside / upside vol", "dispersion split by direction", "Whether the risk is symmetric."],
  ["Vol skew (down/up)", "their ratio", "> 1 means the downside is the fatter side. Size smaller when it is."],
]));
children.push(P("Two things to check before trusting this panel:"));
children.push(bullet([B("Read the caption. "), T("“Probabilities are counted directly off the empirical, fat-tailed return distribution” means HAR-RV (or Vol-LSTM) was in the run and the tail is real. “Approximate read” means no fat-tailed model was selected and each 95% band was approximated as log-normal — which UNDERSTATES TAIL RISK, the one thing you least want understated. Add HAR-RV to the selection and re-run.")]));
children.push(bullet([B("Treat P(up) as ordinal, not cardinal. "), T("A probability read second-hand off a regression interval is not a calibrated probability, and this project measured that directly: the same construction scored ECE ~ 0.31 in the cross-sectional work (Section 3.30 / 6.14), i.e. a “60%” could be off by roughly 30 points. Use it to rank (“further from 50% than yesterday”), not as a number to bet proportionally on. The properly calibrated alternative — a classifier asked DIRECTLY for a probability, reaching ECE 0.0139 — exists in cross_sectional_model.py but is NOT wired into the UI.")]));

children.push(H2("4.7 Step 6 — Signal Score and Conviction, for rows that earned it"));
children.push(P("Signal Score (%) is the model's forecast percentage change to the horizon. It is the value the Bullish/Bearish call is computed from, and on its own it is close to meaningless: a +3% signal from a No-edge model is a number a random walk would also produce."));
children.push(P("Conviction = the forecast move divided by half the model's own 95% band."));
children.push(table([2200, 7160], [
  ["|Conviction|", "Reading"],
  ["< 0.5", "Within the model's own noise. Ignore the direction."],
  ["0.5 - 1.0", "A real move relative to its uncertainty, but inside the band."],
  [">= 1.0", "The move exceeds the model's 95% band — the current price sits outside it. High conviction."],
  ["—", "The model emits no interval."],
]));
children.push(P([B("The trap: "), T("conviction is measured against THE MODEL'S OWN band, so a model with a badly narrow band manufactures high conviction. That is why the two columns must be read together — a high Conviction on a row whose Basis reports poor coverage is an over-confident model, not a strong signal. Coverage in the 0.85-0.99 window is one of the three conditions for High, which is why High + Conviction >= 1 is the only combination worth weight.")]));

children.push(H2("4.8 Step 7 — the charts"));
children.push(P("Each chart overlays history, the forecast line, the shaded 95% band, and a GREY DOTTED RANDOM-WALK BASELINE. The question the chart answers is not “where does the line go” but “is the forecast line meaningfully outside the grey line's band?” Usually it is not. That is the honest picture of short-horizon equity forecasting, and seeing it is the point of drawing the baseline at all."));

children.push(H2("4.9 Feature flags: one registry, with the evidence attached"));
children.push(P("Six USE_* toggles decide what the app actually does, and they used to be defined wherever they happened to be consumed - five in UI.py, one in ML_model.py. That is fine until something needs to read ALL of them at once, and the console startup banner does. Building it meant importing a flag out of a model module purely to display it: the UI depending on ML_model for a piece of configuration, which is the wrong direction. config.py is now the single source of truth, and it imports nothing from this project, so anything may import it."));
children.push(table([3400, 1400, 4560], [
  ["Flag", "Ships", "Owning module"],
  ["USE_MARKET_CONTEXT", "off", "market_context.py"],
  ["USE_IV_ADJUST", "off", "iv_data.py"],
  ["USE_ASYMMETRIC_CONE", "off", "HAR_RV_model.py"],
  ["USE_INTRADAY_FEATURES", "ON", "ML_model.py"],
  ["USE_REGIME_NOVELTY", "off", "autoencoder_regime.py"],
  ["USE_PREDICTION_LOG", "ON", "prediction_log.py"],
]));
children.push(P([B("The rationale lives with the flag. "), T("Each registry entry carries the measured result behind its default, so “why is this off?” is answerable without hunting through a documentation section. Four of the six are off because an A/B said so. Running python config.py prints the whole set with reasons.")]));
children.push(P([B("The banner is generated, not hand-listed. "), T("active_flags() derives it from the registry, so a flag added here appears in the console automatically. A flag the operator cannot see is a flag that silently changes results, and a hand-maintained display list is how one goes missing — test_active_flags_covers_the_whole_registry pins it.")]));
children.push(P([B("Every flag has an environment override. "), T("STOCKAPP_USE_MARKET_CONTEXT=1 flips one for a single run, and STOCKAPP_USE_INTRADAY_FEATURES=0 is exactly the A/B this project still owes on the intraday features. Editing a constant to run an experiment is how experiments end up committed by accident. A malformed value falls back to the default rather than raising: a stray export should fail to take effect, not stop the app. An active override is called out in the banner, because a run with one is not the shipped configuration and its numbers need reading that way.")]));
children.push(P([B("The serve-time gate constants moved here too "), T("(GATE_SPLITS = 3, GATE_MIN_TRAIN, GATE_MAX_ROWS) and are env-tunable, which makes the trade-off visible rather than buried: raise STOCKAPP_GATE_SPLITS for a stronger confidence check at the cost of a slower Submit. See Section 4.5 for why three origins is a filter and not proof.")]));
children.push(P("One deliberate wrinkle: ML_model does `from config import USE_INTRADAY_FEATURES` rather than reading it through the module, so ML_model.USE_INTRADAY_FEATURES stays monkeypatchable by the existing parity tests."));

children.push(H2("4.10 The same story in the terminal"));
children.push(P("Running streamlit run UI.py from cmd used to print a long, interleaved trace of per-model chatter — “Fitting Auto-ARIMA...”, “Simulating 10000 price paths...”, “Prediction Complete.” — and NOTHING about what the app concluded. Nineteen models would announce completion and the terminal could not tell you whether a single one of them had beaten a random walk. The conclusion is the product; it was browser-only. console.py closes that gap by adding three blocks around the existing trace."));
children.push(P([B("The startup banner "), T("answers a question the console previously could not: WHICH VERSION OF THE APP IS THIS? Five USE_* flags materially change what the models produce (market-context, IV-tilt, asymmetric-cone, intraday-features, regime-novelty, prediction-log), and an operator watching cmd had no way to tell which were active. The seed and the compute device are printed for the same reason — a reported number is not reproducible unless you know both.")]));
children.push(P([B("The RUN header "), T("frames each Submit — ticker, interval, horizon, model count, timestamp — so one run's trace is separable from the next in a long scroll.")]));
children.push(P([B("The RESULT block is the console mirror of the browser's decision layer, "), T("and it maps line-for-line onto the sections above:")]));
children.push(table([2600, 6760], [
  ["Console line", "UI equivalent"],
  ["data quality", "the data-quality banner (Section 4.2)"],
  ["regime", "the novelty gate's Basis annotation (Section 4.5)"],
  ["confidence", "the Confidence + Basis columns (Section 4.5)"],
  ["consensus", "the consensus cards (Section 4.4)"],
  ["verdict", "the abstention banner (Section 4.3)"],
  ["logged", "browser-silent: rows appended to the forward prediction log (Section 3.29)"],
]));
children.push(P("A representative RESULT block:"));
children.push(P([Code("RESULT  RELIANCE.NS  1d  h=5  (37.4s)")]));
children.push(P([Code("  data quality    OK (score 92/100) -> forecasts usable")]));
children.push(P([Code("  regime          novelty gate off (USE_REGIME_NOVELTY = False)")]));
children.push(P([Code("  confidence      HAR-RV         No edge   no edge vs random walk (DM p=0.55)")]));
children.push(P([Code("                  Meta-Ensemble  Medium    weak edge (DM p=0.14)")]));
children.push(P([Code("                  Quantile-LGBM  Low       within noise (+1% vs RW, DM p=0.31)")]));
children.push(P([Code("  consensus       median 1,423.55 (+0.84%)  |  bullish 2  |  bearish 1  |  withheld 1")]));
children.push(P([Code("  verdict         Only 1 of 4 models beat the random-walk baseline with any")]));
children.push(P([Code("                  reliability here. Weight the range over the point line.")]));
children.push(P([Code("  logged          4 row(s) -> .prediction_log/predictions.jsonl")]));
children.push(P([B("It renders verdicts; it never recomputes them. "), T("The buckets come from the same conf_map, the reasons from the same gating.confidence_reason, and the verdict sentence from the same _honesty_banner the browser renders — passed through strip_markdown so the one authored sentence serves both channels. Re-deriving any of it here is precisely how two surfaces start telling a user different things. The one deliberate ordering choice: the honesty banner is re-read AFTER the data-quality and novelty gates have been applied, so a degraded run reports the withheld verdict rather than the pre-gate one.")]));
children.push(P([B("Two robustness details that are not cosmetic. "), T("Output is plain ASCII and every write is wrapped: a Windows cmd session on a legacy code page cannot encode a rupee sign or an em dash, and an unguarded print there raises UnicodeEncodeError — which would let a cosmetic log line kill a forecast. _write degrades to a replacement character instead, and test_write_survives_a_legacy_console_encoding pins that behaviour. The banner is also printed ONCE PER PROCESS via a module-level flag rather than st.session_state, because Streamlit re-executes UI.py top-to-bottom on every widget interaction and a naive banner would reprint on every click.")]));
children.push(P("Set STOCKAPP_QUIET=1 to silence all of it; the per-model chatter is unaffected either way."));

children.push(H2("4.11 Putting it together"));
children.push(table([4200, 5160], [
  ["Screen state", "Supported decision"],
  ["Data quality red (abstain)", "Act on nothing. Fix the data."],
  ["Event risk / risk_cone_only", "Size for the range. No direction, whatever the table says."],
  ["Red abstention banner, all No edge", "Range-only. If your thesis needs a direction, this app does not supply one — that is information, and it is worth acting on."],
  ["Mixed, your model High + Conviction >= 1 + agrees with the median", "The strongest state available. Still 3 origins — confirm with run_backtest.py before sizing up."],
  ["High conviction, but Basis shows poor coverage", "An over-confident model. Discount it."],
  ["P(loss > x%) materially exceeds P(gain > +x%) at the same x, vol skew > 1", "Asymmetric downside. Size down or widen the stop."],
  ["“Approximate read” caption", "Re-run with HAR-RV before using any tail number."],
]));

children.push(H2("4.12 What the screen cannot tell you"));
children.push(P("Stated plainly, because a guide that only explains the numbers implies they cover more than they do:"));
children.push(bullet([B("Whether to buy. "), T("No entry signal is produced anywhere, by design.")]));
children.push(bullet([B("Anything about fundamentals, news, or announcements. "), T("Inputs are OHLCV and a market proxy. A result that will be obsolete the moment an earnings release lands is not flagged as such beyond the event-risk gate.")]));
children.push(bullet([B("Which model is best. "), T("SPA and the Reality Check say the data cannot support that claim.")]));
children.push(bullet([B("Real-world probability. "), T("Every probability is conditional on the model and on the past resembling the future. It is model uncertainty, not certainty.")]));
children.push(bullet([B("Anything validated at longer horizons. "), T("The evidence base here is short-horizon daily and hourly.")]));
children.push(P([B("Before acting, three questions. "), T("Is the data-quality banner green? Does the RANGE — not the point forecast — still make the position worth taking? And is there a single number on the page that would look different if the model had no skill at all? If the answer to the last one is no, the screen is telling you to do nothing, which is a legitimate output and the one it produces most often.")]));

children.push(H1("5. Evaluation and Backtesting"));
children.push(P("A model can't be trusted until tested out-of-sample on a moving window. backtest.py provides this."));
children.push(H2("5.1 Walk-forward backtesting"));
children.push(P("walk_forward_backtest picks several origins through history; at each it re-fits on data up to that point, forecasts the next horizon steps, and compares to what actually happened — mimicking real deployment (you only know the past)."));
children.push(H2("5.2 Baselines"));
children.push(P("Every forecast is compared to a ladder of baselines, not just one, because beating the random walk is a surprisingly weak bar:"));
children.push(bullet([B("Naive (random walk) "), T("— the next horizon prices all equal the last observed price. The primary benchmark; a model that can't beat it adds no value.")]));
children.push(bullet([B("Drift "), T("— random walk plus the mean historical log-return; beats naive whenever there's any trend.")]));
children.push(bullet([B("AR(1) "), T("— a first-order autoregression on log returns; beats naive whenever there's short-horizon return autocorrelation.")]));
children.push(P("The leaderboards report naive_rmse, drift_rmse and ar1_rmse side by side."));
children.push(H2("5.3 Is the edge real? The Diebold-Mariano test"));
children.push(P("RMSE deltas on near-random-walk returns are often inside the noise band, so a smaller RMSE on a handful of origins can be luck. The Diebold-Mariano test (backtest.diebold_mariano) asks whether the loss differential between the model and the naive walk is statistically different from zero. It uses a HAC (Newey-West) long-run variance with h−1 lags — to account for the autocorrelation overlapping multi-step forecasts create — plus the Harvey-Leybourne-Newbold small-sample correction. The harness reports the statistic (negative means the model is more accurate), a two-sided p-value, and a plain verdict (significantly better / not significant / significantly worse); the leaderboards carry dm_p and dm_sig."));
children.push(H2("5.4 Metrics"));
children.push(table([2200, 5360, 1800], [
  ["Metric", "What it measures", "Good value"],
  ["RMSE / MAE", "Average price error", "lower"],
  ["SMAPE", "Symmetric percentage error", "lower"],
  ["MASE", "Error scaled by the naive forecast's error (comparable across tickers)", "< 1 beats naive"],
  ["Directional accuracy", "Fraction of steps with correct up/down direction", "> 0.5 beats chance"],
  ["Coverage", "Fraction of actuals inside the 95% interval", "approx 0.95"],
]));
children.push(P("MASE and directional accuracy are scale-free, so they compare across stocks; raw RMSE is not (it depends on the price level)."));
children.push(P([B("Economic metrics run alongside them. "), T("walk_forward_backtest also returns a strategy block (strategy_metrics.evaluate_strategy) that turns the same forecasts into a cost-charged return stream and reports Sharpe, Sortino, information ratio versus buy-and-hold, maximum drawdown, information coefficient, hit rate and turnover — because a good RMSE and a profitable forecast are separate claims, and only the second is what a user of a forecast wants (Section 3.23). Pass strategy=False to skip it, cost_bps= to change the cost assumption, and watch the overlapping_origins flag: if the origin spacing is shorter than the horizon the trades overlap and every risk-adjusted figure is optimistic.")]));
children.push(H2("5.5 Running the backtests"));
children.push(P("The manual evaluation drivers live in tests/validation/ (run from the repo root):"));
children.push(P([Code("python tests/validation/run_full_backtest.py AAPL")]));
children.push(P([Code("python tests/validation/run_multi_backtest.py \"AAPL,MSFT,GOOGL\"")]));
children.push(P([Code("python tests/validation/run_multi_backtest.py \"AAPL,MSFT,GOOGL\" --fast")]));
children.push(P("Both drivers checkpoint to CSV and are resumable if interrupted."));
children.push(P("Three further drivers answer the questions the statistical leaderboards do not — is it profitable, is the risk number calibrated, and does the deep volatility model beat the four-parameter regression:"));
children.push(P([Code("python tests/validation/run_strategy_eval.py RELIANCE.NS [--fast] [--cost 25] [--deadband]")]));
children.push(P([Code("python tests/validation/run_var_backtest.py RELIANCE.NS [--alpha 0.01] [--horizon 5]")]));
children.push(P([Code("python tests/validation/run_vol_comparison.py RELIANCE.NS [--quick] [--online]")]));

// 5. Findings
children.push(H1("6. Empirical Findings"));
children.push(P("Numbers below are indicative, not definitive — a few tickers and origins — so treat them as directional evidence. The point is the method: walk-forward + a baseline ladder + the Diebold-Mariano significance test, so claims are grounded."));
children.push(H2("6.1 Multi-ticker leaderboard"));
children.push(P("RELIANCE.NS / TCS.NS / INFY.NS, 4 splits, 5-day horizon, ranked by mean RMSE:"));
children.push(table([2700, 1700, 1900, 1500, 1560], [
  ["Model", "RMSE mean", "beats-naive", "DM wins", "MASE"],
  ["Ensemble-Stack", "28.06", "3/3", "TCS (p=0.0002)", "1.37"],
  ["ARIMA+GARCH", "32.11", "3/3", "TCS (p=0.003)", "1.54"],
  ["RegimeSwitching", "32.47", "3/3", "TCS, INFY", "1.55"],
  ["ARIMAX+GARCH", "32.53", "1/3", "TCS (worse on INFY)", "1.56"],
  ["Meta-Ensemble", "33.15", "1/3", "-", "1.59"],
  ["XGBoost / LightGBM / Quantile", "33.4-33.8", "0-1/3", "-", "~1.6"],
  ["LSTM", "33.98", "0/3", "-", "1.57"],
  ["N-BEATS", "63.78", "0/3", "worse (TCS 111)", "2.41"],
]));
children.push(H2("6.2 What the evidence says"));
children.push(bullet([B("The Diebold-Mariano test is essential. "), T("Several models beat naive on RMSE, but statistically-significant edge is rare and ticker-specific (concentrated on TCS; none on RELIANCE). Beating the random walk on a handful of origins is often inside the noise band.")]));
children.push(bullet([B("Most consistent: "), T("the Ensemble-Stack and the statistical models (ARIMA / Regime-Switching) beat naive on all three tickers and are the only DM-significant wins.")]));
children.push(bullet([B("MASE > 1 almost everywhere "), T("— against the one-step naive, genuine multi-step skill is thin at a 5-day horizon.")]));
children.push(bullet([B("N-BEATS is still unstable "), T("(blew up to RMSE 111 on TCS); the earlier capacity reduction helped on US data but isn't sufficient here. Neural nets remain high-variance — never trust a single run's ranking.")]));
children.push(bullet([B("Prophet over-extrapolates "), T("and was under-covered (~0.7) on some tickers.")]));
children.push(H2("6.3 Did market context help? No (the honest result)"));
children.push(P("A controlled A/B (context ON vs OFF, same models and splits) on the two large-cap Indian tickers. Delta is the change in RMSE; positive means worse:"));
children.push(table([3360, 2000, 2000, 2000], [
  ["Model", "RELIANCE", "TCS", "Effect"],
  ["XGBoost", "+10.3%", "+6.4%", "worse"],
  ["LightGBM", "+5.0%", "+10.9%", "worse"],
  ["Quantile-LGBM", "+2.9%", "-0.1%", "worse / neutral"],
  ["Ensemble-Stack", "+0.2%", "+0.3%", "neutral"],
  ["ARIMAX+GARCH", "-0.2%", "+0.7%", "neutral"],
]));
children.push(P("Adding the eight context columns hurt the single tree models and was neutral for the ensemble/ARIMAX — none improved. At a 5-day horizon the contemporaneous market state has little power over the next week's return (the market is itself a random walk), so the extra columns mainly added overfitting surface."));
children.push(P([B("Excess-return reframing did not help either. "), T("Predicting the excess return (stock minus market) instead of the absolute return, A/B'd the same way:")]));
children.push(table([3360, 2000, 2000], [
  ["Model", "RELIANCE", "TCS"],
  ["XGBoost", "+12.5%", "+5.7%"],
  ["LightGBM", "+11.2%", "+2.4%"],
  ["Quantile-LGBM", "+3.5%", "+7.8%"],
  ["Ensemble-Stack", "-3.4%", "+1.6%"],
]));
children.push(P("Same pattern — worse for the tree singles, neutral for the ensemble. Expected, because the expected short-horizon market return is ~0, so reconstruction re-injects the unforecastable market move and absolute-price RMSE can't improve. Conclusion across both experiments: market data helps cross-sectional / ranking problems, not single-stock absolute-price forecasting at a 5-day horizon. Both features ship off by default."));
children.push(H2("6.4 Cross-sectional probe, HAR-RV coverage, and calibration"));
children.push(P([B("Cross-sectional probe (the ranking fork). "), T("A 20-name NSE universe (run_cross_sectional.py) showed 12-1 momentum with the correct sign (rank-IC ~ +0.02, long-short hit-rate up to 59%) but not statistically significant (t ~ 1) — expected, since real cross-sectional factors have small ICs that need hundreds of names to detect. A ranking product is plausible but unconfirmed at this scale, and pursuing it is a deliberate product fork (rank a universe), not a tweak to the single-ticker app.")]));
children.push(P([B("HAR-RV coverage (where the value is). "), T("HAR-RV's point RMSE equals the random walk by construction; its deliverable is the cone. With the per-horizon conformal multiplier, coverage improved (e.g. RELIANCE ~0.80 toward full) but still under-covers on some tickers (TCS/INFY ~0.80 vs 0.95 target). The residual gap is static conformal meeting a volatility regime shift in the unseen horizon — the known limitation that motivates adaptive conformal (ACI) in an online monitoring loop. Coverage estimates are also noisy at ~25 points.")]));
children.push(P([B("Calibration of the probabilistic outputs (run_calibration.py). "), T("Validating the uncertainty rather than the point forecast — illustrative single-ticker run (RELIANCE.NS, 5-day horizon, 6 origins):")]));
children.push(table([3400, 2000, 3960], [
  ["Diagnostic", "Result", "Read"],
  ["HAR-RV CRPS, empirical vs log-normal (final horizon)", "24.63 vs 25.35", "The fat-tailed empirical read scores better — the Section 3.13 risk-panel fix helps the proper score, not just in principle."],
  ["HAR-RV PIT vs Uniform(0,1)", "mean 0.47, KS 0.16, p ~ 0.39", "Can't reject calibration — the conformal cone is roughly well-calibrated across quantiles, not just at 95%."],
  ["Coverage quality (per horizon)", "coverage 0.83-1.0; tail balance ~0 to -0.17", "Near target; misses lean slightly upside on this name (cone isn't systematically understating downside)."],
  ["XGBoost P(up) reliability", "ECE ~ 0.31 (overconfident)", "Directional probabilities are noisy/miscalibrated — the honest reason the app withholds the call when the gate says No edge."],
]));
children.push(P("These numbers are small-sample and single-ticker (illustrative, not a verdict); a firmer read uses more origins across several tickers. The point is that the harness now measures whether the probabilities are honest."));
children.push(P([B("Adaptive (ACI) vs static conformal. "), T("A/B of HAR-RV's cone with adaptive=False vs True (3 NSE tickers, 18 origins, 5-day horizon, via compare_static_vs_aci):")]));
children.push(table([2600, 2400, 2200, 2160], [
  ["Ticker", "|cov-0.95| static -> ACI", "width static -> ACI", "Winner"],
  ["RELIANCE.NS", "0.032 -> 0.050", "10.79% -> 10.25%", "static"],
  ["TCS.NS", "0.041 -> 0.032", "10.75% -> 9.81%", "ACI"],
  ["INFY.NS", "0.041 -> 0.032", "11.96% -> 10.96%", "ACI"],
]));
children.push(P("Honest read: average miscoverage is a tie (~0.038 both), but ACI yields consistently ~7% narrower intervals and improves the two names (TCS/INFY) that were the documented coverage problem children — on both coverage and width. It slightly over-tightens RELIANCE, an already-well-calibrated calm name. So ACI ships on by default as a coverage-neutral, sharpness-positive change whose real upside is regime response, which this calm 2023-2026 window barely exercised."));

children.push(P([B("Stress-period test (run_stress_test.py). "), T("Slicing RELIANCE's full history into volatility regimes and A/B-ing the cone:")]));
children.push(table([2900, 1900, 2400, 2160], [
  ["Window", "daily vol", "|cov-.95| static -> ACI", "width static -> ACI"],
  ["COVID crash 2020", "3.75%", "0.050 -> 0.067", "16.31% -> 18.15%"],
  ["2022 drawdown", "1.67%", "0.050 -> 0.047", "13.15% -> 12.82%"],
  ["Calm 2024", "1.44%", "0.043 -> 0.040", "11.14% -> 9.92%"],
]));
children.push(P("Honest, slightly counter-intuitive result: in the COVID extreme ACI did the right thing directionally — it widened the cone ~11% — but its coverage came out marginally worse than static, because calibrating a band in the fat tail of a crash is genuinely hard; in milder regimes it sharpened and slightly improved coverage. So the tidy 'ACI wins most in stress' hypothesis is NOT borne out on this name: ACI is a sharpness-positive, roughly coverage-neutral change that moves the cone the right way under stress without fully solving tail calibration."));

children.push(H2("6.5 Data-snooping-robust selection (SPA / Reality Check)"));
children.push(P("run_spa.py ran White's Reality Check and Hansen's SPA over a 40-origin loss panel for the fast 9-model subset on RELIANCE.NS (5-day horizon, squared loss, benchmark = random walk). Per-model mean loss-differential vs the random walk (positive = beats it) and SPA t-stat:"));
children.push(table([3400, 3000, 2960], [
  ["Model (best -> worst)", "mean loss-diff vs RW", "SPA t-stat"],
  ["ARIMA+GARCH", "+1.02", "+0.33"],
  ["RegimeSwitching", "+0.16", "+0.50"],
  ["HAR-RV (= random walk)", "0.00", "0.00"],
  ["ARIMAX+GARCH", "-1.45", "-0.50"],
  ["Ensemble / Meta / Quantile", "-27.7 / -30.5 / -35.6", "-0.53 / -0.87 / -0.68"],
  ["XGBoost / LightGBM", "-47.0 / -47.2", "-1.09 / -1.01"],
]));
children.push(P("White's Reality Check p = 0.899, Hansen's SPA p = 0.874 -> H0 NOT rejected. Even the best-looking model (ARIMA+GARCH) is comfortably within what trying 9 models would produce by chance, and the gradient-boosted trees are materially worse than the random walk. This is the data-snooping-robust confirmation of the project's central honest finding: at this horizon no model has a selection-bias-free edge over the random walk — exactly why the product's value was relocated to calibrated uncertainty. (Small-sample, single-ticker; the conservative Reality Check drives the verdict.)"));

children.push(H2("6.6 Forward-looking India-VIX tilt"));
children.push(P("A/B of the HAR-RV cone with vs without the India-VIX tilt (Section 3.20, via compare_iv_adjust, ACI on in both arms, 5-day horizon, 18 origins):"));
children.push(table([3400, 2200, 1880, 1880], [
  ["Window", "|cov-0.95| no-IV -> +IV", "no-IV width", "+IV width"],
  ["RELIANCE.NS (calm 2021-26)", "0.046 -> 0.054", "17.19%", "17.46%"],
  ["TCS.NS (calm 2021-26)", "0.050 -> 0.050", "20.16%", "20.19%"],
  ["INFY.NS (calm 2021-26)", "0.050 -> 0.050", "15.86%", "16.08%"],
  ["RELIANCE.NS (2019-20 crash)", "0.020 -> 0.020", "14.98%", "16.39%"],
]));
children.push(P("Honest result: in calm regimes implied ~ realized, so the multiplier sits near 1 and barely moves the cone (RELIANCE slightly worse, the rest unchanged). In the concentrated COVID-crash window the tilt did the directionally right thing — it widened the cone ~1.4 pp as VIX spiked — but with no coverage payoff on this sample. So the tilt is principled and forward-looking but unproven on the available NSE data, and ships off by default. Likely reasons it underwhelms here: India VIX is a market-level (NIFTY) signal, so it carries only each stock's systematic vol slice (single-name option IV, which it cannot access, would be sharper), and the 2021-26 calm window offers little implied/realized divergence to exploit."));

children.push(H2("6.7 Asymmetric cone (downside tail-miss balance)"));
children.push(P("A/B of the symmetric vs asymmetric cone (Section 3.21, via compare_asymmetric, ACI on in both, 5-day horizon, 18 origins). The decisive metric is tail-miss imbalance, mean |lower_miss - upper_miss| (lower = better-balanced):"));
children.push(table([2600, 2400, 2300, 2060], [
  ["Ticker", "sym tail-imbalance", "asym tail-imbalance", "asym |cov-.95|"],
  ["RELIANCE.NS", "0.033", "0.067", "0.059"],
  ["TCS.NS", "0.067", "0.078", "0.070"],
  ["INFY.NS", "0.034", "0.022", "0.035"],
]));
children.push(P("Better for INFY, worse for RELIANCE/TCS. The reason is statistical: splitting the calibration into two half-size per-side samples adds estimation noise, and on a near-symmetric residual distribution (the calm-regime norm) that noise outweighs the asymmetry it is trying to capture. The asymmetric cone is principled and visibly does the right thing under genuine skew (the single-fit RELIANCE example: downside -8.1% vs upside +4.7%), but on this data it does not reliably beat the symmetric cone, so it ships off by default. The always-on downside reporting (expected shortfall, semideviation, vol skew) needs none of this — it reads the empirical distribution directly."));

children.push(H2("6.8 Economic evaluation: would acting on these forecasts have made money?"));
children.push(P("run_strategy_eval.py RELIANCE.NS --fast (5-day horizon, 8 non-overlapping origins, 10 bps per side, sign positions). Buy-and-hold returned -7.30% over the same periods. Illustrative and tiny-sample, like every table in this section:"));
children.push(table([2200, 1200, 1100, 1500, 1200, 1200, 1160], [
  ["Model", "RMSE", "MASE", "Total ret %", "Sharpe", "Max DD %", "IC (t)"],
  ["RegimeSwitching", "23.97", "1.72", "+7.39", "3.20", "-2.43", "n/a"],
  ["Ensemble-Stack", "22.59", "1.58", "-1.83", "-0.69", "-4.80", "0.33 (0.86)"],
  ["ARIMAX+GARCH", "23.90", "1.72", "-2.53", "-0.94", "-5.09", "0.46 (1.27)"],
  ["XGBoost / LightGBM", "26.3", "1.89", "-7.39", "-3.37", "-9.83", "~0"],
  ["Quantile-LGBM", "27.31", "2.00", "-8.42", "-4.02", "-10.42", "0.04 (0.10)"],
  ["ARIMA+GARCH", "23.96", "1.73", "-9.13", "-4.26", "-9.54", "-0.25 (-0.63)"],
]));
children.push(P([B("Six of seven models lose money. "), T("The one that does not — RegimeSwitching at Sharpe 3.20 — sits well inside its own +/-2.5 standard error, i.e. statistically indistinguishable from zero; sharpe_significant is False for every row. The tree models are the worst economically, mirroring their position in the SPA table (Section 6.5). All of this is consistent with the SPA result rather than in tension with it, and matches the prediction written before the driver was run.")]));
children.push(P([B("The two rankings genuinely differ. "), T("The rank correlation between the RMSE ordering and the Sharpe ordering was +0.45 — positively related but far from identical. The best model on RMSE (Ensemble-Stack, 22.59) is second on Sharpe and still loses money; the best on Sharpe is mid-table on RMSE. That is the concrete argument for reporting both tables rather than letting one stand in for the other.")]));

children.push(H2("6.9 VaR method comparison and backtests"));
children.push(P("run_var_backtest.py RELIANCE.NS (full history 1996-2026, alpha = 0.05, 1-day horizon, 250-bar window, 7,440 non-overlapping evaluations). Ranked by conditional-coverage p-value:"));
children.push(table([2400, 1700, 1700, 1700, 1860], [
  ["Method", "Exception rate", "Avg VaR reserved", "Kupiec p", "Verdict"],
  ["variance-covariance", "0.0487", "3.45%", "0.5932", "rate OK, breaches clustered"],
  ["historical", "0.0539", "2.98%", "0.1274", "rate OK, breaches clustered"],
  ["generative (block bootstrap)", "0.0524", "3.02%", "0.3419", "rate OK, breaches clustered"],
  ["fhs", "0.0656", "2.90%", "0.0000", "under-reserves on this window"],
  ["cornish-fisher", "0.1082", "1.45%", "0.0000", "badly under-reserves (see 3.25)"],
]));
children.push(P([B("Two honest reads. "), T("First, every method's breaches were flagged as clustered — which is expected rather than damning: with 7,440 evaluations spanning 2008 and 2020, the independence test has overwhelming power and volatility clustering is real. On a sample this large the informative comparison is the relative LR statistic across methods, not the pass/fail label. Second, the Cornish-Fisher row was the genuine surprise: a 10.8% exception rate against a nominal 5%. Chasing it down traced to the sign of its kurtosis term inside |z| < sqrt(3) (Section 3.25) — now a documented property with a regression test pinning both halves of the behaviour, rather than a number filed under 'close enough'.")]));

children.push(H2("6.10 Volatility model comparison, and the latent HAR-RV bias it exposed"));
children.push(P("run_vol_comparison.py RELIANCE.NS --quick (4 origins, 5-day horizon, 1000 bars). Part 1 scores each model's per-step variance forecast against the realised r^2, ranked by QLIKE (the loss robust to the noise in that proxy). bias_ratio is forecast vol divided by realised vol — 1.0 is unbiased:"));
children.push(table([2600, 1600, 1900, 1700, 1560], [
  ["Model", "QLIKE", "Forecast vol %", "bias ratio", "cum sq error"],
  ["EWMA (lambda=0.94)", "-7.860", "1.280", "1.06", "2.0e-6"],
  ["GARCH (BIC, Student-t)", "-7.794", "1.259", "1.04", "2.0e-6"],
  ["Vol-LSTM", "-7.665", "1.510", "1.25", "2.0e-6"],
  ["HAR-RV (BEFORE the fix)", "-7.263", "2.322", "1.92", "5.0e-6"],
]));
children.push(P([B("HAR-RV was over-stating volatility by ~1.9x "), T("— with 2.5x the cumulative squared error of every other model. A defect in the shipped model, not a property of the data. So Vol-LSTM's apparent win over HAR-RV was not the network learning anything clever; it was simply the only one of the two with a correct level transform.")]));
children.push(P([B("The cause. "), T("forecast_har_variance converted its log-variance forecast to a level with the log-normal Jensen correction exp(mu + resid_var/2). That is right for a Gaussian residual — but the residual of a regression on log(r^2) is log-chi-squared, whose variance is pi^2/2 ~ 4.93. The correction therefore multiplied variance by e^2.46 ~ 11.7 where the correct factor is e^1.27 ~ 3.6, netting ~1.9x in volatility terms.")]));
children.push(P([B("Why it survived this long. "), T("The conformal layer silently absorbs it: the per-horizon multiplier is fitted to the realised dispersion, so an inflated sigma is cancelled by a deflated k and coverage stays correct. The tell-tale was sitting in HAR-RV's own log output the whole time — k(h) ~ 1.0-1.3 against a Gaussian 1.96, i.e. calibration working against the variance forecast rather than with it. Only a direct level check (this driver's bias_ratio column) catches it, which is a good argument for scoring the raw variance and not just the interval.")]));
children.push(P("The fix replaces the Jensen correction with a data-estimated offset (har_level_offset). Re-running the identical comparison:"));
children.push(table([2600, 1600, 1900, 1700, 1560], [
  ["Model", "QLIKE", "Forecast vol %", "bias ratio", "cum sq error"],
  ["EWMA", "-7.860", "1.280", "1.06", "2.0e-6"],
  ["Vol-LSTM (offset model-calibrated)", "-7.803", "1.242", "1.03", "2.0e-6"],
  ["HAR-RV (AFTER the fix)", "-7.796", "1.273", "1.05", "2.0e-6"],
  ["GARCH", "-7.794", "1.259", "1.04", "2.0e-6"],
]));
children.push(P([B("A second bias, in the new model. "), T("Auditing the above exposed that Vol-LSTM had the same class of problem one level down. Its offset was unconditional — log(mean RV) - mean(log RV) on the training block — which corrects the log-chi-squared transform but leaves the NETWORK's own conditional bias untouched (measured bias_ratio 1.25). Switching to a model-calibrated offset — log(mean RV_cal) - mean(predicted log RV_cal) on the held-out calibration block, i.e. 'what constant makes THIS model's forecasts land on the realised level?' — absorbs both in one scalar. Result: bias_ratio 1.249 -> 1.027 (now the best of the four) and QLIKE -7.665 -> -7.803, moving it from 4th to 2nd. Fitting one scalar on the calibration block is what the conformal layer already does with its per-horizon multiplier, and the block is held out of training either way, so it adds no lookahead.")]));
children.push(P([B("The original prediction was right after all. "), T("HAR-RV moves from last to second, effectively tied with GARCH and near-unbiased, and its cumulative squared error drops to the field average; k(h) now averages ~2.4, straddling 1.96 as it should. With the bug removed the deep model does not beat the four-parameter OLS regression — nor does it beat plain EWMA or GARCH. That is the expected shape of result for a network on ~1000 daily bars, and the earlier reversal was entirely an artefact of the defect.")]));
children.push(P("The fix is cone-neutral, verified by re-running the cone diagnostics at identical settings before and after:"));
children.push(table([2600, 2600, 2100, 2060], [
  ["", "Coverage (per step)", "Mean width", "Final-horizon CRPS"],
  ["Before", "1.00 at every step", "9.22%", "19.71"],
  ["After", "1.00 at every step", "9.10%", "19.81"],
]));
children.push(P("Coverage is unchanged, width is marginally narrower, and the CRPS difference is well inside noise on 20 step-records — so every cone A/B published in this document remains valid. What the fix corrects is the volatility column HAR-RV reports (surfaced in the UI and consumed by iv_data's tilt) and its ranking against any unbiased volatility model. Pinned by two regression tests, one of which asserts the old transform would have failed, so the check cannot pass vacuously."));
children.push(P([B("Part 2 — cone calibration (the deliverable). "), T("At 10 origins post-fix, HAR-RV's cone covers 0.90-1.00 per step (mean |coverage - 0.95| = 0.050) at a mean width of 9.83%, with empirical CRPS beating the log-normal read (18.69 vs 19.22) and PIT not rejecting calibration (KS = 0.149, p = 0.198) though flagged hump-shaped (intervals too wide). Against Vol-LSTM on the 4-origin quick run, both cones over-covered at 1.00, so coverage is uninformative; Vol-LSTM's cone was ~9% narrower (8.40% vs 9.22%) while HAR-RV won CRPS (19.71 vs 20.36). Four origins on one ticker separates nothing — the honest read is 'no separation yet; run more origins across several tickers'.")]));

children.push(H2("6.11 Predictions written first, then checked"));
children.push(P("The Section 3.23-3.26 additions were built and unit-tested before being measured. Their tests are correctness tests (known-answer arithmetic, synthetic series with a known volatility, engineered exception sequences with a known verdict) — not skill claims. So the predictions were written before the drivers ran, then marked with the outcome:"));
children.push(table([2600, 6760], [
  ["Addition", "Prediction, and what actually happened"],
  ["Economic metrics (3.23)", "Predicted: Sharpe near zero, negative after 10 bps, nothing statistically distinguishable. RUN — held. 6 of 7 models lost money; no Sharpe cleared 2 SE."],
  ["VaR backtests (3.25)", "Predicted: Gaussian under-reserves; historical simulation fails independence; FHS passes both. RUN — partly held, one surprise. Every method's breaches read as clustered (the test is overwhelmingly powerful at n = 7,440), and Cornish-Fisher under-reserved badly — traced, documented and pinned."],
  ["Vol-LSTM (3.24)", "Predicted: HAR-RV holds on QLIKE; a four-parameter OLS beating a network on ~1000 bars is the expected outcome. RUN — held, but only after a bug fix. The first run said otherwise; chasing it found the ~1.9x HAR-RV level bias. Fixed, and the prediction then held."],
  ["CNN-LSTM (3.24)", "Predicted: middle of the pack, high run-to-run variance. NOT YET RUN on real data."],
  ["Regime novelty (3.26)", "Predicted: on calm 2021-26 data the gate should almost never fire (that is the design); its value can only be shown on a genuine regime break. NOT YET RUN — needs a stress window around March 2020."],
]));
children.push(P("Writing the predictions down before running the drivers is the same discipline that produced the four documented negative results above (market context, excess returns, IV tilt, asymmetric cone): a stated expectation cannot be retro-fitted to whatever the numbers turn out to be. It earned its keep twice over immediately — both the Cornish-Fisher and the volatility-comparison results were unexpected, and in both cases the surprise is what forced an investigation instead of a number quietly filed under 'close enough'."));

children.push(H2("6.12 Does tuning HAR-RV's lags help? No — the fifth negative result"));
children.push(P("tuning.nested_search over HAR-RV's memory windows, scored by walk-forward negative QLIKE on the variance forecast, 700 inner rows / 300 untouched holdout rows per ticker, exhaustive grid over five lag sets:"));
children.push(table([2200, 2000, 1900, 1700, 1560], [
  ["Ticker", "Search winner", "Holdout default", "Holdout tuned", "Generalises?"],
  ["RELIANCE.NS", "(1, 3, 10)", "7.81632", "7.82239  (+0.00607)", "YES"],
  ["TCS.NS", "(1, 10, 22)", "8.15977", "8.15899  (-0.00078)", "no"],
  ["INFY.NS", "(1, 5, 22)", "6.75660", "6.75660  (0.00000)", "no - picked the default"],
  ["HDFCBANK.NS", "(1, 3, 10)", "8.02523", "7.93134  (-0.09388)", "no"],
  ["ITC.NS", "(1, 3, 10)", "8.01704", "7.97924  (-0.03780)", "no"],
]));
children.push(P("One ticker in five improved, by 0.08% relative — and two got materially worse. The winning lag set is ticker-specific ((1,3,10) three times, (1,10,22) once, and on INFY the search independently re-selected Corsi's canonical (1,5,22)). There is no consistent alternative to ship."));
children.push(P([B("Verdict: keep the canonical (1, 5, 22). "), T("The inner search reliably found a better FIT — every ticker's best inner score beat its default — and that fit did not survive contact with held-out data. This is the fifth documented negative result in this project, alongside market context, excess-return reframing, the India-VIX tilt and the asymmetric cone.")]));
children.push(P([B("The nesting is what makes this readable. "), T("A conventional non-nested search — pick the best inner score, report it — would have produced '(1, 3, 10) beats the default on 3 of 5 tickers, ship it', and shipped a change that is worse on HDFCBANK by 20x the margin it wins on RELIANCE. The structural guard in Section 3.28 is the entire reason the right answer is visible, and it is why nested_search is the only entry point that returns a reportable number.")]));

children.push(H2("6.13 Is the economic leaderboard itself data-snooped? Now checked"));
children.push(P("The Sharpe table in Section 6.8 ranked seven models and named a winner — which is precisely the data-snooping mistake run_spa.py was built to correct for RMSE, left unapplied to the economic table. strategy_metrics.strategy_return_panel now assembles the aligned (T, K) panel of 'net strategy return minus buy-and-hold' differentials, and run_strategy_eval.py runs White's Reality Check and Hansen's SPA over it before printing any conclusion."));
children.push(P("The panel is intersected on common origins across models: the stationary bootstrap resamples rows, so it can only preserve the cross-model dependence if every column refers to the same origin — the same discipline collect_loss_panel applies to the loss panel. A model that failed at an origin drops that origin for everyone."));
children.push(P([B("Validated against eight pure-noise models "), T("on a shared realised-return series: best mean differential +0.0018, Reality Check p = 0.916, SPA p = 0.871 — correctly refusing to crown a winner. The driver now prints this ABOVE the Sharpe leaderboard, with the note that the leaderboard's top row is the best of K tries and these p-values say whether that is more than K tries would produce by chance.")]));

children.push(H2("6.14 Cross-sectional classifier: the probability problem solved, the skill problem not"));
children.push(P("run_cross_sectional_clf.py on 39 NSE names (TATAMOTORS.NS came back delisted and was dropped with a recorded reason — the survivorship audit working), 77,135 panel rows, 2018-08 to 2026-08, 5-day horizon, combined split (27 training names before 2024-04-18, 12 entirely unseen names after it):"));
children.push(table([4200, 5160], [
  ["Measure", "Result"],
  ["Panel", "77,135 rows x 39 tickers -> 74,749 labelled"],
  ["Class balance", "short 0.30 / nothing 0.42 / buy 0.28"],
  ["Train / calib / val rows", "27,046 / 9,045 / 6,887"],
  ["Calibration ECE", "0.0647 -> 0.0026 (calib block); 0.0139 on held-out val"],
  ["Accuracy vs majority", "0.4302 vs 0.4311"],
  ["Macro F1", "0.203"],
  ["Long-short spread", "+0.00008"],
  ["Rank IC (t)", "+0.0111 (t = 0.92)"],
]));
children.push(P([B("The win: honest probabilities. "), T("The project's derived P(up) — read second-hand off a regression interval — measured ECE ~ 0.31, meaning a forecast saying '60% likely' was off by about 31 percentage points. A model asked DIRECTLY for a probability and then isotonically calibrated scores ECE 0.0139 on unseen names in unseen dates — roughly a 22x improvement. That is a genuine, separable win: the probabilities are now honest EVEN THOUGH the signal is absent. Those are two different problems and this fixes exactly one of them.")]));
children.push(P([B("The null: no cross-sectional skill at 40 names. "), T("Rank IC +0.0111 at t = 0.92 — right sign, comfortably inside noise, and almost identical to the earlier signal probe's t ~ 1. Accuracy (0.4302) is BELOW the majority-class baseline (0.4311); macro F1 is 0.203. Exactly the predicted outcome: real cross-sectional ICs are 0.02-0.05 and need HUNDREDS of names to detect. 39 is not hundreds, so this is a POWER result, not evidence against the approach.")]));
children.push(P([B("That prediction has since been tested and confirmed - see Section 3.39. "), T("On survivorship-free bhavcopy data at 400 names (100 unseen validation names, 464 dates) the same experiment gives rank IC +0.0396 at Fama-MacBeth t = 2.24, replicating across 20 of 20 seed-runs and two disjoint periods at a stable effect size of 0.033-0.037. The null above was a power result exactly as claimed. But attribution shows THE MODEL IS NOT THE FINDING - THE FACTOR IS: log_return_5 alone scores IC -0.0524 at t = -4.34, beating the model by 1.32x on IC and nearly 2x on t. The signal is SHORT-TERM REVERSAL, a long-documented effect, rediscovered rather than learned. Read that section's four caveats before acting on this sentence - in particular, the long-short spread is NOT usable and the classifier's discrete calls remain near-worthless; the ordering is what carries the result.")]));
children.push(P([B("The detail worth pausing on: the model abstains. "), T("Of 6,887 validation predictions it called 'do nothing' 6,857 times — 99.6%. Only 11 longs and 19 shorts. Given an explicit neutral class and a calibrated objective, the classifier independently concluded it had no view, on names it had never seen. That is the project's central thesis arriving from a completely different direction. Every earlier abstention was IMPOSED — a confidence bucket from a walk-forward test, a data-quality gate, a novelty check. This one is EMERGENT: nothing told the model to abstain, and the 3-class framing simply let 'no view' be a first-class answer rather than a threshold applied after the fact. It is the sixth documented negative result, and the first one a model volunteered about itself.")]));
children.push(P("One caveat on the reliability table: the [0.0, 0.1) bin holds 17 of 6,887 rows and shows a -0.29 gap. With that few points the bin is noise; the populated bin carrying the mass, [0.2, 0.3) with n = 6,227, shows a gap of -0.007."));

// 6. Shared modules
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(H1("7. Shared Modules Reference"));
children.push(table([2400, 6960], [
  ["Module", "Purpose"],
  ["model_utils.py", "All cross-model shared logic: preprocessing, feature engineering, Wilder RSI, NSE exchange-calendar future-date generation (holiday/session-aware, 7 hourly bars/session), BIC GARCH selection, Monte Carlo simulation, Keras training utilities, and the direct multi-horizon NN engine (forecast_nn_direct) with conformal intervals."],
  ["direct_forecast.py", "Direct multi-horizon engine and embargoed split-conformal calibration for the tree/ML models (make_horizon_targets, training_frame, compute_origin_row, conformal_halfwidth)."],
  ["market_context.py", "Fetches market/volatility indices and derives causal cross-sectional context features (add_market_context) and the mkt_index column for excess-return reframing (add_market_index). Both off by default after A/B testing."],
  ["HAR_RV_model.py", "HAR realized-volatility model: forecasts the variance cone, converts log to level with a data-estimated offset (har_level_offset — the Jensen correction it replaced over-stated volatility ~1.9x), conformalizes per horizon, and (default) applies adaptive conformal (ACI) so the cone responds to recent regime shifts. Also supports an optional India-VIX forward tilt (iv_adjust=) and an optional asymmetric cone (asymmetric=, separate lower/upper edges from signed residuals + realized semivariance), and exposes the recent downside share. Flat random-walk point forecast."],
  ["vol_lstm_model.py", "Vol-LSTM — the book's Chapter 5 deep volatility model, as the deep counterpart to HAR-RV. Direct multi-horizon log-variance forecast over five causal channels (log-RV, HAR weekly/monthly averages, signed return for the leverage effect, downside share), with a data-estimated level debias, reusing HAR-RV's conformal + ACI cone machinery. Flat random-walk point path. Also exposes cumulative_squared_error and the robust qlike_loss for model comparison."],
  ["CNN_LSTM_model.py", "CNN-LSTM — the book's Chapter 7 'LSTM over a CNN'. Causal Conv1D pattern extraction, batch norm, one max-pool, then stacked LSTM, running on the shared forecast_nn_direct engine so it inherits direct multi-horizon targets and per-horizon conformal intervals."],
  ["prediction_log.py", "Forward prediction log — book Ch. 3 'Going live'. Append-only JSONL written at serve time (with the gate verdicts in force), annotated with realised prices as horizons mature. Powers live calibration-drift alerting (binomial-CI gated), live gate validation, and the paper portfolio. Ships ON; writing is best-effort and never breaks a forecast."],
  ["cross_sectional_panel.py", "Pooled multi-ticker panel — book Ch. 6. Fetches a universe, reuses the existing per-ticker features, adds within-date cross-sectional ranks, builds the 3-class market-neutral label, and splits by asset, time, or both. Built against survivorship, cross-sectional look-ahead, and forward-column leakage."],
  ["cross_sectional_model.py", "3-class (buy / do nothing / short) classifier with isotonic probability calibration — the direct fix for the derived-P(up) ECE ~ 0.31 problem. Reports ECE before and after, plus rank IC, long-short spread and macro F1."],
  ["tuning.py", "Hyperparameter search — book Ch. 3. Grid / random / TPE-Bayesian samplers with a MANDATORY nested wrapper (nested_search: search on a training prefix, score once on an untouched tail) and a selection-bias warning attached to every result. Includes qlike_objective_har for tuning HAR-RV's memory windows. Pure numpy/pandas — no hyperopt dependency."],
  ["strategy_metrics.py", "Economic (investment-strategy) evaluation — the book's Chapter 3 metric set. evaluate_strategy turns forecasts into a cost-charged return stream and scores it against buy-and-hold: Sharpe, Sortino, information ratio, maximum drawdown, Calmar, information coefficient (Pearson and rank, with a t-stat), hit rate, profit factor, turnover, and a monthly return table. sharpe_standard_error (Lo 2002, correctly annualised) travels with every Sharpe. Pure — numpy/pandas only. Also provides the Fama-MacBeth cross-sectional IC (ic_by_date, newey_west_se, fama_macbeth_ic), which replaces the pooled correlation t-test for panel data."],
  ["var_models.py", "Value-at-Risk estimation AND validation — the book's Chapter 9. Five estimators (variance-covariance, historical simulation, Cornish-Fisher, filtered historical simulation, block-bootstrap generative with an optional GAN arm), each documented with the drawback it answers, plus the rolling out-of-sample harness (backtest_var), the calibration battery (kupiec_pof_test, christoffersen_independence_test, christoffersen_conditional_coverage) and compare_var_methods, plus Expected-Shortfall validation (acerbi_szekely_z2, backtest_es, compare_es_methods) because reporting an ES without checking it would repeat the very gap this module closes for VaR. Pure — no SciPy (closed-form chi-squared tails for 1 and 2 df)."],
  ["autoencoder_regime.py", "Denoising autoencoder — the book's Chapter 4 — repurposed as a regime-novelty / distribution-shift detector for the serving gate rather than as a feature transform. build_autoencoder covers the vanilla / denoising / sparse variants; regime_novelty scores the latest window against a held-out reference error distribution and returns familiar / unusual / unprecedented. Leak-free (fit, then held-out reference, then score), scale-free, and never fatal (lazy TensorFlow, neutral report on failure)."],
  ["backtest.py", "Model-agnostic walk-forward evaluation, the baseline ladder (naive/drift/AR(1)), the Diebold-Mariano significance test, the shared skill-to-label rule (confidence_bucket, used by both the UI gate and the calibration harness), skill metrics (RMSE, MAE, SMAPE, MASE, directional accuracy, coverage), and — new — the cost-charged economic evaluation of the same forecasts as a strategy block, with per-origin signals and an overlapping-origins caveat flag."],
  ["tests/validation/calibration.py", "Validation-only library (not used by the app): CRPS (empirical vs log-normal), PIT calibration, reliability/ECE of P(up) & P(move), coverage quality, nested gate validation, and the cone A/Bs (compare_static_vs_aci, compare_iv_adjust, compare_asymmetric)."],
  ["tests/validation/multiple_testing.py", "Validation-only library: data-snooping-robust model selection — White's Reality Check + Hansen's SPA over a stationary bootstrap with automatic block length (Politis-White) and a Newey-West HAC studentizer (whites_reality_check, hansens_spa, collect_loss_panel, auto_block_length, summarize)."],
  ["data_quality.py", "Input data-quality gate: scores a fetched series for fitness (history, staleness, duplicates, bad OHLC, zero-volume, gaps, abnormal jumps, currency status), returning reason codes and a serving mode (normal/warn/risk_cone_only/abstain) that the UI consumes (assess_data_quality, gate_action, DQReport). Pure — no Streamlit."],
  ["iv_data.py", "Forward-looking volatility tilt for the HAR-RV cone from India VIX (^INDIAVIX): the implied/realized ratio scaled by the stock's market R^2 (forward_vol_factor). Leak-free (as-of-last-bar), cached, no-op on missing data. Opt-in (iv_adjust=), off by default after an A/B showed no measurable coverage gain on calm data."],
  ["risk_metrics.py", "Pure (no-Streamlit) risk math for the panel: empirical P(up)/P(move)/VaR plus the downside reads — expected shortfall (CVaR), up/down realized semideviation, and vol skew (empirical_risk); log-normal fallback when no empirical sample exists (risk_from_interval). Unit-tested directly."],
  ["range_volatility.py", "Range-based realized variance from the HIGH/LOW ALREADY FETCHED (Sharma & Mehta Ch. 18 uses Parkinson's 0.361*ln(H/L)^2). Measured 1.6-2.5x more precise than r_t^2 on real NSE bars against a textbook ~5x. Every per-bar estimator is a within-bar ratio and so immune to corporate-action adjustment. Wired into HAR-RV via rv_estimator=; the A/B is a documented null (Section 3.41) and the default stays squared."],
  ["bhavcopy.py", "POINT-IN-TIME NSE prices from the daily bhavcopy - membership is whatever actually traded, so delisted companies are present for exactly the span they existed. Fixes a 26.8% survivorship gap that yfinance cannot (23 of 30 vanished names return no data there). Handles both the legacy and UDiFF formats via fallback, and reconstructs adj_close from splits, bonuses, dividends and rights: validated against yfinance at return correlation 1.00000 for 24/24 names. adjust_prices(as_of=...) gives a genuinely point-in-time series, closing the back-adjustment look-ahead of Section 3.18. No new dependency."],
  ["fracdiff.py", "Fractional differencing (Lopez de Prado, via Kaabar Ch. 9) - stationarity that PRESERVES MEMORY, plus the project's first ADF/KPSS stationarity testing. On RELIANCE the minimum stationary order is d = 0.50 (correlation with the price level 0.88) against the d = 1 the pipeline uses (0.004). Adds no parameters and no new dependency; the forecasting A/B is a documented null (Section 3.37)."],
  ["feature_drift.py", "LEADING drift indicator on the model's inputs, complementing prediction_log's lagging coverage drift. The verdict comes from a PERMUTATION null, not the folklore PSI bands - PSI is biased upward on small samples (identical distributions score 0.30 at n=50, which the folklore calls significant drift). Corrects for multiple testing. Closed-form Kolmogorov-Smirnov, no SciPy."],
  ["explain.py", "EXACT TreeSHAP attribution via LightGBM/XGBoost natively - no shap or lime dependency. Verifies the additivity identity rather than assuming it, and returns None for unsupported models rather than degrading to an approximation. The concentration measure produced Section 3.36's finding: attribution is nearly uniform in both real models."],
  ["kalman_model.py", "Damped local linear trend on log prices - the suite's only STATE-SPACE model, re-estimating its state every bar rather than freezing parameters after a fit. Produces a NATIVE interval from the state covariance (no calibration set), reported alongside the conformal one. Fitted by concentrated (profile) maximum likelihood on a grid; pure NumPy, no SciPy. Reports honestly when it degenerates to a random walk - 70% of origins on real data (Section 3.35)."],
  ["epistemic.py", "Monte-Carlo dropout MODEL uncertainty (Klaas Ch. 4) - the axis the conformal cone cannot express, since it takes the fitted model as given. Ships OFF: the cross-model comparison FAILED its falsifiable check (Section 3.34), because the spread tracks network topology rather than data scarcity. Reported separately from the 95% band, never folded in."],
  ["fundamentals.py", "Point-in-time fundamental features for the pooled panel. Stamps every feature by PUBLICATION date (period end + SEBI reporting lag), derives ratios from raw line items, and REFUSES to join a non-point-in-time frame - Ticker.info holds today's values, so joining it to a historical row is undetectable look-ahead. coverage_report measures feasibility; on yfinance it is 16% of the panel, so the experiment is blocked (Section 3.33)."],
  ["architectures.py", "Declarative network architectures (JSON-overridable via architectures.json or STOCKAPP_ARCH_FILE) AND the realised-architecture record read back off the compiled Keras model. Closes a hole in the reproducibility manifest, which pinned the seed but not the layer stack. Spec-driven: DL, CNN-LSTM, Vol-LSTM; introspection-only: N-BEATS, TCN, Transformer - reported on every record via spec_driven."],
  ["config.py", "Single source of truth for the six USE_* feature flags and the serve-time gate tunables (GATE_SPLITS / GATE_MIN_TRAIN / GATE_MAX_ROWS). Imports nothing from this project. Each entry carries the measured evidence for its default; the console banner is generated from the registry rather than hand-listed; every flag takes a STOCKAPP_* environment override, and an active override is reported in the banner. python config.py dumps the lot."],
  ["console.py", "Terminal mirror of the UI decision layer (no Streamlit import): startup_banner, run_header, run_summary, note, strip_markdown. Prints the seed / device / active USE_* flags at startup, frames each Submit, and renders the end-of-run verdict — data-quality mode, per-model bucket + Basis, consensus, honesty banner. Renders, never recomputes, so console and browser cannot drift. ASCII-only and encoding-safe for legacy Windows code pages; STOCKAPP_QUIET=1 silences it."],
  ["gating.py", "Pure serving-gate logic (no Streamlit): withhold the directional call on No edge, force No edge on degraded/event/cache-fallback data or an off-manifold market regime, compute conviction (move / half-band), and build the per-row Basis reason code (gated_direction, conviction, apply_data_quality_gate, apply_novelty_gate, confidence_reason). The trust layer, unit-tested directly."],
  ["reproducibility.py", "Pin every RNG (random/NumPy/TF/torch) per run and build an auditable manifest — seed, package versions, params, timestamps (set_all_seeds, run_manifest). Makes experiments reproducible, not markets predictable."],
  ["safe_fetch.py", "Resilient fetch wrapper: retries + exponential backoff, empty/partial detection, last-known-good disk cache fallback, and a source status tag (live/partial/cached_fallback) the data-quality gate consumes (fetch_with_fallback)."],
  ["tests/validation/cross_sectional.py", "Validation-only library: cross-sectional ranking probe — rank-IC and long-short quintile spread over a universe (research artifact, not used in the app)."],
  ["meta_ensemble.py", "Cross-family median meta-ensemble (run_meta_ensemble_prediction)."],
  ["model_utils.py (GPU)", "configure_compute / gpu_available / compute_device_label — detect a GPU, enable TF memory growth, and report the active device; deep models & Chronos auto-use it, trees stay on CPU."],
  ["tests/validation/run_*.py", "Manual evaluation/research drivers (CLI, network, slow — not used by the app): single-ticker leaderboard (run_full_backtest), multi-ticker variance-aware ranking (run_multi_backtest), cross-sectional signal probe (run_cross_sectional), calibration & gate validation (run_calibration), SPA / Reality Check (run_spa), stress-period ACI evaluation (run_stress_test), the economic Sharpe-Sortino-drawdown leaderboard (run_strategy_eval), VaR method comparison with Kupiec/Christoffersen tests (run_var_backtest), and the HAR-RV vs Vol-LSTM vs GARCH volatility comparison (run_vol_comparison)."],
]));

// 7. Getting started
children.push(H1("8. Getting Started"));
children.push(P([B("Prerequisites: "), T("Python 3.10+, optionally GPU TensorFlow.")]));
children.push(P([B("Install: "), Code("pip install -r requirements.txt")]));
children.push(P([B("Run the app: "), Code("streamlit run UI.py")]));
children.push(P("In the app: select a company (NSE/BSE search), choose interval (daily/hourly), set the horizon, pick which models to run, and Submit. Browse the confidence-graded comparison table, the Risk & Probability panel, and per-model charts (history + 95% band + naive baseline)."));
children.push(P([B("Tests & audits: "), T("all test/validation scripts live in the "), Code("tests/"), T(" folder. Run the twelve regression suites together with "), Code("pytest tests/"), T(" (138 tests, or run any one as a plain script, e.g. "), Code("python tests/test_gates.py"), T("): intraday parity, data quality, IV factor, downside/semivariance (including the HAR-RV level-bias regression), reproducibility, serving gates, resilient fetch, strategy metrics, the backtest strategy wiring, VaR estimators and their calibration tests, the regime-novelty gate, and a slower contract suite for the new deep models (test_new_models_smoke.py — needs TensorFlow, ~2-4 minutes on CPU, and self-skips the TF-dependent cases if it is unavailable). "), Code("python tests/audit_price_adjustment.py"), T(" runs the one-shot adjusted-vs-raw-close look-ahead audit on a few NSE names.")]));

// 8. Caveats
children.push(H1("9. Caveats and Limitations"));
children.push(bullet("Not financial advice — educational/research use only."));
children.push(bullet("Markets are near-efficient; at short horizons the random walk is hard to beat. The value here is calibrated uncertainty, combining models, and honest evaluation — not magic accuracy."));
children.push(bullet("Backtest scope is limited (a few tickers, a handful of origins); rankings should be confirmed on more tickers."));
children.push(bullet("Neural nets are stochastic and high-variance; consider averaging multiple seeds for production."));
children.push(bullet("Prophet and the raw neural nets can misbehave on some tickers; the meta-ensemble and conformal intervals exist partly to contain that risk."));
children.push(bullet("Hybrid (ARIMA+LSTM) is the one base model still using recursive forecasting without conformal intervals — a candidate for the same treatment as the others."));
children.push(bullet("Market context uses an India-default proxy (NIFTY 50 / India VIX). For a non-Indian ticker these are only an approximate market proxy; mapping a ticker to its true home index (e.g. S&P 500 / VIX for US names) is a known refinement."));
children.push(bullet("Conformal cones track regime shifts only partially. HAR-RV's cone now applies Adaptive Conformal Inference (ACI) over its own recent calibration residuals (on by default), so the live multiplier widens after a run of misses and tightens after easy covers. Two honest limits remain: on a calm window it can slightly over-tighten an already-well-calibrated name (Section 6.4), and a fully online loop that persists alpha across successive live requests (true cross-session monitoring) is still future work. The tree/NN models' static conformal intervals are unchanged; only HAR-RV is adaptive so far."));
children.push(bullet("HAR-RV makes no point-forecast claim by design, so it always reads No edge in the confidence column; its value is the calibrated risk cone."));
children.push(bullet("The fat-tailed risk read needs HAR-RV in the run: the empirical P(up)/P(move)/VaR come from HAR-RV's conformal residual sample; if HAR-RV is deselected the risk panel falls back to a log-normal approximation of each model's interval (and says so in the caption). Extending other models to expose an empirical sample is a clean future step."));
children.push(bullet("Calibration figures (run_calibration.py) in this document are single-ticker, small-sample illustrations — they demonstrate the harness and the direction of the result, not a firm verdict; a trustworthy claim needs many origins across several tickers. Gate validation is offline (a nested backtest), not wired into the live app."));
children.push(bullet("The SPA/Reality-Check verdict (run_spa.py) is small-sample and subset-by-default: one loss per origin (T ~ 40), the fast 9-model subset unless --full, single ticker. The conservative Reality Check drives the headline; SPA can be mildly liberal at small T. The current 'no edge' verdict is robust to this (both p ~ 0.9), but a positive finding would need more origins/tickers before being trusted."));
children.push(bullet("Intraday features are on but not yet A/B-validated: the hourly NSE-session features are leak-free and train/serve-consistent, and intraday seasonality is more defensible than daily alpha, but they have not been confirmed to improve hourly forecasts by a controlled A/B (the main backtests are daily). They ship on (USE_INTRADAY_FEATURES=True) and apply only to the tree/ML family; a dedicated hourly backtest with the flag on/off is the right way to confirm their value."));
children.push(bullet("Hourly history is provider-capped: yfinance serves only a limited intraday lookback (often ~1-2 years, varying by ticker/version), so hourly models train on far less data than daily. The app surfaces the actual span and warns when it is short."));
children.push(bullet("Currency conversion is a dormant safety net (Section 3.17): the universe is NSE/BSE-only, so every selectable stock is INR-native and the conversion never runs in normal use (audit tag 'none'). When it does fire (a foreign ticker via the search fallback, not selectable from the dropdown) it converts per-date at historical FX with audited degraded fallbacks surfaced in the UI. Because Indian hourly prices need no FX, intraday-FX granularity is moot for this product. Fixed along the way: a DataFrame.drop(columns=..., axis=1) call threw before the conversion step, so a foreign-currency stock - if ever reached - was returned unconverted but labelled in rupees; conversion now runs and is tagged."));
children.push(bullet("Data-quality thresholds are heuristic (Section 3.18): the gate in data_quality.py uses documented, deliberately-lenient cut-offs (history floors, staleness windows, zero-volume/bad-OHLC fractions, gap days) tuned to catch genuinely broken inputs without nagging on normal market data. They are sensible defaults, not calibrated against a labelled set of good/bad feeds; tune the module constants for a stricter or looser policy. The gate runs at request time on the fetched series."));
children.push(bullet("The price-adjustment look-ahead is documented, not eliminated (Section 3.19): training on yfinance's back-adjusted close embeds future corporate-action sizes into a backtest's past bars, but the audit shows this is immaterial for this return-based, scale-invariant pipeline (live serving has zero leak; only ~0.4-1.6% of bars differ, and they cancel in DM/SPA/MASE). A strict point-in-time re-adjustment per origin would close the residual but buy nothing measurable, so it is left as a documented, reproducible finding."));
children.push(bullet("Forward-looking IV is market-level, opt-in, and unproven on this data (Section 3.20): single-name NSE option IV is not freely/reliably reachable (NSE's API is bot-protected), so the India-VIX tilt injects only the systematic (NIFTY-linked) slice of forward vol, not stock-specific implied vol. It is leak-free and directionally sensible (widens when VIX spikes) but an A/B showed no measurable coverage gain on the available calm window, so it ships off (USE_IV_ADJUST = False). A genuine single-name IV feed (a paid vendor, or an authenticated browser session) would be needed to test the stronger version."));
children.push(bullet("Downside reads are always on; the asymmetric cone and HAR-RS are opt-in/future (Section 3.21): expected-shortfall / semideviation / vol-skew are pure reporting of HAR-RV's empirical distribution and need a fat-tailed model (HAR-RV) in the run. The asymmetric cone is principled but A/B-mixed on calm data (per-side calibration is noisier when residuals are near-symmetric), so it ships off (USE_ASYMMETRIC_CONE = False). A full HAR-RS (semivariance-in-the-regression) forecast is deliberately not built: it needs recursive component forecasting, and the IV/asymmetric A/Bs both indicate changes to the central variance forecast barely move the empirically-conformalized cone — so it stays documented future work."));
children.push(bullet("GPU is used only where it helps: deep models and Chronos auto-use a GPU when present; gradient-boosted trees stay on CPU intentionally (GPU tree training is slower on these small windows)."));
children.push(bullet("Prophet vs pandas 3.0 compatibility: Prophet 1.2.2's regressor_column_matrix builds its component frame with a duplicate-labelled index, which pandas 3.0's stricter crosstab rejects ('cannot reindex on an axis with duplicate labels'), breaking every Prophet fit. fb_prophet_model.py applies a small idempotent monkey-patch (add_group_component -> clean RangeIndex) so Prophet works on pandas 2.x and 3.x. requirements.txt now pins pandas 3.0.3 / numpy 2.4.6 to match the installed, tested environment (the two move together — pandas 3.0 requires numpy 2.x); the patch is retained so the code still runs on pandas 2.x if you downgrade."));
children.push(bullet("Economic results are single-ticker and tiny-sample (Section 6.8): eight non-overlapping origins on one name cannot rank models, and the annualised Sharpe standard error at that count is roughly 2.5 — so nothing in that table clears significance, which is itself the finding. The economic block is deliberately NOT surfaced in the live UI: the serve-time gate runs only three origins, where a Sharpe would be pure noise, and showing a noisy Sharpe next to a calibrated confidence bucket would undercut the honesty the gate exists to provide. Use run_strategy_eval.py, which runs enough non-overlapping origins for the number to mean something."));
children.push(bullet("VaR independence tests are overwhelmingly powerful at scale (Section 6.9): with ~7,400 evaluations spanning several crises, Christoffersen's independence test rejects for essentially any real equity series, because volatility clustering is real. On large samples compare the relative LR statistics across methods rather than reading the pass/fail label. Cornish-Fisher ships as a documented cautionary reference point, not a recommendation — it under-reserves at alpha = 5% on leptokurtic data (Section 3.25)."));
children.push(bullet("The GAN arm of var_models is available but unproven (Section 3.25): prefer_gan=True trains a compact 1-D GAN and falls back silently to the block bootstrap on any failure, but a GAN fitted to ~1000 daily returns is least trustworthy exactly in the tail VaR cares about. The block bootstrap is the default for that reason. Anyone enabling the GAN should check it with backtest_var before relying on it."));
children.push(bullet("Vol-LSTM and CNN-LSTM are new and lightly measured: Vol-LSTM has been run against HAR-RV / GARCH / EWMA on one ticker (Section 6.10) and does not beat them; CNN-LSTM has not yet been through a real-data backtest at all. Both are neural nets and therefore high-variance run to run — the N-BEATS lesson applies. Their current tests are contract tests (right columns, ordered bounds, unbiased variance level, causal convolutions), not skill claims."));
children.push(bullet("The regime-novelty gate is unexercised on a real regime break (Section 3.26): on the calm 2021-26 window it should almost never fire, which is the design, so its value cannot be demonstrated there. The honest test is a stress-window evaluation around March 2020, verifying it flags the crash and stays quiet on calm windows. A detector that fires often in calm data is mis-tuned, not sensitive. It also needs TensorFlow and enough history to fit; every failure path returns 'unknown', which is a no-op for the gate."));
children.push(bullet("The HAR-RV level fix changes reported volatility, not coverage (Section 6.10): the log-to-level transform was corrected from the Gaussian Jensen form to a data-estimated offset. Re-running the cone diagnostics at identical settings gave unchanged coverage and marginally narrower width, so the cone A/Bs published here remain valid — but HAR-RV's printed per-step volatility and its conformal k(h) values are now materially different from any figure captured before the fix (k(h) now averages ~2.4 rather than ~1.1). Historical logs and screenshots predating it should be read with that in mind."));
children.push(bullet("The older DOCUMENTATION.md is stale and superseded: it predates the HAR-RV, gating, calibration, data-quality and SPA work and has not been maintained. This document and README.md are the current references."));
children.push(bullet("The app trains on demand (no model registry): each Submit fetches data and trains/serves, with per-parameter caching within a session but no scheduled retraining, drift monitoring, or persisted model store — deferred production-grade additions."));
children.push(bullet("The resilient-fetch cache is best-effort, and full prediction logging is still deferred (Section 3.22): safe_fetch keeps a local last-known-good copy under .data_cache/ (pickle) and serves it cone-only when a live fetch fails; it is not a versioned store and is safe to delete. A persistent prediction log with realized-outcome tracking and calibration-drift monitoring remain Tier C — worth building the moment this stops being a single-user train-on-demand app and starts persisting predictions for real users over time (calibration-drift monitoring first, since a cone calibrated at training time silently decays as the regime moves)."));

// ---- build ------------------------------------------------------------
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: BLUE, font: "Arial" },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: "2E5496", font: "Arial" },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 23, bold: true, color: "333333", font: "Arial" },
        paragraph: { spacing: { before: 140, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•",
        alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 260 } } } }] },
      { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.",
        alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 260 } } } }] },
    ],
  },
  sections: [{
    properties: { page: {
      size: { width: 12240, height: 15840 },
      margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
    } },
    footers: { default: new Footer({ children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "Stock Price Forecasting App — Technical Documentation   |   Page ", size: 18, color: "888888" }),
        new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "888888" })] })] }) },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("Stock_Prediction_Documentation.docx", buf);
  console.log("Wrote Stock_Prediction_Documentation.docx (" + buf.length + " bytes)");
});
