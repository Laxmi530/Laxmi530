"""
Cross-sectional 3-class classifier with calibrated probabilities.

Motivated by *Hands-On Deep Learning for Finance* (Troiano et al.), Chapter 6,
"Trading Rule Identification by CNN": trading framed as **classification**
(buy / do nothing / short) across a pooled universe with an asset-stratified
split. The panel lives in :mod:`cross_sectional_panel`; this module is the model.

Two gaps this closes
--------------------
**1. There was no classifier at all.** Every model in this repository regresses a
price or a variance, and the P(up) shown in the risk panel is derived *second
hand* from a regression interval. The calibration harness measured that derived
probability at **ECE ≈ 0.31 — badly overconfident** (README "Empirical
findings"). A model that is asked directly for a probability, and then
**calibrated**, is the standard fix, and an explicit "do nothing" class matches a
product whose central feature is abstention.

**2. Pooling attacks the binding constraint.** Every "no edge" verdict here was
measured on ~1000 rows of a single ticker. Forty names is ~40,000 rows and, more
importantly, introduces a *relative* question ("which of these will outperform?")
that has a much better-documented empirical basis than the absolute one ("what
will this stock do?").

Why a gradient-boosted tree and not the book's CNN
--------------------------------------------------
The book renders indicator windows as 2-D images and applies a CNN, on the
argument that traders read charts as pictures. That is a reasonable motivation
and a poor fit here:

* The features are already a **tabular cross-section**, not a spatial grid.
  Convolution's inductive bias is translation invariance over adjacent pixels;
  adjacency between `rank_mom_21` and `rank_vol_21` is an artifact of column
  order and means nothing, so the bias is not merely unhelpful but wrong.
* Gradient-boosted trees are the reigning default on tabular data and need no
  GPU, which keeps this runnable in the same environment as everything else.
* This project has already paid for the "add capacity" lesson twice (N-BEATS
  overfitting, Vol-LSTM losing to EWMA). The interesting variable here is the
  **pooling and the split**, not the architecture — so the architecture is held
  boring on purpose, and swapping it in later is a controlled experiment rather
  than a confound.

The calibration step is the part that matters most
--------------------------------------------------
A classifier's raw ``predict_proba`` is not a probability — it is a score that
happens to lie in [0, 1]. Gradient boosting in particular is systematically
overconfident. So the model is fit on a *proper training* block and its
probabilities are then mapped through an **isotonic regression** fitted on a
separate calibration block. Isotonic rather than Platt scaling because it is
non-parametric: it can correct an arbitrary monotone distortion, where Platt
assumes a sigmoid and cannot fix a miscalibration shaped differently.

Reliability (ECE) is reported before *and* after, so the calibration's effect is
measured rather than assumed — the same discipline applied to every other claim
in this project.
"""

import numpy as np
import pandas as pd

CLASSES = (-1, 0, 1)          # short / do nothing / buy
CLASS_NAMES = {-1: "short", 0: "do nothing", 1: "buy"}
_EPS = 1e-12


# ==========================================
# 1. Model
# ==========================================
def build_classifier(n_estimators=400, learning_rate=0.05, num_leaves=31,
                     min_child_samples=100, seed=42, class_weight=None):
    """
    LightGBM multiclass classifier for the 3-class label.

    ``min_child_samples`` is raised well above the single-ticker default (20 ->
    100) because a pooled panel has *many* correlated rows per date: forty names
    on the same day share the market move, so a leaf holding 20 samples may hold
    only one or two genuinely independent observations. Requiring bigger leaves
    is the cheapest guard against fitting a single day's cross-section.

    ``class_weight`` defaults to None (unweighted), which is the configuration
    every published result in this project was measured under. Pass
    ``'balanced'`` to reweight inversely to class frequency. The label is
    deliberately imbalanced — the neutral class is the largest by construction,
    since the deadband is what makes "no view" a first-class answer — so an
    unweighted objective has a standing incentive to drift toward predicting
    neutral. Whether the near-total abstention observed on real data is that
    artefact or a genuine finding is exactly what
    ``tests/validation/run_class_weight_ab.py`` measures; the parameter exists
    so the question is answerable rather than arguable.
    """
    import lightgbm as lgb
    return lgb.LGBMClassifier(
        objective="multiclass", num_class=3,
        n_estimators=n_estimators, learning_rate=learning_rate,
        num_leaves=num_leaves, min_child_samples=min_child_samples,
        subsample=0.8, subsample_freq=1, colsample_bytree=0.8,
        reg_alpha=0.1, reg_lambda=1.0,
        class_weight=class_weight,
        # Reproducibility. LightGBM's multi-threaded histogram construction is
        # NOT bit-reproducible by default: with n_jobs=-1 the same seed gave
        # visibly different results run to run (abstention 0.9461 vs 0.9552 on
        # an identical fit), because float addition order varies with thread
        # scheduling. That silently undermines every A/B run against this model
        # - a difference between arms cannot be read when the same arm does not
        # reproduce itself. deterministic=True plus a fixed bin-construction
        # mode and a single thread fixes it, at some cost in fit time, which is
        # the right trade for a research model that must be re-runnable.
        deterministic=True, force_col_wise=True, n_jobs=1,
        random_state=seed, verbose=-1)


def _split_train_calib(train_df, calib_frac=0.25):
    """
    Temporal split of the training block into proper-train and calibration.

    Temporal rather than random: a random split would put the *same date's*
    cross-section on both sides, and since names on one day share the market
    move, the calibration set would not be independent of the fit.
    """
    dates = np.sort(train_df["datetime"].unique())
    if len(dates) < 10:
        return train_df, train_df.iloc[0:0]
    cut = pd.Timestamp(dates[int(len(dates) * (1 - calib_frac))])
    return (train_df[train_df["datetime"] < cut],
            train_df[train_df["datetime"] >= cut])


def fit_calibrated(train_df, feature_cols, calib_frac=0.25, seed=42,
                   verbose=True, **model_kwargs):
    """
    Fit the classifier, then calibrate its probabilities on a held-out block.

    Pipeline: proper-train fit -> predict on the calibration block -> fit one
    isotonic regression **per class** mapping raw score to observed frequency ->
    renormalise so the three calibrated probabilities sum to 1.

    Per-class one-vs-rest isotonic is the standard multiclass extension; the
    renormalisation is required because three independently-calibrated monotone
    maps have no reason to sum to one.

    Returns
    -------
    dict
        {'model', 'calibrators', 'feature_cols', 'classes', 'n_train',
        'n_calib', 'ece_raw', 'ece_calibrated'} — the two ECE figures make the
        calibration's effect measurable rather than assumed.
    """
    proper, calib = _split_train_calib(train_df, calib_frac)
    # Pass DataFrames (not .values) on both fit and predict so LightGBM keeps its
    # feature names and sklearn does not warn about a name/array mismatch — and
    # so a column-order bug would surface as an error rather than silently
    # scoring the wrong feature.
    X = proper[list(feature_cols)]
    y = proper["label_idx"].values.astype(int)

    model = build_classifier(seed=seed, **model_kwargs)
    if verbose:
        print(f"  fitting on {len(proper):,} rows x {len(feature_cols)} features "
              f"({proper['ticker'].nunique()} tickers)")
    model.fit(X, y)

    calibrators, ece_raw, ece_cal = None, float("nan"), float("nan")
    if len(calib) >= 200:
        P = model.predict_proba(calib[list(feature_cols)])
        yc = calib["label_idx"].values.astype(int)
        ece_raw = float(np.mean([expected_calibration_error(P[:, k], yc == k)
                                 for k in range(P.shape[1])]))
        calibrators = _fit_isotonic(P, yc)
        Pc = _apply_isotonic(calibrators, P)
        ece_cal = float(np.mean([expected_calibration_error(Pc[:, k], yc == k)
                                 for k in range(Pc.shape[1])]))
        if verbose:
            print(f"  calibrated on {len(calib):,} rows: "
                  f"mean ECE {ece_raw:.4f} -> {ece_cal:.4f}")
    elif verbose:
        print("  (calibration block too small — shipping raw probabilities)")

    return {"model": model, "calibrators": calibrators,
            "feature_cols": list(feature_cols), "classes": list(CLASSES),
            "n_train": int(len(proper)), "n_calib": int(len(calib)),
            "ece_raw": ece_raw, "ece_calibrated": ece_cal}


def _fit_isotonic(P, y):
    """One isotonic regressor per class (one-vs-rest)."""
    from sklearn.isotonic import IsotonicRegression
    out = []
    for k in range(P.shape[1]):
        ir = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        ir.fit(P[:, k], (y == k).astype(float))
        out.append(ir)
    return out


def _apply_isotonic(calibrators, P):
    """Apply the per-class maps and renormalise to a valid distribution."""
    if not calibrators:
        return P
    Q = np.column_stack([c.predict(P[:, k]) for k, c in enumerate(calibrators)])
    Q = np.clip(Q, _EPS, 1.0)
    return Q / Q.sum(axis=1, keepdims=True)


def predict_proba(bundle, df):
    """Calibrated class probabilities, columns ordered as :data:`CLASSES`."""
    P = bundle["model"].predict_proba(df[bundle["feature_cols"]])
    return _apply_isotonic(bundle.get("calibrators"), P)


# ==========================================
# 2. Reliability
# ==========================================
def expected_calibration_error(prob, actual, bins=10):
    """
    Expected Calibration Error: mean |predicted − observed| across probability bins.

    The metric that made this module necessary. The project's derived P(up) scored
    **ECE ≈ 0.31**, meaning a forecast saying "60% likely" was wrong by roughly
    31 percentage points on average — a number that looks like a probability but
    does not behave like one. ECE near 0.02-0.05 is respectable; below 0.01 on a
    small sample usually means too few points per bin rather than excellence.
    """
    p = np.asarray(prob, dtype=float)
    a = np.asarray(actual, dtype=float)
    n = min(len(p), len(a))
    p, a = p[:n], a[:n]
    ok = np.isfinite(p) & np.isfinite(a)
    p, a = p[ok], a[ok]
    if len(p) == 0:
        return float("nan")
    edges = np.linspace(0.0, 1.0, bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, bins - 1)
    total = 0.0
    for b in range(bins):
        m = idx == b
        if m.sum() == 0:
            continue
        total += (m.sum() / len(p)) * abs(p[m].mean() - a[m].mean())
    return float(total)


def reliability_table(prob, actual, bins=10):
    """Per-bin predicted vs observed frequency — the plot behind the ECE number."""
    p = np.asarray(prob, dtype=float)
    a = np.asarray(actual, dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, bins - 1)
    rows = []
    for b in range(bins):
        m = idx == b
        if m.sum() == 0:
            continue
        rows.append({"bin": f"[{edges[b]:.1f},{edges[b + 1]:.1f})",
                     "n": int(m.sum()),
                     "mean_pred": round(float(p[m].mean()), 4),
                     "observed": round(float(a[m].mean()), 4),
                     "gap": round(float(p[m].mean() - a[m].mean()), 4)})
    return pd.DataFrame(rows)


# ==========================================
# 3. Evaluation
# ==========================================
def evaluate(bundle, val_df, verbose=True, horizon=None):
    """
    Score the classifier on the held-out (unseen-name, unseen-date) block.

    Reports, in ascending order of how impressed you should be by a good number:

    * **accuracy** — nearly meaningless on its own here, because the neutral
      class is the largest; a model predicting "do nothing" always would score
      well. Reported only next to the majority-class baseline that exposes that.
    * **macro F1** — treats the three classes equally, so always-neutral scores
      badly. The honest headline for classification quality.
    * **ECE** — is the probability a probability?
    * **long-short spread** — the economic read: mean forward excess return of
      names the model calls "buy" minus those it calls "short". This is what a
      cross-sectional signal is *for*, and the only number here that survives
      contact with a portfolio.
    * **rank IC** — Spearman correlation between P(buy) − P(short) and the
      realised forward excess return, the standard factor-research statistic,
      with a t-stat because a small IC on a small sample is indistinguishable
      from zero.

    Returns
    -------
    dict
        Metrics plus 'reliability' (DataFrame) and 'confusion' (DataFrame).
    """
    from sklearn.metrics import f1_score

    if val_df.empty:
        return {"n": 0}
    P = predict_proba(bundle, val_df)
    y = val_df["label_idx"].values.astype(int)
    pred = P.argmax(axis=1)

    majority = int(np.bincount(y, minlength=3).argmax())
    score = P[:, 2] - P[:, 0]                      # P(buy) - P(short)
    fwd = val_df["fwd_excess"].values.astype(float)

    # Long-short spread on the model's own calls.
    longs, shorts = fwd[pred == 2], fwd[pred == 0]
    spread = (float(longs.mean() - shorts.mean())
              if len(longs) and len(shorts) else float("nan"))

    import strategy_metrics as sm
    ric = sm.rank_information_coefficient(score, fwd)
    # The POOLED t-stat, kept only for continuity with earlier reported figures.
    # It treats every row as an independent observation, which on a panel is
    # false: names on the same date share the market move, so this overstates
    # significance by roughly sqrt(names per date). Never quote it alone.
    ric_t_pooled = sm.ic_t_stat(ric, len(fwd))

    # The Fama-MacBeth form, and the figure that should be quoted: IC computed
    # within each date's cross-section, then t-tested across dates, with a
    # Newey-West correction because a horizon-h forward return sampled daily
    # makes consecutive dates' ICs overlap by h-1 days.
    # DataFrame.attrs does not survive boolean indexing reliably, so the caller
    # may pass the horizon explicitly; attrs is only a fallback. Getting this
    # wrong understates the Newey-West lag, not the result's direction.
    if horizon is None:
        horizon = val_df.attrs.get("horizon", 0)
    horizon = int(horizon or 0)
    ic_series = sm.ic_by_date(val_df["datetime"].values, score, fwd)
    fm = sm.fama_macbeth_ic(ic_series, lags=max(horizon - 1, 0))

    ece = float(np.mean([expected_calibration_error(P[:, k], y == k)
                         for k in range(3)]))

    conf = pd.crosstab(pd.Series([CLASS_NAMES[CLASSES[i]] for i in y],
                                 name="actual"),
                       pd.Series([CLASS_NAMES[CLASSES[i]] for i in pred],
                                 name="predicted"))

    # Prediction mix. The abstention rate is the number that separates "the
    # model concluded it had no view" from "an unweighted objective drifted to
    # the majority class" — two very different claims that look identical in an
    # accuracy column. Reported next to the neutral class's own base rate so the
    # comparison is against the right null.
    n_neutral = int((pred == 1).sum())
    res = {
        "n": int(len(val_df)),
        "n_tickers": int(val_df["ticker"].nunique()),
        "abstain_rate": round(float(n_neutral / max(len(pred), 1)), 4),
        "neutral_base_rate": round(float((y == 1).mean()), 4),
        "n_neutral": n_neutral,
        "accuracy": round(float((pred == y).mean()), 4),
        "majority_baseline": round(float((y == majority).mean()), 4),
        "macro_f1": round(float(f1_score(y, pred, average="macro")), 4),
        "ece": round(ece, 4),
        "long_short_spread": (round(spread, 6) if np.isfinite(spread)
                              else float("nan")),
        "n_long": int((pred == 2).sum()), "n_short": int((pred == 0).sum()),
        "rank_ic": round(ric, 4) if np.isfinite(ric) else float("nan"),
        "rank_ic_t_pooled": (round(ric_t_pooled, 2)
                             if np.isfinite(ric_t_pooled) else float("nan")),
        # Headline: date-level mean IC and its Newey-West t-stat.
        "rank_ic_fm": (round(fm["mean_ic"], 4)
                       if np.isfinite(fm["mean_ic"]) else float("nan")),
        "rank_ic_t": (round(fm["t_stat"], 2)
                      if np.isfinite(fm["t_stat"]) else float("nan")),
        "ic_n_dates": fm["n_dates"],
        "ic_hit_rate": (round(fm["hit_rate"], 4)
                        if np.isfinite(fm["hit_rate"]) else float("nan")),
        "reliability": reliability_table(P[:, 2], y == 2),
        "confusion": conf,
    }
    if verbose:
        print(f"  val: {res['n']:,} rows / {res['n_tickers']} unseen tickers | "
              f"acc {res['accuracy']:.3f} (majority {res['majority_baseline']:.3f}) "
              f"| macroF1 {res['macro_f1']:.3f} | ECE {res['ece']:.4f} | "
              f"L-S {res['long_short_spread']:+.5f} | "
              f"rankIC {res['rank_ic_fm']:+.4f} "
              f"(FM t={res['rank_ic_t']} over {res['ic_n_dates']} dates; "
              f"pooled t={res['rank_ic_t_pooled']})")
    return res


def format_report(bundle, res):
    """Render the fit + evaluation as an honest text block."""
    lines = [
        "=== Cross-sectional 3-class classifier ===",
        f"  Train rows / calib rows : {bundle['n_train']:,} / {bundle['n_calib']:,}",
        f"  Features                : {len(bundle['feature_cols'])}",
        f"  Calibration ECE         : {bundle['ece_raw']:.4f} -> "
        f"{bundle['ece_calibrated']:.4f}",
        f"  Val rows / unseen names : {res.get('n', 0):,} / {res.get('n_tickers', 0)}",
        f"  Accuracy vs majority    : {res.get('accuracy')} vs "
        f"{res.get('majority_baseline')}",
        f"  Macro F1                : {res.get('macro_f1')}",
        f"  Val ECE                 : {res.get('ece')}",
        f"  Long-short spread       : {res.get('long_short_spread')} "
        f"({res.get('n_long')} long / {res.get('n_short')} short)",
        f"  Rank IC (pooled)        : {res.get('rank_ic')} "
        f"(naive t={res.get('rank_ic_t_pooled')} — overstated, see below)",
        f"  Rank IC (Fama-MacBeth)  : {res.get('rank_ic_fm')} "
        f"(t={res.get('rank_ic_t')} over {res.get('ic_n_dates')} dates, "
        f"hit rate {res.get('ic_hit_rate')})",
        f"  Abstention rate         : {res.get('abstain_rate')} "
        f"({res.get('n_neutral')} of {res.get('n', 0):,} called neutral; "
        f"base rate {res.get('neutral_base_rate')})",
    ]
    ric_t = res.get("rank_ic_t", float("nan"))
    if np.isfinite(ric_t) and abs(ric_t) > 2:
        lines.append("  Verdict                 : rank IC is >2 SE from zero — "
                     "worth pursuing, but confirm on a larger universe and a "
                     "different period before believing it.")
    else:
        lines.append("  Verdict                 : rank IC is within noise. "
                     "Consistent with every other skill result in this project; "
                     "pooling 40 names is not the hundreds the cross-sectional "
                     "literature needs.")
    return "\n".join(lines)
