# `tools/` — research scaffolding

Small command-line utilities for *working on* this project. Each one exists
because it was written into a scratchpad, thrown away, and written again.

**These are not part of the product.** Nothing the app imports may import from
here, and the research drivers in `tests/validation/` deliberately keep their
own explicit setup so a reader can follow the order of operations. If something
here becomes load-bearing, it belongs in a real module with tests.

| Tool | Answers |
|---|---|
| [`book.py`](book.py) | What does this PDF say? |
| [`check.py`](check.py) | Do the repo and its two documents still agree? |
| [`panel.py`](panel.py) | Give me the NSE panel, fast, and tell me what is odd about it. |
| [`splice.py`](splice.py) | Edit a file at a marker without a shell mangling it. |

---

## `book.py` — read a PDF without poppler

The editor's PDF reader shells out to `pdftoppm`, which is not installed here,
so `Read` on a PDF fails outright. PyMuPDF is installed and extracts text
directly.

```bash
python tools/book.py --list                       # the 27 books available
python tools/book.py tsang --toc                  # find and print the contents
python tools/book.py tsang --pages 93-101
python tools/book.py kaabar --search "fractional"
python tools/book.py hilpisch --outline           # embedded bookmarks
```

The name is any unambiguous case-insensitive fragment of the filename.
Ambiguous fragments list the candidates rather than guessing.

`--toc` matters more than it looks: printed page numbers disagree with PDF page
numbers by however long the front matter is, so "the contents are on page 9" is
usually wrong by two to six pages. It searches for the heading *and* for the
number-column shape that contents pages have, which handles the common case
where extraction puts the chapter title and its page number on separate lines.

`Books/` is gitignored — copyrighted, ~349 MB — so the tool ships and the books
do not. It says so clearly when the folder is absent.

---

## `check.py` — the things tests do not catch

Every check here is a mistake actually made in this project and then re-checked
by hand on every subsequent edit.

```bash
python tools/check.py                  # ~2 seconds
python tools/check.py --tests          # + collect the suite (slow, imports TF)
python tools/check.py --only anchors,pins
```

| Check | Catches |
|---|---|
| `syntax` | any `.py` that stopped parsing |
| `anchors` | `](#...)` links to headings that do not exist — three at once while writing §44, and one that had been broken far longer |
| `ordinals` | two sections both claiming "the *n*th negative result", a tally maintained by hand across 2,500 lines |
| `docx` | a README section with no counterpart in `generate_docx.js`, which is a separate script and therefore diverges silently |
| `pins` | `requirements.txt` drifting from the installed environment — the drift that took eight libraries down and made `fracdiff.adf_pvalue` return `NaN` without raising |
| `tests` | a stated test count left stale after tests were added *(opt-in)* |

Exits non-zero on any problem, so it can gate a commit. None of these breaks a
test, which is exactly why they survive.

The README↔docx chapter offset (README §43 = docx 3.44) is recorded as
`DOCX_OFFSET` rather than rediscovered.

---

## `panel.py` — the NSE panel in one call

Every driver and every ad-hoc check opens with the same twelve lines: fetch
corporate actions over a lookback, `build_panel`, group by symbol, take
`adj_close`, sort, drop non-positive prices, drop short series. Each step fails
quietly when wrong — forget the action lookback and a 1:10 split becomes a −90%
return.

```bash
python tools/panel.py                              # summary + audit
python tools/panel.py --start 2022-01-01 --n 400
python tools/panel.py --refresh                    # ignore the cache
```

```python
import sys; sys.path.insert(0, "tools")
import panel
series = panel.by_symbol()        # {symbol: adjusted close Series}
df, rep = panel.load()            # the raw long panel
```

Defaults are the window and universe size the published sections use
(2022-01-01 → 2024-06-30, n=400), so an ad-hoc check measures the same thing
the drivers did. Builds take 30–60s; results are cached to `.panel_cache/`
keyed on the parameters, which is the difference between checking something
properly and checking it against yfinance because that was faster.

### What the audit found

Building this surfaced a real issue. The liquidity screen selects on
**turnover**, and NSE ETFs trade in the same series as equities, so the
universe contains four of them:

| Symbol | Annualised vol | Zero-return days | |
|---|---|---|---|
| `LIQUIDBEES` | **0.0%** | **53.9%** | money-market fund, near-constant price |
| `GOLDBEES` | 11.6% | 1.8% | gold tracker |
| `NIFTYBEES` | 12.8% | 0.2% | **the index itself** |
| `BANKBEES` | 16.2% | 0.2% | bank index tracker |

An index tracker inside a *stock-selection* cross-section is a category error —
it is the thing being selected against, not a candidate. `LIQUIDBEES` is a cash
equivalent that cannot be ranked against a stock at all.

They are **reported, never silently dropped**: at ~4 names in 400 the effect on
any published figure is negligible, and quietly changing the universe would
make README §38–§44 irreproducible. The right fix, if it is ever worth making,
is an instrument-type filter in `bhavcopy.liquidity_screen` with the affected
sections re-run and their numbers updated — not a quiet exclusion here.

### Precision, on the research path

`data_quality.py` raises `COARSE_PRICE_GRID` (README §46) for names whose tick
is a material share of a daily move — but only on the **app** path. The
research path (`bhavcopy.build_panel` → the drivers) never calls that gate, and
the coarse names are in the panel: `MERCATOR`, `UNITECH` and `RCOM` all sit in
the 400-name universe with roughly half their daily returns exact duplicates of
another day's.

So the audit reports the same dimension here:

```
  COARSE PRICE GRID -- returns are materially quantised:
    LIQUIDBEES     Rs  1,000.0  tick 0.01  grid is  139% of a daily move
    IDEA           Rs      9.2  tick 0.04  grid is   13% of a daily move
    SUZLON         Rs      9.7  tick 0.05  grid is   12% of a daily move
```

Reported, left in — the same rule as the ETFs. §46 measured the reversal signal
inside every precision quintile and found it present at all of them, so
dropping these names would change the published universe without changing a
result. The tick is read from the **unadjusted** close: corporate-action
adjustment multiplies prices by a non-integer factor and destroys the grid.
---

## `splice.py` — edit a file at a marker, without a shell in the way

Inserting a documentation section or replacing a function body is the most
repeated operation in this project, and it kept being done by piping a Python
script through a bash heredoc. That failed three times in one session, and the
third failure was silent and destructive:

```
r"\bthe (" + "|".join(_ORDINALS) + ...     what was written
r"<0x08>the (" + ...                       what landed in the file
```

The heredoc turned the two characters `\b` into a single **backspace control
character**. The regex then matched nothing, so `check_ordinals` reported
`[ ok ]` on every run — *including runs where the document was wrong* — and it
was only caught by deliberately planting a duplicate and noticing the check
still passed.

The bug class is "text containing escapes passes through a shell". This removes
the shell: the payload is read from a **file**, byte for byte.

```bash
# insert before / after the line containing a marker
python tools/splice.py README.md --before "## Reading the screen" --payload new.md

# replace from START's line up to (not including) END's — Python slice semantics
python tools/splice.py README.md --between "#### The null" "### 45." --payload x.md

# delete that span
python tools/splice.py tools/check.py --between "def old(" "def next(" --delete

# look first
python tools/splice.py README.md --before "## Caveats" --payload x.md --dry-run
```

Markers match as a **substring of a line**, which is how you actually remember
them; `--regex` switches to a pattern, `--occurrence N` picks among duplicates.

### Four guards, each earned

| Guard | Prevents |
|---|---|
| **Control characters rejected** — in the payload *and* in the result | The exact bug above. It cannot be committed now. |
| **Markers must be unique** | An ambiguous marker is an error listing every match, never a guess. Silently taking the first match is how an edit lands in the wrong section. |
| **The edit is verified after writing** | A splice that quietly changed nothing is the second-worst outcome after one that corrupted something. Both now fail loudly. |
| **Syntax checked** — `ast` for `.py`, `node --check` for `.js` | A file that stopped parsing is reported with its backup path, rather than discovered later. |

A `.splicebak` is kept beside the file unless `--no-backup` is passed.

### It tests itself, and `check.py` runs that test

`python tools/splice.py --selftest` exercises all ten behaviours on temporary
files. It is also wired in as the `tools` check, so it runs with everything
else rather than waiting to be remembered — a guard nobody tests is decoration,
which is the whole lesson of the bug that prompted this.

Verified the way the original failure should have been: sabotage the
control-character guard, and the check reports
`splice guard failed -- control_chars_rejected: a backspace character was accepted`.
