"""
Splice a block of text into a file at a marker, without a shell in the way.

Why this exists
---------------
Inserting a documentation section or replacing a function body is the single
most repeated operation in this project, and it kept being done by piping a
Python script through a bash heredoc. That failed three times in one session,
and the third failure was silent and destructive:

    r"\\bthe (" + ... ->  r"<0x08>the (" + ...

The heredoc turned the two characters ``\\b`` into one **backspace control
character**. The regex then matched nothing, ``check_ordinals`` reported
"clean" on every run including runs where the document was wrong, and the only
reason it was caught was a deliberate test against a planted duplicate.

The bug class is "text with escapes passes through a shell". This tool removes
the shell: the payload is read from a **file**, byte for byte.

Four guards, each earned
------------------------
1. **Control characters are rejected**, in the payload and in the result. This
   is the specific failure above, and it is now impossible to commit.
2. **Markers must be unique.** An ambiguous marker is an error listing every
   match, never a guess at which one was meant.
3. **The edit is verified after writing.** A splice that silently changed
   nothing is the second-worst outcome after a splice that corrupted
   something; both now fail loudly.
4. **Syntax is checked** for ``.py`` (ast) and ``.js`` (``node --check``) when
   the tool is available. A file that stopped parsing is reported, and the
   backup path is printed so the edit can be undone.

Usage
-----
::

    # insert a block before / after the line containing a marker
    python tools/splice.py README.md --before "## Reading the screen" \\
        --payload section45.md

    # replace from the START marker's line up to (not including) END's
    python tools/splice.py README.md --between "#### The null" "### 45." \\
        --payload rewrite.md

    # delete that same span
    python tools/splice.py tools/check.py --between "def old(" "def next(" \\
        --delete

    # look before you leap
    python tools/splice.py README.md --before "## Caveats" --payload x.md --dry-run

    python tools/splice.py --selftest

Markers are matched as a **substring of a line**, which is how you actually
remember them; ``--regex`` switches to a pattern if you need one.
"""

import argparse
import ast
import os
import re
import shutil
import subprocess
import sys

#: The only control characters allowed to appear in source or documentation.
CONTROL_OK = "\n\t"

BACKUP_SUFFIX = ".splicebak"


class SpliceError(Exception):
    """Anything that should stop the edit rather than guess at intent."""


# ==========================================
# guards
# ==========================================
def find_control_chars(text):
    """``[(index, codepoint), ...]`` for control characters that must not appear."""
    return [(i, ord(c)) for i, c in enumerate(text)
            if ord(c) < 32 and c not in CONTROL_OK]


def _describe_control(text, hits, limit=5):
    out = []
    for i, code in hits[:limit]:
        line = text.count("\n", 0, i) + 1
        ctx = text[max(0, i - 30):i + 30].replace("\n", "\\n")
        out.append(f"    line {line}: 0x{code:02x}  near: {ctx!r}")
    if len(hits) > limit:
        out.append(f"    ... and {len(hits) - limit} more")
    return "\n".join(out)


def check_control(text, what):
    hits = find_control_chars(text)
    if hits:
        raise SpliceError(
            f"{what} contains {len(hits)} control character(s) that must not be "
            f"in a source file:\n{_describe_control(text, hits)}\n"
            f"  This is the heredoc-escaping bug this tool exists to prevent.")


def find_marker(lines, marker, use_regex=False, occurrence=None):
    """
    The single line index matching ``marker``.

    Ambiguity is an error, not a coin flip: a marker matching three lines and
    silently taking the first is how an edit lands in the wrong section.
    """
    if use_regex:
        pat = re.compile(marker)
        hits = [i for i, l in enumerate(lines) if pat.search(l)]
    else:
        hits = [i for i, l in enumerate(lines) if marker in l]
    if not hits:
        raise SpliceError(f"marker not found: {marker!r}")
    if len(hits) > 1:
        if occurrence is None:
            shown = "\n".join(f"    line {i + 1}: {lines[i].strip()[:90]}"
                              for i in hits[:8])
            raise SpliceError(
                f"marker {marker!r} matches {len(hits)} lines; pass "
                f"--occurrence N (1-based) to choose:\n{shown}")
        if not 1 <= occurrence <= len(hits):
            raise SpliceError(
                f"--occurrence {occurrence} out of range (1..{len(hits)})")
        return hits[occurrence - 1]
    return hits[0]


def syntax_ok(path):
    """``(ok, message)``; ``(True, 'skipped')`` for formats with no checker."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".py":
        try:
            with open(path, encoding="utf-8") as fh:
                ast.parse(fh.read())
            return True, "python parses"
        except SyntaxError as e:
            return False, f"python syntax error at line {e.lineno}: {e.msg}"
    if ext == ".js":
        if shutil.which("node") is None:
            return True, "skipped (node not on PATH)"
        r = subprocess.run(["node", "--check", path],
                           capture_output=True, text=True)
        if r.returncode == 0:
            return True, "javascript parses"
        return False, f"javascript syntax error: {r.stderr.strip().splitlines()[0]}"
    return True, "skipped (no checker for this format)"


# ==========================================
# the edit
# ==========================================
def splice(path, payload="", before=None, after=None, between=None,
           delete=False, use_regex=False, occurrence=None, backup=True,
           dry_run=False):
    """
    Perform one splice. Returns a dict describing what changed.

    Exactly one of ``before``, ``after`` or ``between`` selects the location.
    ``between=(START, END)`` replaces ``lines[start : end]`` -- the START line
    is replaced, the END line is kept, matching Python slice intuition.
    """
    with open(path, encoding="utf-8") as fh:
        original = fh.read()
    check_control(original, f"{path} (before editing)")
    if payload:
        check_control(payload, "payload")

    lines = original.split("\n")
    body = payload.rstrip("\n").split("\n") if payload else []

    if sum(x is not None for x in (before, after, between)) != 1:
        raise SpliceError("choose exactly one of --before, --after, --between")

    if before is not None:
        i = find_marker(lines, before, use_regex, occurrence)
        lo, hi, what = i, i, f"insert before line {i + 1}"
        new_lines = lines[:i] + body + lines[i:]
    elif after is not None:
        i = find_marker(lines, after, use_regex, occurrence)
        lo, hi, what = i + 1, i + 1, f"insert after line {i + 1}"
        new_lines = lines[:i + 1] + body + lines[i + 1:]
    else:
        start, end = between
        i = find_marker(lines, start, use_regex, occurrence)
        j = find_marker(lines, end, use_regex, occurrence)
        if j <= i:
            raise SpliceError(
                f"end marker (line {j + 1}) is not after start (line {i + 1})")
        lo, hi = i, j
        what = (f"{'delete' if delete else 'replace'} lines {i + 1}-{j} "
                f"({j - i} line(s))")
        new_lines = lines[:i] + body + lines[j:]

    result = "\n".join(new_lines)
    check_control(result, f"{path} (after editing)")

    info = {"path": path, "action": what, "removed": hi - lo,
            "added": len(body), "dry_run": dry_run}

    if dry_run:
        lo_ctx, hi_ctx = max(0, lo - 3), min(len(new_lines), lo + len(body) + 3)
        info["preview"] = "\n".join(
            f"    {k + 1:5d}| {new_lines[k][:100]}"
            for k in range(lo_ctx, hi_ctx))
        return info

    if backup:
        shutil.copy2(path, path + BACKUP_SUFFIX)
        info["backup"] = path + BACKUP_SUFFIX
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(result)

    # Post-condition. A splice that quietly changed nothing is a bug, and the
    # only way to know is to look at the file afterwards rather than trust the
    # arithmetic above.
    with open(path, encoding="utf-8") as fh:
        written = fh.read()
    if written == original and (body or delete or hi > lo):
        raise SpliceError(f"{path} is unchanged after a splice that should "
                          f"have changed it")
    for probe in [l for l in body if l.strip()][:1] + \
                 [l for l in body if l.strip()][-1:]:
        if probe not in written:
            raise SpliceError(f"payload line not found after writing: "
                              f"{probe.strip()[:80]!r}")
    ok, msg = syntax_ok(path)
    info["syntax"] = msg
    if not ok:
        raise SpliceError(f"{msg}\n  backup kept at {info.get('backup')}")
    return info


# ==========================================
# self-test -- run by tools/check.py
# ==========================================
def selftest():
    """Prove the guards still work. A guard nobody tests is decoration."""
    import tempfile
    failures = []

    def case(name, fn):
        try:
            fn()
        except AssertionError as e:
            failures.append(f"{name}: {e}")
        except Exception as e:                         # noqa: BLE001
            failures.append(f"{name}: unexpected {type(e).__name__}: {e}")

    with tempfile.TemporaryDirectory() as d:
        def write(text, name="f.py"):
            p = os.path.join(d, name)
            with open(p, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(text)
            return p

        def read(p):
            with open(p, encoding="utf-8") as fh:
                return fh.read()

        def t_insert_before():
            p = write("a = 1\nb = 2\nc = 3\n")
            splice(p, payload="x = 0", before="b = 2", backup=False)
            assert read(p).split("\n")[:3] == ["a = 1", "x = 0", "b = 2"], read(p)

        def t_insert_after():
            p = write("a = 1\nb = 2\n")
            splice(p, payload="x = 0", after="a = 1", backup=False)
            assert read(p).split("\n")[1] == "x = 0", read(p)

        def t_between_replaces_start_keeps_end():
            p = write("head\nold1\nold2\ntail\n", "f.md")
            splice(p, payload="new", between=("head", "tail"), backup=False)
            assert read(p) == "new\ntail\n", repr(read(p))

        def t_delete():
            p = write("head\ngone1\ngone2\ntail\n", "f.md")
            splice(p, between=("gone1", "tail"), delete=True, backup=False)
            assert read(p) == "head\ntail\n", repr(read(p))

        def t_control_chars_rejected():
            p = write("a = 1\nb = 2\n")
            try:
                splice(p, payload="x = '" + chr(8) + "'", before="b = 2",
                       backup=False)
            except SpliceError as e:
                assert "control character" in str(e), e
                assert read(p) == "a = 1\nb = 2\n", "file was modified anyway"
                return
            raise AssertionError("a backspace character was accepted")

        def t_ambiguous_marker_refuses():
            p = write("x\ndup\ny\ndup\n", "f.md")
            try:
                splice(p, payload="q", before="dup", backup=False)
            except SpliceError as e:
                assert "matches 2 lines" in str(e), e
                return
            raise AssertionError("ambiguous marker was not refused")

        def t_occurrence_disambiguates():
            p = write("x\ndup\ny\ndup\n", "f.md")
            splice(p, payload="q", before="dup", occurrence=2, backup=False)
            assert read(p).split("\n") == ["x", "dup", "y", "q", "dup", ""], read(p)

        def t_missing_marker_refuses():
            p = write("a\n", "f.md")
            try:
                splice(p, payload="q", before="nope", backup=False)
            except SpliceError as e:
                assert "not found" in str(e), e
                return
            raise AssertionError("missing marker was not refused")

        def t_broken_python_is_caught_and_backed_up():
            p = write("a = 1\nb = 2\n")
            try:
                splice(p, payload="def (:", before="b = 2", backup=True)
            except SpliceError as e:
                assert "syntax error" in str(e), e
                assert os.path.exists(p + BACKUP_SUFFIX), "no backup kept"
                return
            raise AssertionError("a syntax error was not caught")

        def t_dry_run_does_not_write():
            p = write("a = 1\nb = 2\n")
            info = splice(p, payload="x = 0", before="b = 2", dry_run=True)
            assert read(p) == "a = 1\nb = 2\n", "dry run wrote to the file"
            assert "preview" in info

        for name, fn in list(locals().items()):
            if name.startswith("t_"):
                case(name[2:], fn)

    return failures


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Splice text into a file at a marker, shell-free.",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", nargs="?")
    ap.add_argument("--payload", help="file holding the text to insert")
    ap.add_argument("--before", metavar="MARKER")
    ap.add_argument("--after", metavar="MARKER")
    ap.add_argument("--between", nargs=2, metavar=("START", "END"))
    ap.add_argument("--delete", action="store_true",
                    help="with --between, remove the span")
    ap.add_argument("--regex", action="store_true",
                    help="treat markers as regular expressions")
    ap.add_argument("--occurrence", type=int,
                    help="1-based choice when a marker matches several lines")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)

    if a.selftest:
        fails = selftest()
        for f in fails:
            print(f"  FAIL {f}")
        print("splice selftest: " + ("all guards hold" if not fails
                                     else f"{len(fails)} failure(s)"))
        return 1 if fails else 0

    if not a.file:
        ap.error("a file is required (or use --selftest)")
    payload = ""
    if a.payload:
        with open(a.payload, encoding="utf-8") as fh:
            payload = fh.read()
    elif not a.delete:
        ap.error("--payload is required unless --delete is given")

    try:
        info = splice(a.file, payload=payload, before=a.before, after=a.after,
                      between=tuple(a.between) if a.between else None,
                      delete=a.delete, use_regex=a.regex,
                      occurrence=a.occurrence, backup=not a.no_backup,
                      dry_run=a.dry_run)
    except SpliceError as e:
        print(f"splice refused: {e}")
        return 1

    head = "would " if info["dry_run"] else ""
    print(f"{head}{info['action']} in {info['path']}  "
          f"(-{info['removed']} +{info['added']} lines)")
    if info.get("preview"):
        print(info["preview"])
    if info.get("syntax"):
        print(f"  {info['syntax']}")
    if info.get("backup"):
        print(f"  backup: {os.path.basename(info['backup'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
