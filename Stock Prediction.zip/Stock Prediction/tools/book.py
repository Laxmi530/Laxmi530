"""
Read a PDF from ``Books/`` without poppler.

Why this exists
---------------
The editor's built-in PDF reader shells out to ``pdftoppm`` (poppler), which is
not installed on this machine, so ``Read`` on a PDF fails outright. PyMuPDF is
installed and extracts text directly. Every book review in this project has
started by rewriting the same six-line extraction script into the scratchpad;
this is that script, kept.

It also removes the two bits of friction that actually cost time: typing the
full 80-character path to a book, and hunting for which physical pages hold the
table of contents when the printed page numbers disagree with the PDF's.

``Books/`` is gitignored (copyrighted, ~349 MB), so this tool ships and the
books do not. It degrades with a clear message when the folder is absent.

Usage
-----
::

    python tools/book.py --list
    python tools/book.py tsang --toc
    python tools/book.py tsang --pages 93-101
    python tools/book.py "lopez de prado" --search "triple barrier"
    python tools/book.py afml --outline

The name is a case-insensitive substring of the filename; an unambiguous
fragment is enough (``tsang``, ``kaabar``, ``sharma``). Ambiguous matches list
the candidates instead of guessing.
"""

import argparse
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(_HERE)
BOOKS = os.path.join(ROOT, "Books")


def _safe_stdout():
    """
    Let PDF text through a cp1252 console.

    Extracted PDF text is full of typographic characters -- U+2010 hyphen,
    curly quotes, en dashes -- and Windows' default console encoding raises
    UnicodeEncodeError on the first one, mid-page, after printing half the
    output. Replacing the offending character is right here: the point is to
    read the text, not to round-trip it.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:                              # pragma: no cover
            pass



def _open(path):
    try:
        import fitz                                    # PyMuPDF
    except ImportError:
        sys.exit("PyMuPDF is not installed:  pip install pymupdf")
    return fitz.open(path)


def find(name, books_dir=BOOKS):
    """Resolve a filename fragment to one PDF path, or exit with the options."""
    if not os.path.isdir(books_dir):
        sys.exit(f"no Books/ directory at {books_dir} (it is gitignored -- "
                 f"this is expected on a fresh clone)")
    pdfs = sorted(f for f in os.listdir(books_dir) if f.lower().endswith(".pdf"))
    if not pdfs:
        sys.exit(f"no PDFs in {books_dir}")
    if not name:
        return None, pdfs
    hits = [f for f in pdfs if name.lower() in f.lower()]
    if not hits:
        sys.exit(f"no book matching {name!r}. Try --list.")
    if len(hits) > 1:
        sys.exit("ambiguous, matches:\n  " + "\n  ".join(hits))
    return os.path.join(books_dir, hits[0]), pdfs


def parse_pages(spec, n_pages):
    """``"8-10"`` / ``"12"`` / ``"8-"`` -> a 1-indexed inclusive page list."""
    if not spec:
        return []
    out = []
    for part in str(spec).split(","):
        part = part.strip()
        if "-" in part:
            a, _, b = part.partition("-")
            lo = int(a) if a.strip() else 1
            hi = int(b) if b.strip() else n_pages
        else:
            lo = hi = int(part)
        out.extend(range(max(1, lo), min(n_pages, hi) + 1))
    return out


def find_toc(doc, scan=30):
    """
    Physical pages that look like a table of contents.

    Printed page numbers rarely match PDF page numbers (front matter is
    numbered in roman), so "the TOC is on page 9" is usually wrong by 2-6. This
    looks for the heading, then for the dotted-leader/number-column shape that
    contents pages have and body text does not.
    """
    hits = []
    for i in range(min(scan, doc.page_count)):
        text = doc[i].get_text()
        head = re.search(r"^\s*(CONTENTS|Contents|TABLE OF CONTENTS)\s*$",
                         text, re.M)
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
        # A contents page is mostly short lines carrying a page number. Two
        # shapes, because extraction is inconsistent: "Chapter title .... 24"
        # when the leaders survive, and a bare "24" on its own line when the
        # number sits in a separate text block (common, and what made the
        # first version of this miss every continuation page).
        numeric = sum(1 for ln in lines
                      if re.fullmatch(r"\d{1,4}", ln)
                      or re.search(r"(\.{2,}\s*|\s)\d{1,4}$", ln))
        if head or (len(lines) > 8 and numeric >= max(6, len(lines) // 3)):
            hits.append(i + 1)
    # Contents pages run consecutively; keep the first block.
    block = []
    for p in hits:
        if not block or p - block[-1] <= 2:
            block.append(p)
        else:
            break
    return block


def dump(doc, pages, width=70):
    for p in pages:
        print("\n" + "=" * width)
        print(f"PDF PAGE {p}  (of {doc.page_count})")
        print("=" * width)
        print(doc[p - 1].get_text())


def search(doc, term, context=90, limit=60):
    pat = re.compile(re.escape(term), re.I)
    n = 0
    for i in range(doc.page_count):
        text = doc[i].get_text()
        for m in pat.finditer(text):
            a = max(0, m.start() - context)
            snippet = " ".join(text[a:m.end() + context].split())
            print(f"  p{i + 1:<5d} ...{snippet}...")
            n += 1
            if n >= limit:
                print(f"  (stopped at {limit} matches)")
                return n
    return n


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("name", nargs="?", help="filename fragment, e.g. 'tsang'")
    ap.add_argument("--list", action="store_true", help="list available books")
    ap.add_argument("--pages", help="'8-10', '12', '8-' (1-indexed PDF pages)")
    ap.add_argument("--toc", action="store_true",
                    help="locate and print the table of contents")
    ap.add_argument("--outline", action="store_true",
                    help="print the embedded bookmark tree, if any")
    ap.add_argument("--search", help="case-insensitive text search")
    ap.add_argument("--books", default=BOOKS)
    a = ap.parse_args(argv)
    _safe_stdout()

    path, pdfs = find(None if a.list else a.name, a.books)
    if a.list or not a.name:
        print(f"{len(pdfs)} book(s) in {a.books}:")
        for f in pdfs:
            print("   ", f)
        return 0

    doc = _open(path)
    print(f"{os.path.basename(path)}  --  {doc.page_count} pages")

    if a.outline:
        toc = doc.get_toc() or []
        if not toc:
            print("\n(no embedded outline; try --toc)")
        for lvl, title, page in toc:
            print(f"{'  ' * (lvl - 1)}{title}  ...  p{page}")
    if a.toc:
        block = find_toc(doc)
        if not block:
            print("\nno contents page found in the first 30 pages; "
                  "use --pages or --outline")
        else:
            print(f"\ncontents detected on PDF page(s) {block}")
            dump(doc, block)
    if a.search:
        print(f"\nsearching for {a.search!r}:")
        if not search(doc, a.search):
            print("  no matches")
    if a.pages:
        dump(doc, parse_pages(a.pages, doc.page_count))
    if not any((a.outline, a.toc, a.search, a.pages)):
        print("\nnothing to do -- pass --toc, --outline, --pages or --search")
    return 0


if __name__ == "__main__":
    sys.exit(main())
