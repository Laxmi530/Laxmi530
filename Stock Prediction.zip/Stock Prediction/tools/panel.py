"""
Load the survivorship-free, corporate-action-adjusted NSE panel in one call.

Why this exists
---------------
Every research driver and every ad-hoc check opens with the same twelve lines:
fetch corporate actions over a lookback, call ``bhavcopy.build_panel``, group by
symbol, take ``adj_close``, sort, drop non-positive prices, drop short series.
Getting any step wrong is quiet rather than loud -- forget the action lookback
and a 1:10 split becomes a -90% return; screen liquidity inside the study window
and you have selected names on test-period information.

Rebuilding also costs 30-60 seconds each time, which is the real reason a
one-off check gets run against yfinance instead, and then the check is
measuring a different (survivorship-biased) universe than the driver it is
meant to be checking. So this caches the built panel, keyed on its parameters.

**This is research scaffolding, not library code.** Nothing the app imports may
import it; the drivers in ``tests/validation/`` deliberately keep their own
explicit ``build_panel`` calls so a reader can see the order of operations.

Usage
-----
::

    python tools/panel.py                          # summary of the default panel
    python tools/panel.py --start 2022-01-01 --n 400
    python tools/panel.py --refresh                # ignore the cache

From Python::

    import sys; sys.path.insert(0, "tools")
    import panel
    series = panel.by_symbol()                     # {symbol: adj_close Series}
    long_df, report = panel.load()                 # the raw long panel
"""

import argparse
import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(_HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import bhavcopy as bc                              # noqa: E402

#: Cached panels, keyed by parameters. Derived data -- safe to delete.
CACHE_DIR = os.path.join(ROOT, ".panel_cache")

#: The window and universe size the published sections use (README §38-§44),
#: so an ad-hoc check measures the same thing the drivers did.
START = "2022-01-01"
END = "2024-06-30"
N = 400

#: Corporate actions are fetched from before the window: a split on day 3 of
#: the study period is only adjustable if the action list reaches back past it.
ACTION_LOOKBACK_DAYS = 400

#: Shorter series cannot support a cross-sectional or event-based measurement.
MIN_BARS = 120


def _key(start, end, n):
    return f"panel_{pd.Timestamp(start):%Y%m%d}_{pd.Timestamp(end):%Y%m%d}_n{n}"


def load(start=START, end=END, n=N, refresh=False, verbose=True):
    """
    The long panel plus its build report, cached on disk.

    Returns
    -------
    (pd.DataFrame, dict)
        The panel as ``bhavcopy.build_panel`` returns it, and that call's
        report (which carries ``universe``). On a cache hit the report is
        reconstructed from the panel, so ``universe`` is still populated.
    """
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        raise SystemExit(
            "No bhavcopy cache. Build it first:\n"
            "    python tests/validation/fetch_bhav_cache.py")

    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, _key(start, end, n) + ".csv.gz")
    if os.path.exists(path) and not refresh:
        if verbose:
            print(f"panel: cache hit  {os.path.relpath(path, ROOT)}")
        df = pd.read_csv(path, parse_dates=["datetime"])
        return df, {"universe": sorted(df["symbol"].unique()),
                    "n_tickers": df["symbol"].nunique(), "cached": True}

    if verbose:
        print(f"panel: building {start}..{end} n={n} (30-60s) ...")
    actions = bc.corporate_actions(
        pd.Timestamp(start) - pd.Timedelta(days=ACTION_LOOKBACK_DAYS), end)
    df, report = bc.build_panel(start, end, n=n, actions=actions, verbose=False)
    df.to_csv(path, index=False)
    report["cached"] = False
    if verbose:
        print(f"panel: cached to {os.path.relpath(path, ROOT)}")
    return df, report


def by_symbol(start=START, end=END, n=N, min_bars=MIN_BARS, refresh=False,
              column="adj_close", verbose=True):
    """
    ``{symbol: Series}`` of adjusted closes, indexed by date, cleaned.

    Non-positive and non-finite prices are dropped (a halted session arrives
    as 0.0 and makes every ratio infinite), each series is sorted, and names
    with fewer than ``min_bars`` observations are excluded.
    """
    df, _ = load(start, end, n, refresh=refresh, verbose=verbose)
    out = {}
    for sym, g in df.groupby("symbol"):
        s = g.set_index("datetime")[column].astype(float).sort_index()
        v = s.to_numpy()
        s = s[np.isfinite(v) & (v > 0)]
        if len(s) >= min_bars:
            out[sym] = s
    if verbose:
        print(f"panel: {len(out)} names with >= {min_bars} bars")
    return out


#: Names whose price barely moves are not tradeable cross-sectional members:
#: a stock that did not move has no meaningful rank against one that did.
_FLAT_VOL = 0.05          # annualised
#: Tick size as a share of one daily standard deviation. Above this the return
#: series is materially quantised -- README section 46. The app path raises
#: COARSE_PRICE_GRID for it; the research path never calls that gate, so the
#: same dimension is reported here.
_COARSE_GRID = 0.10
_FLAT_ZERO_RET = 0.20     # share of days with an exactly zero return


def interior_gaps(raw, min_frac=0.02):
    """
    Sessions a name is missing **while still listed**, and why that happens.

    A name absent before its first bar or after its last is a listing or a
    delisting, which is what a survivorship-free panel is supposed to contain.
    A name absent *between* its own first and last bar is something else.

    The cause is an identifier one (Khraisha Ch. 3, README section 47): NSE's
    real instrument key is (SYMBOL, SERIES), and ``bhavcopy.read_legacy`` keeps
    SERIES == 'EQ'. The exchange moves a company to 'BE' under the Additional
    Surveillance Measure and back again, so a live, trading company drops out
    of the panel for the length of its surveillance period. Verified on the
    raw archive for 2018-08-01: RAIN and BOMDYEING sit in 'BE' that day,
    RELIANCE in 'EQ'.

    Keeping the filter is the right call -- a trade-for-trade line cannot be
    traded like a normal one -- but the hole it leaves is non-random: the
    exchange flags names precisely when they are volatile or distressed.

    Returns
    -------
    dict
        ``{'names': [...], 'missing_name_days': int, 'total_span': int,
        'detail': {symbol: {'missing', 'frac', 'span'}}}``
    """
    if raw is None or "datetime" not in getattr(raw, "columns", []):
        return {"names": [], "missing_name_days": 0, "total_span": 0,
                "detail": {}}
    sessions = pd.Index(sorted(pd.unique(raw["datetime"])))
    pos = {d: i for i, d in enumerate(sessions)}
    detail, missing_total, span_total = {}, 0, 0
    for sym, g in raw.groupby("symbol"):
        idx = sorted(pos[d] for d in g["datetime"])
        if len(idx) < 30:
            continue
        span = idx[-1] - idx[0] + 1
        miss = span - len(idx)
        span_total += span
        missing_total += miss
        if miss > 0 and miss / span >= min_frac:
            detail[sym] = {"missing": miss, "frac": miss / span, "span": span}
    return {"names": sorted(detail, key=lambda s: -detail[s]["frac"]),
            "missing_name_days": missing_total, "total_span": span_total,
            "detail": detail}
def audit(series, raw=None):
    """
    Flag panel members that are not ordinary equities.

    Found by building this tool: a turnover screen on the bhavcopy selects on
    *liquidity*, and NSE's ETFs trade in the same series as equities, so the
    universe quietly contains them. ``LIQUIDBEES`` is a money-market fund
    pegged near a constant price -- 53.9% of its days have an exactly zero
    return and its annualised volatility is 0.0%. ``NIFTYBEES`` and
    ``BANKBEES`` are index trackers, which in a *stock-selection*
    cross-section is a category error: the index is the thing being selected
    against, not a candidate.

    Reported, never silently dropped. At ~4 names in 400 the effect on any
    published figure is negligible, and quietly changing the universe would
    make the numbers in README §38-§44 irreproducible.

    Returns
    -------
    dict
        ``{'flat': [...], 'etf_like': [...], 'coarse': [...],
        'detail': {symbol: {...}}}``. ``coarse`` needs ``raw`` -- the long
        panel -- because a tick can only be read off an UNADJUSTED close;
        corporate-action adjustment multiplies by a non-integer factor and
        destroys the grid.
    """
    ticks = {}
    if raw is not None and "close" in getattr(raw, "columns", []):
        for sym, g in raw.groupby("symbol"):
            px = g.sort_values("datetime")["close"].to_numpy(dtype=float)
            step = np.abs(np.diff(px))
            step = step[step > 1e-9]
            if len(step) > 20 and np.median(px) > 0:
                ticks[sym] = (float(np.min(step)), float(np.median(px)))

    flat, etf_like, coarse, detail = [], [], [], {}
    for sym, s in series.items():
        r = np.diff(np.log(s.to_numpy(dtype=float)))
        if len(r) < 2:
            continue
        vol = float(np.std(r, ddof=1) * np.sqrt(252))
        zero = float(np.mean(r == 0.0))
        detail[sym] = {"vol": vol, "zero_ret": zero, "bars": len(s)}
        if sym in ticks:
            tick, level = ticks[sym]
            sd = float(np.std(r, ddof=1))
            share = (tick / level) / sd if sd > 0 else np.inf
            detail[sym].update(tick=tick, price=level, grid_share=share)
            if share > _COARSE_GRID:
                coarse.append(sym)
        if vol < _FLAT_VOL or zero > _FLAT_ZERO_RET:
            flat.append(sym)
        # Nippon India's ETF family is the bulk of NSE ETF turnover. This is a
        # name heuristic and therefore incomplete -- it is a prompt to look,
        # not a filter to trust.
        if sym.endswith("BEES") or sym.startswith("SETF"):
            etf_like.append(sym)
    return {"flat": sorted(flat), "etf_like": sorted(etf_like),
            "coarse": sorted(coarse), "detail": detail}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Load/inspect the NSE panel.")
    ap.add_argument("--start", default=START)
    ap.add_argument("--end", default=END)
    ap.add_argument("--n", type=int, default=N)
    ap.add_argument("--min-bars", type=int, default=MIN_BARS)
    ap.add_argument("--refresh", action="store_true", help="rebuild, ignore cache")
    a = ap.parse_args(argv)

    raw, _ = load(a.start, a.end, a.n, refresh=a.refresh, verbose=False)
    series = by_symbol(a.start, a.end, a.n, a.min_bars, refresh=a.refresh)
    if not series:
        print("no usable names")
        return 1
    lens = np.array([len(s) for s in series.values()])
    rets = np.array([float(np.std(np.diff(np.log(s.to_numpy())), ddof=1)
                           * np.sqrt(252)) for s in series.values()])
    first = min(s.index[0] for s in series.values())
    last = max(s.index[-1] for s in series.values())
    print()
    print(f"  names          : {len(series)}")
    print(f"  span           : {first:%Y-%m-%d} .. {last:%Y-%m-%d}")
    print(f"  bars per name  : min {lens.min()}  median {int(np.median(lens))}"
          f"  max {lens.max()}")
    print(f"  annualised vol : median {np.median(rets):.1%}  "
          f"range {rets.min():.1%}..{rets.max():.1%}")
    print(f"  sample         : {', '.join(sorted(series)[:8])} ...")

    rep = audit(series, raw=raw)
    gaps = interior_gaps(raw)
    if gaps["names"]:
        pct = gaps["missing_name_days"] / max(gaps["total_span"], 1)
        print("")
        print(f"  INTERIOR GAPS -- listed but absent from the panel "
              f"({pct:.2%} of name-days):")
        for sym in gaps["names"][:8]:
            d = gaps["detail"][sym]
            print(f"    {sym:<14s}{d['missing']:>5} of {d['span']:>5} sessions"
                  f"  ({d['frac']:.0%} of its own history)")
        print(f"    {len(gaps['names'])} names lose 2%+ of their span this way.")
        print("    Cause is the SERIES filter, not a download hole: NSE moves a")
        print("    name to 'BE' under surveillance and bhavcopy keeps 'EQ' only,")
        print("    so a live company drops out and returns. Non-random -- the")
        print("    exchange flags names when they are distressed. README s47.")

    if rep["coarse"]:
        print("")
        print("  COARSE PRICE GRID -- returns are materially quantised:")
        for sym in sorted(rep["coarse"],
                          key=lambda s: -rep["detail"][s]["grid_share"]):
            d = rep["detail"][sym]
            print(f"    {sym:<14s} Rs {d['price']:>8,.1f}  tick {d['tick']:g}  "
                  f"grid is {d['grid_share']:5.0%} of a daily move")
        print("    The app path raises COARSE_PRICE_GRID for these; the")
        print("    research path has no gate, so they are reported here and")
        print("    left in -- README section 46 shows the reversal signal is")
        print("    present at every precision level, so removing them would")
        print("    change the published universe without changing a result.")

    if rep["flat"] or rep["etf_like"]:
        print("\n  NOT ORDINARY EQUITIES -- reported, not removed:")
        for sym in sorted(set(rep["flat"]) | set(rep["etf_like"])):
            d = rep["detail"][sym]
            why = []
            if sym in rep["flat"]:
                why.append("flat")
            if sym in rep["etf_like"]:
                why.append("ETF-like name")
            print(f"    {sym:<14s} vol {d['vol']:6.1%}  "
                  f"zero-return days {d['zero_ret']:5.1%}  ({', '.join(why)})")
        print("    A turnover screen selects on liquidity, and NSE ETFs trade")
        print("    in the same series as equities. An index tracker inside a")
        print("    stock-selection cross-section is a category error.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
