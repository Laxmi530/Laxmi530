import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error
import warnings

from model_utils import (
    normalize_interval, wilder_rsi, generate_future_dates, NSE_BARS_PER_SESSION,
)
from direct_forecast import (
    horizon_feature_cols, make_horizon_targets, training_frame,
    compute_origin_row, conformal_halfwidth,
)

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

_DAILY_WINDOWS = [5, 10, 20, 50]
_HOURLY_WINDOWS = [6, 12, 24, 48]
_RSI_PERIOD = 14
_BUFFER_SIZE = 80

# Intraday (hourly-only) features capturing NSE session structure. NSE sessions
# are 09:15-15:30, which yfinance returns as 7 contiguous hourly bars (hours
# 9..15), so "N bars back = same bar of an earlier session" is exact regardless
# of holidays.
#
# The default and its rationale live in config.py with every other flag; it is
# re-bound here (rather than read through the module) so the existing A/B tests
# can still monkeypatch ML_model.USE_INTRADAY_FEATURES, and so the functions
# below keep reading a plain module global. Set STOCKAPP_USE_INTRADAY_FEATURES=0
# to A/B it for a run without editing source.
from config import USE_INTRADAY_FEATURES
_NSE_OPEN_HOUR = 9


def _add_intraday_features_vec(df):
    """
    Add leak-free NSE intraday features to a datetime-indexed hourly frame.

    All features use only the current bar and the past: bar position in the
    session, first/last-bar flags, return since the session open, the overnight
    gap (today's open vs the *previous* session's close), and the return vs the
    same bar one session ago. Modifies ``df`` in place.
    """
    hour = df.index.hour
    bar = np.clip(hour - _NSE_OPEN_HOUR, 0, NSE_BARS_PER_SESSION - 1)
    df['bar_in_session'] = bar
    df['is_first_bar'] = (bar == 0).astype(int)
    df['is_last_bar'] = (bar == NSE_BARS_PER_SESSION - 1).astype(int)

    sess = df.index.normalize()
    sess_series = pd.Series(sess, index=df.index)
    # Return since the session's opening bar (0 at the open; past-only otherwise).
    session_open = df.groupby(sess)['adj_close'].transform('first')
    df['ret_since_open'] = np.log(df['adj_close'] / session_open)
    # Overnight gap: today's open vs the PREVIOUS session's close (both known at
    # the open, so it is constant across the session and never peeks ahead).
    daily_first = df.groupby(sess)['adj_close'].first()
    daily_last = df.groupby(sess)['adj_close'].last()
    gap = np.log(daily_first / daily_last.shift(1))
    df['overnight_gap'] = sess_series.map(gap).values
    # Same bar, one session ago (7 contiguous bars back).
    df['same_hour_prev_day_ret'] = np.log(
        df['adj_close'] / df['adj_close'].shift(NSE_BARS_PER_SESSION)
    )


# ==========================================
# 1. Vectorised Feature Engineering (Training)
# ==========================================
def create_features(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    """
    Build scale-invariant, return-based features plus technical indicators.

    Features include multi-horizon log returns, MA ratios, rolling
    volatility at multiple windows, RSI (Wilder smoothing), Bollinger
    Band position, normalised MACD line and histogram, ATR (normalised),
    price range ratio, price z-score (mean-reversion signal), volume
    ratio and change, and calendar variables.  Every feature can also
    be computed from a price/volume buffer in ``_features_from_buffers``,
    keeping training and prediction consistent.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with datetime, open, high, low, close,
        adj_close, volume columns.
    interval : str
        'daily' or 'hourly'; determines rolling window sizes and
        whether the 'hour' calendar feature is included.

    Returns
    -------
    pd.DataFrame
        DataFrame indexed by datetime with all engineered features and
        a 'target_log_return' column (next-step log return).
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime').sort_index()

    for col in ['open', 'high', 'low', 'close', 'adj_close', 'volume']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.dropna(subset=['adj_close'])

    df['target_log_return'] = np.log(
        df['adj_close'] / df['adj_close'].shift(1)
    ).shift(-1)

    for lag in [1, 2, 3, 5, 10]:
        df[f'log_return_{lag}'] = np.log(
            df['adj_close'] / df['adj_close'].shift(lag)
        )

    windows = _DAILY_WINDOWS if interval == 'daily' else _HOURLY_WINDOWS
    ret_1 = np.log(df['adj_close'] / df['adj_close'].shift(1))

    for w in windows:
        ma = df['adj_close'].rolling(w).mean()
        df[f'ma_ratio_{w}'] = df['adj_close'] / ma
        df[f'volatility_{w}'] = ret_1.rolling(w).std()

    df['rsi_14'] = wilder_rsi(df['adj_close'], period=_RSI_PERIOD)

    ma_bb = df['adj_close'].rolling(20).mean()
    std_bb = df['adj_close'].rolling(20).std()
    df['bb_position'] = (df['adj_close'] - ma_bb) / (
        2 * std_bb.replace(0, 1e-10)
    )

    ema_12 = df['adj_close'].ewm(span=12, adjust=False).mean()
    ema_26 = df['adj_close'].ewm(span=26, adjust=False).mean()
    macd_line = ema_12 - ema_26
    macd_signal = macd_line.ewm(span=9, adjust=False).mean()
    df['macd_norm'] = macd_line / df['adj_close']
    df['macd_hist_norm'] = (macd_line - macd_signal) / df['adj_close']

    if all(c in df.columns for c in ['high', 'low', 'close']):
        prev_close = df['close'].shift(1)
        tr = pd.concat([
            df['high'] - df['low'],
            (df['high'] - prev_close).abs(),
            (df['low'] - prev_close).abs(),
        ], axis=1).max(axis=1)
        df['atr_norm'] = tr.ewm(span=_RSI_PERIOD, adjust=False).mean() / (
            df['adj_close'].replace(0, 1e-10)
        )
        df['range_pct'] = (df['high'] - df['low']) / (
            df['adj_close'].replace(0, 1e-10)
        )
    else:
        abs_ret = ret_1.abs()
        df['atr_norm'] = abs_ret.rolling(_RSI_PERIOD).mean()
        df['range_pct'] = abs_ret.rolling(5).mean() * 2

    ma_20 = df['adj_close'].rolling(20).mean()
    std_20 = df['adj_close'].rolling(20).std()
    df['price_zscore'] = (df['adj_close'] - ma_20) / (
        std_20.replace(0, 1e-10)
    )

    df['return_accel'] = ret_1.diff()

    vol_ma = df['volume'].rolling(20).mean()
    df['volume_ratio'] = df['volume'] / vol_ma.replace(0, 1)
    df['volume_change'] = df['volume'].pct_change()

    df['month'] = df.index.month
    df['dayofweek'] = df.index.dayofweek
    if interval == 'hourly':
        df['hour'] = df.index.hour
        if USE_INTRADAY_FEATURES:
            _add_intraday_features_vec(df)

    df = df.replace([np.inf, -np.inf], np.nan).dropna()

    return df


# ==========================================
# 2. Single-row feature computation (Prediction)
# ==========================================
def _features_from_buffers(prices, volumes, dt, interval):
    """
    Compute a single feature row from raw price/volume buffers.

    Mirror of ``create_features`` but operates on numpy arrays and
    returns a dict for one timestep.  Uses Wilder's exponential
    smoothing for RSI and pandas EWM for MACD, ensuring consistency
    with the training-time feature definitions.  ATR and range_pct
    are approximated from close-to-close changes (since high/low are
    unavailable during recursive prediction).  Called inside the
    recursive prediction loop.

    Parameters
    ----------
    prices : array-like
        Historical price buffer (most recent at the end, length
        >= ``_BUFFER_SIZE``).
    volumes : array-like
        Historical volume buffer (same length as prices).
    dt : datetime-like
        Timestamp for the current prediction step (used for calendar
        features).
    interval : str
        'daily' or 'hourly'; determines window sizes and whether
        the 'hour' feature is included.

    Returns
    -------
    dict
        Feature name -> value mapping for a single observation.
    """
    features = {}
    prices = np.asarray(prices, dtype=np.float64)
    volumes = np.asarray(volumes, dtype=np.float64)

    for lag in [1, 2, 3, 5, 10]:
        if len(prices) > lag and prices[-1 - lag] > 0:
            features[f'log_return_{lag}'] = np.log(
                prices[-1] / prices[-1 - lag]
            )
        else:
            features[f'log_return_{lag}'] = 0.0

    windows = _DAILY_WINDOWS if interval == 'daily' else _HOURLY_WINDOWS
    log_rets = np.diff(np.log(np.maximum(prices, 1e-10)))

    for w in windows:
        if len(prices) >= w:
            features[f'ma_ratio_{w}'] = prices[-1] / np.mean(prices[-w:])
        else:
            features[f'ma_ratio_{w}'] = 1.0

        if len(log_rets) >= w:
            features[f'volatility_{w}'] = float(
                np.std(log_rets[-w:], ddof=1)
            )
        elif len(log_rets) > 1:
            features[f'volatility_{w}'] = float(np.std(log_rets, ddof=1))
        else:
            features[f'volatility_{w}'] = 0.0

    if len(prices) > _RSI_PERIOD:
        s = pd.Series(prices)
        delta = s.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = (-delta.where(delta < 0, 0.0))
        avg_gain = gain.ewm(
            alpha=1.0 / _RSI_PERIOD, min_periods=_RSI_PERIOD, adjust=False,
        ).mean()
        avg_loss = loss.ewm(
            alpha=1.0 / _RSI_PERIOD, min_periods=_RSI_PERIOD, adjust=False,
        ).mean()
        rs_val = avg_gain.iloc[-1] / (
            avg_loss.iloc[-1] if avg_loss.iloc[-1] > 0 else 1e-10
        )
        features['rsi_14'] = 100.0 - (100.0 / (1.0 + rs_val))
    else:
        features['rsi_14'] = 50.0

    if len(prices) >= 20:
        ma_20 = np.mean(prices[-20:])
        std_20 = float(np.std(prices[-20:], ddof=1))
        features['bb_position'] = (
            (prices[-1] - ma_20) / (2 * std_20) if std_20 > 0 else 0.0
        )
    else:
        features['bb_position'] = 0.0

    if len(prices) >= 26:
        ps = pd.Series(prices)
        ema_12 = ps.ewm(span=12, adjust=False).mean().iloc[-1]
        ema_26 = ps.ewm(span=26, adjust=False).mean().iloc[-1]
        macd_line = ema_12 - ema_26
        macd_signal = (
            ps.ewm(span=12, adjust=False).mean()
            - ps.ewm(span=26, adjust=False).mean()
        ).ewm(span=9, adjust=False).mean().iloc[-1]
        features['macd_norm'] = macd_line / prices[-1] if prices[-1] > 0 else 0.0
        features['macd_hist_norm'] = (
            (macd_line - macd_signal) / prices[-1] if prices[-1] > 0 else 0.0
        )
    else:
        features['macd_norm'] = 0.0
        features['macd_hist_norm'] = 0.0

    abs_rets = np.abs(log_rets) if len(log_rets) > 0 else np.array([0.0])
    if len(abs_rets) >= _RSI_PERIOD:
        features['atr_norm'] = float(np.mean(abs_rets[-_RSI_PERIOD:]))
    elif len(abs_rets) > 0:
        features['atr_norm'] = float(np.mean(abs_rets))
    else:
        features['atr_norm'] = 0.0

    if len(abs_rets) >= 5:
        features['range_pct'] = float(np.mean(abs_rets[-5:]) * 2)
    elif len(abs_rets) > 0:
        features['range_pct'] = float(np.mean(abs_rets) * 2)
    else:
        features['range_pct'] = 0.0

    if len(prices) >= 20:
        ma_20 = np.mean(prices[-20:])
        std_20 = float(np.std(prices[-20:], ddof=1))
        features['price_zscore'] = (
            (prices[-1] - ma_20) / std_20 if std_20 > 0 else 0.0
        )
    else:
        features['price_zscore'] = 0.0

    if len(log_rets) >= 2:
        features['return_accel'] = float(log_rets[-1] - log_rets[-2])
    else:
        features['return_accel'] = 0.0

    if len(volumes) >= 20:
        vol_ma = np.mean(volumes[-20:])
        features['volume_ratio'] = (
            volumes[-1] / vol_ma if vol_ma > 0 else 1.0
        )
    else:
        features['volume_ratio'] = 1.0

    if len(volumes) >= 2 and volumes[-2] > 0:
        features['volume_change'] = volumes[-1] / volumes[-2] - 1
    else:
        features['volume_change'] = 0.0

    features['month'] = dt.month
    features['dayofweek'] = dt.dayofweek
    if interval == 'hourly':
        features['hour'] = dt.hour
        if USE_INTRADAY_FEATURES:
            # Scalar mirror of _add_intraday_features_vec for the origin bar.
            # Contiguous 7-bar sessions => the session open is `bar` bars back and
            # the same bar one session ago is NSE_BARS_PER_SESSION bars back.
            n = len(prices)
            bar = int(min(max(dt.hour - _NSE_OPEN_HOUR, 0),
                          NSE_BARS_PER_SESSION - 1))
            features['bar_in_session'] = bar
            features['is_first_bar'] = int(bar == 0)
            features['is_last_bar'] = int(bar == NSE_BARS_PER_SESSION - 1)
            features['ret_since_open'] = (
                float(np.log(prices[-1] / prices[-1 - bar]))
                if n > bar and prices[-1 - bar] > 0 else 0.0
            )
            features['overnight_gap'] = (
                float(np.log(prices[-1 - bar] / prices[-2 - bar]))
                if n > bar + 1 and prices[-2 - bar] > 0 else 0.0
            )
            features['same_hour_prev_day_ret'] = (
                float(np.log(prices[-1] / prices[-1 - NSE_BARS_PER_SESSION]))
                if n > NSE_BARS_PER_SESSION
                and prices[-1 - NSE_BARS_PER_SESSION] > 0 else 0.0
            )

    return features


# ==========================================
# 3. Model Factory
# ==========================================
def get_model_and_params(model_type: str):
    """
    Create and return a configured gradient-boosting regressor.

    Uses Huber loss (pseudo-Huber for XGBoost, Huber for LightGBM)
    for robustness to fat-tailed return outliers, which are common
    in stock data and can dominate squared-error training.

    Parameters
    ----------
    model_type : str
        'xgboost' or 'lightgbm'.

    Returns
    -------
    tuple of (estimator, str)
        model : configured XGBRegressor or LGBMRegressor instance.
        engine : string identifier ('xgboost' or 'lightgbm').

    Raises
    ------
    ValueError
        If model_type is not 'xgboost' or 'lightgbm'.
    """
    if model_type == 'xgboost':
        model = xgb.XGBRegressor(
            objective='reg:pseudohubererror',
            n_estimators=1500,
            learning_rate=0.03,
            max_depth=5,
            subsample=0.8,
            colsample_bytree=0.8,
            reg_alpha=0.1,
            reg_lambda=1.0,
            min_child_weight=5,
            n_jobs=-1,
            random_state=42,
            early_stopping_rounds=50,
        )
        return model, 'xgboost'

    elif model_type == 'lightgbm':
        model = lgb.LGBMRegressor(
            objective='huber',
            n_estimators=1500,
            learning_rate=0.03,
            num_leaves=31,
            subsample=0.8,
            subsample_freq=1,
            colsample_bytree=0.8,
            reg_alpha=0.1,
            reg_lambda=1.0,
            min_child_samples=20,
            n_jobs=-1,
            random_state=42,
            verbose=-1,
        )
        return model, 'lightgbm'

    else:
        raise ValueError("model_type must be 'xgboost' or 'lightgbm'")


# ==========================================
# 4. Unified Training Function
# ==========================================
def train_generic_model(features_df: pd.DataFrame, target_col: str,
                        model_type: str, test_size=0.1):
    """
    Train an XGBoost or LightGBM model with temporal train/test split.

    Automatically selects feature columns (excluding raw OHLCV and the
    target), trains with early stopping on a held-out temporal
    validation set, and reports test MAE.

    Parameters
    ----------
    features_df : pd.DataFrame
        DataFrame with engineered feature columns and the target column.
    target_col : str
        Name of the target column (e.g., 'target_log_return').
    model_type : str
        'xgboost' or 'lightgbm'.
    test_size : float, optional
        Fraction of data reserved for temporal validation. Default 0.1.

    Returns
    -------
    tuple of (estimator, list of str)
        model : trained model instance.
        feature_cols : list of feature column names used during training.
    """
    raw_cols = {'open', 'high', 'low', 'close', 'adj_close', 'volume'}
    feature_cols = [
        c for c in features_df.columns
        if c != target_col and c not in raw_cols
    ]

    X = features_df[feature_cols]
    y = features_df[target_col]

    split_idx = int(len(X) * (1 - test_size))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

    print(
        f"Training {model_type.upper()}... "
        f"(Train: {len(X_train)}, Test: {len(X_test)}, "
        f"Features: {len(feature_cols)})"
    )

    model, engine = get_model_and_params(model_type)

    if engine == 'xgboost':
        model.fit(
            X_train, y_train,
            eval_set=[(X_test, y_test)],
            verbose=False,
        )
    else:
        callbacks = [
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(0),
        ]
        model.fit(
            X_train, y_train,
            eval_set=[(X_test, y_test)],
            eval_metric='rmse',
            callbacks=callbacks,
        )

    mae = mean_absolute_error(y_test, model.predict(X_test))
    print(f"{model_type.upper()} Test MAE: {mae:.6f}")

    return model, feature_cols


# ==========================================
# 5. Main Orchestrator (Direct Multi-Horizon)
# ==========================================
def run_ML_prediction(df: pd.DataFrame, interval: str, horizon: int,
                      model_type: str = 'xgboost'):
    """
    Main function to run XGBoost or LightGBM prediction.

    Uses **direct multi-horizon** forecasting: a separate model is trained for
    each step ``h`` to predict the cumulative log return ``log(P[t+h]/P[t])``,
    and every step is forecast directly from the observed features at the last
    bar. This replaces the previous recursive scheme, which compounded errors
    across the horizon (and started one bar early), and was the weakest
    performer in the walk-forward backtest.

    Orchestrates feature engineering (Wilder RSI, MACD, Bollinger Bands,
    multi-scale momentum/volatility), per-horizon model training with Huber
    loss and early stopping, and direct forecasting from the origin row.
    Distribution-free **conformal** prediction intervals are added per horizon
    via a temporal split-conformal calibration, so the forecast now carries
    calibrated 95% bounds whose width grows with horizon. Training data is
    limited to recent observations to focus on the current market regime.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with columns datetime, open, high, low, close,
        adj_close, volume.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.
    model_type : str, optional
        'xgboost' (default) or 'lightgbm'.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)

    df = df.copy()
    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.iloc[-max_obs:]

    features_df = create_features(df, interval)
    feature_cols = horizon_feature_cols(features_df)
    targets = make_horizon_targets(features_df, horizon)

    origin_X, last_price, last_date = compute_origin_row(
        df, feature_cols, interval,
    )
    future_dates = generate_future_dates(last_date, horizon, interval)

    print(f"Training {horizon} direct {model_type.upper()} horizon models...")

    rows = []
    for i, h in enumerate(range(1, horizon + 1)):
        target_name = f'target_h{h}'
        train_df = training_frame(
            features_df, feature_cols, targets[h], target_name,
        )
        model, _ = train_generic_model(train_df, target_name, model_type)
        cum_return = float(model.predict(origin_X)[0])

        # Conformal half-width (log-return space) from a temporal calibration split.
        def _fit_predict(proper_df, X_cal, _tn=target_name, _mt=model_type):
            cal_model, _ = train_generic_model(proper_df, _tn, _mt)
            return cal_model.predict(X_cal)

        half = conformal_halfwidth(
            train_df, feature_cols, target_name, _fit_predict, embargo=h,
        )
        if half is None:
            half = 1.96 * float(np.std(train_df[target_name].values))

        median = last_price * np.exp(cum_return)
        lower = last_price * np.exp(cum_return - half)
        upper = last_price * np.exp(cum_return + half)
        rows.append({
            'datetime': future_dates[i],
            'predicted_price': float(median),
            'lower_bound': float(lower),
            'upper_bound': float(upper),
            'volatility': float((upper - lower) / (2 * 1.96)),
        })

    return pd.DataFrame(rows)
