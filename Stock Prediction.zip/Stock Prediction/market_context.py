"""
Cross-sectional market / sector / volatility context features.

Short-horizon stock returns are dominated by the broad market: a single stock's
next move is mostly its **beta** times the index move plus a smaller
stock-specific (alpha) component. Every model in this project, however, sees
only the stock's own OHLCV history, so the most predictable part of the return —
the market component — is withheld from it. Both external reviews flagged this
as the single highest-impact gap.

This module fetches a market index and a volatility index and derives a small
set of **causal** context features (each known at or before time t, never
forward-looking) that are attached as columns to the raw stock DataFrame:

    mkt_ret_1        contemporaneous 1-period index log return
    mkt_ret_5        trailing 5-period cumulative index log return
    excess_ret_1     stock 1-period return minus the index return (alpha proxy)
    rel_strength_20  trailing 20-period stock-minus-market cumulative return
    beta_60          rolling 60-period beta of the stock to the index
    corr_60          rolling 60-period correlation of stock/index returns
    vix_change       contemporaneous volatility-index log change
    vix_z_60         rolling 60-period z-score of the volatility-index level

Design choices that keep this safe and non-disruptive:

* **Attached upstream, consumed downstream.** The features are added to the df
  once (in the UI fetch step and in the backtest drivers). ``create_features``
  rides extra columns straight through and ``horizon_feature_cols`` treats any
  non-raw, non-target column as a feature, so the tree / ML / ensemble families
  pick them up automatically. The walk-forward harness slices the enriched df
  row-wise, so the per-row context stays perfectly aligned with no per-split
  network calls.
* **No look-ahead.** All features are contemporaneous or trailing, and the
  rolling statistics are backward-looking, so computing them once on the full
  history and slicing later introduces no leakage (identical to how every
  existing feature is handled).
* **Never truncates history.** Missing index data (e.g. a volatility index with
  a shorter history than the stock) is filled with a neutral 0 rather than
  dropped, so adding context can never shrink the usable training set and
  regress the existing models.
* **Graceful degradation.** If the index data cannot be fetched, the original
  df is returned unchanged and every model behaves exactly as before.

Because the app is India-centric (prices are normalised to INR and NSE/BSE
tickers are prioritised), the defaults are the NIFTY 50 and India VIX. For a
non-Indian ticker these are an approximate market proxy; the symbols are
overridable via the function arguments.
"""

import numpy as np
import pandas as pd

# Default market / volatility proxies (India-centric app).
DEFAULT_MARKET_SYMBOL = "^NSEI"        # NIFTY 50
DEFAULT_VIX_SYMBOL = "^INDIAVIX"       # India VIX

# The context feature columns this module adds (consumed as model features).
MARKET_CONTEXT_COLS = [
    "mkt_ret_1", "mkt_ret_5", "excess_ret_1", "rel_strength_20",
    "beta_60", "corr_60", "vix_change", "vix_z_60",
]

_BETA_WINDOW = 60
_REL_WINDOW = 20


def add_market_index(df, interval, market_symbol=DEFAULT_MARKET_SYMBOL,
                     _market_series=None):
    """
    Attach the aligned market-index level as a single ``mkt_index`` column.

    This is the hook for **excess-return target reframing**: when the column is
    present, the direct-forecast target builders switch from the absolute
    cumulative return ``ln(P[t+h]/P[t])`` to the **excess** return
    ``ln(P[t+h]/P[t]) - ln(M[t+h]/M[t])`` — i.e. the model learns the
    stock-specific (alpha) component with the broad market move removed, which
    can be a less noisy, more learnable target.

    Reconstruction is intentionally unchanged: because the expected short-horizon
    market return is ~0 (the market is itself a random walk), the predicted
    excess return maps back to price with ``last_price * exp(prediction)`` just
    as the absolute target did. So attaching this column is the *only* switch
    needed — no model signature changes.

    The index is aligned by a backward as-of match and forward/back-filled so it
    never introduces NaNs (and thus never truncates the stock history). If the
    index can't be fetched the df is returned unchanged (excess reframing stays
    off).

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close'.
    interval : str
        '1d'/'daily' or '1h'/'hourly' (indices are fetched daily and aligned
        as-of, as in :func:`add_market_context`).
    market_symbol : str, optional
        yfinance market-index symbol. Default NIFTY 50 ('^NSEI').
    _market_series : pd.Series, optional
        Pre-supplied date-indexed close series (offline-test injection).

    Returns
    -------
    pd.DataFrame
        Copy of ``df`` with an ``mkt_index`` column, or the original df if the
        index is unavailable.
    """
    if df is None or not hasattr(df, "columns") or "adj_close" not in df.columns:
        return df

    out = df.copy()
    out["datetime"] = pd.to_datetime(out["datetime"])
    mkt = _market_series if _market_series is not None else \
        fetch_close_series(market_symbol, out["datetime"].min(),
                           out["datetime"].max())
    if mkt is None or len(mkt) < 5:
        print("[market_context] market index unavailable; "
              "excess-return reframing stays off.")
        return df

    idx_feat = pd.DataFrame({"mkt_index": mkt.sort_index()})
    aligned = _asof_align(out["datetime"], idx_feat)["mkt_index"]
    # Fill any leading/holiday gaps so the column never adds NaN rows.
    out["mkt_index"] = aligned.ffill().bfill().values
    print(f"[market_context] attached mkt_index ({market_symbol}) "
          f"for excess-return targets.")
    return out


def context_matrix(df):
    """
    Extract the market-context columns of a df as a clean numeric matrix.

    Used by the neural-network feature path (``forecast_nn_direct``) to give the
    sequence models the same market context the tree models already get. Returns
    None when the df carries no context columns, so the NN path transparently
    falls back to the price-only feature matrix (graceful degradation).

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame that may contain :data:`MARKET_CONTEXT_COLS`.

    Returns
    -------
    (np.ndarray, list of str) or (None, [])
        (matrix of shape (len(df), k), ordered column names), or (None, []) if
        no context columns are present.
    """
    cols = [c for c in MARKET_CONTEXT_COLS if c in df.columns]
    if not cols:
        return None, []
    m = df[cols].to_numpy(dtype=float)
    m = np.nan_to_num(m, nan=0.0, posinf=0.0, neginf=0.0)
    return m, cols


def fetch_close_series(symbol, start, end):
    """
    Fetch a daily adjusted-close series for an index via yfinance.

    Always fetches at daily resolution (index/volatility intraday data is
    patchy); intraday stock rows later inherit the most recent daily context
    via an as-of merge. Returns None on any failure so the caller can degrade
    gracefully.

    Parameters
    ----------
    symbol : str
        yfinance symbol (e.g. '^NSEI', '^INDIAVIX', '^GSPC', '^VIX').
    start, end : datetime-like
        Inclusive date range to fetch.

    Returns
    -------
    pd.Series or None
        Date-normalised (tz-naive) close series, or None if unavailable.
    """
    try:
        import yfinance as yf

        raw = yf.Ticker(symbol).history(
            start=pd.Timestamp(start).normalize(),
            end=pd.Timestamp(end).normalize() + pd.Timedelta(days=1),
            interval="1d",
            auto_adjust=False,
        )
        if raw is None or raw.empty or "Close" not in raw.columns:
            return None

        s = raw["Close"].copy()
        s.index = pd.to_datetime(s.index).tz_localize(None).normalize()
        s = s[~s.index.duplicated(keep="last")].sort_index()
        s = pd.to_numeric(s, errors="coerce").dropna()
        return s if len(s) > 0 else None
    except Exception as exc:  # network / symbol / yfinance issues
        print(f"[market_context] fetch failed for {symbol}: {exc}")
        return None


def _asof_align(stock_dt, feature_df):
    """
    Backward as-of align a date-indexed feature frame onto stock timestamps.

    Each stock row receives the most recent index feature row at or before its
    timestamp, so both daily and intraday (hourly) stock rows are handled: an
    hourly row on day D inherits day D's daily market context.

    Parameters
    ----------
    stock_dt : pd.Series
        Stock 'datetime' column (any resolution), need not be sorted.
    feature_df : pd.DataFrame
        Date-indexed (normalised) frame of market features.

    Returns
    -------
    pd.DataFrame
        ``feature_df`` columns reindexed to ``stock_dt``'s original order.
    """
    left = pd.DataFrame({"datetime": pd.to_datetime(stock_dt).values})
    left["_order"] = np.arange(len(left))
    left_sorted = left.sort_values("datetime")

    right = feature_df.reset_index().rename(columns={"index": "datetime"})
    right = right.rename(columns={right.columns[0]: "datetime"})
    right["datetime"] = pd.to_datetime(right["datetime"])
    right = right.sort_values("datetime")

    merged = pd.merge_asof(
        left_sorted, right, on="datetime", direction="backward",
    )
    merged = merged.sort_values("_order").drop(columns=["_order", "datetime"])
    merged.index = left.index
    return merged


def add_market_context(df, interval, market_symbol=DEFAULT_MARKET_SYMBOL,
                       vix_symbol=DEFAULT_VIX_SYMBOL,
                       _market_series=None, _vix_series=None):
    """
    Attach causal market / volatility context columns to a stock DataFrame.

    Fetches the market and volatility indices over the df's date range, derives
    the :data:`MARKET_CONTEXT_COLS` features, and merges them onto the df by an
    as-of (backward) date match. Missing index values are filled with a neutral
    0 so the stock history is never truncated. If the market index cannot be
    fetched at all, the df is returned unchanged.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d'/'daily' or '1h'/'hourly' (only affects logging; indices are always
        fetched daily and aligned as-of).
    market_symbol : str, optional
        yfinance symbol for the market index. Default NIFTY 50 ('^NSEI').
    vix_symbol : str, optional
        yfinance symbol for the volatility index. Default India VIX
        ('^INDIAVIX'). If unavailable, the VIX-derived columns are left at 0.
    _market_series, _vix_series : pd.Series, optional
        Pre-supplied date-indexed close series (dependency injection for
        offline testing); when given, no network fetch occurs.

    Returns
    -------
    pd.DataFrame
        Copy of ``df`` with the context columns added, or the original df
        unchanged if the market index is unavailable.
    """
    if df is None or not hasattr(df, "columns") or "adj_close" not in df.columns:
        return df

    out = df.copy()
    out["datetime"] = pd.to_datetime(out["datetime"])
    start, end = out["datetime"].min(), out["datetime"].max()

    mkt = _market_series if _market_series is not None else \
        fetch_close_series(market_symbol, start, end)
    if mkt is None or len(mkt) < _BETA_WINDOW + 5:
        print("[market_context] market index unavailable; "
              "returning df without context features.")
        return df

    # Market features on the index's own daily grid (causal / trailing).
    mkt = mkt.sort_index()
    mkt_ret_1 = np.log(mkt / mkt.shift(1))
    idx_feat = pd.DataFrame(index=mkt.index)
    idx_feat["mkt_ret_1"] = mkt_ret_1
    idx_feat["mkt_ret_5"] = np.log(mkt / mkt.shift(5))

    vix = _vix_series if _vix_series is not None else \
        fetch_close_series(vix_symbol, start, end)
    if vix is not None and len(vix) >= _BETA_WINDOW:
        vix = vix.sort_index().reindex(mkt.index).ffill()
        idx_feat["vix_change"] = np.log(vix / vix.shift(1))
        roll = vix.rolling(_BETA_WINDOW)
        idx_feat["vix_z_60"] = (vix - roll.mean()) / roll.std().replace(0, np.nan)
    else:
        idx_feat["vix_change"] = 0.0
        idx_feat["vix_z_60"] = 0.0

    # Align the index returns onto the stock rows, then build the
    # stock-relative features (beta/correlation/relative strength) on the
    # stock's own row grid so they match the stock's trading calendar.
    aligned = _asof_align(out["datetime"], idx_feat)
    out["mkt_ret_1"] = aligned["mkt_ret_1"].values
    out["mkt_ret_5"] = aligned["mkt_ret_5"].values
    out["vix_change"] = aligned["vix_change"].values
    out["vix_z_60"] = aligned["vix_z_60"].values

    stock_ret = np.log(
        pd.to_numeric(out["adj_close"], errors="coerce")
        / pd.to_numeric(out["adj_close"], errors="coerce").shift(1)
    )
    out["excess_ret_1"] = stock_ret - out["mkt_ret_1"]
    out["rel_strength_20"] = (
        stock_ret.rolling(_REL_WINDOW).sum()
        - out["mkt_ret_1"].rolling(_REL_WINDOW).sum()
    )
    cov = stock_ret.rolling(_BETA_WINDOW).cov(out["mkt_ret_1"])
    var = out["mkt_ret_1"].rolling(_BETA_WINDOW).var()
    out["beta_60"] = cov / var.replace(0, np.nan)
    out["corr_60"] = stock_ret.rolling(_BETA_WINDOW).corr(out["mkt_ret_1"])

    # Neutralise warmup / missing-index gaps so context never truncates history.
    out[MARKET_CONTEXT_COLS] = (
        out[MARKET_CONTEXT_COLS]
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
    )

    n_ctx = int((out[MARKET_CONTEXT_COLS].abs().sum(axis=1) > 0).sum())
    print(f"[market_context] attached {len(MARKET_CONTEXT_COLS)} features "
          f"({market_symbol}) to {n_ctx}/{len(out)} rows.")
    return out
