"""
Single source of truth for the app's feature flags and serve-time tunables.

Why this module exists
----------------------
The ``USE_*`` toggles were defined wherever they happened to be consumed: five
in ``UI.py``, one in ``ML_model.py``. That is fine until something needs to
*read all of them at once* - and the console startup banner does, because an
operator watching ``cmd`` cannot otherwise tell which version of the app is
running. Building that banner meant importing a flag out of ``ML_model`` purely
to display it, which is the wrong direction of dependency: the UI ended up
depending on a model module for a piece of configuration.

Consolidating here fixes three things at once:

1. **One place to look.** Every flag, its default, and the evidence behind that
   default sit together, so "what ships on?" is answerable by reading one file.
2. **The banner is generated, not hand-listed.** :func:`active_flags` derives it
   from :data:`FLAGS`, so a flag added here appears in the console automatically
   and cannot silently go unreported.
3. **Environment overrides.** ``STOCKAPP_USE_MARKET_CONTEXT=1`` flips a flag for
   one run without editing source - which is what an A/B actually needs. Editing
   a constant to run an experiment is how experiments end up committed by
   accident.

Design constraints
------------------
- **Imports nothing from this project.** Every other module may import config;
  config may import no one. That keeps it free of circular-import risk and cheap
  enough to import from anywhere, including ``console.py``.
- **Flags resolve once, at import.** They are constants with constant semantics.
  ``env_flag`` itself reads live, so anything that genuinely needs a per-call
  value (``STOCKAPP_QUIET``) still gets one.
- **Consuming modules re-export their own binding.** ``ML_model`` does
  ``from config import USE_INTRADAY_FEATURES``, which keeps
  ``ML_model.USE_INTRADAY_FEATURES`` patchable by the existing A/B tests.

The defaults encode this project's standing rule: **an unvalidated feature does
not ship on.** Four of the six are off, each with a measured negative result
behind it rather than a hunch.
"""

import os

_TRUE = ("1", "true", "yes", "on")
_FALSE = ("0", "false", "no", "off")

ENV_PREFIX = "STOCKAPP_"


def env_flag(name, default=False):
    """
    Read a boolean environment variable, falling back to ``default``.

    Reads live rather than caching, so callers that need a per-call answer (the
    console's ``STOCKAPP_QUIET`` check) get one. An unrecognised value returns
    the default rather than raising: a malformed env var should not stop the app,
    it should just fail to take effect.
    """
    raw = os.environ.get(name)
    if raw is None:
        return default
    raw = raw.strip().lower()
    if raw in _TRUE:
        return True
    if raw in _FALSE:
        return False
    return default


def env_int(name, default):
    """Read an integer environment variable, falling back to ``default``."""
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return default


# -----------------------------------------------------------------------------
# Feature-flag registry
# -----------------------------------------------------------------------------
# Ordered: this is the order the console banner prints. Each entry carries the
# evidence for its default, so the reason a flag is off lives next to the flag
# rather than in a README section someone has to go find.
FLAGS = {
    "USE_MARKET_CONTEXT": {
        "label": "market-context",
        "default": False,
        "module": "market_context.py",
        "why": (
            "OFF: a controlled A/B on Indian tickers showed market/VIX context "
            "features did not improve 5-day forecasts and made the single tree "
            "models worse (extra overfitting surface at this horizon). Kept for "
            "experimentation; the promising direction is excess-return target "
            "reframing instead. See README 'Empirical findings'."
        ),
    },
    "USE_IV_ADJUST": {
        "label": "IV-tilt",
        "default": False,
        "module": "iv_data.py",
        "why": (
            "OFF: tilting the HAR-RV cone by the forward-looking India-VIX "
            "implied/realized factor is coverage-neutral on calm data and only "
            "widens directionally under stress, so it ships as a documented "
            "research opt-in. Single-name NSE option IV is not freely reachable "
            "(bot-protected API), so this is the market-level VIX only."
        ),
    },
    "USE_ASYMMETRIC_CONE": {
        "label": "asymmetric-cone",
        "default": False,
        "module": "HAR_RV_model.py",
        "why": (
            "OFF: separate lower/upper cone edges were mixed on tail-miss "
            "balance in an A/B on NSE names - per-side calibration is noisier "
            "when residuals are near-symmetric. The always-on downside reporting "
            "(expected shortfall, downside vol, vol skew) does not require it."
        ),
    },
    "USE_INTRADAY_FEATURES": {
        "label": "intraday-features",
        "default": True,
        "module": "ML_model.py",
        "why": (
            "ON: NSE session-structure features for hourly forecasts. Leak-free "
            "and train/serve-consistent, and intraday seasonality is more "
            "defensible than daily alpha - but NOT yet confirmed by a controlled "
            "hourly A/B (the main backtests are daily). Applies only to the "
            "tree/ML family. This is the one default not backed by a measurement."
        ),
    },
    "USE_REGIME_NOVELTY": {
        "label": "regime-novelty",
        "default": False,
        "module": "autoencoder_regime.py",
        "why": (
            "OFF: a denoising autoencoder scores how unlike its fitted history "
            "the latest window is; 'unprecedented' withholds every directional "
            "call, filling the blind spot the other two gates cannot see. Off "
            "because on the calm 2021-26 window it should almost never fire (that "
            "IS the design), so its value cannot be demonstrated there - the "
            "honest test is a stress window around March 2020. Needs TensorFlow; "
            "every failure path is a no-op, so enabling it can only add caution."
        ),
    },
    "USE_EPISTEMIC": {
        "label": "epistemic-uncertainty",
        "default": False,
        "module": "epistemic.py",
        "why": (
            "OFF: Monte-Carlo dropout (Klaas Ch. 4) measures MODEL uncertainty - "
            "how much a forecast would move under a different plausible fit - "
            "which the conformal cone cannot express because it takes the fitted "
            "model as given. Off because the number is a RELATIVE signal, not a "
            "calibrated probability: no coverage guarantee has been measured for "
            "it, and this project does not ship unvalidated features on. It also "
            "costs n_passes extra forward passes per model. Reported separately "
            "from the 95% band, never folded into it."
        ),
    },
    "USE_PREDICTION_LOG": {
        "label": "prediction-log",
        "default": True,
        "module": "prediction_log.py",
        "why": (
            "ON, and the only toggle that ships on without a measurement behind "
            "it - because it changes no forecast and makes no claim. It records "
            "what already happened, and a log that is off by default records "
            "nothing and is therefore worthless. Writing is best-effort and "
            "wrapped: a log failure is never a forecast failure."
        ),
    },
}


def _resolve(name):
    """Resolve one flag: registry default, overridden by ``STOCKAPP_<NAME>``."""
    return env_flag(ENV_PREFIX + name, FLAGS[name]["default"])


USE_MARKET_CONTEXT = _resolve("USE_MARKET_CONTEXT")
USE_IV_ADJUST = _resolve("USE_IV_ADJUST")
USE_ASYMMETRIC_CONE = _resolve("USE_ASYMMETRIC_CONE")
USE_INTRADAY_FEATURES = _resolve("USE_INTRADAY_FEATURES")
USE_REGIME_NOVELTY = _resolve("USE_REGIME_NOVELTY")
USE_EPISTEMIC = _resolve("USE_EPISTEMIC")
USE_PREDICTION_LOG = _resolve("USE_PREDICTION_LOG")


# -----------------------------------------------------------------------------
# Serve-time gate tunables
# -----------------------------------------------------------------------------
# The confidence gate must return while a user waits, which is the entire reason
# it runs so few origins. Exposing that as configuration rather than a buried
# constant makes the trade-off visible: raise GATE_SPLITS for a stronger check at
# the cost of a slower Submit. Three origins is enough to catch a broken model
# and NOT enough to establish skill - see README "Reading the screen", step 4.
GATE_SPLITS = env_int(ENV_PREFIX + "GATE_SPLITS", 3)
GATE_MIN_TRAIN = env_int(ENV_PREFIX + "GATE_MIN_TRAIN", 300)
GATE_MAX_ROWS = env_int(ENV_PREFIX + "GATE_MAX_ROWS", 600)

# Stochastic forward passes for MC-dropout epistemic uncertainty.
# 50 is the book's order of magnitude; the standard error of the
# reported spread falls as 1/sqrt(n), so fewer passes make the
# number noisier rather than wrong.
EPISTEMIC_PASSES = env_int(ENV_PREFIX + "EPISTEMIC_PASSES", 50)

# Silences console.py's banner / run header / run summary. Read live (not
# resolved here) so tests and one-off runs can toggle it in-process.
QUIET_ENV = ENV_PREFIX + "QUIET"


def active_flags():
    """
    Return ``{label: bool}`` for the console banner, in registry order.

    Generated rather than hand-listed, so a flag added to :data:`FLAGS` is
    reported automatically. A flag the operator cannot see is a flag that
    silently changes results.
    """
    return {meta["label"]: globals()[name] for name, meta in FLAGS.items()}


def overridden():
    """
    Return the names of flags currently differing from their shipped default.

    Worth surfacing separately: a run with an override active is not the shipped
    configuration, and any result from it should be read that way.
    """
    return [name for name, meta in FLAGS.items()
            if globals()[name] != meta["default"]]


def describe():
    """Return a plain-text dump of every flag, its state, and its rationale."""
    lines = []
    for name, meta in FLAGS.items():
        state = "on" if globals()[name] else "off"
        default = "on" if meta["default"] else "off"
        suffix = "" if state == default else f"  [OVERRIDDEN from {default}]"
        lines.append(f"{name} = {state}{suffix}")
        lines.append(f"    module: {meta['module']}")
        lines.append(f"    {meta['why']}")
        lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    print(describe())
    print(f"gate: splits={GATE_SPLITS} min_train={GATE_MIN_TRAIN} "
          f"max_rows={GATE_MAX_ROWS}")
