import pandas as pd
import numpy as np
from get_data import get_whole_stock_data, get_ticker
from model_utils import wilder_rsi
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

model_chronos_bolt_small = r"C:\Users\lrouta001\Desktop\AI Models\autogluon-chronos-bolt-small"
model_amazon_chronos_2 = r"C:\Users\lrouta001\Desktop\AI Models\amazon-chronos-2"

# ─── Constants ──────────────────────────────────────────────────────────────────
_VOLATILITY_WINDOW = 10
_SMA_SHORT = 5
_SMA_LONG = 20
_RSI_PERIOD = 14
_MAX_CONTEXT_DAILY = 2000
_MAX_CONTEXT_HOURLY = 4000
_QUANTILE_LEVELS = [0.025, 0.5, 0.975]

_pipeline_cache = None


def _get_pipeline():
    """
    Lazily load and cache the Chronos-2 pipeline.

    Loads the pretrained model on first call and caches it for
    subsequent calls, avoiding the memory and startup cost when
    the module is imported but prediction is not invoked.

    Returns
    -------
    Chronos2Pipeline
        Loaded and ready-to-use Chronos-2 pipeline instance.
    """
    global _pipeline_cache
    if _pipeline_cache is None:
        from chronos import BaseChronosPipeline

        # Use the GPU when one is available (Chronos-2 is a transformer that
        # benefits markedly from it); fall back to CPU otherwise.
        try:
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            device = "cpu"

        print(f"Loading Chronos-2 pipeline on {device}...")
        _pipeline_cache = BaseChronosPipeline.from_pretrained(
            model_amazon_chronos_2, device_map=device,
        )
        print("Chronos-2 pipeline loaded.")
    return _pipeline_cache


# ─── Feature Engineering ────────────────────────────────────────────────────────

def _add_covariates(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    """
    Add engineered covariates as past-only context for Chronos-2.

    Chronos-2 natively supports multivariate input: any numeric column
    in the DataFrame (besides the target) is used as a past-only
    covariate. Features are chosen to carry genuinely new information
    beyond raw OHLCV, using scale-invariant representations that
    generalise across price levels.

    Covariates added:
    - log_return : single-period log return
    - volatility : rolling standard deviation of log returns
    - log_volume_ratio : log(volume / 20-period MA), centered at 0
    - range_pct : (high - low) / price, normalized intraday range
    - rsi : Relative Strength Index via Wilder smoothing
    - sma_ratio : short SMA / long SMA, captures trend direction
    - momentum_5 : 5-period log return for medium-term trend
    - dayofweek, month : calendar seasonality
    - hour : intra-day seasonality (hourly only)

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with at least 'adj_close' and optionally 'volume',
        'high', 'low', and a datetime column.
    interval : str
        '1d' or '1h'; determines whether 'hour' covariate is added.

    Returns
    -------
    pd.DataFrame
        DataFrame with additional covariate columns, NaN/Inf cleaned
        via forward-fill then back-fill.
    """
    df = df.copy()
    price = df["adj_close"].astype(float)

    df["log_return"] = np.log(price / price.shift(1))

    df["volatility"] = (
        df["log_return"]
        .rolling(_VOLATILITY_WINDOW, min_periods=1)
        .std()
    )

    if "volume" in df.columns:
        vol = df["volume"].astype(float)
        vol_ma = vol.rolling(_SMA_LONG, min_periods=1).mean()
        df["log_volume_ratio"] = np.log(
            (vol / vol_ma.replace(0, 1)).clip(lower=0.01)
        )

    if "high" in df.columns and "low" in df.columns:
        df["range_pct"] = (
            (df["high"].astype(float) - df["low"].astype(float)) / price
        )

    df["rsi"] = wilder_rsi(price, period=_RSI_PERIOD)

    sma_short = price.rolling(_SMA_SHORT, min_periods=1).mean()
    sma_long = price.rolling(_SMA_LONG, min_periods=1).mean()
    df["sma_ratio"] = sma_short / sma_long.replace(0, 1)

    df["momentum_5"] = np.log(price / price.shift(5))

    ts_col = "original_datetime" if "original_datetime" in df.columns else "datetime"
    ts = pd.to_datetime(df[ts_col])
    df["dayofweek"] = ts.dt.dayofweek.astype(float)
    df["month"] = ts.dt.month.astype(float)
    if interval == "1h":
        df["hour"] = ts.dt.hour.astype(float)

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.ffill().bfill()
    return df


# ─── Data Preparation ───────────────────────────────────────────────────────────

def prepare_timeseries_data(
    df: pd.DataFrame, company_name: str, interval: str = "1d",
) -> pd.DataFrame:
    """
    Prepare timeseries data for the Chronos-2 pipeline.

    For daily data: normalises timestamps to midnight, reindexes to
    business-day frequency, and forward-fills gaps. For hourly data:
    preserves original timestamps in a separate column and replaces
    them with uniform 1-hour spacing (required by Chronos-2's
    regular-grid assumption).

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with a 'datetime' column and OHLCV data.
    company_name : str
        Company display name, used to derive the ticker for the 'id'
        column required by Chronos-2's ``predict_df`` API.
    interval : str, optional
        '1d' for daily or '1h' for hourly. Default is '1d'.

    Returns
    -------
    pd.DataFrame
        DataFrame ready for Chronos-2 with proper timestamp frequency,
        an 'id' column, and optionally an 'original_datetime' column
        (hourly only).

    Raises
    ------
    ValueError
        If *interval* is not '1d' or '1h'.
    """
    df = df.copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values("datetime").reset_index(drop=True)

    if interval == "1d":
        df = df.drop_duplicates(subset="datetime", keep="last")
        df["datetime"] = df["datetime"].dt.normalize()
        df = df.drop_duplicates(subset="datetime", keep="last")
        df = df.set_index("datetime")
        df = df.asfreq("B")
        df = df.ffill()
        df = df.reset_index()

    elif interval == "1h":
        df = df.drop_duplicates(subset="datetime", keep="last")
        df["original_datetime"] = df["datetime"]
        start_time = df["datetime"].iloc[0]
        uniform_timestamps = pd.date_range(
            start=start_time, periods=len(df), freq="h",
        )
        df["datetime"] = uniform_timestamps
        print(
            f"Hourly data: Replaced {len(df)} irregular timestamps "
            f"with uniform 1h spacing"
        )
    else:
        raise ValueError(f"Invalid interval: {interval}. Use '1d' or '1h'.")

    df["id"] = get_ticker(company_name)
    print(f"Interval: {interval} | Final shape: {df.shape}")
    return df


# ─── Output Cleaning ────────────────────────────────────────────────────────────

def clean_prediction_output(pred_df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean Chronos-2 prediction output into the standard model format.

    Renames columns to match the project-wide convention, drops
    metadata columns, and derives a ``volatility`` column from the
    confidence interval width for consistency with other models.

    Parameters
    ----------
    pred_df : pd.DataFrame
        Raw prediction DataFrame from ``pipeline.predict_df``.

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'volatility'].
    """
    pred_df = pred_df.copy()

    if "predictions" in pred_df.columns:
        pred_df = pred_df.rename(columns={"predictions": "predicted_price"})

    for col in ("target_name", "id"):
        if col in pred_df.columns:
            pred_df = pred_df.drop(columns=[col])

    float_cols = sorted(c for c in pred_df.columns if isinstance(c, float))
    if len(float_cols) >= 2:
        pred_df = pred_df.rename(
            columns={float_cols[0]: "lower_bound", float_cols[-1]: "upper_bound"},
        )
        middle_cols = float_cols[1:-1]
        if middle_cols:
            pred_df = pred_df.drop(columns=middle_cols, errors="ignore")

    if "lower_bound" in pred_df.columns and "upper_bound" in pred_df.columns:
        ci_width = pred_df["upper_bound"] - pred_df["lower_bound"]
        pred_df["volatility"] = (ci_width / (2 * 1.96)).clip(lower=0.0)
    else:
        pred_df["volatility"] = 0.0

    numeric_cols = pred_df.select_dtypes(include=["float64", "float32"]).columns
    pred_df[numeric_cols] = pred_df[numeric_cols].round(2)
    return pred_df.reset_index(drop=True)


# ─── Hourly Timestamp Mapping ───────────────────────────────────────────────────

def _map_hourly_predictions_to_real_timestamps(
    pred_df: pd.DataFrame,
    original_df: pd.DataFrame,
    prediction_length: int,
) -> pd.DataFrame:
    """
    Replace artificial uniform timestamps with real trading-hour timestamps.

    Chronos-2 requires uniform spacing for input, so hourly data uses
    synthetic 1-hour timestamps. This function maps predictions back
    to actual market hours derived from the observed trading schedule.

    Parameters
    ----------
    pred_df : pd.DataFrame
        Prediction DataFrame with synthetic 'datetime' column.
    original_df : pd.DataFrame
        Prepared input DataFrame containing 'original_datetime' with
        the true market-hours timestamps.
    prediction_length : int
        Number of forecast steps.

    Returns
    -------
    pd.DataFrame
        Prediction DataFrame with 'datetime' replaced by real future
        trading-hour timestamps.
    """
    original_times = original_df["original_datetime"]
    trading_times = sorted(set(original_times.dt.time))

    if not trading_times:
        return pred_df

    last_real_datetime = original_df["original_datetime"].iloc[-1]
    last_date = last_real_datetime.date()
    last_time = last_real_datetime.time()

    future_timestamps = []
    current_date = last_date

    try:
        time_idx = trading_times.index(last_time) + 1
    except ValueError:
        time_idx = 0
        current_date = current_date + pd.Timedelta(days=1)

    while len(future_timestamps) < prediction_length:
        if time_idx >= len(trading_times):
            current_date = current_date + pd.Timedelta(days=1)
            while pd.Timestamp(current_date).dayofweek >= 5:
                current_date = current_date + pd.Timedelta(days=1)
            time_idx = 0

        future_ts = pd.Timestamp.combine(current_date, trading_times[time_idx])
        future_timestamps.append(future_ts)
        time_idx += 1

    if "datetime" in pred_df.columns and len(pred_df) == prediction_length:
        pred_df["datetime"] = future_timestamps
        pred_df["datetime"] = pd.to_datetime(pred_df["datetime"])
    elif "datetime" in pred_df.columns:
        series_ids = (
            pred_df["id"].unique() if "id" in pred_df.columns else [None]
        )
        for sid in series_ids:
            mask = pred_df["id"] == sid if sid is not None else pred_df.index
            pred_df.loc[mask, "datetime"] = future_timestamps[: mask.sum()]

    print(
        f"Mapped predictions to real trading timestamps: "
        f"{future_timestamps[0]} -> {future_timestamps[-1]}"
    )
    return pred_df


# ─── Main Pipeline ──────────────────────────────────────────────────────────────

def run_chronos_prediction(
    df: pd.DataFrame,
    interval: str,
    prediction_length: int,
    company_name: str = "ID",
) -> pd.DataFrame:
    """
    Full Chronos-2 prediction pipeline.

    Orchestrates context limiting, timestamp preparation, covariate
    engineering, model inference, timestamp remapping (hourly), and
    output cleaning. The pipeline lazily loads the Chronos-2 model
    on first invocation to avoid unnecessary memory usage.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with columns datetime, open, high, low,
        close, adj_close, volume.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    prediction_length : int
        Number of future steps to predict.
    company_name : str, optional
        Company display name for ticker resolution. Default is 'ID'.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'volatility'].
    """
    interval = "1d" if interval in ("1d", "1D", "daily", "1 Day") else "1h"

    if isinstance(df, str):
        print(df)
        return pd.DataFrame()

    max_obs = _MAX_CONTEXT_DAILY if interval == "1d" else _MAX_CONTEXT_HOURLY
    if len(df) > max_obs:
        df = df.tail(max_obs).reset_index(drop=True)

    print(f"--- Starting Chronos-2 Prediction ({interval}) ---")
    print(company_name)

    df = prepare_timeseries_data(df, company_name, interval=interval)

    df = _add_covariates(df, interval)

    input_df = df.drop(columns=["original_datetime"], errors="ignore")

    pipeline = _get_pipeline()

    try:
        pred_df = pipeline.predict_df(
            input_df,
            prediction_length=prediction_length,
            quantile_levels=_QUANTILE_LEVELS,
            id_column="id",
            timestamp_column="datetime",
            target="adj_close",
            validate_inputs=(interval == "1d"),
        )
    except Exception as exc:
        raise RuntimeError(
            f"Chronos-2 prediction failed for '{company_name}' "
            f"(interval={interval}, horizon={prediction_length}): {exc}"
        ) from exc

    if interval == "1h" and "original_datetime" in df.columns:
        pred_df = _map_hourly_predictions_to_real_timestamps(
            pred_df=pred_df,
            original_df=df,
            prediction_length=prediction_length,
        )

    pred_df = clean_prediction_output(pred_df)
    print("Chronos-2 Prediction Complete.")
    return pred_df
