"""
Data-quality scoring for the forecast pipeline.

Reviewer ask (paraphrased): *"Because the source is yfinance, input robustness
matters a lot. Score the data before every forecast, attach reason codes, and
make data quality part of the confidence gate — good data forecasts normally,
poor data abstains or drops to HAR-RV-only."*

This module is the implementation. It is **pure** (pandas / numpy only, no
Streamlit, no I/O) so it can be unit-tested and reused by the backtest as well
as the app. ``assess_data_quality`` returns a structured report; the UI renders
it and ``gate_action`` maps it to a serving decision.

Design notes
------------
* Every check emits a *reason code* (stable string), a severity
  (``info`` / ``warn`` / ``critical``) and a human message — so the UI can show
  "Low confidence: only 38 sessions of hourly history" rather than a bare score.
* The numeric ``score`` (0-100) is a convenience summary; the **mode** decision
  is driven by reason codes, not the score alone, because a single critical flaw
  (stale data, unconverted currency) should abstain regardless of an otherwise
  clean series.
* Thresholds are module constants, documented inline, and deliberately lenient:
  the goal is to catch genuinely broken inputs, not to nag on normal market data
  (holidays, the odd zero-volume bar).
"""

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

# ── Severity levels and their score penalties ───────────────────────────────
INFO, WARN, CRITICAL = "info", "warn", "critical"
_PENALTY = {INFO: 3, WARN: 12, CRITICAL: 40}

# ── Thresholds (documented; tune here) ──────────────────────────────────────
NSE_BARS_PER_SESSION = 7          # mirror of model_utils; kept local to stay pure

# Insufficient-history floors: need enough rows to fit + walk-forward-assess.
_MIN_DAILY_ROWS = 60
_MIN_HOURLY_ROWS = 140            # ~20 NSE sessions
_HORIZON_ROW_FACTOR = 8           # want >= factor * horizon rows

# Staleness: how old the last bar may be before we flag it (calendar days).
_STALE_DAILY_WARN, _STALE_DAILY_CRIT = 5, 12
_STALE_HOURLY_WARN, _STALE_HOURLY_CRIT = 3, 8

# Bad-data fractions.
_BADOHLC_WARN, _BADOHLC_CRIT = 0.01, 0.05
_ZEROVOL_WARN, _ZEROVOL_CRIT = 0.10, 0.40
_NAN_PRICE_CRIT = 0.02

# Internal calendar gap: flag a *hole* bigger than this many calendar days. Use
# absolute days (not x-median) because intraday data has large but NORMAL gaps
# overnight and across weekends/holidays, which an x-median rule false-flags.
# Daily: >10 days is a real hole (NSE never closes that long). Hourly: >6 days
# exceeds even a long festival weekend.
_GAP_DAYS_DAILY = 10.0
_GAP_DAYS_HOURLY = 6.0
# Recent abnormal jump (possible unadjusted action / event): robust-z and size.
_JUMP_Z, _JUMP_ABS = 6.0, 0.15
_RECENT_BARS = 5
# Recent abnormal volume (event/news/corporate-action proxy): last bar's volume
# this many times the trailing median counts as a spike.
_VOL_SPIKE_X = 5.0
_VOL_MED_WINDOW = 20

# Short-hourly-window threshold (sessions).
_SHORT_HOURLY_SESSIONS = 100

# Score -> tier cut-offs (used only when no critical code forces the mode).
_GOOD_MIN, _MEDIUM_MIN = 82, 60

_PRICE_COLS = ("open", "high", "low", "close", "adj_close")


@dataclass
class DQReport:
    """Structured data-quality result."""
    score: float
    tier: str                      # 'good' | 'medium' | 'poor'
    mode: str                      # 'normal' | 'warn' | 'risk_cone_only' | 'abstain'
    codes: list = field(default_factory=list)   # list of dicts: code/severity/message
    checks: dict = field(default_factory=dict)  # raw metrics, for transparency
    event_risk: bool = False       # a price/volume event flag is present

    def messages(self, min_severity=INFO):
        order = {INFO: 0, WARN: 1, CRITICAL: 2}
        lo = order[min_severity]
        return [c["message"] for c in self.codes if order[c["severity"]] >= lo]

    @property
    def ok(self):
        return self.mode in ("normal", "warn")


def _add(codes, code, severity, message):
    codes.append({"code": code, "severity": severity, "message": message})


def _interval_kind(interval):
    return "hourly" if str(interval).lower() in ("1h", "hourly", "1 hour") else "daily"


def assess_data_quality(df, interval="1d", horizon=5, now=None):
    """
    Score a stock DataFrame's fitness for forecasting.

    Parameters
    ----------
    df : pd.DataFrame
        Raw OHLCV frame with a 'datetime' column (and optionally the
        ``fx_conversion`` / ``history`` attrs set by ``get_data``).
    interval : str
        '1d'/'daily' or '1h'/'hourly'.
    horizon : int
        Forecast horizon in steps (used for the insufficient-history floor).
    now : pd.Timestamp, optional
        Reference "current time" for staleness (defaults to ``pd.Timestamp.now()``);
        injectable for tests.

    Returns
    -------
    DQReport
    """
    codes = []
    checks = {}
    kind = _interval_kind(interval)

    # ── 0. Structural sanity ────────────────────────────────────────────────
    if df is None or not isinstance(df, pd.DataFrame) or len(df) == 0:
        _add(codes, "NO_DATA", CRITICAL, "No data returned for this ticker.")
        return DQReport(0.0, "poor", "abstain", codes, {"rows": 0})

    if "datetime" not in df.columns:
        _add(codes, "NO_DATETIME", CRITICAL, "Data has no datetime column.")
        return DQReport(0.0, "poor", "abstain", codes, {"rows": len(df)})

    n = len(df)
    checks["rows"] = n
    dt = pd.to_datetime(df["datetime"], errors="coerce")
    price = pd.to_numeric(df.get("adj_close"), errors="coerce") if "adj_close" in df.columns else None

    # ── 1. Insufficient history ─────────────────────────────────────────────
    floor = max(_MIN_HOURLY_ROWS if kind == "hourly" else _MIN_DAILY_ROWS,
                _HORIZON_ROW_FACTOR * int(horizon))
    checks["min_rows_required"] = floor
    if n < floor:
        _add(codes, "INSUFFICIENT_HISTORY", CRITICAL,
             f"Only {n} bars of history (< {floor} needed for a {horizon}-step "
             f"{kind} forecast). Too little data to model reliably.")
    elif n < 2 * floor:
        _add(codes, "THIN_HISTORY", WARN,
             f"Limited history ({n} bars); estimates will be noisier than usual.")

    if kind == "hourly":
        sessions = n // NSE_BARS_PER_SESSION
        checks["sessions"] = sessions
        if floor <= n and sessions < _SHORT_HOURLY_SESSIONS:
            _add(codes, "SHORT_HOURLY_WINDOW", WARN,
                 f"Only ~{sessions} trading sessions of hourly history "
                 "(provider-capped). Hourly models train on far less data than daily.")

    # ── 2. Duplicate / unsorted timestamps ──────────────────────────────────
    n_dup = int(dt.duplicated().sum())
    checks["duplicate_timestamps"] = n_dup
    if n_dup:
        sev = CRITICAL if n_dup > 0.05 * n else WARN
        _add(codes, "DUPLICATE_TIMESTAMPS", sev,
             f"{n_dup} duplicate timestamp(s) detected — would corrupt features.")
    if not dt.is_monotonic_increasing:
        _add(codes, "UNSORTED", INFO, "Timestamps are not sorted ascending.")

    # ── 3. NaN / non-positive prices ────────────────────────────────────────
    if price is None:
        _add(codes, "NO_PRICE_COLUMN", CRITICAL, "No adj_close price column found.")
    else:
        nan_frac = float(price.isna().mean())
        checks["nan_price_frac"] = round(nan_frac, 4)
        if nan_frac > _NAN_PRICE_CRIT:
            _add(codes, "NAN_PRICES", CRITICAL,
                 f"{nan_frac*100:.1f}% of prices are missing.")
        elif nan_frac > 0:
            _add(codes, "NAN_PRICES", WARN,
                 f"{nan_frac*100:.1f}% of prices are missing (will be dropped).")
        nonpos = int((price <= 0).sum())
        checks["nonpositive_prices"] = nonpos
        if nonpos:
            _add(codes, "NONPOSITIVE_PRICE", CRITICAL,
                 f"{nonpos} non-positive price(s) — log-return modeling impossible.")

    # ── 4. Bad OHLC rows ────────────────────────────────────────────────────
    if all(c in df.columns for c in ("high", "low", "close")):
        hi = pd.to_numeric(df["high"], errors="coerce")
        lo = pd.to_numeric(df["low"], errors="coerce")
        cl = pd.to_numeric(df["close"], errors="coerce")
        bad = (hi < lo) | (cl > hi * 1.001) | (cl < lo * 0.999)
        bad_frac = float(bad.mean())
        checks["bad_ohlc_frac"] = round(bad_frac, 4)
        if bad_frac > _BADOHLC_CRIT:
            _add(codes, "BAD_OHLC", CRITICAL,
                 f"{bad_frac*100:.1f}% of bars have inconsistent OHLC values.")
        elif bad_frac > _BADOHLC_WARN:
            _add(codes, "BAD_OHLC", WARN,
                 f"{bad_frac*100:.1f}% of bars have inconsistent OHLC values.")

    # ── 5. Zero-volume rows ─────────────────────────────────────────────────
    if "volume" in df.columns:
        vol = pd.to_numeric(df["volume"], errors="coerce").fillna(0)
        zero_frac = float((vol <= 0).mean())
        checks["zero_volume_frac"] = round(zero_frac, 4)
        if zero_frac > _ZEROVOL_CRIT:
            _add(codes, "ZERO_VOLUME", CRITICAL,
                 f"{zero_frac*100:.0f}% of bars have zero volume (illiquid / halted).")
        elif zero_frac > _ZEROVOL_WARN:
            _add(codes, "ZERO_VOLUME", WARN,
                 f"{zero_frac*100:.0f}% of bars have zero volume — thin liquidity.")

    # ── 6. Stale last candle ────────────────────────────────────────────────
    now = pd.Timestamp.now() if now is None else pd.Timestamp(now)
    last = dt.dropna().max()
    if pd.notna(last):
        age_days = (now.normalize() - last.normalize()).days
        checks["last_bar_age_days"] = int(age_days)
        warn_d, crit_d = ((_STALE_HOURLY_WARN, _STALE_HOURLY_CRIT) if kind == "hourly"
                          else (_STALE_DAILY_WARN, _STALE_DAILY_CRIT))
        if age_days > crit_d:
            _add(codes, "STALE_DATA", CRITICAL,
                 f"Last candle is {age_days} days old — data feed looks stale.")
        elif age_days > warn_d:
            _add(codes, "STALE_DATA", WARN,
                 f"Last candle is {age_days} days old (older than expected).")

    # ── 7. Internal calendar gaps (missing candles / halts) ─────────────────
    # Measured in calendar days against an interval-aware threshold so normal
    # overnight/weekend/holiday gaps (huge relative to an hourly cadence) don't
    # false-flag; only a genuine data hole trips this.
    dts = dt.dropna().sort_values()
    if len(dts) > 5:
        gap_days = dts.diff().dropna().dt.total_seconds() / 86400.0
        if len(gap_days):
            max_gap = float(gap_days.max())
            limit = _GAP_DAYS_HOURLY if kind == "hourly" else _GAP_DAYS_DAILY
            checks["max_gap_days"] = round(max_gap, 1)
            if max_gap > limit:
                _add(codes, "CALENDAR_GAP", WARN,
                     f"A {max_gap:.0f}-day gap in the series (missing candles / "
                     "trading halt / data hole).")

    # ── 8. Abnormal recent jump (possible unadjusted action or event) ───────
    if price is not None and price.notna().sum() > _RECENT_BARS + 20:
        r = np.log(price / price.shift(1)).replace([np.inf, -np.inf], np.nan).dropna()
        if len(r) > 25:
            med = float(r.median())
            mad = float((r - med).abs().median()) or 1e-9
            recent = r.tail(_RECENT_BARS)
            rz = (recent - med).abs() / (1.4826 * mad)   # robust z-score
            big = recent[(rz > _JUMP_Z) & (recent.abs() > _JUMP_ABS)]
            checks["recent_max_jump"] = round(float(recent.abs().max()), 4)
            if len(big):
                _add(codes, "ABNORMAL_GAP", WARN,
                     f"A {big.iloc[-1]*100:+.1f}% jump in the last {_RECENT_BARS} "
                     "bars — possible unadjusted corporate action or event risk.")

    # ── 8b. Abnormal recent volume (event / news / corporate-action proxy) ──
    if "volume" in df.columns:
        vol = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)
        if len(vol) > _VOL_MED_WINDOW + 1:
            med_vol = float(vol.iloc[-_VOL_MED_WINDOW - 1:-1].median())
            last_vol = float(vol.iloc[-1])
            if med_vol > 0:
                ratio = last_vol / med_vol
                checks["last_volume_x_median"] = round(ratio, 1)
                if ratio >= _VOL_SPIKE_X:
                    _add(codes, "ABNORMAL_VOLUME", WARN,
                         f"Latest volume is {ratio:.0f}x its 20-bar median — a "
                         "spike that often marks an event or corporate action.")

    # ── 9. Currency-conversion status (from get_data audit tag) ─────────────
    fx = getattr(df, "attrs", {}).get("fx_conversion") if hasattr(df, "attrs") else None
    if fx:
        checks["fx_method"] = fx.get("method")
        if fx.get("method") == "live_uniform":
            _add(codes, "FX_DEGRADED", WARN,
                 "Currency converted at a single live rate (historical levels rescaled).")
        elif fx.get("method") == "unconverted":
            _add(codes, "CURRENCY_UNCONVERTED", CRITICAL,
                 "Currency conversion failed — prices are not in INR.")

    # ── 10. Fetch source status (from safe_fetch's last-known-good wrapper) ──
    src = getattr(df, "attrs", {}).get("source") if hasattr(df, "attrs") else None
    if src:
        checks["source_status"] = src.get("status")
        if src.get("status") == "cached_fallback":
            _add(codes, "SOURCE_CACHED_FALLBACK", WARN,
                 f"Live fetch failed; using cached data "
                 f"(~{src.get('cache_age_days', '?')} days old). "
                 "Forecast downgraded to risk-cone-only.")
        elif src.get("status") == "partial":
            _add(codes, "SOURCE_PARTIAL", WARN,
                 "Live fetch returned suspiciously few bars (partial data).")

    # ── Aggregate ───────────────────────────────────────────────────────────
    score = 100.0 - sum(_PENALTY[c["severity"]] for c in codes)
    score = float(max(0.0, min(100.0, score)))

    event_risk = any(c["code"] in _EVENT_RISK_CODES for c in codes)
    mode = _resolve_mode(codes, score, event_risk)
    tier = {"normal": "good", "warn": "medium",
            "risk_cone_only": "poor", "abstain": "poor"}[mode]
    return DQReport(round(score, 1), tier, mode, codes, checks, event_risk)


# Critical codes that make ANY directional or point modeling untrustworthy ->
# abstain entirely. Other criticals (bad bars, illiquidity) still allow the
# random-walk + HAR-RV risk cone, which needs only a price series.
_ABSTAIN_CODES = {
    "NO_DATA", "NO_DATETIME", "NO_PRICE_COLUMN", "INSUFFICIENT_HISTORY",
    "STALE_DATA", "CURRENCY_UNCONVERTED", "NONPOSITIVE_PRICE", "NAN_PRICES",
}

# Price/volume event flags. When present, withhold the directional call and show
# the risk cone only (a known event makes the *direction* especially unreliable
# while the *cone* is exactly what should be shown — widened around the event).
_EVENT_RISK_CODES = {"ABNORMAL_GAP", "ABNORMAL_VOLUME"}

# Non-critical codes that nonetheless force risk-cone-only (withhold direction):
# serving off a stale cache is not trustworthy enough for a directional call.
_CONE_ONLY_CODES = {"SOURCE_CACHED_FALLBACK"}


def _resolve_mode(codes, score, event_risk=False):
    crit = [c for c in codes if c["severity"] == CRITICAL]
    if any(c["code"] in _ABSTAIN_CODES for c in crit):
        return "abstain"
    if crit:
        return "risk_cone_only"
    # An event flag or a cache-fallback serve withholds direction even if the
    # series is otherwise clean.
    if event_risk or any(c["code"] in _CONE_ONLY_CODES for c in codes):
        return "risk_cone_only"
    if score < _MEDIUM_MIN:
        return "risk_cone_only"
    if score < _GOOD_MIN:
        return "warn"
    return "normal"


def gate_action(report):
    """
    Map a DQReport to a UI/serving action.

    Returns a dict: {level, headline, detail} where level is a Streamlit method
    name ('success'/'info'/'warning'/'error').
    """
    if report.mode == "abstain":
        return {
            "level": "error",
            "headline": "Forecast withheld — data quality insufficient",
            "detail": "; ".join(report.messages(CRITICAL)) or
                      "Critical data-quality problem.",
        }
    if report.mode == "risk_cone_only":
        headline = ("Event risk detected — showing the risk cone, not directional "
                    "calls" if report.event_risk
                    else "Degraded data — showing the risk cone, not directional calls")
        return {
            "level": "warning",
            "headline": headline,
            "detail": "; ".join(report.messages(WARN)),
        }
    if report.mode == "warn":
        return {
            "level": "warning",
            "headline": f"Data-quality caveats (score {report.score:.0f}/100)",
            "detail": "; ".join(report.messages(WARN)),
        }
    return {
        "level": "success",
        "headline": f"Data quality OK (score {report.score:.0f}/100)",
        "detail": "",
    }
