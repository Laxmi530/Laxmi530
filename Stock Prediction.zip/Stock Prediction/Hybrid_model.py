import pandas as pd
import numpy as np
import pmdarima as pm
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler
import os
import warnings

from model_utils import (
    normalize_interval,
    prepare_log_returns,
    reset_keras_seeds,
    temporal_train_val_split,
    default_keras_callbacks,
    generate_future_dates,
)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

_LOOK_BACK = 30


# ==========================================
# 1. ARIMA Component (Linear)
# ==========================================
def _fit_arima(returns):
    """
    Fit Auto-ARIMA on log returns to capture the linear component.

    Uses BIC for model selection, d=0 (returns are stationary), and
    caps the total ARMA order at 10 to prevent overfitting.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Log return series.

    Returns
    -------
    pmdarima.ARIMA
        Fitted ARIMA model.
    """
    print("Fitting ARIMA (linear component)...")
    arima_model = pm.auto_arima(
        returns,
        start_p=0, start_q=0,
        max_p=5, max_q=5,
        max_order=10,
        d=0,
        seasonal=False,
        information_criterion='bic',
        stepwise=True,
        suppress_warnings=True,
        error_action='ignore',
        trace=False,
    )
    print(f"Best ARIMA Order: {arima_model.order}")
    return arima_model


# ==========================================
# 3. LSTM Component (Non-linear Residuals)
# ==========================================
def _build_residual_sequences(residuals, look_back=_LOOK_BACK):
    """
    Create scaled look-back sequences from ARIMA residuals for the LSTM.

    The LSTM learns the non-linear patterns that ARIMA cannot capture.
    Residuals are scaled to [0, 1] before sequencing.

    Parameters
    ----------
    residuals : np.ndarray
        1-D array of ARIMA residuals (observed - ARIMA fitted).
    look_back : int, optional
        Number of past residual values per input sequence. Default 30.

    Returns
    -------
    X : np.ndarray
        (n_samples, look_back, 1) input sequences.
    y : np.ndarray
        (n_samples,) target values (next residual, scaled).
    scaler : MinMaxScaler
        Fitted scaler for inverse transforms.
    """
    resid = residuals.reshape(-1, 1).astype(np.float64)

    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled = scaler.fit_transform(resid).flatten()

    X, y = [], []
    for i in range(look_back, len(scaled)):
        X.append(scaled[i - look_back:i])
        y.append(scaled[i])

    X = np.array(X).reshape(-1, look_back, 1)
    y = np.array(y)

    return X, y, scaler


def _train_residual_lstm(X, y):
    """
    Train a small LSTM to model the ARIMA residual series.

    Architecture: two LSTM layers (32, 16 units) with dropout,
    trained with Huber loss, Adam with gradient clipping, early
    stopping, and LR scheduling on a temporal validation split.

    Parameters
    ----------
    X : np.ndarray
        (n_samples, look_back, 1) input sequences.
    y : np.ndarray
        (n_samples,) target values.

    Returns
    -------
    tf.keras.Model
        Trained LSTM model for residual prediction.
    """
    reset_keras_seeds()

    X_train, X_val, y_train, y_val = temporal_train_val_split(X, y)

    model = Sequential([
        LSTM(32, return_sequences=True, recurrent_dropout=0.1,
             input_shape=(X.shape[1], 1)),
        Dropout(0.2),
        LSTM(16, return_sequences=False, recurrent_dropout=0.1),
        Dropout(0.2),
        Dense(8, activation='relu'),
        Dense(1),
    ])

    model.compile(
        loss='huber',
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3, clipnorm=1.0),
    )

    print("Training LSTM on ARIMA residuals...")
    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=80,
        batch_size=32,
        callbacks=default_keras_callbacks(),
        shuffle=True,
        verbose=0,
    )
    return model


# ==========================================
# 4. Recursive Hybrid Prediction
# ==========================================
def _predict_hybrid_recursive(arima_model, lstm_model, resid_scaler,
                              residual_history, last_price, horizon,
                              interval, last_date):
    """
    Recursive multi-step forecasting combining ARIMA and LSTM.

    At each step:
    1. ARIMA predicts the next log return (linear component).
    2. LSTM predicts the next residual correction (non-linear).
    3. The combined return = ARIMA mean + LSTM residual correction.
    4. Price is updated and buffers are extended.

    Parameters
    ----------
    arima_model : pmdarima.ARIMA
        Fitted ARIMA model.
    lstm_model : tf.keras.Model
        Trained LSTM for residual prediction.
    resid_scaler : MinMaxScaler
        Scaler fitted on ARIMA residuals.
    residual_history : np.ndarray
        Recent residual values for the LSTM input buffer.
    last_price : float
        Last observed adjusted close price.
    horizon : int
        Steps to forecast.
    interval : str
        'daily' or 'hourly'.
    last_date : datetime-like
        Last observed datetime.

    Returns
    -------
    pd.DataFrame
        Columns: ['datetime', 'predicted_price'].
    """
    future_preds = []
    curr_price = last_price

    resid_buffer = list(residual_history[-_LOOK_BACK:])

    future_dates = generate_future_dates(last_date, horizon, interval)

    print(f"Generating {horizon} hybrid (ARIMA+LSTM) forecasts...")

    for curr_date in future_dates:
        arima_pred = float(arima_model.predict(n_periods=1)[0])
        arima_model.update([arima_pred])

        recent_resid = np.array(resid_buffer[-_LOOK_BACK:]).reshape(-1, 1)
        scaled_resid = resid_scaler.transform(recent_resid).flatten()
        lstm_input = scaled_resid.reshape(1, _LOOK_BACK, 1)
        lstm_scaled = lstm_model.predict(lstm_input, verbose=0)[0, 0]

        dummy = np.array([[lstm_scaled]])
        lstm_correction = float(resid_scaler.inverse_transform(dummy)[0, 0])

        combined_return = arima_pred + lstm_correction
        pred_price = curr_price * np.exp(combined_return)

        future_preds.append({
            'datetime': curr_date,
            'predicted_price': float(pred_price),
        })

        actual_resid = combined_return - arima_pred
        resid_buffer.append(actual_resid)
        curr_price = pred_price

    return pd.DataFrame(future_preds)


# ==========================================
# 5. Main Orchestrator
# ==========================================
def run_hybrid_prediction(df, interval, horizon):
    """
    Main function to run the ARIMA + LSTM hybrid prediction.

    Decomposes the forecasting problem into a linear component
    (ARIMA on log returns) and a non-linear component (LSTM on
    ARIMA residuals). This hybrid approach is well-documented in
    the literature as outperforming either model alone, because
    ARIMA captures the autocorrelation structure while the LSTM
    learns complex non-linear residual patterns that ARIMA misses.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        Columns: ['datetime', 'predicted_price'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Hybrid ARIMA+LSTM Prediction ({interval}) ---")

    max_obs = 750 if interval == 'daily' else 500
    clean_df = prepare_log_returns(df, max_obs=max_obs)

    returns = clean_df['log_return'].values

    arima_model = _fit_arima(returns)

    arima_fitted = arima_model.predict_in_sample()
    residuals = returns - arima_fitted

    if len(residuals) <= _LOOK_BACK + 10:
        print("Insufficient data for LSTM residual model, using ARIMA only")
        last_price = float(clean_df['adj_close'].iloc[-1])
        last_date = clean_df.index[-1]
        arima_fcast = arima_model.predict(n_periods=horizon)

        future_dates = generate_future_dates(last_date, horizon, interval)

        future_data = []
        curr_price = last_price
        for i in range(horizon):
            curr_price *= np.exp(arima_fcast[i])
            future_data.append({
                'datetime': future_dates[i],
                'predicted_price': float(curr_price),
            })
        return pd.DataFrame(future_data)

    X_res, y_res, resid_scaler = _build_residual_sequences(residuals)
    lstm_model = _train_residual_lstm(X_res, y_res)

    last_price = float(clean_df['adj_close'].iloc[-1])
    last_date = clean_df.index[-1]

    results_df = _predict_hybrid_recursive(
        arima_model, lstm_model, resid_scaler,
        residuals, last_price, horizon, interval, last_date,
    )

    print("Hybrid ARIMA+LSTM Prediction Complete.")
    return results_df
