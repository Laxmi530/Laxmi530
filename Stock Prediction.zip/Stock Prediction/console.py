"""
Consistent, decision-oriented console output for the Streamlit app.

Why this module exists
----------------------
Running ``streamlit run UI.py`` prints a long, interleaved trace of per-model
chatter — "Fitting Auto-ARIMA...", "Simulating 10000 price paths...",
"Prediction Complete." That trace tells an operator *which model is running*
and nothing at all about what the app **concluded**. The conclusion is the
product: the data-quality verdict, each model's confidence bucket and the reason
for it, and whether anything beat a random walk. All of that was visible in the
browser and invisible in the terminal.

This module closes that gap. It prints three things the raw trace never did:

1. a **startup banner** naming the seed, the compute device, and which optional
   layers are on — because five ``USE_*`` flags materially change the output and
   an operator watching the console had no way to tell which were active;
2. a **run header** framing each Submit, so one run's output is separable from
   the next;
3. a **run summary** mirroring the UI's decision layer — the same verdict, the
   same buckets, the same reasons.

Design constraints
------------------
- **No Streamlit import.** Keeps the module unit-testable and reusable from the
  offline drivers.
- **No duplicated policy.** The summary renders verdicts the caller computed
  (``_honesty_banner``, ``confidence_reason``); it never re-derives them, so the
  console and the browser cannot drift apart.
- **ASCII only, and encoding-safe.** A Windows ``cmd`` console commonly runs a
  legacy code page where printing a box-drawing character or an emoji raises
  ``UnicodeEncodeError`` — which would turn a cosmetic log line into a crashed
  run. Output is plain ASCII and every write is wrapped (see :func:`_write`).
- **Silenceable.** Set ``STOCKAPP_QUIET=1`` to suppress everything here.
"""

import os
import sys
import textwrap

import config as _cfg

WIDTH = 80

# Printed once per process. Streamlit re-executes UI.py top-to-bottom on every
# interaction, so a module-level banner in UI.py would reprint on every widget
# click; this module is imported once and cached in sys.modules, so a flag here
# survives reruns without needing st.session_state.
_BANNER_SHOWN = False


def enabled():
    """
    Return False when ``STOCKAPP_QUIET`` is set to a truthy value.

    Reads live on every call (via ``config.env_flag``) rather than resolving at
    import, so a test or a one-off script can silence output in-process.
    """
    return not _cfg.env_flag(_cfg.QUIET_ENV, False)


def _write(text):
    """
    Print one line, degrading rather than raising on a legacy console encoding.

    Everything this module emits is ASCII, so the fallback should never fire for
    our own strings — but callers pass through model names, tickers and
    exception messages, any of which can carry non-ASCII. A logging line must
    never be the thing that kills a forecast.
    """
    if not enabled():
        return
    try:
        print(text)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "ascii"
        print(text.encode(enc, errors="replace").decode(enc, errors="replace"))
    except Exception:
        pass


def rule(char="-"):
    """Print a full-width horizontal rule."""
    _write(char * WIDTH)


def field(label, value, label_w=16):
    """
    Print an aligned ``label   value`` row, wrapping long values under the value
    column so the label gutter stays readable.
    """
    lab = f"  {label:<{label_w}}"
    pad = " " * len(lab)
    lines = textwrap.wrap(str(value), width=max(20, WIDTH - len(lab))) or [""]
    _write(lab + lines[0])
    for chunk in lines[1:]:
        _write(pad + chunk)


def note(tag, message):
    """Print a tagged, non-fatal advisory line (consistent with app prefixes)."""
    _write(f"[{tag}] {message}")


def short_path(path):
    """
    Render a path relative to the working directory when that is shorter.

    LOG_FILE is absolute, and an absolute Windows path wraps across two console
    lines for no information gain. Falls back to the original on any failure
    (different drive, permission error), because a cosmetic helper must never
    be the thing that raises.
    """
    if not path:
        return path
    try:
        rel = os.path.relpath(str(path))
        return rel if len(rel) < len(str(path)) else str(path)
    except Exception:
        return str(path)


def _flag(name, on):
    """Compact, greppable flag rendering: ``market-context=off``."""
    return f"{name}={'on' if on else 'off'}"


def startup_banner(seed, device, n_models, flags, log_path=None,
                   overrides=None, force=False):
    """
    Print the once-per-process startup banner.

    Parameters
    ----------
    seed : int
        The global RNG seed every model is pinned to.
    device : str
        Human-readable compute device label.
    n_models : int
        Size of the model registry.
    flags : dict
        Mapping of optional-layer name -> bool. Printed in registry order so the
        console matches the flag block at the top of UI.py.
    log_path : str, optional
        Where the forward prediction log is being written.
    overrides : list of str, optional
        Flags whose value differs from the shipped default (``config.overridden``).
        Called out separately and loudly: a run with an override active is not
        the shipped configuration, and any number it produces has to be read
        that way. Silently honouring an environment variable is how a stray
        export ends up misattributed as a result.
    force : bool
        Print even if the banner was already shown (used by tests).
    """
    global _BANNER_SHOWN
    if _BANNER_SHOWN and not force:
        return False
    _BANNER_SHOWN = True

    rule("=")
    _write(f" Stock Prediction  |  seed {seed}  |  {device}  |  "
           f"{n_models} models")
    rule("=")

    items = [_flag(k, v) for k, v in flags.items()]
    for i in range(0, len(items), 2):
        field("optional layers" if i == 0 else "", "   ".join(items[i:i + 2]))
    if overrides:
        field("OVERRIDDEN", ", ".join(overrides)
              + "  <- not the shipped default; read results accordingly")
    if log_path:
        field("prediction log", short_path(log_path))
    field("guide", 'README.md > "Reading the screen: which numbers support '
                   'a decision" explains every number below.')
    field("quiet mode", "set STOCKAPP_QUIET=1 to silence this output.")
    rule("=")
    return True


def run_header(ticker, interval, horizon, models, timestamp=None):
    """Frame the start of one Submit so runs are separable in a long scroll."""
    rule()
    stamp = f"  |  {timestamp}" if timestamp else ""
    _write(f"RUN  {ticker}  |  {interval}  |  horizon {horizon}  |  "
           f"{len(models)} model(s){stamp}")
    rule()


_DQ_ACTION = {
    "ok": "forecasts usable",
    "warn": "usable, with caveats",
    "risk_cone_only": "DIRECTIONAL CALLS WITHHELD - risk cone only",
    "abstain": "FORECAST WITHHELD - input too degraded",
}


def run_summary(ticker, interval, horizon, dq_mode, dq_score, conf_rows,
                consensus=None, verdict=None, novelty_verdict=None,
                log_path=None, n_logged=0, elapsed=None):
    """
    Print the end-of-run decision summary — the console mirror of the UI.

    Deliberately renders, rather than recomputes, every verdict: ``conf_rows``
    carries the buckets and reason strings the UI already built, and ``verdict``
    is the honesty banner's own text. If the policy changes in ``gating.py`` or
    ``backtest.confidence_bucket``, this output follows automatically.

    Parameters
    ----------
    dq_mode : str
        One of 'ok', 'warn', 'risk_cone_only', 'abstain'.
    dq_score : float
        Data-quality score out of 100.
    conf_rows : list of tuple
        ``(model_name, bucket, basis)`` per model, in display order.
    consensus : dict, optional
        Output of the UI's ``_build_consensus``.
    verdict : str, optional
        Plain-text honesty banner (markdown already stripped by the caller).
    novelty_verdict : str, optional
        Regime-novelty verdict, or None when the gate is disabled.
    log_path, n_logged : str, int
        Where forecasts were appended, and how many rows.
    elapsed : float, optional
        Wall-clock seconds for the run.
    """
    rule()
    _write(f"RESULT  {ticker}  {interval}  h={horizon}"
           + (f"  ({elapsed:.1f}s)" if elapsed is not None else ""))

    action = _DQ_ACTION.get(dq_mode, dq_mode)
    score = f"{dq_score:.0f}/100" if dq_score is not None else "n/a"
    field("data quality", f"{dq_mode.upper()} (score {score}) -> {action}")

    field("regime", novelty_verdict if novelty_verdict
          else "novelty gate off (USE_REGIME_NOVELTY = False)")

    if conf_rows:
        name_w = min(22, max(len(str(m)) for m, _, _ in conf_rows))
        for i, (model, bucket, basis) in enumerate(conf_rows):
            row = f"{str(model)[:name_w]:<{name_w}}  {str(bucket):<8}  {basis}"
            field("confidence" if i == 0 else "", row)
    else:
        field("confidence", "not assessed (confidence check disabled)")

    if consensus:
        field("consensus",
              f"median {consensus.get('median_price', float('nan')):,.2f} "
              f"({consensus.get('median_pct', float('nan')):+.2f}%)  |  "
              f"bullish {consensus.get('n_up', 0)}  |  "
              f"bearish {consensus.get('n_down', 0)}  |  "
              f"withheld {consensus.get('n_noedge', 0)}")

    if verdict:
        field("verdict", verdict)

    if log_path and n_logged:
        field("logged", f"{n_logged} row(s) -> {short_path(log_path)}")

    rule()


def strip_markdown(text):
    """
    Flatten the UI's markdown banner text for console use.

    The honesty banner is authored once, with ``**bold**`` for the browser. The
    console needs the same sentence without the asterisks; re-authoring it as a
    second string is how two channels start telling different stories.
    """
    if not text:
        return ""
    return " ".join(text.replace("**", "").split())
