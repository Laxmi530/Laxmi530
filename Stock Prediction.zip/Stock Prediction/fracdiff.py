"""
Fractional differentiation: stationarity without throwing the memory away.

The design choice this questions
---------------------------------
Every model in this project sees **fully differenced** data. ``prepare_log_returns``
computes ``log(price / price.shift(1))``; the features are ``log_return_1..10``;
the target is a cumulative log return. That is differencing order **d = 1**, and
it was adopted by convention, never measured.

d = 1 guarantees stationarity, and it is *maximally destructive*: it removes not
just the trend but every trace of long-range dependence in the level. If prices
carry persistent structure — and long memory in financial series is a
well-documented empirical claim — then d = 1 discards it before any model sees
the data, and no architecture downstream can recover it.

Kaabar, *Deep Learning for Finance*, Ch. 9, describing López de Prado's method:

    "Fractional differentiation is a mathematical technique used to transform a
     time series into a stationary series while preserving some of its memory...
     if [these dependencies] are completely eliminated, that may hinder the
     ability of the algorithm to perform well."

On the S&P 500 the book reports ADF p = 0.842 raw, **0.039 at d = 0.48**, and
0.000 at d = 1 — stationary at a fractional order, with memory intact.

How it works
------------
The differencing operator ``(1 - B)^d`` expands, for non-integer d, into an
infinite binomial series::

    w_0 = 1,   w_k = -w_{k-1} * (d - k + 1) / k

giving ``x_t^(d) = sum_k w_k * x_{t-k}``. For d = 1 the weights terminate at
``[1, -1]`` — an ordinary first difference. For 0 < d < 1 they decay slowly and
never terminate, which is precisely the memory being retained. The series is
truncated where ``|w_k|`` falls below a tolerance.

The window is fixed rather than expanding (López de Prado's "fixed-width window"
variant), so every observation is differenced with the *same* weights. An
expanding window applies different weights early and late in the sample, which
makes the transformed series non-comparable across time — a subtle way to
introduce drift into what is supposed to be a stationarity transform.

No new dependency
-----------------
The book uses ``pip install fracdiff``. The weights are a four-line recurrence,
so this module implements them directly; ADF/KPSS come from ``statsmodels``,
already pinned in ``requirements.txt``.

Honest expectation
------------------
This is a **representation** change, and Section 32 established that this
project's binding constraint is *information*. A representation change cannot
create signal that is not there. It is worth measuring anyway because, unlike
"add another architecture", it adds no parameters — so a null result cannot be
blamed on capacity — and because it puts a number on a choice currently made by
convention. ``run_fracdiff_eval.py`` runs that A/B.
"""

import numpy as np
import pandas as pd

_EPS = 1e-12


def frac_weights(d, size=None, tol=1e-5, max_size=2000):
    """
    Binomial weights of the operator ``(1 - B)^d``.

    Parameters
    ----------
    d : float
        Differencing order. ``d = 0`` is the identity, ``d = 1`` an ordinary
        first difference, ``0 < d < 1`` the fractional case.
    size : int, optional
        Fixed number of weights. When omitted the series is truncated at the
        first ``|w_k| < tol``, which is what makes the window width a property
        of ``d`` rather than an arbitrary hyperparameter.

    Returns
    -------
    numpy.ndarray
        Weights ordered ``[w_0, w_1, ...]`` with ``w_0 = 1`` — i.e. index 0
        multiplies the *most recent* observation.
    """
    w = [1.0]
    k = 1
    limit = size if size is not None else max_size
    while k < limit:
        nxt = -w[-1] * (d - k + 1) / k
        if size is None and abs(nxt) < tol:
            break
        w.append(nxt)
        k += 1
    return np.asarray(w, dtype=float)


def frac_diff(series, d, tol=1e-5, window=None):
    """
    Fixed-width fractional differencing of a 1-D series.

    Returns
    -------
    numpy.ndarray
        Same length as the input, with the first ``len(weights) - 1`` entries
        NaN — those observations have no full window and are *not* padded with
        a partial one. Padding them would apply different weights to different
        rows, which is the very inconsistency the fixed-width variant exists to
        avoid.
    """
    x = np.asarray(series, dtype=float)
    n = len(x)
    w = frac_weights(d, size=window, tol=tol)
    width = len(w)
    out = np.full(n, np.nan)
    if n < width:
        return out
    # w[0] multiplies the current observation, w[k] the one k bars back.
    for t in range(width - 1, n):
        seg = x[t - width + 1: t + 1][::-1]      # most recent first
        if np.any(~np.isfinite(seg)):
            continue
        out[t] = float(np.dot(w, seg))
    return out


def adf_pvalue(x):
    """Augmented Dickey-Fuller p-value; NaN on failure rather than raising."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 30 or np.std(x) < _EPS:
        return float("nan")
    try:
        from statsmodels.tsa.stattools import adfuller
        return float(adfuller(x, autolag="AIC")[1])
    except Exception:
        return float("nan")


def kpss_pvalue(x):
    """
    KPSS p-value, whose null is the *opposite* of ADF's.

    Reported alongside because the two tests disagree in an informative way:
    ADF's null is "has a unit root" (non-stationary), KPSS's is "is stationary".
    A series that rejects ADF *and* fails to reject KPSS is stationary on both
    readings; one that rejects both is usually fractionally integrated, which is
    exactly the regime this module operates in.
    """
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 30 or np.std(x) < _EPS:
        return float("nan")
    try:
        import warnings
        from statsmodels.tsa.stattools import kpss
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return float(kpss(x, regression="c", nlags="auto")[1])
    except Exception:
        return float("nan")


def min_d(series, d_grid=None, alpha=0.05, tol=1e-5):
    """
    Smallest differencing order that achieves stationarity.

    The point of the whole method: take the *least* differencing that passes
    ADF, because every increment of ``d`` beyond that discards memory for no
    statistical gain. López de Prado's minimum-``d`` criterion.

    Returns
    -------
    dict
        ``d`` (the chosen order, NaN if none qualifies), the full ``scan``
        table, and ``corr_with_level`` — the correlation between the
        transformed series and the original level, which is the direct measure
        of how much memory survived. For d = 1 this collapses toward zero; a
        useful fractional order keeps it high.
    """
    x = np.asarray(series, dtype=float)
    if d_grid is None:
        d_grid = np.round(np.arange(0.0, 1.01, 0.05), 2)

    rows = []
    chosen = float("nan")
    for d in d_grid:
        fd = frac_diff(x, float(d), tol=tol)
        ok = np.isfinite(fd)
        if ok.sum() < 50:
            continue
        p_adf = adf_pvalue(fd[ok])
        p_kpss = kpss_pvalue(fd[ok])
        # Memory retained: correlation of the transformed series with the level
        # it came from, on the rows where both exist.
        lvl = x[ok]
        corr = (float(np.corrcoef(fd[ok], lvl)[0, 1])
                if np.std(lvl) > _EPS and np.std(fd[ok]) > _EPS else float("nan"))
        stationary = np.isfinite(p_adf) and p_adf < alpha
        rows.append({"d": float(d), "adf_p": p_adf, "kpss_p": p_kpss,
                     "corr_with_level": corr, "n_obs": int(ok.sum()),
                     "window": int(len(frac_weights(float(d), tol=tol))),
                     "stationary": bool(stationary)})
        if stationary and not np.isfinite(chosen):
            chosen = float(d)

    scan = pd.DataFrame(rows)
    corr_at_d = float("nan")
    if np.isfinite(chosen) and not scan.empty:
        hit = scan[scan["d"] == chosen]
        if len(hit):
            corr_at_d = float(hit.iloc[0]["corr_with_level"])
    return {"d": chosen, "scan": scan, "corr_with_level": corr_at_d,
            "alpha": alpha}


def add_fracdiff_features(df, price_col="adj_close", d=None, orders=(0.3, 0.5),
                          prefix="fd", tol=1e-5):
    """
    Attach fractionally differenced log-price columns to a feature frame.

    Operates on **log** prices so the result is comparable in scale to the
    project's existing log-return features, and so a d = 1 column reduces
    exactly to ``log_return_1`` — which makes the A/B a like-for-like swap
    rather than a change of units.

    Parameters
    ----------
    d : float, optional
        A single order. When given it overrides ``orders``.
    orders : tuple
        Orders to add when ``d`` is not supplied.
    """
    out = df.copy()
    if price_col not in out.columns:
        return out
    px = pd.to_numeric(out[price_col], errors="coerce").values
    logpx = np.log(np.maximum(px, _EPS))
    for order in ([d] if d is not None else list(orders)):
        col = f"{prefix}_{str(order).replace('.', '')}"
        out[col] = frac_diff(logpx, float(order), tol=tol)
    return out


def format_report(res, label="series"):
    """Plain-text summary of a minimum-d scan."""
    scan = res.get("scan")
    lines = [f"=== Fractional differentiation: {label} ==="]
    if scan is None or scan.empty:
        lines.append("  no usable orders (series too short)")
        return "\n".join(lines)
    lines.append("      d   ADF p   KPSS p   corr(level)   window  stationary")
    for _, r in scan.iterrows():
        lines.append(f"   {r['d']:>4.2f}  {r['adf_p']:>6.4f}  {r['kpss_p']:>6.4f}  "
                     f"{r['corr_with_level']:>11.4f}  {int(r['window']):>7}  "
                     f"{'yes' if r['stationary'] else 'no'}")
    d = res.get("d")
    if np.isfinite(d):
        lines.append(f"\n  Minimum stationary d : {d:.2f} "
                     f"(ADF p < {res['alpha']})")
        lines.append(f"  Memory retained      : corr with level "
                     f"{res['corr_with_level']:.4f}")
        d1 = scan[scan["d"] == 1.0]
        if len(d1):
            lines.append(f"  For comparison, d = 1: corr with level "
                         f"{float(d1.iloc[0]['corr_with_level']):.4f} "
                         f"(what this project currently uses)")
    else:
        lines.append("\n  No order on the grid achieved stationarity.")
    return "\n".join(lines)
