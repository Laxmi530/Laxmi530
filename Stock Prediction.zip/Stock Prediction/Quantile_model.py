import pandas as pd
import numpy as np
import lightgbm as lgb
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

from model_utils import normalize_interval, generate_future_dates
from ML_model import create_features
from direct_forecast import (
    horizon_feature_cols, make_horizon_targets, training_frame,
    compute_origin_row,
)

_QUANTILES = [0.025, 0.5, 0.975]


# ==========================================
# 1. Build Quantile LightGBM Models
# ==========================================
def _build_quantile_lgb(alpha):
    """
    Create a LightGBM regressor configured for quantile loss.

    Parameters
    ----------
    alpha : float
        Target quantile in (0, 1). For example 0.5 gives the median,
        0.025 gives the 2.5th percentile (lower bound of 95 % CI).

    Returns
    -------
    lgb.LGBMRegressor
        Configured but unfitted LightGBM model.
    """
    return lgb.LGBMRegressor(
        objective='quantile',
        alpha=alpha,
        n_estimators=1200,
        learning_rate=0.03,
        num_leaves=31,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        min_child_samples=20,
        n_jobs=-1,
        random_state=42,
        verbose=-1,
    )


# ==========================================
# 2. Train Three Quantile Models
# ==========================================
def train_quantile_models(features_df, target_col, test_size=0.1):
    """
    Train three LightGBM models for the 2.5th, 50th, and 97.5th quantiles.

    Each model independently optimises quantile loss (pinball loss) for
    its target percentile.  A temporal train/test split avoids look-ahead
    bias, and early stopping prevents overfitting.

    Parameters
    ----------
    features_df : pd.DataFrame
        Engineered features DataFrame (datetime-indexed) with a target
        column and raw OHLCV columns.
    target_col : str
        Name of the target column (e.g., 'target_log_return').
    test_size : float, optional
        Fraction of data for temporal validation. Default 0.1.

    Returns
    -------
    models : dict
        Mapping of quantile float -> fitted LGBMRegressor.
    feature_cols : list of str
        Ordered list of feature column names used during training.
    """
    raw_cols = {'open', 'high', 'low', 'close', 'adj_close', 'volume'}
    feature_cols = [
        c for c in features_df.columns
        if c != target_col and c not in raw_cols
    ]

    X = features_df[feature_cols]
    y = features_df[target_col]

    split_idx = int(len(X) * (1 - test_size))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

    models = {}

    for q in _QUANTILES:
        label = f"Q{q:.3f}"
        print(f"Training LightGBM {label}...")

        model = _build_quantile_lgb(q)
        callbacks = [
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(0),
        ]
        model.fit(
            X_train, y_train,
            eval_set=[(X_test, y_test)],
            eval_metric='quantile',
            callbacks=callbacks,
        )
        models[q] = model

    print(f"Quantile training complete (features: {len(feature_cols)})")
    return models, feature_cols


# ==========================================
# 3. Main Orchestrator (Direct Multi-Horizon)
# ==========================================
def run_quantile_prediction(df, interval, horizon):
    """
    Main function to run quantile forecasting with LightGBM.

    Uses **direct multi-horizon** forecasting: for each step ``h`` three
    LightGBM models target the 2.5th / 50th / 97.5th quantiles of the
    *cumulative* log return ``log(P[t+h]/P[t])``, forecast directly from the
    observed features at the last bar. This yields native probabilistic
    intervals whose width grows naturally with horizon, and avoids the
    recursive error accumulation (and one-bar origin offset) of the previous
    step-by-step scheme.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with datetime, OHLCV columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps.

    Returns
    -------
    pd.DataFrame
        Columns: ['datetime', 'predicted_price', 'lower_bound',
        'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Quantile Prediction ({interval}) ---")

    df = df.copy()
    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.iloc[-max_obs:]

    features_df = create_features(df, interval)
    feature_cols = horizon_feature_cols(features_df)
    targets = make_horizon_targets(features_df, horizon)

    origin_X, last_price, last_date = compute_origin_row(
        df, feature_cols, interval,
    )
    future_dates = generate_future_dates(last_date, horizon, interval)

    print(f"Training {horizon} direct quantile horizon models...")

    rows = []
    for i, h in enumerate(range(1, horizon + 1)):
        target_name = f'target_h{h}'
        train_df = training_frame(
            features_df, feature_cols, targets[h], target_name,
        )
        models, _ = train_quantile_models(train_df, target_name)

        # Direct cumulative-return quantiles, sorted to prevent crossing.
        prices = sorted(
            float(last_price * np.exp(models[q].predict(origin_X)[0]))
            for q in _QUANTILES
        )
        lower_price, median_price, upper_price = prices
        vol = (upper_price - lower_price) / (2 * 1.96)

        rows.append({
            'datetime': future_dates[i],
            'predicted_price': float(median_price),
            'lower_bound': float(lower_price),
            'upper_bound': float(upper_price),
            'volatility': float(vol),
        })

    print("Quantile Prediction Complete.")
    return pd.DataFrame(rows)
