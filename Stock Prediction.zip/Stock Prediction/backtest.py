"""
Walk-forward backtesting and evaluation for the stock-prediction models.

For near-random-walk series like daily/hourly stock prices, a forecast is only
meaningful if it beats the **naive random-walk baseline** (tomorrow = today) on
out-of-sample data. This module provides:

- error / skill metrics (RMSE, MAE, SMAPE, MASE, directional accuracy) and
  interval-coverage for models that emit confidence bands,
- a model-agnostic walk-forward backtest that repeatedly re-fits at successive
  origins and compares each forecast to the realised prices and to the naive
  baseline,
- an **economic** evaluation of the same forecasts (Sharpe / Sortino / max
  drawdown / information coefficient, net of transaction costs) via
  ``strategy_metrics``, because a good RMSE and a profitable forecast are not
  the same claim.

Any of the project's ``run_*`` orchestrators can be passed as ``predict_fn``,
since they all share the signature ``fn(df, interval, horizon) -> DataFrame``
with a ``predicted_price`` column.

The module deliberately depends only on numpy / pandas so importing it is cheap
and it never pulls a modelling backend into memory; the model is injected by
the caller.
"""

import numpy as np
import pandas as pd


# ==========================================
# Metrics
# ==========================================
def rmse(actual, pred):
    """Root mean squared error."""
    actual = np.asarray(actual, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    return float(np.sqrt(np.mean((actual - pred) ** 2)))


def mae(actual, pred):
    """Mean absolute error."""
    actual = np.asarray(actual, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    return float(np.mean(np.abs(actual - pred)))


def smape(actual, pred):
    """
    Symmetric mean absolute percentage error (in percent, 0-200).

    Uses the symmetric denominator (|a| + |p|) / 2 and guards against a zero
    denominator, so it is bounded and well-defined even near zero prices.
    """
    actual = np.asarray(actual, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    denom = (np.abs(actual) + np.abs(pred)) / 2.0
    denom = np.where(denom == 0, 1e-10, denom)
    return float(np.mean(np.abs(actual - pred) / denom) * 100.0)


def mase(actual, pred, train_series, m=1):
    """
    Mean Absolute Scaled Error.

    Scales the forecast MAE by the in-sample MAE of a naive lag-``m`` forecast
    on the training series. MASE < 1 means the model beats the naive random
    walk; MASE >= 1 means it does not. This is the key skill metric for stock
    forecasts, where the random walk is a strong baseline.

    Parameters
    ----------
    actual, pred : array-like
        Realised and predicted values over the forecast horizon.
    train_series : array-like
        The in-sample series used to compute the naive scaling factor.
    m : int, optional
        Seasonal lag for the naive baseline. Default 1 (non-seasonal).

    Returns
    -------
    float
        MASE, or NaN if the naive in-sample error is zero.
    """
    actual = np.asarray(actual, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    train_series = np.asarray(train_series, dtype=np.float64)

    if len(train_series) <= m:
        return float('nan')
    naive_mae = np.mean(np.abs(np.diff(train_series, n=m)))
    if naive_mae == 0:
        return float('nan')
    return float(np.mean(np.abs(actual - pred)) / naive_mae)


def directional_accuracy(actual, pred, anchor):
    """
    Fraction of steps whose predicted direction matches the realised direction.

    Both the actual and predicted paths are anchored on the last observed price
    so the first step's direction is well-defined. Returns a value in [0, 1];
    ~0.5 is chance level for a binary up/down call.

    Parameters
    ----------
    actual, pred : array-like
        Realised and predicted price paths over the horizon.
    anchor : float
        Last observed price immediately before the forecast.

    Returns
    -------
    float
        Directional hit rate, or NaN if the horizon is empty.
    """
    actual = np.asarray(actual, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    if len(actual) == 0:
        return float('nan')
    actual_dir = np.sign(np.diff(np.concatenate([[anchor], actual])))
    pred_dir = np.sign(np.diff(np.concatenate([[anchor], pred])))
    return float(np.mean(actual_dir == pred_dir))


def interval_coverage(actual, lower, upper):
    """
    Fraction of realised values that fall within [lower, upper].

    For a well-calibrated 95% interval this should be ~0.95. Much lower means
    the model is overconfident; much higher means the bands are too wide.
    """
    actual = np.asarray(actual, dtype=np.float64)
    lower = np.asarray(lower, dtype=np.float64)
    upper = np.asarray(upper, dtype=np.float64)
    return float(np.mean((actual >= lower) & (actual <= upper)))


# ==========================================
# Baseline
# ==========================================
def naive_forecast(anchor, horizon):
    """
    Random-walk baseline: repeat the last observed price across the horizon.

    Parameters
    ----------
    anchor : float
        Last observed price.
    horizon : int
        Number of steps to forecast.

    Returns
    -------
    np.ndarray
        Array of length ``horizon`` filled with ``anchor``.
    """
    return np.repeat(float(anchor), horizon)


def drift_forecast(train_prices, horizon):
    """
    Random-walk-with-drift baseline: extrapolate the mean historical log return.

    A slightly stronger benchmark than the pure random walk — it gives the model
    credit only if it beats the trivial "prices keep drifting at their average
    past rate" rule. ``price[t+h] = last * exp(mean_log_return * h)``.

    Parameters
    ----------
    train_prices : array-like
        In-sample price series up to the forecast origin.
    horizon : int
        Number of steps to forecast.

    Returns
    -------
    np.ndarray
        Drift forecast of length ``horizon``.
    """
    p = np.asarray(train_prices, dtype=np.float64)
    p = p[p > 0]
    if len(p) < 2:
        return naive_forecast(p[-1] if len(p) else 1.0, horizon)
    mu = float(np.mean(np.diff(np.log(p))))
    return float(p[-1]) * np.exp(mu * np.arange(1, horizon + 1))


def ar1_forecast(train_prices, horizon):
    """
    AR(1)-on-log-returns baseline.

    Fits a first-order autoregression ``r_t = c + phi * r_{t-1}`` to the
    in-sample log returns by OLS and rolls it forward, compounding the predicted
    returns onto the last price. Captures any short-horizon return
    autocorrelation a model should be able to exploit, so beating it is a
    stronger claim than beating the random walk.

    Parameters
    ----------
    train_prices : array-like
        In-sample price series up to the forecast origin.
    horizon : int
        Number of steps to forecast.

    Returns
    -------
    np.ndarray
        AR(1) forecast of length ``horizon``.
    """
    p = np.asarray(train_prices, dtype=np.float64)
    p = p[p > 0]
    lr = np.diff(np.log(p)) if len(p) > 1 else np.array([])
    if len(lr) < 10:
        return naive_forecast(p[-1] if len(p) else 1.0, horizon)
    y, x = lr[1:], lr[:-1]
    a = np.vstack([np.ones_like(x), x]).T
    c, phi = np.linalg.lstsq(a, y, rcond=None)[0]
    price, r = float(p[-1]), float(lr[-1])
    out = []
    for _ in range(horizon):
        r = c + phi * r
        price = price * np.exp(r)
        out.append(price)
    return np.asarray(out, dtype=np.float64)


# Baselines evaluated alongside the model at every origin. The naive random
# walk is the primary benchmark (and the one the DM test uses); drift and AR(1)
# are progressively stronger reference points.
BASELINES = {
    'naive': lambda train_prices, anchor, h: naive_forecast(anchor, h),
    'drift': lambda train_prices, anchor, h: drift_forecast(train_prices, h),
    'ar1': lambda train_prices, anchor, h: ar1_forecast(train_prices, h),
}


# ==========================================
# Diebold-Mariano test
# ==========================================
def diebold_mariano(errors_a, errors_b, h=1, loss='squared'):
    """
    Diebold-Mariano test of equal predictive accuracy of forecasts A vs B.

    RMSE deltas on near-random-walk returns are often inside the noise band, so
    "model RMSE < naive RMSE" on a handful of origins may be luck. The DM test
    asks whether the **loss differential** ``loss(A) - loss(B)`` is significantly
    different from zero, using a HAC (Newey-West) long-run variance with ``h-1``
    lags to account for the autocorrelation that overlapping multi-step
    forecasts induce, plus the Harvey-Leybourne-Newbold small-sample correction.

    **Bartlett-weighted HAC.** The autocovariance terms carry Bartlett weights
    ``1 - k/h``. An earlier version summed them unweighted (a truncated, or
    rectangular, kernel), which is *not* guaranteed positive semi-definite: on
    short samples the long-run variance could come out negative, and the
    function then returned NaN rather than a p-value. That is a correct guard
    but a real loss of power - a test that silently declines to run is a test
    that never rejects. Bartlett weights are PSD by construction, so the
    variance cannot go negative and the comparison always resolves.

    Two consequences worth stating: ``h = 1`` is **unaffected** (the lag loop
    does not execute), and for ``h > 1`` the variance is generally *smaller*
    than the unweighted version, so p-values shift. README section 37 records
    the before/after for every published figure.

    Sign convention: with A = model and B = baseline, a **negative** statistic
    means the model has the lower average loss (is better); the p-value is
    two-sided.

    Parameters
    ----------
    errors_a, errors_b : array-like
        Aligned forecast errors (actual - predicted) for A and B.
    h : int, optional
        Forecast horizon; sets the HAC lag (h-1). Default 1.
    loss : {'squared', 'absolute'}, optional
        Loss function applied to the errors. Default 'squared'.

    Returns
    -------
    dict
        {'stat': HLN-corrected DM statistic, 'p_value': two-sided p-value,
         'n': number of paired points, 'favors': 'model'|'baseline'|None}.
    """
    ea = np.asarray(errors_a, dtype=np.float64)
    eb = np.asarray(errors_b, dtype=np.float64)
    n = len(ea)
    nan_result = {'stat': float('nan'), 'p_value': float('nan'),
                  'n': n, 'favors': None}
    if n < 3 or len(eb) != n:
        return nan_result

    d = (np.abs(ea) - np.abs(eb)) if loss == 'absolute' else (ea ** 2 - eb ** 2)
    dbar = float(np.mean(d))
    d0 = d - dbar

    # Long-run variance of the mean, Newey-West with BARTLETT weights:
    #     gamma_0 + 2 * sum_{k=1}^{h-1} (1 - k/h) * gamma_k
    # The weight is what makes the estimator positive semi-definite. Summing the
    # autocovariances unweighted (a rectangular kernel) can produce a negative
    # variance on short samples, which forces a NaN and costs the test outright.
    var = float(np.mean(d0 * d0))
    lag_max = int(h) - 1
    for k in range(1, lag_max + 1):
        if k < n:
            w = 1.0 - k / (lag_max + 1.0)          # Bartlett
            var += 2.0 * w * float(np.mean(d0[k:] * d0[:-k]))
    var /= n
    if not np.isfinite(var) or var <= 0:
        # With Bartlett weights this is now essentially unreachable (it needs a
        # degenerate, zero-variance loss differential), but the guard stays:
        # returning NaN beats returning a p-value from a bad variance.
        return nan_result

    dm = dbar / np.sqrt(var)
    # Harvey-Leybourne-Newbold small-sample correction.
    corr = (n + 1 - 2 * h + h * (h - 1) / n) / n
    dm_adj = dm * np.sqrt(max(corr, 1e-8))

    try:
        from scipy.stats import t
        p = float(2 * t.cdf(-abs(dm_adj), df=n - 1))
    except Exception:
        from math import erfc, sqrt
        p = float(erfc(abs(dm_adj) / sqrt(2)))  # normal approximation

    favors = None
    if p < 0.05:
        favors = 'model' if dm_adj < 0 else 'baseline'
    return {'stat': float(dm_adj), 'p_value': p, 'n': n, 'favors': favors}


# ==========================================
# Confidence bucket (shared skill -> label rule)
# ==========================================
def confidence_bucket(improvement, dm_pvalue, coverage):
    """
    Classify forecast reliability from walk-forward skill vs. baselines.

    Encodes the project's own finding — most point-forecast "wins" are within
    noise — into an explicit, honest label rather than hiding it. The rule
    blends three signals: RMSE improvement over the best naive baseline, the
    Diebold-Mariano p-value (is that edge statistically real?), and interval
    coverage (are the bands trustworthy?).

    This is the single source of truth for the label used in both the live UI
    confidence gate and the offline calibration/gate-validation harness, so the
    validation measures exactly the rule the app ships.

    Parameters
    ----------
    improvement : float
        ``(best_baseline_rmse - model_rmse) / best_baseline_rmse``.
    dm_pvalue : float
        Two-sided Diebold-Mariano p-value vs. the naive walk (NaN if absent).
    coverage : float
        Empirical 95%-interval coverage (NaN for models without intervals).

    Returns
    -------
    str
        'High', 'Medium', 'Low', or 'No edge'.
    """
    cov_ok = np.isnan(coverage) or (0.85 <= coverage <= 0.99)
    sig = (not np.isnan(dm_pvalue)) and dm_pvalue < 0.10
    weak_sig = (not np.isnan(dm_pvalue)) and dm_pvalue < 0.20
    if improvement > 0.05 and sig and cov_ok:
        return 'High'
    if improvement > 0.02 and weak_sig:
        return 'Medium'
    if improvement > 0:
        return 'Low'
    return 'No edge'


# ==========================================
# Single-forecast evaluation
# ==========================================
def evaluate_forecast(actual, pred, train_series, anchor,
                      lower=None, upper=None):
    """
    Compute the full metric set for one forecast against realised prices.

    Parameters
    ----------
    actual : array-like
        Realised prices over the horizon.
    pred : array-like
        Predicted prices over the horizon.
    train_series : array-like
        In-sample prices (for the MASE scaling factor).
    anchor : float
        Last observed price before the forecast (for directional accuracy).
    lower, upper : array-like, optional
        Confidence-band bounds; if both given, coverage is included.

    Returns
    -------
    dict
        Metric name -> value.
    """
    metrics = {
        'rmse': rmse(actual, pred),
        'mae': mae(actual, pred),
        'smape': smape(actual, pred),
        'mase': mase(actual, pred, train_series),
        'directional_accuracy': directional_accuracy(actual, pred, anchor),
    }
    if lower is not None and upper is not None:
        metrics['coverage'] = interval_coverage(actual, lower, upper)
    return metrics


# ==========================================
# Walk-forward backtest
# ==========================================
def walk_forward_backtest(df, predict_fn, interval, horizon,
                          n_splits=5, min_train=250, predict_kwargs=None,
                          model_name='model', verbose=True,
                          strategy=True, cost_bps=None, position_mode='sign'):
    """
    Walk-forward (rolling-origin) backtest of a forecasting function.

    At each of ``n_splits`` origins (spread between ``min_train`` and the last
    point that still leaves ``horizon`` future observations), the model is
    re-fit on data up to the origin and asked to forecast the next ``horizon``
    steps. Forecasts are compared positionally to the realised prices and to
    the naive random-walk baseline.

    Because each model generates its own future trading calendar, comparison is
    positional (forecast step k vs the k-th realised observation after the
    origin) rather than by timestamp.

    Parameters
    ----------
    df : pd.DataFrame
        Full history with 'datetime' and 'adj_close' columns.
    predict_fn : callable
        ``fn(train_df, interval, horizon, **predict_kwargs)`` returning a
        DataFrame with a 'predicted_price' column (and optionally
        'lower_bound' / 'upper_bound').
    interval : str
        Passed through to ``predict_fn`` ('1d' / 'daily' / '1h' / 'hourly').
    horizon : int
        Forecast horizon (steps) evaluated at each origin.
    n_splits : int, optional
        Number of walk-forward origins. Default 5.
    min_train : int, optional
        Minimum training observations before the first origin. Default 250.
    predict_kwargs : dict, optional
        Extra keyword arguments forwarded to ``predict_fn`` (e.g.
        ``{'model_type': 'lightgbm'}``).
    model_name : str, optional
        Label used in the returned summary.
    verbose : bool, optional
        Print per-split progress. Default True.
    strategy : bool, optional
        Also score the forecasts **economically** (Sharpe / Sortino / drawdown /
        information coefficient, net of costs) by treating each origin's
        horizon-end forecast as a trade signal. Default True; set False to skip
        (it costs nothing extra to compute — it reuses the same forecasts).
    cost_bps : float, optional
        One-way transaction cost in basis points for the strategy evaluation.
        Defaults to ``strategy_metrics.DEFAULT_COST_BPS`` (10 bps).
    position_mode : str, optional
        Position rule for the strategy evaluation ('sign' / 'deadband' /
        'scaled'); see ``strategy_metrics.position_from_signal``. Default 'sign'.

    Returns
    -------
    dict
        {
          'summary'    : pd.DataFrame indexed by metric with 'model' and
                         'naive' mean columns,
          'per_split'  : pd.DataFrame of per-origin model metrics,
          'origins'    : list of integer origin indices used,
          'dm'         : Diebold-Mariano result vs the naive walk,
          'signals'    : pd.DataFrame of per-origin (predicted, realised)
                         horizon-end log returns — the strategy input,
          'strategy'   : dict from ``strategy_metrics.evaluate_strategy``
                         (absent when ``strategy=False`` or too few origins),
        }

    Raises
    ------
    ValueError
        If the data is too short to form even one (min_train, horizon) split.
    """
    predict_kwargs = predict_kwargs or {}

    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.sort_values('datetime').reset_index(drop=True)
    df['adj_close'] = pd.to_numeric(df['adj_close'], errors='coerce')

    prices = df['adj_close'].values.astype(np.float64)
    n = len(df)

    max_origin = n - horizon
    if max_origin <= min_train:
        raise ValueError(
            f"Not enough data for a walk-forward backtest: need > "
            f"{min_train + horizon} rows, have {n}."
        )

    origins = np.unique(
        np.linspace(min_train, max_origin, n_splits, dtype=int)
    )

    model_rows = []
    baseline_rows = {name: [] for name in BASELINES}
    used_origins = []
    # Per-point errors (actual - pred) pooled across origins for the DM test.
    model_err_chunks = []
    naive_err_chunks = []
    # Per-origin horizon-end (predicted, realised) log returns — the trade signal
    # the economic evaluation below acts on.
    signal_rows = []

    for origin in origins:
        train_df = df.iloc[:origin]
        train_prices = prices[:origin]
        anchor = prices[origin - 1]
        actual = prices[origin:origin + horizon]

        try:
            fc = predict_fn(train_df, interval, horizon, **predict_kwargs)
        except Exception as exc:
            if verbose:
                print(f"  [{model_name}] origin={origin} FAILED: {exc}")
            continue

        if fc is None or 'predicted_price' not in getattr(fc, 'columns', []):
            if verbose:
                print(f"  [{model_name}] origin={origin}: no predicted_price")
            continue

        pred = np.asarray(fc['predicted_price'].values[:horizon], dtype=np.float64)
        if len(pred) < horizon:
            if verbose:
                print(f"  [{model_name}] origin={origin}: short forecast")
            continue

        lower = fc['lower_bound'].values[:horizon] if 'lower_bound' in fc.columns else None
        upper = fc['upper_bound'].values[:horizon] if 'upper_bound' in fc.columns else None

        m = evaluate_forecast(actual, pred, train_prices, anchor, lower, upper)
        m['origin'] = int(origin)
        model_rows.append(m)
        used_origins.append(int(origin))

        # Evaluate every baseline at this origin.
        baseline_preds = {}
        for name, fn in BASELINES.items():
            bpred = np.asarray(fn(train_prices, anchor, horizon), dtype=np.float64)
            baseline_preds[name] = bpred
            baseline_rows[name].append(
                evaluate_forecast(actual, bpred, train_prices, anchor)
            )

        model_err_chunks.append(actual - pred)
        naive_err_chunks.append(actual - baseline_preds['naive'])

        # Horizon-end cumulative log returns: what the model claimed the total
        # move to step `horizon` would be, and what it actually was. Anchored on
        # the last observed price so both are measured from the same origin.
        if anchor > 0 and pred[-1] > 0 and actual[-1] > 0:
            signal_rows.append({
                'origin': int(origin),
                'datetime': df['datetime'].iloc[origin - 1],
                'anchor': float(anchor),
                'pred_return': float(np.log(pred[-1] / anchor)),
                'real_return': float(np.log(actual[-1] / anchor)),
            })

        if verbose:
            print(
                f"  [{model_name}] origin={origin}: "
                f"MASE={m['mase']:.3f} (naive=1.000), "
                f"dir_acc={m['directional_accuracy']:.2f}, "
                f"RMSE={m['rmse']:.3f}"
            )

    if not model_rows:
        raise ValueError(
            f"All {len(origins)} backtest splits failed for '{model_name}'."
        )

    per_split = pd.DataFrame(model_rows)
    metric_cols = [c for c in per_split.columns if c != 'origin']
    point_cols = [c for c in metric_cols if c != 'coverage']

    summary_cols = {'model': per_split[metric_cols].mean()}
    for name, rows in baseline_rows.items():
        if rows:
            summary_cols[name] = pd.DataFrame(rows)[point_cols].mean()
    summary = pd.DataFrame(summary_cols)

    # Diebold-Mariano test of the model vs the naive random walk.
    dm = diebold_mariano(
        np.concatenate(model_err_chunks),
        np.concatenate(naive_err_chunks),
        h=horizon,
    )

    result = {
        'summary': summary,
        'per_split': per_split,
        'origins': used_origins,
        'dm': dm,
        'signals': pd.DataFrame(signal_rows),
    }

    # ── Economic evaluation (book Ch. 3: "Evaluating investment strategy") ──
    # Same forecasts, different question: acting on them, what would the Sharpe,
    # Sortino, drawdown and information coefficient have been *after costs*?
    if strategy and len(signal_rows) >= 3:
        import strategy_metrics as sm

        sig = pd.DataFrame(signal_rows)
        # Origins from `np.linspace` are evenly spaced; if that spacing is
        # shorter than the horizon the "trades" overlap, so the return stream is
        # serially dependent and the Sharpe is optimistic. Flag it rather than
        # silently reporting a prettier number.
        spacing = (int(np.min(np.diff(used_origins)))
                   if len(used_origins) > 1 else horizon)
        overlapping = spacing < horizon

        strat = sm.evaluate_strategy(
            sig['pred_return'].values,
            sig['real_return'].values,
            interval='hourly' if str(interval).lower() in ('1h', 'hourly', '1 hour')
                     else 'daily',
            cost_bps=(sm.DEFAULT_COST_BPS if cost_bps is None else float(cost_bps)),
            mode=position_mode,
            dates=sig['datetime'].values,
            periods_per_bar=horizon,
        )
        strat['origin_spacing'] = int(spacing)
        strat['overlapping_origins'] = bool(overlapping)
        if overlapping:
            strat['caveat'] = (
                f"origins are {spacing} bars apart but the horizon is {horizon} "
                "bars, so the trade returns overlap — risk-adjusted figures are "
                "optimistic (use n_splits small enough that spacing >= horizon)")
        result['strategy'] = strat

    return result


def print_backtest_summary(result, model_name='model'):
    """
    Pretty-print a walk-forward backtest result with a skill verdict.

    Parameters
    ----------
    result : dict
        Output of ``walk_forward_backtest``.
    model_name : str, optional
        Label for the printed header.
    """
    summary = result['summary']
    print(f"\n=== Walk-forward backtest: {model_name} "
          f"({len(result['origins'])} splits) ===")
    print(summary.to_string(float_format=lambda v: f"{v:.4f}"))

    if 'mase' in summary.index:
        model_mase = summary.loc['mase', 'model']
        verdict = "BEATS naive random walk" if model_mase < 1 else \
                  "does NOT beat naive random walk"
        print(f"\nMASE = {model_mase:.3f}  ->  {model_name} {verdict}.")
    if 'directional_accuracy' in summary.index:
        da = summary.loc['directional_accuracy', 'model']
        print(f"Directional accuracy = {da:.2%} "
              f"({'better' if da > 0.5 else 'no better'} than chance).")
    if 'coverage' in summary.index and not np.isnan(summary.loc['coverage', 'model']):
        print(f"Interval coverage = {summary.loc['coverage', 'model']:.2%} "
              f"(target ~95%).")

    # RMSE vs each baseline (richer reference than the naive walk alone).
    if 'rmse' in summary.index:
        extra = [c for c in ('naive', 'drift', 'ar1') if c in summary.columns]
        if extra:
            ref = "  ".join(
                f"{c}={summary.loc['rmse', c]:.3f}" for c in extra
            )
            print(f"RMSE: model={summary.loc['rmse', 'model']:.3f}  ({ref})")

    # Diebold-Mariano significance verdict.
    dm = result.get('dm')
    if dm and not np.isnan(dm.get('stat', float('nan'))):
        if dm['favors'] == 'model':
            tail = "model is significantly MORE accurate than naive (p<0.05)"
        elif dm['favors'] == 'baseline':
            tail = "model is significantly LESS accurate than naive (p<0.05)"
        else:
            tail = "difference from naive is NOT statistically significant"
        print(f"Diebold-Mariano: stat={dm['stat']:.3f}, p={dm['p_value']:.3f} "
              f"(n={dm['n']})  ->  {tail}.")

    # Economic verdict: statistical accuracy and profitability are different
    # claims, so print both rather than letting RMSE stand in for value.
    strat = result.get('strategy')
    if strat:
        import strategy_metrics as sm
        print()
        print(sm.format_strategy_report(strat, model_name))
        if strat.get('caveat'):
            print(f"  NOTE: {strat['caveat']}")
