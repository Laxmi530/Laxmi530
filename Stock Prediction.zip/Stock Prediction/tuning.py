"""
Hyperparameter search: grid, random, and Bayesian (TPE) — **nested by construction**.

Motivated by *Hands-On Deep Learning for Finance* (Troiano et al.), Chapter 3,
"Tuning the model" (pp. 128-135), which covers grid search, random search — noting
that random beats grid at equal budget because a regular lattice keeps re-testing
irrelevant factors along its axes — and Bayesian optimisation (SMBO/TPE), which
directs the search with a surrogate model instead of treating each trial as
independent.

The gap this fills
------------------
Every model in this repository carries **hardcoded** hyperparameters: XGBoost's
``max_depth=5, learning_rate=0.03``, the LSTM's ``64/64/32``, Vol-LSTM's
``48/24``, N-BEATS' capacity (itself reduced by hand after it overfit). Not one
was chosen by a search. That is a real gap — but it is a gap that has to be
closed *carefully*, because in this particular project a naive search is worse
than no search at all.

Why a naive search would be actively harmful here
-------------------------------------------------
The project's own verdict is that **no model has a data-snooping-robust edge**
(White's Reality Check p = 0.90, Hansen's SPA p = 0.87). Against that backdrop:

* A search over ``N`` configurations evaluated on the *same* walk-forward origins
  you later report is an efficient machine for manufacturing exactly the
  snooped edge ``run_spa.py`` exists to detect. Trying 50 configurations and
  keeping the best is 50 more chances for noise to look like skill.
* Hyperparameter tuning improves **fit**, and fit is not the binding constraint
  on a near-random-walk series — sample size and signal are.

So this module is built with two hard structural guards, not optional ones:

1. **Nested evaluation is mandatory** (:func:`nested_search`). The search sees
   only a *training prefix* of the history; the held-out tail is never touched
   during the search and is scored once, afterwards. This is the same structure
   ``calibration.validate_gate`` uses for the confidence gate, and it is the only
   way the reported number means anything.
2. **Every result carries its own selection-bias warning** — the number of
   configurations tried, and an explicit reminder that the winner must go
   through ``run_spa.py`` before any improvement is believed. A search result is
   a *hypothesis*, not a finding.

Where it is most likely to genuinely pay
----------------------------------------
Not on the price models. The honest expectation there is a better-fitting model
with the same (absent) predictive edge. The promising target is the **volatility**
side — HAR-RV's and Vol-LSTM's window lengths, which were picked by convention
(1/5/22, a 60-bar look-back) rather than measured. Volatility *is* forecastable,
so a search there is optimising something that exists. :func:`suggest_spaces`
encodes that opinion.

Pure numpy/pandas plus whatever the objective needs; no new dependencies (the
TPE implementation is ~40 lines and replaces the book's ``hyperopt`` import).
"""

import itertools
import math

import numpy as np
import pandas as pd

_EPS = 1e-12


# ==========================================
# Search spaces
# ==========================================
def suggest_spaces():
    """
    Opinionated default search spaces, ordered by how likely they are to pay.

    Deliberately small. A large space on ~1000 rows is not thoroughness, it is
    more chances for noise to win — and the whole point of the guards in this
    module is that the number of configurations tried is a cost, not a feature.

    Returns
    -------
    dict[str, dict]
        Named spaces, each mapping parameter name -> list of candidate values.
        ``vol_lstm`` and ``har_rv`` are listed first because volatility is the
        one quantity this project has evidence is forecastable; the tree/NN
        spaces are provided for completeness and are expected to change fit
        without changing skill.
    """
    return {
        # --- Most promising: the second moment, where signal demonstrably exists.
        'har_rv': {
            # (short, medium, long) memory in bars. The canonical (1, 5, 22) is
            # a convention from daily equity data, never measured on NSE names.
            'lags': [(1, 5, 22), (1, 5, 15), (1, 10, 22), (1, 3, 10), (1, 7, 30)],
            'aci_gamma': [0.02, 0.05, 0.10],
        },
        'vol_lstm': {
            'look_back': [30, 45, 60, 90],
            'units': [(32, 16), (48, 24), (64, 32)],
            'dropout': [0.1, 0.2, 0.3],
            'aci_gamma': [0.02, 0.05, 0.10],
        },
        # --- Provided for completeness; expect fit gains, not skill gains.
        'xgboost': {
            'max_depth': [3, 4, 5, 6],
            'learning_rate': [0.01, 0.03, 0.06],
            'min_child_weight': [3, 5, 10],
            'subsample': [0.7, 0.8, 0.9],
        },
        'lstm': {
            'look_back': [45, 60, 90],
            'units': [(32, 32, 16), (64, 64, 32), (96, 64, 32)],
            'dropout': [0.2, 0.3, 0.4],
        },
    }


def space_size(space):
    """Total number of configurations in a grid (the cost of an exhaustive run)."""
    n = 1
    for v in space.values():
        n *= max(len(v), 1)
    return n


# ==========================================
# Samplers (book Ch. 3)
# ==========================================
def grid_configs(space):
    """
    Every combination in the grid, in deterministic order.

    Exhaustive and reproducible, but the book's own caution applies: a regular
    lattice spends its budget re-testing values of parameters that turn out not
    to matter, because every irrelevant axis multiplies the cost of exploring the
    relevant ones. Prefer :func:`random_configs` beyond ~4 parameters.
    """
    keys = list(space)
    return [dict(zip(keys, combo))
            for combo in itertools.product(*(space[k] for k in keys))]


def random_configs(space, n_iter, seed=0):
    """
    ``n_iter`` configurations sampled uniformly at random (with replacement).

    Bergstra & Bengio's result, which the book restates: at an equal budget,
    random search finds better models than grid search. The reason is that real
    objectives depend strongly on a *few* hyperparameters, and random sampling
    gives each important axis ``n_iter`` distinct values instead of the handful a
    lattice allows once it has been multiplied out across unimportant axes.
    """
    rng = np.random.default_rng(seed)
    keys = list(space)
    out = []
    for _ in range(int(n_iter)):
        out.append({k: space[k][int(rng.integers(len(space[k])))] for k in keys})
    return out


def _key(cfg):
    """Hashable identity of a configuration, for duplicate suppression."""
    return tuple(sorted((k, str(v)) for k, v in cfg.items()))


def _tpe_suggest(space, history, rng, gamma=0.25, n_candidates=24,
                 seen=None):
    """
    One Tree-structured Parzen Estimator proposal (the book's ``tpe.suggest``).

    TPE is the practical form of Bayesian optimisation for discrete spaces, and
    it needs no Gaussian-process library — which is why it is implemented here in
    a few dozen lines rather than pulled in as a dependency.

    The idea: split the trials seen so far into a **good** set (the best ``gamma``
    fraction of scores) and a **bad** set (the rest), then model
    ``p(param | good)`` and ``p(param | bad)`` independently per parameter. For a
    categorical/discrete axis those are just smoothed histograms. Sampling
    candidates from the good distribution and picking the one maximising the
    ratio ``l(x)/g(x)`` is equivalent to maximising Expected Improvement, so the
    search is *directed* by what it has learned rather than starting from scratch
    each trial — the specific weakness of grid and random search the book calls
    out.

    Laplace smoothing (the ``+1``) keeps a value that happened to appear only in
    the bad set from being ruled out permanently after a handful of trials.

    **Duplicate suppression is load-bearing on a discrete space.** Taking the
    deterministic argmax of the ratio over sampled candidates makes TPE collapse:
    once a configuration looks best it is proposed again and again, and the
    remaining budget is spent re-evaluating it. Measured on a 10x10 space, TPE
    burned 12 of 30 trials on a single point and finished *worse than random
    search*. Candidates already evaluated are therefore skipped, with a random
    unseen fallback when every candidate has been seen — which restores the
    exploration a continuous-space TPE gets for free.
    """
    seen = seen or set()
    keys = list(space)
    scores = np.array([h['score'] for h in history], dtype=float)
    order = np.argsort(-scores)                      # higher score = better
    n_good = max(1, int(math.ceil(gamma * len(history))))
    good = [history[i]['config'] for i in order[:n_good]]
    bad = [history[i]['config'] for i in order[n_good:]] or good

    def _probs(pool, k):
        vals = space[k]
        counts = np.array([sum(1 for c in pool if c[k] == v) for v in vals],
                          dtype=float) + 1.0        # Laplace smoothing
        return counts / counts.sum()

    l_probs = {k: _probs(good, k) for k in keys}
    g_probs = {k: _probs(bad, k) for k in keys}

    best_cfg, best_ratio, fallback = None, -np.inf, None
    for _ in range(n_candidates):
        cfg, log_ratio = {}, 0.0
        for k in keys:
            i = int(rng.choice(len(space[k]), p=l_probs[k]))
            cfg[k] = space[k][i]
            log_ratio += math.log(l_probs[k][i] + _EPS) - math.log(g_probs[k][i] + _EPS)
        fallback = fallback or cfg
        if _key(cfg) in seen:
            continue                       # already evaluated - no information
        if log_ratio > best_ratio:
            best_cfg, best_ratio = cfg, log_ratio

    if best_cfg is not None:
        return best_cfg
    # Every candidate was already tried: take a random unseen point so the
    # remaining budget still buys information.
    for _ in range(50):
        cfg = {k: space[k][int(rng.integers(len(space[k])))] for k in keys}
        if _key(cfg) not in seen:
            return cfg
    return fallback


# ==========================================
# The search driver
# ==========================================
def search(objective, space, method='random', n_iter=20, seed=0,
           n_startup=6, verbose=True):
    """
    Run a hyperparameter search and return the ranked trial history.

    Parameters
    ----------
    objective : callable
        ``objective(config) -> float``, **higher is better**. Must be evaluated on
        data the final report will NOT reuse — see :func:`nested_search`, which
        enforces that rather than trusting the caller.
    space : dict
        Parameter name -> list of candidate values.
    method : {'grid', 'random', 'bayesian'}, optional
        'grid' is exhaustive (ignores ``n_iter``); 'random' samples uniformly;
        'bayesian' runs TPE after ``n_startup`` random warm-up trials, which it
        needs before the good/bad split means anything.
    n_iter : int, optional
        Trial budget for 'random' and 'bayesian'. Default 20.
    seed : int, optional
        RNG seed — the whole search is reproducible from it.
    n_startup : int, optional
        Random warm-up trials before TPE takes over. Default 6.
    verbose : bool, optional
        Print each trial as it completes.

    Returns
    -------
    dict
        {'best_config', 'best_score', 'history' (DataFrame, best first),
        'n_trials', 'method', 'warning'} — ``warning`` states the selection-bias
        caveat in words, so it travels with the result instead of living only in
        this docstring.
    """
    if method == 'grid':
        configs = grid_configs(space)
        n_iter = len(configs)
    elif method == 'random':
        configs = random_configs(space, n_iter, seed=seed)
    elif method != 'bayesian':
        raise ValueError("method must be 'grid', 'random' or 'bayesian'")

    rng = np.random.default_rng(seed)
    history = []
    seen = set()

    for t in range(int(n_iter)):
        if method == 'bayesian':
            cfg = (random_configs(space, 1, seed=seed + t)[0]
                   if t < n_startup
                   else _tpe_suggest(space, history, rng, seen=seen))
        else:
            cfg = configs[t]
        try:
            score = float(objective(cfg))
        except Exception as exc:
            if verbose:
                print(f"  trial {t + 1}/{n_iter} FAILED ({str(exc)[:70]}): {cfg}")
            score = float('-inf')
        seen.add(_key(cfg))
        history.append({'trial': t + 1, 'config': cfg, 'score': score})
        if verbose and np.isfinite(score):
            print(f"  trial {t + 1}/{n_iter}: score={score:.6f}  {cfg}")

    hist = pd.DataFrame(history).sort_values('score', ascending=False)
    hist = hist.reset_index(drop=True)
    finite = hist[np.isfinite(hist['score'])]
    best = finite.iloc[0] if len(finite) else None

    return {
        'best_config': (best['config'] if best is not None else None),
        'best_score': (float(best['score']) if best is not None else float('nan')),
        'history': hist,
        'n_trials': int(n_iter),
        'method': method,
        'warning': (
            f"Best of {n_iter} configurations. That is {n_iter} chances for noise "
            "to look like skill, so this is a HYPOTHESIS, not a finding: score it "
            "on the untouched holdout (nested_search does this automatically) and "
            "run the winner through tests/validation/run_spa.py before believing "
            "any improvement."),
    }


def nested_search(df, space, fit_score_fn, method='random', n_iter=20,
                  holdout_frac=0.30, seed=0, verbose=True):
    """
    Search on a training prefix, then score the winner **once** on an untouched tail.

    This is the only entry point that produces a number worth reporting. The
    structure matters more than the search algorithm:

    * the search sees ``df`` up to ``1 - holdout_frac`` and nothing else;
    * the holdout tail is scored exactly twice at the end — once for the tuned
      configuration, once for the **default** — and never during the search;
    * the two holdout scores are compared, so the output answers "did tuning
      help *out of sample*?" rather than "what was the best in-sample fit?".

    A search that improves the inner score while the holdout score gets worse is
    the signature of overfitting the search itself, and this function is designed
    to make that visible rather than to hide it behind a single best-score number.

    Parameters
    ----------
    df : pd.DataFrame
        Full history (datetime + OHLCV), oldest first.
    space : dict
        Search space.
    fit_score_fn : callable
        ``fit_score_fn(train_df, config) -> float`` (higher is better). It must
        do its own internal walk-forward on the frame it is handed; the frame is
        the only data it may see.
    method, n_iter, seed, verbose
        Passed to :func:`search`.
    holdout_frac : float, optional
        Fraction of the most recent rows reserved and untouched. Default 0.30.

    Returns
    -------
    dict
        The :func:`search` result plus 'holdout_score_tuned',
        'holdout_score_default', 'improvement', 'generalizes' and 'verdict'.
        ``default_config`` is the space's first listed value per parameter, which
        is why :func:`suggest_spaces` lists the current shipped value first.
    """
    n = len(df)
    cut = int(n * (1.0 - holdout_frac))
    if cut < 100 or n - cut < 50:
        raise ValueError(f"too little data to nest: {n} rows -> "
                         f"{cut} train / {n - cut} holdout")
    inner, holdout = df.iloc[:cut], df

    if verbose:
        print(f"Nested search: {cut} inner rows, {n - cut} untouched holdout rows")

    res = search(lambda cfg: fit_score_fn(inner, cfg), space, method=method,
                 n_iter=n_iter, seed=seed, verbose=verbose)

    default_cfg = {k: v[0] for k, v in space.items()}
    if verbose:
        print("Scoring on the untouched holdout (tuned vs default)...")
    try:
        tuned = float(fit_score_fn(holdout, res['best_config']))
    except Exception as exc:
        print(f"  tuned holdout score failed: {exc}")
        tuned = float('nan')
    try:
        base = float(fit_score_fn(holdout, default_cfg))
    except Exception as exc:
        print(f"  default holdout score failed: {exc}")
        base = float('nan')

    improvement = (tuned - base) if np.isfinite(tuned) and np.isfinite(base) else float('nan')
    generalizes = bool(np.isfinite(improvement) and improvement > 0)

    if not np.isfinite(improvement):
        verdict = "holdout scoring failed — no conclusion."
    elif generalizes:
        verdict = (
            f"Tuning improved the untouched holdout by {improvement:+.6f} "
            f"({base:.6f} -> {tuned:.6f}). This is a hypothesis worth testing "
            "further, NOT a confirmed gain: run the tuned model through "
            "run_spa.py, and re-run on other tickers before shipping the change.")
    else:
        verdict = (
            f"Tuning did NOT improve the untouched holdout ({base:.6f} -> "
            f"{tuned:.6f}, {improvement:+.6f}). The inner search found a better "
            "FIT that did not generalise — the expected outcome on a "
            "near-random-walk series, and the reason the nesting is mandatory. "
            "Keep the default configuration.")

    res.update({'default_config': default_cfg,
                'holdout_score_tuned': tuned,
                'holdout_score_default': base,
                'improvement': improvement,
                'generalizes': generalizes,
                'inner_rows': int(cut),
                'holdout_rows': int(n - cut),
                'verdict': verdict})
    return res


# ==========================================
# Ready-made objectives
# ==========================================
def qlike_objective_har(train_df, config, interval='1d', horizon=5, n_splits=5):
    """
    Walk-forward **negative QLIKE** of HAR-RV's variance forecast (higher = better).

    QLIKE rather than squared error because the ``r^2`` variance proxy is
    extremely noisy and QLIKE (Patton 2011) is the loss shown to be robust to
    exactly that noise — using squared error here would rank models partly by how
    they handle proxy noise rather than by forecast quality.

    Scores the *variance forecast* rather than the cone, deliberately: the cone's
    conformal layer adapts to whatever the variance forecast does (that is how
    the 1.9x HAR-RV level bias hid for so long), so tuning against coverage would
    optimise a quantity the calibration already fixes.
    """
    from HAR_RV_model import fit_har, forecast_har_variance, _EPS as _E
    import vol_lstm_model as vl

    prices = pd.to_numeric(train_df['adj_close'], errors='coerce').values.astype(float)
    prices = prices[np.isfinite(prices) & (prices > 0)]
    lags = tuple(config.get('lags', (1, 5, 22)))
    n = len(prices)
    origins = np.unique(np.linspace(max(lags[2] + 60, int(n * 0.5)),
                                    n - horizon - 1, n_splits, dtype=int))
    actual, pred = [], []
    for o in origins:
        r = np.diff(np.log(prices[:o]))
        if len(r) < lags[2] + 15:
            continue
        log_rv = np.log(r ** 2 + _E)
        lo, hi = np.percentile(log_rv, [1, 99])
        log_rv = np.clip(log_rv, lo, hi)
        coef, _ = fit_har(log_rv, lags)
        sv = forecast_har_variance(log_rv, coef, lags, horizon)
        realised = np.diff(np.log(prices[o - 1:o + horizon])) ** 2
        if len(realised) < horizon:
            continue
        actual.append(realised)
        pred.append(sv)
    if not actual:
        return float('-inf')
    return -vl.qlike_loss(np.concatenate(actual), np.concatenate(pred))


def format_search_report(res, name='search'):
    """Render a :func:`nested_search` result as a short, honest block."""
    lines = [
        f"=== Hyperparameter search: {name} ({res['method']}, "
        f"{res['n_trials']} trials) ===",
        f"  Inner / holdout rows : {res.get('inner_rows', '?')} / "
        f"{res.get('holdout_rows', '?')}",
        f"  Best config          : {res['best_config']}",
        f"  Best inner score     : {res['best_score']:.6f}",
        f"  Default config       : {res.get('default_config')}",
        f"  Holdout default      : {res.get('holdout_score_default', float('nan')):.6f}",
        f"  Holdout tuned        : {res.get('holdout_score_tuned', float('nan')):.6f}",
        f"  Holdout improvement  : {res.get('improvement', float('nan')):+.6f}",
        f"  Verdict              : {res.get('verdict', '')}",
        f"  NOTE                 : {res['warning']}",
    ]
    return "\n".join(lines)
