"""
Range-based realized variance: using the high and low the app already fetches.

The gap this closes
-------------------
``HAR_RV_model`` builds its variance series as ``RV_t = r_t**2`` and its own
docstring calls that "the standard proxy **when sub-bar data is unavailable**".
Sub-bar data is not unavailable. Every bar this app fetches carries **open, high
and low** alongside the close, and they have been used for features but never
for the variance estimate that drives the uncertainty cone -- which the README
names as the actual product ("the value here is calibrated uncertainty").

Sharma & Mehta (eds.), *Deep Learning Tools for Predicting Stock Market
Movements*, Ch. 18 (Kaur & Chaudhary, "Volatility Transmission Role of Indian
Equity and Commodity Markets") converts price series to volatility with

.. math::  \\sigma^2_{it} = 0.361\\,[\\ln(P^{high}_{it}) - \\ln(P^{low}_{it})]^2

noting that "literature has proven the advantage of using a range-based
volatility estimator as compared to the traditional method". That constant is
:math:`1/(4\\ln 2) = 0.3607` -- the **Parkinson (1980)** estimator.

Why a range beats a squared return
----------------------------------
``r_t**2`` is a one-observation estimate of the bar's variance: it uses two
prices and throws away everything that happened between them. A day that opened
at 100, ran to 108, fell to 94 and closed at 100 has ``r_t = 0`` and therefore
**zero** estimated variance, which is plainly wrong. The high-low range saw all
of it. Under geometric Brownian motion the theoretical efficiency gains over
close-to-close are roughly **5x** (Parkinson), **7x** (Garman-Klass) and **8x**
(Rogers-Satchell) -- meaning the same precision from a fifth as much data.

Four estimators, and why more than one
--------------------------------------
* :func:`parkinson` -- the book's. High/low only. Assumes zero drift.
* :func:`garman_klass` -- adds open and close. More efficient, still assumes
  zero drift, and can go negative on a single bar.
* :func:`rogers_satchell` -- **drift-robust**. The only one of the three that
  stays unbiased when the bar has a strong trend, which matters for a
  momentum-y or crashing name.
* :func:`yang_zhang` -- the only one that includes the **overnight gap**, at the
  cost of needing a rolling window rather than being defined per bar.

The trap that makes a naive swap wrong
--------------------------------------
Parkinson, Garman-Klass and Rogers-Satchell are **intraday** measures. A daily
bar's total variance also contains the **overnight** move, and for equities that
is a large share of it -- earnings and news arrive when the market is shut.
Substituting an intraday-only estimator into a model that forecasts
*close-to-close* risk would therefore **understate the cone** and cause
under-coverage.

:func:`scale_to_total` measures that ratio from the data instead of assuming it,
so the level is right. This is not cosmetic: the conformal layer downstream
absorbs a *constant* scale error (an inflated sigma is cancelled by a deflated
multiplier), so a naive swap could look fine on coverage while the reported
per-step volatility was wrong -- exactly the failure mode the HAR level-offset
fix already had to correct once.

A property worth having
-----------------------
``ln(H/L)``, ``ln(C/O)``, ``ln(H/C)`` and friends are **ratios within one bar**,
so every estimator here except Yang-Zhang is invariant to any multiplicative
rescaling of that bar's prices. That means they can be computed from **raw**
OHLC and are immune to split and dividend adjustment -- a useful property given
that this project fetches raw ``open/high/low/close`` beside an adjusted
``adj_close``. Yang-Zhang's overnight term crosses a bar boundary and is *not*
immune. :func:`estimate` warns accordingly.

No new dependency: NumPy and pandas only.
"""

import numpy as np
import pandas as pd

_EPS = 1e-12

#: 1 / (4 ln 2) -- the constant the book writes as 0.361.
_PARKINSON_K = 1.0 / (4.0 * np.log(2.0))

#: Estimators defined per bar (usable directly as a HAR-RV input series).
PER_BAR = ("squared", "parkinson", "garman_klass", "rogers_satchell")

#: Every estimator, including the rolling one.
ESTIMATORS = PER_BAR + ("yang_zhang",)

#: Theoretical efficiency relative to close-to-close under GBM, for reference
#: only -- :func:`efficiency` measures the realised figure instead.
THEORETICAL_EFFICIENCY = {"squared": 1.0, "parkinson": 5.2,
                          "garman_klass": 7.4, "rogers_satchell": 8.0}


def _arr(x):
    return np.asarray(x, dtype=float)


def _safe_log_ratio(a, b):
    """log(a / b) with non-positive prices removed rather than warned about."""
    a, b = _arr(a), _arr(b)
    out = np.full(a.shape, np.nan)
    ok = (a > 0) & (b > 0) & np.isfinite(a) & np.isfinite(b)
    out[ok] = np.log(a[ok] / b[ok])
    return out


# ==========================================
# 1. Per-bar estimators
# ==========================================
def squared_return(close):
    """
    The incumbent: ``RV_t = r_t**2`` from close-to-close log returns.

    Returned aligned to the *later* bar of each pair, so element 0 is NaN and
    the series has the same length as ``close``.

    Parameters
    ----------
    close : array-like

    Returns
    -------
    np.ndarray
    """
    c = _arr(close)
    out = np.full(len(c), np.nan)
    if len(c) > 1:
        r = _safe_log_ratio(c[1:], c[:-1])
        out[1:] = r ** 2
    return out


def parkinson(high, low):
    """
    Parkinson (1980): ``(1 / (4 ln 2)) * ln(H/L)**2``.

    The estimator used in Ch. 18, where the constant appears as 0.361.
    Uses only the intraday range, so it **excludes the overnight gap** -- see
    :func:`scale_to_total`.

    Parameters
    ----------
    high, low : array-like

    Returns
    -------
    np.ndarray
    """
    return _PARKINSON_K * _safe_log_ratio(high, low) ** 2


def garman_klass(open_, high, low, close):
    """
    Garman-Klass (1980): ``0.5*ln(H/L)**2 - (2 ln 2 - 1)*ln(C/O)**2``.

    More efficient than Parkinson because it also uses the open and close.
    Can return a **negative** value on an individual bar (when the close-open
    move is large relative to the range); such bars are set to NaN rather than
    clipped to zero, because a clipped zero would silently bias the mean down.

    Returns
    -------
    np.ndarray
    """
    hl = _safe_log_ratio(high, low)
    co = _safe_log_ratio(close, open_)
    v = 0.5 * hl ** 2 - (2.0 * np.log(2.0) - 1.0) * co ** 2
    v[v < 0] = np.nan
    return v


def rogers_satchell(open_, high, low, close):
    """
    Rogers-Satchell (1991): ``ln(H/C)ln(H/O) + ln(L/C)ln(L/O)``.

    The only per-bar estimator here that is **unbiased under non-zero drift**.
    Parkinson and Garman-Klass both assume a driftless bar and over-state
    variance when the bar trends hard -- which is precisely the situation
    (a gap-and-run, a crash) where an honest risk number matters most.

    Returns
    -------
    np.ndarray
    """
    return (_safe_log_ratio(high, close) * _safe_log_ratio(high, open_) +
            _safe_log_ratio(low, close) * _safe_log_ratio(low, open_))


def yang_zhang(open_, high, low, close, window=30):
    """
    Yang-Zhang (2000): overnight + open-to-close + Rogers-Satchell.

    The only estimator here that captures the **overnight gap**, and therefore
    the only one that estimates *total* close-to-close variance directly. The
    price is that it is defined over a rolling ``window`` rather than per bar,
    so it is a diagnostic and a scaling reference rather than a drop-in HAR
    input.

    Because its overnight term spans a bar boundary, it is **not** invariant to
    corporate-action adjustment -- feed it an adjusted series.

    Parameters
    ----------
    open_, high, low, close : array-like
    window : int, optional

    Returns
    -------
    np.ndarray
        Same length as the inputs; the first ``window`` entries are NaN.
    """
    o, h, l, c = _arr(open_), _arr(high), _arr(low), _arr(close)
    n = len(c)
    out = np.full(n, np.nan)
    if n <= window or window < 2:
        return out

    overnight = np.full(n, np.nan)
    overnight[1:] = _safe_log_ratio(o[1:], c[:-1])
    open_close = _safe_log_ratio(c, o)
    rs = rogers_satchell(o, h, l, c)

    k = 0.34 / (1.34 + (window + 1.0) / (window - 1.0))
    for i in range(window, n):
        sl = slice(i - window + 1, i + 1)
        ov, oc, r = overnight[sl], open_close[sl], rs[sl]
        m = np.isfinite(ov) & np.isfinite(oc) & np.isfinite(r)
        if m.sum() < 3:
            continue
        v_ov = float(np.var(ov[m], ddof=1))
        v_oc = float(np.var(oc[m], ddof=1))
        v_rs = float(np.mean(r[m]))
        out[i] = v_ov + k * v_oc + (1.0 - k) * v_rs
    return out


# ==========================================
# 2. Dispatch
# ==========================================
def estimate(df, estimator="parkinson", window=30):
    """
    Compute a realized-variance series from an OHLC frame.

    Parameters
    ----------
    df : pd.DataFrame
        Needs ``close``; range estimators additionally need ``high``/``low``
        (and ``open`` for all but Parkinson).
    estimator : str, optional
        One of :data:`ESTIMATORS`.
    window : int, optional
        Rolling window for ``yang_zhang``.

    Returns
    -------
    np.ndarray

    Raises
    ------
    ValueError
        On an unknown estimator, or when the required columns are absent --
        rather than silently falling back to squared returns, which would make
        an A/B compare a model against itself.
    """
    if estimator not in ESTIMATORS:
        raise ValueError(f"unknown estimator {estimator!r}; "
                         f"expected one of {ESTIMATORS}")
    need = {"squared": ["close"], "parkinson": ["high", "low"],
            "garman_klass": ["open", "high", "low", "close"],
            "rogers_satchell": ["open", "high", "low", "close"],
            "yang_zhang": ["open", "high", "low", "close"]}[estimator]
    missing = [c for c in need if c not in df.columns]
    if missing:
        raise ValueError(f"{estimator!r} needs columns {missing}, which are absent")

    if estimator == "squared":
        return squared_return(df["close"].values)
    if estimator == "parkinson":
        return parkinson(df["high"].values, df["low"].values)
    if estimator == "garman_klass":
        return garman_klass(df["open"].values, df["high"].values,
                            df["low"].values, df["close"].values)
    if estimator == "rogers_satchell":
        return rogers_satchell(df["open"].values, df["high"].values,
                               df["low"].values, df["close"].values)
    return yang_zhang(df["open"].values, df["high"].values,
                      df["low"].values, df["close"].values, window=window)


# ==========================================
# 3. Level correction and diagnostics
# ==========================================
def scale_to_total(range_rv, close, min_obs=60):
    """
    Rescale an intraday-only variance series to close-to-close level.

    Parkinson, Garman-Klass and Rogers-Satchell measure the variance **inside**
    the bar. A daily bar's total variance also contains the overnight move, and
    for equities that is a large share of it. Substituting an intraday-only
    series into a model that forecasts close-to-close risk understates the cone.

    The factor is **measured, not assumed**: the ratio of mean squared
    close-to-close return to mean range variance over the supplied history.
    Estimated from whatever slice the caller passes, so a walk-forward origin
    can derive its own from past bars only.

    **``close`` must be corporate-action adjusted.** The range term is a within
    -bar ratio and so immune to splits, but the close-to-close term is not: an
    unadjusted 1:10 split injects a fake -90% return, inflating the measured
    total variance and hence the factor. Measured on six NSE names, using raw
    closes moved TATASTEEL's level ratio from a plausible 0.794 to 0.120 and its
    factor from 1.26 to **8.32**. Four of the six were corrupted this way; only
    the two without splits in the window were unaffected. This is not a
    hypothetical -- it happened while building this module.

    ``implausible`` in the returned diagnostics flags a factor outside
    [0.25, 4.0], which is the signature of exactly that mistake. The factor is
    still returned (the caller may have a genuinely odd series) but it is
    labelled, because silently scaling a cone by 8x is worse than saying so.

    Parameters
    ----------
    range_rv : array-like
    close : array-like
        **Adjusted** closing prices.
    min_obs : int, optional
        Below this many usable pairs the factor is not identified and 1.0 is
        returned, leaving the series untouched.

    Returns
    -------
    (np.ndarray, dict)
        ``(scaled_series, info)`` where ``info`` carries ``factor``,
        ``level_ratio`` (share of total variance the range captures), ``n_obs``
        and ``implausible``.
    """
    rv = _arr(range_rv)
    cc = squared_return(close)
    m = np.isfinite(rv) & np.isfinite(cc) & (rv > 0)
    info = {"factor": 1.0, "level_ratio": float("nan"),
            "n_obs": int(m.sum()), "implausible": False}
    if m.sum() < min_obs:
        return rv, info
    denom = float(np.mean(rv[m]))
    if denom <= _EPS:
        return rv, info
    factor = float(np.mean(cc[m]) / denom)
    if not np.isfinite(factor) or factor <= 0:
        return rv, info
    info["factor"] = factor
    info["level_ratio"] = 1.0 / factor
    info["implausible"] = bool(factor < 0.25 or factor > 4.0)
    return rv * factor, info


def efficiency(df, estimator="parkinson", block=5):
    """
    Measure the realised precision gain over squared returns.

    The theory quotes ~5x for Parkinson under geometric Brownian motion; real
    bars are discrete, gap overnight and trend, so the honest number is the
    measured one.

    Method: both series are aggregated into non-overlapping blocks of ``block``
    bars (a block mean is a variance estimate over that block). Because both
    estimate the same underlying quantity, the estimator with the smaller
    variance *of the log block means* is the more precise one, and the ratio is
    the efficiency gain.

    Returns
    -------
    dict
        ``{'estimator', 'efficiency', 'n_blocks', 'mean_ratio'}``. ``efficiency``
        above 1 means the range estimator is more precise.
    """
    rv_r = estimate(df, estimator)
    rv_s = estimate(df, "squared")
    m = np.isfinite(rv_r) & np.isfinite(rv_s) & (rv_r > 0) & (rv_s > 0)
    rv_r, rv_s = rv_r[m], rv_s[m]
    n = (len(rv_r) // block) * block
    if n < block * 10:
        return {"estimator": estimator, "efficiency": float("nan"),
                "n_blocks": 0, "mean_ratio": float("nan")}
    br = rv_r[:n].reshape(-1, block).mean(axis=1)
    bs = rv_s[:n].reshape(-1, block).mean(axis=1)
    # Compare on the log scale: variance is right-skewed, so a raw variance
    # comparison is dominated by a handful of large blocks.
    vr = float(np.var(np.log(br + _EPS), ddof=1))
    vs = float(np.var(np.log(bs + _EPS), ddof=1))
    return {"estimator": estimator,
            "efficiency": (vs / vr) if vr > _EPS else float("nan"),
            "n_blocks": int(len(br)),
            "mean_ratio": float(np.mean(br) / np.mean(bs))}


def compare(df, block=5):
    """
    Efficiency and level of every per-bar estimator on one frame.

    Returns
    -------
    pd.DataFrame
        ``estimator``, ``efficiency``, ``mean_ratio``, ``n_valid``, sorted by
        efficiency.
    """
    rows = []
    for est in PER_BAR:
        try:
            e = efficiency(df, est, block=block)
            rv = estimate(df, est)
            e["n_valid"] = int(np.isfinite(rv).sum())
        except ValueError as exc:
            e = {"estimator": est, "efficiency": float("nan"),
                 "mean_ratio": float("nan"), "n_valid": 0,
                 "note": str(exc)[:60]}
        rows.append(e)
    out = pd.DataFrame(rows)
    return out.sort_values("efficiency", ascending=False).reset_index(drop=True)


def format_report(tab, title="Range-based volatility estimators"):
    """Render :func:`compare` output for the console."""
    lines = [title, "=" * len(title),
             f"{'estimator':18s}{'efficiency':>12s}{'level vs r^2':>14s}"
             f"{'valid bars':>12s}"]
    for _, r in tab.iterrows():
        eff = "n/a" if not np.isfinite(r["efficiency"]) else f"{r['efficiency']:.2f}x"
        lvl = "n/a" if not np.isfinite(r["mean_ratio"]) else f"{r['mean_ratio']:.3f}"
        lines.append(f"{str(r['estimator'])[:17]:18s}{eff:>12s}{lvl:>14s}"
                     f"{int(r['n_valid']):12d}")
    lines.append("")
    lines.append("efficiency > 1 means more precise than squared returns;")
    lines.append("level vs r^2 < 1 is expected for intraday-only estimators,")
    lines.append("which exclude the overnight gap (see scale_to_total).")
    return "\n".join(lines)
