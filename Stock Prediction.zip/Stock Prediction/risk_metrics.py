"""
Pure risk-metric math for the Risk & Probability panel.

Extracted from UI.py so it carries **no Streamlit dependency** and can be unit
tested directly (the app imports these). Two read paths:

* ``empirical_risk`` — counts probabilities and tail metrics straight off a
  fat-tailed return sample (HAR-RV's conformal residuals). This is the honest
  path: it preserves the tails the model estimated and is the only place the
  downside reads (expected shortfall, semideviation, vol skew) are meaningful.
* ``risk_from_interval`` — a log-normal fallback from a model's median + 95%
  band, used only when no model exposes an empirical sample. Re-imposes
  normality, so the UI labels it as an approximation.
"""

import math

import numpy as np


def normal_cdf(x):
    """Standard-normal CDF Φ(x) via the error function (no SciPy dependency)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def empirical_risk(last_actual, log_returns, threshold_pct):
    """
    Read risk probabilities and downside metrics off an empirical return sample.

    Counts probabilities straight from the sample (no Gaussian), so the fat tails
    survive into the numbers the user sees; VaR is an empirical quantile.

    Parameters
    ----------
    last_actual : float
        Last observed price (reference for "up"/"down").
    log_returns : np.ndarray
        Sample of horizon-end log-returns (centred near 0 for a random-walk
        point forecast).
    threshold_pct : float
        Move size (in %) for the gain/loss probabilities.

    Returns
    -------
    dict
        {'p_up', 'p_gain', 'p_loss', 'var5_pct', 'range_low', 'range_high',
         'cvar5_pct', 'down_semidev', 'up_semidev', 'vol_skew'} — the last four
        are the downside-risk reads: expected shortfall and the up/down realized
        semideviation split.
    """
    r = np.asarray(log_returns, dtype=float)
    t = math.log(1.0 + threshold_pct / 100.0)
    t_dn = math.log(max(1.0 - threshold_pct / 100.0, 1e-9))
    q05, q025, q975 = np.quantile(r, [0.05, 0.025, 0.975])

    # Expected shortfall / CVaR(5%): the average loss given we're already in the
    # worst 5% tail — "if it's a bad day, how bad on average".
    tail = r[r <= q05]
    cvar5 = float(math.exp(tail.mean()) - 1.0) if len(tail) else float(math.exp(q05) - 1.0)

    # Realized semideviation split (Barndorff-Nielsen et al. 2010): dispersion of
    # down-moves vs up-moves; their ratio is a forward skew gauge.
    neg, pos = r[r < 0.0], r[r > 0.0]
    down_semidev = float(np.sqrt(np.mean(neg ** 2))) if len(neg) else 0.0
    up_semidev = float(np.sqrt(np.mean(pos ** 2))) if len(pos) else 0.0
    vol_skew = float(down_semidev / up_semidev) if up_semidev > 0 else float('nan')

    return {
        'p_up': float(np.mean(r > 0.0)),
        'p_gain': float(np.mean(r > t)),
        'p_loss': float(np.mean(r < t_dn)),
        'var5_pct': float(math.exp(q05) - 1.0),
        'range_low': float(last_actual * math.exp(q025)),
        'range_high': float(last_actual * math.exp(q975)),
        'cvar5_pct': cvar5,
        'down_semidev': down_semidev,
        'up_semidev': up_semidev,
        'vol_skew': vol_skew,
    }


def risk_from_interval(median, lower, upper, last_actual, threshold_pct,
                       conf=0.95):
    """
    Fallback risk read from a model's median + (1-α) interval (Gaussian approx).

    Used ONLY when no model exposes an empirical sample. Approximates the
    horizon-end forecast as log-normal. Re-imposes normality, so it is labelled
    as an approximation in the UI and superseded whenever an empirical-residual
    model (HAR-RV) is selected.

    Returns
    -------
    dict or None
        {'p_up', 'p_gain', 'p_loss', 'var5_pct', 'range_low', 'range_high'},
        or None if degenerate.
    """
    if min(median, lower, upper, last_actual) <= 0 or upper <= lower:
        return None
    from statistics import NormalDist
    z = NormalDist().inv_cdf(1.0 - (1.0 - conf) / 2.0)   # 0.95 -> 1.96
    mu = math.log(median / last_actual)
    sigma = (math.log(upper) - math.log(lower)) / (2.0 * z)
    if sigma <= 0:
        return None
    t = math.log(1.0 + threshold_pct / 100.0)
    t_dn = math.log(max(1.0 - threshold_pct / 100.0, 1e-9))
    return {
        'p_up': normal_cdf(mu / sigma),
        'p_gain': normal_cdf((mu - t) / sigma),
        'p_loss': normal_cdf((t_dn - mu) / sigma),
        'var5_pct': math.exp(mu - 1.6448536269514722 * sigma) - 1.0,
        'range_low': lower,
        'range_high': upper,
    }
