import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, Input
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler
from pandas.tseries.offsets import BusinessDay
import os

# Suppress TensorFlow logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


# ==========================================
# 1. Helper: Data Processing
# ==========================================
def prepare_transformer_data(df: pd.DataFrame, look_back=60):
    """
    Same preparation as LSTM.
    Shape: [Samples, Time Steps, Features]
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime').sort_index()
    
    # Filter only the target column
    data = df.filter(['adj_close']).values
    data = data.astype('float32')

    # Scale (Transformers are very sensitive to scale)
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(data)

    X, y = [], []
    for i in range(look_back, len(scaled_data)):
        X.append(scaled_data[i-look_back:i, 0])
        y.append(scaled_data[i, 0])

    X, y = np.array(X), np.array(y)

    # Reshape: [Samples, Time Steps, Features]
    # Features is 1 because we are only using Price
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))
    
    return X, y, scaler, scaled_data

# ==========================================
# 2. Helper: The Transformer Architecture
# ==========================================
def transformer_encoder(inputs, head_size, num_heads, ff_dim, dropout=0):
    """
    A single Transformer Encoder Block.
    1. Attention
    2. Normalization
    3. Feed Forward
    """
    # Normalization and Attention
    x = layers.LayerNormalization(epsilon=1e-6)(inputs)
    x = layers.MultiHeadAttention(
        key_dim=head_size, num_heads=num_heads, dropout=dropout
    )(x, x)
    # Residual Connection (Add original input to result)
    res = x + inputs

    # Feed Forward Part
    x = layers.LayerNormalization(epsilon=1e-6)(res)
    x = layers.Conv1D(filters=ff_dim, kernel_size=1, activation="relu")(x)
    x = layers.Dropout(dropout)(x)
    x = layers.Conv1D(filters=inputs.shape[-1], kernel_size=1)(x)
    
    # Residual Connection
    return x + res

def build_transformer_model(input_shape, head_size=256, num_heads=4, ff_dim=4, num_transformer_blocks=4, mlp_units=[128], dropout=0.2, mlp_dropout=0.2):
    """
    Builds the complete model.
    """
    inputs = Input(shape=input_shape)
    x = inputs

    # --- 1. Transformer Blocks ---
    # We stack multiple blocks to learn complex patterns
    for _ in range(num_transformer_blocks):
        x = transformer_encoder(x, head_size, num_heads, ff_dim, dropout)

    # --- 2. Global Pooling ---
    # Instead of flattening (which loses time info), we average over the time steps
    x = layers.GlobalAveragePooling1D(data_format="channels_last")(x)

    # --- 3. MLP Head (Final Prediction) ---
    for dim in mlp_units:
        x = layers.Dense(dim, activation="relu")(x)
        x = layers.Dropout(mlp_dropout)(x)

    outputs = layers.Dense(1)(x) # Predict 1 value (Price)

    model = models.Model(inputs, outputs)
    
    model.compile(loss="mse", optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4))
    return model

# ==========================================
# 3. Helper: Training Wrapper
# ==========================================
def train_transformer(X, y):
    print("Building Transformer Model...")
    
    input_shape = X.shape[1:] # (Lookback, 1)
    
    model = build_transformer_model(
        input_shape,
        head_size=64,            # Size of attention heads
        num_heads=2,             # Number of heads (Parallel attention)
        ff_dim=64,               # Feed forward dimension
        num_transformer_blocks=2,# Number of stacked layers
        mlp_units=[64],          # Final dense layers
        dropout=0.2,
        mlp_dropout=0.2
    )

    early_stop = EarlyStopping(monitor='loss', patience=5, restore_best_weights=True)
    
    print("Training Transformer (this may take time)...")
    model.fit(
        X, y,
        validation_split=0.2,
        epochs=30, # Transformers need more epochs than LSTMs
        batch_size=32,
        callbacks=[early_stop],
        verbose=0
    )
    
    return model

# ==========================================
# 4. Helper: Recursive Prediction (Same as LSTM)
# ==========================================
def predict_transformer_recursive(model, scaler, full_scaled_data, horizon, interval, last_date, look_back):
    future_predictions = []
    current_date = last_date
    
    if interval == 'daily':
        date_offset = BusinessDay(n=1)
    else:
        date_offset = pd.DateOffset(hours=1)

    # Get initial batch
    current_batch = full_scaled_data[-look_back:].reshape(1, look_back, 1)

    print(f"Generating {horizon} future steps recursively...")

    for i in range(horizon):
        # 1. Update Date
        current_date += date_offset
        if interval == 'hourly':
            if current_date.dayofweek >= 5:
                days_add = 7 - current_date.dayofweek
                current_date += pd.DateOffset(days=days_add)
                current_date = current_date.replace(hour=9, minute=15)
            if current_date.hour >= 16 or current_date.hour < 9:
                current_date += pd.DateOffset(days=1)
                current_date = current_date.replace(hour=9, minute=15)
                if current_date.dayofweek >= 5:
                    days_add = 7 - current_date.dayofweek
                    current_date += pd.DateOffset(days=days_add)
                    current_date = current_date.replace(hour=9, minute=15)

        # 2. Predict
        pred_scaled = model.predict(current_batch, verbose=0)
        pred_price = scaler.inverse_transform(pred_scaled)[0][0]
        
        future_predictions.append({
            'datetime': current_date,
            'predicted_price': float(pred_price)
        })

        # 3. Update Batch
        new_step = pred_scaled.reshape(1, 1, 1)
        current_batch = np.append(current_batch[:, 1:, :], new_step, axis=1)

    return pd.DataFrame(future_predictions)

# ==========================================
# 5. Main Orchestrator
# ==========================================
def run_transformer_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run Transformer prediction.
    """
    print(f"--- Starting Transformer Prediction ({interval}) ---")
    
    # Fix Datetime String Issue
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    
    look_back = 60 if interval == 'daily' else 24
    
    X, y, scaler, scaled_data = prepare_transformer_data(df, look_back)
    last_date = df['datetime'].iloc[-1]
    
    model = train_transformer(X, y)
    
    results_df = predict_transformer_recursive(model, scaler, scaled_data, horizon, interval, last_date, look_back)
    
    print("Transformer Prediction Complete.")
    return results_df