import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, Input
import os
import warnings

from model_utils import (
    normalize_interval,
    reset_keras_seeds,
    temporal_train_val_split,
    default_keras_callbacks,
    forecast_nn_direct,
)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


# ==========================================
# 1. Transformer Architecture
# ==========================================
class InputEmbedding(layers.Layer):
    """
    Input projection with learnable positional embedding.

    Projects raw features to ``d_model`` dimensions via a Dense
    layer, then adds a learnable positional embedding so the
    Transformer knows the temporal position of each timestep
    in the sequence.
    """

    def __init__(self, max_len, d_model, **kwargs):
        """
        Initialise projection and positional embedding layers.

        Parameters
        ----------
        max_len : int
            Maximum sequence length (size of the positional embedding
            lookup table).
        d_model : int
            Dimensionality of the model's internal representation.
        **kwargs
            Additional keyword arguments forwarded to the base Layer.
        """
        super().__init__(**kwargs)
        self.projection = layers.Dense(d_model)
        self.pos_embedding = layers.Embedding(
            input_dim=max_len, output_dim=d_model,
        )

    def call(self, x):
        """
        Forward pass: project features to d_model and add positional embeddings.

        Parameters
        ----------
        x : tf.Tensor
            Input tensor of shape (batch, seq_len, n_features).

        Returns
        -------
        tf.Tensor
            Embedded tensor of shape (batch, seq_len, d_model).
        """
        seq_len = tf.shape(x)[1]
        positions = tf.range(start=0, limit=seq_len, delta=1)
        x = self.projection(x)
        x = x + self.pos_embedding(positions)
        return x


def transformer_encoder(inputs, head_size, num_heads, ff_dim, dropout=0):
    """
    Pre-norm Transformer encoder block with causal attention.

    Architecture per block:
    LayerNorm -> CausalMultiHeadAttention -> Residual ->
    LayerNorm -> FeedForward (Dense-ReLU-Dropout-Dense) -> Residual.

    Causal masking prevents each position from attending to future
    positions within the look-back window, which is more principled
    for autoregressive time-series prediction.

    Parameters
    ----------
    inputs : tf.Tensor
        Input tensor of shape (batch, seq_len, d_model).
    head_size : int
        Dimensionality of each attention head (d_model // num_heads).
    num_heads : int
        Number of parallel attention heads.
    ff_dim : int
        Hidden dimensionality of the position-wise feed-forward network.
    dropout : float, optional
        Dropout rate applied in attention and the feed-forward network.
        Default is 0.

    Returns
    -------
    tf.Tensor
        Output tensor of same shape as *inputs*.
    """
    x = layers.LayerNormalization(epsilon=1e-6)(inputs)
    x = layers.MultiHeadAttention(
        key_dim=head_size, num_heads=num_heads, dropout=dropout,
    )(x, x, use_causal_mask=True)
    res = x + inputs

    x = layers.LayerNormalization(epsilon=1e-6)(res)
    x = layers.Dense(ff_dim, activation='relu')(x)
    x = layers.Dropout(dropout)(x)
    x = layers.Dense(inputs.shape[-1])(x)
    return x + res


def build_transformer_model(input_shape,
                            d_model=64,
                            num_heads=4,
                            ff_dim=128,
                            num_blocks=3,
                            dropout=0.2,
                            mlp_units=None,
                            output_dim=1):
    """
    Build a Transformer encoder model for time-series regression.

    Architecture: InputEmbedding (projection + learnable positional
    encoding) -> N causal transformer encoder blocks ->
    GlobalAveragePooling1D -> MLP head -> single output. Compiled
    with Huber loss and Adam optimiser with gradient clipping.

    Parameters
    ----------
    input_shape : tuple of int
        (sequence_length, n_features) shape of each input sample.
    d_model : int, optional
        Internal representation dimension. Default 64.
    num_heads : int, optional
        Number of attention heads. Default 4.
    ff_dim : int, optional
        Hidden dimension of the feed-forward network. Default 128.
    num_blocks : int, optional
        Number of stacked transformer encoder blocks. Default 3.
    dropout : float, optional
        Dropout rate applied inside encoder blocks and MLP head.
        Default 0.2.
    mlp_units : list of int, optional
        Hidden layer sizes for the MLP head. Default [32].

    Returns
    -------
    tf.keras.Model
        Compiled Keras model ready for training.
    """
    if mlp_units is None:
        mlp_units = [32]

    inputs = Input(shape=input_shape)

    x = InputEmbedding(max_len=input_shape[0], d_model=d_model)(inputs)

    head_size = d_model // num_heads
    for _ in range(num_blocks):
        x = transformer_encoder(x, head_size, num_heads, ff_dim, dropout)

    x = layers.GlobalAveragePooling1D(data_format="channels_last")(x)

    for dim in mlp_units:
        x = layers.Dense(dim, activation='relu')(x)
        x = layers.Dropout(dropout)(x)

    outputs = layers.Dense(output_dim)(x)

    model = models.Model(inputs, outputs)
    model.compile(
        loss='huber',
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3, clipnorm=1.0),
    )
    return model


# ==========================================
# 2. Training Wrapper
# ==========================================
def train_transformer(X, y, output_dim=1):
    """
    Build and train the Transformer model with temporal validation.

    Clears the TF session, sets random seeds for reproducibility,
    splits data temporally (last 10% for validation), and trains
    with early stopping and learning-rate scheduling.

    Parameters
    ----------
    X : np.ndarray
        Input sequences of shape (n_samples, look_back, n_features).
    y : np.ndarray
        Targets of shape (n_samples,) or (n_samples, output_dim) — the
        per-horizon cumulative log returns for direct multi-horizon output.
    output_dim : int, optional
        Number of outputs (= forecast horizon for direct multi-horizon).
        Default 1.

    Returns
    -------
    tf.keras.Model
        Trained Keras Transformer model.
    """
    reset_keras_seeds()

    input_shape = X.shape[1:]

    X_train, X_val, y_train, y_val = temporal_train_val_split(X, y)

    print(
        f"Building Transformer Model "
        f"({input_shape[0]} steps x {input_shape[1]} features)..."
    )
    model = build_transformer_model(input_shape, output_dim=output_dim)

    print("Training Transformer (this may take time)...")
    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=100,
        batch_size=32,
        callbacks=default_keras_callbacks(),
        shuffle=True,
        verbose=0,
    )

    return model


# ==========================================
# 3. Main Orchestrator
# ==========================================
def run_transformer_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run Transformer prediction.

    Orchestrates data preparation (9-feature engineering with RSI,
    momentum, dual-window volatility, z-score, and acceleration),
    Transformer model training with causal attention and temporal
    validation, and direct multi-horizon forecasting (one output per
    step, no recursive feedback) with distribution-free conformal
    prediction intervals.  Training data is limited to recent
    observations to focus on the current regime.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Transformer Prediction ({interval}) ---")

    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])

    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.tail(max_obs).reset_index(drop=True)

    look_back = 90 if interval == 'daily' else 48

    results_df = forecast_nn_direct(
        df, interval, horizon, look_back,
        build_train_fn=lambda X, Y, od: train_transformer(X, Y, output_dim=od),
        model_name='Transformer',
    )

    print("Transformer Prediction Complete.")
    return results_df
