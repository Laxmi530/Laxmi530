import pandas as pd
import numpy as np
from prophet import Prophet
from pandas.tseries.offsets import BusinessDay
import logging

# Suppress Prophet's excessive logging
logging.getLogger('cmdstanpy').setLevel(logging.WARNING)

# ==========================================
# 1. Helper: Prepare Data for Prophet
# ==========================================
def prepare_prophet_data(df: pd.DataFrame):
    """
    Prophet STRICTLY requires columns named 'ds' (Date) and 'y' (Target).
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    
    # Rename columns to match Prophet requirements
    # ds = datestamp, y = measurement
    prophet_df = df.rename(columns={'datetime': 'ds', 'adj_close': 'y'})
    
    # Sort and ensure no NaNs
    prophet_df = prophet_df.sort_values('ds')
    prophet_df = prophet_df.dropna(subset=['y'])
    
    return prophet_df[['ds', 'y']]

# ==========================================
# 2. Helper: Train Advanced Model
# ==========================================
def train_prophet_model(df: pd.DataFrame, interval: str):
    """
    Configures an 'Advanced' Prophet model suited for Finance.
    """
    print("Configuring Prophet Model...")
    
    # --- Advanced Hyperparameters ---
    model = Prophet(
        # 1. Seasonality Mode: 'multiplicative' is better for Finance.
        # It models percentage changes rather than absolute dollar changes.
        seasonality_mode='multiplicative',
        
        # 2. Changepoint Scale: Default is 0.05. 
        # We increase to 0.15 to make it more sensitive to recent trend changes.
        changepoint_prior_scale=0.15,
        
        # 3. Seasonality settings
        daily_seasonality=True if interval == 'hourly' else False,
        weekly_seasonality=True, # Stocks have strong weekly patterns
        yearly_seasonality=True  # Capture annual cycles
    )
    
    # --- 4. Add Holidays (Crucial for accuracy) ---
    # Since you are in India, we add Indian holidays. 
    # Change country_name to 'US', 'UK', etc. as needed.
    try:
        model.add_country_holidays(country_name='IN')
    except Exception as e:
        print(f"Warning: Could not add holidays. {e}")

    print("Training Prophet Model...")
    model.fit(df)
    
    return model

# ==========================================
# 3. Helper: Custom Future Logic
# ==========================================
def generate_prophet_forecast(model, last_date, horizon, interval):
    """
    Generates future dates skipping weekends/nights, then predicts.
    """
    future_dates = []
    current_date = last_date
    
    # Logic for Date Increment (Same as your ML models)
    if interval == 'daily':
        date_offset = BusinessDay(n=1)
    else:
        date_offset = pd.DateOffset(hours=1)

    print(f"Generating {horizon} future dates (Trading Logic)...")

    # 1. Generate the future dates manually to skip weekends/nights
    for _ in range(horizon):
        current_date += date_offset
        
        if interval == 'hourly':
            # Skip Weekend
            if current_date.dayofweek >= 5:
                days_add = 7 - current_date.dayofweek
                current_date += pd.DateOffset(days=days_add)
                current_date = current_date.replace(hour=9, minute=15)
            
            # Skip Night (e.g., after 3:30 PM or before 9:15 AM)
            if current_date.hour >= 16 or current_date.hour < 9:
                current_date += pd.DateOffset(days=1)
                current_date = current_date.replace(hour=9, minute=15)
                # Re-check weekend
                if current_date.dayofweek >= 5:
                    days_add = 7 - current_date.dayofweek
                    current_date += pd.DateOffset(days=days_add)
                    current_date = current_date.replace(hour=9, minute=15)
        
        future_dates.append(current_date)

    # 2. Create DataFrame for Prophet
    future_df = pd.DataFrame({'ds': future_dates})
    
    # 3. Predict
    # Prophet returns a huge dataframe. We only need specific columns.
    forecast = model.predict(future_df)
    
    # 4. Clean up output
    results = pd.DataFrame({
        'datetime': forecast['ds'],
        'predicted_price': forecast['yhat'],       # The prediction
        'lower_bound': forecast['yhat_lower'],     # Lower confidence interval
        'upper_bound': forecast['yhat_upper'],     # Upper confidence interval
        'trend': forecast['trend']                 # The underlying trend component
    })
    
    return results

# ==========================================
# 4. Main Orchestrator
# ==========================================
def run_prophet_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run Prophet prediction.
    
    Args:
        df: DataFrame with 'datetime' and 'adj_close'
        interval: 'daily' or 'hourly'
        horizon: Number of steps to predict
        
    Returns:
        pd.DataFrame: ['datetime', 'predicted_price', 'lower_bound', 'upper_bound', 'trend']
    """
    print(f"--- Starting Prophet Prediction ({interval}) ---")
    
    # 1. Prepare
    prophet_df = prepare_prophet_data(df)
    last_date = prophet_df['ds'].iloc[-1]
    
    # 2. Train
    model = train_prophet_model(prophet_df, interval)
    
    # 3. Forecast
    results_df = generate_prophet_forecast(model, last_date, horizon, interval)
    
    print("Prophet Prediction Complete.")
    return results_df
