import pandas as pd
import numpy as np
from prophet import Prophet
import logging
import warnings

from model_utils import normalize_interval, generate_future_dates

logging.getLogger('cmdstanpy').setLevel(logging.WARNING)
logging.getLogger('prophet').setLevel(logging.WARNING)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


def _patch_prophet_pandas3_compat():
    """
    Make Prophet's component-matrix build robust to pandas >= 3.0.

    ``Prophet.add_group_component`` concatenates component rows without
    ``ignore_index``, leaving the frame with a **duplicate-labelled index**.
    pandas 3.0 tightened ``pd.crosstab`` so it now raises *"cannot reindex on an
    axis with duplicate labels"* inside ``regressor_column_matrix`` during
    ``model.fit`` — breaking Prophet entirely on pandas 3.x (the environment here
    runs pandas 3.0 even though requirements pin 2.3.3). We wrap the method to
    return a clean ``RangeIndex``. This is safe because the index is positional
    only — the real feature-column positions live in the ``'col'`` column — and
    is harmless on older pandas, so it can always be applied. Idempotent.
    """
    try:
        if getattr(Prophet.add_group_component, '_pandas3_patched', False):
            return
        _orig = Prophet.add_group_component

        def _patched(self, components, name, group):
            return _orig(self, components, name, group).reset_index(drop=True)

        _patched._pandas3_patched = True
        Prophet.add_group_component = _patched
    except Exception as exc:   # never let a patch failure break import
        print(f"Prophet pandas-3 compat patch skipped: {exc}")


_patch_prophet_pandas3_compat()


# ==========================================
# 1. Helper: Prepare Data for Prophet
# ==========================================
def prepare_prophet_data(df: pd.DataFrame, max_obs=None):
    """
    Prepare data for Prophet: rename columns, log-transform the target,
    and compute exogenous regressors.

    Prophet requires columns named 'ds' (date) and 'y' (target).
    The target is log-transformed so Prophet's additive decomposition
    operates in log-space, equivalent to a multiplicative decomposition
    in price-space. Two exogenous regressors are computed from OHLCV
    data to help Prophet separate signal from noise during training.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with columns datetime, open, high, low,
        close, adj_close, volume.
    max_obs : int, optional
        Maximum number of recent observations to keep. If None, use all.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['ds', 'y', 'log_volume_ratio',
        'range_pct']. Regressor columns may be absent if the
        source columns are missing from *df*.
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.sort_values('datetime').reset_index(drop=True)

    for col in ['adj_close', 'volume', 'high', 'low']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if max_obs and len(df) > max_obs:
        df = df.iloc[-max_obs:]

    if 'volume' in df.columns:
        vol_ma = df['volume'].rolling(20, min_periods=1).mean()
        df['log_volume_ratio'] = np.log(
            (df['volume'] / vol_ma.replace(0, 1)).clip(lower=0.01)
        )

    if 'high' in df.columns and 'low' in df.columns:
        df['range_pct'] = (
            (df['high'] - df['low']) / df['adj_close'].replace(0, 1)
        )

    prophet_df = df.rename(columns={'datetime': 'ds', 'adj_close': 'y'})
    prophet_df = prophet_df.dropna(subset=['y'])
    prophet_df['y'] = pd.to_numeric(prophet_df['y'], errors='coerce')
    prophet_df = prophet_df[prophet_df['y'] > 0]

    prophet_df['y'] = np.log(prophet_df['y'])

    for col in ['log_volume_ratio', 'range_pct']:
        if col in prophet_df.columns:
            prophet_df[col] = (
                prophet_df[col].replace([np.inf, -np.inf], np.nan).fillna(0)
            )

    keep = ['ds', 'y']
    for col in ['log_volume_ratio', 'range_pct']:
        if col in prophet_df.columns:
            keep.append(col)

    return prophet_df[keep].reset_index(drop=True)


# ==========================================
# 2. Helper: Train Advanced Model
# ==========================================
def train_prophet_model(df: pd.DataFrame, interval: str):
    """
    Configure and train a Prophet model for stock price forecasting.

    Uses log-space additive decomposition (equivalent to multiplicative
    in price-space), 95% uncertainty intervals, dynamically scaled
    changepoints, Indian market holidays, stock-specific monthly and
    quarterly seasonalities (daily only), and exogenous regressors
    (log volume ratio and high-low range) to absorb non-seasonal
    variance and improve trend/seasonality estimation.

    Parameters
    ----------
    df : pd.DataFrame
        Prophet-formatted DataFrame with columns ['ds', 'y'] and
        optional regressor columns ['log_volume_ratio', 'range_pct'].
    interval : str
        'daily' or 'hourly'; controls which seasonalities are enabled.

    Returns
    -------
    tuple of (Prophet, list of str)
        model : fitted Prophet model.
        regressor_cols : list of regressor column names registered
        with the model (needed for building the future dataframe).
    """
    print("Configuring Prophet Model...")

    n_changepoints = min(30, max(10, len(df) // 20))

    model = Prophet(
        growth='linear',
        seasonality_mode='additive',
        interval_width=0.95,
        changepoint_prior_scale=0.1,
        changepoint_range=0.9,
        n_changepoints=n_changepoints,
        seasonality_prior_scale=5.0,
        holidays_prior_scale=5.0,
        daily_seasonality=(interval == 'hourly'),
        weekly_seasonality=True,
        yearly_seasonality=True,
    )

    if interval == 'daily':
        model.add_seasonality(name='monthly', period=30.5, fourier_order=5)
        model.add_seasonality(name='quarterly', period=91.25, fourier_order=3)

    regressor_cols = [c for c in df.columns if c not in ('ds', 'y')]
    for col in regressor_cols:
        model.add_regressor(col, mode='additive')

    try:
        model.add_country_holidays(country_name='IN')
    except Exception as e:
        print(f"Warning: Could not add holidays. {e}")

    print(
        f"Training Prophet Model "
        f"(n_changepoints={n_changepoints}, regressors={regressor_cols})..."
    )
    model.fit(df)

    return model, regressor_cols


# ==========================================
# 3. Helper: Custom Future Logic
# ==========================================
def generate_prophet_forecast(model, last_date, horizon, interval,
                              regressor_cols, train_df):
    """
    Generate future dates, build regressor estimates, and predict.

    Creates a future dataframe with business dates (daily) or market
    hours (hourly), populates regressor columns with neutral/estimated
    future values, runs Prophet prediction, and converts results from
    log-space back to price-space. A volatility column is derived
    from the 95% confidence interval width for consistency with
    other models in the project.

    Regressor future-value strategy:
    - log_volume_ratio : 0.0 (neutral — volume at its 20-period average)
    - range_pct : recent 20-period median (mean-reverts)

    Parameters
    ----------
    model : Prophet
        Trained Prophet model.
    last_date : datetime-like
        Last date in the training data.
    horizon : int
        Number of future steps to predict.
    interval : str
        'daily' or 'hourly'.
    regressor_cols : list of str
        Regressor column names registered with the model.
    train_df : pd.DataFrame
        Training dataframe (used to compute recent regressor statistics
        for future estimation).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'trend', 'volatility']
        in price-space.
    """
    print(f"Generating {horizon} future dates (Trading Logic)...")

    future_dates = generate_future_dates(last_date, horizon, interval)

    future_df = pd.DataFrame({'ds': future_dates})

    recent = train_df.tail(20)
    for col in regressor_cols:
        if col == 'log_volume_ratio':
            future_df[col] = 0.0
        elif col == 'range_pct':
            future_df[col] = float(recent[col].median()) if col in recent.columns else 0.0
        else:
            future_df[col] = 0.0

    forecast = model.predict(future_df)

    predicted_price = np.exp(forecast['yhat'].values)
    lower_bound = np.exp(forecast['yhat_lower'].values)
    upper_bound = np.exp(forecast['yhat_upper'].values)

    ci_width = upper_bound - lower_bound
    volatility = (ci_width / (2 * 1.96)).clip(min=0.0)

    results = pd.DataFrame({
        'datetime': forecast['ds'],
        'predicted_price': predicted_price,
        'lower_bound': lower_bound,
        'upper_bound': upper_bound,
        'trend': np.exp(forecast['trend'].values),
        'volatility': volatility,
    })

    return results


# ==========================================
# 4. Main Orchestrator
# ==========================================
def run_prophet_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run Prophet prediction.

    Orchestrates data preparation (log-transform target, compute
    exogenous regressors), model training (with 95% CI, dynamic
    changepoints, and volume/range regressors), and forecast
    generation with log-to-price inverse transform.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with columns datetime, open, high, low,
        close, adj_close, volume.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns ['datetime', 'predicted_price',
        'lower_bound', 'upper_bound', 'trend', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Prophet Prediction ({interval}) ---")

    max_obs = 750 if interval == 'daily' else 500

    prophet_df = prepare_prophet_data(df, max_obs=max_obs)
    last_date = prophet_df['ds'].iloc[-1]

    model, regressor_cols = train_prophet_model(prophet_df, interval)
    results_df = generate_prophet_forecast(
        model, last_date, horizon, interval, regressor_cols, prophet_df,
    )

    print("Prophet Prediction Complete.")
    return results_df
