"""
CNN-LSTM: an LSTM stacked over a 1-D convolutional feature extractor.

Motivated by *Hands-On Deep Learning for Finance* (Troiano et al.), Chapter 7,
"Asset Allocation by LSTM over a CNN" — the hybrid the book uses for tactical
allocation, where convolutions first compress each window into local patterns
and a recurrent layer then models how those patterns evolve.

Why add it to this zoo
----------------------
The project already has four sequence architectures, but they all read the
look-back window in one particular way:

* **LSTM / GRU** consume the window step-by-step, so every bar gets equal
  attention and short local shapes must be re-learned at each offset.
* **Transformer** attends globally, which is powerful but data-hungry — the
  weakest fit for ~1000 rows.
* **TCN** convolves with dilations, so it is *all* convolution and no recurrence.
* **N-BEATS** flattens the window entirely, discarding temporal ordering inside
  the block.

CNN-LSTM occupies the remaining, genuinely distinct corner: **local translation-
invariant pattern extraction followed by temporal state**. The Conv1D stack acts
as a learned, multi-scale technical-indicator bank — a filter can key on "three
rising bars then a gap" wherever it occurs in the window — and max-pooling
shortens the sequence so the LSTM models a handful of *pattern activations* over
time rather than 90 raw bars. The shorter recurrent path is the practical
benefit: fewer timesteps means less vanishing-gradient trouble and far fewer
recurrent parameters, which is exactly what a small-sample financial series
wants.

It reuses the shared ``forecast_nn_direct`` engine, so it inherits the whole
robustness stack for free: **direct** multi-horizon targets (one output per step,
no recursive error accumulation), a training-block-only feature scaler, an
embargoed train/validation split, and per-horizon **split-conformal** prediction
intervals. Nothing about it is exempt from the project's honest read — the
first-moment evidence says a random walk is hard to beat — but it is a
cheap, architecturally distinct vote in the model comparison.
"""

import os
import warnings

import pandas as pd

from model_utils import (
    normalize_interval,
    reset_keras_seeds,
    temporal_train_val_split,
    default_keras_callbacks,
    forecast_nn_direct,
)

os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


# ==========================================
# 1. Architecture
# ==========================================
def build_cnn_lstm_model(input_shape, output_dim=1, filters=None,
                         kernel_size=None, pool_size=None, lstm_units=None,
                         dropout=None):
    """
    Build the CNN -> LSTM -> Dense regression network.

    Layer plan (the book's "LSTM over a CNN" arrangement):

    ``Conv1D(32, causal) -> BN -> ReLU -> Conv1D(64, causal) -> BN -> ReLU ->
    MaxPool -> LSTM(48, seq) -> Dropout -> LSTM(24) -> Dropout -> Dense(16) ->
    Dense(output_dim)``

    Three deliberate choices:

    * **Causal padding.** ``padding='causal'`` means a filter at position *t*
      only sees positions <= *t*. With ``'same'`` padding a convolution reaches
      forward, which would leak future bars of the window into earlier
      timesteps — harmless for a plain classifier but wrong for a time series,
      and the kind of leak that quietly inflates validation scores.
    * **BatchNorm between conv and activation.** Financial feature channels have
      wildly different scales even after min-max scaling (returns vs RSI); the
      normalisation keeps the conv stack trainable at a single learning rate.
    * **Pool once, not twice.** A single ``MaxPool1D`` halves the sequence for
      the LSTM (90 -> 45 steps) which is the point of the hybrid; pooling harder
      would start destroying the recent-bar detail that dominates a
      short-horizon forecast.

    Parameters
    ----------
    input_shape : tuple of int
        (look_back, n_features).
    output_dim : int, optional
        Number of outputs (= forecast horizon for direct multi-horizon).
    filters : tuple of int, optional
        Channel widths of the two convolution layers. Default (32, 64).
    kernel_size : int, optional
        Convolution kernel width. Default 3.
    pool_size : int, optional
        Max-pooling factor. Default 2.
    lstm_units : tuple of int, optional
        Hidden sizes of the two LSTM layers. Default (48, 24).
    dropout : float, optional
        Dropout rate after each recurrent layer. Default 0.2.

    Returns
    -------
    tf.keras.Model
        Compiled model (Huber loss, Adam with gradient clipping).
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model, Input

    # Defaults resolve from architectures.SPECS rather than the signature, so the
    # shipped network is a declared object the run manifest can record and a JSON
    # file can override. Explicit arguments still win, which keeps this usable as
    # a plain builder in tests.
    import architectures as arch
    _sp = arch.spec('CNN-LSTM')
    filters = tuple(filters if filters is not None else _sp.get('filters', (32, 64)))
    kernel_size = int(kernel_size if kernel_size is not None
                      else _sp.get('kernel_size', 3))
    pool_size = int(pool_size if pool_size is not None
                    else _sp.get('pool_size', 2))
    lstm_units = tuple(lstm_units if lstm_units is not None
                       else _sp.get('lstm_units', (48, 24)))
    dropout = float(dropout if dropout is not None else _sp.get('dropout', 0.2))

    inputs = Input(shape=input_shape)

    x = inputs
    for f in filters:
        x = layers.Conv1D(f, kernel_size, padding='causal',
                          kernel_initializer='he_normal')(x)
        x = layers.BatchNormalization()(x)
        x = layers.Activation('relu')(x)

    # Only pool when the window is long enough to spare the resolution.
    if input_shape[0] >= pool_size * 8:
        x = layers.MaxPooling1D(pool_size=pool_size)(x)

    x = layers.LSTM(lstm_units[0], return_sequences=True,
                    recurrent_dropout=0.1)(x)
    x = layers.Dropout(dropout)(x)
    x = layers.LSTM(lstm_units[1], return_sequences=False,
                    recurrent_dropout=0.1)(x)
    x = layers.Dropout(dropout)(x)

    x = layers.Dense(16, activation='relu')(x)
    outputs = layers.Dense(output_dim)(x)

    model = Model(inputs, outputs)
    model.compile(
        loss='huber',
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3, clipnorm=1.0),
    )
    return model


# ==========================================
# 2. Training wrapper
# ==========================================
def train_cnn_lstm(X, Y, output_dim=1):
    """
    Build and train the CNN-LSTM with an embargoed temporal validation split.

    Matches the other sequence models' trainer contract
    (``fn(X, Y, output_dim) -> model``) so it drops straight into
    ``forecast_nn_direct``. The embargo in ``temporal_train_val_split`` purges a
    gap equal to the horizon between train and validation, so overlapping
    multi-horizon label windows cannot leak into the early-stopping signal.

    Parameters
    ----------
    X : np.ndarray
        (n_samples, look_back, n_features) input windows.
    Y : np.ndarray
        (n_samples, output_dim) per-horizon cumulative log-return targets.
    output_dim : int, optional
        Number of outputs (= horizon). Default 1.

    Returns
    -------
    tf.keras.Model
        Trained model.
    """
    reset_keras_seeds()

    X_train, X_val, Y_train, Y_val = temporal_train_val_split(X, Y)

    print(f"Building CNN-LSTM model "
          f"({X.shape[1]} steps x {X.shape[2]} features -> {output_dim})...")
    model = build_cnn_lstm_model(X.shape[1:], output_dim=output_dim)

    print("Training CNN-LSTM...")
    model.fit(
        X_train, Y_train,
        validation_data=(X_val, Y_val),
        epochs=100,
        batch_size=32,
        callbacks=default_keras_callbacks(),
        shuffle=True,
        verbose=0,
    )
    return model


# ==========================================
# 3. Main orchestrator
# ==========================================
def run_cnn_lstm_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run CNN-LSTM prediction.

    Delegates to the shared direct multi-horizon engine, so the forecast is
    produced with one network output per step (no recursive feedback), a
    train-block-only scaler, and per-horizon distribution-free conformal
    prediction intervals.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        Columns ['datetime', 'predicted_price', 'lower_bound', 'upper_bound',
        'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting CNN-LSTM Prediction ({interval}) ---")

    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])

    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.tail(max_obs).reset_index(drop=True)

    look_back = 90 if interval == 'daily' else 48

    results_df = forecast_nn_direct(
        df, interval, horizon, look_back,
        build_train_fn=lambda X, Y, od: train_cnn_lstm(X, Y, output_dim=od),
        desc="CNN-LSTM forecasts",
        model_name='CNN-LSTM',
    )

    print("CNN-LSTM Prediction Complete.")
    return results_df
