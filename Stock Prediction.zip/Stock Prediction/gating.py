"""
Pure serving-gate logic — the layer the product's *trust* depends on.

A reviewer's point: "your product's trust depends on the gates, not only the
models." So the gate rules live here, free of Streamlit, and are unit-tested
directly (``test_gates.py``). The UI imports these; it does not re-implement them.

The rules encode the project's honest-serving contract:
* a "No edge" confidence bucket withholds the directional call,
* degraded / event-risk data forces every model to "No edge" (cone-only),
* an **off-manifold market regime** (autoencoder novelty) does the same, because
  a backtest-derived confidence bucket is an extrapolation once the present
  state is unlike anything the models were fitted on,
* conviction is the move measured in units of the model's own uncertainty, so a
  wide interval mechanically yields |conviction| < 1 ("inside the band").

The bucket rule itself lives in ``backtest.confidence_bucket`` (shared with the
offline calibration harness); this module is the *serving* layer on top of it.
"""

import numpy as np

WITHHELD_BUCKET = "No edge"
WITHHELD_DIRECTION = "–"


def gated_direction(change, bucket):
    """
    Resolve (sentiment, direction) for a model row, honouring the gate.

    When the confidence ``bucket`` is "No edge" the directional call is withheld
    — the app never asserts Bullish/Bearish on a forecast its own walk-forward
    test rates no better than a coin flip.

    Parameters
    ----------
    change : float
        Forecast price change (sign gives Bullish/Bearish when not withheld).
    bucket : str
        Confidence bucket ('High'/'Medium'/'Low'/'No edge'/...).

    Returns
    -------
    tuple(str, str)
        (sentiment, direction marker).
    """
    if bucket == WITHHELD_BUCKET:
        return WITHHELD_BUCKET, WITHHELD_DIRECTION
    if change >= 0:
        return "Bullish", "▲"
    return "Bearish", "▼"


def conviction(change, lower, upper):
    """
    Forecast move ÷ half the model's own 95% interval width.

    Same sign as the move; |conviction| >= 1 means the move exceeds the model's
    uncertainty (the current price sits outside the band). A *wide* interval
    therefore drives conviction toward 0 — the band swamps the move — which is
    exactly the "don't over-read a noisy point" behaviour the gate wants.

    Returns
    -------
    float
        Conviction, or ``np.nan`` if no usable interval is available.
    """
    if lower is None or upper is None:
        return float("nan")
    half_band = (float(upper) - float(lower)) / 2.0
    if half_band <= 0:
        return float("nan")
    return float(change) / half_band


def apply_data_quality_gate(conf_map, model_names, degraded):
    """
    On degraded/event-risk data, force every model's bucket to "No edge".

    This reuses the existing abstention machinery (``gated_direction`` keys off
    "No edge") so directional calls vanish consistently when the *input* — not
    the model — is the problem. Returns a NEW dict; inputs are not mutated.

    Parameters
    ----------
    conf_map : dict
        Mapping model name -> confidence dict (may be empty if assessment off).
    model_names : iterable of str
        Models in the current run.
    degraded : bool
        True when the data-quality gate is in 'risk_cone_only' or 'abstain'.

    Returns
    -------
    dict
        Updated confidence map.
    """
    out = {k: dict(v) for k, v in (conf_map or {}).items()}
    if not degraded:
        return out
    for name in model_names:
        entry = dict(out.get(name, {}))
        entry["bucket"] = WITHHELD_BUCKET
        entry.setdefault("note", "withheld: data quality")
        out[name] = entry
    return out


def apply_novelty_gate(conf_map, model_names, novelty):
    """
    On an **off-manifold market regime**, force every model's bucket to "No edge".

    Closes a blind spot in the existing gates. ``apply_data_quality_gate`` catches
    a broken *input*; the confidence bucket catches a model with no measured edge
    *in the past*. Neither can see that the present regime is unlike anything the
    models were fitted on — and in that situation a backtest-derived confidence
    bucket is an extrapolation, not evidence. The autoencoder novelty detector
    (``autoencoder_regime.regime_novelty``) supplies the missing signal.

    Deliberately conservative: only an ``'unprecedented'`` verdict (reconstruction
    error above the 99.5th percentile of the held-out reference distribution)
    withholds the call. An ``'unusual'`` verdict is *annotated* but left tradeable,
    because equity data is fat-tailed and a 95th-percentile window is a normal
    monthly occurrence — gating on it would abstain far too often to be useful.

    Reuses the same "No edge" mechanism as the other gates so the directional
    call disappears consistently, whatever the reason. Returns a NEW dict; inputs
    are not mutated.

    Parameters
    ----------
    conf_map : dict
        Mapping model name -> confidence dict.
    model_names : iterable of str
        Models in the current run.
    novelty : dict
        Report from ``autoencoder_regime.regime_novelty``. An unavailable or
        ``'unknown'`` report is a no-op, so the gate never fires on a failed
        novelty check.

    Returns
    -------
    dict
        Updated confidence map.
    """
    out = {k: dict(v) for k, v in (conf_map or {}).items()}
    if not novelty or not novelty.get("available"):
        return out

    verdict = novelty.get("verdict")
    if verdict not in ("unusual", "unprecedented"):
        return out

    pct = novelty.get("percentile", float("nan"))
    pct_s = f"{pct * 100:.1f}th pct" if pct == pct else "n/a"     # NaN check
    for name in model_names:
        entry = dict(out.get(name, {}))
        entry["novelty"] = verdict
        if verdict == "unprecedented":
            entry["bucket"] = WITHHELD_BUCKET
            entry.setdefault("note", f"withheld: unseen market regime ({pct_s})")
        else:
            entry.setdefault("note", f"caution: unusual market regime ({pct_s})")
        out[name] = entry
    return out


def confidence_reason(entry):
    """
    Short, auditable reason code for a model's confidence verdict.

    Ties the bucket to the DM p-value / coverage / data-quality so every row says
    *why* it got its label instead of presenting a bare bucket (or an implied
    winner). Reads a conf_map entry produced by the UI's confidence assessment.
    """
    if not entry:
        return "not assessed"
    note = entry.get("note", "")
    if "data quality" in note:
        return "withheld — data quality"
    if "unseen market regime" in note:
        return "withheld — unseen market regime"
    bucket = entry.get("bucket", "—")
    dm_p = entry.get("dm_p", float("nan"))
    cov = entry.get("coverage", float("nan"))
    imp = entry.get("improvement", float("nan"))
    p = f"DM p={dm_p:.2f}" if dm_p == dm_p else "DM n/a"        # NaN check
    cov_s = f", cov {cov*100:.0f}%" if cov == cov else ""
    imp_s = f"{imp*100:+.0f}% vs RW" if imp == imp else ""
    # An 'unusual' (but not unprecedented) regime does not withhold the call; it
    # is surfaced as a caveat on whatever verdict the skill test produced.
    suffix = " · unusual regime" if entry.get("novelty") == "unusual" else ""

    if bucket == "High":
        return f"beats random walk ({p}{cov_s}){suffix}"
    if bucket == "Medium":
        return f"weak edge ({p}){suffix}"
    if bucket == "Low":
        return f"within noise ({imp_s}, {p}){suffix}"
    if bucket == WITHHELD_BUCKET:
        return f"no edge vs random walk ({p})"
    if bucket == "N/A":
        return note or "assessment failed"
    return "—"
