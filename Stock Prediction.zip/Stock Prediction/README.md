# Stock Price Forecasting App

A multi-model stock-price forecasting toolkit built with **Streamlit**, targeting **Indian markets (NSE/BSE)** with support for global tickers. The app runs **20 forecasting models** in parallel — spanning statistical, machine-learning, deep-learning, ensemble, and foundation-model approaches — presents interactive Plotly comparisons, and ships with a **walk-forward backtesting harness** that measures every model against the only honest yardstick for stock prices: the naive random walk.

> **Disclaimer:** This project is for educational and research purposes only. Predictions are **not** financial advice.

---

## Table of Contents

1. [What this project does](#what-this-project-does)
2. [Models](#models)
3. [Project structure](#project-structure)
4. [Concepts explained](#concepts-explained) — *the educational core*
   - [The forecasting problem and what "robust" means](#1-the-forecasting-problem-and-what-robust-means)
   - [Predict log returns, not prices](#2-predict-log-returns-not-prices)
   - [Feature engineering](#3-feature-engineering)
   - [Robustness to outliers](#4-robustness-to-outliers)
   - [Recursive vs. direct multi-horizon forecasting](#5-recursive-vs-direct-multi-horizon-forecasting)
   - [Avoiding data leakage](#6-avoiding-data-leakage-look-ahead-bias)
   - [Volatility and uncertainty: GARCH + Monte Carlo](#7-volatility-and-uncertainty-garch--monte-carlo)
   - [Quantile regression](#8-quantile-regression)
   - [Conformal prediction](#9-conformal-prediction-distribution-free-intervals)
   - [The cross-family meta-ensemble](#10-the-cross-family-meta-ensemble)
   - [Model-by-model summary](#11-model-by-model-summary)
   - [Volatility forecasting with HAR-RV](#12-volatility-forecasting-with-har-rv)
   - [Confidence, abstention, and risk outputs](#13-confidence-abstention-and-risk-outputs)
   - [Validating the uncertainty (calibration)](#14-validating-the-uncertainty-calibration)
   - [Data-snooping-robust model selection (Reality Check & SPA)](#15-data-snooping-robust-model-selection-reality-check--spa)
   - [Currency conversion to INR and its audit trail](#16-currency-conversion-to-inr-and-its-audit-trail)
   - [Input data-quality gating](#17-input-data-quality-gating)
   - [Price-adjustment hygiene (adjusted vs. raw close)](#18-price-adjustment-hygiene-adjusted-vs-raw-close)
   - [Forward-looking volatility from India VIX](#19-forward-looking-volatility-from-india-vix)
   - [Downside risk: semivariance, expected shortfall, and the asymmetric cone](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)
   - [Operational robustness: reproducibility, resilient fetch, event-risk gating](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)
   - [Economic evaluation: does the forecast make money?](#22-economic-evaluation-does-the-forecast-make-money)
   - [Deep volatility forecasting (Vol-LSTM) and CNN-LSTM](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)
   - [Value-at-Risk estimation and VaR backtesting](#24-value-at-risk-estimation-and-var-backtesting)
   - [Regime novelty from a denoising autoencoder](#25-regime-novelty-from-a-denoising-autoencoder)
   - [Book coverage: what was taken, what was left, and why](#26-book-coverage-what-was-taken-what-was-left-and-why)
   - [Hyperparameter search, nested so it cannot cheat](#27-hyperparameter-search-nested-so-it-cannot-cheat)
   - [Going live: the forward prediction log and paper portfolio](#28-going-live-the-forward-prediction-log-and-paper-portfolio)
   - [Cross-sectional classification: pooling the universe](#29-cross-sectional-classification-pooling-the-universe)
   - [Testing the abstention claim: class weighting, and a t-statistic that was wrong](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong)
   - [Architecture as configuration, and the hole it closed in the manifest](#31-architecture-as-configuration-and-the-hole-it-closed-in-the-manifest)
   - [Fundamentals: the right experiment, blocked by data](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)
   - [Epistemic uncertainty and psychological tolerance (Klaas)](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result)
   - [The Kalman filter: the model class that was missing](#34-the-kalman-filter-the-model-class-that-was-missing)
   - [Feature drift and attribution](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)
   - [Fractional differentiation](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result)
   - [The Diebold-Mariano kernel fix](#37-the-diebold-mariano-kernel-fix-and-the-windows-race-it-uncovered)
   - [Universe expansion: point-in-time data, and the first positive result](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)
   - [Costing the reversal signal: the eleventh negative result](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)
   - [Range-based volatility (Sharma & Mehta Ch. 18)](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result)
   - [Open interest, and a look-ahead worth 2.9 sigma](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result)
5. [The app: from a price line to honest uncertainty](#the-app-from-a-price-line-to-honest-uncertainty)
6. [Reading the screen: which numbers support a decision](#reading-the-screen-which-numbers-support-a-decision) — *the user's guide*
7. [Evaluation and backtesting](#evaluation-and-backtesting)
8. [Empirical findings](#empirical-findings)
9. [Shared modules reference](#shared-modules-reference)
10. [Getting started](#getting-started)
11. [Dependencies](#dependencies)
12. [Caveats and limitations](#caveats-and-limitations)

---

## What this project does

- **India-first company search** — merged NSE + BSE listings with automatic ticker resolution.
- **INR normalization** — each historical bar is converted to INR at **that date's own FX rate** (`USDINR=X` etc. from yfinance), not a single current rate, so returns/volatility aren't distorted; an open.er-api.com live rate is the fallback. The app shows an **auditable notice** of which conversion path was used (period-accurate historical vs. a degraded live-uniform rescale vs. unconverted) — see [§16](#16-currency-conversion-to-inr-and-its-audit-trail).
- **Daily and hourly forecasting** with a configurable horizon.
- **20 models** compared side-by-side in one run (pick any subset), each producing a price path and — for most models — a **calibrated 95% confidence band**.
- **Honest, uncertainty-first output:** a per-model **confidence gate** (High / Medium / Low / No-edge) backed by walk-forward skill vs. a random walk, an **abstention banner** when nothing beats the baseline, and a **Risk & Probability** panel (P(up), P(gain/loss > X%), VaR-style downside, 95% range).
- **Two dedicated volatility models (HAR-RV and Vol-LSTM)** — they forecast the *risk cone* where skill genuinely exists, rather than a point price.
- **Economic as well as statistical evaluation** — the backtest reports Sharpe, Sortino, information ratio, maximum drawdown and the information coefficient **net of transaction costs**, because "low RMSE" and "would have made money" are different claims.
- **Interactive Plotly charts** with history overlay, the 95% band, and the naive random-walk baseline drawn for reference, plus a styled summary comparison table.
- **A backtesting harness** (`backtest.py`, with CLI drivers in `tests/validation/`) that walk-forward-evaluates any model on real data and reports skill metrics, a baseline ladder, and a Diebold-Mariano significance test.
- **Automatic GPU/CPU selection** — the deep models and Chronos use a GPU when one is present, and fall back to CPU otherwise.

### Robustness work baked in

This codebase went through a deliberate robustness pass. The headline changes (all explained in [Concepts](#concepts-explained)):

- Neural nets now predict **returns**, not the raw price level, with the scaler fit on **training data only** (no look-ahead).
- The tree/ML models and the neural nets forecast multiple steps **directly** instead of feeding predictions back recursively — this removed large multi-step error accumulation.
- **Conformal prediction intervals** were added so 12 of 14 base models carry calibrated uncertainty.
- A **cross-family meta-ensemble** combines the most reliable models robustly.
- **Cross-sectional market context** (market/sector/VIX features, `market_context.py`) can be fed to every family — trees, neural nets, and ARIMAX — but a controlled backtest showed it did not improve 5-day forecasts, so it ships **off by default** (opt-in). See [Empirical findings](#empirical-findings).
- **Purged/embargoed validation** removes the label-overlap that was quietly inflating early-stopping and conformal-coverage numbers.
- **NSE-exchange-calendar-aware horizons** — forecast timestamps are generated from the real NSE trading calendar (`pandas_market_calendars`), so future dates skip weekends **and** exchange holidays; hourly forecasts land on genuine session bars (09:15–15:15, ~7 per trading day) instead of a naïve 9–16h grid. The horizon is chosen in **trading days** for both frequencies — for hourly the choice maps to *days × 7* session bars internally — so "5 days" means the same thing whether you forecast daily or hourly.
- **Intraday NSE-session features (hourly)** — the tree/ML models get bar-in-session, first/last-bar flags, return-since-open, overnight gap, and same-bar-yesterday return; all leak-free and train/serve-consistent (see [§3](#3-feature-engineering)), toggleable via `USE_INTRADAY_FEATURES`.
- **History-span surfacing** — the app reports the actual hourly lookback (bars/sessions/dates) and **warns when it's short**, since intraday history is provider-capped and hourly models train on far less data than daily.
- The backtest now grades against **stronger baselines** (drift, AR(1)) and runs a **Diebold-Mariano test** so an apparent edge is checked for statistical significance, not just a smaller RMSE.
- After the evidence showed point forecasts are mostly within noise, the product **pivoted to uncertainty-as-the-deliverable**: a confidence/abstention gate, a probability/risk panel, distribution-first framing, and a dedicated **HAR-RV volatility model** with a **conformalized** (distribution-free, per-horizon) cone that is now **adaptive (ACI)** — it responds to recent volatility regime shifts.
- The **risk panel now reads probabilities off the empirical, fat-tailed conformal distribution** (P(up), P(move), VaR), instead of re-imposing a normal distribution at the output — and the **directional Sentiment/Direction call is withheld** for any model the gate rates "No edge", so the app never asserts conviction its own tests don't support.
- A **calibration harness** (`calibration.py` / `run_calibration.py`) *validates* those probabilistic claims — **CRPS, PIT, reliability/ECE, coverage quality, and nested gate validation** — so the uncertainty is measured, not asserted. See [§14](#14-validating-the-uncertainty-calibration).
- An **input data-quality gate** (`data_quality.py`) scores every fetched series *before* it is trusted — missing/duplicate/stale candles, bad OHLC, zero-volume, abnormal gaps, short hourly span, currency status — and **abstains** (or drops to **risk-cone-only**, withholding directional calls) when the data is too poor, with explicit **reason codes** surfaced in the UI. See [§17](#17-input-data-quality-gating).
- The **no-edge finding is operationalized in the UI**: every model row carries a plain-language **Basis** reason code (tied to its Diebold-Mariano p-value / coverage / data-quality), and a standing notice states that the data-snooping-robust tests found no confirmed winner — so the table is never read as crowning a "best" model. See [§17](#17-input-data-quality-gating).
- A **price-adjustment hygiene audit** (`audit_price_adjustment.py`) quantified the only remaining look-ahead the reviewers flagged (training on yfinance's back-adjusted close) and confirmed it is immaterial for this return-based pipeline. See [§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close).
- A **forward-looking volatility input** (`iv_data.py`) can tilt the HAR-RV cone by the **India VIX** implied/realized ratio — the one signal HAR-RV's backward-looking realized variance structurally can't see. Single-name option IV proved unavailable for free, so this uses the reliably-free market-level VIX scaled by each stock's market linkage; it ships **off** after an A/B showed it coverage-neutral on calm data. See [§19](#19-forward-looking-volatility-from-india-vix).
- **Downside-risk reporting** (always on): the risk panel now reports **expected shortfall (CVaR)**, the **downside/upside realized-semideviation split**, and the **vol-skew** ratio off HAR-RV's empirical residual sample — the left-tail reads a risk user actually cares about. An optional **asymmetric cone** (`asymmetric=`) widens the downside edge when the loss tail is fatter; A/B-gated, ships off. See [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone).
- **Operational robustness** (the ship-readiness layer): **seed-pinned reproducibility** with an auditable per-run manifest (`reproducibility.py`); a **resilient data fetch** with retries, last-known-good cache fallback, and a source status the gate consumes (`safe_fetch.py`); **structured event-risk reason codes** (abnormal price/volume → withhold direction, show the cone); and the serving-gate logic extracted to a pure, unit-tested module (`gating.py`). See [§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating).
- **Economic evaluation** (`strategy_metrics.py`) answers the question the statistical metrics never did — *"would acting on this forecast have made money, after costs?"* — with Sharpe, Sortino, information ratio, maximum drawdown and the information coefficient, charged for transaction costs on every position change. `walk_forward_backtest` now returns a `strategy` block alongside the RMSE table, and flags overlapping trade windows instead of quietly reporting an optimistic Sharpe. See [§22](#22-economic-evaluation-does-the-forecast-make-money).
- **VaR estimation *and* VaR backtesting** (`var_models.py`): five estimators (Gaussian, historical simulation, Cornish-Fisher, filtered historical simulation, a block-bootstrap generative sampler) plus **Kupiec's proportion-of-failures** and **Christoffersen's independence / conditional-coverage** tests. The app reported a VaR before; it never *validated* one — and clustered breaches, which only the independence test catches, are the failure mode that actually matters. See [§24](#24-value-at-risk-estimation-and-var-backtesting).
- **Two model additions where the evidence says value can exist**: **Vol-LSTM** (`vol_lstm_model.py`), a deep counterpart to HAR-RV that can express non-linear variance dynamics and the leverage effect, with the same flat-point / conformal-cone contract; and **CNN-LSTM** (`CNN_LSTM_model.py`), an architecturally distinct sequence model (causal convolutions → recurrence). See [§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm).
- **A latent HAR-RV bias, found and fixed.** Scoring the raw *variance* forecast (not just the interval) revealed that HAR-RV was over-stating volatility by **~1.9×**: it converted its log-variance forecast to a level with the log-normal Jensen correction, which assumes a Gaussian residual, but a regression on `log(r²)` has a **log-χ²** residual. The conformal layer had been silently cancelling the error — coverage was fine, the *reported* volatility was not. `forecast_har_variance` now uses a data-estimated offset (`har_level_offset`); the fix is coverage- and width-neutral, moves HAR-RV from last to second on QLIKE, and is pinned by two regression tests. See [Empirical findings](#volatility-model-comparison--and-the-latent-har-rv-bias-it-exposed-now-fixed).
- A **regime-novelty gate** (`autoencoder_regime.py` + `gating.apply_novelty_gate`): a denoising autoencoder's reconstruction error detects when the current market state is **off-manifold** relative to what the models were fitted on, and withholds the directional call. This closes a real blind spot — a backtest-derived confidence bucket describes the *past* regime and says nothing about a novel present. See [§25](#25-regime-novelty-from-a-denoising-autoencoder).
- A **regression test suite** (`test_intraday_parity.py`, `test_data_quality.py`, `test_iv_data.py`, `test_har_downside.py`, `test_reproducibility.py`, `test_gates.py`, `test_safe_fetch.py`, `test_strategy_metrics.py`, `test_backtest_strategy.py`, `test_var_models.py`, `test_novelty_gate.py`, `test_new_models_smoke.py`) locks in the highest silent-bug risks: intraday-feature train/serve parity and leak-freeness, the data-quality gate, the VIX factor, the downside/semivariance math, seeded reproducibility, the **serving gates** (abstention / no-edge / **novelty** / conviction), the resilient-fetch fallback, the economic-metric arithmetic and its cost accounting, the VaR estimators and their calibration tests, and the new models' output contract (including a check that CNN-LSTM's convolutions are causal, i.e. cannot see forward inside the window).
- Shared logic was consolidated into reusable modules (`model_utils.py`, `direct_forecast.py`, `market_context.py`, `HAR_RV_model.py`, `vol_lstm_model.py`, `calibration.py`, `data_quality.py`, `iv_data.py`, `risk_metrics.py`, `strategy_metrics.py`, `var_models.py`, `autoencoder_regime.py`, `gating.py`, `reproducibility.py`, `safe_fetch.py`).

---

## Models

| # | Category | Model | Module | Forecast strategy | Intervals? |
|---|---|---|---|---|---|
| 1 | Statistical | Auto-ARIMA + GARCH (Monte Carlo) | `ARIMA_GARCH.py` | Simulation | ✅ |
| 2 | Statistical | ARIMAX + GARCH (exogenous + market context) | `ARIMAX_model.py` | Simulation | ✅ |
| 3 | Statistical | Markov Regime-Switching AR | `RegimeSwitching_model.py` | Simulation | ✅ |
| 4 | Prophet | Facebook Prophet | `fb_prophet_model.py` | Additive decomposition | ✅ |
| 5 | Machine Learning | XGBoost | `ML_model.py` | Direct multi-horizon | ✅ (conformal) |
| 6 | Machine Learning | LightGBM | `ML_model.py` | Direct multi-horizon | ✅ (conformal) |
| 7 | Ensemble | XGB + LGB + Ridge stacking | `Ensemble_model.py` | Direct multi-horizon | ✅ (conformal) |
| 8 | Quantile | LightGBM quantile regression | `Quantile_model.py` | Direct multi-horizon | ✅ (native) |
| 9 | Deep Learning | LSTM | `DL_model.py` | Direct multi-horizon | ✅ (conformal) |
| 10 | Deep Learning | GRU | `DL_model.py` | Direct multi-horizon | ✅ (conformal) |
| 11 | Deep Learning | Transformer | `Transformer_model.py` | Direct multi-horizon | ✅ (conformal) |
| 12 | Deep Learning | N-BEATS (capacity-reduced) | `NBeats_model.py` | Direct multi-horizon | ✅ (conformal) |
| 13 | Deep Learning | Temporal Convolutional Network | `TCN_model.py` | Direct multi-horizon | ✅ (conformal) |
| 14 | Hybrid | ARIMA + LSTM on residuals | `Hybrid_model.py` | Recursive | ❌ |
| 15 | Foundation | Amazon Chronos-2 (+ covariates) | `chronos_model.py` | Native multi-step | ✅ |
| 16 | **Volatility** | **HAR-RV** (flat price + conformalized risk cone) | `HAR_RV_model.py` | Variance forecast | ✅ (conformal) |
| 17 | **Meta-ensemble** | **Median of Quantile-LGBM + XGBoost + ARIMAX** | `meta_ensemble.py` | Combination | ✅ |
| 18 | Deep Learning | **CNN-LSTM** (LSTM over a causal conv stack) | `CNN_LSTM_model.py` | Direct multi-horizon | ✅ (conformal) |
| 19 | **Volatility** | **Vol-LSTM** (deep counterpart to HAR-RV) | `vol_lstm_model.py` | Variance forecast | ✅ (conformal + ACI) |
| 20 | **State-space** | **Kalman** (damped local linear trend) | `kalman_model.py` | Filtered state, damped extrapolation | ✅ (native + conformal) |

**HAR-RV and Vol-LSTM are deliberately different:** they make *no directional claim* (their point forecast is the random walk) and their deliverable is the volatility cone — see [§12](#12-volatility-forecasting-with-har-rv) and [§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm). They will therefore show "No edge" in the confidence column by design; their value is the calibrated interval, not the price line.

Every model exposes the same entry point, `run_*_prediction(df, interval, horizon)`, and returns a DataFrame with at least `datetime` and `predicted_price` (plus `lower_bound`, `upper_bound`, `volatility` where intervals exist).

---

## Project structure

```
Stock Prediction/
├── UI.py                     # Streamlit app: model selection, confidence gate,
│                             #   risk panel, distribution-first charts, GPU label
├── get_data.py               # Data ingestion, ticker resolution, INR conversion
│
│   # ── Shared infrastructure (new) ─────────────────────────────
├── model_utils.py            # Shared helpers: features, RSI, GARCH, dates,
│                             #   conformal NN forecasting, GPU detection, training
├── direct_forecast.py        # Direct multi-horizon engine + conformal for tree models
├── market_context.py         # Market / sector / VIX context + excess-return hook (opt-in)
├── backtest.py               # Walk-forward backtest + baselines + DM test + confidence_bucket
├── data_quality.py           # Input data-quality scoring + reason-coded abstention gate
├── iv_data.py                # India-VIX forward-vol factor for the HAR-RV cone (opt-in)
├── risk_metrics.py           # Pure risk math: empirical P/VaR/CVaR/semideviation, log-normal fallback
├── strategy_metrics.py       # Economic evaluation: Sharpe/Sortino/IR/drawdown/IC, cost-aware
├── var_models.py             # VaR estimators (Gaussian/HS/CF/FHS/generative) + Kupiec & Christoffersen
├── autoencoder_regime.py     # Denoising autoencoder -> regime-novelty score for the gate
├── fracdiff.py               # Fractional differencing + ADF/KPSS stationarity testing
├── bhavcopy.py               # Point-in-time NSE prices from daily bhavcopy + corporate-action adjustment
├── range_volatility.py       # Parkinson/Garman-Klass/Rogers-Satchell/Yang-Zhang variance from OHLC
├── feature_drift.py          # Input-distribution drift (permutation-calibrated PSI + KS)
├── explain.py                # Exact TreeSHAP attribution (no new dependency)
├── kalman_model.py           # Damped local-linear-trend state-space model (native + conformal bands)
├── epistemic.py              # MC-dropout model uncertainty (off by default; failed its cross-model check)
├── fundamentals.py           # Point-in-time fundamental features + coverage audit (look-ahead-proof as-of join)
├── architectures.py          # Declarative network specs + realised-architecture record for the manifest
├── config.py                 # Feature-flag registry + serve-time tunables (STOCKAPP_* env overrides)
├── console.py                # Terminal mirror of the decision layer: startup banner, run header, run summary
├── gating.py                 # Pure serving-gate logic: gated direction, conviction, dq + novelty override, reason codes
├── reproducibility.py        # Seed pinning (all RNGs) + auditable run manifest
├── safe_fetch.py             # Resilient fetch: retries + last-known-good cache + source status
├── meta_ensemble.py          # Cross-family median meta-ensemble
│
│   # ── Tests & validation (not used by the app; kept for reference) ─
├── tests/
│   ├── conftest.py           # pytest path bootstrap (adds repo root to sys.path)
│   ├── test_intraday_parity.py   # intraday-feature train/serve parity + leak-freeness
│   ├── test_data_quality.py      # data-quality gate reason codes & modes
│   ├── test_iv_data.py           # India-VIX factor leak-freeness, bounds, fallback
│   ├── test_har_downside.py      # semivariance split, asymmetric cone, downside metrics
│   ├── test_reproducibility.py   # seed determinism + run manifest
│   ├── test_gates.py             # confidence bucket / abstention / no-edge / conviction gates
│   ├── test_safe_fetch.py        # retries, cache fallback, source status
│   ├── test_strategy_metrics.py  # Sharpe/Sortino/IR/drawdown/IC + cost-aware strategy bundle
│   ├── test_backtest_strategy.py # economic-evaluation wiring in walk_forward_backtest
│   ├── test_var_models.py        # VaR estimators + Kupiec / Christoffersen backtests
│   ├── test_novelty_gate.py      # regime-novelty gate + pure autoencoder helpers
│   ├── test_new_models_smoke.py  # Vol-LSTM / CNN-LSTM / autoencoder contract tests (slow, needs TF)
│   ├── audit_price_adjustment.py # one-shot adjusted-vs-raw-close look-ahead audit
│   └── validation/           # manual evaluation/research drivers + their libraries (CLI, network, slow)
│       ├── calibration.py          # Calibration harness lib: CRPS, PIT, reliability/ECE, gate validation, ACI/IV/asym A/Bs
│       ├── multiple_testing.py     # Lib: White's Reality Check + Hansen's SPA (data-snooping-robust selection)
│       ├── cross_sectional.py      # Lib: cross-sectional ranking probe (rank-IC, long-short)
│       ├── run_full_backtest.py    # whole-suite backtest on one ticker
│       ├── run_multi_backtest.py   # variance-aware ranking across tickers
│       ├── run_cross_sectional.py  # cross-sectional signal probe over a universe
│       ├── run_calibration.py      # validate the uncertainty (CRPS / PIT / reliability / gate)
│       ├── run_spa.py              # SPA / Reality Check — does ANY model beat the random walk?
│       ├── run_stress_test.py      # ACI vs static cone across stress (2020/2022) vs calm windows
│       ├── run_strategy_eval.py    # economic leaderboard: Sharpe/Sortino/IR/drawdown after costs
│       ├── run_var_backtest.py     # VaR method comparison + Kupiec / Christoffersen tests
│       └── run_vol_comparison.py   # HAR-RV vs Vol-LSTM vs GARCH (QLIKE / CSE + cone A/B)
│
│   # ── Models ──────────────────────────────────────────────────
├── ARIMA_GARCH.py            # Auto-ARIMA + GARCH (Monte Carlo)
├── ARIMAX_model.py           # ARIMAX + GARCH with exogenous features
├── RegimeSwitching_model.py  # Markov regime-switching autoregression
├── fb_prophet_model.py       # Prophet
├── ML_model.py               # XGBoost / LightGBM (+ shared feature engineering)
├── Ensemble_model.py         # Stacking ensemble (XGB + LGB + Ridge)
├── Quantile_model.py         # LightGBM quantile regression
├── DL_model.py               # LSTM / GRU
├── Transformer_model.py      # Time-series Transformer
├── NBeats_model.py           # N-BEATS
├── TCN_model.py              # Temporal Convolutional Network
├── CNN_LSTM_model.py         # CNN-LSTM hybrid (LSTM over a causal conv stack)
├── Hybrid_model.py           # ARIMA + LSTM hybrid
├── chronos_model.py          # Amazon Chronos-2 foundation model
├── HAR_RV_model.py           # HAR realized-volatility model (conformalized cone)
├── vol_lstm_model.py         # Vol-LSTM: deep realized-volatility model (conformal + ACI cone)
│
├── requirements.txt
├── README.md                 # This file
├── generate_docx.js          # Builds Stock_Prediction_Documentation.docx from this README's
│                             #   material — re-run `node generate_docx.js` after doc changes
├── DOCUMENTATION.md          # SUPERSEDED older per-model reference (13-model era; see its banner)
└── Stock_Prediction_Documentation.docx  # Detailed Word documentation
```

---

## Concepts explained

This section explains every important idea in the codebase from first principles. You do **not** need a finance or ML background to follow it.

### 1. The forecasting problem and what "robust" means

A **time series** is a sequence of values ordered in time (here, a stock's daily or hourly price). Forecasting means predicting future values from past ones. Stock prices are notoriously hard because they behave close to a **random walk**: the best naive guess for tomorrow's price is *today's price*. Markets are largely **efficient** — most predictable patterns are already priced in.

This has a crucial consequence: **chasing a lower price error (RMSE) is often a losing game.** A model can look "accurate" simply by echoing the last price. So in this project, *robust* does **not** mean "lowest RMSE." It means:

1. **Never blow up** — no catastrophic forecasts on any ticker.
2. **Consistently match or beat the random walk** out-of-sample, across different stocks.
3. **Quantify uncertainty honestly** — produce confidence intervals that actually contain the truth ~95% of the time.

Everything below serves those three goals.

### 2. Predict log returns, not prices

A **log return** is `r_t = ln(P_t / P_{t-1})` — the percentage change between consecutive prices, in log space. We forecast returns instead of raw prices for two reasons:

- **Stationarity.** Raw prices trend and drift (their mean/variance change over time), which violates the assumptions of most models. Returns are roughly **stationary** (stable mean near zero), which models handle far better.
- **Scale-free.** A ₹50 stock and a ₹5,000 stock have comparable return distributions, so the same model and features transfer across tickers.

To recover a price from a return: `P_t = P_{t-1} · exp(r_t)`. For a multi-step forecast we predict a **cumulative log return** `ln(P_{t+h}/P_t)` and reconstruct `P_{t+h} = P_t · exp(cumulative return)`.

Originally the neural nets predicted the *scaled price level* directly; this was changed to returns because predicting the level on near-random-walk data makes the network simply echo the last price (the "persistence trap") and pushes future prices outside the scaler's fitted range.

### 3. Feature engineering

Models that take tabular inputs (XGBoost, LightGBM, ensembles, and the neural nets) are fed engineered **features** derived only from past prices/volume, so they never peek at the future. All are **scale-invariant** (ratios, returns, normalised indicators) so they generalise across price levels. Defined in `ML_model.create_features` (tabular) and `model_utils.compute_price_features` (sequence models):

- **Log returns** over several lags (1, 2, 3, 5, 10) — short-term momentum.
- **Moving-average ratios** (price / SMA) and **SMA-short / SMA-long** — trend direction.
- **Rolling volatility** at multiple windows — recent risk level.
- **RSI (Relative Strength Index)** via Wilder's smoothing — momentum oscillator (0–100) measuring the balance of up-moves vs. down-moves.
- **MACD** (normalised) — difference of fast/slow exponential moving averages; a trend/momentum signal.
- **Bollinger-band position** and **price z-score** — how far price sits from its recent mean, in standard deviations (mean-reversion signals).
- **ATR / range** — normalised intraday range (volatility proxy).
- **Volume ratio / change** — is today's volume unusual?
- **Calendar features** — day-of-week, month, hour (hourly only) — seasonality.
- **Intraday NSE-session features (hourly only)** — `bar_in_session` (0–6), `is_first_bar` / `is_last_bar`, `ret_since_open`, `overnight_gap` (today's open vs the previous session's close), and `same_hour_prev_day_ret` (vs the same bar one session ago). These capture genuine intraday structure (open/close auction effects, the overnight gap, intraday seasonality) that day-level features miss. They're **leak-free** (current-and-past only) and **train/serve-consistent** — computed identically in the vectorized `create_features` and the scalar `_features_from_buffers` (NSE sessions are 7 contiguous hourly bars, so "*N* bars back = same bar of an earlier session" is exact). They apply to the **tree/ML family** and can be A/B'd via `ML_model.USE_INTRADAY_FEATURES`.

The neural nets use a compact 9-feature matrix (price, log return, SMA ratio, two volatilities, RSI, momentum, z-score, acceleration), all computable from a price buffer so the same definitions apply during training and prediction. (The intraday-session features above are tree/ML-only — the NN feature matrix is datetime-less by construction.)

**Cross-sectional market context (`market_context.py`).** All of the features above are *self-referential* — derived from the stock alone. But short-horizon returns are dominated by the **market**: a stock's next move is mostly its **beta** times the index move plus a smaller stock-specific (alpha) component. Withholding the market is withholding the most predictable part of the return. So the pipeline fetches a market index (NIFTY 50 by default) and a volatility index (India VIX) and attaches eight **causal** context columns to the data once, up front:

- `mkt_ret_1`, `mkt_ret_5` — contemporaneous and trailing-5 index log return,
- `excess_ret_1` — stock return minus market return (an **alpha** proxy),
- `rel_strength_20` — trailing 20-period stock-minus-market strength,
- `beta_60`, `corr_60` — rolling 60-period beta and correlation to the index,
- `vix_change`, `vix_z_60` — volatility-index change and rolling z-score (a fear/regime gauge).

Because `create_features` carries extra columns through and `horizon_feature_cols` treats any non-raw, non-target column as a feature, the **tree, ensemble, and meta models consume these automatically**. The **neural nets** get the same context (concatenated onto their feature matrix inside `forecast_nn_direct`), and **ARIMAX** takes `mkt_ret_1`/`vix_change` as **exogenous regressors**. Every feature is contemporaneous or trailing (no look-ahead), missing index data is filled with a neutral 0 so context can never truncate the stock history, and if the index can't be fetched the data passes through unchanged.

> **Empirical caveat — this is off by default.** A controlled A/B backtest on Indian tickers (where NIFTY is the *correct* proxy) showed these features **did not improve 5-day forecasts** and **made the single tree models worse** (extra overfitting surface at this horizon — see [Empirical findings](#empirical-findings)). They therefore ship **disabled** (`USE_MARKET_CONTEXT = False` in `config.py`; `--with-context` flag on the backtest drivers). For a non-Indian ticker the NIFTY/India-VIX defaults are only an approximate proxy ([caveats](#caveats-and-limitations)).

> **Excess-return reframing was also tried — and also didn't help.** The reviewers' deeper idea was to predict the *excess* return (stock − market) instead of the absolute return (`market_context.add_market_index` attaches an `mkt_index` column; the direct target builders then subtract the market's cumulative return). A controlled A/B showed it **did not improve absolute-price RMSE** (it hurt the tree singles and was neutral for the ensemble). This is expected: because the expected short-horizon market move is ~0, reconstruction re-injects the unforecastable market noise, so the price error can't shrink unless de-noising made the alpha dramatically more learnable — which, on single stocks at a 5-day horizon, it didn't. It is therefore **off by default too** (no `mkt_index` is attached unless you opt in). The broader lesson: **market data helps cross-sectional/ranking problems, not single-stock absolute-price forecasting at this horizon.**

### 4. Robustness to outliers

Financial returns have **fat tails** — extreme moves happen far more often than a normal distribution predicts. Three defences are used:

- **Winsorization** (`model_utils.winsorize`) — clip values at the 1st/99th percentiles so a single crash/spike doesn't dominate training. The clip bounds can be fit on the training block only (`winsorize_bounds`) and reused on later data, keeping the preprocessing free of look-ahead bias.
- **Huber loss** — a loss function that behaves like squared error for small errors but like absolute error for large ones, so outliers don't dominate the gradient. Used by the gradient-boosting and neural models.
- **Fat-tailed GARCH innovations** — the volatility models can use Student-t / skewed-t distributions (see §7).

### 5. Recursive vs. direct multi-horizon forecasting

To forecast `h` steps ahead there are two strategies:

- **Recursive (iterative):** predict one step, append the prediction, recompute features, predict the next step, and so on. Simple, but **errors compound** — each step's mistake feeds into the next — and it can drift badly over the horizon.
- **Direct:** train the model to predict step `h` *directly* from the **observed** data at the origin (no feedback). For each horizon `h` we use the cumulative-return target `ln(P_{t+h}/P_t)`. Either train one model per horizon (tree models) or one network with `h` outputs (neural nets).

This project **switched the tree/ML models and the neural nets from recursive to direct**, which was the single biggest robustness win. In the backtest the gradient-boosted models improved ~25–34% in RMSE and moved from "worse than the random walk" to beating it. (Direct forecasting also implicitly fixed a one-bar origin offset that the recursive path had.)

- Tree models: `direct_forecast.py` (`make_horizon_targets`, `training_frame`, `compute_origin_row`).
- Neural nets: `model_utils.forecast_nn_direct` (a single network with `Dense(horizon)` outputs).

### 6. Avoiding data leakage (look-ahead bias)

**Data leakage** is when information from the future sneaks into training, inflating apparent accuracy and producing models that fail in the real world. Two specific fixes:

- **Scaler fit on training rows only.** A `MinMaxScaler` learns each feature's min/max. Originally it was fit on the *entire* series — including the validation period — leaking the future feature range. It is now fit on the **training portion only**, then applied to validation/recent data.
- **Targets are strictly future, features strictly past.** Rolling features use only past windows; the prediction target is a future return. For model *selection* the harness uses **walk-forward** splitting (see §[Evaluation](#evaluation-and-backtesting)), not random k-fold (which leaks across the time boundary).
- **Purged / embargoed validation for overlapping labels.** The direct multi-horizon target `ln(P_{t+h}/P_t)` spans `h` future bars, so the *last* training samples and the *first* validation/calibration samples share overlapping future windows — an overlap that quietly makes early-stopping `val_loss` and conformal coverage look better than reality. The pipeline now drops an **embargo gap** of `h` samples between the train block and the held-out block at all three internal split points: `temporal_train_val_split` (NN early stopping), `forecast_nn_direct` (NN conformal calibration), and `conformal_halfwidth` (tree conformal calibration). This is the same "purging" idea used in financial ML, applied wherever a future-spanning label is held out.

### 7. Volatility and uncertainty: GARCH + Monte Carlo

Stock volatility **clusters** — calm and turbulent periods come in runs. **GARCH** (Generalized Autoregressive Conditional Heteroskedasticity) models this: it predicts that tomorrow's variance depends on recent squared shocks and recent variance.

The statistical models (`ARIMA_GARCH`, `ARIMAX_model`) fit GARCH on the residuals and select the best variant by **BIC** (Bayesian Information Criterion, which rewards fit while penalising complexity) among:

- **GARCH** (symmetric), **GJR-GARCH** and **EGARCH** (asymmetric — "bad news" raises volatility more than "good news"),
- with **Normal, Student-t, skewed-t, GED** innovation distributions (the fat-tailed ones capture extreme moves).

Forecasts are then generated by **Monte Carlo simulation** (`model_utils.simulate_price_paths`): simulate thousands of future return paths through the fitted dynamics, build price paths, and read off the **median** (point forecast) and the **2.5th/97.5th percentiles** (95% interval). This naturally produces wider intervals in volatile regimes.

### 8. Quantile regression

Instead of predicting the mean, **quantile regression** predicts a specific percentile. `Quantile_model.py` trains three LightGBM models per horizon — for the **2.5th, 50th (median), and 97.5th** percentiles of the cumulative return — using the **pinball loss**. The median is the point forecast; the outer two form a native 95% interval whose width grows with horizon. Unlike a Gaussian "±1.96σ" band, this makes no symmetry/normality assumption.

### 9. Conformal prediction (distribution-free intervals)

Many models output only a point forecast. **Conformal prediction** wraps *any* model to produce a calibrated interval, with minimal assumptions. The split-conformal recipe used here:

1. Hold out a recent **calibration** block the model didn't train on (with an **embargo gap** of `h` bars before it, so the future-spanning labels don't overlap — see §6).
2. Measure the model's **errors** (residuals) on that block, **per horizon step**.
3. The (1−α) quantile of those absolute residuals is the interval **half-width**; the band is `forecast · exp(±half-width)` in return space.

Because stock data is not exchangeable (it has trend and changing volatility), the split is **temporal** (calibrate on the most recent block) and the half-width is computed **per horizon**, so intervals widen with horizon. This was added to:

- the tree/ML models — `direct_forecast.conformal_halfwidth` (a separate calibration fit per horizon), and
- the neural nets — inside `model_utils.forecast_nn_direct` (one calibration pass per held-out window).

Coverage is then *checked empirically* by the backtest (does the "95%" band really contain ~95% of outcomes?).

### 10. The cross-family meta-ensemble

The multi-ticker backtest showed there is **no universal winner**: tree models won some stocks, statistical models won others. So `meta_ensemble.py` combines **different model families** — Quantile-LGBM and XGBoost (tree) plus ARIMAX+GARCH (statistical) — and aggregates them with the **median** of the per-horizon point forecasts.

The median is deliberate: it is **robust to a single model misfiring**, which is exactly the failure mode (one family doing badly on a given ticker). Confidence bounds are averaged across the constituents. The result tracks whichever family suits the current ticker without needing to know which in advance, and it degrades gracefully if a constituent fails.

### 11. Model-by-model summary

- **ARIMA + GARCH** — Auto-ARIMA models the linear autocorrelation of returns; GARCH models the volatility; Monte Carlo produces the forecast and interval. Strong, stable, near-flat point forecasts.
- **ARIMAX + GARCH** — ARIMA plus **exogenous regressors** (volume ratio, range, RSI, momentum, calendar). Often the best statistical model.
- **Regime Switching** — a **Markov** model with hidden bull/bear (low-/high-volatility) states, each with its own mean and variance; forecasts via regime-aware simulation.
- **Prophet** — additive decomposition into trend + seasonality + holidays (log-space). Easy to use but can over-extrapolate trends — see [caveats](#caveats-and-limitations).
- **XGBoost / LightGBM** — gradient-boosted decision trees on the engineered features; **direct multi-horizon** with **conformal** intervals. Among the most robust models.
- **Stacking Ensemble** — XGB + LGB + Ridge base learners combined by a Ridge meta-learner trained on **out-of-fold** (leakage-safe) predictions; direct multi-horizon + conformal.
- **Quantile-LGBM** — native probabilistic intervals via quantile regression; consistently the most robust single model in the backtest.
- **LSTM / GRU** — recurrent neural networks that learn temporal patterns; now **direct multi-horizon** (multi-output) with conformal bands.
- **Transformer** — self-attention sequence model with causal masking; direct multi-horizon + conformal.
- **TCN** — dilated causal convolutions with skip connections; direct multi-horizon + conformal.
- **N-BEATS** — fully-connected residual stack; **capacity-reduced** (64 units × 2 blocks) after the original 256-unit version overfit badly; direct multi-horizon + conformal.
- **Hybrid ARIMA + LSTM** — ARIMA captures the linear part, an LSTM models the non-linear residual.
- **Chronos-2** — Amazon's pretrained time-series **foundation model**, run zero-shot with engineered covariates.
- **HAR-RV** — a volatility model (see §12); flat point forecast + a conformalized risk cone.
- **Meta-Ensemble** — the median combination described in §10.

### 12. Volatility forecasting with HAR-RV

The backtest taught the central lesson of this domain: at single-name daily/hourly horizons the **return** (the price *direction*) is essentially a random walk — no feature set reliably beat it. But the **second moment** is different: **volatility clusters and is genuinely forecastable** (it's the same property GARCH exploits). So `HAR_RV_model.py` adds a model that stops pretending to predict the price and instead forecasts the *risk*.

**HAR-RV** (Heterogeneous AutoRegressive model of Realized Volatility, Corsi 2009) explains today's (log) realized variance with its own **daily, weekly, and monthly** lagged averages — three horizons of memory that capture volatility's long persistence with just four OLS parameters. The model:

1. builds a realized-variance series from the bar returns,
2. fits the HAR regression and rolls it forward to get a per-step **log**-variance forecast,
3. converts log → level with a **data-estimated offset** (`har_level_offset`), sums the step variances (variance is additive) to get the cumulative variance to each horizon, and
4. wraps a **flat (random-walk) price path** in a `last_price · exp(±k · √cum_var)` band.

Step 3 is subtler than it looks and was originally wrong. Exponentiating the mean of `log(r²)` does not give the variance: writing `r = σ·z`, `log(r²) = log(σ²) + log(z²)` and `E[log z²] = −1.27` for Gaussian `z`. The textbook repair — the log-normal Jensen correction `exp(μ + σ²_resid/2)` — assumes a **Gaussian** residual, but this residual is **log-χ²**, with variance `π²/2 ≈ 4.93`, so that correction over-shot and inflated volatility by a measured **~1.9×**. The offset is now estimated from the data instead (`c = log(mean RV) − mean(log RV)`), which recovers 1.27 on Gaussian returns and self-adjusts for fat tails. The bug was invisible for a long time because the conformal layer in step 4 cancels it; see [Empirical findings](#volatility-model-comparison--and-the-latent-har-rv-bias-it-exposed-now-fixed) for how the variance-forecast scoring in `run_vol_comparison.py` surfaced it.

It makes **no directional claim** — embodying the honest position that the point forecast is unforecastable but the cone is not. The multiplier `k` is **conformalized per horizon**: rather than the textbook normal `1.96` (which under-covers because returns are fat-tailed), `k_h` is the empirical quantile of recent *cumulative* standardized residuals, so the band is distribution-free and calibrated to the realized h-step move. A useful diagnostic falls out of this: if the fitted `k_h` sits far *below* 1.96, the variance forecast it is correcting is probably biased high — which is precisely how the level bug announced itself.

**Adaptive (ACI) refinement (default on).** A static `k_h` is the quantile of the *whole* calibration pool — it can't tell that the *recent* stretch has been systematically under-covering (a volatility regime shift), which is the exact failure the backtest exposed. So the cone now applies **Adaptive Conformal Inference** (Gibbs & Candès 2021): walking the calibration residuals in time order it updates the miscoverage level `α_{t+1} = α_t + γ(α* − err_t)` — a run of misses (high-vol regime) drives `α` down → a higher quantile → a **wider** cone; a run of easy covers tightens it. Because `α` carries memory, the value at the end of the stream is recency-weighted, so the live multiplier reflects the *current* regime, not the long-run average. It's a parameter (`adaptive=True`, `aci_gamma`) on `run_har_rv_prediction`, so the calibration harness can A/B it (see [Empirical findings](#empirical-findings)). On a calm window it can slightly over-tighten an already-well-calibrated name; its upside is regime response — discussed in [caveats](#caveats-and-limitations).

### 13. Confidence, abstention, and risk outputs

Because the backtest showed most point "wins" are within noise, the app treats **uncertainty as the deliverable**, not the price line:

- **Confidence gate** — at request time the app runs a quick walk-forward backtest for each model and labels it **High / Medium / Low / No edge** from its RMSE improvement over the best naive baseline, the **Diebold-Mariano** p-value, and interval coverage (the rule is `backtest.confidence_bucket`, the single source of truth shared with the offline validation harness — see [§14](#14-validating-the-uncertainty-calibration)). Low/No-edge means *"use the range, not the point."*
- **Abstention banner** — when *no* model reliably beats the random walk for the chosen ticker/horizon, the app says so prominently rather than presenting a confident-looking line.
- **Gated directional call** — the **Sentiment / Direction** columns are *withheld* ("No edge", "–") for any model the gate labels "No edge", so the app never asserts a Bullish/Bearish view off a point forecast its own test says is no better than a coin flip.
- **Risk & Probability panel (read off the empirical, fat-tailed distribution).** **P(up)**, **P(gain > +X%)**, **P(loss > X%)**, the **VaR-style 5% downside**, and the 95% **range** are counted *directly from HAR-RV's conformal residual sample* — the genuine fat-tailed distribution — not from a normal approximation. (Earlier versions re-imposed a log-normal at this last step, discarding exactly the tails the conformal machinery had estimated; that is fixed.) When no fat-tailed model (HAR-RV) is in the run, the panel falls back to a log-normal read of each model's interval and **says so explicitly** in the caption. The panel also reports the **downside-specific** reads — **expected shortfall (CVaR)**, the **downside/upside semideviation split**, and the **vol-skew** ratio — off the same empirical sample (see [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)).
- **Distribution-first charts** — every chart draws the **naive random-walk baseline** next to the forecast and frames the band as the plausible-outcome cone.

These reframe the same underlying models around what they actually know.

### 14. Validating the uncertainty (calibration)

A probabilistic product is only honest if its probabilities are **calibrated** — a "95%" interval that covers 80% of the time, or a "P(up)=70%" that is right 55% of the time, is worse than silence. `calibration.py` (driver: `run_calibration.py`) is the validation harness for exactly this. It does *not* add a model; it checks the claims the app already makes, with standard proper tools:

- **CRPS** (Continuous Ranked Probability Score) — the gold-standard *proper* score for a full predictive distribution; it jointly rewards calibration **and** sharpness (lower is better, generalises MAE to distributions). Reported per horizon, and — crucially — **empirical-sample CRPS vs log-normal-approximation CRPS side by side** for HAR-RV, so the value of the fat tails is *measured*, not asserted.
- **PIT** (Probability Integral Transform) — `F_pred(actual)` should be Uniform(0,1) if the distribution is calibrated; a U-shape means over-confident (too narrow), a hump means too wide. Summarised by a KS distance to uniform.
- **Reliability / ECE** — bins predicted **P(up)** and **P(move > X%)** and compares to the realised frequency; the Expected Calibration Error says whether "70%" really means 70%. (P(up) reliability is meaningful for *directional* models; HAR-RV's is ~0.5 by design.)
- **Coverage quality, not just coverage** — coverage *and* mean interval width, their efficiency ratio, and the lower/upper **tail-miss balance** (misses skewed downside ⇒ the cone underestimates crash risk).
- **Gate validation** — a nested walk-forward assigns each origin a confidence bucket from *past-only* data (the same `backtest.confidence_bucket` the UI ships) and measures the realised next-horizon skill, so you can check that "High" actually beats "No edge" out-of-sample rather than being theatre.

An illustrative single-ticker run (RELIANCE.NS, 5-day horizon) is summarised in [Empirical findings](#empirical-findings); the headline is that HAR-RV's **empirical fat-tailed CRPS beats its log-normal approximation**, confirming the risk-panel fix in §13 helps the proper score and is not just principled.

### 15. Data-snooping-robust model selection (Reality Check & SPA)

The Diebold-Mariano test (§"Is the edge real?") is **pairwise** — it asks whether *one* model beats the random walk. But the app compares **17 models** across several tickers, and picking the best-looking one reintroduces the very bias DM guards against: with enough candidates, one wins by luck. `multiple_testing.py` (driver: `run_spa.py`) closes that gap with the standard data-snooping corrections, both over a **stationary bootstrap** (Politis–Romano) of the aligned loss differentials, with the block length chosen automatically from the data (Politis–White 2004):

- **White's Reality Check** (2000) — bootstraps `max_k √T · mean(loss_benchmark − loss_model_k)` under the least-favourable null. Conservative; used as the headline verdict here.
- **Hansen's SPA** (2005) — studentizes (Newey–West HAC) and applies the *consistent* recentering that drops hopeless models from the null, so it's more powerful. Reported as a companion; it can be mildly liberal at small sample, so a borderline SPA rejection that the Reality Check doesn't confirm is treated as unconfirmed.

H0 for both: *no model in the set beats the benchmark.* The experiment unit is the **forecast origin** (one mean loss per origin), not the within-horizon step, so the bootstrapped events are near-independent. This is the rigorous capstone to the DM work: it answers the honest question **"after trying K models, is there evidence that *any* of them genuinely beats the random walk?"** The result is in [Empirical findings](#empirical-findings).

### 16. Currency conversion to INR and its audit trail

The app is INR-centric but can forecast foreign-listed names, so prices are converted to INR in [`get_data.py`](get_data.py). The conversion is **period-accurate by default**: it fetches the historical FX series (`USDINR=X`, `EURINR=X`, …) and converts **each bar at its own date's rate**, so a 2019 price uses the 2019 rate and a 2026 price uses the 2026 rate. This matters — converting the whole history at one current rate would leave day-to-day *returns* unchanged but distort the *level* path the volatility models see. Weekend/holiday gaps are forward/back-filled from the nearest trading day.

There are two fallbacks, used only when the historical series can't cover the data: a few un-coverable early dates are filled with **today's** rate, and if the whole historical fetch fails, the entire series is rescaled by today's rate (a degraded mode). If even the live rate fails, prices are left unconverted.

Because those fallbacks change what the ₹ numbers *mean*, every fetch carries an **audit tag** (`df.attrs['fx_conversion']`) recording the path taken, and the UI renders it above the results:
- **historical** → a quiet caption ("converted at each date's own historical rate; latest ≈ ₹X/USD");
- **live-uniform** → a **warning** that historical *levels* are rescaled and not period-accurate;
- **unconverted** → an **error** that the ₹ labels don't apply.

This makes the conversion reviewer-auditable rather than invisible. (Building this audit trail also surfaced and fixed a latent bug where a `DataFrame.drop` call threw before the conversion ran, silently returning foreign prices labelled as INR — see [caveats](#caveats-and-limitations).)

**Scope note — this is a dormant safety net.** The company selector is built **only from NSE + BSE listings** (`get_data.company_list`), so every selectable stock is **quoted in INR already** and the conversion path is *never* taken in normal use (the audit tag reads `none`). `_convert_to_inr` can only fire for a foreign ticker reached via the API-search fallback for a name *not* in the dropdown — an edge case the UI doesn't expose. Consequently there is **no FX applied to an Indian hourly series at all**, so intraday-FX granularity is moot for this product; it would only matter if the universe were ever widened to foreign listings. The audit tag exists precisely so that, *if* that dormant path ever fires, it is surfaced loudly rather than silently mislabelling prices.

### 17. Input data-quality gating

A forecast is only as trustworthy as the data feeding it, and the source here is yfinance — which can serve stale candles, missing bars, zero-volume rows, or (rarely) inconsistent OHLC. A weak prediction caused by *bad data* is indistinguishable, in the output, from one caused by a weak *model* — unless you check. So `data_quality.py` scores every fetched series **before** any model output is trusted, and makes data quality part of the gate (the discipline both reviewers asked for).

`assess_data_quality(df, interval, horizon)` runs a battery of pure checks and returns a structured report — a 0–100 score, a tier, a serving **mode**, and a list of **reason codes** (each with a severity and a human message):

- **Insufficient / thin history** — fewer bars than needed to fit and walk-forward-assess a horizon-step forecast (interval-aware floor).
- **Short hourly window** — provider-capped intraday history below ~100 sessions.
- **Duplicate / unsorted timestamps** — would corrupt feature construction.
- **Missing / non-positive prices** — NaNs or ≤ 0 levels that break log-return modeling.
- **Bad OHLC bars** — `high < low`, or close outside the bar's range.
- **Zero-volume bars** — illiquidity / halts (fraction-based).
- **Stale last candle** — the feed hasn't updated within the expected cadence.
- **Calendar gap** — a genuine data hole, measured in *calendar days* against an interval-aware threshold so normal overnight/weekend/holiday gaps don't false-flag.
- **Abnormal recent jump** — a large robust-z return spike in the last few bars (possible unadjusted corporate action or event risk).
- **Currency status** — reads `get_data`'s `fx_conversion` audit tag (degraded → warn, unconverted → critical).

The reason codes drive a **serving mode**, not just a number:

| Mode | When | UI behaviour |
|---|---|---|
| `normal` | clean data | forecast as usual |
| `warn` | minor caveats | forecast with a data-quality warning |
| `risk_cone_only` | a non-fatal critical (illiquidity, bad bars) | **withhold directional calls**, steer to the risk cone |
| `abstain` | a fatal flaw (insufficient history, stale feed, unconverted currency, non-positive prices) | **don't present a directional forecast** |

In the app, a degraded gate forces every model's confidence bucket to **"No edge"**, reusing the existing abstention machinery so directional calls vanish consistently, and a 🩺 banner plus an expandable per-check list make the verdict auditable. This is wired alongside the existing skill gate and the SPA/Reality-Check framing: **every model row now shows a plain-language *Basis* reason code** (e.g. "no edge vs random walk (DM p=0.42)", "withheld — data quality"), and a standing notice states that the data-snooping-robust tests found **no confirmed winner** — so the comparison table is never read as crowning a "best" model. The gate's behaviour is covered by `test_data_quality.py`.

### 18. Price-adjustment hygiene (adjusted vs. raw close)

A reviewer flagged a subtle potential leak: yfinance retro-adjusts its `Adj Close` series for **all** splits and dividends, including ones that occur *after* a given bar, and this whole pipeline models log returns off `adj_close`. Could a past bar therefore "know" about a future corporate action? `audit_price_adjustment.py` measures it directly on real NSE names, and the answer is **no — it is immaterial for this pipeline**, for three concrete reasons:

1. **Live serving has zero leak.** At serve time the latest bar's adjustment factor is 1.0, so only actions that have *already* happened are baked in — exactly the information a real user would have.
2. **The leak is confined to corporate-action bars** (≈ 0.4–1.6 % of bars in the audited sample). On those exact bars the *adjusted* return is the economically-correct value (it removes the artificial split/dividend price jump); on every other bar the adjusted and raw returns are **identical**, so every scale-invariant feature (returns, ratios, RSI, volatility, z-scores) is unchanged.
3. **The level distortion cancels where it matters.** Past *price levels* can be rescaled by up to ~10–18 % at the oldest origin, but the models forecast *log returns* and the metrics that drive the gate (Diebold-Mariano, SPA, MASE) are scale-invariant, so a piecewise rescale of levels cancels in every model-vs-baseline comparison.

Switching to *raw* close would be **worse**: it would inject fake ~2–3 % jumps at every ex-dividend/split date as if they were real returns, corrupting volatility and RSI. Using the adjusted (total-return) series is the correct choice for return modeling; the residual look-ahead is documented rather than "fixed" because fixing it (point-in-time re-adjustment per origin) would buy nothing measurable here. The audit script is kept so the claim is reproducible.

#### The fallback path was a different story

All of the above concerns the **primary** yfinance path, which was correct. The **nselib daily fallback** — which fires only when yfinance returns nothing, and does fire, because NSE renames leave yfinance with no quote at all (`TATAMOTORS` → `TMPV`) — was not. Being the least-exercised code in the fetch layer and the only module with **no test coverage**, it had accumulated four defects:

1. **`AveragePrice` was mapped to `adj_close`.** That column is **VWAP**, not a close, and it is **completely unadjusted**. Across CESC's 10:1 split it yields a **−89.5%** one-day return in the exact column this section argues so carefully about — a far worse version of the "fake 2–3% jump" the design explicitly rejects.
2. **No `Series` filter.** Before ~2003 several names traded in two series simultaneously, so the pull returned **two rows per date** — 442 of RELIANCE's 6,863 rows. Duplicate dates corrupt every rolling window downstream.
3. **Unsorted output**, not monotonic in either direction.
4. **`datetime` returned as a string** where the yfinance path returns `datetime64`.

Measured against yfinance's `Adj Close` on RELIANCE over 2,879 overlapping days:

| | Return correlation | Worst-day gap |
|---|---|---|
| Before (VWAP as `adj_close`) | **0.527** | **69%** |
| After | **0.996** | 8% |

Mean absolute return difference is now **0.000035**. `close` comes from `ClosePrice`, VWAP is retained as its own `vwap` column rather than discarded, and `adj_close` is built from NSE's corporate-action feed via [`bhavcopy`](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) — **one request, ~4 s** for 26 years, measured before committing to the design.

**The residual 8% is a single day: 2023-07-20, the Jio Financial demerger.** Demergers are deliberately not handled — the correct adjustment depends on the listed value of the spun-off entity, which the action feed does not carry — so this is a named gap rather than a guess.

**Degradation is declared, not hidden.** If the action feed is unreachable, `adj_close` falls back to the raw close *and* `attrs['price_adjustment']['adjusted']` is set `False` with the reason. Serving unadjusted prices under the name `adj_close` without saying so was the original bug; failing silently would have recreated it in a new form. 14 offline tests in `tests/test_nselib_fallback.py` pin all of it.

This is also where the §38 research module pays back into the product: `bhavcopy.corporate_actions` and `adjust_prices` were built to measure model skill honestly, and they are what makes the fallback correct.

### 19. Forward-looking volatility from India VIX

HAR-RV's cone is built entirely on **realized** (backward-looking) variance — it forecasts future risk from how volatile the recent past was. The one thing it structurally *cannot* see is what the market **expects** next, which is exactly what option-**implied** volatility encodes. Injecting implied vol was a reviewer's strongest remaining idea, precisely because it targets volatility (where skill exists) rather than direction (where the SPA/Reality-Check tests proved there is none).

**The honest data-feed finding.** True **single-name** NSE option-chain IV is **not freely or reliably available**: NSE's own API is bot-protected (HTTP 403 without a real browser session; empty bodies from data centres), `nselib`'s wrapper fails the same way, and yfinance serves no options for `.NS` tickers. Building a single-name IV scraper would be fragile, frequently-empty dead code — so, consistent with this project's discipline, it was **not** built. What *is* reliably free is **India VIX** (`^INDIAVIX`), NSE's forward-looking implied-vol index for NIFTY — a plain quote, already referenced by the market-context module.

So `iv_data.py` uses India VIX to tilt the cone with the *systematic* slice of forward vol:

- `F = (VIX-implied market daily vol) / (NIFTY recently-realized daily vol)` — the market's **implied/realized** ratio. `F > 1` ⇒ the market prices in *more* forward vol than recently realized (widen the cone); `F < 1` ⇒ calmer ahead (tighten).
- `w = R²` of the stock vs NIFTY — its **systematic variance share** (how market-linked it is; `beta` cancels in the ratio `F`).
- `m = clip(1 + w·(F − 1), [0.85, 1.30])` — the forward-vol multiplier applied to the cone's cumulative sigma (so the band **and** the empirical risk distribution stay consistent).

It is **leak-free** — every VIX/NIFTY lookup is "as of" the last bar of the passed frame, so a walk-forward origin only ever sees the VIX that existed then (verified in `test_iv_data.py`) — and every failure path returns a no-op multiplier of 1.0.

**The honest A/B verdict (ships off).** Run through the calibration harness (`compare_iv_adjust`) on RELIANCE / TCS / INFY, the tilt was **coverage-neutral on the calm 2021–2026 window** (RELIANCE slightly *worse*, the other two unchanged), because in calm regimes implied ≈ realized so the multiplier barely moves. Even with origins **concentrated in the 2020 COVID crash** it stayed coverage-neutral while correctly **widening** the cone (~1.4 pp) as VIX spiked — the right *direction*, but no measurable coverage payoff on the available data. So, exactly like market-context and excess-return, it ships **off by default** (`USE_IV_ADJUST = False`, or `iv_adjust=` on `run_har_rv_prediction`): a principled, forward-looking, opt-in research feature, not a claimed win. See [Empirical findings](#empirical-findings).

### 20. Downside risk: semivariance, expected shortfall, and the asymmetric cone

A risk user does not care equally about both tails — they care about **how bad the bad case is**. Symmetric volatility treats a +5% and a −5% move as the same; for a risk instrument that is the wrong emphasis. This project adds three left-tail-specific reads, all built on HAR-RV's existing empirical conformal residual sample (so they inherit its fat tails, no Gaussian).

**Realized semivariance (the foundation).** Realized variance splits into a **downside** and an **upside** half — `RS⁻ = Σ r²·1{r<0}`, `RS⁺ = Σ r²·1{r>0}`, with `RS⁻ + RS⁺ = RV` (Barndorff-Nielsen, Kinnebrock & Shephard 2010). Patton & Sheppard (2015, *"Good Volatility, Bad Volatility"*) show the *downside* half carries most of the predictive content for future volatility. HAR-RV exposes the recent **downside share** (`attrs['downside_share']`) for transparency.

**Always-on downside reporting (the user-facing win).** The Risk & Probability panel now adds, alongside VaR and the 95% range:
- **Expected shortfall (CVaR, worst 5%)** — the *average* outcome given you are already in the worst 5% tail ("if it's a bad day, how bad on average"), a more honest left-tail number than VaR, which is only the threshold.
- **Downside vol / upside vol** — the realized **semideviation** split (dispersion of down-moves vs up-moves).
- **Vol skew** — their ratio; **> 1** means the downside is the fatter side of this stock's outcome distribution.

These are pure *reporting* of the distribution HAR-RV already estimates (no model change, no skill claim), so they are always on whenever a fat-tailed model is in the run. The math lives in the Streamlit-free `risk_metrics.py` and is covered by `test_har_downside.py`.

**The asymmetric cone (opt-in, A/B-gated).** Going one step further, the cone itself can be made **asymmetric** (`asymmetric=True`): instead of a symmetric `exp(±k·σ)` band, the lower and upper edges get **separate multipliers** from the left- and right-tail quantiles of the signed residuals (each at the one-sided level, static or via one-sided ACI), so a fatter loss tail produces a wider *downside* edge. On a single recent RELIANCE fit this correctly pushed the downside to −8.1% while pulling the upside to +4.7% (vs a symmetric ±~8%). But an A/B on calm 2021–26 data was **mixed on tail-miss balance** (better for INFY, worse for RELIANCE/TCS): splitting the calibration into two half-size per-side samples adds estimation noise when the residuals are near-symmetric, which is the common case in calm regimes. So — consistent with the project's discipline — the asymmetric cone ships **off by default** (`USE_ASYMMETRIC_CONE = False`); it is a principled opt-in that should pay off under genuine, persistent skew. See [Empirical findings](#empirical-findings).

**Why not a full HAR-RS forecast?** Feeding downside semivariance into the HAR *regression* (a "good vol / bad vol" forecast) is the natural extension, but it requires forecasting the semivariance components forward recursively, and — as the IV and asymmetric-cone A/Bs both showed — changes to the *central* variance forecast move the empirically-conformalized cone's coverage very little. So it is deliberately left as documented future work rather than built speculatively.

### 21. Operational robustness: reproducibility, resilient fetch, event-risk gating

Two independent reviews converged on the same conclusion: the *forecasting* question is closed (the four killed experiments — market context, excess returns, IV tilt, asymmetric cone — collectively confirm the SPA wall), so the remaining robustness is **operational and presentational**, not more modeling. This section is that layer — making the app reliable, auditable, and honest about its serving behaviour.

**Seed-pinned reproducibility + run manifest (`reproducibility.py`).** `set_all_seeds` pins every RNG (`random`, NumPy, TensorFlow, PyTorch-if-present) from one call at the start of each run, so a forecast is reproducible given the seed — and the NN path now goes through the same call (it previously seeded only TF/NumPy). `run_manifest` records the seed, interpreter and key package versions, the run parameters, the data's as-of date, and a UTC timestamp; the UI surfaces it in a **"Run details (reproducibility)"** expander. This doesn't make markets predictable — it makes your *experiments auditable*.

**Resilient data fetch (`safe_fetch.py`).** Because the app fetches live from yfinance, a transient empty response or rate-limit must not silently produce a degraded forecast that *looks* healthy ("a weak prediction can come from bad fetch behaviour, not model weakness"). `fetch_with_fallback` wraps the fetch with bounded **retries + exponential backoff**, empty/error detection, **partial-data detection**, and a persistent **last-known-good disk cache**. Every result carries `attrs['source']` ∈ {`live`, `partial`, `cached_fallback`}, which the data-quality gate turns into a reason code: a **cache-fallback serve is downgraded to risk-cone-only** (the directional call is withheld until live data returns), surfaced in the UI as *"Live fetch failed; using cached data (~N days old). Forecast downgraded to risk-cone-only."*

**Structured event-risk reason codes (`data_quality.py`).** Beyond the earlier abnormal-jump check, the gate now also flags an **abnormal recent volume spike** (latest bar ≫ its 20-bar median). Both are price/volume-only **event-risk** signals (no fragile news/earnings scraping). When either fires, `event_risk` is set and the serving mode drops to **risk-cone-only** — a known event makes the *direction* especially unreliable while the *cone*, widened around the event, is exactly what should be shown. The UI banner reads *"Event risk detected — showing the risk cone, not directional calls."*

**The serving gates are a pure, tested module (`gating.py`).** The product's trust lives in the gates, not the models, so the gate rules were extracted from the UI into a Streamlit-free module and unit-tested directly (`test_gates.py`): the directional call is withheld when the bucket is "No edge"; degraded/event-risk/cache-fallback data forces every model to "No edge"; conviction is the move measured in units of the model's own band (so a *wide* interval mechanically yields |conviction| < 1 — "inside the band"); and a weak Diebold-Mariano p-value can never produce a "High" confidence. Together with the existing reproducible-seed and resilient-fetch layers, the result is the controlled-serving behaviour the reviewers identified as the only robustness still open:

```
Good data + validated edge → directional forecast + interval + confidence
Good data + no edge        → random-walk price + HAR-RV/ACI risk cone
Bad data                   → abstain or risk-cone-only
Event / cache-fallback     → widen + withhold direction (cone only)
Many models, SPA no winner → never imply a "best model"
```

### 22. Economic evaluation: does the forecast make money?

Everything in §14–§15 is a *statistical* score — RMSE, MASE, CRPS, Diebold-Mariano, SPA. None of them answers the only question a user of a forecast actually has: **would acting on it have made money, after costs?** `strategy_metrics.py` closes that gap with the metric set from *Hands-On Deep Learning for Finance* Ch. 3 ("Evaluating investment strategy"): cumulative and monthly returns, the **information coefficient**, the **information ratio**, **Sharpe** and **Sortino**, and **maximum drawdown**.

The distinction is not cosmetic. RMSE is dominated by the *magnitude* of quiet periods; P&L is dominated by the *sign* on the few large moves. Neither is a monotone function of the other, so a model can win on RMSE and lose money — or the reverse. And transaction costs act as a hard filter that no statistical metric applies: a 52% directional hit rate at a 5-day horizon is worthless once you pay ~10 bps per round trip.

**How the conversion works.** `evaluate_strategy` takes the per-origin (predicted, realised) horizon-end log returns, maps the forecast to a **position** (`sign`, `deadband`, or `scaled`), computes gross P&L, then charges cost on `|Δposition|` — so a long→short flip costs two one-way trades and staying put costs nothing. Everything downstream (Sharpe, Sortino, drawdown, information ratio vs **buy-and-hold over the identical periods**) is computed on the net stream, with the gross figures reported alongside so the cost drag is visible.

Three deliberate design points:

- **`deadband` mode is the economic twin of the abstention gate.** Only trade when the claimed move clears the round-trip cost hurdle. It is the same "don't act on a signal smaller than your uncertainty" logic that `gating.conviction` applies to the interval.
- **Sortino, not just Sharpe.** Sharpe punishes upside and downside dispersion equally, which is the wrong penalty for an asymmetric return distribution — the same reasoning that motivated the semivariance work in [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone).
- **Overlap is flagged, not hidden.** `walk_forward_backtest` now returns a `strategy` block, and if the origin spacing is shorter than the horizon the trades overlap, the return stream is serially dependent and every risk-adjusted figure is optimistic. The harness sets `overlapping_origins=True` and prints a caveat rather than reporting a prettier Sharpe.

**Every Sharpe travels with its standard error.** A Sharpe computed from a handful of non-overlapping trades has an enormous sampling error, and quoting the point estimate alone invites reading noise as skill. `sharpe_standard_error` uses Lo (2002) — `SE ≈ √((1 + SR²/2)/n)` per period, **annualised by √(periods/year)** — and `sharpe_significant` reports whether the estimate clears 2 SE. The annualisation is the load-bearing part: a bare `1/√n` understates the error by `√(periods/year)`, so at 8 weekly trades it would report ±0.35 when the true figure is **±2.5**. That is the difference between "Sharpe 3.2 looks great" and "Sharpe 3.2 is 1.3 SE from zero".

**Expected result, stated up front.** Given `run_spa.py`'s verdict (White's Reality Check *p* = 0.899, Hansen's SPA *p* = 0.874 — no model has a selection-bias-free edge), the honest expectation is **Sharpe ≈ 0, negative after costs, and nothing statistically distinguishable**. That is the metrics working, not failing. A strongly positive Sharpe on a handful of origins is a **red flag to investigate** — overlapping trades, too few origins, a leak — before it is a discovery. `run_strategy_eval.py` therefore prints Sharpe ± SE and a significance flag next to every model, and reports the **rank correlation between the RMSE ranking and the Sharpe ranking** to show how differently the two order the same models.

**First run on real data** (RELIANCE.NS, 5-day horizon, 8 non-overlapping origins, 10 bps/side, `--fast` subset) — illustrative, tiny sample:

| Model | RMSE | MASE | Total ret % | Sharpe | Sortino | Max DD % | IC (t) |
|---|---|---|---|---|---|---|---|
| RegimeSwitching | 23.97 | 1.72 | **+7.39** | **3.20** | 7.28 | −2.43 | n/a |
| Ensemble-Stack | **22.59** | 1.58 | −1.83 | −0.69 | −0.88 | −4.80 | 0.33 (0.86) |
| ARIMAX+GARCH | 23.90 | 1.72 | −2.53 | −0.94 | −1.22 | −5.09 | 0.46 (1.27) |
| XGBoost / LightGBM | 26.3 | 1.89 | −7.39 | −3.37 | −3.50 | −9.83 | ≈0 |
| Quantile-LGBM | 27.31 | 2.00 | −8.42 | −4.02 | −3.99 | −10.42 | 0.04 (0.10) |
| ARIMA+GARCH | 23.96 | 1.73 | −9.13 | −4.26 | −4.11 | −9.54 | −0.25 (−0.63) |

(Buy-and-hold returned −7.30% over the same periods.) **Six of seven models lose money**, and the one that does not — RegimeSwitching at Sharpe 3.20 — sits well inside its own ±2.5 standard error, i.e. **statistically indistinguishable from zero**; `sharpe_significant` is `False` for every row. The tree models are the worst economically, mirroring their position in the SPA table. The RMSE↔Sharpe rank correlation was **+0.45** — positively related but far from identical, confirming that the two tables genuinely order the models differently and that reporting only one of them would be misleading. All of this is consistent with the SPA result rather than in tension with it.

### 23. Deep volatility forecasting (Vol-LSTM) and CNN-LSTM

Two model additions drawn from the book, chosen to sit where this project's evidence says value can exist.

**Vol-LSTM (`vol_lstm_model.py`) — Ch. 5, "Volatility Forecasting by LSTM."** The book's chapter builds an LSTM on realized volatility and benchmarks it against a plain RNN and **GARCH** using the cumulative squared error. That is the right place to spend a neural network here: the first moment is a random walk at these horizons (§15), but volatility clusters and is genuinely forecastable — which is exactly why HAR-RV and the GARCH layer earn their place. Vol-LSTM is therefore the **deep counterpart to HAR-RV**, and honours the same contract: flat random-walk point path, conformalized cone as the deliverable, `run_*_prediction(df, interval, horizon)` signature.

What it can express that HAR-RV cannot:

| | HAR-RV | Vol-LSTM |
|---|---|---|
| Inputs | 3 linear lags of log-RV (day / week / month) | a 60-bar window of 5 causal channels |
| Parameters | 4 (OLS) | ~15k (2 stacked LSTM layers, 48/24 units) |
| Non-linearity | none | yes |
| Leverage effect | no (symmetric in the sign of returns) | **yes** — a signed-return channel lets a −3% day imply more future variance than a +3% day |
| "Bad volatility" | reported, not used | a downside-share channel is an input |

The HAR averages are handed to the network as explicit channels rather than left to be rediscovered from raw lags — a cheap inductive bias that matters a lot on ~1000 rows. Capacity is deliberately modest, because N-BEATS already taught this codebase what an over-parameterised network does to a ~700-row window.

**One numerical detail worth knowing.** The network predicts the mean of `log(r²)`, and exponentiating that mean does **not** give the conditional variance: with `r = σ·z`, `log(r²) = log(σ²) + log(z²)` and `E[log z²] = −1.27` for Gaussian `z` (the mean of a log-χ²(1)). The classic Jensen fix `exp(μ + σ²_resid/2)` is *also* wrong here, because the residual is log-χ² rather than Gaussian — with a residual variance near `π²/2 ≈ 4.93` it over-corrects by an order of magnitude in variance terms, roughly doubling the reported volatility. Vol-LSTM instead estimates the level offset from the training block directly (`c = log(mean RV) − mean(log RV)`), which reproduces the theoretical 1.27 on Gaussian data and self-adjusts for the percentile clipping and for genuinely fat tails. The effect is visible in the conformal multipliers: with the debiased level they land near the Gaussian 1.96, instead of ~0.9 (a multiplier well below 1.96 is the tell-tale sign that the cone is silently compensating for a mis-scaled variance forecast — the *interval* stays calibrated either way, but the reported per-step volatility does not).

**CNN-LSTM (`CNN_LSTM_model.py`) — Ch. 7, "Asset Allocation by LSTM over a CNN."** The zoo already had four sequence architectures, but each reads the look-back window one particular way: LSTM/GRU step through every bar equally; the Transformer attends globally (the most data-hungry option on ~1000 rows); the TCN is all convolution and no recurrence; N-BEATS flattens the window and discards ordering. CNN-LSTM occupies the remaining corner — **local translation-invariant pattern extraction, then temporal state**. The Conv1D stack acts as a learned multi-scale indicator bank (a filter can key on "three rising bars then a gap" *wherever* it appears in the window), and one max-pool halves the sequence so the LSTM models a handful of pattern activations over 45 steps rather than 90 raw bars — fewer recurrent parameters and a shorter gradient path, which is what a small-sample series wants.

Convolutions use `padding='causal'`, not `'same'`: with `'same'` a filter reaches *forward*, leaking future bars of the window into earlier timesteps. Harmless for an image classifier, wrong for a time series, and precisely the kind of leak that quietly inflates a validation score. `test_new_models_smoke.py` asserts the padding.

Both models reuse the shared engines (`forecast_nn_direct` for CNN-LSTM; HAR-RV's ACI machinery for Vol-LSTM's cone), so they inherit direct multi-horizon targets, training-block-only scaling, embargoed validation, and per-horizon conformal intervals for free — and any future improvement to those layers lands in them automatically.

### 24. Value-at-Risk estimation and VaR backtesting

Book Ch. 9 ("Risk Measurement Using GAN") opens with "Estimating value at risk" and "Computing methods and drawbacks" and closes with "Benchmarking results". `var_models.py` implements that arc, and in doing so fixes a real gap: the app already *reported* a 5% VaR and expected shortfall off HAR-RV's conformal residuals ([§13](#13-confidence-abstention-and-risk-outputs)), but nothing ever **validated a VaR number**. Interval coverage checks the two-sided 95% cone — a different question from *"does the left tail break exactly 5% of the time, and are the breaks independent?"*

That second clause is the one that matters. A VaR model can have textbook-perfect unconditional coverage and still be useless because every breach arrives in the same week — clustered breaches are what actually destroy a position.

**The estimators, and the drawback each one answers:**

| Method | Idea | Known drawback |
|---|---|---|
| **variance-covariance** | Gaussian quantile of `μ`, `σ` | equity returns are leptokurtic → systematically **under**-reserves; √t scaling assumes i.i.d. |
| **historical simulation** | empirical quantile of past returns | **unconditional** — a calm estimate persists into a crisis; noisy tail (5% of 250 bars = 12 points) |
| **cornish-fisher** | Gaussian quantile shifted by sample skew/kurtosis | asymptotic in the moments; **and it moves the wrong way at α = 5%** — see below |
| **FHS** (filtered historical simulation) | standardise by EWMA σ → bootstrap the residuals → rescale by the *current* σ | needs a volatility filter; MC noise |
| **generative** | block-bootstrap sampler (contiguous blocks preserve clustering *and* autocorrelation) | not a marginal-only sampler; GAN arm available but see below |

**The Cornish-Fisher trap (a real finding from running this).** The expansion's kurtosis term scales with `z³ − 3z`, which is **positive** for `|z| < √3 ≈ 1.732` — and the 5% quantile sits at `z = −1.645`, *inside* that range. So when excess kurtosis is large enough to dominate the skew term, the "fat-tail correction" makes the 5% quantile **less** negative and *reduces* the reserve, which is the opposite of the intuition. On RELIANCE's full history (excess kurtosis ≈ 50) this drove the 5% exception rate to 10.8% against a 1.45% average reserve — comfortably the worst method in the table — while at α = 0.5% the sign flips and the same expansion widens dramatically. Cornish-Fisher therefore ships as a documented **cautionary reference point**, not a recommendation; `test_var_models.py` pins both halves of the behaviour so the surprising row in the driver output reads as a known property rather than a suspected bug.

**On the GAN.** The chapter's technique is a GAN over returns. The idea is sound but, applied to a single stock, it hits a hard data limit worth stating plainly: a GAN on ~1000 daily returns is fitting a distribution from a sample that is small even for a histogram. In practice it mode-collapses or memorises, and its **tail — the only region VaR cares about — is where it is least trustworthy**. That is a bad trade for a risk number. So the default generator is the stationary block bootstrap (Politis & Romano): generative in the sense that matters (novel paths with the right dependence), no training, cannot mode-collapse, reproducible. `prefer_gan=True` opts into a compact 1-D GAN for comparison, imports TensorFlow lazily, and falls back silently on any failure — so enabling it can never break a caller, but its tail should be checked with `backtest_var` before it is trusted.

**Expected Shortfall is backtested too.** Every estimator reports `es_return` next to `var_return`, and an early version of this module validated only the VaR — repeating, one level down, exactly the criticism it was written to answer. `acerbi_szekely_z2` (Acerbi & Székely 2014) closes that. ES is famously **not elicitable**, so it has no scoring function that pins it down the way a quantile loss pins down VaR; the Z2 test sidesteps that by conditioning on the breaches actually observed. `Z2 < 0` means realised tail losses were **worse** than the ES promised (the dangerous direction); `Z2 > 0` means the model was conservative. Significance comes from a bootstrap under the null, and getting that null right is the whole trick — see the note below. `backtest_es` and `compare_es_methods` mirror the VaR harness. Read the two tables together: **a method can pass Kupiec (right breach *frequency*) while failing Z2 (breaches far *worse* than promised)**, and that combination is precisely the one that quietly under-reserves a portfolio.

> **A bug worth recording.** The first Z2 implementation built its H0 bootstrap by resampling the *observed* exceedance severities — which already encode the model's mis-calibration. The null therefore centred on the observed failure (measured: −1.045 instead of ~0), so the test could never reject on severity and reported **p = 1.00 for a model whose realised tail was 1.9× its predicted ES**. The pool is now re-centred to unit mean, imposing H0 while preserving the observed dispersion. After the fix, on fat-tailed data the Gaussian ES is correctly rejected (severity ratio 1.88, p = 0.0015) while historical simulation passes (severity ratio 1.01, p = 0.16); on genuinely Gaussian data all methods pass. `test_es_null_distribution_is_centred_at_zero` pins it.

**The VaR backtests.** `kupiec_pof_test` (proportion of failures, χ²(1)) asks whether the breach *rate* is right; `christoffersen_independence_test` (χ²(1)) asks whether the breaches are **clustered**, by testing `π₀₁ = π₁₁` in a first-order Markov chain on the exception indicator; `christoffersen_conditional_coverage` sums the two on χ²(2) for the joint verdict. `backtest_var` runs a rolling out-of-sample harness (each estimate sees only past bars) and `compare_var_methods` ranks every method on one history. `avg_var_loss` is printed next to every *p*-value on purpose: a model can pass coverage by simply reserving an enormous amount, and the width is what that safety cost. Run it with `python tests/validation/run_var_backtest.py TICKER [--alpha 0.01]`.

### 25. Regime novelty from a denoising autoencoder

Book Ch. 4 ("Index Replication by Autoencoders") builds a vanilla autoencoder and then explores the **denoising** and **sparse** variants. `autoencoder_regime.py` implements all three on one architecture — but *not* for the obvious purpose.

**What it deliberately does not do.** The tempting use of an AE in a forecasting pipeline is dimensionality reduction: compress the feature window to a latent code and feed that to the predictor. This project has already run that experiment in a different guise and reported the answer honestly — market-context features and excess-return reframing both **hurt or did nothing** ([Empirical findings](#empirical-findings)), because at a 5-day single-name horizon the first moment is a random walk and extra representation capacity is mostly extra overfitting surface. Adding a learned compression in front of a model that cannot beat a random walk would be more of the same. So `latent_codes()` exists as an available research function and is wired into **no** forecaster.

**What it does instead.** An autoencoder trained on one regime reconstructs that regime well and anything else badly, so reconstruction error is a **distribution-shift detector** — and that plugs straight into the layer that carries this project's value, the serving gate. The app already abstains on degraded data (`data_quality`) and on models with no measured edge (`gating`). What it could not see is *"today's market state is unlike anything these models were fitted on"*. A backtest-derived confidence bucket is a statement about the **past** regime; it says nothing about a novel present. That blind spot is what this closes.

`regime_novelty` returns a verdict from the reconstruction error's percentile in a held-out reference distribution:

| Percentile | Verdict | Gate action |
|---|---|---|
| < 95th | `familiar` | none — normal confidence machinery applies |
| 95th–99.5th | `unusual` | **annotated only** (`"· unusual regime"` in the Basis column) |
| > 99.5th | `unprecedented` | `gating.apply_novelty_gate` forces every model to **"No edge"** |

The threshold split is deliberately conservative: equity data is fat-tailed and a 95th-percentile window is a normal monthly occurrence, so gating on it would abstain far too often to be useful.

**It is wired into the app**, behind `USE_REGIME_NOVELTY` in `config.py` (cached per company/interval, since the answer is identical for every model in a run) and applied immediately after the data-quality gate. It ships **off by default** for the same reason the IV tilt and the asymmetric cone do — on the calm 2021–26 window it should almost never fire, so its value cannot be demonstrated there, and an unvalidated feature does not ship on in this project. Every failure path returns `verdict='unknown'`, a no-op for the gate, so turning it on can only ever make the app *more* conservative.

**Three properties keep it honest.** *(1) Leak-free by construction* — the AE is fitted on the earliest 70% of windows, its reference error distribution is measured on a held-out middle 20% it never saw (in-sample errors are systematically too small and would make *everything* look novel), and only then is the latest window scored; inside a walk-forward backtest an origin-truncated frame yields a genuinely out-of-sample read. *(2) Scale-free* — windows come from the shared `compute_price_features` matrix and are standardised on training statistics, so a ₹100 and a ₹4000 stock give comparable numbers. *(3) Never fatal* — TensorFlow is imported lazily and every failure path returns `verdict='unknown'`, which is a no-op for the gate.

The denoising variant is the load-bearing one: with a generous bottleneck a vanilla AE happily learns a near-identity map, which makes it a poor novelty detector. Injecting Gaussian noise during training only (and reconstructing the *clean* input) forces the network onto the data manifold, which is what makes an *off-manifold* window's error large. `cone_multiplier` (bounded to 1.0–1.5) is offered as a widening suggestion but applied **nowhere automatically** — the HAR-RV/Vol-LSTM cones are conformally calibrated, and silently multiplying a calibrated interval by an uncalibrated factor would break the guarantee that makes it useful. Treat it as a research knob to A/B, like the India-VIX tilt.


### 26. Book coverage: what was taken, what was left, and why

The additions in §22–§25 came from *Hands-On Deep Learning for Finance* (Troiano et al.). That book has 13 chapters and only five fed into this codebase, so this section records the whole triage — including the items that are **still open**, because a partial reading presented as a complete one is the same failure mode this project spends the rest of its documentation avoiding.

| Ch. | Topic | Status here |
|---|---|---|
| 1 | Deep learning for finance 101, autoencoder warm-up | Folded into §25 |
| 2 | Designing neural network architectures (MLP, CNN, RNN, LSTM, GRU) | Already covered by the existing model zoo |
| 3 | **Evaluating investment strategy** (IC, IR, Sharpe, Sortino, drawdown) | **Implemented** — §22 |
| 3 | **Tuning the model** (grid / random / Bayesian search) | **Implemented** — §27, nested; found no generalising gain |
| 3 | **Going live** (paper portfolios, benchmarking live vs model) | **Implemented** — §28 |
| 4 | **Index replication by autoencoders** (vanilla / denoising / sparse) | **Implemented**, repurposed as a novelty gate — §25 |
| 5 | **Volatility forecasting by LSTM** (vs RNN, vs GARCH, cumulative sq. error) | **Implemented** — §23 |
| 6 | **Trading rule identification by CNN** (3-class, asset-stratified) | **Implemented** — §29 (tabular GBM, not a CNN; reason given there) |
| 7 | **Asset allocation by LSTM over a CNN** | **Implemented** — §23 |
| 8 | Digesting news using NLP with BLSTM | Skipped — needs a licensed news feed; the same "fragile, frequently-empty dead code" argument that killed single-name option IV ([§19](#19-forward-looking-volatility-from-india-vix)) applies |
| 9 | **Risk measurement using GAN** | **Implemented**, via FHS + block bootstrap rather than a GAN — §24 |
| 10 | Chart visual analysis by transfer learning (ResNet50) | Skipped — rendering price windows as images to reuse ImageNet features discards the numeric precision the models already have; a well-documented dead end for tabular series |
| 11 | Better chart analysis using CapsNets | Skipped — exotic, little independent replication, and the project's own evidence is that *more* capacity is the wrong direction here |
| 12 | Training trader robots using deep RL (DQN) | Skipped — RL needs either a simulator or vastly more data than one ticker's history, and it optimises a *directional* policy, which [§15](#15-data-snooping-robust-model-selection-reality-check--spa) says has no edge to find |
| 13 | What next? (AutoML, distributed training, HFT) | AutoML overlaps the tuning gap; the rest is infrastructure, not modelling |

All three of the genuine gaps flagged in the original triage have since been closed: hyperparameter tuning in [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat), the forward paper-portfolio log in [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio), and cross-sectional classification in [§29](#29-cross-sectional-classification-pooling-the-universe). The original reasoning is kept below, because *why* each was deprioritised is as much a part of the record as the eventual result.

**1. Hyperparameter tuning (Ch. 3, pp. 128–135) — since closed, see [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat).** Every model in this repo carried **hardcoded** hyperparameters: XGBoost's `max_depth=5, learning_rate=0.03`, the LSTM's `64/64/32`, Vol-LSTM's `48/24`, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search. The book covers grid search, random search — noting that random beats grid at equal budget, because grid re-tests irrelevant factors along its regular lattice — and Bayesian optimisation (SMBO/TPE), which directs the search using a surrogate model instead of treating each trial as independent.

The honest counter-argument, and the reason it was deprioritised rather than forgotten: with the SPA verdict at *p* = 0.87, tuning is very likely to buy a *better-fit* model rather than a *predictive* one, and a search run against a walk-forward objective on ~40 origins is an efficient way to manufacture exactly the data-snooped edge [§15](#15-data-snooping-robust-model-selection-reality-check--spa) exists to detect. If it is built, it must be **nested** (inner search on past data only, outer evaluation untouched — the structure `calibration.validate_gate` already uses) and its winner must be run through `run_spa.py` before any improvement is believed. The place it is most likely to genuinely pay is **Vol-LSTM and HAR-RV's window lengths**, since volatility *is* forecastable and those windows were picked by convention, not measurement.

**2. Classification + asset stratification (Ch. 6) — since closed, see [§29](#29-cross-sectional-classification-pooling-the-universe).** The chapter frames trading as **3-class classification** (buy / do nothing / short) over a 30-day horizon, trained across **2,700 NASDAQ stocks** with an *asset-stratified* split — fit on 700 names, validate on 300 entirely different ones. Two things here are absent from this project:

- **There is no classifier at all.** Every model regresses a price or a variance, and P(up) is derived second-hand from a regression interval. The calibration harness measured that derived probability at **ECE ≈ 0.31 — badly overconfident** ([Empirical findings](#empirical-findings)). A purpose-built classifier with isotonic or Platt calibration is the standard fix, and an explicit "do nothing" class is a natural fit for a product whose central feature is *abstention*.
- **Pooling across a universe attacks the actual binding constraint.** Every "no edge" result here rests on ~1000 rows for one ticker. The book's stratification turns that into millions of rows and validates on unseen *assets*, which is a stronger generalisation claim than unseen *time*. This project's own cross-sectional probe ([§ cross-sectional](#empirical-findings)) found 12-1 momentum with the right sign but *t* ≈ 1, and explicitly concluded it needs **hundreds of names** — Chapter 6 is the recipe for exactly that. It is a deliberate product fork (rank a universe, don't forecast one name), which is why it was not slipped in as a tweak.

**3. Going live: paper portfolios and live-vs-model benchmarking (Ch. 3, pp. 135–142) — since closed, see [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio).** `prediction_log.py` now writes an append-only forward log at serve time, resolves realised outcomes as horizons mature, and reports live coverage drift, live gate validation and a paper portfolio. The remaining unimplemented parts of that chapter (soft launch, capital commitment, compliance sign-off) are organisational rather than technical and are out of scope for this codebase.


### 27. Hyperparameter search, nested so it cannot cheat

Book Ch. 3's "Tuning the model" (pp. 128–135) covers grid search, random search — noting that **random beats grid at equal budget**, because a regular lattice keeps re-testing values of parameters that turn out not to matter — and Bayesian optimisation (SMBO/TPE), which directs the search with a surrogate model instead of treating every trial as independent. `tuning.py` implements all three.

Until now, **every model here carried hardcoded hyperparameters**: XGBoost's `max_depth=5, learning_rate=0.03`, the LSTM's `64/64/32`, Vol-LSTM's `48/24`, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search.

**Why a naive search would have been worse than none.** With the SPA verdict at *p* = 0.87, a search over *N* configurations evaluated on the same origins you later report is an efficient machine for manufacturing exactly the snooped edge [§15](#15-data-snooping-robust-model-selection-reality-check--spa) exists to detect: 50 configurations is 50 more chances for noise to look like skill. So the module has two **structural** guards, not optional ones:

1. **`nested_search` is the only entry point that produces a reportable number.** The search sees a training prefix (default 70%); the tail is untouched during the search and scored exactly twice at the end — once for the tuned config, once for the **default**. The output therefore answers *"did tuning help out of sample?"*, not *"what fit best in-sample?"*, and an inner win with a holdout loss — the signature of overfitting the search itself — is made visible rather than hidden behind a single best-score number.
2. **Every result carries its own selection-bias warning**, naming the number of configurations tried and pointing at `run_spa.py` as the required next step. A search result is a hypothesis, not a finding.

**TPE, and a bug worth recording.** The Bayesian sampler is a ~40-line Tree-structured Parzen Estimator (no GP library, replacing the book's `hyperopt` import): split the trials into a good set (best γ fraction) and a bad set, model `p(param | good)` and `p(param | bad)` as smoothed histograms, then sample from the good distribution and keep the candidate maximising `l(x)/g(x)` — equivalent to maximising Expected Improvement.

The first version took the deterministic argmax over sampled candidates and **collapsed**: once a configuration looked best it was proposed again and again. Measured on a 10×10 space it burned **12 of 30 trials on a single point** and finished *worse than random search* (−1.845 vs −1.296). Suppressing already-evaluated candidates (with a random unseen fallback) restores the exploration a continuous-space TPE gets for free:

| Sampler | Budget | Mean best score over 6 seeds |
|---|---|---|
| Random | 30 trials | −1.429 |
| **TPE (after the fix)** | 30 trials | **−0.001** |
| Grid (exhaustive) | 100 trials | −0.092 |

TPE at 30 trials now beats an exhaustive 100-trial grid, because the grid can only ever land on lattice points. `test_tpe_beats_random_at_equal_budget` pins the ordering.

**What it was pointed at, and what happened.** Not the price models — the honest expectation there is a better-fitting model with the same absent edge. The promising target is the **volatility** side, where signal demonstrably exists and the windows were picked by convention: HAR-RV's canonical Corsi lags `(1, 5, 22)` have never been measured on NSE names. `qlike_objective_har` scores the *variance forecast* (not the cone — the conformal layer adapts to whatever the variance does, which is how the 1.9× level bias hid for so long) using QLIKE, the loss robust to `r²` proxy noise. The result is [§ below](#does-tuning-har-rvs-lags-help-no-the-fifth-negative-result).

### 28. Going live: the forward prediction log and paper portfolio

Book Ch. 3's "Going live" (pp. 135–142) walks prototype → transition → **paper portfolio** → soft launch, with continuous **benchmarking of live results against model diagnostics**. `prediction_log.py` implements the parts that apply to a single-user app.

**Every evaluation before this one was backward.** Pick historical origins, re-fit, score against what already happened. That is the right way to *build* a model and an inadequate way to *operate* one, because it can only tell you how the model would have done on data that already existed when you tested it. Nothing recorded what the app **actually served**, leaving three questions unanswerable:

1. **Is the cone still calibrated?** A conformal interval is calibrated at fit time and decays silently as the regime moves. Coverage on 2021–26 backtest origins says nothing about coverage on what was served last month.
2. **Did the confidence gate work?** Buckets are assigned *before* outcomes exist, so whether they sorted realised skill is checkable only against outcomes that arrived afterwards.
3. **Would the served signals have made money?** [§22](#22-economic-evaluation-does-the-forecast-make-money) simulates a portfolio backwards over chosen origins; a paper portfolio runs what the app really emitted, in order, with no origin selection at all.

**Why append-only is the whole point.** A prediction is written before its outcome exists and is never rewritten — only annotated with the realised price once that price is knowable. That single property makes the resulting numbers immune to the data-snooping the rest of this project works hard to correct: no origin selection, no re-fitting, no choice of which forecasts to count. Every served forecast is in the sample, including the embarrassing ones. `test_resolution_never_rewrites_the_prediction_itself` pins it.

**What it records.** One JSONL row per (run, model, horizon step), including the **gate verdicts in force at serve time** — confidence bucket, data-quality mode, novelty verdict. Without that context the log could say whether forecasts were accurate but not whether the *gates* were doing their job, which is the more valuable question for a product whose central feature is abstention.

**Alerting that can be trusted.** `drift_report` compares live coverage to the nominal 95% with a binomial CI and **fires only when the CI excludes the target**. Below that bar the sample cannot distinguish drift from noise, and an alert that fires on noise teaches people to ignore alerts. It also isolates the most recent N predictions per model, so a year of good coverage cannot bury five misses in the last ten. Verified end-to-end: an honest cone (0.933, CI [0.87, 1.00]) stays silent; a deliberately over-confident one (0.083, CI [0.01, 0.15]) fires with a "recalibrate before trusting it" message.

> **A third self-inflicted bug, caught the same way.** `gate_validation`'s monotonicity check was `hits[i] <= hits[i+1]` — which **every tie satisfies**. An end-to-end run where both buckets had identical realised accuracy (0.517 vs 0.517) was duly reported as *"the gate IS informative"*. A gate that discriminates nothing being declared a success is precisely the over-claim this project exists to avoid. It now requires a strict spread (`_GATE_MIN_SPREAD`) and reports **"FLAT — the labels are not discriminating yet"** otherwise. `test_flat_gate_is_not_declared_informative` fails against the old behaviour.

**It ships ON** (`USE_PREDICTION_LOG` in `config.py`), unlike every other toggle — because it changes no forecast and makes no claim, it only records what already happened, and a log that is off by default records nothing and is therefore worthless. Writing is best-effort and wrapped: a log failure is not a forecast failure. Read it with `python tests/validation/run_drift_report.py --resolve`.


### 29. Cross-sectional classification: pooling the universe

Book Ch. 6 ("Trading Rule Identification by CNN") frames trading as **3-class classification** — buy / do nothing / short — trained across **2,700 NASDAQ stocks** with an **asset-stratified** split: fit on 700 names, validate on 300 entirely different ones. `cross_sectional_panel.py` builds that panel; `cross_sectional_model.py` is the model.

**Why this was the highest-upside item in the book for this project.** Every "no edge" verdict here — SPA *p* = 0.87, MASE > 1 almost everywhere, six of seven models losing money — was measured on **~1000 rows of a single ticker**. That is the binding constraint, and no additional architecture fixes it. Pooling changes both the sample size *and the question*: not *"what will this stock do?"* (absolute, and the evidence says random walk) but *"which of these will outperform the others?"* (relative, with a far better documented empirical basis). This project's own earlier probe found 12-1 momentum with the right sign at *t* ≈ 1 and concluded it needed **hundreds of names**.

**The asset split is a stronger claim than the walk-forward split used everywhere else.** A temporal split asks "does this survive into next month?"; an asset split asks "does this exist in stocks the model has never seen?" — much harder to satisfy by memorisation, since there is no shared price level, regime history, or idiosyncratic noise to latch onto. The default `mode='combined'` requires **both**: unseen names *and* unseen dates. An asset split alone still lets the model see the same calendar period on both sides, so a market-wide regime present in both would inflate the score.

**Three leakage traps it is built against.** *(1) Survivorship* — the universe is an explicit literal list, not a live index scrape, because an index API returns **today's** constituents and back-testing those over ten years silently selects the winners; every dropped ticker is recorded with a reason. *(2) Cross-sectional look-ahead* — every rank is computed **within a single date's cross-section**, never from full-history statistics; `test_cross_sectional_ranks_are_within_date_and_causal` proves truncating the panel does not change a past date's rank. *(3) Forward columns as features* — one `fwd_return` left in the feature list and the classifier scores ~100% on a near-random problem, so the exclusion list is centralised in `feature_columns` and asserted directly.

**Why a gradient-boosted tree, not the book's CNN.** The book renders indicator windows as 2-D images because traders read charts as pictures. Here the features are already a **tabular cross-section**, and convolution's inductive bias — translation invariance over adjacent pixels — is not merely unhelpful but *wrong*: the adjacency between `rank_mom_21` and `rank_vol_21` is an artifact of column order. This project has also already paid twice for the "add capacity" lesson (N-BEATS, Vol-LSTM). The interesting variable is the **pooling and the split**, so the architecture is held boring on purpose and swapping it later is a controlled experiment rather than a confound.

**The calibration step is the part that matters most.** A classifier's raw `predict_proba` is a score that happens to lie in [0, 1], and gradient boosting is systematically overconfident. The model is fit on a proper-train block and its probabilities mapped through a per-class **isotonic regression** fitted on a separate, temporally-split calibration block (temporal, not random — names on the same day share the market move, so a random split would not be independent of the fit). Isotonic rather than Platt because it is non-parametric and can correct an arbitrary monotone distortion. ECE is reported before *and* after, so the effect is measured rather than asserted.

---

## The app: from a price line to honest uncertainty

The Streamlit app (`UI.py`) was reworked so the output is honest about what the models know. Pick a company (NSE/BSE only), interval (daily/hourly), horizon **in trading days** (hourly maps it to ~7 session bars/day), and **which models to run**, then Submit.

**The Model Comparison table** lists every selected model with:

| Column | Meaning |
|---|---|
| Predicted Price | the model's median forecast at the horizon |
| Change (₹) | rupee change from the last actual price |
| Signal Score (%) | forecast % change — the value the bull/bear call is made on |
| Conviction | the move ÷ half the model's own 95% band (|Conviction| ≥ 1 ⇒ move beyond its uncertainty) |
| Confidence | walk-forward reliability bucket: High / Medium / Low / No edge |
| Basis | plain-language reason for the verdict, tied to the DM p-value / coverage / data-quality (e.g. "no edge vs random walk (DM p=0.42)", "withheld — data quality") |
| Sentiment | Bullish / Bearish — or **"No edge"** when the gate found no edge (directional call withheld) |
| Direction | ▲ / ▼ — or **"–"** when withheld |

Above it sit **consensus cards** (median forecast, models bullish/bearish, and how many abstained), the **abstention banner**, and the **Risk & Probability panel** (P(up), P(gain/loss > threshold), VaR-style downside, 95% range, plus the **downside reads** — expected shortfall, downside/upside vol, and vol skew — all read off the empirical fat-tailed distribution; see [§13](#13-confidence-abstention-and-risk-outputs) and [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)). Each model's chart overlays history, the 95% band, the forecast, and the **naive random-walk baseline**. (Concepts behind these: [§13](#13-confidence-abstention-and-risk-outputs).)

**Performance & infrastructure:**
- **Model selection** — run any subset; the slow neural nets are opt-out for a fast run.
- **Per-model caching + parameter snapshot** — results are cached per (ticker, interval, horizon, model), and the run parameters are frozen at Submit, so interacting with a control doesn't silently recompute the suite.
- **GPU/CPU auto-detection** (`model_utils.configure_compute`) — TensorFlow models and Chronos use a GPU when present (with memory-growth enabled) and fall back to CPU; the active device is shown in the sidebar. The gradient-boosted trees stay on CPU on purpose (GPU tree training is slower on these small windows).
- **Reproducibility + resilient fetch** — every run pins all RNGs and shows an auditable **Run details** manifest (seed, versions, params); data is fetched with retries and a **last-known-good cache fallback** that downgrades to risk-cone-only when live data is unavailable (see [§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)).

> **New to the screen?** [Reading the screen: which numbers support a decision](#reading-the-screen-which-numbers-support-a-decision) walks the panels in the order they gate each other, gives the threshold for every number, and says which decision each one can actually support.

### 30. Testing the abstention claim: class weighting, and a t-statistic that was wrong

[§29](#29-cross-sectional-classification-pooling-the-universe) reported that the classifier called "do nothing" for **99.6%** of validation rows and read that as *emergent abstention* — a model volunteering that it had no view. That reading had an obvious duller rival that had not been ruled out: the neutral class is the largest by construction (**42.3%**), the classifier was fitted with `class_weight=None`, and an unweighted multiclass objective has a standing incentive to drift toward the majority class. "Concluded it had no view" and "took the cheapest route to a good log-loss" produce *identical* accuracy columns.

`tests/validation/run_class_weight_ab.py` settles it: same panel, same split, same seed, same hyperparameters, one variable changed.

| Arm | Abstention | Macro F1 | Val ECE | Rank IC (FM *t*) |
|---|---|---|---|---|
| **A** — `class_weight=None` (shipped) | **0.9970** | 0.2021 | 0.0116 | +0.0203 (*t* = 1.10) |
| **B** — `class_weight='balanced'` | **0.9895** | 0.2073 | 0.0091 | +0.0194 (*t* = 1.01) |

*Mean of three seeds (42 / 7 / 2024), 39 NSE names, 74,704 labelled rows, 12 unseen validation tickers, 574 validation dates.*

**The abstention survives.** Balanced weighting raises the payoff for calling short or buy by roughly 1.4× relative to neutral, and the model still declines on **98.95%** of rows — a shift of 0.74 percentage points. It abstains *even when the objective actively pays it to call*. That makes the original reading stronger rather than weaker, and it is now a measured claim instead of an inference. **Skill remains null in both arms** (no seed reaches |*t*| > 2), so this is abstention without hidden signal, exactly as reported.

`class_weight` is now a parameter of `build_classifier`, defaulting to `None` so every previously published figure remains the shipped configuration.

#### Two bugs the experiment exposed

**1. The IC t-statistic assumed independent observations.** `ic_t_stat(ic, n)` is the ordinary correlation t-test, valid for a single ticker's time series and *wrong* for a pooled panel: names on the same date share the market move, so 6,884 rows across 574 dates carry nothing like 6,884 independent observations.

The fix is the factor-research standard (Fama-MacBeth): compute the IC **within each date's cross-section**, then t-test that series across dates, with a **Newey-West** correction because a 5-day forward return sampled daily makes consecutive dates' ICs overlap by four days. `strategy_metrics.ic_by_date`, `newey_west_se` and `fama_macbeth_ic` implement it, and `evaluate` now reports the Fama-MacBeth figure as the headline with the pooled one labelled as overstated.

Honesty about magnitude: **on this data the two mostly agree.** The labels are already market-neutral and dispersion-scaled, so much of the date effect is removed before the IC is computed — which is why the originally reported *t* = 0.92 was not badly wrong. But the correction changed one verdict in three: at seed 2024 the pooled statistic gives ***t* = 2.43**, over the conventional threshold and reportable as a finding, while the honest one gives ***t* = 1.69**, which is noise. One false positive in three seeds is the whole argument for the correction. `test_pooled_t_stat_is_inflated_by_a_shared_market_effect` builds a panel with a pure daily shock and zero cross-sectional signal, where the pooled read returns IC > 0.5 at *t* > 20 and the Fama-MacBeth read correctly returns nothing.

**2. The classifier was not reproducible.** Two runs of the *same seed* gave abstention 0.9461 and 0.9552. LightGBM's multi-threaded histogram construction is not bit-reproducible by default — float addition order varies with thread scheduling. A project that ships a seed-pinned reproducibility manifest was quietly failing to reproduce this model, and an A/B is unreadable when an arm does not reproduce *itself*. Fixed with `deterministic=True, force_col_wise=True, n_jobs=1`, pinned by `test_classifier_is_bit_reproducible_across_fits`. It costs fit time; that is the correct trade for a research model.

Both bugs came out of the same exercise, and neither was the thing being tested — which is the argument for running the counterfactual rather than defending the original reading.
### 31. Architecture as configuration, and the hole it closed in the manifest

This project ships an auditable per-run manifest ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)) recording the seed, package versions and request parameters — and it did **not** record the network shape. That is a reproducibility claim with a hole in it: pinning the seed reproduces a fit only if the architecture is also fixed, and the layer stacks lived as literals inside `DL_model.py`, `CNN_LSTM_model.py` and `vol_lstm_model.py`. Change a hidden size and every earlier manifest silently describes a model that no longer exists, while still presenting itself as complete.

`architectures.py` closes it, with two mechanisms doing deliberately different jobs.

**Declared specs drive the build.** `SPECS` holds each network as a JSON-serialisable object — recurrent units, dropout schedule, filters, kernel and pool sizes — and the builders read from it. Override with an `architectures.json` (or `STOCKAPP_ARCH_FILE`) to change a network without touching model code. The defaults reproduce the previous hardcoded stacks *exactly*, and `test_defaults_match_the_previously_hardcoded_stacks` pins that: introducing the module had to change no forecast, or every published figure would silently refer to a different model.

**The manifest records the realised architecture, not the declared one.** `describe()` reads layer types, output shapes, parameter counts, optimizer and loss back off the *compiled Keras object*. This is the load-bearing choice. A spec merely stored beside a run is decoration — the same "configuration theatre" `config.py`'s tests exist to prevent — whereas introspection cannot drift from the fit it describes, and it covers models whose builders are not spec-driven. Each run now carries a compact block per model:

```json
"CNN-LSTM": {
  "n_layers": 14, "n_params": 36677, "optimizer": "Adam",
  "loss": "huber", "fingerprint": "6d57343ffa8b", "spec_driven": true
}
```

The **fingerprint** is a stable 12-character hash of the realised layer stack, so "was this the same network?" is answerable in one token instead of a nested diff. `manifest_block` deliberately stores only the summary: a six-model layer dump would bury the seed and versions sitting beside it in the Run-details expander.

**Honest scope, reported rather than glossed.** Spec-driven today: **DL (LSTM/GRU)**, **CNN-LSTM**, **Vol-LSTM** — the three whose builders take their sizes as arguments. **N-BEATS, TCN and Transformer are introspection-only**: their shapes are recorded faithfully but not yet controlled from here. `spec_driven` says which is which on every record, and `test_spec_driven_flag_is_honest_about_coverage` fails if a model claims control it does not have.

**A bug this caught in its own wiring.** The first version passed `forecast_nn_direct`'s `desc` string ("CNN-LSTM forecasts") where the registry key ("CNN-LSTM") was expected, so the lookup missed and the manifest reported `spec_driven: false` for a model that *is* spec-driven. Under-claiming is still misreporting, and it was invisible until a real end-to-end run was inspected. Every deep model now passes its key explicitly, checked statically by `test_every_deep_model_passes_its_registry_key_not_its_display_string` so the guard costs no training time.

Architecture overrides are surfaced in the console banner alongside feature-flag overrides ([§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) neighbours), because a run on a non-default network is not the shipped configuration and its numbers need reading that way. `python architectures.py` dumps every spec with its fingerprint.
### 32. Fundamentals: the right experiment, blocked by data — the seventh negative result

Every model here transforms the same OHLCV series, and six negative results point at the **information**, not the architecture, as the binding constraint. Fundamentals are the cheapest second axis available — unlike news/NLP they need no licensed feed — so the obvious next experiment was to add valuation, margin and leverage features to the pooled panel ([§29](#29-cross-sectional-classification-pooling-the-universe)) and re-run the classifier at a horizon where such signals plausibly act: a year, not five days.

`fundamentals.py` implements the machinery. `run_fundamentals_audit.py` establishes that **the experiment cannot currently be run**, and that finding — not a model result — is the deliverable.

**Feasibility first, deliberately.** Building the panel and discovering the coverage problem afterwards would have meant reporting a null that was really a data artefact. That is exactly the confusion [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) had to disentangle for the abstention result, and having paid for that lesson once, the audit came first.

| Measure | Result (12 NSE names, quarterly statements) |
|---|---|
| Tickers with any data | 12 / 12 |
| Median reporting periods per ticker | **5** (max 6) |
| Median first *knowable* date | **2025-05-15** |
| Covered span | 1.28 years of a **7.99-year** panel — **16%** |
| Independent 1-year label dates | **~1** |

For scale: §30's null result had **574** validation dates and still only reached *t* = 0.45. One label date cannot detect an effect of any size. `yfinance` returns a handful of recent filings, not a decade of restated history, so any cross-sectional fundamental result built on it would measure coverage rather than signal.

**The trap this module is built around.** `Ticker.info` returns *today's* trailing P/E, margins and book value, and it is available for every ticker over any date range — which makes it the single most inviting mistake in the field. Joining it onto a 2019 panel row gives that row information that did not exist for another six years, and the resulting classifier looks excellent while measuring nothing. Two structural defences, neither of them advisory:

- **The join refuses.** `current_snapshot` tags its output `point_in_time=False`, and `as_of_join` raises on such a frame rather than warning. Being *unable* to make the mistake beats being told not to.
- **Features are stamped by publication, not by period end.** A quarter ending 31 March is not public on 31 March — SEBI LODR allows 45 days. Dating features by period end leaks up to a quarter of forward information, so `available_from` adds the lag and the merge is a backward as-of on that date. Where the true availability date is uncertain, the module errs late: assuming publication *earlier* than reality leaks, assuming it later merely delays a feature.

`test_as_of_join_never_shows_a_row_a_future_statement` and `test_as_of_join_refuses_a_non_point_in_time_frame` pin both. Ratios are derived from raw line items rather than read off `info`, for the same reason.

**What would change the answer.** A point-in-time vendor with restated history (Compustat, CapitalIQ, Refinitiv) — or, at no cost but time, an archive built forward from today. `prediction_log.py` ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)) already demonstrates that pattern: record now, evaluate when the sample matures. Recording quarterly statements from this point on would make the experiment runnable in a few years, which is unsatisfying and is the honest timescale.

**Note that this stacks with the power problem, it does not replace it.** §30 showed 39 names are too few to detect a cross-sectional IC even when one exists; roughly 55–60 validation names are needed for *t* = 2. Fundamentals would have to clear *both* bars. Running them on the current universe, even with perfect history, would produce another underpowered null.

The module ships complete and tested so that the day a data source appears, the experiment is a configuration change rather than a rewrite. That is the useful form of a negative result: the reason is recorded, the machinery is ready, and nobody has to rediscover the coverage limit by building the panel first.
### 33. Epistemic uncertainty and psychological tolerance (Klaas) — the eighth negative result

Two ideas taken from *Machine Learning for Finance* (Klaas). One works and ships; one **failed its own test and is documented as a failure**.

#### The diagnostic that came free

Ch. 8 offers a rule of thumb: *"You should have 10 times as many samples as there are features."* Applied to the five deep models on ~1000 daily bars:

| Model | look-back | input dim | samples | ratio | |
|---|---|---|---|---|---|
| DL (LSTM/GRU) | 90 | 9 | 910 | 101 : 1 | OK |
| CNN-LSTM | 90 | 9 | 910 | 101 : 1 | OK |
| TCN | 90 | 9 | 910 | 101 : 1 | OK |
| Transformer | 90 | 9 | 910 | 101 : 1 | OK |
| **N-BEATS** | 60 | **540** | 940 | **1.7 : 1** | **under-determined** |

N-BEATS uses `flatten=True`, so its window becomes 540 independent inputs against 940 samples — about **one sixth** of the threshold. The recurrent and convolutional models share weights across time and see 9 inputs per step. This project had already documented N-BEATS underperforming and filed it as a behavioural lesson ("the add-capacity lesson"); it has a **structural** explanation, and one that was measurable all along.

#### Time under water (Ch. 4) — shipped

The book lists four backtest biases. Three — look-ahead, survivorship, overfitting — this project already guards against. The fourth it did not measure:

> *"Consider an algorithm that loses money for four months in a row before making it all back in a backtest... if the algorithm loses money for four months in a row in real life and we don't know whether it will make that amount back, then will we sit tight or pull the plug?"*

`max_drawdown` answers *how deep*. Depth is what you lose; **duration** is what makes someone abandon a strategy before it recovers — and a backtest reader knows the recovery happened, which is exactly the knowledge a live operator lacks. `strategy_metrics.time_under_water` adds `longest_underwater`, `currently_underwater`, `fraction_underwater` and `longest_losing_streak`, in years when a period count is supplied.

`currently_underwater` is reported separately on purpose: **a backtest that ends mid-drawdown looks calmer than it was**, and the run still open at the end is the one an investor would actually be sitting in.

#### MC-dropout epistemic uncertainty (Ch. 4) — built, tested, FAILED

Every interval this project ships is **aleatoric**: the conformal cone measures how wrong the fitted model has *been* and takes the model as given. It cannot say *how much would this forecast move under a different plausible fit* — **epistemic** uncertainty, which is large exactly when data is scarce. Since [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) established sample size as the binding constraint, that silence is on the one axis that matters most.

`epistemic.py` implements the book's method — activate dropout at prediction time, run *n* passes, take the spread. Cheap: no retraining, and every deep model already carries dropout.

Adding an uncertainty number is easy; showing it means something is not. So the module shipped with a prediction that could fail: **if this measures parameter uncertainty, N-BEATS — the 1.7:1 model — should be the most uncertain.**

| Model | dropout | epistemic share | data/input |
|---|---|---|---|
| DL (LSTM) | 0.30 | 0.104 | 101 |
| CNN-LSTM | 0.20 | 0.294 | 101 |
| **TCN** | **0.15** | **0.539** | 101 |
| N-BEATS | 0.20 | 0.331 | **1.7** |

**It failed.** Rank correlation between data-per-input and uncertainty: **−0.26** — the predicted sign, but weak — and the most uncertain model is **TCN**, not N-BEATS.

The check also caught a genuine bug on the way. The first version normalised the spread by the mean prediction; since the target is a **cumulative log return centred near zero**, that denominator was arbitrary (implied values spanned 0.0015 to 0.0147 across four models) and produced a rank correlation of **+0.77** — confidently backwards. Dividing by the model's own conformal sigma is the right comparison and was determinable in advance: both are in log-return units, and the ratio asks *what share of this model's uncertainty is parameter uncertainty rather than residual noise?* Correcting a broken denominator is legitimate; tuning further until the test passed would be the data-snooping this project exists to avoid, so the corrected result stands as the answer.

**Why it fails is identifiable, and it is not the data.** The lowest-dropout model (TCN, 0.15) has the *highest* spread and the highest-dropout model (DL, 0.30) the *lowest*, so the rate isn't driving it either. What drives it is **topology**: TCN puts dropout inside every dilated residual block, so variance compounds across many stochastic layers, while DL's dropout sits between recurrent layers whose 90-step state averages the noise away. MC-dropout spread is not comparable across architectures unless the dropout rate is itself calibrated per model — the known limitation that motivated Concrete Dropout.

**So it ships off** (`USE_EPISTEMIC`), documented as a failed cross-model comparison rather than quietly presented with a plausible story. It may still be meaningful *within* one model across dates or regimes — but that has not been tested, so it is not claimed. It is reported separately from the 95% band and never folded into it: trading a measured coverage guarantee for an unvalidated one would be a bad exchange.

Two implementation details worth keeping. Sampling uses the per-call `training=True` argument rather than the book's TF 1.x `set_learning_phase(1)`, because the global flag **stays set** and silently makes every later `predict` stochastic — `test_sampling_does_not_leave_inference_stochastic` pins that. And a model without dropout reports `available=False` rather than a spread of zero, since every pass through a deterministic network is identical and zero would read as supreme confidence rather than the absence of a measurement.

#### What the book confirms rather than adds

Ch. 4 endorses the forward log directly — *"deploy models silently and test them in the future... executes only virtual trades"* — which is [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio). Ch. 8's "Unit testing data" is `data_quality.py`. Both predate reading it.

Deliberately not taken: NLP (Ch. 5) needs the licensed feed already parked in [§26](#26-book-coverage-what-was-taken-what-was-left-and-why); RL (Ch. 7) hits the power wall §30 measured; computer vision (Ch. 3) is the wrong inductive bias for a tabular cross-section ([§29](#29-cross-sectional-classification-pooling-the-universe)). **Kalman filters** (Ch. 4) were the one item left genuinely open by that review, and have since been built — see [§34](#34-the-kalman-filter-the-model-class-that-was-missing).
### 34. The Kalman filter: the model class that was missing

The nineteen models here all did the same thing structurally: fit **fixed parameters** over a training window, freeze them, forecast. A Kalman filter carries a *state* re-estimated at every bar, so the level and slope it extrapolates from are the ones implied by the most recent data, continuously reweighted against their own uncertainty. That is a different answer to non-stationarity than refitting on a rolling window, and it was the one gap `Machine Learning for Finance` left genuinely open ([§33](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result)).

`kalman_model.py` implements a **damped local linear trend** on log prices:

```
level_t = level_{t-1} + φ · slope_{t-1} + w_level
slope_t =               φ · slope_{t-1} + w_slope
y_t     = level_t                       + v
```

φ ∈ [0, 1] damps the trend, so the *h*-step forecast adds `slope · (φ + φ² + … + φʰ)` — a geometric sum that **converges** rather than extrapolating a straight line. That matters more here than usual: an undamped slope fitted to a recent run-up would project it indefinitely, which is precisely the failure the evaluation layer exists to catch.

**The model is allowed to conclude it is a random walk**, and the fitted parameters are surfaced so it is visible when it does.

#### The result, on 7,696 real RELIANCE bars over 40 walk-forward origins

| | Coverage (target 0.95) | 95% CI | Mean width |
|---|---|---|---|
| **Native** (Kalman Gaussian) | **0.985** | [0.968, 1.002] | 46.60 |
| **Conformal** (shipped default) | **0.975** | [0.953, 0.997] | 43.70 |

Both **over-cover** — conservative rather than broken — and at 200 observations the two are **not distinguishable**; their confidence intervals overlap heavily. Conformal is about 6% narrower, which is why it stays the default, but this should not be reported as a win.

The genuinely interesting finding is the one the book advertised: **the native interval reaches near-nominal coverage with no calibration set at all.** No held-out residuals, no quantile, nothing tuned — it falls straight out of the state covariance. Not one of the other nineteen models can do that. On this evidence the Gaussian assumption survives contact with fat-tailed equity data better than expected, though 200 observations is not enough to say it survives the tails specifically.

Point forecast: RMSE 11.33 against the random walk's 11.15 — **1.6% worse**, i.e. parity. That is the *expected* result, not a disappointment: **70% of origins fitted a degenerate slope**, mean φ = 0.32. On a near-efficient price series a local-level Kalman fit *is* an adaptive random walk, and it says so instead of manufacturing a trend.

So its value here is the interval and the fitted structure, not the point forecast — the same honest position HAR-RV occupies.

#### A bug the tests caught, which would otherwise have been invisible

The first implementation fixed `r = 1` and scored the **raw** Gaussian likelihood over the noise ratios. On log-price data of scale ~0.02 that rewards whichever ratio pushes the innovation variance towards 1, so it drove `q → 0` regardless of the truth: a simulated process with a known q/r of **4.0 was fitted as 0.000**, and the likelihood fell monotonically across the whole grid.

Nothing downstream looked wrong. The model produced a flat forecast with a widening cone and plausible prices — exactly what a correct fit on a random walk produces. Only `test_fit_recovers_a_known_signal_to_noise_ratio`, run against a *simulated process with known parameters*, exposed it.

The fix is the **concentrated (profile) likelihood**: σ² is profiled out analytically, leaving a likelihood in the ratios alone. Recovery afterwards, on simulated data:

| True q/r | Fitted |
|---|---|
| 4.00 | 5.00 |
| 0.25 | 0.20 |
| 100.00 | 160.00 |

Within grid resolution in every case. `test_likelihood_is_not_monotone_in_q` now guards the specific failure directly.

The lesson generalises past this model: **a state-space fit that cannot recover known parameters from simulated data is not fitting anything**, and no amount of plausible-looking output on real data will reveal that. It is the same shape as the silent bugs found across the sample repos — a no-op normaliser, a leaky interpolator, a callback that could never fire.

#### Implementation notes

Estimation is a coarse grid over `(q_level/r, q_slope/r, φ)` with a local refinement — grid rather than an optimiser because state-space likelihoods are notoriously multi-modal and flat in places, and three parameters are cheap. Pure NumPy, no SciPy, consistent with `var_models.py`. The 2×2 covariance algebra is written out rather than delegated to `numpy.linalg`, which keeps the scalar Kalman gain visible to a reader checking it.

`use_conformal=True` is the shipped default and the native half-width is recorded alongside in `attrs` either way, so the comparison above can be re-run at any time. The model appears in the app as **Kalman (local trend)** — the suite is now **20 models**.
### 35. Feature drift and attribution — the ninth negative result, arriving from a new direction

Two more items from Klaas Ch. 8, both answering questions this project could not previously answer. Neither improves accuracy; one improves *operations*, the other improves *diagnosis*. The second produced a genuine finding.

#### Feature-distribution drift: the leading indicator

`prediction_log.drift_report` monitors **outcome** drift — live interval coverage against nominal 95%, binomial-CI-gated ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)). That is the right headline, but it is a **lagging** indicator: at a 5-day horizon it needs weeks of matured forecasts before it can say anything. If the *inputs* have moved away from what a model was fitted on, its forecasts are extrapolations regardless of how the last few intervals happened to land.

`feature_drift.py` measures that directly. The design choice worth explaining is why it **does not use the conventional PSI thresholds**.

Those bands — 0.10 "moderate", 0.25 "significant" — are folklore, and PSI is **biased upward on small samples**: two halves of the *same* distribution show non-zero PSI purely from binning noise, and the smaller the sample, the larger that floor. Measured:

| n | PSI between two samples of the **same** distribution | Folklore verdict |
|---|---|---|
| 50 | **0.3044** | "significant drift" |
| 100 | 0.1465 | "moderate drift" |
| 300 | 0.0713 | stable |
| 1,000 | 0.0077 | stable |
| 5,000 | 0.0038 | stable |

At n = 50 the folklore declares significant drift on **identical distributions**. Applying a fixed cut-off to short windows fires constantly, which is how monitoring gets switched off.

So significance is established by **permutation**: pool both samples, reshuffle the labels, recompute PSI many times. That gives the PSI attributable to binning noise *at these exact sample sizes and this exact binning*, and a feature is flagged only when it exceeds it. Same discipline as the binomial-CI gate — an alert that fires on noise teaches people to ignore alerts. The conventional bands are still reported, because a risk function will ask for them; they simply never decide.

The aggregate verdict also corrects for **multiple testing**: 40 features at α = 0.05 yields ~2 false positives by construction, so "some feature drifted" is not news.

**On real data** (RELIANCE, 750-bar reference vs 250-bar current, 26 features): **10 features flagged — WIDESPREAD DRIFT**, against 1.3 expected by chance. And they are coherently themed: `volatility_50`, `volatility_20`, `volatility_10`, `atr_norm`, plus `macd_norm`, `ma_ratio_50`, `rsi_14`. The **volatility and trend-regime family has moved; the raw return distribution, volume and calendar features have not.**

One honest note: at 750/250 the permutation test and the folklore bands happened to agree (both flagged 10). The calibration matters at *small* samples, which is exactly where a monitor gets run in practice — not at this one.

#### Attribution: exact TreeSHAP, and what it says about the project

Klaas Ch. 8 asks *"why did your model make the prediction it made?"* and reaches for LIME. For tree ensembles there is something strictly better: **TreeSHAP is exact** rather than a local surrogate, and both LightGBM and XGBoost implement it natively via `pred_contrib` / `pred_contribs`. So `explain.py` needs **no new dependency** — not `shap`, not `lime`.

Exactness matters more than usual here. A surrogate's disagreement with the model is indistinguishable from a genuine attribution, so an approximate explainer applied to a near-noise model produces confident-looking nonsense. Unsupported models return `None` rather than falling back to an approximation.

**But the reason to run it is sharper than interpretability.** This project's central claim is that most apparent edge is noise. Attribution checks that from the inside: a model driven by a few economically sensible features is making a structured claim; attribution spread thinly across dozens is what fitting noise looks like. The **Herfindahl index** makes it concrete — near `1/n` is uniform, near 1 is one feature explaining everything.

The method demonstrably detects concentration when it exists. On a synthetic model where only two of six features matter, those two took **95.6%** of attribution, Herfindahl **3.8×** uniform.

**On the real models:**

| Model | Top feature | Features for 50% | Herfindahl vs uniform |
|---|---|---|---|
| Single-ticker GBM (26 features) | `volatility_10` — **9.0%** | 8 | 0.0525 vs 0.04 — **1.3×** |
| Cross-sectional classifier (30 features) | `atr_norm` — **6.9%** | 11 | 0.039 vs 0.0333 — **1.2×** |

**Attribution is nearly uniform in both.** No feature carries the prediction. It takes 8 and 11 features respectively to reach half the attribution, and the top feature carries under 10%.

This is the ninth documented negative result, and the one that arrives from the most independent direction. *(Superseded in part: [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) re-ran this measurement on 400 names and attribution **does** concentrate there — top feature 14.8% against ~3% uniform. The near-uniform result below is a property of the 39-name universe, not of the problem.)* Every previous null came from *measuring outcomes* — RMSE against a random walk, SPA p-values, rank IC t-statistics. This one comes from **looking inside the model** and finding no driver to look at. It could easily have come out the other way: a concentrated attribution on economically sensible features would have been a genuine lead, and the synthetic control proves the method would have found it.

Additivity is verified rather than assumed (`base_value + Σ SHAP == prediction`, error 4.3 × 10⁻¹⁷ on real data), because a silently mis-parsed contribution layout would still produce plausible-looking attributions.

**One caveat stated in the driver itself:** attribution explains what the model *did*, not whether it was right. A confidently-attributed forecast from a model with no measured edge is still a forecast with no measured edge.
### 36. Fractional differentiation: measuring a choice made by convention — the tenth negative result

From Kaabar, *Deep Learning for Finance*, Ch. 9 (López de Prado's method). The one item in that book touching something this project does **by convention rather than by measurement**.

#### The choice that was never tested

Every model here sees **d = 1** data. `prepare_log_returns` computes `log(price / price.shift(1))`; the features are `log_return_1…10`; the target is a cumulative log return. That guarantees stationarity — and it is *maximally destructive*, removing not just the trend but every trace of long-range dependence in the level. If prices carry persistent structure, d = 1 discards it before any model sees the data, and no architecture downstream can recover it.

Fractional differencing expands `(1 − B)^d` for non-integer *d* into an infinite binomial series: `w₀ = 1`, `wₖ = −wₖ₋₁ · (d − k + 1) / k`. At d = 1 the weights terminate at `[1, −1]` — an ordinary difference. At 0 < d < 1 they decay slowly and never terminate, and **that non-termination is the retained memory**.

`fracdiff.py` implements it. The book uses `pip install fracdiff`; the weights are a four-line recurrence, so this is a **no-new-dependency** implementation — ADF/KPSS come from `statsmodels`, already pinned.

#### What d = 1 actually costs, on real data

Minimum-*d* scan on **RELIANCE, 7,697 bars** (tol = 1e-4):

| d | ADF *p* | corr with level | window | stationary |
|---|---|---|---|---|
| 0.00 | 0.5816 | 1.0000 | 1 | no |
| 0.30 | 0.3577 | 0.9779 | 388 | no |
| 0.40 | 0.1580 | 0.9464 | 282 | no |
| **0.50** | **0.0292** | **0.8823** | 200 | **yes** |
| 0.70 | 0.0001 | 0.5848 | 97 | yes |
| **1.00** | 0.0000 | **0.0039** | 2 | yes |

**At the minimum stationary order d = 0.50, the series still correlates 0.88 with the price level. At d = 1 — what this project uses — the correlation is 0.004.** Stationarity is achieved either way; the difference is roughly all the memory.

That is the sharpest available statement of what the pipeline throws away.

#### Does the retained memory forecast anything? No.

`run_fracdiff_eval.py` runs the A/B: identical models, identical walk-forward origins, one arm with the existing feature set and one with frac-diff log-price columns at d = 0.50. 40 origins on 7,325 usable rows.

| Arm | RMSE | vs random walk |
|---|---|---|
| random walk | 0.048694 | — |
| baseline (d = 1) | 0.048897 | **−0.42%** |
| **frac-diff (d = 0.50)** | 0.046358 | **+4.80%** |

Frac-diff is 5.19% better than baseline in point estimate — and **Diebold-Mariano gives *p* = 0.436 on 40 origins**. Not significant. The honest reading is **no difference**.

This is the **tenth documented negative result**, and a cleaner one than most: frac-diff adds **no parameters**, so unlike N-BEATS and Vol-LSTM this null cannot be blamed on capacity. It changes the *representation*, and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) established the constraint is *information*. A representation change cannot create signal that is not there.

**One practical constraint worth recording:** the window length is a function of *d*. At tol = 1e-5, d = 0.4 needs **1,458 bars** — longer than the 1,000-bar cap the single-ticker models use, which would produce an all-NaN column. Loosening to tol = 1e-4 gives 282 bars, which is workable. That tension is real: a looser tolerance truncates the memory sooner, partially defeating the purpose.

#### Two bugs found — one mine, one pre-existing

**Mine, and it mattered.** The first version of the A/B trained on rows up to `o − 1` while evaluating `y[o]`. Row `o − 1`'s target spans `[o−1, o−1+h]`, which **overlaps** the evaluation target — the overlapping-label leak our own `embargo` exists to prevent. It reported the baseline at **+20.20% vs the random walk**.

That number is what gave it away: a 20% RMSE improvement over a naive baseline is flatly inconsistent with every other result in this project. With the embargo applied, the same arm scores **−0.42%** — parity, as expected. The leak was worth roughly **20 percentage points of imaginary skill**, and the only thing that caught it was the result disagreeing with the rest of the evidence.

**Pre-existing, in `get_data.py`.** Running the scan surfaced `Error processing data: 'charmap' codec can't encode character '✅'`. Seven status messages in the currency-conversion path contain emoji, and an unguarded `print` of them raises `UnicodeEncodeError` on a legacy Windows code page — *inside* a `try/except`, so it was caught and re-reported as a generic data error that masked what actually happened. This is exactly the exposure flagged when `console.py` was built ([§34's neighbour](#the-same-story-in-the-terminal)) and deferred as out of scope; it has now fired for real. All seven now route through `console._write`, which degrades instead of raising.

#### One inconsistency noted, deliberately not fixed

The DM test on baseline-vs-random-walk returned `NaN`. That is `diebold_mariano`'s own guard firing correctly: it computes the Newey-West long-run variance with **unweighted** autocovariances, which can come out negative, and it returns NaN rather than a bogus p-value.

Worth recording that `strategy_metrics.newey_west_se` — added in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) — *does* apply a Bartlett kernel, which cannot go negative. The two are inconsistent. Adding the kernel to `diebold_mariano` would be a genuine improvement, and it would **change every DM p-value published in this document**. That is not a change to make silently as a side effect of a frac-diff experiment, so it is recorded here as a known issue rather than applied.

#### What else was in the book

Nothing else worth taking. **Forecasting threshold** (p270) is the `Conviction` column and the abstention gate. **Multiperiod forecasting** (p277) is direct multi-horizon. **Time-series cross-validation** (p275) is walk-forward with embargo. **Continuous retraining** (p272) is train-on-demand. **COT data** (p307) is US futures positioning and does not exist for NSE equities. Chapters 1–6 are foundations; Ch. 7–8 the model zoo already built; Ch. 10 deep RL, blocked by the power wall §30 measured.
### 37. The Diebold-Mariano kernel fix, and the Windows race it uncovered

[§36](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result) recorded an inconsistency rather than fixing it: `diebold_mariano` computed its Newey-West long-run variance with **unweighted** autocovariances, while `strategy_metrics.newey_west_se` (added in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong)) applied a **Bartlett** kernel. Fixing it would move every published DM p-value, so it was flagged rather than changed silently. This section is that fix, done properly — with the before/after measured.

#### The bug

An unweighted sum of autocovariances is a *truncated* (rectangular) kernel, and it is **not positive semi-definite**. On short samples the estimated variance can come out **negative**, and the function then returns `NaN` rather than a p-value. That guard is correct — a p-value from a negative variance would be nonsense — but it is a silent loss of power: **a test that declines to run is a test that never rejects.**

Bartlett weights `1 − k/h` are PSD by construction, so the variance cannot go negative.

#### How often it actually fired

Simulated, 400 comparisons per cell:

| h | n | NaN (old) | NaN (new) | mean \|Δp\| | verdicts flipped @0.05 |
|---|---|---|---|---|---|
| 1 | 20–120 | 0 | 0 | **0.0000** | **0** |
| 3 | 20 | 25 | 0 | 0.0492 | 27 |
| 5 | 20 | **81** | 0 | 0.0691 | 24 |
| 5 | 40 | 28 | 0 | 0.0567 | 30 |
| 10 | 20 | **190** | 2 | 0.0945 | 15 |

Two things stand out. **At h = 1 the change is exactly zero** — the lag loop never executes — which bounds the blast radius: every single-step DM figure ever published here is bit-identical. And at h = 5, n = 20 the old version **refused to produce a p-value in 20% of cases**; at h = 10, n = 20, in **48%**.

That regime is not hypothetical. The serve-time confidence gate runs **3 origins** at `h = horizon`, so a 5-day forecast gives ~15 error points — squarely inside it.

**The failure was conservative, which is why it was never noticed.** `confidence_bucket` treats a NaN p-value as "not significant", so an affected model could never reach **High** or **Medium** — it capped at **Low**. The app was under-rating models, not over-rating them. That is the safe direction, and still wrong.

#### What changed in the published figures

Measured on **identical real error series**, captured from `walk_forward_backtest` and scored under both kernels (6 splits, h = 5, n = 30):

| Ticker | Model | old *p* | new *p* | Δ |
|---|---|---|---|---|
| TCS.NS | ARIMA+GARCH | 0.1920 | 0.2155 | +0.0235 |
| TCS.NS | Ensemble-Stack | 0.8679 | 0.8451 | −0.0228 |
| TCS.NS | XGBoost | 0.7761 | 0.7829 | +0.0068 |
| RELIANCE.NS | ARIMA+GARCH | 0.3836 | 0.3637 | −0.0199 |
| RELIANCE.NS | Ensemble-Stack | 0.4233 | 0.4029 | −0.0204 |
| RELIANCE.NS | XGBoost | 0.8379 | 0.8126 | −0.0253 |

**Maximum movement: 0.025.** No verdict changes at the 0.05 or 0.10 thresholds. **One** changes at 0.20 — TCS ARIMA+GARCH crosses from 0.1920 to 0.2155, dropping that configuration from **Medium** to **Low**, again in the conservative direction.

So: the fix is correct and necessary, and **no conclusion in this document changes**. The empirical findings, the SPA verdict and the "no confirmed winner" framing all stand.

#### The Windows race the fix uncovered

Re-running the suite after the change produced an intermittent failure — and, tellingly, in a **different test each time**: three separate drift-report tests failed across runs, each passing in isolation. That pattern says shared non-determinism, not a broken assertion.

The tests already used isolated temp directories, so it was not file contamination. The cause was found only after **hardening the test harness**: `log_forecast` swallows every exception on purpose (a logging failure must never break a forecast), which in a test converts a transient write failure into a *short log*, surfacing several assertions later as an unexplained coverage number. Asserting that every write succeeded turned the puzzle into a named failure, and the named failure pointed at `_rewrite`:

```
PermissionError: [WinError 5] Access is denied:
  '...\predictions.jsonl.tmp' -> '...\predictions.jsonl'
```

`os.replace` is atomic on POSIX. On Windows it raises whenever another process holds even a momentary handle on the destination — an antivirus scanner or the search indexer touching a just-written file is enough. It is a race, failing roughly one run in ten.

**This is a production bug, not a test artefact.** `resolve_outcomes` is what `run_drift_report.py --resolve` calls on the real log; hitting this would crash the resolve and leave a stray `.tmp` beside the log. Fixed with retry-and-exponential-backoff — the standard Windows-safe pattern — and the temporary file is removed if every attempt fails, so a failed resolve cannot leave litter a later run mistakes for data.

The general lesson is the one this project keeps rediscovering: **the deliberate swallow that makes a system robust in production is the same swallow that makes it undiagnosable in testing.** The fix is not to remove it, but to make the test harness refuse to tolerate it.

### 38. Universe expansion: point-in-time data, and the first positive result

Ten negative results in this project point at the same suspect. The cross-sectional null in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) — rank IC +0.0111 at **t = 0.92** — was read at the time as a *power* result rather than evidence against the approach: real cross-sectional ICs are 0.02–0.05, and detecting one needs roughly **55–60 validation names** where 39 were available. [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) deferred to the same wall.

Breadth was the one lever never pulled. This section pulls it — and most of the work turned out to be in the **data source**, not the experiment.

#### The obvious source is a trap

NSE publishes `EQUITY_L.csv`, and `get_data.get_bse_nse_data` already fetches it: 2,565 listings, 2,302 with `SERIES == EQ`, and **1,154** listed early enough to have full history. Ample to draw 400 names from.

It is also **a list of companies that still exist**. Measured against Wayback Machine snapshots of the identical URL — the current `archives.nseindia.com` domain has only two, but the pre-2020 `nseindia.com` URL has **33 going back to 2006**:

| Snapshot | EQ names then | Absent from today's list |
|---|---|---|
| 2017-07 | 1,465 | **392 (26.8%)** |
| 2018-12 | 1,456 | 306 (21.0%) |
| 2021-05 | 1,563 | 209 (13.4%) |

**A quarter of the 2017 universe is gone.** Drawing a 2018–2026 panel from today's roster selects companies *on the basis of having survived the window*, then asks a model to predict their returns over it. A larger biased sample is worse than a small honest one, because it produces a confident answer.

The gap cannot be patched from the existing feed: of 30 randomly sampled vanished symbols fetched from yfinance, **23 returned no data at all**, 6 partial, 1 usable. yfinance discards delisted history.

This is not hypothetical for this project. **`TATAMOTORS.NS` — one of the 40 names in `DEFAULT_UNIVERSE` — now returns zero bars from yfinance** after the 2025 demerger, while bhavcopy still carries all 490 of its 2018–2019 sessions. That is precisely why the published cross-sectional work ran on *39* usable names rather than 40. The bias had already started eating the universe.

#### Bhavcopy: point-in-time by construction

NSE publishes a **daily bhavcopy** — one file per trading day listing every instrument that traded. There is no membership list to get wrong and no survivorship correction to apply: whatever traded on 2 January 2018 is in the 2 January 2018 file. `3IINFOTECH`, `ADANITRANS`, `ADLABS` and `ADHUNIK` are all there with full OHLCV.

`bhavcopy.py` is that loader. Two formats, found by probing rather than assumed:

* **legacy** zipped CSV — serves 2017-01 through **2024-07-01**, 404 from 2024-07-08
* **UDiFF** via `nselib` — serves **2024-01** onward

`fetch_day` tries legacy and falls back, so the cutover is absorbed rather than hardcoded. The six-month overlap is a **free cross-validation**, and `test_readers_agree_on_the_normalised_schema` pins that downstream code cannot tell which source produced a row. The cache is one gzipped file per day — 2,500 days, ~105 MB, ~33 minutes once. A missing day is stored as an *empty* file, because a weekend and an exchange holiday are indistinguishable from date arithmetic and must be discovered, never interpolated.

#### The harder half: raw prices

Bhavcopy carries **raw traded prices**. yfinance was silently handling splits and bonuses; bhavcopy does not, and an unadjusted 1:10 split reads as a **−90% return** that would poison every momentum feature in the panel. `PREVCLOSE` is no help — checked on seven 2019 split/bonus ex-dates it equals the prior day's raw close exactly (ratio 1.000). NSE does not adjust it either.

So the adjustment is ours, parsed from `nselib`'s corporate-action feed (coverage verified back to **January 2017**):

| Subject | Adjustment |
|---|---|
| `Bonus 1:4` | ×1.25 |
| `Face Value Split From Rs 10/- ... To Rs 2/- ...` | ×5 |
| `Bonus 1:2/Face Value Split ... Rs 2/- To Re 1/-` | ×3 (compound) |
| `Interim Dividend Rs 2/- Per Share` | Rs 2 cash |
| `Rights 19:67 @ Premium Rs 215 Per Share` | via TERP |

Dividends are included because the pipeline models log returns off **`adj_close`** (`get_data` ~line 352), yfinance's *fully* back-adjusted series. Adjusting only for splits would make the new panel incomparable with every figure already published here.

**A bug caught during validation.** GPIL filed a 10→5 split **and** a 1:1 bonus as two separate records on 2021-10-26 — true factor 4.0. An early version deduplicated by `(symbol, ex_date)` and parsed 2.0, an **82% error**. Same-day actions must *compound*; `test_same_day_actions_compound` exists so it cannot return. Every correction is expressed as the ratio of theoretical post-event price to cum price, so compounding is correct by construction rather than by patch.

#### Validated against yfinance, which found the one thing left out

A per-event check (does the price drop by the parsed factor?) is confounded by the stock's genuine move that day — which is why one of 18 hand-checked events came in 13% off with a perfectly correct factor. The stronger test compares the **whole return series** against an independent adjusted source. `run_bhavcopy_audit.py` does that over 2018–2019:

| | |
|---|---|
| Median return correlation | **1.00000** |
| Names above 0.999 | **24 / 24** |
| Names bit-identical | 14 |
| Worst single-day gap | 0.83% |

It did not start there. The first run gave **22/24**, with BHARTIARTL (0.98507) and TATASTEEL (0.99537) failing — and both turned out to be **rights issues**, which the parser did not handle. Adding theoretical-ex-rights-price adjustment moved them to 0.99986 and 0.99999. Worth recording: NSE quotes the **premium over face value**, not the subscription price, so Bharti's `Rs 215` is really Rs 220 against a Rs 5 face value, and the face value has to come from the feed's `faceVal` column. Tata Steel's subject carries a fully-paid *and* a partly-paid tranche; only the first is taken, because a partly-paid share is a separate instrument and folding it in would be wrong in a worse way than ignoring it.

`adjust_prices(as_of=...)` applies **only actions known by that date**, which closes the back-adjustment look-ahead `tests/audit_price_adjustment.py` documented and yfinance cannot avoid.

#### The experiment

`run_universe_expansion.py` runs the **identical** experiment at four universe sizes — same features, labels, split rule, model and horizon. Only breadth varies.

The integration is one function, deliberately: `cross_sectional_panel.build_panel` already accepted an injected `fetch_fn` so its tests could run offline, and `bhavcopy.bhav_fetcher` slots into that seam. **Not one line of `cross_sectional_panel.py`, `cross_sectional_model.py` or the feature code changed.** Had the pipeline been rebuilt alongside the data source, no comparison with the published 39-name result would have meant anything.

Window 2018-01-01 → 2024-06-30, horizon 5 days, `mode='combined'` (unseen names **and** unseen dates), seed 42:

| Requested | Usable | Val names | IC dates | Rank IC | **FM *t*** | Abstain |
|---|---|---|---|---|---|---|
| 39 | 39 | 12 | 464 | +0.0283 | 1.31 | 0.968 |
| 100 | 100 | 30 | 464 | +0.0048 | 0.24 | 0.956 |
| 200 | 197 | 59 | 464 | +0.0375 | **2.37** | 0.937 |
| 400 | 332 | 100 | 464 | **+0.0396** | **2.24** | 0.922 |

The 39-name row reproduces the project's own history — *t* = 1.31 against the published 0.92 — on a different window and a differently-selected universe. That is the control.

#### It was not reported until it survived being attacked

**The table is not monotonic.** Under a pure power story *t* should climb roughly with the square root of the validation count; instead 1.31 → **0.24** → 2.37 → 2.24. The dip at 100 is larger than sampling noise should comfortably allow, and every row is **one seed**. §30 already recorded a case where one seed gave a reportable *t* = 2.43 where the honest read gave 1.69.

`run_universe_seeds.py` builds the panel once (it does not depend on the seed) and re-splits, re-fits and re-evaluates, then repeats the whole thing on two **disjoint periods**:

| Window | IC dates | Rank IC median | FM *t* median | *t* > 2 | Negative IC |
|---|---|---|---|---|---|
| Full 2018-01 → 2024-06 | 464 | +0.0367 | +2.42 | 7 / 8 | **0 / 8** |
| A: 2018-01 → 2021-06 | ~230 | +0.0336 | +1.92 | 2 / 6 | **0 / 6** |
| B: 2021-07 → 2024-12 | 240 | +0.0328 | +2.70 | 6 / 6 | **0 / 6** |

**Twenty of twenty seed-runs are positive**, and the effect *size* is near-identical across two non-overlapping periods: 0.0367 / 0.0336 / 0.0328. Period A's weaker *t* is not a weaker effect — its IC is the same size, measured over half the dates with more than double the dispersion (sd 0.0145 vs 0.0065), which is what a window containing the COVID crash should look like.

So the n = 100 dip was a single-draw artefact, and **the cross-sectional null in §30 was a power result exactly as claimed.** This is the project's **first positive result** after ten negatives.

#### What this result is not

Four caveats, none decorative:

**1. The long-short spread is not usable; the rank IC is.** The spread looks large (+0.017 to +0.061 of 5-day excess log return) and rests on almost nothing:

| Universe | Long calls | Short calls | of |
|---|---|---|---|
| 39 | **0** | 143 | 4,405 |
| 100 | 26 | 499 | 11,813 |
| 200 | 18 | 1,573 | 25,085 |
| 400 | 148 | 2,978 | 39,844 |

148 longs out of 39,844 is 0.37%, against 20× as many shorts. That is not a balanced portfolio, the mean of 148 observations is dominated by a handful of moves, and no transaction costs appear anywhere in it. At n = 39 there were **zero** long calls, which is why that spread is undefined. **Quote the IC, not the spread.**

**2. The classifier still barely classifies.** Accuracy 0.510 against a 0.501 majority baseline; macro F1 0.288. The rank IC carries the entire result — the model *orders* names better than chance while its discrete calls stay close to worthless. Abstention holds at **92%** even at 400 names, so §30's emergent-abstention behaviour is not a small-sample artefact. Calibration is genuinely good, though: ECE 0.0204 → **0.0026**.

**3. A residual survivorship filter remains, smaller but real.** `build_panel` requires **300 rows** per name, so companies trading for under ~14 months inside the window are dropped — 68 of 400 at the largest size. And a company that fails simply stops appearing; its final observed return is not −100%, so genuine wipeouts are under-represented. Both push optimistic. Far weaker than "must still exist in 2026", and not zero.

**4. One market, one model family, gross of costs.** No capacity analysis, and no borrow cost on a book that is 95% short by count.

#### What the signal is made of — and why the model is not the finding

A statistical result whose mechanism is unknown is one step away from an artefact nobody has found yet. `run_universe_attribution.py` asks what the 400-name model is actually keying on, with the decisive measurement being the **univariate IC**: for every raw feature, the Fama-MacBeth IC of that feature *alone* against forward excess return — same rows, same 464 dates, same machinery as the model.

| Feature | Univariate IC | FM *t* | Hit rate | SHAP share |
|---|---|---|---|---|
| `log_return_5` | **−0.0524** | **−4.34** | 0.388 | 1.6% |
| `rank_rev_5` | −0.0524 | −4.34 | 0.388 | 4.2% |
| `ma_ratio_10` | −0.0490 | −4.00 | 0.386 | 1.6% |
| `macd_hist_norm` | −0.0469 | −3.67 | 0.373 | 3.1% |
| `log_return_3` | −0.0442 | −4.08 | 0.397 | 0.9% |
| `rank_mom_63` | **+0.0276** | **+2.24** | 0.595 | 7.1% |
| *the model* | *+0.0396* | *+2.24* | *0.565* | — |

**A single raw feature beats the model — 1.32× the IC and nearly double the *t*.** And the sign is unambiguous: a negative IC on recent returns means recent winners underperform, which is **short-term reversal**, one of the most documented effects in equities. The hit rate of 0.388 says the IC is negative on 61% of dates, so it is consistent rather than carried by a handful of them. The whole top of the table is the same effect wearing different names.

**A second textbook effect appears with the correct opposite sign.** `rank_mom_63` scores +0.0276 at *t* = +2.24 — positive IC at a 63-day lookback. Short-horizon reversal *and* medium-horizon momentum, both present, both correctly signed, in a survivorship-free panel built from scratch. That is a strong independent check on the entire data pipeline: if the bhavcopy loader or the corporate-action adjustment were subtly wrong, these two effects would not both emerge at their textbook signs and horizons.

**The SHAP explains why the model underperforms.** Its top three features by attribution are `volatility_50` (14.8%), `atr_norm` (9.0%) and `rank_vol_21` (7.3%) — all volatility. `rank_rev_5`, which carries the actual edge, ranks **seventh at 4.2%**. The model spends its capacity deciding *when to stay out* rather than *which way to lean*, which is coherent with the 92% abstention and is exactly what it was punished for.

This also reverses [§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)'s reading. Attribution there was near-uniform (Herfindahl 1.3× uniform) and was recorded as "no driver to look at". At 400 names it concentrates: the top feature takes 14.8% where uniform would be ~3%. **There was a driver; the 39-name universe was hiding it**, in the same way and for the same reason it hid the IC.

#### The honest summary

There is a **real, replicable cross-sectional ordering signal** in liquid NSE equities at a 5-day horizon, invisible at 39 names and detectable at 200+. That part of §30's prediction is confirmed.

But **the model is not the finding — the factor is.** This section is a known effect *rediscovered*, not learned cross-sectional skill, and a naive 5-day reversal sort is the benchmark any model here has to beat. This one does not beat it. Anyone reporting the +0.0396 without the −0.0524 beside it would be overstating what the machine learning contributed, which is: nothing yet.

That is a better outcome than an unexplained edge. An edge you cannot explain is one you cannot reason about when it stops working — and short-term reversal has a known mechanism (liquidity provision, bid-ask bounce, over-reaction), known decay, and known capacity limits. Whether it survives costs is answered in [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc): **it does not.** Breakeven is 6.1 bp round trip against an STT of 20 bp, and no holding period or tail width in the sweep clears even 25 bp.

---

### 39. Costing the reversal signal — the eleventh negative result, and the end of the arc

[§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) closed with an open question: the cross-sectional signal is real, replicable and identified as short-term reversal, but *"whether it survives costs is a different question this project has not asked."* This asks it, and the answer closes the arc.

`run_reversal_costs.py` builds the tradeable version: long the bottom decile of 5-day past return (recent losers), short the top decile (recent winners), equal-weighted, dollar-neutral, rebalanced every 5 trading days so holding periods do not overlap. 339 names, 1,601 dates, **319 rebalances**.

The signal is a cross-sectional sort on a raw feature with **no free parameters** — nothing is fitted — so the whole 2018–2024 panel is fair game and there is no train/test split to respect.

#### It was already thin before costs

| | |
|---|---|
| Gross annual return | +5.30% |
| Gross annual volatility | 22.49% |
| **Gross Sharpe** | **+0.24** |
| Periods positive | 0.517 |

**An IC of −0.052 sounds respectable and converts to a Sharpe of 0.24.** The decile spread carries 22% annualised volatility, so the risk-adjusted edge was small before a single rupee of cost. §38's statistical significance came from having 464 dates, not from a large effect — which is exactly the distinction the Fama-MacBeth machinery exists to expose, and it cuts both ways.

#### Costs remove it several times over

The book turns over **3.47 of a possible 4.00 notional per rebalance — an 87% refresh, every five days.**

| Round-trip cost | Annual return | Sharpe | Scenario |
|---|---|---|---|
| 10 bp | −3.44% | −0.15 | institutional, futures, top liquidity |
| 25 bp | −16.56% | −0.74 | liquid cash equity, modest size |
| 50 bp | −38.43% | −1.71 | realistic incl. mid-cap impact |
| 100 bp | −82.16% | −3.66 | retail delivery, STT both sides |

**Breakeven: 6.1 bp round trip.** That is the number to argue with, because it assumes nothing — it is simply where gross return equals cost drag. For scale, **STT alone is 20 bp round trip** on Indian delivery, before brokerage, exchange fees, stamp duty or market impact.

#### The obvious rescue does not work, and the reason is interesting

A turnover-driven null invites one objection: *rebalance more slowly*. Tested across holding periods and tail widths:

| Hold | Tail | Notional traded | Gross annual | Sharpe | Breakeven |
|---|---|---|---|---|---|
| 5d | 1/10 | 3.471 | **+5.30%** | +0.24 | **6.1 bp** |
| 5d | 1/5 | 3.159 | +4.06% | +0.25 | 5.1 bp |
| 10d | 1/10 | 3.471 | −1.82% | −0.09 | −4.2 bp |
| 21d | 1/10 | 3.485 | −2.54% | −0.14 | −12.1 bp |
| 42d | 1/10 | 3.455 | −9.15% | −0.55 | −88.3 bp |

**Only the 5-day book has a positive gross return at all.** At 10 days and beyond the effect is gone and the sign flips — consistent with the reversal literature, where the effect lives at days-to-weeks and decays fast.

The unexpected part is the middle column: **turnover barely moves.** Holding for 42 days instead of 5 still trades ~3.46 of 4.00. That is because the signal has *no persistence* — a 5-day return is close to uncorrelated with the 5-day return measured 42 days later, so decile membership is redrawn essentially from scratch at every rebalance regardless of spacing. Slowing down therefore buys **no** turnover reduction while forfeiting all of the return.

That is the mechanism, and it is why this particular null cannot be engineered around: the horizon at which the signal exists and the horizon at which it would be cheap to trade are disjoint.

#### A second, independent blocker

**Indian cash equity has no overnight short selling.** A 5-day short leg needs single-stock futures, and those exist for only **129 of the 339 universe names (38%)** — on *today's* F&O list, which is an upper bound since the list was narrower historically.

So the short side — where §38's model made 95% of its calls — is unimplementable for nearly two-thirds of the universe. Restricting to F&O names would cut breadth by that much, and breadth is precisely what generated the IC in the first place.

Two independent reasons for failure is a sturdier conclusion than one.

#### The arc, complete

| Stage | Finding |
|---|---|
| §30 | No cross-sectional skill at 39 names (*t* = 0.92) — diagnosed as **underpowered**, not absent |
| §38 | At 400 survivorship-free names the signal **is** there: IC +0.0396, *t* = 2.24, 20/20 seeds |
| §38 attribution | It is **short-term reversal** — and one raw feature beats the model |
| §39 | It is **not tradeable**: breakeven 6.1 bp, no configuration clears 25 bp |

**The eleventh negative result, and the one that completes the story rather than deferring it.** The honest summary of this project's central question is now a single sentence: *there is a small, real, statistically solid cross-sectional signal in liquid NSE equities, it is a long-known effect rather than anything learned, and it is worth less than the cost of trading it.*

That is a more useful place to stop than an unresolved positive. A statistically significant result left uncosted would have been the most misleading thing this repository could ship.

---

### 40. Range-based volatility (Sharma & Mehta Ch. 18) — the twelfth negative result

*Deep Learning Tools for Predicting Stock Market Movements* (Sharma & Mehta, eds., 2024) is mostly surveys, bibliometrics and questionnaire-based behavioural studies — Ch. 4, 7, 8, 10–15 and 17 contain nothing implementable, Ch. 2 and 5 are quantum computing, and Ch. 1's LSTM+ARIMA+sentiment stack is already here minus the sentiment feed [§26](#26-book-coverage-what-was-taken-what-was-left-and-why) rejected as licensed.

**Ch. 18** (Kaur & Chaudhary, "Volatility Transmission Role of Indian Equity and Commodity Markets") is the exception, and its useful contribution is not the Diebold-Yilmaz spillover model in the title. It is one line of methodology:

> σ²ᵢₜ = 0.361 · [ln(Pʰⁱᵍʰᵢₜ) − ln(Pˡᵒʷᵢₜ)]²

with the note that "literature has proven the advantage of using a range-based volatility estimator as compared to the traditional method". That constant is **1/(4 ln 2) = 0.3607** — the **Parkinson (1980)** estimator.

#### The gap it pointed at

`HAR_RV_model` builds its variance series as `RV_t = r_t²`, and its own docstring calls that *"the standard proxy **when sub-bar data is unavailable**"*. Sub-bar data is not unavailable: every bar the app fetches carries **open, high and low**, used for features and never for the variance estimate that drives the uncertainty cone — which this README names as the actual product.

The motivating case is stark. A bar that opens at 100, runs to 108, falls to 94 and closes at 100 has `r_t = 0` and therefore **zero** estimated variance. The range saw all of it.

`range_volatility.py` implements Parkinson, Garman-Klass, Rogers-Satchell and Yang-Zhang. Against a synthetic process with known variance the efficiency gains land on theory: **Parkinson 5.07×** (theory 5.2), **Garman-Klass 6.77×** (7.4).

**On real NSE bars the gain is 1.6–2.5×, not 5×** — real bars trade discretely, so the observed high and low understate the true extremes. The measured number is the one reported.

#### A trap, hit and then pinned

Range estimators are **within-bar ratios**, so they are invariant to any rescaling of a bar's prices and therefore immune to split and dividend adjustment. Close-to-close returns are not.

`scale_to_total` compares the two, to restore the overnight variance an intraday estimator misses. Measured with **raw** closes, TATASTEEL's scale factor came out at **8.32** (level ratio 0.120); with adjusted closes, **1.26** (0.794). Four of six names were corrupted this way — only the two without splits in the window were unaffected. The function now flags implausible factors, and `test_scale_to_total_flags_an_unadjusted_close` exists so it cannot recur.

The honest level ratios: the intraday range captures **64–85%** of close-to-close variance. The rest happens overnight, when earnings and news land — which is why a naive substitution would have understated the cone and caused under-coverage.

#### The A/B, and two corrections to my own analysis

12 names, 24 walk-forward origins, horizon 5, measuring **coverage and width together** — width alone is meaningless because the conformal layer rescales the cone to target and would absorb a constant bias in the variance estimate.

| Estimator | Mean width Δ | sd | **Paired *t*** | Wins |
|---|---|---|---|---|
| parkinson | +0.48% | 5.51% | **0.30** | 6/12 |
| garman_klass | −0.17% | 5.44% | **−0.11** | 6/12 |
| rogers_satchell | −1.11% | 5.87% | **−0.65** | 7/12 |

Every |*t*| < 1, win rates are coin flips, and the per-ticker spread runs −8.5% to +10%. **No estimator changes the cone.**

Getting there required correcting the work twice, and both corrections are the point:

**1. The first run was underpowered and said the opposite.** At 8 origins the range estimators looked **8–12% worse**; at 24 origins the sign flipped to 1.4% *better*. A result that reverses when power is added was never a result. [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) published an underpowered null that [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) later overturned; applying that lesson to *this* measurement rather than only to the older ones is what caught it.

**2. The verdict logic was over-claiming.** It declared "rogers_satchell wins at −1.4% width" from a paired *t* of −0.65 — precisely the error the rest of this project exists to prevent, written into the new driver. Replaced with a **paired** test that compares each ticker against itself, so the large between-name variation is differenced out instead of averaged into a decisive-looking mean, and that requires |*t*| > 2 before naming a winner.

#### Why it fails — a more precise measurement of the wrong quantity

`scale_to_total` restores the missing overnight variance with a **constant** factor, but the intraday/overnight split is not constant — it moves with the news and earnings cycle. The range estimators therefore trade *sampling noise* for a *time-varying bias*.

They are genuinely better at measuring the **last** bar's variance (2× more precise, measured) and no better at forecasting the **next** one, which is the only thing the cone needs. That distinction is the finding, and it generalises: an estimator's efficiency at describing history is not the same property as its usefulness in a forecast.

`range_volatility.py` ships complete, tested (18 tests) and wired into `run_har_rv_prediction(rv_estimator=...)`. **The shipped default stays `'squared'`**, per this project's standing rule that an unvalidated change does not ship.

*(A note on the coverage column: every arm, baseline included, covers ~0.919 against a 0.95 target in this walk-forward configuration. That is a property of the configuration, not of the estimator choice, and it does not affect the comparison — but it is worth not glossing.)*

---

### 41. Open interest, and a look-ahead worth 2.9 sigma — the thirteenth negative result

Every negative result before this one was measured on a **transformation of OHLCV**: more models, more architectures, fractional differencing, range volatility, cross-sectional ranks. [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) was the single attempt at a second data axis and it died on *coverage*, not on evidence.

**Open interest is the first genuinely orthogonal, obtainable data source this project has found.** It measures *positioning* — how many contracts are open — and is not derived from price at all. `nselib.derivatives.future_price_volume_data` serves it historically and free. So the question is different in kind from "does another function of price help", which has now been answered twelve times.

#### The claim, reduced

Ch. 3 (Bakshi, "Analyzing Open Interest") gives a 2×2 interpretation table with **no backtest, no statistics and no validation anywhere in the chapter**:

| Price | OI | The chapter's claim |
|---|---|---|
| Rising | Rising | Strongly bullish; trend continues |
| Rising | Falling | Short-covering rally; downtrend next |
| Falling | Rising | Aggressive short-selling; bearish continues |
| Falling | Falling | Forced liquidation; upward move may start |

Read as a predicted sign, that table is exactly

```
signal = sign(Δprice) × sign(ΔOI)
```

**+1 when the two agree, −1 when they diverge.** The whole chapter collapses to one product of two signs, which is convenient — it turns four rules into a single testable signal.

Tested on 60 liquid F&O names over 2023–2024 (479 dates), with ΔOI from the **near-month** contract and both Δprice and the forward return from the survivorship-free, corporate-action-adjusted [`bhavcopy`](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) panel.

#### It looked real

| Horizon | Mean IC | **FM *t*** |
|---|---|---|
| 1 day | +0.0198 | **+2.88** |
| 5 day | +0.0078 | +1.12 |

At one day that clears the conventional threshold, on a genuinely orthogonal data source, with all four quadrants leaning the direction the chapter predicts. It would have been the project's second positive finding.

#### It was a publication-timing look-ahead

**NSE publishes the F&O bhavcopy — and therefore open interest for date *t* — after the close of *t*.** You cannot trade at the close of *t* on a number that does not exist until afterwards. The earliest possible entry is the close of *t+1*, so the honest forward return runs from *t+1*.

| Variant | Mean IC | **FM *t*** |
|---|---|---|
| 1d, trade at close *t* — **not tradeable** | +0.0198 | **+2.88** |
| 1d, **tradeable** (one-day lag) | −0.0018 | **−0.27** |
| 5d, trade at close *t* | +0.0078 | +1.12 |
| 5d, **tradeable** | +0.0004 | +0.05 |

**The effect does not decay under the lag — it vanishes**, and flips sign. Out of period it is nothing in both halves: 2023 *t* = **+0.11**, 2024 *t* = **−0.50**.

The entire 2.9-sigma result was one day of hindsight.

#### Why this one is worth a section

Nothing here was a modelling choice. The features, the horizon, the universe and the statistic were all fixed before the number appeared; the only thing that changed was **whether the data existed when the trade would have been placed**. A one-day misalignment on a daily signal manufactured an IC of +0.02 at *t* = 2.88 out of an effect of exactly zero.

That is a useful calibration on every "significant" daily-frequency result in this literature, and on the chapter itself — which asserts its table confidently and never tests it at all. The driver now prints **both** rows, labelled, so the gap is visible rather than reconstructible:

```
naive  (trade at close t -- NOT tradeable) IC +0.0198  t +2.88  SIGNIFICANT
HONEST (trade at close t+1)                IC -0.0018  t -0.27  not significant
```

Two further reasons the tradeable version was never going to survive even if it had held: only **38% of a liquid NSE universe is F&O-eligible** ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)), so breadth is cut by two-thirds; and a **one-day** signal implies ~100% daily turnover against the ~20 bp of STT alone that §39 measured, where a 5-day signal at 6.1 bp breakeven already failed.

**The thirteenth negative result, and the first to rule out an orthogonal data source rather than another feature of the same one.** The book's only empirically testable claim does not survive contact with its own publication schedule.

---

## Reading the screen: which numbers support a decision

The app puts a lot of numbers on one page, and they are **not equally load-bearing**. This section is the user's guide to them: what each one is, what value counts as strong or weak, and — the part that matters — which decision it can actually support.

**The one-sentence version.** This app is built to tell you *how uncertain the next move is* and *whether any model has demonstrable skill on this ticker right now*. It is not built to tell you where the price is going. The decisions it genuinely supports are therefore **abstain / size / set a stop** — not **buy / sell**. Every design choice below follows from that, including the ones that deliberately withhold a number you might want.

### Read it in this order

The layout is deliberately top-down: each block gates the one below it. Reading it out of order is the single most common way to reach a wrong conclusion from a correct screen.

1. **🩺 Data-quality banner** — is the *input* sound? If this is red, stop here; nothing below it is meaningful.
2. **Abstention banner** — how many of the selected models beat a random walk on this ticker/horizon.
3. **Consensus cards** — median forecast, and the bullish / bearish / abstained split.
4. **Confidence and Basis columns** — the per-model verdict and *why* it got that verdict.
5. **Risk & Probability panel** — the actual deliverable: range, VaR, expected shortfall, probabilities.
6. **Signal Score and Conviction** — worth reading only for rows that cleared step 4.
7. **Per-model charts** — the 95% band against the grey dotted random-walk line.

**Row order in the Model Comparison table is not a ranking.** The table is sorted for display, not by merit, and the lowest-error model is not a winner: across the full set, White's Reality Check and Hansen's SPA found no selection-bias-free edge over a random walk (*p* ≈ 0.9). Reading the top row as "the best model" is exactly the data-snooping error the whole evaluation layer exists to prevent.

### Step 1 — the data-quality banner decides whether to continue

| Banner | Mode | What to do |
|---|---|---|
| 🩺 *Data quality OK (score n/100)* | `ok` | Continue. |
| ⚠️ *Data-quality caveats* | `warn` | Continue, but widen your margin — something in the feed is imperfect. |
| ⚠️ *Event risk detected — showing the risk cone* | `risk_cone_only` | **No directional call.** An earnings date or a gap is inside the window; the range is the only output. |
| ⛔ *Forecast withheld — data quality insufficient* | `abstain` | **Stop.** Directional calls are already suppressed. Refetch, or pick another ticker. |

Open **Data-quality details** for the reason codes. This gate runs on the fetched series at request time and catches a broken *input*; it says nothing about whether the model is any good — that is step 2.

### Step 2 — the abstention banner is the honest headline

| Banner | Meaning | Decision |
|---|---|---|
| 🔴 *No model showed a statistically reliable edge* | zero of *n* models reached High or Medium | Treat the **range** as the entire output. Do not act on the point forecast. |
| 🟠 *Only k of n models beat the baseline* | fewer than half | Weight the range heavily; the point line is weak evidence. |
| 🟢 *k of n models showed a measurable edge* | at least half | The strongest state this app produces — and still small-sample (see below). |

The red banner is the **expected** state for most tickers at short horizons. It is a finding, not a malfunction.

### Step 3 — consensus cards, and why the vote count is not a vote

**Median Forecast** is the median across selected models, with its percentage change. **Models Bullish / Bearish** counts the directional calls that survived gating, and a caption reports how many were withheld.

Two cautions that matter more than the numbers:

- **The models are not independent voters.** They share the same OHLCV history, largely the same engineered features, and in several cases the same family. "14 of 19 bullish" is emphatically *not* fourteen independent opinions — it is closer to one opinion, computed fourteen ways, with correlated errors. Treat agreement as weak corroboration, never as a probability.
- **The median is more robust than any single row**, which is precisely why it is the headline. If the median and your chosen model disagree sharply, the model is the outlier, not the median.

### Step 4 — Confidence and Basis: the only skill claim on the page

**Confidence** comes from a walk-forward backtest run at request time on recent history, and it is the single most decision-relevant column. The rule (`backtest.confidence_bucket`) is fixed and auditable:

| Bucket | Rule | How to read it |
|---|---|---|
| **High** | RMSE improvement > 5% over the best naive baseline, **and** Diebold-Mariano *p* < 0.10, **and** 95% coverage within 0.85–0.99 | A measurable edge with trustworthy bands. |
| **Medium** | improvement > 2% and DM *p* < 0.20 | A modest, weakly significant edge. |
| **Low** | improvement > 0, but not significant | Better than the random walk *within noise*. Not evidence. |
| **No edge** | no improvement | No better than assuming the price stays put. **The directional call is withheld.** |
| **No data** | insufficient history for the check | Unassessed — treat as No edge. |

**The honest caveat, which belongs next to every High you ever see:** this gate runs **3 origins on at most 600 rows** (`_GATE_SPLITS = 3`), because it must return while a user waits. Three origins is enough to catch a model that is clearly broken; it is *not* enough to establish skill. A **High** here means "worth a closer look with `run_backtest.py` on more origins", not "proven". Conversely, **No edge** on three origins is quite reliable — it is much easier to fail to beat a random walk convincingly than to beat one by luck three times.

**Basis** is the plain-language reason, so no row shows a bare verdict:

| Basis text | What happened |
|---|---|
| `beats random walk (DM p=…, cov …%)` | High — with the actual p-value and coverage shown. |
| `weak edge (DM p=…)` | Medium. |
| `within noise (+…% vs RW, DM p=…)` | Low — note the improvement is stated so you can see how small it is. |
| `no edge vs random walk (DM p=…)` | No edge. |
| `withheld — data quality` | The data-quality gate overrode the skill test. |
| `withheld — unseen market regime` | The novelty gate fired: current conditions are off-manifold, so a backtest-derived bucket would be an extrapolation. (Ships off by default.) |
| `… · unusual regime` | An advisory suffix — conditions are unusual but not unprecedented; the verdict stands, with a caveat. |

**HAR-RV always reads No edge, and that is correct.** It makes no point-forecast claim by design; its entire output is the calibrated risk cone. Do not read its bucket as failure — and do not deselect it, because the fat-tailed risk panel depends on it.

### Step 5 — the Risk & Probability panel is the deliverable

| Metric | What it is | What decision it supports |
|---|---|---|
| **Likely range (95%)** | the calibrated interval at the horizon | **The primary output.** Stop placement, position sizing, whether the trade you had in mind is even distinguishable from noise. |
| **P(price up)** | probability of finishing above today | Direction only if it is far from 50% — see the calibration warning below. |
| **P(gain > +x%) / P(loss > x%)** | probability of a move beyond your threshold (set it yourself) | "Is my target plausible at this horizon?" Often the most useful number on the page. |
| **95% downside (VaR)** | the 5th-percentile price | A worst-case-but-not-extreme reference for sizing. |
| **Expected shortfall** | the *average* outcome in that worst 5% | What a bad day actually costs, not just where it starts. Always worse than VaR. |
| **Downside / upside vol** | dispersion split by direction | Whether the risk is symmetric. |
| **Vol skew (down/up)** | their ratio | **> 1 means the downside is the fatter side.** Size smaller when it is. |

Two things to check before trusting this panel:

- **Read the caption.** *"Probabilities are counted directly off the empirical, fat-tailed return distribution"* means HAR-RV (or Vol-LSTM) was in the run and the tail is real. *"⚠️ Approximate read"* means no fat-tailed model was selected and each 95% band was approximated as log-normal — which **understates tail risk**, the one thing you least want understated. Add **HAR-RV** to the selection and re-run.
- **Treat P(up) as ordinal, not cardinal.** A probability read second-hand off a regression interval is not a calibrated probability, and this project measured that directly: the same construction scored **ECE ≈ 0.31** in the cross-sectional work ([§29](#29-cross-sectional-classification-pooling-the-universe)), i.e. a "60%" could be off by roughly 30 points. Use it to rank ("further from 50% than yesterday"), not as a number to bet proportionally on. The properly calibrated alternative — a classifier asked *directly* for a probability, reaching ECE 0.0139 — exists in `cross_sectional_model.py` but is **not wired into the UI**.

### Step 6 — Signal Score and Conviction, for rows that earned it

**Signal Score (%)** is the model's forecast percentage change to the horizon. It is the value the Bullish/Bearish call is computed from, and on its own it is close to meaningless: a +3% signal from a **No edge** model is a number a random walk would also produce.

**Conviction** = the forecast move ÷ half the model's own 95% band.

| \|Conviction\| | Reading |
|---|---|
| < 0.5 | Within the model's own noise. Ignore the direction. |
| 0.5 – 1.0 | A real move relative to its uncertainty, but inside the band. |
| ≥ 1.0 | The move exceeds the model's 95% band — the current price sits outside it. High conviction. |
| — | The model emits no interval. |

**The trap:** conviction is measured against *the model's own* band, so a model with a badly narrow band manufactures high conviction. That is why the two columns must be read together — a high Conviction on a row whose Basis reports poor coverage is an over-confident model, not a strong signal. Coverage in the 0.85–0.99 window is one of the three conditions for **High**, which is why High + Conviction ≥ 1 is the only combination worth weight.

### Step 7 — the charts

Each chart overlays history, the forecast line, the shaded 95% band, and a **grey dotted random-walk baseline**. The question the chart answers is not "where does the line go" but **"is the forecast line meaningfully outside the grey line's band?"** Usually it is not. That is the honest picture of short-horizon equity forecasting, and seeing it is the point of drawing the baseline at all.

### Feature flags: one registry, with the evidence attached

Six `USE_*` toggles decide what the app actually does, and they used to be defined wherever they happened to be consumed — five in `UI.py`, one in `ML_model.py`. That is fine until something needs to read **all of them at once**, and the console startup banner does. Building it meant importing a flag out of a model module purely to display it: the UI depending on `ML_model` for a piece of configuration, which is the wrong direction.

`config.py` is now the single source of truth. It imports nothing from this project, so anything may import it.

| Flag | Ships | Owning module |
|---|---|---|
| `USE_MARKET_CONTEXT` | off | `market_context.py` |
| `USE_IV_ADJUST` | off | `iv_data.py` |
| `USE_ASYMMETRIC_CONE` | off | `HAR_RV_model.py` |
| `USE_INTRADAY_FEATURES` | **on** | `ML_model.py` |
| `USE_REGIME_NOVELTY` | off | `autoencoder_regime.py` |
| `USE_PREDICTION_LOG` | **on** | `prediction_log.py` |

Three properties are worth more than the tidiness:

**The rationale lives with the flag.** Each registry entry carries the measured result behind its default, so "why is this off?" is answerable without hunting through a README section. Four of the six are off because an A/B said so. `python config.py` prints the whole set with reasons.

**The banner is generated, not hand-listed.** `active_flags()` derives it from the registry, so a flag added here appears in the console automatically. A flag the operator cannot see is a flag that silently changes results, and a hand-maintained display list is how one goes missing — `test_active_flags_covers_the_whole_registry` pins it.

**Every flag has an environment override.** `STOCKAPP_USE_MARKET_CONTEXT=1` flips one for a single run, and `STOCKAPP_USE_INTRADAY_FEATURES=0` is the A/B that section [§3](#3-feature-engineering) says is still owed. Editing a constant to run an experiment is how experiments end up committed by accident. A malformed value falls back to the default rather than raising: a stray `export` should fail to take effect, not stop the app.

Overrides are **called out in the banner**, because a run with one active is not the shipped configuration and its numbers need reading that way:

```text
  OVERRIDDEN      USE_MARKET_CONTEXT  <- not the shipped default; read results
                  accordingly
```

The serve-time gate constants (`GATE_SPLITS = 3`, `GATE_MIN_TRAIN`, `GATE_MAX_ROWS`) moved here too and are env-tunable. That makes the trade-off visible rather than buried: raise `STOCKAPP_GATE_SPLITS` for a stronger confidence check at the cost of a slower Submit — see [step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page) for why three origins is a filter and not proof.

One deliberate wrinkle: `ML_model` does `from config import USE_INTRADAY_FEATURES` rather than reading it through the module, so `ML_model.USE_INTRADAY_FEATURES` stays monkeypatchable by the existing parity tests.

### The same story in the terminal

Running `streamlit run UI.py` from `cmd` used to print a long, interleaved trace of per-model chatter — *"Fitting Auto-ARIMA..."*, *"Simulating 10000 price paths..."*, *"Prediction Complete."* — and **nothing about what the app concluded**. Nineteen models would announce completion and the terminal could not tell you whether a single one of them had beaten a random walk. The conclusion is the product; it was browser-only.

`console.py` closes that gap. It adds three blocks around the existing trace:

```text
================================================================================
 Stock Prediction  |  seed 42  |  CPU  |  20 models
================================================================================
  optional layers market-context=off   IV-tilt=off
                  asymmetric-cone=off   intraday-features=on
                  regime-novelty=off   prediction-log=on
  prediction log  .prediction_log/predictions.jsonl
  guide           README.md > "Reading the screen: which numbers support a
                  decision" explains every number below.
  quiet mode      set STOCKAPP_QUIET=1 to silence this output.
================================================================================
--------------------------------------------------------------------------------
RUN  RELIANCE.NS  |  1d  |  horizon 5  |  4 model(s)  |  14:23:07
--------------------------------------------------------------------------------
... the existing per-model trace ...
--------------------------------------------------------------------------------
RESULT  RELIANCE.NS  1d  h=5  (37.4s)
  data quality    OK (score 92/100) -> forecasts usable
  regime          novelty gate off (USE_REGIME_NOVELTY = False)
  confidence      HAR-RV         No edge   no edge vs random walk (DM p=0.55)
                  Meta-Ensemble  Medium    weak edge (DM p=0.14)
                  Quantile-LGBM  Low       within noise (+1% vs RW, DM p=0.31)
                  Chronos-2      No edge   no edge vs random walk (DM p=0.61)
  consensus       median 1,423.55 (+0.84%)  |  bullish 2  |  bearish 1  |
                  withheld 1
  verdict         Only 1 of 4 models beat the random-walk baseline with any
                  reliability here. Weight the range over the point line.
  logged          4 row(s) -> .prediction_log/predictions.jsonl
--------------------------------------------------------------------------------
```

**The startup banner** answers a question the console previously could not: *which version of the app is this?* Five `USE_*` flags materially change what the models produce, and an operator watching `cmd` had no way to tell which were active. The seed and device are there for the same reason — a reported number is not reproducible unless you know both.

**The `RUN` header** simply frames each Submit, so one run's trace is separable from the next in a long scroll.

**The `RESULT` block is the console mirror of the browser's decision layer**, and it maps line-for-line onto the sections above:

| Console line | UI equivalent |
|---|---|
| `data quality` | the 🩺 banner ([step 1](#step-1--the-data-quality-banner-decides-whether-to-continue)) |
| `regime` | the novelty gate's Basis annotation ([step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page)) |
| `confidence` | the Confidence + Basis columns ([step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page)) |
| `consensus` | the consensus cards ([step 3](#step-3--consensus-cards-and-why-the-vote-count-is-not-a-vote)) |
| `verdict` | the abstention banner ([step 2](#step-2--the-abstention-banner-is-the-honest-headline)) |
| `logged` | (browser-silent) rows appended to the forward prediction log |

**It renders verdicts; it never recomputes them.** The buckets come from the same `conf_map`, the reasons from the same `gating.confidence_reason`, and the verdict sentence from the same `_honesty_banner` the browser renders — passed through `strip_markdown` so the one authored sentence serves both channels. Re-deriving any of it here is precisely how two surfaces start telling a user different things. The one deliberate ordering choice: the honesty banner is re-read **after** the data-quality and novelty gates have been applied, so a degraded run reports the withheld verdict rather than the pre-gate one.

**Two robustness details that are not cosmetic.** Output is plain **ASCII**, and every write is wrapped: a Windows `cmd` session on a legacy code page cannot encode `₹` or `—`, and an unguarded `print` there raises `UnicodeEncodeError` — which would let a log line kill a forecast. `_write` degrades to a replacement character instead, and `test_write_survives_a_legacy_console_encoding` pins that. The banner is also printed **once per process** via a module-level flag rather than `st.session_state`, because Streamlit re-executes `UI.py` top-to-bottom on every widget interaction and a naive banner would reprint on each click.

Set **`STOCKAPP_QUIET=1`** to silence all of it; the per-model model chatter is unaffected either way.

### Putting it together

| Screen state | Supported decision |
|---|---|
| DQ red (`abstain`) | Act on nothing. Fix the data. |
| Event risk / `risk_cone_only` | Size for the range. No direction, whatever the table says. |
| Red abstention banner, all No edge | Range-only. If your thesis needs a direction, this app does not supply one — that is information, and it is worth acting on. |
| Mixed, your model High + Conviction ≥ 1 + agrees with the median | The strongest state available. Still 3 origins — confirm with `run_backtest.py` before sizing up. |
| High conviction, but Basis shows poor coverage | An over-confident model. Discount it. |
| P(loss > x%) materially exceeds P(gain > +x%) at the same *x*, vol skew > 1 | Asymmetric downside. Size down or widen the stop. |
| "⚠️ Approximate read" caption | Re-run with HAR-RV before using any tail number. |

### What the screen cannot tell you

Stated plainly, because a guide that only explains the numbers implies they cover more than they do:

- **Whether to buy.** No entry signal is produced anywhere, by design.
- **Anything about fundamentals, news, or announcements.** Inputs are OHLCV and a market proxy. A result that will be obsolete the moment an earnings release lands is not flagged as such beyond the event-risk gate.
- **Which model is best.** SPA and the Reality Check say the data cannot support that claim.
- **Real-world probability.** Every probability is conditional on the model and on the past resembling the future. It is model uncertainty, not certainty.
- **Anything validated at longer horizons.** The evidence base here is short-horizon daily and hourly.

**Before acting, three questions:** Is the data-quality banner green? Does the range — not the point forecast — still make the position worth taking? And is there a single number on the page that would look different if the model had no skill at all? If the answer to the last one is no, the screen is telling you to do nothing, which is a legitimate output and the one it produces most often.

---

## Evaluation and backtesting

You cannot trust a forecasting model until it is tested **out-of-sample on a moving window**. `backtest.py` provides this.

### Walk-forward backtesting

`walk_forward_backtest(df, predict_fn, interval, horizon, n_splits, ...)` picks several **origins** spread through history; at each origin it re-fits the model on data up to that point, forecasts the next `horizon` steps, and compares to what actually happened. This mimics real deployment (you only ever know the past).

### Baselines

Every forecast is compared to a ladder of **baselines**, not just one, because "beats the random walk" is a surprisingly weak bar:

- **Naive (random walk)** — the next `horizon` prices all equal the last observed price. The primary benchmark; a model that can't beat it adds no value.
- **Drift** — random walk plus the mean historical log-return. Beats naive whenever there's any trend.
- **AR(1)** — a first-order autoregression on log returns. Beats naive whenever there's short-horizon return autocorrelation.

A model should ideally clear all three. The leaderboards report `naive_rmse`, `drift_rmse`, and `ar1_rmse` side by side.

### Is the edge real? The Diebold-Mariano test

RMSE deltas on near-random-walk returns are often *inside the noise band*, so "model RMSE < naive RMSE" on a handful of origins can be luck. The **Diebold-Mariano (DM) test** (`backtest.diebold_mariano`) asks whether the loss differential between the model and the naive walk is **statistically** different from zero. It uses a HAC (Newey-West) long-run variance with `h−1` **Bartlett-weighted** lags — to account for the autocorrelation that overlapping multi-step forecasts create — plus the Harvey-Leybourne-Newbold small-sample correction. The Bartlett weighting is not cosmetic: an unweighted sum is not positive semi-definite and returned `NaN` on up to 48% of short samples ([§37](#37-the-diebold-mariano-kernel-fix-and-the-windows-race-it-uncovered)). The harness reports the statistic (negative ⇒ model more accurate), a two-sided p-value, and a plain verdict (significantly better / not significant / significantly worse). The leaderboards carry `dm_p` and `dm_sig`.

### Metrics

| Metric | What it measures | Good value |
|---|---|---|
| **RMSE / MAE** | Average price error | lower |
| **SMAPE** | Symmetric percentage error | lower |
| **MASE** | Error **scaled by the naive forecast's error** — directly comparable across tickers | < 1 beats one-step naive |
| **Directional accuracy** | Fraction of steps whose up/down direction is correct | > 0.5 beats chance |
| **Coverage** | Fraction of actual values inside the 95% interval | ≈ 0.95 |

`MASE` and `directional accuracy` are scale-free, so they're the right metrics to compare across stocks; raw RMSE is not (it depends on the price level).

**Economic metrics run alongside them.** `walk_forward_backtest` also returns a `strategy` block (`strategy_metrics.evaluate_strategy`) that turns the same forecasts into a cost-charged return stream and reports **Sharpe, Sortino, information ratio vs buy-and-hold, maximum drawdown, information coefficient, hit rate and turnover** — because a good RMSE and a profitable forecast are separate claims, and only the second one is what a user of a forecast wants. See [§22](#22-economic-evaluation-does-the-forecast-make-money). Pass `strategy=False` to skip it, `cost_bps=` to change the cost assumption, and watch the `overlapping_origins` flag: if the origin spacing is shorter than the horizon the trades overlap and every risk-adjusted figure is optimistic.

### Running the backtests

These manual evaluation drivers live in `tests/validation/` (run from the repo root):

```bash
# Whole suite on one ticker
python tests/validation/run_full_backtest.py AAPL

# Variance-aware ranking across several tickers (mean ± std per model)
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL"
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL" --fast   # exclude the slow neural nets

# Validate the UNCERTAINTY (CRPS / PIT / reliability / coverage quality)
python tests/validation/run_calibration.py RELIANCE.NS              # HAR-RV + XGBoost diagnostics
python tests/validation/run_calibration.py RELIANCE.NS --with-gate  # + nested gate validation (slower)
python tests/validation/run_calibration.py RELIANCE.NS --quick      # fewer origins for a fast smoke run

# Data-snooping-robust selection: does ANY of K models beat the random walk?
python tests/validation/run_spa.py RELIANCE.NS                       # White RC + Hansen SPA (fast subset)
python tests/validation/run_spa.py RELIANCE.NS --full                # include the neural nets

# Stress-period ACI evaluation (cone behaviour across 2020/2022 vs calm)
python tests/validation/run_stress_test.py RELIANCE.NS

# ECONOMIC leaderboard: would acting on each forecast have made money after costs?
python tests/validation/run_strategy_eval.py RELIANCE.NS               # full suite
python tests/validation/run_strategy_eval.py RELIANCE.NS --fast        # statistical + trees only
python tests/validation/run_strategy_eval.py RELIANCE.NS --cost 25     # stress the cost assumption
python tests/validation/run_strategy_eval.py RELIANCE.NS --deadband    # only trade above the cost hurdle

# VaR: compare five estimators, then Kupiec / Christoffersen them
python tests/validation/run_var_backtest.py RELIANCE.NS
python tests/validation/run_var_backtest.py RELIANCE.NS --alpha 0.01   # the 1% tail
python tests/validation/run_var_backtest.py RELIANCE.NS --horizon 5    # 5-day VaR

# Volatility models head-to-head: HAR-RV vs Vol-LSTM vs GARCH vs EWMA
python tests/validation/run_vol_comparison.py RELIANCE.NS
python tests/validation/run_vol_comparison.py RELIANCE.NS --quick      # fewer origins
python tests/validation/run_vol_comparison.py RELIANCE.NS --online     # + Ch.5 online-learning arm
```

The first two drivers checkpoint results to CSV and are **resumable** if interrupted; `run_calibration.py` prints its calibration tables directly (it validates the probabilistic outputs rather than ranking point forecasts — see [§14](#14-validating-the-uncertainty-calibration)). `run_strategy_eval.py`, `run_var_backtest.py` and `run_vol_comparison.py` answer the three questions the statistical leaderboards do not: *is it profitable*, *is the risk number calibrated*, and *does the deep volatility model beat the four-parameter regression*.

---

## Empirical findings

Numbers below are **indicative, not definitive** — a few tickers and origins, so treat them as directional evidence rather than precise rankings. The point is the *method*: walk-forward + a baseline ladder + the Diebold-Mariano significance test, so claims are grounded.

**Multi-ticker leaderboard** (RELIANCE.NS / TCS.NS / INFY.NS, 4 splits, 5-day horizon, ranked by mean RMSE):

| Model | RMSE mean | beats-naive rate | DM-significant wins | MASE |
|---|---|---|---|---|
| **Ensemble-Stack** | **28.06** | 3/3 | TCS (p=0.0002) | 1.37 |
| ARIMA+GARCH | 32.11 | 3/3 | TCS (p=0.003) | 1.54 |
| RegimeSwitching | 32.47 | 3/3 | TCS, INFY | 1.55 |
| ARIMAX+GARCH | 32.53 | 1/3 | TCS (sig. *worse* on INFY) | 1.56 |
| Meta-Ensemble | 33.15 | 1/3 | — | 1.59 |
| XGBoost / LightGBM / Quantile-LGBM | 33.4–33.8 | 0–1/3 | — | ~1.6 |
| LSTM | 33.98 | 0/3 | — | 1.57 |
| N-BEATS | 63.78 | 0/3 | sig. *worse* (TCS RMSE 111) | 2.41 |

**What the evidence says:**

- **The Diebold-Mariano test is essential.** Several models "beat naive" on RMSE, but statistically-significant edge is **rare and ticker-specific** (concentrated on TCS; none on RELIANCE). "Beats the random walk" on a handful of origins is often inside the noise band — exactly why the DM test was added.
- **The Ensemble-Stack and the statistical models** (ARIMA / Regime-Switching) are the most consistent performers (beat naive on all three tickers; the only DM-significant *wins*).
- **MASE > 1 almost everywhere** — against the one-step naive, genuine multi-step skill is thin at a 5-day horizon.
- **N-BEATS is still unstable** on these tickers (blew up to RMSE 111 on TCS); the earlier capacity reduction helped on US data but isn't sufficient here. Neural nets remain high-variance — never trust a single run's NN ranking.
- **Prophet over-extrapolates** and was under-covered (~0.7–0.78) on some tickers.

**Did market context help? No (the honest result).** A controlled A/B (context ON vs OFF, same models/splits) on the two large-cap Indian tickers:

| Model | RELIANCE Δ RMSE | TCS Δ RMSE | Effect |
|---|---|---|---|
| XGBoost | +10.3% | +6.4% | worse |
| LightGBM | +5.0% | +10.9% | worse |
| Quantile-LGBM | +2.9% | −0.1% | worse / neutral |
| Ensemble-Stack | +0.2% | +0.3% | neutral |
| ARIMAX+GARCH | −0.2% | +0.7% | neutral |

(Δ = change in RMSE; positive = worse.) Adding the eight context columns **hurt the single tree models** and was **neutral** for the ensemble/ARIMAX — none improved. At a 5-day horizon the *contemporaneous* market state has little power over the *next week's* return (the market is itself a random walk), so the extra columns mainly added overfitting surface.

**And excess-return reframing didn't help either.** Predicting the *excess* return (stock − market) instead of the absolute return — A/B'd the same way:

| Model | RELIANCE Δ RMSE | TCS Δ RMSE |
|---|---|---|
| XGBoost | +12.5% | +5.7% |
| LightGBM | +11.2% | +2.4% |
| Quantile-LGBM | +3.5% | +7.8% |
| Ensemble-Stack | −3.4% | +1.6% |

Same pattern — worse for the tree singles, neutral for the ensemble. This is the expected result: because the expected short-horizon market return is ~0, reconstruction re-injects the unforecastable market move, so absolute-price RMSE can't improve unless de-noising the target makes the alpha much more learnable (it doesn't, on single stocks at this horizon). **Conclusion across both experiments: market data helps cross-sectional/ranking problems ("which stock will beat which"), not single-stock absolute-price forecasting at a 5-day horizon.** Both features ship **off by default**.

**Cross-sectional probe (the ranking fork).** A 20-name NSE universe (`run_cross_sectional.py`) showed **12-1 momentum** with the correct sign (rank-IC ≈ +0.02, long-short hit-rate up to 59%) but **not statistically significant** (t ≈ 1) — expected, since real cross-sectional factors have small ICs that need *hundreds* of names to detect. So a ranking product is plausible but unconfirmed at this scale, and pursuing it is a deliberate product fork (rank a universe), not a tweak to the single-ticker app.

**HAR-RV coverage (where the value actually is).** HAR-RV's point RMSE equals the random walk by construction (it *is* the walk); its deliverable is the cone. With the per-horizon **conformal** multiplier, coverage improved (e.g. RELIANCE ~0.80 → ~full) but still under-covers on some tickers (TCS/INFY ≈ 0.80 vs 0.95 target). The residual gap is **static conformal meeting a volatility regime shift** in the unseen horizon — the known limitation that motivates *adaptive* conformal (ACI) in an online monitoring loop (a deployment feature, not a one-shot tweak). Coverage estimates are also noisy at ~25 points.

**Calibration of the probabilistic outputs (`run_calibration.py`).** Validating the uncertainty rather than the point forecast — illustrative single-ticker run (RELIANCE.NS, 5-day horizon, 6 origins):

| Diagnostic | Result | Read |
|---|---|---|
| HAR-RV CRPS, **empirical vs log-normal** (final horizon) | **24.63 vs 25.35** | The fat-tailed empirical read scores *better* — the §13 risk-panel fix helps the proper score, not just in principle. |
| HAR-RV PIT vs Uniform(0,1) | mean 0.47, KS 0.16, **p ≈ 0.39** | Can't reject calibration — the conformal cone is roughly well-calibrated across quantiles, not just at 95%. |
| Coverage quality (per horizon) | coverage 0.83–1.0; tail-miss balance ≈ 0 to −0.17 | Near target; misses lean slightly *upside* here (cone isn't systematically under-stating downside on this name). |
| XGBoost **P(up) reliability** | **ECE ≈ 0.31** (overconfident in the 0.5–0.6 bin) | Directional probabilities are noisy/miscalibrated — the honest reason the app withholds the call when the gate says "No edge". |

These numbers are small-sample and single-ticker (illustrative, not a verdict); a firmer read uses more origins and several tickers (`--with-gate`, more `--splits`). The point is that the harness now *measures* whether the probabilities are honest.

**Adaptive (ACI) vs static conformal — does the adaptation earn its place?** A/B of HAR-RV's cone with `adaptive=False` vs `True` (3 NSE tickers, 18 origins, 5-day horizon, via `compare_static_vs_aci`):

| Ticker | static \|cov−0.95\| | ACI \|cov−0.95\| | static width | ACI width |
|---|---|---|---|---|
| RELIANCE.NS | **0.032** | 0.050 | 10.79% | 10.25% |
| TCS.NS | 0.041 | **0.032** | 10.75% | **9.81%** |
| INFY.NS | 0.041 | **0.032** | 11.96% | **10.96%** |

**The honest read:** average miscoverage is a **tie** (~0.038 both), but ACI yields consistently **~7% narrower** intervals, and it **improves the two names (TCS/INFY) that were the project's documented coverage problem children** — on both coverage *and* width. It slightly over-tightens RELIANCE, an already-well-calibrated calm name. So ACI ships **on by default** as a coverage-neutral, sharpness-positive change whose real upside is regime response — which this calm 2023–2026 window barely exercised.

**Stress-period test — does ACI's benefit actually concentrate in a crash?** `run_stress_test.py` slices RELIANCE's full history (1996→) into volatility regimes and A/Bs the cone in each:

| Window | realised daily vol | static \|cov−.95\| | ACI \|cov−.95\| | static→ACI width |
|---|---|---|---|---|
| COVID crash 2020 | **3.75%** | 0.050 | **0.067** | 16.31% → **18.15%** |
| 2022 drawdown | 1.67% | 0.050 | 0.047 | 13.15% → 12.82% |
| Calm 2024 | 1.44% | 0.043 | 0.040 | 11.14% → 9.92% |

**The honest (and slightly counter-intuitive) result:** in the COVID extreme ACI did exactly what it should *directionally* — it **widened the cone ~11%** — but its coverage came out marginally *worse* than static, because calibrating a band in the fat tail of a crash is genuinely hard; in the milder regimes it sharpened and slightly improved coverage. So the tidy "ACI wins most in stress" hypothesis is **not** borne out on this name: ACI is best summarised as a sharpness-positive, roughly coverage-neutral change that moves the cone the right way under stress without fully solving tail calibration. (Single ticker, small samples — illustrative.)

**Does forward-looking India-VIX sharpen the cone? Not measurably (the honest result).** A/B of the HAR-RV cone with vs without the India-VIX tilt ([§19](#19-forward-looking-volatility-from-india-vix), via `compare_iv_adjust`, ACI on in both arms, 5-day horizon, 18 origins):

| Window | no-IV \|cov−0.95\| | +IV \|cov−0.95\| | no-IV width | +IV width |
|---|---|---|---|---|
| RELIANCE.NS (calm 2021–26) | **0.046** | 0.054 | 17.19% | 17.46% |
| TCS.NS (calm 2021–26) | 0.050 | 0.050 | 20.16% | 20.19% |
| INFY.NS (calm 2021–26) | 0.050 | 0.050 | 15.86% | 16.08% |
| RELIANCE.NS (2019–20 crash, concentrated) | 0.020 | 0.020 | 14.98% | **16.39%** |

In calm regimes implied ≈ realized, so the multiplier sits near 1 and barely moves the cone (RELIANCE slightly worse, the rest unchanged). In the concentrated COVID-crash window the tilt did the **directionally** right thing — it widened the cone ~1.4 pp as VIX spiked — but with **no coverage payoff** on this sample. So the tilt is principled and forward-looking but **unproven on the available NSE data**, and ships **off by default**. The likely reasons it underwhelms here: India VIX is a *market-level* (NIFTY) signal, so it only carries each stock's *systematic* vol slice (single-name option IV, which it cannot access, would be sharper), and the 2021–26 calm window simply offers little implied/realized divergence to exploit.

**Does the asymmetric cone improve tail-miss balance? Mixed (the honest result).** A/B of the symmetric vs asymmetric cone ([§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone), via `compare_asymmetric`, ACI on in both, 5-day horizon, 18 origins). The decisive metric is **tail-miss imbalance** `mean|lower_miss − upper_miss|` (lower = better-balanced):

| Ticker | sym tail-imbalance | asym tail-imbalance | sym \|cov−.95\| | asym \|cov−.95\| |
|---|---|---|---|---|
| RELIANCE.NS | **0.033** | 0.067 | 0.066 | 0.059 |
| TCS.NS | **0.067** | 0.078 | 0.017 | 0.070 |
| INFY.NS | 0.034 | **0.022** | 0.026 | 0.035 |

Better for INFY, worse for RELIANCE/TCS. The reason is statistical: splitting the calibration into two half-size per-side samples adds estimation noise, and on a *near-symmetric* residual distribution (the calm-regime norm) that noise outweighs the asymmetry it is trying to capture. The asymmetric cone is principled and visibly does the right thing under genuine skew (the single-fit example in §20), but on this data it does not reliably beat the symmetric cone, so it ships **off by default**. (The always-on downside *reporting* — expected shortfall, semideviation, vol skew — needs none of this; it reads the empirical distribution directly.)

**Does *any* model beat the random walk after correcting for trying many? No (the rigorous capstone).** `run_spa.py` ran White's Reality Check and Hansen's SPA over a 40-origin loss panel for the fast 9-model subset on RELIANCE.NS (5-day horizon, squared loss, benchmark = random walk):

| Model (best → worst) | mean loss-diff vs RW | SPA t-stat |
|---|---|---|
| ARIMA+GARCH | +1.02 | +0.33 |
| RegimeSwitching | +0.16 | +0.50 |
| HAR-RV | 0.00 | 0.00 *(it **is** the random walk)* |
| ARIMAX+GARCH | −1.45 | −0.50 |
| Ensemble-Stack | −27.7 | −0.53 |
| Meta-Ensemble | −30.5 | −0.87 |
| Quantile-LGBM | −35.6 | −0.68 |
| XGBoost | −47.0 | −1.09 |
| LightGBM | −47.2 | −1.01 |

**White's Reality Check p = 0.899, Hansen's SPA p = 0.874 → H0 not rejected.** Even the best-looking model (ARIMA+GARCH) is comfortably within what trying 9 models would produce by chance, and the gradient-boosted trees are *materially worse* than the random walk. This is the data-snooping-robust confirmation of the project's central, honest finding: **at this horizon, no model has a selection-bias-free edge over the random walk** — which is exactly why the product's value was relocated to calibrated uncertainty.


### Does tuning HAR-RV's lags help? No — the fifth negative result

`tuning.nested_search` over HAR-RV's memory windows, scored by walk-forward negative QLIKE on the variance forecast, 700 inner rows / 300 untouched holdout rows per ticker, exhaustive grid over five lag sets:

| Ticker | Search winner | Holdout (default) | Holdout (tuned) | Δ | Generalises? |
|---|---|---|---|---|---|
| RELIANCE.NS | (1, 3, 10) | 7.81632 | 7.82239 | **+0.00607** | ✅ |
| TCS.NS | (1, 10, 22) | 8.15977 | 8.15899 | −0.00078 | ❌ |
| INFY.NS | (1, 5, 22) | 6.75660 | 6.75660 | 0.00000 | ❌ (picked the default) |
| HDFCBANK.NS | (1, 3, 10) | 8.02523 | 7.93134 | **−0.09388** | ❌ |
| ITC.NS | (1, 3, 10) | 8.01704 | 7.97924 | −0.03780 | ❌ |

**One ticker in five improved, by 0.08% relative — and two got materially worse.** The winning lag set is **ticker-specific** ((1,3,10) three times, (1,10,22) once, and on INFY the search independently re-selected Corsi's canonical (1,5,22)). There is no consistent alternative to ship.

**Verdict: keep the canonical (1, 5, 22).** The inner search reliably found a better *fit* — every ticker's best inner score beat its default — and that fit did not survive contact with held-out data. This is the fifth documented negative result in this project, alongside market context, excess-return reframing, the India-VIX tilt and the asymmetric cone.

**The nesting is what makes this readable.** A conventional non-nested search — pick the best inner score, report it — would have produced "(1, 3, 10) beats the default on 3 of 5 tickers, ship it", and shipped a change that is *worse* on HDFCBANK by 20× the margin it wins on RELIANCE. The structural guard in [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat) is the entire reason the right answer is visible, and it is the reason `nested_search` is the only entry point that returns a reportable number.

### Is the economic leaderboard itself data-snooped? Now checked

The Sharpe table in [§22](#22-economic-evaluation-does-the-forecast-make-money) ranked seven models and named a winner — which is precisely the data-snooping mistake `run_spa.py` was built to correct for RMSE, left unapplied to the economic table. `strategy_metrics.strategy_return_panel` now assembles the aligned (T, K) panel of `net strategy return − buy-and-hold` differentials, and `run_strategy_eval.py` runs White's Reality Check and Hansen's SPA over it before printing any conclusion.

The panel is intersected on **common origins** across models: the stationary bootstrap resamples rows, so it can only preserve the cross-model dependence if every column refers to the same origin — the same discipline `collect_loss_panel` applies to the loss panel. A model that failed at an origin drops that origin for everyone.

Validated against eight pure-noise "models" on a shared realised-return series: best mean differential +0.0018, **Reality Check *p* = 0.916, SPA *p* = 0.871** — correctly refusing to crown a winner. The driver now prints this **above** the Sharpe leaderboard, with the note that the leaderboard's top row is the best of *K* tries and these p-values say whether that is more than *K* tries would produce by chance.

### Cross-sectional classifier: the probability problem solved, the skill problem not

`run_cross_sectional_clf.py` on **39 NSE names** (TATAMOTORS.NS came back delisted and was dropped with a recorded reason — the survivorship audit working), **77,135 panel rows**, 2018-08 → 2026-08, 5-day horizon, `combined` split (27 training names before 2024-04-18, **12 entirely unseen names after it**):

| | Result |
|---|---|
| Panel | 77,135 rows × 39 tickers → 74,749 labelled |
| Class balance | short 0.30 / nothing 0.42 / buy 0.28 |
| Train / calib / val | 27,046 / 9,045 / 6,887 rows |
| **Calibration ECE** | **0.0647 → 0.0026** (calib block) · **0.0139** (held-out val) |
| Accuracy vs majority | 0.4302 vs **0.4311** |
| Macro F1 | 0.203 |
| Long-short spread | +0.00008 |
| **Rank IC (t)** | **+0.0111 (t = 0.92)** |

**The win: honest probabilities.** The project's derived P(up) — read second-hand off a regression interval — measured **ECE ≈ 0.31**, meaning a forecast saying "60% likely" was off by about 31 percentage points. A model asked *directly* for a probability and then isotonically calibrated scores **ECE 0.0139 on unseen names in unseen dates** — roughly a **22× improvement**. That is a genuine, separable win: the probabilities are now honest *even though* the signal is absent. Those are two different problems and this fixes exactly one of them.

**The null: no cross-sectional skill at 40 names.** Rank IC +0.0111 at **t = 0.92** — right sign, comfortably inside noise, and almost identical to the earlier signal probe's *t* ≈ 1. Accuracy (0.4302) is *below* the majority-class baseline (0.4311); macro F1 is 0.203. Exactly the predicted outcome: real cross-sectional ICs are 0.02–0.05 and need **hundreds** of names to detect. 39 is not hundreds, so this is a **power** result, not evidence against the approach.

**That prediction has since been tested and confirmed — see [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result).** On survivorship-free bhavcopy data at 400 names (100 unseen validation names, 464 dates) the same experiment gives rank IC **+0.0396 at Fama-MacBeth t = 2.24**, replicating across 20 of 20 seed-runs and two disjoint periods at a stable effect size of 0.033–0.037. The null above was a power result exactly as claimed. But attribution shows **the model is not the finding — the factor is**: `log_return_5` *alone* scores IC −0.0524 at *t* = −4.34, beating the model by 1.32× on IC and nearly 2× on *t*. The signal is **short-term reversal**, a long-documented effect, rediscovered rather than learned. Costed in [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), it **does not survive**: breakeven 6.1 bp round trip, and no holding period from 5 to 42 days clears 25 bp. Real, small, long-known, and worth less than the cost of trading it. Read that section's four caveats before acting on this sentence — in particular, the long-short spread is *not* usable and the classifier's discrete calls remain near-worthless; the ordering is what carries the result.

**The detail worth pausing on: the model abstains.** Of 6,887 validation predictions it called **"do nothing" 6,857 times** — 99.6%. Only 11 longs and 19 shorts. Given an explicit neutral class and a calibrated objective, the classifier independently concluded it had no view, on names it had never seen.

That is the project's central thesis arriving from a completely different direction. Every earlier abstention was **imposed** — a confidence bucket computed from a walk-forward test, a data-quality gate, a novelty check. This one is **emergent**: nothing told the model to abstain, and the 3-class framing simply let "no view" be a first-class answer rather than a threshold applied after the fact. It is the sixth documented negative result, and the first one a model volunteered about itself. That reading is no longer an inference: [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) tests it against a balanced-weighting counterfactual, and the abstention survives.

*(One caveat on the reliability table: the `[0.0, 0.1)` bin holds 17 of 6,887 rows and shows a −0.29 gap. With that few points the bin is noise; the populated bins that carry the mass — `[0.2, 0.3)` with n = 6,227 — show a gap of −0.007.)*

### The §22–§25 additions: predictions written first, then checked

The economic evaluation, VaR backtesting, Vol-LSTM, CNN-LSTM and the regime-novelty gate were **built and unit-tested before being measured on real data**. Their tests are correctness tests (known-answer arithmetic, synthetic series with a known volatility, engineered exception sequences with a known verdict) — not skill claims. So the predictions below were written *before* the drivers were run, then marked with the outcome; two have been run so far.

| Addition | What to run | Prediction, and what would falsify it |
|---|---|---|
| Economic metrics ([§22](#22-economic-evaluation-does-the-forecast-make-money)) | `run_strategy_eval.py` | **Run — prediction held.** 6 of 7 models lost money net of 10 bps, and no model's Sharpe cleared 2 SE. See the table in §22. |
| VaR backtests ([§24](#24-value-at-risk-estimation-and-var-backtesting)) | `run_var_backtest.py` | **Run — partly held, one surprise.** Every method's breaches were flagged as clustered (expected: with 7,440 evaluations across 1996–2026 the independence test has overwhelming power). The surprise was **Cornish-Fisher**, which *under*-reserved badly at α = 5% — traced to the sign of its kurtosis term inside `|z| < √3` and now documented in §24 and pinned by a test. |
| Vol-LSTM ([§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)) | `run_vol_comparison.py` | **Run — prediction held, but only after a bug fix.** The first run said Vol-LSTM beat HAR-RV; chasing that down found HAR-RV over-stating volatility by ~1.9× (a Jensen correction applied to a log-χ² residual). With that **fixed**, HAR-RV moves from last to second and the deep model loses to HAR-RV, GARCH and EWMA alike — the originally predicted outcome. See the table below. |
| CNN-LSTM ([§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)) | `run_full_backtest.py` / `run_multi_backtest.py` | *Not yet run.* Middle of the pack, like the other sequence models; high run-to-run variance. As with N-BEATS, never trust a single run's NN ranking. |
| Regime novelty ([§25](#25-regime-novelty-from-a-denoising-autoencoder)) | *needs a stress window; not yet run* | On calm 2021–26 data the gate should almost never fire (that is the design). Its value can only be demonstrated on a genuine regime break, so the honest test is `run_stress_test.py`-style slicing around March 2020 — verifying it flags the crash **and** stays quiet on the calm windows. A detector that fires often in calm data is mis-tuned, not sensitive. |

Writing the predictions down *before* running the drivers is the same discipline that produced the four documented negative results above (market context, excess returns, IV tilt, asymmetric cone): a stated expectation cannot be retro-fitted to whatever the numbers turn out to be. It earned its keep twice over immediately — both the Cornish-Fisher and the volatility-comparison results were *unexpected*, and in both cases the surprise is what forced an investigation instead of a number quietly filed under "close enough".

### Volatility model comparison — and the latent HAR-RV bias it exposed (now fixed)

`run_vol_comparison.py RELIANCE.NS --quick` (4 origins, 5-day horizon, 1000 bars). Part 1 scores each model's **per-step variance forecast** against the realised `r²`, ranked by QLIKE (the loss robust to the noise in that proxy). The first run produced a result that contradicted the stated prediction, and chasing it down found a real defect:

| Model | QLIKE | forecast vol % | realised vol % | **bias ratio** | cum. sq. error |
|---|---|---|---|---|---|
| **EWMA** (λ=0.94) | **−7.860** | 1.280 | 1.209 | 1.06 | 2.0e−6 |
| GARCH (BIC-selected, Student-t) | −7.794 | 1.259 | 1.209 | 1.04 | 2.0e−6 |
| Vol-LSTM | −7.665 | 1.510 | 1.209 | 1.25 | 2.0e−6 |
| HAR-RV *(before the fix)* | −7.263 | 2.322 | 1.209 | **1.92** | 5.0e−6 |

`bias_ratio` = forecast vol ÷ realised vol. HAR-RV was **over-stating volatility by ~1.9×**, with 2.5× the cumulative squared error of every other model — a defect in the shipped model, not a property of the data. So Vol-LSTM's apparent win over HAR-RV was not the network learning anything clever; it was simply the only one of the two with a correct level transform.

**The cause.** `forecast_har_variance` converted its log-variance forecast to a level with the log-normal Jensen correction `exp(μ + σ²_resid/2)`. That is right for a **Gaussian** residual — but the residual of a regression on `log(r²)` is **log-χ²(1)**, whose variance is `π²/2 ≈ 4.93`. The correction therefore multiplied variance by `e^2.46 ≈ 11.7` where the correct factor is `e^1.27 ≈ 3.6`, netting ~1.9× in volatility terms.

**Why it survived this long.** The **conformal layer silently absorbs it**: the per-horizon multiplier is fitted to the *realised* dispersion, so an inflated σ is cancelled by a deflated `k` and coverage stays correct. The tell-tale was sitting in HAR-RV's own log output the whole time — `k(h) ≈ 1.0–1.3` against a Gaussian 1.96, i.e. calibration working *against* the variance forecast rather than with it. Only a direct level check (this driver's `bias_ratio` column) catches it, which is a good argument for scoring the raw variance and not just the interval.

**The fix.** `forecast_har_variance` now uses `har_level_offset` — the data-estimated constant `c = log(mean RV) − mean(log RV)` — which reproduces the theoretical 1.27 on Gaussian returns and self-adjusts for the percentile clipping and for genuinely fat tails (on RELIANCE it lands at ≈1.45–1.55, correctly higher than Gaussian). It is computed from whatever history slice the caller passes, so each walk-forward calibration origin derives its own offset from past bars only. Re-running the identical comparison:

| Model | QLIKE | forecast vol % | **bias ratio** | cum. sq. error |
|---|---|---|---|---|
| EWMA | **−7.860** | 1.280 | 1.06 | 2.0e−6 |
| **Vol-LSTM** *(offset now model-calibrated)* | **−7.803** | 1.242 | **1.03** | 2.0e−6 |
| **HAR-RV** *(after the fix)* | **−7.796** | 1.273 | 1.05 | 2.0e−6 |
| GARCH | −7.794 | 1.259 | 1.04 | 2.0e−6 |

HAR-RV moves from **last to second-from-last → third**, near-unbiased, with its cumulative squared error down to the field average and `k(h)` now averaging ≈2.4 (straddling 1.96 as it should).

**A second bias, in my own model.** Auditing the above exposed that Vol-LSTM had the *same class* of problem one level down. Its offset was **unconditional** — `c = log(mean RV) − mean(log RV)` on the training block — which corrects the log-χ² transform but leaves the *network's own* conditional bias untouched (measured `bias_ratio` 1.25). Switching to a **model-calibrated** offset — `c = log(mean RV_cal) − mean(predicted log RV_cal)` on the held-out calibration block, i.e. "what constant makes *this model's* forecasts land on the realised level?" — absorbs both in one scalar. Result: `bias_ratio` **1.249 → 1.027** (now the best of the four) and QLIKE **−7.665 → −7.803**, moving it from 4th to 2nd. Fitting one scalar on the calibration block is the same thing the conformal layer already does with its per-horizon multiplier, and the block is held out of training either way, so it adds no lookahead.

**The original prediction was right after all.** With the bug removed, the deep model does **not** beat the four-parameter OLS regression — nor does it beat plain EWMA or GARCH. That is the expected shape of result for a network on ~1000 daily bars, and it is exactly what §"predictions written first" said to expect. The earlier reversal was entirely an artefact of the defect.

**The fix is cone-neutral, as predicted.** Re-running the cone diagnostics at the *identical* settings before and after:

| | coverage (per step) | mean width | final-horizon CRPS (empirical) |
|---|---|---|---|
| Before | 1.00 at every step | 9.22% | 19.71 |
| After | 1.00 at every step | **9.10%** | 19.81 |

Coverage is unchanged, width is marginally *narrower*, and the CRPS difference is well inside noise on 20 step-records — so **every cone A/B published in this document remains valid**. What the fix corrects is the `volatility` column HAR-RV reports (surfaced in the UI and consumed by `iv_data`'s tilt) and its ranking against any unbiased volatility model. Pinned by two regression tests in `test_har_downside.py`, one of which asserts the *old* transform would have failed, so the check cannot pass vacuously.

**Part 2 — cone calibration (the deliverable).** At 10 origins post-fix, HAR-RV's cone covers 0.90–1.00 per step (mean |coverage − 0.95| = 0.050) at a mean width of 9.83%, with empirical CRPS beating the log-normal read (18.69 vs 19.22) and PIT not rejecting calibration (KS = 0.149, *p* = 0.198) though flagged "hump-shaped → intervals too wide". Against Vol-LSTM on the 4-origin quick run, both cones over-covered at 1.00, so coverage is uninformative; Vol-LSTM's cone was ~9% narrower (8.40% vs 9.22%) while HAR-RV won CRPS (19.71 vs 20.36). Four origins on one ticker separates nothing — the honest read is "no separation yet; run more origins across several tickers".

---

## Shared modules reference

| Module | Key functions | Purpose |
|---|---|---|
| `model_utils.py` | `normalize_interval`, `coerce_numeric_columns`, `prepare_log_returns`, `winsorize`/`winsorize_bounds`, `wilder_rsi`, `compute_price_features`, `generate_future_dates` (NSE-calendar-aware), `select_best_garch`, `simulate_price_paths`, `reset_keras_seeds`, `temporal_train_val_split` (embargoed), `default_keras_callbacks`, `forecast_nn_direct`, `configure_compute`/`gpu_available`/`compute_device_label` | All cross-model shared logic: preprocessing, features, **NSE exchange-calendar** future-date generation (holiday/session-aware, 7 hourly bars/session), GARCH selection, Monte Carlo, the direct multi-horizon NN engine with conformal intervals, and GPU/CPU detection. |
| `direct_forecast.py` | `horizon_feature_cols`, `make_horizon_targets`, `training_frame`, `compute_origin_row`, `conformal_halfwidth` (embargoed) | Direct multi-horizon engine and split-conformal calibration for the tree/ML models. |
| `market_context.py` | `add_market_context`, `add_market_index`, `context_matrix`, `fetch_close_series`, `MARKET_CONTEXT_COLS` | Fetches market/volatility indices; derives causal context features (`add_market_context`) and the `mkt_index` column for excess-return reframing (`add_market_index`). Both **off by default** after A/B testing showed no benefit. |
| `HAR_RV_model.py` | `run_har_rv_prediction` (`adaptive=`/`aci_gamma=`), `fit_har`, `har_level_offset`, `forecast_har_variance`, `_conformal_band_multipliers`, `_aci_multipliers` | HAR realized-volatility model: forecasts the variance cone, converts log→level with a **data-estimated offset** (`har_level_offset` — the Jensen correction it replaced over-stated volatility ~1.9×), conformalizes per horizon, and (default) applies **adaptive conformal (ACI)** so the cone responds to recent regime shifts. Flat random-walk point forecast. |
| `backtest.py` | `walk_forward_backtest` (now also returns `signals` + a `strategy` block), `evaluate_forecast`, `naive_forecast`/`drift_forecast`/`ar1_forecast`, `diebold_mariano`, `confidence_bucket`, `rmse`/`mae`/`smape`/`mase`/`directional_accuracy`/`interval_coverage`, `print_backtest_summary` | Model-agnostic walk-forward evaluation, baseline ladder, DM significance test, the shared skill→label rule (`confidence_bucket`, used by both the UI gate and the calibration harness), skill metrics, **and** the cost-charged economic evaluation of the same forecasts. |
| `cross_sectional_panel.py` | `build_panel`, `add_ticker_features`, `add_cross_sectional_ranks`, `add_labels`, `split_panel`, `feature_columns`, `DEFAULT_UNIVERSE` | Pooled multi-ticker panel — book Ch. 6. Fetches a universe, reuses the existing per-ticker features, adds within-date cross-sectional ranks, builds the 3-class market-neutral label, and splits by **asset**, time, or both. Built against survivorship, cross-sectional look-ahead, and forward-column leakage. |
| `cross_sectional_model.py` | `fit_calibrated`, `predict_proba`, `evaluate`, `expected_calibration_error`, `reliability_table`, `format_report` | 3-class (buy / do nothing / short) classifier with **isotonic probability calibration** — the direct fix for the derived-P(up) ECE ≈ 0.31 problem. Reports ECE before and after, plus rank IC, long-short spread and macro F1. |
| `prediction_log.py` | `log_forecast`, `resolve_outcomes`, `resolved_frame`, `drift_report`, `gate_validation`, `paper_portfolio`, `summary` | Forward prediction log — book Ch. 3 "Going live". Append-only JSONL written at serve time (with the gate verdicts in force), annotated with realised prices as horizons mature. Powers live calibration-drift alerting (binomial-CI gated), live gate validation, and the paper portfolio. Ships **on**; writing is best-effort and never breaks a forecast. |
| `tuning.py` | `nested_search`, `search`, `grid_configs`, `random_configs`, `_tpe_suggest`, `suggest_spaces`, `qlike_objective_har`, `format_search_report` | Hyperparameter search — book Ch. 3. Grid / random / TPE-Bayesian, with a **mandatory nested** wrapper (search on a training prefix, score once on an untouched tail) and a selection-bias warning attached to every result. Pure numpy/pandas; no `hyperopt` dependency. |
| `strategy_metrics.py` | `evaluate_strategy`, `strategy_return_panel`, `sharpe_ratio`, `sortino_ratio`, `information_ratio`, `max_drawdown`, `calmar_ratio`, `information_coefficient`/`rank_information_coefficient`/`ic_t_stat`, **`ic_by_date`/`newey_west_se`/`fama_macbeth_ic`**, **`time_under_water`/`drawdown_series`**, `position_from_signal`, `cumulative_returns`, `period_return_table`, `format_strategy_report` | Economic (investment-strategy) evaluation — book Ch. 3's metric set. Turns forecasts into a cost-charged return stream and scores it against buy-and-hold. Pure (numpy/pandas only). |
| `var_models.py` | `var_variance_covariance`, `var_historical_simulation`, `var_cornish_fisher`, `var_filtered_historical_simulation`, `var_generative`/`generative_return_samples`, `kupiec_pof_test`, `christoffersen_independence_test`, `christoffersen_conditional_coverage`, `backtest_var`, `compare_var_methods`, `ewma_volatility` | Value-at-Risk estimation **and validation** — book Ch. 9. Five estimators (each documented with the drawback it answers) plus the rolling out-of-sample harness and the calibration/independence test battery. Pure (no SciPy: closed-form χ² tails for df ∈ {1,2}). |
| `vol_lstm_model.py` | `run_vol_lstm_prediction`, `build_rv_channels`, `build_vol_lstm`, `train_vol_lstm`, `cumulative_squared_error`, `qlike_loss` | Vol-LSTM — book Ch. 5's deep volatility model, as the deep counterpart to HAR-RV. Direct multi-horizon log-variance forecast with a data-estimated level debias, reusing HAR-RV's conformal + ACI cone machinery. Flat random-walk point path. |
| `CNN_LSTM_model.py` | `run_cnn_lstm_prediction`, `build_cnn_lstm_model`, `train_cnn_lstm` | CNN-LSTM — book Ch. 7's "LSTM over a CNN". Causal Conv1D pattern extraction → max-pool → stacked LSTM, on the shared `forecast_nn_direct` engine (direct multi-horizon + conformal intervals). |
| `autoencoder_regime.py` | `regime_novelty`, `fit_regime_autoencoder`, `build_autoencoder` (vanilla / denoising / sparse), `feature_windows`, `reconstruction_error`, `latent_codes`, `novelty_series` | Denoising autoencoder — book Ch. 4 — repurposed as a **regime-novelty / distribution-shift detector** for the serving gate. Leak-free (fit → held-out reference → score), scale-free, and never fatal (lazy TF, neutral report on failure). |
| `tests/validation/calibration.py` | `crps_sample`/`crps_gaussian`, `collect_step_records`, `coverage_quality`, `crps_report`, `pit_values`/`pit_summary`, `reliability`, `validate_gate`, `compare_static_vs_aci`, `compare_iv_adjust`, `compare_asymmetric` | Validation-only library (not used by the app): CRPS (empirical vs log-normal), PIT calibration, reliability/ECE of P(up) & P(move), coverage quality, nested gate validation, and the cone A/Bs (static-vs-ACI, IV tilt on/off, symmetric-vs-asymmetric incl. tail-miss balance). |
| `tests/validation/multiple_testing.py` | `whites_reality_check`, `hansens_spa`, `collect_loss_panel`, `auto_block_length`, `stationary_bootstrap_indices`, `summarize` | Validation-only library: White's Reality Check + Hansen's SPA over a stationary bootstrap (auto block length, NW-HAC studentizer) — "does any of K models beat the random walk?" |
| `data_quality.py` | `assess_data_quality`, `gate_action`, `DQReport` | Scores a fetched series for fitness (history, staleness, duplicates, bad OHLC, zero-volume, gaps, abnormal jumps, currency status); returns reason codes + a serving mode (`normal`/`warn`/`risk_cone_only`/`abstain`) that the UI gate consumes. Pure (no Streamlit). |
| `iv_data.py` | `forward_vol_factor`, `clear_cache` | Forward-looking volatility tilt for the HAR-RV cone from **India VIX** (`^INDIAVIX`): the implied/realized ratio scaled by the stock's market R². Leak-free (as-of-last-bar), cached, no-op on missing data. Opt-in (`iv_adjust=`). |
| `risk_metrics.py` | `empirical_risk`, `risk_from_interval`, `normal_cdf` | Pure (no-Streamlit) risk math for the panel: empirical P(up)/P(move)/VaR plus the downside reads (expected shortfall, up/down semideviation, vol skew); log-normal fallback when no empirical sample exists. |
| `range_volatility.py` | `parkinson`, `garman_klass`, `rogers_satchell`, `yang_zhang`, `estimate`, `scale_to_total`, `efficiency`, `compare` | Range-based realized variance from the **high/low already fetched** (Sharma & Mehta Ch. 18 uses Parkinson's `0.361*ln(H/L)^2`). Measured **1.6-2.5x** more precise than `r_t^2` on real NSE bars against a textbook ~5x. Every per-bar estimator is a within-bar ratio and so **immune to corporate-action adjustment**. Wired into HAR-RV via `rv_estimator=`; the A/B is a documented null (§40) and the default stays `'squared'`. |
| `bhavcopy.py` | `fetch_day`, `fetch_range`, `load_cache`, `parse_action`, `corporate_actions`, `adjust_prices`, `liquidity_screen`, `build_panel`, `bhav_fetcher` | **Point-in-time** NSE prices from the daily bhavcopy — membership is whatever actually traded, so delisted companies are present for exactly the span they existed. Fixes a **26.8%** survivorship gap that yfinance cannot (23 of 30 vanished names return no data there). Handles both the legacy and UDiFF formats via fallback, and reconstructs `adj_close` from splits, bonuses, dividends and rights: validated against yfinance at **return correlation 1.00000 for 24/24 names**. `adjust_prices(as_of=...)` gives a genuinely point-in-time series, closing the back-adjustment look-ahead `tests/audit_price_adjustment.py` documented. No new dependency. |
| `fracdiff.py` | `frac_diff`, `frac_weights`, `min_d`, `adf_pvalue`, `kpss_pvalue`, `add_fracdiff_features`, `format_report` | Fractional differencing (López de Prado, via Kaabar Ch. 9) — stationarity that **preserves memory**, plus the project's first ADF/KPSS stationarity testing. On RELIANCE the minimum stationary order is d = 0.50 (corr with level **0.88**) against the d = 1 the pipeline uses (**0.004**). Adds **no parameters** and no new dependency; the forecasting A/B is a documented null (§36). |
| `feature_drift.py` | `drift_table`, `psi`, `psi_null`, `ks_statistic`, `summarise`, `format_report` | **Leading** drift indicator on the model's *inputs*, complementing `prediction_log`'s lagging coverage drift. Verdict comes from a **permutation null**, not the folklore PSI bands — PSI is biased upward on small samples (identical distributions score 0.30 at n=50). Corrects for multiple testing. Closed-form KS, no SciPy. |
| `explain.py` | `importance`, `shap_values`, `explain_prediction`, `concentration`, `supports`, `format_report` | **Exact TreeSHAP** attribution via LightGBM/XGBoost natively — **no `shap` or `lime` dependency**. Verifies the additivity identity rather than assuming it, and returns `None` for unsupported models rather than degrading to an approximation. The `concentration` measure produced §35's finding. |
| `kalman_model.py` | `run_kalman_prediction`, `kalman_filter`, `fit_kalman`, `forecast_kalman` | Damped local linear trend on log prices - the suite's only **state-space** model, re-estimating its state every bar rather than freezing parameters after a fit. Produces a **native** interval from the state covariance (no calibration set), reported alongside the conformal one. Fitted by concentrated (profile) maximum likelihood on a grid; pure NumPy. Reports honestly when it degenerates to a random walk - 70% of origins on real data (§34). |
| `epistemic.py` | `epistemic_spread`, `mc_dropout_predict`, `has_dropout`, `attach`, `format_report` | Monte-Carlo dropout **model** uncertainty (Klaas Ch. 4) - the axis the conformal cone cannot express, since it takes the fitted model as given. Ships **off**: the cross-model comparison **failed its falsifiable check** (§33), because the spread tracks network topology rather than data scarcity. Reported separately from the 95% band, never folded in. |
| `fundamentals.py` | `fundamental_history`, `as_of_join`, `available_from`, `derive_ratios`, `coverage_report`, `current_snapshot`, `to_float` | Point-in-time fundamental features for the pooled panel. Stamps every feature by **publication date** (period end + SEBI reporting lag), derives ratios from raw line items, and **refuses** to join a non-point-in-time frame — `Ticker.info` holds today's values, so joining it to a historical row is undetectable look-ahead. `coverage_report` measures feasibility; on yfinance it is 16% of the panel, so the experiment is blocked (§32). |
| `architectures.py` | `SPECS`, `spec`, `spec_driven`, `describe`, `attach`, `manifest_block`, `fingerprint`, `describe_specs` | Declarative network architectures (JSON-overridable via `architectures.json` / `STOCKAPP_ARCH_FILE`) **and** the realised-architecture record read back off the compiled Keras model. Closes a hole in the reproducibility manifest, which pinned the seed but not the layer stack. Spec-driven: DL, CNN-LSTM, Vol-LSTM; introspection-only: N-BEATS, TCN, Transformer — reported per record. |
| `config.py` | `FLAGS`, `active_flags`, `overridden`, `describe`, `env_flag`, `env_int`, `GATE_SPLITS`/`GATE_MIN_TRAIN`/`GATE_MAX_ROWS` | Single source of truth for the six `USE_*` feature flags and the serve-time gate tunables. Imports nothing from this project. Each entry carries the measured evidence for its default; the console banner is **generated** from the registry; every flag takes a `STOCKAPP_*` environment override, and an active override is reported in the banner. `python config.py` dumps the lot. |
| `console.py` | `startup_banner`, `run_header`, `run_summary`, `field`, `note`, `strip_markdown`, `short_path` | Terminal mirror of the UI's decision layer (no Streamlit import). Prints the seed / device / active `USE_*` flags at startup, frames each Submit, and renders the end-of-run verdict — data-quality mode, per-model bucket + Basis, consensus, honesty banner. **Renders, never recomputes**, so the console and browser cannot drift. ASCII-only and encoding-safe for legacy Windows code pages; `STOCKAPP_QUIET=1` silences it. |
| `gating.py` | `gated_direction`, `conviction`, `apply_data_quality_gate`, `apply_novelty_gate`, `confidence_reason` | Pure serving-gate logic (no Streamlit): withhold the directional call on "No edge", force "No edge" on degraded/event/cache-fallback data **or an off-manifold market regime**, compute conviction (move ÷ half-band), and build the per-row Basis reason code. The trust layer, unit-tested directly. |
| `reproducibility.py` | `set_all_seeds`, `run_manifest`, `GLOBAL_SEED` | Pin every RNG (random/NumPy/TF/torch) per run and build an auditable manifest (seed, versions, params, timestamps). Makes experiments reproducible, not markets predictable. |
| `safe_fetch.py` | `fetch_with_fallback` | Resilient fetch wrapper: retries + exponential backoff, empty/partial detection, last-known-good disk cache fallback, and a `source` status tag (live/partial/cached_fallback) the data-quality gate consumes. |
| `tests/validation/cross_sectional.py` | `build_panel`, `add_signals`, `rank_ic`, `long_short_spread` | Validation-only library: cross-sectional ranking probe — rank-IC and long-short quintile spread over a universe (research artifact, not in the app). |
| `meta_ensemble.py` | `run_meta_ensemble_prediction` | Cross-family median meta-ensemble. |
| `tests/validation/run_full_backtest.py`, `run_multi_backtest.py`, `run_cross_sectional.py`, `run_calibration.py`, `run_spa.py`, `run_stress_test.py`, `run_strategy_eval.py`, `run_var_backtest.py`, `run_vol_comparison.py` | `main` | Manual evaluation/research drivers (CLI, network, slow — not used by the app): single-ticker leaderboard / multi-ticker variance-aware ranking / cross-sectional signal probe / calibration & gate validation / SPA & Reality Check / stress-period ACI evaluation / **economic (Sharpe-Sortino-drawdown) leaderboard** / **VaR method comparison & Kupiec-Christoffersen tests** / **HAR-RV vs Vol-LSTM vs GARCH volatility comparison**. |

---

## Getting started

### Prerequisites

- Python 3.10+
- (Optional) GPU-enabled TensorFlow for faster deep-learning training

### Installation

```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
venv\Scripts\activate           # Windows
pip install -r requirements.txt
```

**(Optional — Chronos-2):** update the model path in `chronos_model.py` to your local Chronos-2 weights, or let it download if network access is available.

**Nothing else is needed to run the app.** A fresh clone forecasts immediately — the app fetches live history per ticker from yfinance and holds no local dataset.

### (Optional) The research data cache

Only the cross-sectional research drivers need this; **the app does not**. `.bhav_cache/` is ~121 MB of daily NSE bhavcopy files and is deliberately **not** in the repository — it is derived data, regenerable in one command:

```bash
python tests/validation/fetch_bhav_cache.py           # ~60 min, resumable
python tests/validation/fetch_bhav_cache.py 2018-01-01 2020-12-31   # or a slice
```

Re-running is cheap: cached days are skipped, so an interrupted fetch resumes where it stopped. The drivers that need it ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)) print a pointer to this script rather than failing obscurely if it is absent.

Why it exists at all, given the app fetches live data: the app answers *"what will this stock do?"* for a **currently listed** ticker, where delisted companies are irrelevant. The research layer answers *"do these models have any skill?"*, and that question cannot be answered honestly on survivors alone — 26.8% of the 2017 NSE universe no longer appears in today's listing file, and yfinance cannot return it. Survivorship bias does not corrupt forecasts; it corrupts **evaluations**.

### Running the app

```bash
streamlit run UI.py
```

Then open the URL shown (typically `http://localhost:8501`):

1. Select a **company** (searches NSE + BSE).
2. Choose the **interval** — Daily or Hourly.
3. Set the **forecast horizon**.
4. Optionally pick which models to run.
5. Click **Submit** to fetch data and generate forecasts.
6. Browse per-model charts and the comparison table.

### Running a backtest

```bash
python tests/validation/run_full_backtest.py AAPL
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL"
```

### Running the tests and audits

All test/validation scripts live in `tests/` (each is runnable directly or under pytest):

```bash
# Run the whole suite under pytest (from the repo root)
pytest tests/ -q

# …or run any suite as a plain script (no network needed)
python tests/test_intraday_parity.py    # intraday-feature train/serve parity + leak-freeness
python tests/test_data_quality.py       # data-quality gate reason codes & serving modes
python tests/test_iv_data.py            # India-VIX forward-vol factor: leak-freeness, bounds, fallback
python tests/test_har_downside.py       # semivariance split, asymmetric cone, downside risk metrics
python tests/test_reproducibility.py    # seed determinism + run manifest
python tests/test_gates.py              # confidence bucket / abstention / no-edge / conviction gates
python tests/test_safe_fetch.py         # retries, last-known-good cache fallback, source status
python tests/test_strategy_metrics.py   # Sharpe/Sortino/IR/drawdown/IC + cost-aware strategy bundle
python tests/test_backtest_strategy.py  # economic-evaluation wiring in walk_forward_backtest
python tests/test_var_models.py         # VaR estimators + Kupiec / Christoffersen backtests
python tests/test_novelty_gate.py       # regime-novelty gate + pure autoencoder helpers

# Slow suite: contract tests for the new deep models (needs TensorFlow; ~2-4 min
# on CPU). Self-skips the TF-dependent cases if TensorFlow is unavailable.
python tests/test_new_models_smoke.py   # Vol-LSTM / CNN-LSTM / regime autoencoder

# One-shot data-hygiene audit (needs network; fetches a few NSE names)
python tests/audit_price_adjustment.py                    # default NSE basket
python tests/audit_price_adjustment.py RELIANCE.NS TCS.NS
```

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| pandas | 3.0.3 | Data manipulation |
| numpy | 2.4.6 | Numerical computing |
| streamlit | 1.54.0 | Web UI |
| plotly | 6.5.1 | Interactive charts |
| yfinance | 1.0 | Market data |
| nselib | 2.4.2 | NSE fallback data |
| requests | 2.32.5 | HTTP calls |
| pmdarima | 2.1.1 | Auto-ARIMA |
| arch | 8.0.0 | GARCH models |
| statsmodels | 0.14.6 | Regime switching, statistical tests |
| prophet | 1.2.2 | Facebook Prophet |
| xgboost | 3.1.2 | Gradient boosting |
| lightgbm | 4.6.0 | Gradient boosting |
| scikit-learn | 1.8.0 | Preprocessing, Ridge, metrics |
| tensorflow | 2.20.0 | LSTM, GRU, Transformer, N-BEATS, TCN, CNN-LSTM, Vol-LSTM, regime autoencoder |
| chronos-forecasting | 2.2.2 | Amazon Chronos-2 |

---

## Caveats and limitations

- **Not financial advice.** Educational/research use only.
- **The cross-sectional result is a finding, not a strategy.** [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) establishes a replicable rank IC of 0.033–0.037 at 200+ names, and that is *all* it establishes — and a single raw feature (`log_return_5`, IC −0.0524) **beats the model outright**, so the contribution of the machine learning here is currently negative. And [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) settles the economics: gross Sharpe 0.24, **breakeven 6.1 bp round trip** against a 20 bp STT, 87% book turnover every five days, and only 38% of the universe shortable overnight. **The signal is real and not tradeable.** The long-short spread rests on 148 long calls out of 39,844 predictions and is not a usable economic number; there are no transaction costs, no borrow costs on a book that is 95% short by count, and no capacity analysis anywhere in it. Discrete classification accuracy (0.510) is barely above the majority baseline (0.501) — the model *orders* names better than chance, it does not *classify* them.
- **A smaller survivorship filter survives in the expanded panel.** `cross_sectional_panel.build_panel` requires 300 rows per name, dropping companies that traded under ~14 months inside the window (68 of 400 at the largest size), and a company that fails simply stops appearing in bhavcopy rather than posting a −100% return, so genuine wipeouts are under-represented. Both biases push optimistic. This is far weaker than the 26.8% gap it replaced, and it is not zero.
- **The bhavcopy day cache is a local artefact, not a committed dataset.** ~2,500 gzipped files / ~105 MB under `.bhav_cache/`, rebuilt by `tests/validation/fetch_bhav_cache.py` in ~33 minutes. Delete it freely; nothing in the live app reads it.
- **Markets are near-efficient.** At short horizons the random walk is hard to beat; the value here is calibrated uncertainty, combining models, and honest evaluation — not magic accuracy.
- **Backtest scope is limited** (a few tickers, a handful of origins). Directional-accuracy and coverage figures are noisy; rankings should be confirmed on more tickers before being trusted.
- **Neural nets are stochastic and high-variance**; consider averaging multiple seeds for production use.
- **Prophet and the raw neural nets can misbehave** on some tickers; the meta-ensemble and the conformal intervals exist partly to contain that risk.
- **Hybrid (ARIMA+LSTM)** is the one base model still using recursive forecasting and without conformal intervals — a candidate for the same treatment as the others.
- **Market context uses an India-default proxy.** The cross-sectional features default to NIFTY 50 / India VIX (the app is INR-centric and prioritises NSE/BSE tickers). For a non-Indian ticker these are only an approximate market proxy — the beta/correlation features will be weak. Mapping a ticker to its true home index (e.g. S&P 500 / VIX for US names) is a known refinement.
- **Intraday features are on but not yet A/B-validated.** The hourly NSE-session features ([§3](#3-feature-engineering)) are leak-free and train/serve-consistent, and intraday seasonality is a more defensible signal than daily alpha — but, consistent with this project's discipline, they have **not** been confirmed to improve hourly forecasts by a controlled A/B (the main backtests are daily). They ship on (`USE_INTRADAY_FEATURES = True`) and apply only to the **tree/ML family**; a dedicated **hourly** backtest with the flag on/off is the right way to confirm their value before trusting them.
- **Hourly history is provider-capped.** yfinance serves only a limited intraday lookback (often ~1–2 years, and it varies by ticker/version), so hourly models train on far less data than daily ones. The app surfaces the actual span and warns when it's short, but a thin hourly window genuinely limits what the models can learn.
- **Currency conversion is a dormant safety net ([§16](#16-currency-conversion-to-inr-and-its-audit-trail)).** The universe is **NSE/BSE-only**, so every selectable stock is INR-native and the conversion never runs in normal use (audit tag `none`). When it *does* fire (a foreign ticker via the search fallback, not selectable from the dropdown), it converts per-date at historical FX, with audited degraded fallbacks (live-uniform rescale / unconverted) surfaced as a UI warning/error. Because Indian hourly prices need no FX, **intraday-FX granularity is moot** for this product. *(Fixed along the way: a `DataFrame.drop(columns=…, axis=1)` call threw before the conversion step, so a foreign-currency stock — if ever reached — was returned **unconverted but labelled ₹**; conversion now runs and is tagged.)*
- **Conformal cones track regime shifts only partially.** HAR-RV's cone now applies **Adaptive Conformal Inference (ACI)** over its own recent calibration residuals, so the live multiplier responds to a recent volatility regime (it widens after a run of misses, tightens after easy covers) — this is ACI applied to the in-sample calibration stream and ships on by default. Two honest limits remain: (1) on a *calm* window it can slightly over-tighten an already-well-calibrated name (see [findings](#empirical-findings)); (2) a **fully online loop that persists `α` across successive live requests** (true cross-session deployment monitoring) is still future work. The tree/NN models' static conformal intervals are unchanged; only HAR-RV is adaptive so far.
- **HAR-RV makes no point-forecast claim by design**, so it will always read "No edge" in the confidence column; its value is the calibrated risk cone, surfaced via the chart band and the risk panel.
- **The fat-tailed risk read needs HAR-RV in the run.** The empirical P(up)/P(move)/VaR come from HAR-RV's conformal residual sample; if HAR-RV is deselected, the risk panel falls back to a **log-normal** approximation of each model's interval and says so in the caption. Extending other models to expose an empirical sample is a clean future step (they currently emit only interval bounds).
- **Calibration figures are illustrative.** `run_calibration.py` numbers in this README are single-ticker, small-sample (a handful of walk-forward origins); they demonstrate the harness and the direction of the result, not a firm verdict. A trustworthy calibration claim needs many origins across several tickers. Gate validation is **offline** (a nested backtest), not wired into the live app.
- **The SPA/Reality-Check verdict is small-sample and subset-by-default.** `run_spa.py` aggregates to one loss per origin (T = number of origins ≈ 40), tests the fast 9-model subset unless `--full`, and is computed on a single ticker. The conservative Reality Check drives the headline; Hansen's SPA can be mildly liberal at small T (a known finite-sample property), so a borderline SPA-only rejection is treated as unconfirmed. The current "no edge" verdict is robust to all of this (both p-values ≈ 0.9), but a *positive* finding would warrant more origins/tickers before being trusted.
- **Data-quality thresholds are heuristic.** The gate in `data_quality.py` ([§17](#17-input-data-quality-gating)) uses documented, deliberately-lenient cut-offs (history floors, staleness windows, zero-volume/bad-OHLC fractions, gap days) tuned to catch genuinely broken inputs without nagging on normal market data (holidays, the odd zero-volume bar). They are sensible defaults, not calibrated against a labelled set of "good/bad" feeds; tune the module constants for a stricter or looser policy. The gate runs at request time on the fetched series.
- **The price-adjustment look-ahead is documented, not eliminated.** Training on yfinance's back-adjusted close embeds future corporate-action sizes into a backtest's past bars, but the audit ([§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close)) shows this is immaterial for this return-based, scale-invariant pipeline (live serving has zero leak; only ~0.4–1.6 % of bars differ, and they cancel in DM/SPA/MASE). A strict point-in-time re-adjustment per origin would close the residual but buy nothing measurable, so it is left as a documented, reproducible finding. **This is now closable, and the machinery exists:** `bhavcopy.adjust_prices(as_of=...)` applies only corporate actions known by a given date, so a backtest origin can see the series exactly as it looked then ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)). The single-ticker app still fetches from yfinance, so the residual remains there; the cross-sectional work no longer has it. Separately, the **nselib daily fallback** was found to be mapping VWAP to `adj_close` (a −89.5% artefact at splits, return correlation 0.527 against yfinance); it now adjusts properly via `bhavcopy` and scores **0.996** — see [§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close).
- **Forward-looking IV is market-level, opt-in, and unproven on this data.** Single-name NSE option IV is not freely/reliably reachable (NSE's API is bot-protected), so the India-VIX tilt ([§19](#19-forward-looking-volatility-from-india-vix)) injects only the *systematic* (NIFTY-linked) slice of forward vol, not stock-specific implied vol. It is leak-free and directionally sensible (widens when VIX spikes) but an A/B showed no measurable coverage gain on the available calm window, so it ships **off** (`USE_IV_ADJUST = False`). A genuine single-name IV feed (a paid vendor, or an authenticated browser session) would be needed to test the stronger version.
- **Downside reads are always on; the asymmetric cone and HAR-RS are opt-in/future.** The expected-shortfall / semideviation / vol-skew reads ([§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)) are pure reporting of HAR-RV's empirical distribution and need a fat-tailed model (HAR-RV) in the run. The **asymmetric cone** is principled but A/B-mixed on calm data (per-side calibration is noisier when residuals are near-symmetric), so it ships **off** (`USE_ASYMMETRIC_CONE = False`). A full **HAR-RS** (semivariance-in-the-regression) forecast is deliberately *not* built: it needs recursive component forecasting, and the IV/asymmetric A/Bs both indicate changes to the central variance forecast barely move the empirically-conformalized cone — so it stays documented future work.
- **GPU is used only where it helps.** Deep models and Chronos auto-use a GPU when present; the gradient-boosted trees stay on CPU intentionally (GPU tree training is slower on these small windows).
- **Prophet ↔ pandas 3.0 compatibility.** Prophet 1.2.2's `regressor_column_matrix` builds its component frame with a duplicate-labelled index, which **pandas 3.0**'s stricter `crosstab` rejects (`"cannot reindex on an axis with duplicate labels"`), breaking every Prophet fit. `fb_prophet_model.py` applies a small, idempotent monkey-patch (`add_group_component` → clean `RangeIndex`) so Prophet works on pandas 2.x **and** 3.x. `requirements.txt` now pins **pandas 3.0.3 / numpy 2.4.6** to match the installed, tested environment (the two move together — pandas 3.0 requires numpy 2.x); the patch is retained so the code still runs on pandas 2.x if you downgrade.
- **The app trains on demand** (no model registry). Each Submit fetches data and trains/serves; results are cached per parameter set within a session, but there is no scheduled retraining, drift monitoring, or persisted model store — those are deferred production-grade additions.
- **The resilient-fetch cache is best-effort, and full prediction logging is still deferred.** `safe_fetch` keeps a local last-known-good copy under `.data_cache/` (pickle) and serves it cone-only when a live fetch fails; it is not a versioned store and is safe to delete. A persistent **prediction log** with realized-outcome tracking and **calibration-drift monitoring** remain Tier C — genuinely worth building the moment this stops being a single-user, train-on-demand app and starts persisting predictions for real users over time (calibration-drift monitoring first, since a cone calibrated at training time silently decays as the regime moves).

## License

For personal learning and experimentation.
