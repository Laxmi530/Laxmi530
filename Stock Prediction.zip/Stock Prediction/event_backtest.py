"""
Path-aware (event-based) backtesting: what a position actually lived through.

Hilpisch, *Artificial Intelligence in Finance* (O'Reilly, 2020), Ch. 11.

The gap this closes
-------------------
Every backtest in this project is **vectorized**: a signal is multiplied by the
realised return from entry to horizon. Section 39's reversal book is literally
``fwd = log(px.shift(-hold) / px)`` -- anchor to horizon, in one step. That is
correct arithmetic and it is **blind to the path**. A 5-day hold contains four
bars nobody looks at. The position can go 12% underwater on day 2 and recover
by day 5, and the vectorized backtest reports the recovery as though the
drawdown never happened.

That omission is not cosmetic here. Section 43 measured this exact book at
**kurtosis 13.18 and skew −0.781**. Negative skew is *made of* intra-period
paths that a close-to-close return hides. Anyone who would have been stopped
out, margin-called, or simply unable to keep holding on day 2 did not earn the
number Section 39 reports.

Two things follow, and this module measures both:

1. **Maximum adverse excursion (MAE)** -- how far underwater a position went
   before its horizon, independent of any exit rule. This is the honest size of
   what vectorized backtesting omits, and it needs no strategy assumption.
2. **Path-dependent exits** -- stop loss, take profit, trailing stop, which
   cannot be expressed in a vectorized backtest at all because they depend on
   *when* a price was reached, not just where it ended.

Three places a stop-loss backtest lies
--------------------------------------
Getting this right is most of the value, because the naive version is
systematically optimistic in exactly the regime that matters:

* **Gaps.** A stop is not a guaranteed fill. If the bar opens through the
  level, you fill at the open, not the stop. With kurtosis 13 this is common,
  and assuming a fill at the stop price is what makes stops look protective in
  backtests when they are not. ``gap_fill=True`` models it.
* **Intrabar ordering.** If one bar's low hits the stop *and* its high hits the
  take-profit, daily data cannot say which came first. Assuming the favourable
  one is free money. ``adverse_first=True`` assumes the stop, which is the only
  defensible default.
* **Trailing ratchets.** Raising the trail on bar *i*'s high and then testing
  bar *i*'s low against the new level assumes the high preceded the low. The
  trail here is computed from bars strictly before *i*.

None of these is exotic; all three are why a stop-loss study reproduces badly.

No new dependency: numpy and pandas only.
"""

import numpy as np
import pandas as pd

#: Why a position closed. ``horizon`` means no rule fired and it ran to term.
EXIT_REASONS = ("horizon", "stop_loss", "take_profit", "trailing_stop")

#: Columns a bar frame must provide. ``open`` is required because gap fills are
#: the difference between a realistic stop and a flattering one.
BAR_COLUMNS = ("open", "high", "low", "close")


def adjust_ohlc(bars, close_col="close", adj_col="adj_close"):
    """
    Scale raw OHLC onto the adjusted-close basis.

    Stop levels are fractions of the entry price, so open/high/low and the
    close must share one basis. The bhavcopy panel carries raw OHLC and an
    adjusted close, and mixing them puts a split-sized error into every
    intrabar test -- the same trap ``range_volatility.scale_to_total`` is
    guarded against (README §40).

    Returns a copy with ``open``/``high``/``low``/``close`` all adjusted.
    """
    out = bars.copy()
    if adj_col not in out.columns:
        return out
    ratio = out[adj_col].astype(float) / out[close_col].astype(float)
    ratio = ratio.replace([np.inf, -np.inf], np.nan).ffill().bfill().fillna(1.0)
    for c in ("open", "high", "low", "close"):
        if c in out.columns:
            out[c] = out[c].astype(float) * ratio
    return out


def excursions(entry, bars, side=1):
    """
    Maximum adverse and favourable excursion over the holding period.

    No exit rule, no assumption about behaviour: just how far the position went
    against you and for you before the horizon. MAE is the number a vectorized
    backtest silently discards.

    Parameters
    ----------
    entry : float
        Entry price.
    bars : pd.DataFrame
        Bars **after** entry, with ``high`` and ``low``.
    side : int
        ``+1`` long, ``-1`` short.

    Returns
    -------
    dict
        ``mae`` (<= 0), ``mfe`` (>= 0), both as signed simple returns in the
        position's favour, and ``horizon_return``.
    """
    if entry is None or not np.isfinite(entry) or entry <= 0 or len(bars) == 0:
        return {"mae": np.nan, "mfe": np.nan, "horizon_return": np.nan}
    hi = bars["high"].to_numpy(dtype=float)
    lo = bars["low"].to_numpy(dtype=float)
    last = float(bars["close"].to_numpy(dtype=float)[-1])
    if side > 0:
        worst, best = np.nanmin(lo), np.nanmax(hi)
    else:
        worst, best = np.nanmax(hi), np.nanmin(lo)
    return {"mae": min(0.0, side * (worst / entry - 1.0)),
            "mfe": max(0.0, side * (best / entry - 1.0)),
            "horizon_return": side * (last / entry - 1.0)}


def exit_position(entry, bars, side=1, stop_loss=None, take_profit=None,
                  trailing_stop=None, gap_fill=True, adverse_first=True):
    """
    Walk a position bar by bar and return where it actually closed.

    Parameters
    ----------
    entry : float
        Entry price (the close of the signal bar, matching §39's convention).
    bars : pd.DataFrame
        Bars **after** entry, columns :data:`BAR_COLUMNS`.
    side : int
        ``+1`` long, ``-1`` short.
    stop_loss, take_profit, trailing_stop : float, optional
        Positive fractions, e.g. ``0.05`` for 5%. ``trailing_stop`` is measured
        from the best price seen in bars strictly before the one being tested.
    gap_fill : bool
        Fill at the bar's open when it opens through the level, rather than
        pretending the stop price was available. Default True.
    adverse_first : bool
        When stop and target both trigger in one bar, assume the stop. Default
        True; daily data cannot resolve the order and the alternative is
        optimism.

    Returns
    -------
    dict
        ``exit_price``, ``exit_bar`` (0-indexed into ``bars``), ``reason``,
        ``ret`` (signed simple return in the position's favour), ``bars_held``.
    """
    n = len(bars)
    if entry is None or not np.isfinite(entry) or entry <= 0 or n == 0:
        return {"exit_price": np.nan, "exit_bar": -1, "reason": "horizon",
                "ret": np.nan, "bars_held": 0}

    o = bars["open"].to_numpy(dtype=float)
    h = bars["high"].to_numpy(dtype=float)
    l = bars["low"].to_numpy(dtype=float)
    c = bars["close"].to_numpy(dtype=float)
    s = 1.0 if side > 0 else -1.0

    # Static levels, in price terms. For a long the stop is below and the
    # target above; for a short both flip.
    stop = entry * (1.0 - s * stop_loss) if stop_loss else None
    target = entry * (1.0 + s * take_profit) if take_profit else None
    best = entry                                    # running favourable extreme

    for i in range(n):
        # The trail uses `best` as it stood BEFORE this bar, so a ratchet and a
        # trigger cannot both be credited to the same bar's extremes.
        trail = (best * (1.0 - s * trailing_stop)) if trailing_stop else None

        # Effective stop is the tighter (more protective) of stop and trail.
        eff_stop = stop
        if trail is not None:
            eff_stop = trail if eff_stop is None else (
                max(eff_stop, trail) if s > 0 else min(eff_stop, trail))
        stop_kind = "stop_loss"
        if trail is not None and (eff_stop == trail) and (
                stop is None or trail != stop):
            stop_kind = "trailing_stop"

        # --- gaps: the open is the first tradeable price of the bar ---------
        if eff_stop is not None and gap_fill and s * (o[i] - eff_stop) <= 0:
            return _done(entry, o[i], i, stop_kind, s)
        if target is not None and gap_fill and s * (o[i] - target) >= 0:
            return _done(entry, o[i], i, "take_profit", s)

        hit_stop = eff_stop is not None and s * ((l[i] if s > 0 else h[i])
                                                 - eff_stop) <= 0
        hit_target = target is not None and s * ((h[i] if s > 0 else l[i])
                                                 - target) >= 0

        if hit_stop and hit_target:
            if adverse_first:
                return _done(entry, eff_stop, i, stop_kind, s)
            return _done(entry, target, i, "take_profit", s)
        if hit_stop:
            return _done(entry, eff_stop, i, stop_kind, s)
        if hit_target:
            return _done(entry, target, i, "take_profit", s)

        # Survived the bar: now the ratchet may move.
        best = max(best, h[i]) if s > 0 else min(best, l[i])

    return _done(entry, c[-1], n - 1, "horizon", s)


def _done(entry, price, i, reason, s):
    return {"exit_price": float(price), "exit_bar": int(i), "reason": reason,
            "ret": float(s * (price / entry - 1.0)), "bars_held": int(i) + 1}


def compare(entry, bars, side=1, **rules):
    """
    The vectorized answer and the event-based answer for one position.

    ``vectorized`` is entry-to-last-close, which is what every existing
    backtest in this project computes. ``event`` applies the exit rules. The
    difference is what path-dependence costs (or saves).
    """
    ex = excursions(entry, bars, side)
    ev = exit_position(entry, bars, side=side, **rules)
    return {"vectorized": ex["horizon_return"], "event": ev["ret"],
            "difference": ev["ret"] - ex["horizon_return"],
            "reason": ev["reason"], "bars_held": ev["bars_held"],
            "mae": ex["mae"], "mfe": ex["mfe"]}


def summarize(rows):
    """Aggregate :func:`compare` dicts into means, and the exit-reason mix."""
    df = pd.DataFrame(list(rows))
    if df.empty:
        return {"n": 0}
    out = {
        "n": int(len(df)),
        "vectorized_mean": float(df["vectorized"].mean()),
        "event_mean": float(df["event"].mean()),
        "difference_mean": float(df["difference"].mean()),
        "mae_mean": float(df["mae"].mean()),
        "mae_p05": float(df["mae"].quantile(0.05)),
        "mfe_mean": float(df["mfe"].mean()),
        "bars_held_mean": float(df["bars_held"].mean()),
    }
    counts = df["reason"].value_counts(normalize=True)
    for r in EXIT_REASONS:
        out[f"share_{r}"] = float(counts.get(r, 0.0))
    return out


def format_report(summary, title="EVENT-BASED VS VECTORIZED"):
    """Render :func:`summarize` output."""
    if not summary.get("n"):
        return "no positions"
    lines = [
        "=" * 70, title, "=" * 70,
        f"  positions              : {summary['n']:,}",
        f"  vectorized mean return : {summary['vectorized_mean']:+.4%}",
        f"  event-based mean return: {summary['event_mean']:+.4%}",
        f"  difference             : {summary['difference_mean']:+.4%}",
        "",
        f"  mean MAE (worst drawdown before horizon) : "
        f"{summary['mae_mean']:+.2%}",
        f"  5th pct MAE                              : "
        f"{summary['mae_p05']:+.2%}",
        f"  mean MFE                                 : {summary['mfe_mean']:+.2%}",
        f"  mean bars held                           : "
        f"{summary['bars_held_mean']:.2f}",
        "",
        "  exit mix:",
    ]
    for r in EXIT_REASONS:
        lines.append(f"    {r:<16s} {summary.get(f'share_{r}', 0.0):6.1%}")
    return "\n".join(lines)
