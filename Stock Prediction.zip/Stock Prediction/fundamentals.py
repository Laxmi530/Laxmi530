"""
Point-in-time fundamental features, and an honest audit of what is reachable.

Why this module exists
----------------------
Every model in this project is a transformation of the same OHLCV series. Six
documented negative results point at the *information*, not the architecture,
as the binding constraint. Fundamentals (valuation ratios, margins, leverage,
returns on capital) are the cheapest available second axis — unlike news/NLP
they need no licensed feed — so this module exists to add them to the pooled
cross-sectional panel.

The result, stated up front: **it does not currently work, for a data reason,
not a modelling one.** ``run_fundamentals_audit.py`` measures the gap. See
README section 32.

The trap this module is built around
------------------------------------
``yfinance``'s ``Ticker.info`` returns **today's** trailing P/E, margins and
book value. Joining those onto a 2019 panel row is look-ahead of the most
direct kind: the row would carry information that did not exist for another six
years, and a classifier would look brilliant. That single mistake is what makes
most public "fundamentals + ML" stock projects unreproducible.

Two defences, both structural rather than advisory:

1. :func:`current_snapshot` tags its output ``point_in_time=False`` and
   :func:`as_of_join` **refuses** such a frame. Being unable to make the mistake
   beats being warned about it.
2. Statement data is dated by **publication**, not by period end. A quarter
   ending 31 March is not public on 31 March; Indian listing rules allow 45 days.
   Using the period-end date as the availability date leaks up to a quarter of
   forward information. :data:`PUBLICATION_LAG_DAYS` encodes that delay and
   :func:`as_of_join` does a backward as-of merge on the lagged date, so a panel
   row only ever sees statements already published.

Scope
-----
Reads ``yfinance`` annual/quarterly income statements and balance sheets, derives
ratios from raw line items (rather than trusting pre-computed ``info`` fields,
which are point-in-time-unsafe), and reports coverage per ticker so the panel's
feasibility is a measured number rather than an assumption.
"""

import numpy as np
import pandas as pd

# Indian listing rules (SEBI LODR Reg. 33) require quarterly results within 45
# days of quarter end, and annual results within 60. 45 is the conservative
# choice for quarterly data: assuming publication EARLIER than reality would
# leak, assuming later merely delays the feature by a few weeks. When in doubt
# about a data-availability date, err in the direction that cannot leak.
PUBLICATION_LAG_DAYS = 45
ANNUAL_PUBLICATION_LAG_DAYS = 60

# Raw statement line items we derive ratios from. Names follow yfinance's
# normalised labels; missing items degrade to NaN rather than raising, because
# coverage differs by ticker and a partial row is still worth having.
INCOME_ITEMS = ("Total Revenue", "Gross Profit", "Operating Income", "EBITDA",
                "EBIT", "Net Income", "Diluted EPS", "Basic EPS",
                "Diluted Average Shares")
BALANCE_ITEMS = ("Total Assets", "Total Debt", "Stockholders Equity",
                 "Cash And Cash Equivalents", "Current Assets",
                 "Current Liabilities")

# Derived features. Ratios rather than levels, because a pooled panel compares
# names of wildly different size — absolute revenue is a proxy for market cap,
# not a signal.
FUNDAMENTAL_COLS = ("f_gross_margin", "f_operating_margin", "f_net_margin",
                    "f_roa", "f_roe", "f_debt_to_equity", "f_current_ratio",
                    "f_asset_turnover", "f_eps")


def to_float(value):
    """
    Coerce a statement value to float, returning NaN rather than raising.

    Statement frames arrive with a mix of numpy scalars, ``None``, ``NaT``,
    strings and occasional infinities. A feature pipeline that raises on one bad
    cell loses the whole ticker, so every failure becomes NaN and is handled
    downstream as missing.
    """
    if value is None:
        return float("nan")
    if isinstance(value, str):
        v = value.strip().replace(",", "")
        if v in ("", "-", "N/A", "NaN", "None", "null"):
            return float("nan")
        try:
            return float(v)
        except ValueError:
            return float("nan")
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float("nan")
    return out if np.isfinite(out) else float("nan")


def _safe_div(a, b):
    """Ratio that returns NaN on a zero, missing or non-finite denominator."""
    a, b = to_float(a), to_float(b)
    if not np.isfinite(a) or not np.isfinite(b) or abs(b) < 1e-12:
        return float("nan")
    out = a / b
    return out if np.isfinite(out) else float("nan")


def available_from(period_end, quarterly=True):
    """
    The date a statement for ``period_end`` could first have been known.

    This is the whole point-in-time discipline in one function: features are
    stamped with their *publication* date, never their period end.
    """
    ts = pd.Timestamp(period_end)
    if pd.isna(ts):
        return pd.NaT
    lag = PUBLICATION_LAG_DAYS if quarterly else ANNUAL_PUBLICATION_LAG_DAYS
    return ts.normalize() + pd.Timedelta(days=lag)


def _statement_frames(ticker, quarterly=True):
    """Fetch (income, balance) statement frames for one ticker; empty on failure."""
    import yfinance as yf
    t = yf.Ticker(ticker)
    empty = pd.DataFrame()
    try:
        inc = t.quarterly_income_stmt if quarterly else t.income_stmt
    except Exception:
        inc = empty
    try:
        bal = t.quarterly_balance_sheet if quarterly else t.balance_sheet
    except Exception:
        bal = empty
    return (inc if isinstance(inc, pd.DataFrame) else empty,
            bal if isinstance(bal, pd.DataFrame) else empty)


def _get(frame, item, col):
    if frame is None or frame.empty or item not in frame.index:
        return float("nan")
    try:
        return to_float(frame.loc[item, col])
    except Exception:
        return float("nan")


def derive_ratios(income, balance, col):
    """
    Compute the derived features for one reporting period.

    Ratios are built from raw line items rather than read off ``Ticker.info``,
    because ``info`` carries only today's values — correct for a live screen,
    silently look-ahead for a historical panel.
    """
    rev = _get(income, "Total Revenue", col)
    assets = _get(balance, "Total Assets", col)
    equity = _get(balance, "Stockholders Equity", col)
    net = _get(income, "Net Income", col)
    return {
        "f_gross_margin": _safe_div(_get(income, "Gross Profit", col), rev),
        "f_operating_margin": _safe_div(_get(income, "Operating Income", col), rev),
        "f_net_margin": _safe_div(net, rev),
        "f_roa": _safe_div(net, assets),
        "f_roe": _safe_div(net, equity),
        "f_debt_to_equity": _safe_div(_get(balance, "Total Debt", col), equity),
        "f_current_ratio": _safe_div(_get(balance, "Current Assets", col),
                                     _get(balance, "Current Liabilities", col)),
        "f_asset_turnover": _safe_div(rev, assets),
        "f_eps": _get(income, "Diluted EPS", col),
    }


def fundamental_history(ticker, quarterly=True):
    """
    Point-in-time fundamental features for one ticker.

    Returns
    -------
    pandas.DataFrame
        Columns ``[ticker, period_end, available_from, *FUNDAMENTAL_COLS]``, one
        row per reporting period, sorted by ``available_from``. Empty (with the
        right columns) when nothing is reachable, so callers can concatenate
        without special-casing.
    """
    cols = ["ticker", "period_end", "available_from"] + list(FUNDAMENTAL_COLS)
    income, balance = _statement_frames(ticker, quarterly=quarterly)
    if income.empty and balance.empty:
        return pd.DataFrame(columns=cols)

    periods = sorted(set(list(income.columns)) | set(list(balance.columns)))
    rows = []
    for col in periods:
        ratios = derive_ratios(income, balance, col)
        if all(not np.isfinite(v) for v in ratios.values()):
            continue                      # nothing usable for this period
        rows.append({"ticker": ticker,
                     "period_end": pd.Timestamp(col),
                     "available_from": available_from(col, quarterly),
                     **ratios})
    if not rows:
        return pd.DataFrame(columns=cols)
    out = pd.DataFrame(rows)[cols].sort_values("available_from")
    out.attrs["point_in_time"] = True
    return out.reset_index(drop=True)


def current_snapshot(ticker):
    """
    Today's ``Ticker.info`` fundamentals — explicitly NOT point-in-time.

    Useful for a live screen of the current cross-section. Tagged
    ``point_in_time=False`` so :func:`as_of_join` rejects it: the whole failure
    mode this module guards against is exactly this frame reaching a historical
    panel.
    """
    import yfinance as yf
    try:
        info = yf.Ticker(ticker).info or {}
    except Exception:
        info = {}
    out = pd.DataFrame([{
        "ticker": ticker,
        "trailing_pe": to_float(info.get("trailingPE")),
        "forward_pe": to_float(info.get("forwardPE")),
        "peg_ratio": to_float(info.get("pegRatio")),
        "price_to_book": to_float(info.get("priceToBook")),
        "profit_margin": to_float(info.get("profitMargins")),
        "operating_margin": to_float(info.get("operatingMargins")),
        "debt_to_equity": to_float(info.get("debtToEquity")),
        "beta": to_float(info.get("beta")),
        "held_pct_institutions": to_float(info.get("heldPercentInstitutions")),
    }])
    out.attrs["point_in_time"] = False
    return out


def as_of_join(panel, fundamentals, date_col="datetime", ticker_col="ticker"):
    """
    Attach fundamentals to a panel using a backward as-of merge per ticker.

    Each panel row receives the most recent statement **published on or before**
    that row's date. Rows earlier than a ticker's first publication get NaN,
    which is correct: nothing was knowable yet.

    Raises
    ------
    ValueError
        If ``fundamentals`` is not point-in-time. Refusing beats warning — a
        warning in a log is not a defence against the one mistake that would
        invalidate every downstream number.
    """
    if fundamentals is None or fundamentals.empty:
        return panel.copy()
    if fundamentals.attrs.get("point_in_time") is False:
        raise ValueError(
            "refusing to join a non-point-in-time frame (current_snapshot) onto "
            "a historical panel: Ticker.info holds TODAY's values, so every "
            "historical row would carry information that did not exist yet. "
            "Use fundamental_history() instead.")

    left = panel.copy()
    left[date_col] = pd.to_datetime(left[date_col])
    right = fundamentals.copy()
    right["available_from"] = pd.to_datetime(right["available_from"])
    right = right.dropna(subset=["available_from"])
    if right.empty:
        return left

    left = left.sort_values(date_col)
    right = right.sort_values("available_from")
    merged = pd.merge_asof(
        left, right[["ticker", "available_from"] + list(FUNDAMENTAL_COLS)],
        left_on=date_col, right_on="available_from",
        left_by=ticker_col, right_by="ticker",
        direction="backward",
    )
    return merged.drop(columns=[c for c in ("ticker_y",) if c in merged.columns])


def coverage_report(tickers, panel_start=None, panel_end=None, quarterly=True,
                    verbose=True):
    """
    Measure how much of a target window point-in-time fundamentals actually cover.

    This is the module's most useful function, because the answer determines
    whether the experiment is worth running at all. Reports per ticker and in
    aggregate: number of periods, earliest publication date, and the fraction of
    ``[panel_start, panel_end]`` that any fundamental data is available for.
    """
    rows = []
    for i, tk in enumerate(tickers, 1):
        hist = fundamental_history(tk, quarterly=quarterly)
        if hist.empty:
            rows.append({"ticker": tk, "n_periods": 0, "first_available": pd.NaT,
                         "last_available": pd.NaT, "covered_years": 0.0})
        else:
            rows.append({
                "ticker": tk,
                "n_periods": int(len(hist)),
                "first_available": hist["available_from"].min(),
                "last_available": hist["available_from"].max(),
                "covered_years": float(
                    (hist["available_from"].max() - hist["available_from"].min())
                    .days / 365.25),
            })
        if verbose:
            print(f"  [{i}/{len(tickers)}] {tk}: {rows[-1]['n_periods']} periods")

    df = pd.DataFrame(rows)
    summary = {
        "n_tickers": int(len(df)),
        "n_with_data": int((df["n_periods"] > 0).sum()),
        "median_periods": float(df["n_periods"].median()) if len(df) else 0.0,
        "max_periods": int(df["n_periods"].max()) if len(df) else 0,
    }
    if panel_start is not None and panel_end is not None and len(df):
        ps, pe = pd.Timestamp(panel_start), pd.Timestamp(panel_end)
        span_years = max((pe - ps).days / 365.25, 1e-9)
        first = df["first_available"].dropna()
        if len(first):
            covered = (pe - first.median()).days / 365.25
            summary.update({
                "panel_years": round(span_years, 2),
                "median_first_available": str(first.median().date()),
                "covered_years": round(max(covered, 0.0), 2),
                "covered_fraction": round(max(covered, 0.0) / span_years, 3),
            })
    return df, summary
