# # -----------------------------------------------------------------------------
# # 1. IMPORTS FROM YOUR CUSTOM MODULES
# # -----------------------------------------------------------------------------
# # Wrap imports in try-except to prevent crashing if files are missing during setup

# import streamlit as st
# import plotly.graph_objects as go

# from get_data import company_list, get_whole_stock_data
# from ARIMA_GARCH import run_statistical_prediction
# from DL_Model import run_DL_prediction
# from fb_prophet_model import run_prophet_prediction
# from ML_Model import run_ML_prediction
# from Transformer_model import run_transformer_prediction

# # -----------------------------------------------------------------------------
# # 2. PAGE CONFIGURATION
# # -----------------------------------------------------------------------------
# st.set_page_config(page_title="Forecasting App", layout="wide", page_icon="📈")

# # -----------------------------------------------------------------------------
# # 3. CUSTOM CSS
# # -----------------------------------------------------------------------------
# def local_css():
#     st.markdown("""
#         <style>
#         /* Submit Button - Green */
#         [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button {
#             background-color: #28a745;
#             color: white;
#             border-color: #28a745;
#         }
#         [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button:hover {
#             background-color: #218838;
#             border-color: #1e7e34;
#             color: white;
#         }

#         /* Reset Button - Red */
#         [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button {
#             background-color: #dc3545;
#             color: white;
#             border-color: #dc3545;
#         }
#         [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button:hover {
#             background-color: #c82333;
#             border-color: #bd2130;
#             color: white;
#         }
        
#         .block-container {
#             padding-top: 2rem;
#         }
#         </style>
#         """, unsafe_allow_html=True)

# # -----------------------------------------------------------------------------
# # 4. GRAPHING FUNCTION
# # -----------------------------------------------------------------------------
# def plot_predictions_with_history(original_df, prediction_df, company_name, interval, lookback=20):
#     """
#     Creates an interactive plot using Plotly.
#     Expects original_df to have ['datetime', 'adj_close']
#     Expects prediction_df to have ['datetime', 'predicted_price']
#     """
    
#     # Ensure we don't look back more than we have
#     lookback = min(lookback, len(original_df))
#     history_subset = original_df.tail(lookback).copy()
    
#     # Get the connection point (last historical data point)
#     last_hist_point = history_subset.iloc[-1]
    
#     # Create the prediction line data, starting from the last history point
#     pred_dates = [last_hist_point['datetime']] + list(prediction_df['datetime'])
#     pred_prices = [last_hist_point['adj_close']] + list(prediction_df['predicted_price'])
    
#     fig = go.Figure()

#     # --- Trace 1: History (Blue Line) ---
#     fig.add_trace(go.Scatter(
#         x=history_subset['datetime'],
#         y=history_subset['adj_close'],
#         mode='lines+markers', 
#         name='History',
#         line=dict(color="#1f77b4", width=2), 
#         marker=dict(size=6)
#     ))

#     # --- Trace 2: Forecast (Red Dashed Line) ---
#     fig.add_trace(go.Scatter(
#         x=pred_dates,
#         y=pred_prices,
#         mode='lines+markers',
#         name='Forecast',
#         line=dict(color='#d62728', width=2, dash='dash'), 
#         marker=dict(symbol='x', size=8)
#     ))

#     # Layout
#     fig.update_layout(
#         title=f'{company_name} Prediction: {str(interval).capitalize()} Interval',
#         xaxis_title='Date / Time',
#         yaxis_title='Price',
#         template="plotly_white", 
#         hovermode="x unified",   
#         showlegend=True,
#         margin=dict(l=20, r=20, t=40, b=20)
#     )

#     # X-Axis Formatting
#     if 'Hour' in str(interval) or 'h' in str(interval):
#         fig.update_xaxes(rangeslider_visible=False, tickformat="%d-%b %H:%M", nticks=15)
#     else:
#         fig.update_xaxes(rangeslider_visible=False, tickformat="%Y-%m-%d", nticks=15)
#     return fig 

# # -----------------------------------------------------------------------------
# # 5. REAL BACKEND INTEGRATION
# # -----------------------------------------------------------------------------

# def get_available_companies():
#     """Fetches company list from get_data.py"""
#     try:
#         return company_list()
#     except Exception as e:
#         st.error(f"Error fetching company list: {e}")
#         return ["Error Loading Companies"]

# def run_all_models(company_name, ui_interval, horizon):
#     """
#     Orchestrates the data fetching and model running.
#     """
#     results = {}
    
#     # 1. Convert UI Interval to Backend Interval format
#     # UI: '1 Day', '1 Hour' -> Backend: '1d', '1h'
#     if ui_interval == '1 Day':
#         backend_interval = '1d'
#     else:
#         backend_interval = '1h'
        
#     # 2. Fetch Historical Data
#     with st.spinner(f"Fetching historical data for {company_name}..."):
#         try:
#             raw_hist_df = get_whole_stock_data(company_name, backend_interval)
#             # hist_df = standardize_columns(raw_hist_df, type='history')
#         except Exception as e:
#             st.error(f"Failed to fetch data for {company_name}: {e}")
#             return {}

#     # 3. Define Models to Run
#     # Structure: (Display Name, Function, kwargs)
#     model_configs = [
#         ("ARIMA-GARCH", run_statistical_prediction, {}),
#         ("Prophet", run_prophet_prediction, {}),
#         ("LSTM (DL)", run_DL_prediction, {'model_type': 'LSTM'}),
#         ("GRU (DL)", run_DL_prediction, {'model_type': 'GRU'}),
#         ("XGBoost (ML)", run_ML_prediction, {'model_type': 'xgboost'}),
#         ("LightGBM (ML)", run_ML_prediction, {'model_type': 'lightgbm'}),
#         ("Transformer", run_transformer_prediction, {})
#     ]

#     # 4. Run Loop
#     progress_bar = st.progress(0)
#     total_models = len(model_configs)
    
#     for i, (name, func, kwargs) in enumerate(model_configs):
#         try:
#             # Update progress
#             progress_bar.progress((i) / total_models, text=f"Running {name}...")
            
#             # Call the model function
#             # Assuming all functions accept: df, interval, horizon, + specific kwargs
#             raw_pred_df = func(raw_hist_df, backend_interval, horizon, **kwargs)
            
#             # Store result
#             results[name] = {'history': raw_hist_df, 'prediction': raw_pred_df}
            
#         except Exception as e:
#             st.warning(f"Model {name} failed: {e}")
#             # Optionally store an empty result or skip
            
#     progress_bar.empty()
#     return results

# # -----------------------------------------------------------------------------
# # 6. SESSION STATE & CALLBACKS
# # -----------------------------------------------------------------------------

# if 'submitted' not in st.session_state:
#     st.session_state['submitted'] = False

# def reset_callback():
#     st.session_state['submitted'] = False
#     # Reset to defaults
#     companies = get_available_companies()
#     if companies:
#         st.session_state['sb_company'] = companies[0]
#     st.session_state['sb_freq'] = '1 Day'
#     st.session_state['sb_period'] = 30

# def submit_callback():
#     st.session_state['submitted'] = True

# # -----------------------------------------------------------------------------
# # 7. SIDEBAR UI
# # -----------------------------------------------------------------------------

# local_css()

# st.sidebar.image("./UI asset/logo_1.png", use_container_width=True)
# st.sidebar.title("Configuration")

# # A. Search (Real Data)
# company_options = get_available_companies()
# selected_company = st.sidebar.selectbox("Search Company", options=company_options, key='sb_company')

# # B. Frequency
# selected_freq = st.sidebar.radio("Select Frequency", options=['1 Day', '1 Hour'], key='sb_freq')

# # C. Dynamic Dropdown (Horizon)
# if selected_freq == '1 Day':
#     horizon_label = "Forecast Horizon (Days)"
#     horizon_options = [7, 14, 30, 60, 90, 180]
# else:
#     horizon_label = "Forecast Horizon (Hours)"
#     horizon_options = [6, 12, 24, 48, 72, 96]

# selected_period = st.sidebar.selectbox(horizon_label, options=horizon_options, key='sb_period')

# st.sidebar.markdown("---")

# # D. Buttons
# col_btn1, col_btn2 = st.sidebar.columns(2)
# with col_btn1:
#     st.button("Submit", on_click=submit_callback, use_container_width=True)
# with col_btn2:
#     st.button("Reset", on_click=reset_callback, use_container_width=True)

# # -----------------------------------------------------------------------------
# # 8. MAIN UI LAYOUT
# # -----------------------------------------------------------------------------

# st.title("Multi-Model Forecasting Results")

# if st.session_state['submitted']:
    
#     # Run the real models
#     model_results = run_all_models(selected_company, selected_freq, selected_period)
    
#     if not model_results:
#         st.warning("No models generated results successfully. Please check data availability.")
    
#     for model_name, data in model_results.items():
        
#         st.markdown(f"### Model: {model_name}")
        
#         hist_df = data['history']
#         pred_df = data['prediction']
        
#         # Layout: Dataframe (Left) | Graph (Right)
#         c1, c2 = st.columns([1, 2]) 
        
#         with c1:
#             st.markdown("**Predicted Values**")
#             st.dataframe(pred_df, use_container_width=True, height=400)
            
#         with c2:
#             try:
#                 fig = plot_predictions_with_history(
#                     original_df=hist_df, 
#                     prediction_df=pred_df, 
#                     company_name=selected_company,
#                     interval=selected_freq,
#                     lookback=20 # Visual lookback
#                 )
#                 st.plotly_chart(fig, use_container_width=True, key=f"chart_{model_name}")
#             except Exception as e:
#                 st.error(f"Error plotting graph for {model_name}: {e}")
#         st.divider()
# else:
#     st.info("Select parameters and click Submit to generate forecasts.")




# -----------------------------------------------------------------------------
# 1. IMPORTS
# -----------------------------------------------------------------------------

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

# try:
from get_data import company_list, get_whole_stock_data
from ARIMA_GARCH import run_statistical_prediction
from DL_Model import run_DL_prediction
from fb_prophet_model import run_prophet_prediction
from ML_Model import run_ML_prediction
from Transformer_model import run_transformer_prediction 
# except ImportError as e:
#     st.error(f"Error importing local modules: {e}. Please ensure .py files are in the same directory.")
#     st.stop()

# -----------------------------------------------------------------------------
# 2. PAGE CONFIGURATION
# -----------------------------------------------------------------------------
st.set_page_config(page_title="Forecasting App", layout="wide", page_icon="📈")

# -----------------------------------------------------------------------------
# 3. CUSTOM CSS
# -----------------------------------------------------------------------------
def local_css():
    st.markdown("""
        <style>
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button {
            background-color: #28a745;
            color: white;
            border-color: #28a745;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button:hover {
            background-color: #218838;
            border-color: #1e7e34;
            color: white;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button:hover {
            background-color: #c82333;
            border-color: #bd2130;
            color: white;
        }
        .block-container {
            padding-top: 2rem;
        }
        </style>
        """, unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# 4. GRAPHING FUNCTION (Smart Column Detection)
# -----------------------------------------------------------------------------
def get_col_by_candidates(df, candidates):
    """Helper to find the first existing column from a list of candidates (case-insensitive)."""
    df_cols = [c.lower() for c in df.columns]
    for cand in candidates:
        if cand.lower() in df_cols:
            # Return the actual column name from the dataframe
            return df.columns[df_cols.index(cand.lower())]
    return None

def plot_predictions_with_history(original_df, prediction_df, company_name, interval, lookback=50):
    """
    Creates an interactive plot. 
    Dynamically finds Date/Price columns to handle different model outputs.
    """
    candidates = ['date', 'datetime', 'time', 'ds']
    # 1. Identify Columns for History
    date_col_hist = get_col_by_candidates(original_df, candidates)
    price_col_hist = get_col_by_candidates(original_df, ['adj close', 'close', 'price', 'y'])
    
    # 2. Identify Columns for Prediction
    date_col_pred = get_col_by_candidates(prediction_df, candidates)
    price_col_pred = get_col_by_candidates(prediction_df, ['predicted_price', 'prediction', 'forecast', 'yhat', 'pred', 'close'])

    if not (date_col_hist and price_col_hist and date_col_pred and price_col_pred):
        st.error(f"Could not identify Date/Price columns. Found: {original_df.columns} & {prediction_df.columns}")
        return go.Figure()

    # Ensure lookback doesn't exceed data length
    lookback = min(lookback, len(original_df))
    history_subset = original_df.tail(lookback).copy()
    
    # Get connection point
    last_hist_point = history_subset.iloc[-1]
    
    # Prepare plotting data
    pred_dates = [last_hist_point[date_col_hist]] + list(prediction_df[date_col_pred])
    pred_prices = [last_hist_point[price_col_hist]] + list(prediction_df[price_col_pred])
    
    fig = go.Figure()

    # History Trace
    fig.add_trace(go.Scatter(
        x=history_subset[date_col_hist],
        y=history_subset[price_col_hist],
        mode='lines+markers', 
        name='History',
        line=dict(color="#1f77b4", width=2), 
        marker=dict(size=6)
    ))

    # Forecast Trace
    fig.add_trace(go.Scatter(
        x=pred_dates,
        y=pred_prices,
        mode='lines+markers',
        name='Forecast',
        line=dict(color='#d62728', width=2, dash='dash'), 
        marker=dict(symbol='x', size=8)
    ))

    # Layout
    fig.update_layout(
        title=f'{company_name} Prediction: {str(interval).capitalize()} Interval',
        xaxis_title='Date / Time',
        yaxis_title='Price',
        template="plotly_white", 
        hovermode="x unified",   
        showlegend=True,
        margin=dict(l=20, r=20, t=40, b=20)
    )

    # X-Axis Formatting
    if 'h' in str(interval).lower():
        fig.update_xaxes(rangeslider_visible=False, tickformat="%d-%b %H:%M", nticks=15)
    else:
        fig.update_xaxes(rangeslider_visible=False, tickformat="%Y-%m-%d", nticks=15)

    return fig 

# -----------------------------------------------------------------------------
# 5. BACKEND ORCHESTRATION
# -----------------------------------------------------------------------------

def get_available_companies():
    try:
        return company_list()
    except Exception as e:
        st.error(f"Error fetching company list: {e}")
        return []

def run_all_models(company_name, ui_interval, horizon):
    results = {}
    
    # --- FIX 2: Explicit Interval Conversion ---
    # Ensure we pass exactly '1d' or '1h' to the backend functions
    if ui_interval == '1 Day':
        backend_interval = '1d'
    else:
        backend_interval = '1h'
        
    # Fetch Historical Data
    with st.spinner(f"Fetching historical data ({backend_interval})..."):
        try:
            # --- FIX 1: No standardization, using raw DF ---
            hist_df = get_whole_stock_data(company_name, backend_interval)
            
            # Basic validation
            if hist_df is None or hist_df.empty:
                st.error("Received empty data from backend.")
                return {}
        except Exception as e:
            st.error(f"Failed to fetch data: {e}")
            return {}

    # Define Models
    model_configs = [
        ("ARIMA-GARCH", run_statistical_prediction, {}),
        ("Prophet", run_prophet_prediction, {}),
        ("LSTM (DL)", run_DL_prediction, {'model_type': 'LSTM'}),
        ("GRU (DL)", run_DL_prediction, {'model_type': 'GRU'}),
        ("XGBoost (ML)", run_ML_prediction, {'model_type': 'xgboost'}),
        ("LightGBM (ML)", run_ML_prediction, {'model_type': 'lightgbm'}),
        ("Transformer", run_transformer_prediction, {})
    ]

    progress_bar = st.progress(0)
    total_models = len(model_configs)
    
    for i, (name, func, kwargs) in enumerate(model_configs):
        try:
            progress_bar.progress((i) / total_models, text=f"Running {name}...")
            
            # Call Model
            pred_df = func(hist_df, backend_interval, horizon, **kwargs)
            
            results[name] = {'history': hist_df, 'prediction': pred_df}
        except Exception as e:
            st.warning(f"Model {name} failed: {e}")
            
    progress_bar.empty()
    return results

# -----------------------------------------------------------------------------
# 6. SESSION STATE & CALLBACKS
# -----------------------------------------------------------------------------

if 'submitted' not in st.session_state:
    st.session_state['submitted'] = False

def reset_callback():
    st.session_state['submitted'] = False
    companies = get_available_companies()
    if companies:
        st.session_state['sb_company'] = companies[0]
    st.session_state['sb_freq'] = '1 Day'
    st.session_state['sb_period'] = 30

def submit_callback():
    st.session_state['submitted'] = True

# -----------------------------------------------------------------------------
# 7. SIDEBAR UI
# -----------------------------------------------------------------------------

local_css()

st.sidebar.image("./UI asset/logo_1.png", use_container_width=True)
st.sidebar.title("Configuration")

# Search
company_options = get_available_companies()
selected_company = st.sidebar.selectbox("Search Company", options=company_options, key='sb_company')

# Frequency
selected_freq = st.sidebar.radio("Select Frequency", options=['1 Day', '1 Hour'], key='sb_freq')

# Horizon Dropdown
if selected_freq == '1 Day':
    horizon_label = "Forecast Horizon (Days)"
    horizon_options = [3, 5, 7, 9, 11, 13]
else:
    horizon_label = "Forecast Horizon (Hours)"
    horizon_options = [3, 5, 7, 9, 11, 13]

selected_period = st.sidebar.selectbox(horizon_label, options=horizon_options, key='sb_period')

st.sidebar.markdown("---")

# Buttons
col_btn1, col_btn2 = st.sidebar.columns(2)
with col_btn1:
    st.button("Submit", on_click=submit_callback, use_container_width=True, width='stretch')
with col_btn2:
    st.button("Reset", on_click=reset_callback, use_container_width=True, width='stretch')

# -----------------------------------------------------------------------------
# 8. MAIN UI LAYOUT
# -----------------------------------------------------------------------------

st.title("Multi-Model Forecasting Results")

# --- FIX 3: Caution Message ---
st.warning("⚠️ **Caution:** These predictions are based on historical data patterns and mathematical models. They may not reflect real-world market volatility, news events, or economic changes. Use for educational purposes only.")

if st.session_state['submitted']:
    
    model_results = run_all_models(selected_company, selected_freq, selected_period)
    
    if not model_results:
        st.warning("No models generated results successfully.")
    
    for model_name, data in model_results.items():
        
        st.markdown(f"### Model: {model_name}")
        
        hist_df = data['history']
        pred_df = data['prediction']
        
        c1, c2 = st.columns([1, 2]) 
        
        with c1:
            st.markdown("**Predicted Values**")
            st.dataframe(pred_df, use_container_width=True, height=400, width='stretch')
            
        with c2:
            try:
                fig = plot_predictions_with_history(
                    original_df=hist_df, 
                    prediction_df=pred_df, 
                    company_name=selected_company,
                    interval=selected_freq, # Passed for Title
                    lookback=20
                )
                st.plotly_chart(fig, use_container_width=True, key=f"chart_{model_name}", width='stretch')
            except Exception as e:
                st.error(f"Error plotting graph for {model_name}: {e}")
        
        st.divider()

else:
    st.info("Select parameters and click Submit to generate forecasts.")