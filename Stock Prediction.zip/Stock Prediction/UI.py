# -----------------------------------------------------------------------------
# 1. IMPORTS
# -----------------------------------------------------------------------------

import streamlit as st
import pandas as pd
import datetime as _dt
import time as _time
import numpy as np
import plotly.graph_objects as go
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

from get_data import company_list, get_whole_stock_data
from ARIMA_GARCH import run_statistical_prediction
from ARIMAX_model import run_arimax_prediction
from DL_model import run_DL_prediction
from fb_prophet_model import run_prophet_prediction
from ML_model import run_ML_prediction
from Transformer_model import run_transformer_prediction
from chronos_model import run_chronos_prediction
from NBeats_model import run_nbeats_prediction
from TCN_model import run_tcn_prediction
from Ensemble_model import run_ensemble_prediction
from Quantile_model import run_quantile_prediction
from RegimeSwitching_model import run_regime_prediction
from Hybrid_model import run_hybrid_prediction
from meta_ensemble import run_meta_ensemble_prediction
from HAR_RV_model import run_har_rv_prediction
from vol_lstm_model import run_vol_lstm_prediction
from CNN_LSTM_model import run_cnn_lstm_prediction
from kalman_model import run_kalman_prediction
from market_context import add_market_context
from model_utils import compute_device_label, NSE_BARS_PER_SESSION

# Feature flags live in config.py — one registry, with the evidence for each
# default recorded next to it, and a STOCKAPP_* environment override per flag so
# an A/B run does not require editing (and accidentally committing) a constant.
# They were previously defined here and in ML_model.py, which forced the console
# banner to import a flag out of a model module purely to display it.
import config as _cfg
from config import (
    USE_MARKET_CONTEXT,
    USE_IV_ADJUST,
    USE_ASYMMETRIC_CONE,
    USE_REGIME_NOVELTY,
    USE_PREDICTION_LOG,
)

# -----------------------------------------------------------------------------
# 2. PAGE CONFIGURATION
# -----------------------------------------------------------------------------
st.set_page_config(page_title="Forecasting App", layout="wide", page_icon="📈")

# Single source of truth for the model suite: (display name, function, kwargs),
# in execution order. The sidebar selector, the runner, and the cache key all
# derive from this list. NOTE: Meta-Ensemble internally re-runs Quantile-LGBM +
# XGBoost + ARIMAX, so selecting it alongside those duplicates that compute;
# per-model caching (below) makes the duplication a cache hit rather than a
# recomputation.
MODEL_REGISTRY = [
    ("ARIMA-GARCH", run_statistical_prediction, {}),
    ("ARIMAX-GARCH", run_arimax_prediction, {}),
    ("Prophet", run_prophet_prediction, {}),
    ("LSTM (DL)", run_DL_prediction, {'model_type': 'LSTM'}),
    ("GRU (DL)", run_DL_prediction, {'model_type': 'GRU'}),
    ("XGBoost (ML)", run_ML_prediction, {'model_type': 'xgboost'}),
    ("LightGBM (ML)", run_ML_prediction, {'model_type': 'lightgbm'}),
    ("Transformer", run_transformer_prediction, {}),
    ("Chronos-2", run_chronos_prediction, {}),  # company_name injected at call
    ("N-BEATS", run_nbeats_prediction, {}),
    ("TCN", run_tcn_prediction, {}),
    ("CNN-LSTM", run_cnn_lstm_prediction, {}),
    ("Stacking Ensemble", run_ensemble_prediction, {}),
    ("Quantile (LGB)", run_quantile_prediction, {}),
    ("Regime Switching", run_regime_prediction, {}),
    ("Hybrid ARIMA+LSTM", run_hybrid_prediction, {}),
    # The only state-space model in the suite: parameters are re-estimated every
    # bar rather than frozen after a fit, and the interval falls out of the state
    # covariance instead of a conformal calibration (Klaas Ch. 4).
    ("Kalman (local trend)", run_kalman_prediction, {}),
    ("HAR-RV (volatility)", run_har_rv_prediction,
     {'iv_adjust': USE_IV_ADJUST, 'asymmetric': USE_ASYMMETRIC_CONE}),
    ("Vol-LSTM (volatility)", run_vol_lstm_prediction,
     {'asymmetric': USE_ASYMMETRIC_CONE}),
    ("Meta-Ensemble", run_meta_ensemble_prediction, {}),
]
MODEL_NAMES = [name for name, _, _ in MODEL_REGISTRY]
_MODEL_LOOKUP = {name: (func, kwargs) for name, func, kwargs in MODEL_REGISTRY}

# -----------------------------------------------------------------------------
# 3. CUSTOM CSS
# -----------------------------------------------------------------------------
def local_css():
    """
    Inject custom CSS to style the sidebar buttons and page padding.

    Applies a green theme to the first sidebar button (Submit) and a
    red theme to the second (Reset), with hover states. Also reduces
    top padding on the main content area.
    """
    st.markdown("""
        <style>
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button {
            background-color: #28a745;
            color: white;
            border-color: #28a745;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(1) button:hover {
            background-color: #218838;
            border-color: #1e7e34;
            color: white;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        [data-testid="stSidebar"] [data-testid="column"]:nth-of-type(2) button:hover {
            background-color: #c82333;
            border-color: #bd2130;
            color: white;
        }
        .block-container {
            padding-top: 2rem;
        }
        </style>
        """, unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# 4. GRAPHING FUNCTION (Smart Column Detection)
# -----------------------------------------------------------------------------
def get_col_by_candidates(df, candidates):
    """
    Find the first existing column from a list of candidates (case-insensitive).

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame whose columns are searched.
    candidates : list of str
        Candidate column names to look for, in priority order.

    Returns
    -------
    str or None
        The actual column name from the DataFrame if found, else None.
    """
    df_cols = [c.lower() if isinstance(c, str) else str(c).lower()
               for c in df.columns]
    for cand in candidates:
        if cand.lower() in df_cols:
            return df.columns[df_cols.index(cand.lower())]
    return None


def plot_predictions_with_history(original_df, prediction_df, company_name, interval, lookback=50):
    """
    Create an interactive Plotly chart with history, forecast, and CI band.

    Dynamically detects date and price columns in both DataFrames.
    If the prediction DataFrame contains ``lower_bound`` and
    ``upper_bound`` columns, a shaded 95% confidence-interval band
    is added behind the forecast trace.

    Parameters
    ----------
    original_df : pd.DataFrame
        Historical stock data with a date and a price column.
    prediction_df : pd.DataFrame
        Model predictions with a date, predicted-price, and optionally
        lower_bound / upper_bound columns.
    company_name : str
        Company name for the chart title.
    interval : str
        Frequency label (e.g., '1 Day', '1 Hour') for the chart title
        and x-axis formatting.
    lookback : int, optional
        Number of recent historical points to display. Default 50.

    Returns
    -------
    plotly.graph_objects.Figure
        Plotly figure with history, forecast, and optional CI band.
    """
    date_candidates = ['date', 'datetime', 'time', 'ds']

    date_col_hist = get_col_by_candidates(original_df, date_candidates)
    price_col_hist = get_col_by_candidates(
        original_df, ['adj close', 'adj_close', 'close', 'price', 'y'],
    )

    date_col_pred = get_col_by_candidates(prediction_df, date_candidates)
    price_col_pred = get_col_by_candidates(
        prediction_df,
        ['predicted_price', 'prediction', 'forecast', 'yhat', 'pred', 'close'],
    )

    if not (date_col_hist and price_col_hist and date_col_pred and price_col_pred):
        st.error(
            f"Could not identify Date/Price columns. "
            f"Found: {list(original_df.columns)} & {list(prediction_df.columns)}"
        )
        return go.Figure()

    lookback = min(lookback, len(original_df))
    history_subset = original_df.tail(lookback).copy()

    last_hist_point = history_subset.iloc[-1]

    pred_dates = [last_hist_point[date_col_hist]] + list(
        prediction_df[date_col_pred]
    )
    pred_prices = [last_hist_point[price_col_hist]] + list(
        prediction_df[price_col_pred]
    )

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=history_subset[date_col_hist],
        y=history_subset[price_col_hist],
        mode='lines+markers',
        name='History',
        line=dict(color="#1f77b4", width=2),
        marker=dict(size=6),
    ))

    lower_col = get_col_by_candidates(
        prediction_df, ['lower_bound', 'lower'],
    )
    upper_col = get_col_by_candidates(
        prediction_df, ['upper_bound', 'upper'],
    )
    if lower_col and upper_col:
        fig.add_trace(go.Scatter(
            x=list(prediction_df[date_col_pred]),
            y=list(prediction_df[upper_col]),
            mode='lines',
            line=dict(width=0),
            showlegend=False,
            hoverinfo='skip',
        ))
        fig.add_trace(go.Scatter(
            x=list(prediction_df[date_col_pred]),
            y=list(prediction_df[lower_col]),
            mode='lines',
            line=dict(width=0),
            fill='tonexty',
            fillcolor='rgba(214, 39, 40, 0.15)',
            name='95% CI',
        ))

    # Naive random-walk baseline (price stays flat at the last observed value)
    # — shown so the model's forecast is read against the "no-skill" reference,
    # not mistaken for certainty.
    anchor_price = pred_prices[0]
    fig.add_trace(go.Scatter(
        x=pred_dates,
        y=[anchor_price] * len(pred_dates),
        mode='lines',
        name='Random walk (naive)',
        line=dict(color='#7f7f7f', width=1.5, dash='dot'),
        hovertemplate='Naive: %{y:.2f}<extra></extra>',
    ))

    fig.add_trace(go.Scatter(
        x=pred_dates,
        y=pred_prices,
        mode='lines+markers',
        name='Forecast (median)',
        line=dict(color='#d62728', width=2, dash='dash'),
        marker=dict(symbol='x', size=8),
    ))

    fig.update_layout(
        title=f'{company_name} Prediction: {str(interval).capitalize()} Interval',
        xaxis_title='Date / Time',
        yaxis_title='Price',
        template="plotly_white",
        hovermode="x unified",
        showlegend=True,
        height=480,
        # Legend overlaid inside the (empty) top-right of the plot instead of
        # outside-right, so the plot itself uses the full width.
        legend=dict(
            x=0.99, xanchor='right', y=0.99, yanchor='top',
            bgcolor='rgba(127,127,127,0.12)',
            bordercolor='rgba(127,127,127,0.35)', borderwidth=1,
        ),
        margin=dict(l=20, r=10, t=50, b=20),
    )

    if 'h' in str(interval).lower():
        fig.update_xaxes(
            rangeslider_visible=False, tickformat="%d-%b %H:%M", nticks=15,
        )
    else:
        fig.update_xaxes(
            rangeslider_visible=False, tickformat="%Y-%m-%d", nticks=15,
        )

    # Trim the trailing empty space: clamp the x-range to the actual data
    # (history start .. last forecast date) plus a small right pad.
    try:
        xmin = pd.Timestamp(history_subset[date_col_hist].iloc[0])
        xmax = pd.Timestamp(pred_dates[-1])
        if xmax > xmin:
            fig.update_xaxes(range=[xmin, xmax + (xmax - xmin) * 0.03])
    except Exception:
        pass

    return fig


# -----------------------------------------------------------------------------
# 5. BACKEND ORCHESTRATION
# -----------------------------------------------------------------------------

@st.cache_data(ttl=3600, show_spinner=False)
def _fetch_company_list():
    """
    Fetch and cache the list of available company names.

    Cached for 1 hour to avoid re-fetching on every Streamlit render
    cycle. The caching wrapper is separated from error handling so
    that ``st.error`` is not called inside a cached function.

    Returns
    -------
    list of str
        Sorted company names from BSE/NSE.
    """
    return company_list()


def get_available_companies():
    """
    Fetch the list of available company names for the sidebar dropdown.

    Delegates to a cached inner function and catches any errors,
    returning an empty list as a fallback.

    Returns
    -------
    list of str
        Sorted company names, or an empty list on error.
    """
    try:
        return _fetch_company_list()
    except Exception as e:
        st.error(f"Error fetching company list: {e}")
        return []


@st.cache_data(ttl=3600, show_spinner=False)
def _fetch_history(company_name, backend_interval, use_context):
    """
    Fetch (and optionally enrich) historical data, cached per parameter set.

    Caching means a Streamlit rerun triggered by any widget interaction does not
    re-hit the network, and every model for a given company/interval reuses the
    same fetched history.

    Parameters
    ----------
    company_name : str
        Selected company name.
    backend_interval : str
        '1d' or '1h'.
    use_context : bool
        Whether to attach market-context features (see USE_MARKET_CONTEXT).

    Returns
    -------
    pd.DataFrame or None
        Historical OHLCV data, or None if the backend returned nothing.
    """
    # Resilient fetch: retries + last-known-good cache fallback, tagging
    # attrs['source'] (live / partial / cached_fallback) which the data-quality
    # gate reads. A transient yfinance hiccup degrades gracefully instead of
    # silently producing a broken forecast.
    hist_df = fetch_with_fallback(
        company_name, backend_interval, fetch_fn=get_whole_stock_data)
    if not isinstance(hist_df, pd.DataFrame) or hist_df.empty:
        return None
    if use_context:
        try:
            hist_df = add_market_context(hist_df, backend_interval)
        except Exception as ctx_err:
            _console.note("data", f"market-context enrichment skipped: {ctx_err}")
    return hist_df


@st.cache_data(ttl=3600, show_spinner=False)
def _run_one_model(company_name, backend_interval, horizon, model_name,
                   use_context):
    """
    Run a single model and return its prediction, cached per parameter set.

    Keyed on (company, interval, horizon, model, use_context) so reruns and
    re-selections are cache hits rather than recomputation — the fix for the
    UI re-running the whole suite on every interaction. Exceptions are not
    cached, so a transient failure is retried on the next run.

    Returns
    -------
    pd.DataFrame or None
        The model's prediction DataFrame, or None if history is unavailable.
    """
    hist_df = _fetch_history(company_name, backend_interval, use_context)
    if hist_df is None:
        return None
    func, kwargs = _MODEL_LOOKUP[model_name]
    kwargs = dict(kwargs)
    if model_name == "Chronos-2":
        kwargs["company_name"] = company_name
    return func(hist_df, backend_interval, horizon, **kwargs)


# Walk-forward confidence-gate settings (kept light so it stays interactive).
_GATE_SPLITS = _cfg.GATE_SPLITS
_GATE_MIN_TRAIN = _cfg.GATE_MIN_TRAIN
_GATE_MAX_ROWS = _cfg.GATE_MAX_ROWS


# The skill->label rule lives in backtest.py so the live gate and the offline
# calibration/gate-validation harness score the exact same definition.
from backtest import confidence_bucket as _confidence_bucket

# Data-quality gate: score the input before trusting any forecast (reviewer
# request). Bad data abstains or drops to the risk-cone-only mode rather than
# producing a confident-looking line off broken inputs.
from data_quality import assess_data_quality, gate_action

# Reproducibility: pin every RNG per run and record an auditable manifest.
from reproducibility import set_all_seeds, run_manifest, GLOBAL_SEED

# Resilient data fetch: retries + last-known-good cache fallback + source status.
from safe_fetch import fetch_with_fallback

# Forward prediction log: record every served forecast for later calibration-drift
# monitoring, live gate validation, and the paper portfolio (book Ch. 3).
import prediction_log as _plog

# Console output (console.py). The terminal trace used to show per-model chatter
# and nothing about what the app concluded; these calls mirror the UI's decision
# layer to stdout. Rendered from the same verdicts the browser shows, never
# recomputed, so the two channels cannot drift apart. STOCKAPP_QUIET=1 silences.
import console as _console
import architectures as _arch

_console.startup_banner(
    seed=GLOBAL_SEED,
    device=compute_device_label(),
    n_models=len(MODEL_NAMES),
    flags=_cfg.active_flags(),
    overrides=(_cfg.overridden()
               + [f"architecture:{n}" for n in _arch.OVERRIDDEN]),
    log_path=(_plog.LOG_FILE if USE_PREDICTION_LOG else None),
)


@st.cache_data(ttl=3600, show_spinner=False)
def _model_confidence(company_name, backend_interval, horizon, model_name,
                      use_context):
    """
    Assess a model's recent skill with a light walk-forward backtest (cached).

    Runs the existing ``backtest.walk_forward_backtest`` for one model on recent
    history and returns the metrics plus a confidence bucket. Cached per
    (company, interval, horizon, model) so it is paid once. This is the
    serve-time realisation of the reviewers' "predictability gate": expose, per
    request, whether the model actually beats a random walk here.

    Returns
    -------
    dict
        {'bucket', 'improvement', 'dm_p', 'coverage', 'model_rmse',
         'baseline_rmse', 'n_eval', 'note'}.
    """
    import backtest as bt

    hist_df = _fetch_history(company_name, backend_interval, use_context)
    base = {'bucket': 'N/A', 'improvement': float('nan'), 'dm_p': float('nan'),
            'coverage': float('nan'), 'model_rmse': float('nan'),
            'baseline_rmse': float('nan'), 'n_eval': 0, 'note': ''}
    if hist_df is None or len(hist_df) < _GATE_MIN_TRAIN + horizon + 10:
        base['bucket'] = 'No data'
        base['note'] = 'insufficient history for a walk-forward check'
        return base

    gate_df = hist_df.tail(_GATE_MAX_ROWS).reset_index(drop=True)
    func, kwargs = _MODEL_LOOKUP[model_name]
    kwargs = dict(kwargs)
    if model_name == "Chronos-2":
        kwargs["company_name"] = company_name

    try:
        res = bt.walk_forward_backtest(
            gate_df, func, backend_interval, horizon,
            n_splits=_GATE_SPLITS, min_train=_GATE_MIN_TRAIN,
            predict_kwargs=kwargs, model_name=model_name, verbose=False,
            # The serve-time gate needs the RMSE/DM summary only. The economic
            # block is deliberately NOT surfaced here: with 3 origins its Sharpe
            # would be pure noise, and showing a noisy Sharpe next to a
            # calibrated confidence bucket would undercut the honesty the gate
            # exists to provide. Use tests/validation/run_strategy_eval.py, which
            # runs enough non-overlapping origins for the number to mean something.
            strategy=False,
        )
    except Exception as exc:
        base['note'] = f'assessment failed: {str(exc)[:80]}'
        return base

    s = res['summary']
    dm = res.get('dm', {})
    model_rmse = float(s.loc['rmse', 'model'])
    baseline_rmse = min(
        float(s.loc['rmse', c]) for c in ('naive', 'drift', 'ar1')
        if c in s.columns
    )
    improvement = ((baseline_rmse - model_rmse) / baseline_rmse
                   if baseline_rmse > 0 else 0.0)
    dm_p = float(dm.get('p_value', float('nan')))
    coverage = (float(s.loc['coverage', 'model'])
                if 'coverage' in s.index else float('nan'))

    return {
        'bucket': _confidence_bucket(improvement, dm_p, coverage),
        'improvement': improvement,
        'dm_p': dm_p,
        'coverage': coverage,
        'model_rmse': model_rmse,
        'baseline_rmse': baseline_rmse,
        'n_eval': len(res.get('origins', [])),
        'note': '',
    }


def run_selected_models(company_name, ui_interval, horizon, selected_models):
    """
    Run the user-selected models, collecting predictions with a progress bar.

    The heavy work (fetch + each model) is delegated to cached functions, so
    this wrapper only orchestrates progress display and per-model error
    handling. Failed models surface as UI warnings without aborting the rest.

    Parameters
    ----------
    company_name : str
        Selected company name.
    ui_interval : str
        UI frequency label ('1 Day' or '1 Hour').
    horizon : int
        Number of forecast steps.
    selected_models : list of str
        Display names (subset of MODEL_NAMES) to run.

    Returns
    -------
    dict
        Mapping model name -> {'history': DataFrame, 'prediction': DataFrame}.
    """
    backend_interval = '1d' if ui_interval == '1 Day' else '1h'

    # Pin every RNG before any model trains, so a run is reproducible given the
    # seed (auditable, not predictive — see reproducibility.py).
    set_all_seeds(GLOBAL_SEED)

    with st.spinner(f"Fetching historical data ({backend_interval})..."):
        hist_df = _fetch_history(company_name, backend_interval, USE_MARKET_CONTEXT)
    if hist_df is None:
        st.error("Received empty data from backend.")
        return {}

    results = {}
    total = len(selected_models)
    progress_bar = st.progress(0.0)

    for i, name in enumerate(selected_models):
        progress_bar.progress(i / total, text=f"Running {name}... ({i + 1}/{total})")
        try:
            pred_df = _run_one_model(
                company_name, backend_interval, horizon, name, USE_MARKET_CONTEXT,
            )
            if pred_df is not None and len(pred_df) > 0:
                results[name] = {'history': hist_df, 'prediction': pred_df}
        except Exception as e:
            st.warning(f"Model {name} failed: {e}")
        progress_bar.progress((i + 1) / total,
                              text=f"Completed {name} ({i + 1}/{total})")

    progress_bar.empty()
    return results


def _build_summary_table(model_results, last_actual_price, conf_map=None):
    """
    Build a comparison table summarising every model's final forecast.

    Parameters
    ----------
    model_results : dict
        Mapping of model name -> {'history': DataFrame,
        'prediction': DataFrame}.
    last_actual_price : float
        Last known actual price for computing change and direction.
    conf_map : dict, optional
        Mapping model -> confidence dict (from :func:`_model_confidence`). When
        a model's bucket is **'No edge'**, its directional call is **suppressed**
        (Sentiment → "No edge", Direction → "–"): asserting Bullish/Bearish off a
        point forecast that the walk-forward test says is no better than a random
        walk would contradict the app's own abstention logic. Pass None / empty
        to leave sentiment ungated (e.g. when the user disabled assessment).

    Returns
    -------
    pd.DataFrame or None
        Summary DataFrame with columns [Model, Predicted Price, Change (₹),
        Signal Score (%), Conviction, Sentiment, Direction], or None if no valid
        predictions exist.

        - **Signal Score (%)** — forecasted percentage change from the last
          actual price to the horizon; the quantity the bull/bear call is made on.
        - **Conviction** — the forecast move divided by half the model's own 95%
          interval width, i.e. how large the move is relative to the model's own
          uncertainty. Same sign as the move; ``|Conviction| >= 1`` means the
          current price falls outside the 95% interval (a high-conviction call).
          NaN for models that emit no interval.
        - **Sentiment** — "Bullish" / "Bearish" by the sign of the move, or
          "No edge" when the confidence gate found no edge over a random walk.
        - **Direction** — the matching ▲ / ▼ / – marker (kept as the last column).
    """
    conf_map = conf_map or {}
    rows = []
    for name, data in model_results.items():
        pred_df = data['prediction']
        price_col = get_col_by_candidates(
            pred_df,
            ['predicted_price', 'prediction', 'forecast', 'yhat', 'pred'],
        )
        if price_col and len(pred_df) > 0:
            final_price = float(pred_df[price_col].iloc[-1])
            change = final_price - last_actual_price
            pct = (change / last_actual_price) * 100
            bullish = change >= 0

            # Conviction: forecast move relative to the model's own 95% band
            # (pure rule in gating.py; wide band -> |conviction| < 1).
            lower_col = get_col_by_candidates(pred_df, ['lower_bound', 'lower'])
            upper_col = get_col_by_candidates(pred_df, ['upper_bound', 'upper'])
            low = float(pred_df[lower_col].iloc[-1]) if lower_col else None
            up = float(pred_df[upper_col].iloc[-1]) if upper_col else None
            conv = _conviction(change, low, up)
            conviction = round(conv, 2) if conv == conv else np.nan   # NaN-safe

            # Gate the directional call by the shared abstention rule: "No edge"
            # means don't assert a direction.
            bucket = conf_map.get(name, {}).get('bucket')
            sentiment, direction = _gated_direction(change, bucket)

            rows.append({
                'Model': name,
                'Predicted Price': round(final_price, 2),
                'Change (₹)': round(change, 2),
                'Signal Score (%)': round(pct, 2),
                'Conviction': conviction,
                'Sentiment': sentiment,
                'Direction': direction,
            })
    return pd.DataFrame(rows) if rows else None


def _build_consensus(summary_df):
    """
    Summarise where the models collectively land.

    Given the project's own finding that no single model reliably wins, the
    collective view (how many models lean up vs. down, and the median forecast)
    is more informative than any one row.

    Parameters
    ----------
    summary_df : pd.DataFrame
        Output of :func:`_build_summary_table`.

    Returns
    -------
    dict
        {'n_models', 'n_up', 'n_down', 'n_noedge', 'median_price', 'median_pct'}.
    """
    n = len(summary_df)
    n_up = int((summary_df['Sentiment'] == 'Bullish').sum())
    n_down = int((summary_df['Sentiment'] == 'Bearish').sum())
    return {
        'n_models': n,
        'n_up': n_up,
        'n_down': n_down,
        'n_noedge': n - n_up - n_down,
        'median_price': float(summary_df['Predicted Price'].median()),
        'median_pct': float(summary_df['Signal Score (%)'].median()),
    }


# Pure risk math lives in risk_metrics.py (no Streamlit dep) so it can be unit
# tested directly. The UI just renders what these return.
from risk_metrics import empirical_risk as _empirical_risk
from risk_metrics import risk_from_interval as _risk_from_interval


def build_risk_panel(model_results, last_actual, threshold_pct=2.0):
    """
    Aggregate forecast distributions into consensus risk metrics.

    **Empirical first.** Any model that exposes a fat-tailed return sample via
    ``prediction.attrs['risk_log_returns']`` (HAR-RV's and Vol-LSTM's conformal
    residuals) is used directly — samples are pooled and probabilities counted off the
    empirical distribution, preserving the tails. Only if *no* model exposes
    such a sample do we fall back to the log-normal interval approximation
    (:func:`_risk_from_interval`), and the returned ``method`` flag says which
    path was taken so the UI can caption it honestly.

    Parameters
    ----------
    model_results : dict
        Mapping model -> {'history', 'prediction'}.
    last_actual : float
        Last observed price.
    threshold_pct : float, optional
        Move size (in %) for the gain/loss probabilities. Default 2.0.

    Returns
    -------
    dict or None
        Consensus metrics (incl. 'method' and 'n_used'), or None if nothing
        usable is available.
    """
    # --- Empirical path: pool every model's fat-tailed return sample. ---
    samples, src_models = [], []
    for name, data in model_results.items():
        pred = data['prediction']
        sample = pred.attrs.get('risk_log_returns') if hasattr(pred, 'attrs') else None
        if sample is not None and len(sample) >= 20:
            samples.append(np.asarray(sample, dtype=float))
            src_models.append(name)
    if samples:
        pooled = np.concatenate(samples)
        m = _empirical_risk(last_actual, pooled, threshold_pct)
        m.update({
            'method': 'empirical',
            'n_used': len(src_models),
            'source_models': src_models,
            'threshold_pct': threshold_pct,
            'var5_price': last_actual * (1.0 + m['var5_pct']),
            'cvar5_price': last_actual * (1.0 + m['cvar5_pct']),
        })
        return m

    # --- Fallback path: log-normal read of each model's interval. ---
    keys = ('p_up', 'p_gain', 'p_loss', 'var5_pct')
    acc = {k: [] for k in keys}
    lows, highs = [], []
    for data in model_results.values():
        pred = data['prediction']
        pcol = get_col_by_candidates(
            pred, ['predicted_price', 'prediction', 'forecast', 'yhat', 'pred'])
        lcol = get_col_by_candidates(pred, ['lower_bound', 'lower'])
        ucol = get_col_by_candidates(pred, ['upper_bound', 'upper'])
        if not (pcol and lcol and ucol) or len(pred) == 0:
            continue
        r = _risk_from_interval(
            float(pred[pcol].iloc[-1]), float(pred[lcol].iloc[-1]),
            float(pred[ucol].iloc[-1]), last_actual, threshold_pct)
        if r is None:
            continue
        for k in keys:
            acc[k].append(r[k])
        lows.append(r['range_low'])
        highs.append(r['range_high'])

    if not acc['p_up']:
        return None
    med = lambda a: float(np.median(a))
    var5 = med(acc['var5_pct'])
    return {
        'method': 'gaussian',
        'n_used': len(acc['p_up']),
        'source_models': [],
        'p_up': med(acc['p_up']),
        'p_gain': med(acc['p_gain']),
        'p_loss': med(acc['p_loss']),
        'threshold_pct': threshold_pct,
        'var5_pct': var5,
        'var5_price': last_actual * (1.0 + var5),
        'range_low': med(lows),
        'range_high': med(highs),
    }


def _honesty_banner(conf_map):
    """
    Build an aggregate reliability banner from the per-model confidence buckets.

    Encodes the reviewers' (and the backtest's) core message: when models don't
    reliably beat a random walk, say so plainly and steer the user to the range
    rather than the point line.

    Parameters
    ----------
    conf_map : dict
        Mapping model name -> confidence dict (from :func:`_model_confidence`).

    Returns
    -------
    tuple(str, str) or None
        (streamlit level: 'error'|'warning'|'success', message), or None.
    """
    buckets = [c.get('bucket') for c in conf_map.values()]
    n = len(buckets)
    if n == 0:
        return None
    reliable = sum(b in ('High', 'Medium') for b in buckets)
    if reliable == 0:
        return ('error',
                "**No model showed a statistically reliable edge over a random "
                "walk** for this ticker & horizon in recent walk-forward tests. "
                "Treat the **range / interval** as the output — not the point "
                "forecast.")
    if reliable < n / 2:
        return ('warning',
                f"Only **{reliable} of {n}** models beat the random-walk "
                "baseline with any reliability here. Weight the **range** over "
                "the point line.")
    return ('success',
            f"**{reliable} of {n}** models showed a measurable edge over the "
            "random walk in recent walk-forward tests.")


# Pure serving-gate logic lives in gating.py (no Streamlit) so the trust layer is
# unit-tested directly. The UI just renders what these return.
from gating import (
    gated_direction as _gated_direction,
    conviction as _conviction,
    apply_data_quality_gate as _apply_dq_gate,
    apply_novelty_gate as _apply_novelty_gate,
    confidence_reason as _confidence_reason,
)


@st.cache_data(ttl=3600, show_spinner=False)
def _regime_novelty(company_name, backend_interval, use_context):
    """
    Score how unlike its fitted history the latest market window is (cached).

    Wraps ``autoencoder_regime.regime_novelty``. This is the signal the other two
    gates cannot see: ``data_quality`` catches a broken *input*, and the
    confidence bucket catches a model with no measured edge *in the past* — but
    neither knows that the present regime is off-manifold, where a
    backtest-derived bucket is an extrapolation rather than evidence.

    Cached per (company, interval) because fitting the autoencoder costs a few
    seconds and the answer is identical for every model in the run. Every failure
    path returns ``available=False``, which is a no-op for the gate, so enabling
    this can only ever add information.
    """
    hist_df = _fetch_history(company_name, backend_interval, use_context)
    if hist_df is None:
        return {'available': False, 'verdict': 'unknown', 'note': 'no history'}
    try:
        import autoencoder_regime as ar
        return ar.regime_novelty(hist_df, backend_interval)
    except Exception as exc:
        return {'available': False, 'verdict': 'unknown',
                'note': f'novelty check unavailable: {str(exc)[:100]}'}


def _render_fx_notice(hist_df):
    """
    Surface *how* prices were converted to INR, so the figure is auditable.

    Reads the ``fx_conversion`` audit tag attached by ``get_data`` and renders a
    caption (normal paths) or a prominent warning/error (degraded paths). The
    honest distinction the reviewer asked for: per-date historical conversion is
    period-accurate, whereas the live-uniform fallback rescales the *whole*
    history by today's rate (distorting historical levels) and the failed path
    leaves prices in the original currency.
    """
    info = getattr(hist_df, 'attrs', {}).get('fx_conversion') if hist_df is not None else None
    if not info:
        return
    method = info.get('method')
    cur = info.get('source_currency', '?')
    if method == 'none':
        return                                   # native INR — nothing to flag
    if method == 'historical':
        rate = info.get('latest_rate')
        msg = (f"💱 Prices converted **{cur} → INR at each date's own historical "
               f"rate** (period-accurate; latest ≈ ₹{rate}/{cur}).")
        if info.get('rows_filled_live'):
            msg += (f" {info['rows_filled_live']} early row(s) had no historical "
                    "rate and used today's rate as a fallback.")
        st.caption(msg)
    elif method == 'live_uniform':
        st.warning(
            f"💱 **Historical {cur}→INR rates were unavailable, so the *entire* "
            f"history was converted at today's rate (₹{info.get('rate')}/{cur}).** "
            "Day-to-day returns are preserved, but **historical price *levels* are "
            "rescaled and not period-accurate** — read absolute ₹ levels with care."
        )
    elif method == 'unconverted':
        st.error(
            f"💱 **Currency conversion failed — prices are shown in the original "
            f"{cur}, not INR.** The ₹ labels do not apply to this run."
        )


def _render_history_notice(hist_df):
    """
    Surface the available history span, esp. yfinance's ~730-day hourly cap.

    Hourly models can train on far less history than daily ones; this makes the
    lookback explicit (and warns when it is short for a meaningful fit).
    """
    info = getattr(hist_df, 'attrs', {}).get('history') if hist_df is not None else None
    if not info or info.get('interval') != '1h':
        return                                   # only relevant for hourly
    rows = info.get('rows', 0)
    sessions = rows // NSE_BARS_PER_SESSION
    msg = (f"🕒 Hourly history: **{rows} bars** over ~{info.get('span_days')} days "
           f"(~{sessions} sessions), {info.get('start')} → {info.get('end')}. "
           "Hourly lookback is **capped by the data provider** (much shorter than "
           "daily), so hourly models train on less history.")
    if rows < 700:        # < ~100 sessions: thin for fitting hourly models
        st.warning(msg + " ⚠️ This is a **short window** for training hourly "
                   "models — treat results with extra caution.")
    else:
        st.caption(msg)


def _render_data_quality(report):
    """
    Render the data-quality gate banner and a per-check expander.

    Surfaces the reviewer's data-quality reason codes: a green caption when the
    data is clean, a warning when there are caveats, and a prominent error when
    the input is too broken to forecast (the app then withholds directional calls
    and falls back to the risk cone — see the main flow).
    """
    if report is None:
        return
    act = gate_action(report)
    level = act["level"]
    headline = f"🩺 {act['headline']}"
    if level == "success":
        st.caption(headline)
    else:
        getattr(st, level)(
            f"**{act['headline']}**"
            + (f" — {act['detail']}" if act.get("detail") else "")
        )
    # Always offer the full reason list for auditability.
    if report.codes:
        with st.expander("Data-quality details"):
            for c in report.codes:
                icon = {"info": "ℹ️", "warn": "⚠️", "critical": "⛔"}.get(
                    c["severity"], "•")
                st.markdown(f"{icon} **{c['code']}** — {c['message']}")
            if report.checks:
                st.caption("Raw checks: " + ", ".join(
                    f"{k}={v}" for k, v in report.checks.items()))


def _style_summary(summary_df):
    """
    Color-code and format the summary table for readability.

    Greens/reds the Change (₹), Signal Score (%) and Sentiment columns by sign,
    color-codes the Confidence bucket if present, and formats prices in rupees.
    Returns a pandas Styler, which ``st.dataframe`` renders directly.

    Parameters
    ----------
    summary_df : pd.DataFrame
        Output of :func:`_build_summary_table`.

    Returns
    -------
    pandas.io.formats.style.Styler
        Styled table.
    """
    green, red = '#1e7e34', '#c82333'
    _conf_colors = {
        'High': green, 'Medium': '#b8860b', 'Low': '#d2691e',
        'No edge': red, 'No data': '#6c757d', 'N/A': '#6c757d',
    }

    def _sign_color(v):
        if pd.isna(v):
            return ''
        return f"color: {green if v >= 0 else red}; font-weight: 600"

    grey = '#6c757d'

    def _sentiment_color(v):
        c = {'Bullish': green, 'Bearish': red}.get(v, grey)
        return f"color: {c}; font-weight: 600"

    def _arrow_color(v):
        c = {'▲': green, '▼': red}.get(v, grey)
        return f"color: {c}; font-weight: 600"

    def _conf_color(v):
        return f"color: {_conf_colors.get(v, '#6c757d')}; font-weight: 600"

    styler = (
        summary_df.style
        .map(_sign_color, subset=['Change (₹)', 'Signal Score (%)', 'Conviction'])
        .map(_sentiment_color, subset=['Sentiment'])
        .map(_arrow_color, subset=['Direction'])
        .format({
            'Predicted Price': '₹{:,.2f}',
            'Change (₹)': '{:+,.2f}',
            'Signal Score (%)': '{:+.2f}%',
            'Conviction': '{:+.2f}',
        }, na_rep='—')
    )
    if 'Confidence' in summary_df.columns:
        styler = styler.map(_conf_color, subset=['Confidence'])
    if 'Basis' in summary_df.columns:
        styler = styler.map(
            lambda v: f"color: {grey}; font-style: italic", subset=['Basis'])
    return styler


# -----------------------------------------------------------------------------
# 6. SESSION STATE & CALLBACKS
# -----------------------------------------------------------------------------

if 'submitted' not in st.session_state:
    st.session_state['submitted'] = False


def reset_callback():
    """
    Reset all sidebar controls and session state to defaults.

    Clears the submitted flag, resets company selection to the first
    available, frequency to '1 Day', horizon to 3, and re-selects all models.
    """
    st.session_state['submitted'] = False
    companies = get_available_companies()
    if companies:
        st.session_state['sb_company'] = companies[0]
    st.session_state['sb_freq'] = '1 Day'
    st.session_state['sb_period'] = 3
    st.session_state['sb_models'] = list(MODEL_NAMES)
    st.session_state['sb_assess'] = True


def submit_callback():
    """
    Mark the form submitted and snapshot the current sidebar selections.

    Snapshotting the parameters (rather than reading the live widgets in the
    main panel) means that fiddling with a control *after* submitting does not
    silently recompute results on the changed parameters — results only update
    on the next explicit Submit.
    """
    st.session_state['submitted'] = True
    st.session_state['run_company'] = st.session_state.get('sb_company')
    st.session_state['run_freq'] = st.session_state.get('sb_freq', '1 Day')
    st.session_state['run_period'] = st.session_state.get('sb_period', 3)
    st.session_state['run_models'] = list(
        st.session_state.get('sb_models', MODEL_NAMES)
    )
    st.session_state['run_assess'] = st.session_state.get('sb_assess', True)


# -----------------------------------------------------------------------------
# 7. SIDEBAR UI
# -----------------------------------------------------------------------------

local_css()

st.sidebar.image("./UI asset/logo_1.png", width='stretch')
st.sidebar.title("Configuration")
st.sidebar.caption(f"⚙️ Compute: **{compute_device_label()}** "
                   "(deep models & Chronos auto-use GPU when available)")

company_options = get_available_companies()
selected_company = st.sidebar.selectbox(
    "Search Company", options=company_options, key='sb_company',
)

selected_freq = st.sidebar.radio(
    "Select Frequency", options=['1 Day', '1 Hour'], key='sb_freq',
)

# The horizon is chosen in **trading days** for both frequencies. For daily the
# value is the number of session days (= forecast steps); for hourly it is
# converted to session bars (days × ~7) internally — so the option *values* are
# the actual step counts the models forecast, while the labels read in days.
_B = NSE_BARS_PER_SESSION   # 7 hourly bars per NSE session
horizon_label = "Forecast Horizon (Trading Days)"
if selected_freq == '1 Day':
    horizon_options = [3, 5, 7, 9, 11, 13]                 # days = steps
    horizon_fmt = lambda d: f"{d} days"
    horizon_help = ("Number of future NSE trading days to forecast (weekends and "
                    "exchange holidays are skipped).")
else:
    horizon_options = [1 * _B, 2 * _B, 3 * _B, 5 * _B]     # hourly bars = steps
    horizon_fmt = lambda b: (f"{b // _B} day{'s' if b // _B > 1 else ''} "
                             f"({b} hourly bars)")
    horizon_help = ("Chosen in trading days; each NSE session has ~7 hourly bars "
                    "(09:15-15:30), so the model forecasts days × 7 bars. "
                    "Weekends and exchange holidays are skipped.")

# Keep the persisted selection valid when the option set changes (freq toggled),
# since the two frequencies expose different value sets under one widget key.
if st.session_state.get('sb_period') not in horizon_options:
    st.session_state['sb_period'] = horizon_options[1]

selected_period = st.sidebar.selectbox(
    horizon_label, options=horizon_options, key='sb_period',
    format_func=horizon_fmt, help=horizon_help,
)

selected_models = st.sidebar.multiselect(
    "Models to run",
    options=MODEL_NAMES,
    default=MODEL_NAMES,
    key='sb_models',
    help="Running all models can take several minutes (the neural nets are "
         "slow). Deselect models you don't need for a faster run.",
)
st.sidebar.caption(f"{len(selected_models)} of {len(MODEL_NAMES)} models selected")

assess_confidence = st.sidebar.checkbox(
    "Assess forecast confidence",
    value=True,
    key='sb_assess',
    help="Runs a quick walk-forward backtest per model to check whether it "
         "actually beats a random-walk baseline here, and labels each forecast "
         "High / Medium / Low / No edge. Adds time on the first run for a "
         "ticker/horizon (results are cached). Turn off for a faster run.",
)

st.sidebar.markdown("---")

col_btn1, col_btn2 = st.sidebar.columns(2)
with col_btn1:
    st.button(
        "Submit", on_click=submit_callback,
        width='stretch', type="primary",
    )
with col_btn2:
    st.button(
        "Reset", on_click=reset_callback,
        width='stretch', type="secondary",
    )

# -----------------------------------------------------------------------------
# 8. MAIN UI LAYOUT
# -----------------------------------------------------------------------------

st.title("Multi-Model Forecasting Results")

st.warning(
    "⚠️ **Caution:** These predictions are based on historical data "
    "patterns and mathematical models. They may not reflect real-world "
    "market volatility, news events, or economic changes. "
    "Use for educational purposes only."
)

if st.session_state['submitted']:

    # Use the parameters snapshotted at submit time (see submit_callback), not
    # the live sidebar widgets, so tweaking a control doesn't recompute results.
    run_company = st.session_state.get('run_company')
    run_freq = st.session_state.get('run_freq', '1 Day')
    run_period = st.session_state.get('run_period', 3)
    run_models = st.session_state.get('run_models', list(MODEL_NAMES))
    run_assess = st.session_state.get('run_assess', True)
    backend_interval = '1d' if run_freq == '1 Day' else '1h'

    if not run_models:
        st.warning("No models selected. Pick at least one model and Submit.")
    else:
        # Frame this Submit in the console so one run's per-model trace is
        # separable from the next in a long scroll.
        _t0 = _time.perf_counter()
        _console.run_header(run_company, backend_interval, run_period,
                            run_models,
                            timestamp=_dt.datetime.now().strftime("%H:%M:%S"))
        model_results = run_selected_models(
            run_company, run_freq, run_period, run_models,
        )

        if not model_results:
            st.warning("No models generated results successfully.")
        else:
            # Resolve the history sample and last actual price first, so the
            # data-quality gate can run *before* we trust any forecast.
            hist_sample = list(model_results.values())[0]['history']
            price_col_hist = get_col_by_candidates(
                hist_sample, ['adj_close', 'adj close', 'close', 'price'],
            )
            last_actual = (
                float(hist_sample[price_col_hist].iloc[-1])
                if price_col_hist else None
            )

            # Data-quality gate (reviewer request): score the input. Degraded
            # data withholds directional calls and steers the user to the risk
            # cone; broken data abstains. See data_quality.assess_data_quality.
            dq_report = assess_data_quality(
                hist_sample, backend_interval, run_period)
            dq_degraded = dq_report.mode in ('risk_cone_only', 'abstain')

            # Confidence gate: assess each model's recent walk-forward skill.
            conf_map = {}
            if run_assess:
                assessed = list(model_results.keys())
                cbar = st.progress(
                    0.0, text="Assessing forecast confidence (walk-forward)...")
                for j, mname in enumerate(assessed):
                    try:
                        conf_map[mname] = _model_confidence(
                            run_company, backend_interval, run_period, mname,
                            USE_MARKET_CONTEXT,
                        )
                    except Exception as exc:
                        conf_map[mname] = {'bucket': 'N/A',
                                           'note': str(exc)[:80]}
                    cbar.progress((j + 1) / len(assessed),
                                  text=f"Assessed {mname} ({j + 1}/{len(assessed)})")
                cbar.empty()

                # Show the aggregate skill banner only when the data itself is
                # trustworthy; on degraded data the data-quality banner carries
                # the message and a positive skill banner would contradict it.
                if not dq_degraded:
                    banner = _honesty_banner(conf_map)
                    if banner:
                        getattr(st, banner[0])(banner[1])

            # On degraded data, withhold every directional call by forcing the
            # gate bucket to "No edge" (pure rule in gating.apply_data_quality_gate,
            # unit-tested) — reuses the abstention gating even if assessment is off.
            conf_map = _apply_dq_gate(conf_map, list(model_results), dq_degraded)

            # Regime-novelty gate: if the current market window is off-manifold
            # relative to what the models were fitted on, every model's
            # backtest-derived bucket is an extrapolation, so an
            # "unprecedented" verdict withholds the directional call the same
            # way degraded data does. An "unusual" verdict only annotates the
            # Basis column — 95th-percentile windows are a normal monthly event
            # in fat-tailed data, so gating on them would abstain far too often.
            novelty = {'available': False, 'verdict': 'unknown'}
            if USE_REGIME_NOVELTY:
                with st.spinner("Checking market-regime novelty..."):
                    novelty = _regime_novelty(
                        run_company, backend_interval, USE_MARKET_CONTEXT)
                conf_map = _apply_novelty_gate(
                    conf_map, list(model_results), novelty)

            # ── Forward prediction log ──────────────────────────────────
            # Written AFTER the gates so each row carries the verdicts that were
            # in force when it was served — which is what makes it possible to
            # ask later whether the GATES worked, not just whether the numbers
            # were close. Never raises; a log failure is not a forecast failure.
            _n_logged = 0
            if USE_PREDICTION_LOG and last_actual is not None:
                import uuid as _uuid
                _run_id = _uuid.uuid4().hex[:12]
                for _mname, _mdata in model_results.items():
                    try:
                        _pred = _mdata['prediction']
                        _hist = _mdata['history']
                        _origin = pd.to_datetime(_hist['datetime']).max()
                        _plog.log_forecast(
                            ticker=run_company, interval=backend_interval,
                            horizon=run_period, model=_mname,
                            prediction_df=_pred, anchor_price=float(last_actual),
                            origin_datetime=_origin,
                            confidence_bucket=conf_map.get(_mname, {}).get('bucket'),
                            dq_mode=dq_report.mode,
                            novelty_verdict=novelty.get('verdict'),
                            seed=GLOBAL_SEED, run_id=_run_id)
                        _n_logged += 1
                    except Exception as _log_exc:
                        _console.note("log", f"skipped {_mname} ({_log_exc})")

            if last_actual is not None:
                summary_df = _build_summary_table(
                    model_results, last_actual, conf_map)
                if summary_df is not None:
                    # Hourly horizon is chosen in trading days but counted in
                    # bars internally (~7 bars/session); label it in both.
                    if run_freq == '1 Day':
                        period_label = f"{run_period} trading days"
                    else:
                        _days = max(1, run_period // 7)
                        period_label = (f"{_days} trading day"
                                        f"{'s' if _days > 1 else ''} "
                                        f"({run_period} hourly bars)")

                    # Insert the Confidence bucket + a plain-language reason code
                    # (before Direction) when assessed. The reason ties the label
                    # to the DM test / coverage / data-quality, so no row is ever
                    # presented as a bare (or implied "best") winner.
                    if conf_map:
                        loc = summary_df.columns.get_loc('Direction')
                        summary_df.insert(
                            loc, 'Basis',
                            summary_df['Model'].map(
                                lambda m: _confidence_reason(conf_map.get(m, {}))
                            ),
                        )
                        summary_df.insert(
                            loc, 'Confidence',
                            summary_df['Model'].map(
                                lambda m: conf_map.get(m, {}).get('bucket', '—')
                            ),
                        )

                    st.markdown("### Model Comparison")

                    # Data-quality gate banner first — if the input is degraded
                    # the directional calls below are already withheld.
                    _render_data_quality(dq_report)

                    # Audit: how were these ₹ prices converted? (period-accurate
                    # historical vs degraded live-uniform vs unconverted) and how
                    # much history is available (hourly ~730-day cap).
                    _render_fx_notice(hist_sample)
                    _render_history_notice(hist_sample)

                    # Reproducibility manifest — seed + versions + params, so any
                    # forecast shown here can be reproduced and traced.
                    _hist_info = getattr(hist_sample, 'attrs', {}).get('history', {})
                    # Architectures: each deep model records what it actually
                    # built on its prediction frame's attrs (see
                    # architectures.attach). Lifting them here closes a hole in
                    # the reproducibility claim — the manifest pinned the seed
                    # and package versions but not the network shape, so it
                    # could not in fact reproduce a deep fit.
                    _archs = {}
                    for _mname, _mdata in model_results.items():
                        _a = getattr(_mdata['prediction'], 'attrs', {}).get(
                            'architecture')
                        if _a:
                            _archs[_mname] = _a
                    _manifest = run_manifest(
                        ticker=run_company, interval=backend_interval,
                        horizon=run_period, seed=GLOBAL_SEED,
                        fetched_at=_hist_info.get('end'),
                        training_rows=int(len(hist_sample)),
                        models=list(model_results.keys()),
                        architectures=_arch.manifest_block(_archs),
                        architecture_overrides=_arch.OVERRIDDEN,
                    )
                    with st.expander("🔬 Run details (reproducibility)"):
                        st.caption(
                            f"Seed **{_manifest['seed']}** · Python "
                            f"{_manifest['python']} · {_manifest['training_rows']} "
                            f"training rows · data through {_manifest['fetched_at']} "
                            f"· run {_manifest['run_at_utc'][:19]}Z"
                        )
                        st.json(_manifest, expanded=False)

                    # Consensus view — the collective read across models.
                    cons = _build_consensus(summary_df)

                    # ── Console mirror of the decision layer ────────────────
                    # Everything below was previously browser-only: someone
                    # watching cmd saw 19 models announce "Prediction Complete"
                    # and could not tell whether a single one had beaten a
                    # random walk. Rendered from the same conf_map, the same
                    # _honesty_banner and the same _confidence_reason the UI
                    # uses, so the console cannot claim something the page
                    # doesn't. _honesty_banner is re-read here (rather than
                    # reusing the one rendered above) because it must reflect
                    # the buckets AFTER the data-quality and novelty gates.
                    _cbanner = _honesty_banner(conf_map)
                    _console.run_summary(
                        ticker=run_company, interval=backend_interval,
                        horizon=run_period,
                        dq_mode=dq_report.mode, dq_score=dq_report.score,
                        conf_rows=[
                            (m, conf_map.get(m, {}).get('bucket', '—'),
                             _confidence_reason(conf_map.get(m)))
                            for m in summary_df['Model']
                        ] if conf_map else [],
                        consensus=cons,
                        verdict=_console.strip_markdown(
                            _cbanner[1] if _cbanner else ''),
                        novelty_verdict=(novelty.get('verdict')
                                         if USE_REGIME_NOVELTY else None),
                        log_path=_plog.LOG_FILE if _n_logged else None,
                        n_logged=_n_logged,
                        elapsed=_time.perf_counter() - _t0,
                    )
                    m1, m2, m3, m4 = st.columns(4)
                    m1.metric("Last Actual Price", f"₹{last_actual:,.2f}")
                    m2.metric(
                        f"Median Forecast ({period_label})",
                        f"₹{cons['median_price']:,.2f}",
                        f"{cons['median_pct']:+.2f}%",
                    )
                    m3.metric("Models Bullish",
                              f"{cons['n_up']} / {cons['n_models']}")
                    m4.metric("Models Bearish",
                              f"{cons['n_down']} / {cons['n_models']}")
                    if cons.get('n_noedge', 0) > 0:
                        st.caption(
                            f"↳ **{cons['n_noedge']} / {cons['n_models']}** "
                            "model(s) showed **no edge** over a random walk in "
                            "the confidence check, so their directional call is "
                            "withheld (shown as “No edge / –”) rather than "
                            "asserting a Bullish/Bearish view the evidence "
                            "doesn’t support."
                        )

                    st.dataframe(
                        _style_summary(summary_df),
                        hide_index=True,
                        width='stretch',
                    )
                    # Standing data-snooping disclaimer: operationalize the
                    # project's Reality-Check / SPA finding so the table is never
                    # read as crowning a "best" model. The lowest-RMSE row is not
                    # a confirmed winner once you correct for trying many models.
                    st.info(
                        "🎯 **This is a risk instrument, not an oracle.** Ranking "
                        "models by forecast or backtest RMSE does **not** identify "
                        "a truly superior model here: across the full set, "
                        "data-snooping-robust tests (White's Reality Check & "
                        "Hansen's SPA) found **no selection-bias-free edge over a "
                        "random walk** at these horizons. So read the **Confidence** "
                        "and **Basis** columns, not the row order — and treat the "
                        "**calibrated range / risk cone** as the deliverable, not "
                        "the point forecast."
                    )
                    st.caption(
                        "- **Signal Score (%)** is each model's forecasted "
                        "percentage change from the last actual price to the "
                        f"end of the {period_label} horizon — the "
                        "value the call is based on.\n"
                        "- **Sentiment** is "
                        "**Bullish** when the Signal Score is ≥ 0% and "
                        "**Bearish** when it is < 0% — but is shown as "
                        "**“No edge”** (with a “–” Direction) whenever the "
                        "confidence check finds the model no better than a "
                        "random walk, so no direction is asserted on noise.\n"
                        "- **Conviction** is the "
                        "forecast move divided by half the model's own 95% "
                        "interval width: it has the same sign as the move, and "
                        "**|Conviction| ≥ 1** means the move is larger than the "
                        "model's uncertainty (the current price falls outside "
                        "the 95% band) — a higher-conviction call. The further "
                        "from 0, the stronger the signal; values near 0 are "
                        "within noise. (Shown as “—” for models with no interval.)"
                    )
                    if conf_map:
                        st.caption(
                            "**Confidence** comes from a quick walk-forward "
                            "backtest on recent history:\n"
                            "- **High** — clearly beats the random walk with a "
                            "significant Diebold-Mariano test and sound coverage.\n"
                            "- **Medium** — a modest, weakly-significant edge.\n"
                            "- **Low** — better than the walk but within noise.\n"
                            "- **No edge** — no better than simply assuming the "
                            "price stays put.\n\n"
                            "For Low / No-edge rows, trust the **range**, not the "
                            "point forecast."
                        )
                    st.info(
                        "These are statistical forecasts conditioned on past "
                        "prices — read them as a **distribution of plausible "
                        "outcomes** (the shaded 95% band on each chart, and the "
                        "range around the median), not a precise prediction. "
                        "The grey dotted line on each chart is the naive "
                        "random-walk baseline for reference."
                    )
                    st.divider()

                    # ── Risk & Probability (distribution-first headline) ──────
                    st.markdown(f"### Risk & Probability "
                                f"(next {period_label})")
                    thr = st.number_input(
                        "Move threshold for probabilities (%)",
                        min_value=0.5, max_value=25.0, value=2.0, step=0.5,
                        help="Used for P(gain >) and P(loss >) below.",
                    )
                    risk = build_risk_panel(model_results, last_actual, thr)
                    if risk is None:
                        st.caption("No model emitted an interval, so probability "
                                   "estimates are unavailable for this run.")
                    else:
                        r1, r2, r3, r4 = st.columns(4)
                        r1.metric("P(price up)", f"{risk['p_up'] * 100:.0f}%")
                        r2.metric(f"P(gain > +{thr:.1f}%)",
                                  f"{risk['p_gain'] * 100:.0f}%")
                        r3.metric(f"P(loss > {thr:.1f}%)",
                                  f"{risk['p_loss'] * 100:.0f}%")
                        r4.metric("95% downside (VaR)",
                                  f"₹{risk['var5_price']:,.2f}",
                                  f"{risk['var5_pct'] * 100:+.1f}%")
                        st.markdown(
                            f"**Likely range (95%):** ₹{risk['range_low']:,.2f} "
                            f"– ₹{risk['range_high']:,.2f}"
                        )
                        # Downside-risk row (B2) — only on the empirical path,
                        # where the up/down asymmetry is a real read of the
                        # fat-tailed distribution rather than a symmetric Gaussian.
                        if risk.get('method') == 'empirical' and 'cvar5_price' in risk:
                            d1, d2, d3, d4 = st.columns(4)
                            d1.metric("Expected shortfall (worst 5%)",
                                      f"₹{risk['cvar5_price']:,.2f}",
                                      f"{risk['cvar5_pct'] * 100:+.1f}%")
                            d2.metric("Downside vol",
                                      f"{risk['down_semidev'] * 100:.1f}%")
                            d3.metric("Upside vol",
                                      f"{risk['up_semidev'] * 100:.1f}%")
                            skew = risk.get('vol_skew', float('nan'))
                            d4.metric("Vol skew (down/up)",
                                      "—" if skew != skew else f"{skew:.2f}",
                                      help="> 1 means the downside is the fatter "
                                           "side of the outcome distribution.")
                        if risk.get('method') == 'empirical':
                            src = ", ".join(risk.get('source_models', [])) or "HAR-RV"
                            st.caption(
                                "Probabilities are counted **directly off the "
                                "empirical, fat-tailed return distribution** from "
                                f"the conformal volatility model ({src}) — no "
                                "normal-distribution assumption, so the tail risk "
                                "the model estimated is preserved. **95% downside "
                                "(VaR)** is the empirical 5th-percentile price — a "
                                "worst-case-but-not-extreme reference; **expected "
                                "shortfall** is the *average* outcome in that worst "
                                "5%, and **downside / upside vol** split the "
                                "distribution's dispersion (their ratio, **vol "
                                "skew**, exceeds 1 when the downside is the fatter "
                                "side). Probabilities reflect model uncertainty, not "
                                "real-world certainty."
                            )
                        else:
                            st.caption(
                                f"⚠️ Approximate read across {risk['n_used']} "
                                "models: no fat-tailed volatility model (e.g. "
                                "**HAR-RV**) was in this run, so each model's 95% "
                                "band is approximated as a **log-normal** "
                                "distribution and the median probability is shown. "
                                "Add **HAR-RV** to the selection for the exact, "
                                "fat-tailed empirical read. **95% downside (VaR)** "
                                "is the 5th-percentile price. Probabilities "
                                "reflect model uncertainty, not certainty."
                            )
                    st.divider()

            for model_name, data in model_results.items():

                st.markdown(f"### Model: {model_name}")

                hist_df = data['history']
                pred_df = data['prediction']

                c1, c2 = st.columns([2, 3])

                with c1:
                    st.markdown("**Predicted Values**")
                    # Size the table to exactly the forecast rows (one per selected
                    # day/bar) so there are no empty filler rows; cap so a long
                    # hourly horizon scrolls instead of dominating the page.
                    _n_rows = len(pred_df)
                    _tbl_height = min(600, (_n_rows + 1) * 35 + 3)
                    st.dataframe(pred_df, height=_tbl_height, width='stretch')

                with c2:
                    try:
                        fig = plot_predictions_with_history(
                            original_df=hist_df,
                            prediction_df=pred_df,
                            company_name=run_company,
                            interval=run_freq,
                            lookback=50,
                        )
                        st.plotly_chart(
                            fig, key=f"chart_{model_name}", width='stretch',
                        )
                    except Exception as e:
                        st.error(f"Error plotting graph for {model_name}: {e}")

                st.divider()

else:
    st.info("Select parameters and click Submit to generate forecasts.")
