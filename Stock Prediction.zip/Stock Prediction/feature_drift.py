"""
Feature-distribution drift: has the *input* moved, not just the output?

The gap this fills
------------------
``prediction_log.drift_report`` monitors **outcome** drift — live interval
coverage against the nominal 95%, binomial-CI-gated. That is the right headline,
because coverage is the claim the product actually makes. But it is a *lagging*
indicator: it can only fire once enough forecasts have matured, which at a
5-day horizon means weeks.

Feature drift is the *leading* indicator. Klaas, Ch. 8:

    "Over time, you should recalculate your feature distribution and adjust your
     scaling."

If the inputs have moved away from what a model was fitted on, its predictions
are extrapolations regardless of how its last few intervals happened to land.
This module measures that directly, on the features themselves.

Why a permutation test rather than a fixed threshold
-----------------------------------------------------
The conventional Population Stability Index thresholds — 0.10 "moderate", 0.25
"significant" — are folklore, and worse, **PSI is biased upward on small
samples**. Two random halves of the *same* distribution will show a non-zero PSI
purely from binning noise, and the smaller the sample the larger that floor.
Applying a fixed cut-off therefore fires constantly on short windows, which is
how monitoring gets switched off.

So the significance of an observed PSI is established by **permutation**: pool
the reference and current samples, reshuffle the labels many times, and recompute
PSI. That gives the distribution of PSI under "no drift" *at these exact sample
sizes and this exact binning*, and a feature is flagged only when it exceeds it.
Same discipline as the binomial-CI gate in ``prediction_log``: an alert that
fires on noise teaches people to ignore alerts.

The fixed thresholds are still reported alongside, because they are what a risk
function will ask for — but the permutation verdict is the one to act on.
"""

import numpy as np
import pandas as pd

_EPS = 1e-12

# Conventional PSI bands, reported for familiarity. Not used for the verdict:
# see the module docstring on why a fixed cut-off misfires on small samples.
PSI_MODERATE = 0.10
PSI_SIGNIFICANT = 0.25

# Below this many observations on either side, binning noise dominates and no
# verdict is issued at all. Reporting "insufficient data" beats reporting a
# number that is mostly an artefact of the sample size.
MIN_SAMPLES = 100


def _bin_edges(reference, bins):
    """
    Quantile edges from the REFERENCE only.

    Deliberately not from the pooled sample: the reference is what the model was
    fitted on, so it defines the bins the comparison is made in. Deriving edges
    from the pooled data would let the current window move the yardstick it is
    being measured against.
    """
    ref = np.asarray(reference, dtype=float)
    ref = ref[np.isfinite(ref)]
    if len(ref) == 0:
        return None
    qs = np.linspace(0, 100, bins + 1)
    edges = np.unique(np.percentile(ref, qs))
    if len(edges) < 3:
        return None                      # near-constant feature; no bins to make
    edges[0], edges[-1] = -np.inf, np.inf
    return edges


def psi(reference, current, bins=10, edges=None):
    """
    Population Stability Index between two samples of one feature.

    ``sum((a_i - e_i) * log(a_i / e_i))`` over quantile bins of the reference.
    Empty bins are floored rather than dropped, because dropping them silently
    understates drift exactly when a whole region of the distribution has
    emptied out — which is the case worth catching.
    """
    if edges is None:
        edges = _bin_edges(reference, bins)
    if edges is None:
        return float("nan")

    ref = np.asarray(reference, dtype=float)
    cur = np.asarray(current, dtype=float)
    ref, cur = ref[np.isfinite(ref)], cur[np.isfinite(cur)]
    if len(ref) == 0 or len(cur) == 0:
        return float("nan")

    e = np.histogram(ref, bins=edges)[0].astype(float) / len(ref)
    a = np.histogram(cur, bins=edges)[0].astype(float) / len(cur)
    floor = 1.0 / max(len(ref), len(cur), 1)
    e = np.maximum(e, floor)
    a = np.maximum(a, floor)
    return float(np.sum((a - e) * np.log(a / e)))


def ks_statistic(a, b):
    """
    Two-sample Kolmogorov-Smirnov statistic and asymptotic p-value.

    Closed-form Kolmogorov distribution rather than SciPy, consistent with
    ``var_models.py``'s chi-square tails: this project keeps its statistics
    dependency-free so a reader can check them.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    a, b = np.sort(a[np.isfinite(a)]), np.sort(b[np.isfinite(b)])
    n, m = len(a), len(b)
    if n < 2 or m < 2:
        return float("nan"), float("nan")

    grid = np.concatenate([a, b])
    cdf_a = np.searchsorted(a, grid, side="right") / n
    cdf_b = np.searchsorted(b, grid, side="right") / m
    d = float(np.max(np.abs(cdf_a - cdf_b)))

    en = np.sqrt(n * m / (n + m))
    lam = (en + 0.12 + 0.11 / en) * d
    if lam < _EPS:
        return d, 1.0
    # Q(lam) = 2 * sum_{j>=1} (-1)^(j-1) exp(-2 j^2 lam^2); converges fast.
    j = np.arange(1, 101)
    p = 2.0 * np.sum(((-1.0) ** (j - 1)) * np.exp(-2.0 * (j ** 2) * lam ** 2))
    return d, float(min(max(p, 0.0), 1.0))


def psi_null(reference, current, bins=10, n_perm=200, seed=42):
    """
    Distribution of PSI under "no drift", at these sample sizes.

    Pools both samples and reshuffles the labels, so the returned quantile is
    the PSI attributable to binning noise alone. Anything at or below it is not
    evidence of anything.
    """
    ref = np.asarray(reference, dtype=float)
    cur = np.asarray(current, dtype=float)
    ref, cur = ref[np.isfinite(ref)], cur[np.isfinite(cur)]
    if len(ref) < 2 or len(cur) < 2:
        return np.array([])

    pool = np.concatenate([ref, cur])
    n_ref = len(ref)
    rng = np.random.default_rng(seed)
    out = np.empty(n_perm)
    for i in range(n_perm):
        idx = rng.permutation(len(pool))
        a, b = pool[idx[:n_ref]], pool[idx[n_ref:]]
        out[i] = psi(a, b, bins=bins)
    return out[np.isfinite(out)]


def drift_table(reference, current, columns=None, bins=10, n_perm=200,
                alpha=0.05, seed=42):
    """
    Per-feature drift between a reference window and a current window.

    Parameters
    ----------
    reference, current : pandas.DataFrame
        The fitted-on window and the window being served, respectively.
    columns : list, optional
        Features to test; defaults to the shared numeric columns.

    Returns
    -------
    pandas.DataFrame
        One row per feature: ``psi``, ``psi_null_95`` (the permutation
        threshold), ``psi_p`` (share of permutations at least as extreme),
        ``ks``, ``ks_p``, ``conventional`` (the folklore band) and ``verdict``.
        ``verdict`` is DRIFT only when the permutation test rejects — the fixed
        bands are shown but never decide.
    """
    if columns is None:
        num = reference.select_dtypes(include=[np.number]).columns
        columns = [c for c in num if c in current.columns]

    rows = []
    for col in columns:
        ref = pd.to_numeric(reference[col], errors="coerce").dropna().values
        cur = pd.to_numeric(current[col], errors="coerce").dropna().values

        if len(ref) < MIN_SAMPLES or len(cur) < MIN_SAMPLES:
            rows.append({"feature": col, "n_ref": len(ref), "n_cur": len(cur),
                         "psi": float("nan"), "psi_null_95": float("nan"),
                         "psi_p": float("nan"), "ks": float("nan"),
                         "ks_p": float("nan"), "conventional": "n/a",
                         "verdict": "INSUFFICIENT DATA"})
            continue

        edges = _bin_edges(ref, bins)
        value = psi(ref, cur, bins=bins, edges=edges)
        null = psi_null(ref, cur, bins=bins, n_perm=n_perm, seed=seed)
        thresh = float(np.quantile(null, 1 - alpha)) if len(null) else float("nan")
        p_perm = (float(np.mean(null >= value)) if len(null) and
                  np.isfinite(value) else float("nan"))
        d, p_ks = ks_statistic(ref, cur)

        conventional = ("significant" if value >= PSI_SIGNIFICANT else
                        "moderate" if value >= PSI_MODERATE else "stable")
        drifted = np.isfinite(p_perm) and p_perm < alpha
        rows.append({
            "feature": col, "n_ref": len(ref), "n_cur": len(cur),
            "psi": round(value, 4) if np.isfinite(value) else float("nan"),
            "psi_null_95": round(thresh, 4) if np.isfinite(thresh) else float("nan"),
            "psi_p": round(p_perm, 4) if np.isfinite(p_perm) else float("nan"),
            "ks": round(d, 4) if np.isfinite(d) else float("nan"),
            "ks_p": round(p_ks, 4) if np.isfinite(p_ks) else float("nan"),
            "conventional": conventional,
            "verdict": "DRIFT" if drifted else "stable",
        })

    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("psi", ascending=False, na_position="last")
    return out.reset_index(drop=True)


def summarise(table, alpha=0.05):
    """
    Aggregate verdict, corrected for testing many features at once.

    Testing 40 features at alpha = 0.05 yields ~2 false positives by
    construction, so "some feature drifted" is not news. A Bonferroni-style
    floor is applied to the count that triggers the headline: the same
    multiple-testing discipline ``run_spa.py`` applies to model selection.
    """
    if table is None or table.empty:
        return {"n_features": 0, "n_drifted": 0, "verdict": "NO DATA",
                "expected_false_positives": 0.0, "drifted": []}

    testable = table[table["verdict"] != "INSUFFICIENT DATA"]
    n = int(len(testable))
    drifted = testable[testable["verdict"] == "DRIFT"]["feature"].tolist()
    expected_fp = alpha * n

    if n == 0:
        verdict = "NO DATA"
    elif len(drifted) == 0:
        verdict = "STABLE"
    elif len(drifted) <= expected_fp:
        verdict = "WITHIN NOISE"
    elif len(drifted) >= max(3, 0.25 * n):
        verdict = "WIDESPREAD DRIFT"
    else:
        verdict = "LOCALISED DRIFT"

    return {"n_features": n, "n_drifted": len(drifted), "verdict": verdict,
            "expected_false_positives": round(expected_fp, 2),
            "drifted": drifted}


def format_report(table, summary):
    """Plain-text report for the console and the validation drivers."""
    lines = ["=== Feature-distribution drift ===",
             f"  Features tested : {summary['n_features']}",
             f"  Flagged         : {summary['n_drifted']} "
             f"(expected by chance: {summary['expected_false_positives']})",
             f"  Verdict         : {summary['verdict']}"]
    if summary["drifted"]:
        lines.append(f"  Drifted         : {', '.join(summary['drifted'][:8])}"
                     + (" ..." if len(summary["drifted"]) > 8 else ""))
    if summary["verdict"] == "WITHIN NOISE":
        lines.append("  -> fewer flags than multiple testing predicts; not "
                     "evidence of drift.")
    elif summary["verdict"] == "WIDESPREAD DRIFT":
        lines.append("  -> the inputs have moved. Forecasts are extrapolations "
                     "until the models are refitted, whatever recent coverage "
                     "happens to show.")
    return "\n".join(lines)
