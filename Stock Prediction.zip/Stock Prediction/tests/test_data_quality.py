"""
Tests for data_quality.assess_data_quality / gate_action.

Each test builds a synthetic OHLCV frame, perturbs ONE dimension, and asserts the
right reason code fires and the serving mode degrades as intended. Pure (no
network). Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import data_quality as dq


def _clean_daily(n=400, end="2026-06-26", seed=1):
    """A clean daily OHLCV frame ending recently."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range(end=end, periods=n)
    price = 1000.0 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    df = pd.DataFrame({
        "datetime": days,
        "open": price * (1 + rng.normal(0, 0.001, n)),
        "high": price * (1 + np.abs(rng.normal(0, 0.003, n))),
        "low": price * (1 - np.abs(rng.normal(0, 0.003, n))),
        "close": price,
        "adj_close": price,
        "volume": rng.integers(1e5, 1e6, n).astype(float),
    })
    df.attrs["fx_conversion"] = {"method": "none", "source_currency": "INR"}
    return df


NOW = pd.Timestamp("2026-06-28")


def _codes(report):
    return {c["code"] for c in report.codes}


def test_clean_data_is_normal():
    r = dq.assess_data_quality(_clean_daily(), "1d", horizon=5, now=NOW)
    assert r.mode == "normal", (r.mode, _codes(r))
    assert r.tier == "good"
    assert r.score >= dq._GOOD_MIN


def test_insufficient_history_abstains():
    r = dq.assess_data_quality(_clean_daily(n=30), "1d", horizon=5, now=NOW)
    assert "INSUFFICIENT_HISTORY" in _codes(r)
    assert r.mode == "abstain"


def test_stale_data_abstains():
    df = _clean_daily(end="2026-05-01")        # ~8 weeks stale vs NOW
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "STALE_DATA" in _codes(r)
    assert r.mode == "abstain"


def test_unconverted_currency_abstains():
    df = _clean_daily()
    df.attrs["fx_conversion"] = {"method": "unconverted", "source_currency": "USD"}
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "CURRENCY_UNCONVERTED" in _codes(r)
    assert r.mode == "abstain"


def test_live_uniform_currency_warns():
    df = _clean_daily()
    df.attrs["fx_conversion"] = {"method": "live_uniform", "source_currency": "USD"}
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "FX_DEGRADED" in _codes(r)
    assert r.mode in ("warn", "normal")  # single warn shouldn't abstain


def test_heavy_zero_volume_drops_to_cone():
    df = _clean_daily()
    df.loc[df.index[: int(0.5 * len(df))], "volume"] = 0   # 50% zero-volume
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "ZERO_VOLUME" in _codes(r)
    assert r.mode == "risk_cone_only"        # critical but cone still possible


def test_duplicate_timestamps_flagged():
    df = _clean_daily()
    df.loc[df.index[-1], "datetime"] = df["datetime"].iloc[-2]
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "DUPLICATE_TIMESTAMPS" in _codes(r)


def test_bad_ohlc_flagged():
    df = _clean_daily()
    # Make 8% of bars have high < low.
    idx = df.index[: int(0.08 * len(df))]
    df.loc[idx, "high"] = df.loc[idx, "low"] * 0.5
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "BAD_OHLC" in _codes(r)


def test_abnormal_recent_jump_flagged():
    df = _clean_daily()
    df.loc[df.index[-2], "adj_close"] *= 1.30      # +30% spike near the end
    df.loc[df.index[-2], "close"] *= 1.30
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "ABNORMAL_GAP" in _codes(r)


def test_short_hourly_window_warns():
    rng = np.random.default_rng(3)
    n = 7 * 40                                   # 40 sessions only
    stamps = []
    d = pd.Timestamp("2026-05-01")
    while len([s for s in stamps]) < n:
        if d.dayofweek < 5:
            for h in range(9, 16):
                stamps.append(d + pd.Timedelta(hours=h, minutes=15))
        d += pd.Timedelta(days=1)
    stamps = stamps[:n]
    price = 1000.0 * np.exp(np.cumsum(rng.normal(0, 0.004, n)))
    df = pd.DataFrame({
        "datetime": stamps, "open": price, "high": price * 1.001,
        "low": price * 0.999, "close": price, "adj_close": price,
        "volume": rng.integers(1e3, 1e4, n).astype(float),
    })
    df.attrs["fx_conversion"] = {"method": "none"}
    r = dq.assess_data_quality(df, "1h", horizon=7, now=pd.Timestamp(stamps[-1]) + pd.Timedelta(hours=2))
    assert "SHORT_HOURLY_WINDOW" in _codes(r)


def test_abnormal_volume_is_event_risk():
    df = _clean_daily()
    df.loc[df.index[-1], "volume"] = df["volume"].iloc[-21:-1].median() * 10
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert "ABNORMAL_VOLUME" in _codes(r)
    assert r.event_risk is True
    assert r.mode == "risk_cone_only"            # event withholds direction


def test_abnormal_gap_is_event_risk_and_withholds():
    df = _clean_daily()
    df.loc[df.index[-2], "adj_close"] *= 1.30
    df.loc[df.index[-2], "close"] *= 1.30
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert r.event_risk is True
    assert r.mode == "risk_cone_only"
    act = dq.gate_action(r)
    assert "Event risk" in act["headline"]


def test_clean_data_no_event_risk():
    r = dq.assess_data_quality(_clean_daily(), "1d", horizon=5, now=NOW)
    assert r.event_risk is False


def test_gate_action_shapes():
    for mode_df, expect in [
        (_clean_daily(), "success"),
        (_clean_daily(n=30), "error"),
    ]:
        r = dq.assess_data_quality(mode_df, "1d", horizon=5, now=NOW)
        act = dq.gate_action(r)
        assert act["level"] == expect, (r.mode, act)
        assert "headline" in act


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1
            print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1
            print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All data-quality tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
