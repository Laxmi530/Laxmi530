"""
Tests for fundamentals.py — the point-in-time discipline, mostly.

The bug this module exists to prevent is a single line: joining
``Ticker.info`` (today's trailing P/E, today's margins) onto a historical panel.
Every row would then carry information that did not exist yet, and the resulting
classifier would look excellent. It is the most common flaw in public
"fundamentals + ML" stock projects, and it is invisible in every metric.

So the tests that matter here are not about ratio arithmetic. They are:
a look-ahead frame must be *refused*, features must be stamped by publication
date rather than period end, and the as-of join must never hand a row a
statement published after it.

No network: statement frames are constructed by hand, so these run offline and
deterministically.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fundamentals as fu


# ---------------------------------------------------------------------------
# to_float — the messy-input contract (in the spirit of the sample repo's tests)
# ---------------------------------------------------------------------------

def test_to_float_handles_the_shapes_statement_data_actually_arrives_in():
    assert fu.to_float(3) == 3.0
    assert fu.to_float(np.float64(2.5)) == 2.5
    assert fu.to_float("1234.5") == 1234.5
    assert fu.to_float("1,234.5") == 1234.5
    assert fu.to_float("-0.02") == -0.02
    assert fu.to_float(" 7 ") == 7.0


def test_to_float_returns_nan_rather_than_raising_on_junk():
    """
    A feature pipeline that raises on one bad cell loses the whole ticker.
    Every failure has to become NaN and be handled as missing downstream.
    """
    for junk in (None, "", "-", "N/A", "NaN", "None", "null", "abc",
                 float("inf"), float("nan"), object(), [1, 2]):
        assert not np.isfinite(fu.to_float(junk)), junk


def test_safe_div_guards_the_denominator():
    assert fu._safe_div(10, 4) == 2.5
    for bad in (0, 0.0, None, "N/A", float("nan")):
        assert not np.isfinite(fu._safe_div(10, bad)), bad
    assert not np.isfinite(fu._safe_div(None, 5))


# ---------------------------------------------------------------------------
# Publication dating — features must never be stamped by period end
# ---------------------------------------------------------------------------

def test_available_from_applies_the_publication_lag():
    """
    A quarter ending 31 March is not public on 31 March. Stamping features with
    the period end leaks up to a quarter of forward information.
    """
    q = fu.available_from("2025-03-31", quarterly=True)
    assert q == pd.Timestamp("2025-03-31") + pd.Timedelta(days=fu.PUBLICATION_LAG_DAYS)
    assert q > pd.Timestamp("2025-03-31")

    a = fu.available_from("2025-03-31", quarterly=False)
    assert a > q, "annual results are permitted a longer reporting window"


def test_available_from_tolerates_missing_dates():
    assert pd.isna(fu.available_from(pd.NaT))
    assert pd.isna(fu.available_from(None))


# ---------------------------------------------------------------------------
# Ratio derivation
# ---------------------------------------------------------------------------

def _statements(col="2025-03-31"):
    c = pd.Timestamp(col)
    income = pd.DataFrame({c: {
        "Total Revenue": 1000.0, "Gross Profit": 400.0,
        "Operating Income": 200.0, "Net Income": 120.0, "Diluted EPS": 6.0,
    }})
    balance = pd.DataFrame({c: {
        "Total Assets": 2000.0, "Total Debt": 500.0,
        "Stockholders Equity": 1000.0, "Current Assets": 800.0,
        "Current Liabilities": 400.0,
    }})
    return income, balance, c


def test_derive_ratios_computes_the_expected_values():
    income, balance, c = _statements()
    r = fu.derive_ratios(income, balance, c)
    assert r["f_gross_margin"] == pytest.approx(0.40)
    assert r["f_operating_margin"] == pytest.approx(0.20)
    assert r["f_net_margin"] == pytest.approx(0.12)
    assert r["f_roa"] == pytest.approx(0.06)
    assert r["f_roe"] == pytest.approx(0.12)
    assert r["f_debt_to_equity"] == pytest.approx(0.50)
    assert r["f_current_ratio"] == pytest.approx(2.0)
    assert r["f_asset_turnover"] == pytest.approx(0.50)
    assert r["f_eps"] == pytest.approx(6.0)


def test_derive_ratios_degrades_on_missing_line_items():
    """Coverage differs by ticker; a partial row is still worth having."""
    income, balance, c = _statements()
    income = income.drop(index="Gross Profit")
    balance = balance.drop(index="Total Debt")
    r = fu.derive_ratios(income, balance, c)
    assert not np.isfinite(r["f_gross_margin"])
    assert not np.isfinite(r["f_debt_to_equity"])
    assert r["f_net_margin"] == pytest.approx(0.12)   # unaffected


def test_derive_ratios_on_empty_frames_is_all_nan():
    r = fu.derive_ratios(pd.DataFrame(), pd.DataFrame(), pd.Timestamp("2025-03-31"))
    assert all(not np.isfinite(v) for v in r.values())


# ---------------------------------------------------------------------------
# THE leak guard
# ---------------------------------------------------------------------------

def _pit_frame():
    """A minimal point-in-time fundamentals frame for two tickers."""
    rows = []
    for tk, per in [("A", "2024-03-31"), ("A", "2024-09-30"), ("B", "2024-03-31")]:
        rows.append({"ticker": tk, "period_end": pd.Timestamp(per),
                     "available_from": fu.available_from(per),
                     **{c: 1.0 for c in fu.FUNDAMENTAL_COLS}})
    df = pd.DataFrame(rows)
    df.attrs["point_in_time"] = True
    return df


def test_as_of_join_refuses_a_non_point_in_time_frame():
    """
    The single most important test in this file. ``Ticker.info`` holds TODAY's
    values; joining it to a 2019 row is look-ahead that no metric would reveal.
    Refusing beats warning — a warning in a log is not a defence.
    """
    panel = pd.DataFrame({"ticker": ["A"], "datetime": [pd.Timestamp("2019-01-02")]})
    snapshot = pd.DataFrame([{"ticker": "A", "trailing_pe": 20.0}])
    snapshot.attrs["point_in_time"] = False

    with pytest.raises(ValueError, match="point-in-time"):
        fu.as_of_join(panel, snapshot)


def test_as_of_join_never_shows_a_row_a_future_statement():
    """
    A panel row dated before a statement's publication must get NaN, not the
    statement. This is the property the whole module is built to guarantee.
    """
    fund = _pit_frame()
    pub = fund.loc[fund["ticker"] == "A", "available_from"].min()

    panel = pd.DataFrame({
        "ticker": ["A", "A", "A"],
        "datetime": [pub - pd.Timedelta(days=1), pub, pub + pd.Timedelta(days=30)],
    })
    out = fu.as_of_join(panel, fund).sort_values("datetime")

    vals = out["f_net_margin"].tolist()
    assert not np.isfinite(vals[0]), "row before publication received a statement"
    assert np.isfinite(vals[1]), "row on the publication date should see it"
    assert np.isfinite(vals[2])


def test_as_of_join_does_not_bleed_across_tickers():
    """B has no statement of its own before its date; it must not inherit A's."""
    fund = _pit_frame()
    early = fu.available_from("2024-03-31") - pd.Timedelta(days=5)
    panel = pd.DataFrame({"ticker": ["A", "B"], "datetime": [early, early]})
    out = fu.as_of_join(panel, fund)
    assert out["f_roe"].isna().all()


def test_as_of_join_picks_the_most_recent_published_statement():
    fund = _pit_frame().copy()
    fund.loc[fund["period_end"] == pd.Timestamp("2024-09-30"), "f_roe"] = 9.0
    late = fu.available_from("2024-09-30") + pd.Timedelta(days=1)
    panel = pd.DataFrame({"ticker": ["A"], "datetime": [late]})
    out = fu.as_of_join(panel, fund)
    assert out["f_roe"].iloc[0] == pytest.approx(9.0)


def test_as_of_join_on_empty_fundamentals_returns_the_panel_unchanged():
    panel = pd.DataFrame({"ticker": ["A"], "datetime": [pd.Timestamp("2020-01-01")]})
    out = fu.as_of_join(panel, pd.DataFrame())
    assert len(out) == 1
    assert list(out.columns) == ["ticker", "datetime"]


def test_current_snapshot_is_tagged_unsafe_by_construction():
    """
    Not a network test — just that the contract is declared on the function,
    so the refusal in as_of_join has something to fire on.
    """
    import inspect
    src = inspect.getsource(fu.current_snapshot)
    assert 'attrs["point_in_time"] = False' in src


def test_fundamental_history_declares_itself_point_in_time():
    import inspect
    src = inspect.getsource(fu.fundamental_history)
    assert 'attrs["point_in_time"] = True' in src
    assert "available_from" in src
