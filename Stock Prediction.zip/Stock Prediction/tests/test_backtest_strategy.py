"""
Tests for the economic-evaluation wiring inside ``backtest.walk_forward_backtest``.

Uses trivial injected ``predict_fn``s with known behaviour (a perfect oracle, a
flat random walk, an always-wrong contrarian) so the strategy block's arithmetic
and its overlap caveat can be verified exactly, with no model or network in the
loop.

Network-free, TensorFlow-free and deterministic. Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import backtest as bt


HORIZON = 5
N = 600


def _df(seed=3):
    rng = np.random.default_rng(seed)
    price = 1000 * np.exp(np.cumsum(rng.normal(0.0003, 0.014, N)))
    return pd.DataFrame({
        "datetime": pd.bdate_range("2021-01-04", periods=N),
        "open": price, "high": price * 1.01, "low": price * 0.99,
        "close": price, "adj_close": price,
        "volume": rng.integers(1e5, 1e6, N),
    })


# The full frame is captured so an "oracle" can look up the realised future —
# legitimate only because this is a test fixture probing the harness arithmetic.
_FULL = _df()


def _flat_fn(train_df, interval, horizon, **kw):
    """Random walk: hold the last price. Zero predicted move at every step."""
    last = float(train_df["adj_close"].iloc[-1])
    return pd.DataFrame({
        "datetime": pd.bdate_range(train_df["datetime"].iloc[-1],
                                   periods=horizon + 1)[1:],
        "predicted_price": [last] * horizon,
    })


def _oracle_fn(train_df, interval, horizon, **kw):
    """Perfect foresight: return the actual future path."""
    o = len(train_df)
    future = _FULL["adj_close"].values[o:o + horizon]
    return pd.DataFrame({
        "datetime": _FULL["datetime"].values[o:o + horizon],
        "predicted_price": future,
    })


def _contrarian_fn(train_df, interval, horizon, **kw):
    """Perfectly wrong: mirror the realised move around the anchor."""
    o = len(train_df)
    anchor = float(_FULL["adj_close"].values[o - 1])
    future = _FULL["adj_close"].values[o:o + horizon]
    return pd.DataFrame({
        "datetime": _FULL["datetime"].values[o:o + horizon],
        "predicted_price": anchor * (anchor / np.asarray(future, dtype=float)),
    })


# ── Signals collection ─────────────────────────────────────────────────────
def test_signals_are_collected_and_anchored():
    res = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=5,
                                   min_train=300, verbose=False)
    sig = res["signals"]
    assert len(sig) == len(res["origins"])
    assert set(sig.columns) == {"origin", "datetime", "anchor",
                                "pred_return", "real_return"}
    # The flat model claims no move, so every predicted return is exactly 0.
    assert np.allclose(sig["pred_return"].values, 0.0)
    # The anchor is the bar BEFORE the origin index.
    for _, row in sig.iterrows():
        expected = float(_FULL["adj_close"].iloc[int(row["origin"]) - 1])
        assert np.isclose(row["anchor"], expected)
    # And the realised return matches log(price[origin+h-1]/anchor).
    row = sig.iloc[0]
    o = int(row["origin"])
    expected = np.log(_FULL["adj_close"].iloc[o + HORIZON - 1] / row["anchor"])
    assert np.isclose(row["real_return"], expected)


def test_strategy_block_present_and_shaped():
    res = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON, n_splits=6,
                                   min_train=300, verbose=False)
    s = res["strategy"]
    assert s["n_periods"] == len(res["signals"])
    for key in ("sharpe", "sortino", "information_ratio", "max_drawdown",
                "information_coefficient", "total_return",
                "benchmark_total_return", "origin_spacing"):
        assert key in s


# ── Known-behaviour models ─────────────────────────────────────────────────
def test_oracle_makes_money_and_contrarian_loses():
    good = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON,
                                    n_splits=6, min_train=300, verbose=False,
                                    cost_bps=0.0)["strategy"]
    bad = bt.walk_forward_backtest(_FULL, _contrarian_fn, "1d", HORIZON,
                                   n_splits=6, min_train=300, verbose=False,
                                   cost_bps=0.0)["strategy"]
    assert good["total_return"] > 0 > bad["total_return"]
    assert np.isclose(good["directional_hit_rate"], 1.0)
    assert np.isclose(bad["directional_hit_rate"], 0.0)
    assert good["information_coefficient"] > 0 > bad["information_coefficient"]


def test_flat_forecast_takes_no_informative_position():
    s = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=6,
                                 min_train=300, verbose=False,
                                 cost_bps=0.0)["strategy"]
    # A zero predicted move has sign 0 -> flat, so no P&L and no drawdown.
    assert np.allclose(s["positions"], 0.0)
    assert np.isclose(s["total_return"], 0.0)
    assert np.isnan(s["information_coefficient"])   # constant forecast


def test_deadband_mode_is_honoured():
    # Every |predicted move| is 0, so a deadband cannot possibly trade.
    s = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON, n_splits=6,
                                 min_train=300, verbose=False,
                                 position_mode="deadband")["strategy"]
    assert s["position_mode"] == "deadband"


def test_costs_are_charged_on_position_changes():
    free = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON,
                                    n_splits=6, min_train=300, verbose=False,
                                    cost_bps=0.0)["strategy"]
    paid = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON,
                                    n_splits=6, min_train=300, verbose=False,
                                    cost_bps=100.0)["strategy"]
    assert paid["total_cost"] > 0
    assert paid["total_return"] < free["total_return"]
    assert np.isclose(paid["gross_total_return"], free["gross_total_return"])


# ── Guardrails ─────────────────────────────────────────────────────────────
def test_overlapping_origins_are_flagged():
    # Many splits over a short span => spacing < horizon => overlapping trades.
    res = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=60,
                                   min_train=550, verbose=False)
    s = res["strategy"]
    assert s["origin_spacing"] < HORIZON
    assert s["overlapping_origins"] is True
    assert "overlap" in s["caveat"]


def test_non_overlapping_origins_have_no_caveat():
    res = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=5,
                                   min_train=300, verbose=False)
    s = res["strategy"]
    assert s["origin_spacing"] >= HORIZON
    assert s["overlapping_origins"] is False
    assert "caveat" not in s


def test_strategy_can_be_disabled():
    res = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=5,
                                   min_train=300, verbose=False, strategy=False)
    assert "strategy" not in res
    assert not res["signals"].empty          # signals are still collected


def test_existing_result_keys_are_preserved():
    res = bt.walk_forward_backtest(_FULL, _flat_fn, "1d", HORIZON, n_splits=5,
                                   min_train=300, verbose=False)
    # Backwards compatibility: nothing that existed before was renamed.
    assert {"summary", "per_split", "origins", "dm"} <= set(res)
    assert "rmse" in res["summary"].index
    assert {"model", "naive", "drift", "ar1"} <= set(res["summary"].columns)


def test_print_summary_includes_the_strategy_block(capsys=None):
    res = bt.walk_forward_backtest(_FULL, _oracle_fn, "1d", HORIZON,
                                   n_splits=6, min_train=300, verbose=False)
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        bt.print_backtest_summary(res, "oracle")
    text = buf.getvalue()
    assert "Walk-forward backtest" in text
    assert "Strategy evaluation" in text and "Sharpe" in text


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All backtest-strategy tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
