"""
Tests for config.py — the feature-flag registry.

The properties worth pinning are the ones that would let configuration lie: a
flag that exists but is invisible to the banner, an override that silently fails
to take effect, or a malformed environment variable that stops the app instead
of being ignored.
"""

import contextlib
import importlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config


@contextlib.contextmanager
def _reload_with(env):
    """
    Re-import config under a temporary environment, restoring on exit.

    A context manager rather than a function returning the module:
    ``importlib.reload`` mutates the module object in place, so restoring the
    environment and reloading before the caller reads it would revert the very
    values under test.
    """
    saved = {k: os.environ.get(k) for k in env}
    for k, v in env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    try:
        yield importlib.reload(config)
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        importlib.reload(config)


# ---------------------------------------------------------------------------
# Registry integrity
# ---------------------------------------------------------------------------

def test_every_flag_in_the_registry_has_a_resolved_constant():
    """
    A registry entry with no module constant would be reported by the banner but
    read by nothing — configuration theatre.
    """
    for name in config.FLAGS:
        assert hasattr(config, name), f"{name} is in FLAGS but has no constant"
        assert isinstance(getattr(config, name), bool)


def test_every_flag_documents_its_default():
    for name, meta in config.FLAGS.items():
        assert meta["why"].strip(), f"{name} has no rationale"
        assert meta["module"].endswith(".py"), f"{name} names no owning module"
        assert meta["label"], f"{name} has no banner label"


def test_labels_are_unique():
    """Two flags sharing a banner label would make one of them unreadable."""
    labels = [m["label"] for m in config.FLAGS.values()]
    assert len(labels) == len(set(labels))


def test_active_flags_covers_the_whole_registry():
    """The banner must report every flag; a hidden flag silently changes results."""
    active = config.active_flags()
    assert len(active) == len(config.FLAGS)
    for meta in config.FLAGS.values():
        assert meta["label"] in active


def test_registry_is_ascii():
    """
    config.py is a console tool (`python config.py`). A legacy Windows code page
    cannot encode an em dash, so non-ASCII here prints as mojibake.
    """
    for name, meta in config.FLAGS.items():
        blob = meta["why"] + meta["module"] + meta["label"]
        assert blob.isascii(), f"{name} carries non-ASCII text"


# ---------------------------------------------------------------------------
# Environment parsing
# ---------------------------------------------------------------------------

def test_env_flag_reads_the_documented_truthy_and_falsy_words():
    for word in ("1", "true", "TRUE", "yes", "on", " On "):
        os.environ["_TMP_FLAG"] = word
        assert config.env_flag("_TMP_FLAG", False) is True, word
    for word in ("0", "false", "no", "off"):
        os.environ["_TMP_FLAG"] = word
        assert config.env_flag("_TMP_FLAG", True) is False, word
    os.environ.pop("_TMP_FLAG", None)


def test_malformed_env_var_falls_back_instead_of_raising():
    """A stray value should fail to take effect, not stop the app."""
    os.environ["_TMP_FLAG"] = "maybe"
    try:
        assert config.env_flag("_TMP_FLAG", True) is True
        assert config.env_flag("_TMP_FLAG", False) is False
    finally:
        os.environ.pop("_TMP_FLAG", None)


def test_env_int_falls_back_on_garbage():
    os.environ["_TMP_INT"] = "not-a-number"
    try:
        assert config.env_int("_TMP_INT", 3) == 3
    finally:
        os.environ.pop("_TMP_INT", None)
    os.environ["_TMP_INT"] = " 7 "
    try:
        assert config.env_int("_TMP_INT", 3) == 7
    finally:
        os.environ.pop("_TMP_INT", None)


def test_unset_environment_yields_the_shipped_defaults():
    with _reload_with({config.ENV_PREFIX + n: None for n in config.FLAGS}) as mod:
        for name, meta in mod.FLAGS.items():
            assert getattr(mod, name) is meta["default"], name
        assert mod.overridden() == []


def test_override_takes_effect_and_is_reported():
    with _reload_with({config.ENV_PREFIX + "USE_MARKET_CONTEXT": "1"}) as mod:
        assert mod.USE_MARKET_CONTEXT is True
        assert "USE_MARKET_CONTEXT" in mod.overridden()
        # ...and the banner-facing view reflects it, not the default.
        assert mod.active_flags()[mod.FLAGS["USE_MARKET_CONTEXT"]["label"]] is True


def test_a_flag_that_ships_on_can_be_turned_off():
    """The A/B direction that matters for USE_INTRADAY_FEATURES."""
    with _reload_with({config.ENV_PREFIX + "USE_INTRADAY_FEATURES": "0"}) as mod:
        assert mod.USE_INTRADAY_FEATURES is False
        assert "USE_INTRADAY_FEATURES" in mod.overridden()


def test_gate_tunables_are_env_overridable():
    with _reload_with({config.ENV_PREFIX + "GATE_SPLITS": "5"}) as mod:
        assert mod.GATE_SPLITS == 5
    assert config.GATE_SPLITS == 3, "default not restored after reload"


# ---------------------------------------------------------------------------
# Consumers stay in sync
# ---------------------------------------------------------------------------

def test_ml_model_binding_matches_config():
    """
    ML_model re-binds the flag so the A/B tests can monkeypatch it. That binding
    must start from config's value, or the banner would report one thing while
    the feature does another.
    """
    import ML_model
    assert ML_model.USE_INTRADAY_FEATURES == config.USE_INTRADAY_FEATURES


def test_describe_flags_overrides_visibly():
    with _reload_with({config.ENV_PREFIX + "USE_REGIME_NOVELTY": "1"}) as mod:
        text = mod.describe()
    assert "USE_REGIME_NOVELTY = on" in text
    assert "OVERRIDDEN" in text
