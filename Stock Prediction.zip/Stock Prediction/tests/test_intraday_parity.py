"""
Regression tests: the intraday NSE-session features must be **identical**
whether computed offline (vectorised ``create_features``, used in training) or
online (``_features_from_buffers``, used at serve time), and they must be
**leak-free** (a future bar can never change the current bar's features).

This is the project's highest silent-bug risk: train/serve feature skew would
not raise an error, it would just quietly degrade live forecasts. These tests
lock the contract in place so a future edit to either path is caught.

Run standalone:
    python test_intraday_parity.py
or under pytest:
    pytest test_intraday_parity.py -q

Contract under test (documented in ML_model._add_intraday_features_vec):
NSE sessions are 7 contiguous hourly bars (09:15..15:15). The synthetic data
here is built to honour that, which is exactly the assumption the scalar mirror
relies on.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import ML_model
from model_utils import NSE_BARS_PER_SESSION

# The six intraday features that must match across the two code paths.
INTRADAY_COLS = [
    "bar_in_session",
    "is_first_bar",
    "is_last_bar",
    "ret_since_open",
    "overnight_gap",
    "same_hour_prev_day_ret",
]

_BAR_HOURS = [9, 10, 11, 12, 13, 14, 15]  # 09:15..15:15, 7 bars/session


def _make_hourly_df(n_sessions=40, seed=7):
    """Build a clean synthetic hourly frame: n_sessions x 7 contiguous bars."""
    assert len(_BAR_HOURS) == NSE_BARS_PER_SESSION
    rng = np.random.default_rng(seed)

    # Consecutive weekday sessions (skip Sat/Sun) so index.normalize() groups
    # one calendar day per session, matching the vectorised grouping.
    days, d = [], pd.Timestamp("2024-01-01")  # a Monday
    while len(days) < n_sessions:
        if d.dayofweek < 5:
            days.append(d)
        d += pd.Timedelta(days=1)

    stamps = [
        day + pd.Timedelta(hours=h, minutes=15)
        for day in days
        for h in _BAR_HOURS
    ]

    # A gentle random-walk price path (strictly positive).
    steps = rng.normal(0, 0.004, size=len(stamps))
    price = 1000.0 * np.exp(np.cumsum(steps))

    df = pd.DataFrame({
        "datetime": stamps,
        "open": price * (1 + rng.normal(0, 0.0005, len(stamps))),
        "high": price * (1 + np.abs(rng.normal(0, 0.001, len(stamps)))),
        "low": price * (1 - np.abs(rng.normal(0, 0.001, len(stamps)))),
        "close": price,
        "adj_close": price,
        "volume": rng.integers(1_000, 10_000, len(stamps)).astype(float),
    })
    return df


def _vec_features(df):
    """Run the offline/training feature builder and keep the intraday columns."""
    feat = ML_model.create_features(df, "hourly")
    return feat


def test_offline_online_parity():
    """Each intraday feature from the buffer path must equal the vectorised one."""
    assert ML_model.USE_INTRADAY_FEATURES, "intraday features are disabled"
    df = _make_hourly_df()
    feat = _vec_features(df)
    assert all(c in feat.columns for c in INTRADAY_COLS), "intraday cols missing offline"

    prices = df["adj_close"].to_numpy(float)
    volumes = df["volume"].to_numpy(float)
    stamps = pd.to_datetime(df["datetime"]).to_numpy()

    # Map each surviving feature row back to its position in the raw series.
    pos_by_time = {t: i for i, t in enumerate(stamps)}

    checked = 0
    mismatches = []
    # Walk the rows that survived create_features' dropna(), skipping the very
    # early ones (warm-up) and sampling across the rest.
    for ts in feat.index[5::3]:
        i = pos_by_time[np.datetime64(ts)]
        if i < NSE_BARS_PER_SESSION + 2:
            continue  # need a full prior session for overnight_gap
        online = ML_model._features_from_buffers(
            prices[: i + 1], volumes[: i + 1], pd.Timestamp(ts), "hourly"
        )
        for col in INTRADAY_COLS:
            a = float(feat.loc[ts, col])
            b = float(online[col])
            if not np.isclose(a, b, rtol=1e-9, atol=1e-9):
                mismatches.append((str(ts), col, a, b))
        checked += 1

    assert checked >= 10, f"too few rows checked ({checked})"
    assert not mismatches, f"offline/online mismatch: {mismatches[:5]}"
    return checked


def test_leak_free_future_perturbation():
    """Changing a strictly-future bar must not alter the origin's features."""
    df = _make_hourly_df()
    prices = df["adj_close"].to_numpy(float)
    volumes = df["volume"].to_numpy(float)
    stamps = pd.to_datetime(df["datetime"])

    origin = 120  # a bar deep enough to have full history
    base = ML_model._features_from_buffers(
        prices[: origin + 1], volumes[: origin + 1], stamps.iloc[origin], "hourly"
    )

    # Perturb a FUTURE bar (after the origin) and recompute the SAME origin row.
    perturbed = prices.copy()
    perturbed[origin + 3] *= 1.25
    after = ML_model._features_from_buffers(
        perturbed[: origin + 1], volumes[: origin + 1], stamps.iloc[origin], "hourly"
    )

    diffs = {
        c: (base[c], after[c])
        for c in INTRADAY_COLS
        if not np.isclose(base[c], after[c], rtol=1e-12, atol=1e-12)
    }
    assert not diffs, f"future bar leaked into origin features: {diffs}"
    return True


def test_bar_positions_and_flags():
    """bar_in_session cycles 0..6 with correct first/last flags across sessions."""
    df = _make_hourly_df()
    feat = _vec_features(df)
    bars = feat["bar_in_session"].to_numpy()
    assert set(np.unique(bars)).issubset(set(range(NSE_BARS_PER_SESSION)))
    # first/last flags must agree with the bar index definition
    assert np.array_equal(feat["is_first_bar"].to_numpy(), (bars == 0).astype(int))
    assert np.array_equal(
        feat["is_last_bar"].to_numpy(),
        (bars == NSE_BARS_PER_SESSION - 1).astype(int),
    )
    return True


def test_toggle_off_drops_columns():
    """With the flag off, none of the intraday columns should be produced."""
    original = ML_model.USE_INTRADAY_FEATURES
    try:
        ML_model.USE_INTRADAY_FEATURES = False
        feat = ML_model.create_features(_make_hourly_df(), "hourly")
        present = [c for c in INTRADAY_COLS if c in feat.columns]
        assert not present, f"intraday cols leaked while disabled: {present}"
    finally:
        ML_model.USE_INTRADAY_FEATURES = original
    return True


def _main():
    tests = [
        ("offline==online parity", test_offline_online_parity),
        ("leak-free (future perturbation)", test_leak_free_future_perturbation),
        ("bar positions & flags", test_bar_positions_and_flags),
        ("toggle off drops columns", test_toggle_off_drops_columns),
    ]
    failures = 0
    for name, fn in tests:
        try:
            result = fn()
            extra = f" ({result} rows checked)" if isinstance(result, int) and not isinstance(result, bool) else ""
            print(f"PASS  {name}{extra}")
        except AssertionError as exc:
            failures += 1
            print(f"FAIL  {name}: {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"ERROR {name}: {type(exc).__name__}: {exc}")
    print("-" * 50)
    print("All intraday-parity tests passed." if not failures
          else f"{failures} test(s) failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
