"""
Tests for ``cross_sectional_panel`` and ``cross_sectional_model``.

The single most important assertion here is **leak-freeness**. A pooled panel
with forward-looking labels is the easiest place in this whole repository to
produce a spectacular and completely fake result: one forward column left in the
feature list and the classifier scores ~100%. So the feature/label separation,
the split disjointness and the causality of the cross-sectional ranks are
asserted directly rather than trusted.

Network-free (the fetcher is injected) and deterministic.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import cross_sectional_panel as csp


# ── Fixtures ───────────────────────────────────────────────────────────────
def _fake_universe(n_tickers=12, n_days=520, seed=0):
    """A synthetic universe with a shared market factor plus idiosyncratic noise."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2021-01-04", periods=n_days)
    market = rng.normal(0.0003, 0.009, n_days)
    data = {}
    for k in range(n_tickers):
        beta = 0.6 + 0.8 * rng.random()
        idio = rng.normal(0, 0.011, n_days)
        ret = beta * market + idio
        price = 100 * (1 + k * 0.1) * np.exp(np.cumsum(ret))
        data[f"T{k:02d}.NS"] = pd.DataFrame({
            "datetime": dates, "open": price, "high": price * 1.01,
            "low": price * 0.99, "close": price, "adj_close": price,
            "volume": rng.integers(1e5, 1e6, n_days),
        })
    return data


def _panel(n_tickers=12, n_days=520, seed=0):
    uni = _fake_universe(n_tickers, n_days, seed)
    panel, rep = csp.build_panel(list(uni), fetch_fn=lambda t: uni[t],
                                 verbose=False)
    return panel, rep, uni


# ── Panel construction ─────────────────────────────────────────────────────
def test_build_panel_stacks_and_reports():
    panel, rep, uni = _panel()
    assert rep["n_tickers"] == 12 and rep["n_rows"] == 12 * 520
    assert set(panel["ticker"].unique()) == set(uni)
    assert list(panel.columns[:2]) == ["ticker", "datetime"]
    # Sorted by date then ticker, so groupby(date) reductions are well-defined.
    assert panel["datetime"].is_monotonic_increasing


def test_build_panel_records_why_tickers_were_dropped():
    uni = _fake_universe(4)
    uni["SHORT.NS"] = uni["T00.NS"].head(50)         # too little history
    uni["EMPTY.NS"] = pd.DataFrame()

    def fetch(t):
        if t == "BOOM.NS":
            raise RuntimeError("network")
        return uni[t]

    panel, rep = csp.build_panel(list(uni) + ["BOOM.NS"], fetch_fn=fetch,
                                 verbose=False)
    assert rep["n_tickers"] == 4
    # Survivorship auditability: every exclusion is recorded with a reason.
    assert set(rep["dropped"]) == {"SHORT.NS", "EMPTY.NS", "BOOM.NS"}
    assert "rows" in rep["dropped"]["SHORT.NS"]
    assert "network" in rep["dropped"]["BOOM.NS"]


def test_build_panel_empty_universe():
    panel, rep = csp.build_panel([], fetch_fn=lambda t: None, verbose=False)
    assert panel.empty and rep["n_rows"] == 0


# ── Features ───────────────────────────────────────────────────────────────
def test_ticker_features_never_span_a_ticker_boundary():
    panel, _, uni = _panel(n_tickers=4)
    feat = csp.add_ticker_features(panel)
    assert not feat.empty and "ticker" in feat.columns
    # Recomputing one ticker alone must give identical values — proof no rolling
    # window leaked across the boundary in the stacked version.
    from ML_model import create_features
    solo = create_features(uni["T01.NS"], "daily").reset_index()
    joint = feat[feat["ticker"] == "T01.NS"].reset_index(drop=True)
    merged = solo.merge(joint, on="datetime", suffixes=("_s", "_j"))
    assert len(merged) > 100
    assert np.allclose(merged["rsi_14_s"], merged["rsi_14_j"], equal_nan=True)


def test_cross_sectional_ranks_are_within_date_and_causal():
    panel, _, _ = _panel(n_tickers=10)
    feat = csp.add_ticker_features(panel)
    cs = csp.add_cross_sectional_ranks(feat)
    for c in csp.CS_COLS:
        assert c in cs.columns

    # Ranks are per-date percentiles: within any single date they span (0, 1].
    day = cs[cs["datetime"] == cs["datetime"].max()]
    r = day["rank_mom_21"].dropna()
    assert len(r) > 5 and r.min() > 0 and r.max() <= 1.0
    assert abs(float(r.mean()) - 0.5) < 0.25

    # Causality: truncating the panel must not change a past date's rank, i.e.
    # the rank uses only that day's cross-section, never future information.
    cutoff = cs["datetime"].quantile(0.7)
    trunc = csp.add_cross_sectional_ranks(feat[feat["datetime"] <= cutoff])
    a = cs[cs["datetime"] == cutoff].sort_values("ticker")["rank_mom_21"].values
    b = trunc[trunc["datetime"] == cutoff].sort_values("ticker")["rank_mom_21"].values
    assert np.allclose(a, b, equal_nan=True)


# ── Labels ─────────────────────────────────────────────────────────────────
def test_labels_are_three_class_and_market_neutral():
    panel, _, _ = _panel(n_tickers=10)
    lab = csp.add_labels(csp.add_cross_sectional_ranks(
        csp.add_ticker_features(panel)), horizon=5)
    assert set(lab["label"].unique()) <= {-1, 0, 1}
    assert set(lab["label_idx"].unique()) <= {0, 1, 2}
    # All three classes are populated and none dominates absurdly.
    counts = lab["label"].value_counts(normalize=True)
    assert len(counts) == 3 and counts.max() < 0.75
    # Market-neutral: excess returns are centred within each date by construction.
    per_day = lab.groupby("datetime")["fwd_excess"].mean().abs()
    assert float(per_day.max()) < 1e-9


def test_labels_drop_the_unrealised_tail():
    panel, _, _ = _panel(n_tickers=4, n_days=400)
    feat = csp.add_ticker_features(panel)
    lab = csp.add_labels(feat, horizon=5)
    # The last 5 bars per ticker have no realised future.
    for t, g in lab.groupby("ticker"):
        src = feat[feat["ticker"] == t]
        assert g["datetime"].max() < src["datetime"].max()


# ── The leak test ──────────────────────────────────────────────────────────
def test_feature_columns_exclude_every_forward_looking_field():
    """
    The assertion that matters most.

    One forward column left in the feature list and the classifier scores ~100%
    on a problem that is genuinely near-random. This pins the exclusion list.
    """
    panel, _, _ = _panel(n_tickers=6)
    lab = csp.add_labels(csp.add_cross_sectional_ranks(
        csp.add_ticker_features(panel)), horizon=5)
    cols = csp.feature_columns(lab)
    banned = {"fwd_return", "fwd_excess", "label", "label_idx",
              "adj_close", "close", "open", "high", "low", "volume",
              "ticker", "datetime"}
    assert not (set(cols) & banned), set(cols) & banned
    assert not any(c.startswith("target_") for c in cols)
    assert len(cols) > 15                       # engineered + cross-sectional
    assert set(csp.CS_COLS) <= set(cols)


# ── Splits ─────────────────────────────────────────────────────────────────
def test_asset_split_has_disjoint_tickers():
    panel, _, _ = _panel(n_tickers=12)
    s = csp.split_panel(panel, mode="asset", seed=1)
    assert set(s["train_tickers"]) & set(s["val_tickers"]) == set()
    assert set(s["train"]["ticker"]) & set(s["val"]["ticker"]) == set()
    assert s["n_train"] > 0 and s["n_val"] > 0


def test_time_split_is_ordered_and_embargoed():
    panel, _, _ = _panel(n_tickers=6)
    s = csp.split_panel(panel, mode="time", embargo=5)
    assert s["train"]["datetime"].max() < s["val"]["datetime"].min()


def test_combined_split_is_disjoint_on_both_axes():
    panel, _, _ = _panel(n_tickers=12)
    s = csp.split_panel(panel, mode="combined", seed=2)
    assert set(s["train"]["ticker"]) & set(s["val"]["ticker"]) == set()
    assert s["train"]["datetime"].max() < s["val"]["datetime"].min()
    assert s["mode"] == "combined" and s["split_date"]


def test_split_rejects_unknown_mode():
    panel, _, _ = _panel(n_tickers=4)
    try:
        csp.split_panel(panel, mode="random")
    except ValueError as exc:
        assert "mode" in str(exc)
    else:
        raise AssertionError("expected ValueError")


# ── Calibration machinery ──────────────────────────────────────────────────
def test_ece_is_zero_for_a_perfectly_calibrated_forecast():
    import cross_sectional_model as csm
    rng = np.random.default_rng(0)
    p = rng.random(20000)
    y = (rng.random(20000) < p).astype(float)       # outcomes match the stated p
    assert csm.expected_calibration_error(p, y) < 0.02


def test_ece_catches_systematic_overconfidence():
    import cross_sectional_model as csm
    rng = np.random.default_rng(1)
    p = rng.uniform(0.6, 1.0, 20000)                # always claims high confidence
    y = (rng.random(20000) < 0.5).astype(float)     # reality is a coin flip
    assert csm.expected_calibration_error(p, y) > 0.2


def test_reliability_table_shape():
    import cross_sectional_model as csm
    rng = np.random.default_rng(2)
    p = rng.random(3000)
    y = (rng.random(3000) < p).astype(float)
    t = csm.reliability_table(p, y)
    assert set(t.columns) == {"bin", "n", "mean_pred", "observed", "gap"}
    assert t["n"].sum() == 3000


def test_isotonic_calibration_improves_a_distorted_score():
    import cross_sectional_model as csm
    rng = np.random.default_rng(3)
    true_p = rng.random(6000)
    y = (rng.random(6000) < true_p).astype(int)
    # A squashed, overconfident score: monotone in truth but badly scaled.
    distorted = np.clip(true_p ** 2, 1e-6, 1 - 1e-6)
    P = np.column_stack([1 - distorted, np.zeros_like(distorted), distorted])
    yk = np.where(y == 1, 2, 0)
    before = csm.expected_calibration_error(P[:, 2], yk == 2)
    cals = csm._fit_isotonic(P, yk)
    after = csm.expected_calibration_error(csm._apply_isotonic(cals, P)[:, 2],
                                           yk == 2)
    assert after < before, (before, after)


def test_calibrated_probabilities_form_a_distribution():
    import cross_sectional_model as csm
    rng = np.random.default_rng(4)
    P = rng.random((500, 3)); P /= P.sum(axis=1, keepdims=True)
    y = rng.integers(0, 3, 500)
    Q = csm._apply_isotonic(csm._fit_isotonic(P, y), P)
    assert np.allclose(Q.sum(axis=1), 1.0)
    assert (Q >= 0).all() and (Q <= 1).all()


# ── End to end ─────────────────────────────────────────────────────────────
def test_end_to_end_fit_and_evaluate():
    import cross_sectional_model as csm
    panel, _, _ = _panel(n_tickers=14, n_days=600, seed=7)
    lab = csp.add_labels(csp.add_cross_sectional_ranks(
        csp.add_ticker_features(panel)), horizon=5)
    cols = csp.feature_columns(lab)
    s = csp.split_panel(lab, mode="combined", seed=3)

    bundle = csm.fit_calibrated(s["train"], cols, verbose=False)
    res = csm.evaluate(bundle, s["val"], verbose=False)

    assert res["n"] > 0
    assert 0.0 <= res["accuracy"] <= 1.0
    assert 0.0 <= res["macro_f1"] <= 1.0
    # On a synthetic near-random panel the model must NOT look brilliant; a very
    # high accuracy here would mean a leak, not a discovery.
    assert res["accuracy"] < 0.9, res["accuracy"]
    assert "reliability" in res and "confusion" in res
    txt = csm.format_report(bundle, res)
    assert "Cross-sectional" in txt and "Rank IC" in txt


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All cross-sectional tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
