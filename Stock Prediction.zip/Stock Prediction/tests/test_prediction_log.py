"""
Tests for ``prediction_log`` — the forward log, outcome resolution, drift
monitoring, live gate validation and the paper portfolio (book Ch. 3).

The important test here is not any single metric but the **round trip**: log a
forecast before its outcome exists, resolve it against realised prices later, and
check that the scoring is driven entirely by data that arrived after the
prediction was written. That property is what makes a forward log immune to the
data-snooping the rest of this project has to correct for, so it is asserted
directly rather than assumed.

Everything is network-free and deterministic — the fetcher and the clock are
injected, and the log is written to a temp path so the real ``.prediction_log/``
is never touched.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import json
import os
import tempfile

import numpy as np
import pandas as pd

import prediction_log as pl


# ── Fixtures ───────────────────────────────────────────────────────────────
def _tmp():
    return os.path.join(tempfile.mkdtemp(prefix="plog_"), "predictions.jsonl")


def _history(n=60, start="2024-01-01", seed=0, sigma=0.01):
    rng = np.random.default_rng(seed)
    price = 100 * np.exp(np.cumsum(rng.normal(0.0, sigma, n)))
    return pd.DataFrame({
        "datetime": pd.bdate_range(start, periods=n),
        "adj_close": price,
    })


def _forecast(dates, prices, band=0.05):
    return pd.DataFrame({
        "datetime": dates,
        "predicted_price": prices,
        "lower_bound": [p * (1 - band) for p in prices],
        "upper_bound": [p * (1 + band) for p in prices],
    })


# ── Writing and reading ────────────────────────────────────────────────────
def test_log_writes_one_row_per_step_with_context():
    path = _tmp()
    dates = pd.bdate_range("2024-03-25", periods=3)
    rid = pl.log_forecast("ACME", "1d", 3, "XGBoost",
                          _forecast(dates, [101.0, 102.0, 103.0]),
                          anchor_price=100.0, origin_datetime="2024-03-22",
                          confidence_bucket="High", dq_mode="normal",
                          novelty_verdict="familiar", seed=42, path=path)
    df = pl.read_log(path)
    assert rid and len(df) == 3
    assert list(df["step"]) == [1, 2, 3]
    # The gate verdicts in force at serve time are recorded, which is what makes
    # "did the GATES work?" answerable later.
    assert set(df["confidence_bucket"]) == {"High"}
    assert set(df["dq_mode"]) == {"normal"}
    assert set(df["novelty_verdict"]) == {"familiar"}
    assert df["realised_price"].isna().all()          # nothing resolved yet


def test_log_appends_across_runs():
    path = _tmp()
    d = pd.bdate_range("2024-03-25", periods=2)
    pl.log_forecast("A", "1d", 2, "m1", _forecast(d, [1.0, 2.0]), 1.0, "2024-03-22", path=path)
    pl.log_forecast("A", "1d", 2, "m2", _forecast(d, [1.0, 2.0]), 1.0, "2024-03-22", path=path)
    df = pl.read_log(path)
    assert len(df) == 4 and df["run_id"].nunique() == 2


def test_log_handles_models_without_bands():
    path = _tmp()
    d = pd.bdate_range("2024-03-25", periods=2)
    pl.log_forecast("A", "1d", 2, "hybrid",
                    pd.DataFrame({"datetime": d, "predicted_price": [1.0, 2.0]}),
                    1.0, "2024-03-22", path=path)
    df = pl.read_log(path)
    assert len(df) == 2 and df["lower_bound"].isna().all()


def test_logging_never_raises_on_bad_input():
    # A logging failure must never break a forecast.
    assert pl.log_forecast("A", "1d", 1, "m", None, 1.0, "2024-01-01") is None
    assert pl.log_forecast("A", "1d", 1, "m", pd.DataFrame(), 1.0, "2024-01-01") is None
    bad = pd.DataFrame({"datetime": ["x"], "predicted_price": ["not a number"]})
    assert pl.log_forecast("A", "1d", 1, "m", bad, 1.0, "2024-01-01",
                           path=_tmp()) is None


def test_read_log_survives_a_truncated_line():
    path = _tmp()
    d = pd.bdate_range("2024-03-25", periods=2)
    pl.log_forecast("A", "1d", 2, "m", _forecast(d, [1.0, 2.0]), 1.0, "2024-03-22", path=path)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write('{"run_id": "trunc", "ticker":\n')      # crash mid-write
    df = pl.read_log(path)
    assert len(df) == 2                                   # the good rows survive


def test_read_log_empty_when_absent():
    df = pl.read_log(os.path.join(tempfile.mkdtemp(), "nope.jsonl"))
    assert df.empty and "predicted_price" in df.columns


# ── Resolution ─────────────────────────────────────────────────────────────
def test_resolution_only_touches_matured_rows_and_is_idempotent():
    path = _tmp()
    hist = _history(n=60, start="2024-01-01")
    last = hist["datetime"].iloc[-1]
    # One target inside the history (matured) and one far in the future.
    dates = [hist["datetime"].iloc[-3], last + pd.Timedelta(days=365)]
    pl.log_forecast("ACME", "1d", 2, "m", _forecast(dates, [100.0, 100.0]),
                    100.0, hist["datetime"].iloc[-5], path=path)

    r1 = pl.resolve_outcomes(lambda t, i: hist, now=last, path=path, verbose=False)
    assert r1["resolved"] == 1 and r1["still_pending"] == 1

    # Running again resolves nothing new and changes nothing. Compare with
    # DataFrame.equals, not dict equality: unresolved rows hold NaN, and NaN
    # never equals itself, so a dict comparison can never pass here.
    before = pl.read_log(path)
    r2 = pl.resolve_outcomes(lambda t, i: hist, now=last, path=path, verbose=False)
    assert r2["resolved"] == 0
    assert pl.read_log(path).equals(before)


def test_resolution_never_rewrites_the_prediction_itself():
    """Append-only in spirit: only the outcome columns may change."""
    path = _tmp()
    hist = _history(n=60)
    pl.log_forecast("ACME", "1d", 1, "m",
                    _forecast([hist["datetime"].iloc[-2]], [123.456]),
                    100.0, hist["datetime"].iloc[-5], path=path)
    before = pl.read_log(path).iloc[0].to_dict()
    pl.resolve_outcomes(lambda t, i: hist, now=hist["datetime"].iloc[-1],
                        path=path, verbose=False)
    after = pl.read_log(path).iloc[0].to_dict()
    for k in ("predicted_price", "lower_bound", "upper_bound", "anchor_price",
              "confidence_bucket", "target_datetime", "run_id"):
        assert before[k] == after[k], k
    assert after["realised_price"] is not None


def test_resolution_uses_backward_asof_not_nearest():
    """A target that has not printed yet must not borrow a later bar's price."""
    path = _tmp()
    hist = _history(n=40)
    # Target lands on a weekend: the correct fill is the PRIOR trading bar.
    target = hist["datetime"].iloc[-3] + pd.Timedelta(days=1)
    pl.log_forecast("ACME", "1d", 1, "m", _forecast([target], [1.0]),
                    100.0, hist["datetime"].iloc[-5], path=path)
    pl.resolve_outcomes(lambda t, i: hist, now=hist["datetime"].iloc[-1],
                        path=path, verbose=False)
    got = float(pl.read_log(path)["realised_price"].iloc[0])
    prior = hist[hist["datetime"] <= target]["adj_close"].iloc[-1]
    assert np.isclose(got, prior)


def test_resolution_survives_a_failing_fetch():
    path = _tmp()
    hist = _history(n=40)
    pl.log_forecast("ACME", "1d", 1, "m",
                    _forecast([hist["datetime"].iloc[-2]], [1.0]),
                    100.0, hist["datetime"].iloc[-5], path=path)

    def boom(t, i):
        raise RuntimeError("network down")

    res = pl.resolve_outcomes(boom, now=hist["datetime"].iloc[-1],
                              path=path, verbose=False)
    assert res["resolved"] == 0                     # no crash, nothing resolved


# ── Round trip: the property that makes a forward log worth having ─────────
def _seed_resolved_log(path, n_runs=40, bucket_cycle=("High", "Low"),
                       band=0.05, seed=1):
    """Log n_runs 1-step forecasts against a real history, then resolve them."""
    hist = _history(n=n_runs + 20, seed=seed)
    for k in range(n_runs):
        i = 10 + k
        anchor = float(hist["adj_close"].iloc[i])
        target_dt = hist["datetime"].iloc[i + 1]
        run_id = pl.log_forecast(
            "ACME", "1d", 1, "m",
            _forecast([target_dt], [anchor * 1.001], band=band),
            anchor, hist["datetime"].iloc[i],
            confidence_bucket=bucket_cycle[k % len(bucket_cycle)],
            path=path)
        # log_forecast swallows every exception on purpose - in the app a
        # logging failure must never break a forecast. In a test that same
        # swallow turns a transient write failure into a SHORT LOG, and the
        # mystery then surfaces several assertions later as an unexplained
        # coverage number. Asserting the write succeeded converts an
        # intermittent puzzle into an immediate, named failure.
        assert run_id is not None, (
            f"log_forecast silently failed on row {k}; the log is short and "
            f"every count-dependent assertion below is now meaningless")
    pl.resolve_outcomes(lambda t, i: hist, now=hist["datetime"].iloc[-1],
                        path=path, verbose=False)
    # Same reasoning for the resolution step: a partial resolve would quietly
    # change every coverage figure computed from this log.
    assert len(pl.read_log(path)) == n_runs, (
        f"expected {n_runs} logged rows, found {len(pl.read_log(path))}")
    return hist


def test_round_trip_scores_only_post_prediction_data():
    path = _tmp()
    _seed_resolved_log(path, n_runs=40)
    df = pl.resolved_frame(path)
    assert len(df) == 40
    assert {"pred_return", "real_return", "covered", "direction_hit"} <= set(df.columns)
    # Every scored row was written before its outcome existed: the realised price
    # is dated at/after the target, which is strictly after the origin.
    assert (pd.to_datetime(df["target_datetime"])
            > pd.to_datetime(df["origin_datetime"])).all()
    assert df["resolved_at_utc"].notna().all()


def test_drift_report_flags_a_genuinely_broken_cone():
    path = _tmp()
    # A band of +/-0.05% around the anchor on a 1%/day series: it will miss
    # almost every time, which is exactly what an alert should catch.
    _seed_resolved_log(path, n_runs=40, band=0.0005)
    rep = pl.drift_report(path)
    assert rep["n_resolved"] == 40
    row = rep["per_model"].iloc[0]
    assert row["coverage_recent"] < 0.5
    assert rep["alerts"] and "UNDER-covering" in rep["alerts"][0]


def test_drift_report_is_quiet_on_a_healthy_cone():
    path = _tmp()
    _seed_resolved_log(path, n_runs=40, band=0.06)   # wide enough to cover
    rep = pl.drift_report(path)
    assert rep["per_model"].iloc[0]["coverage_recent"] > 0.9
    assert not any("UNDER-covering" in a for a in rep["alerts"])


def test_drift_report_stays_silent_below_the_sample_floor():
    """A handful of points cannot distinguish drift from noise — so don't alert."""
    path = _tmp()
    _seed_resolved_log(path, n_runs=10, band=0.0005)
    rep = pl.drift_report(path)
    assert rep["alerts"] == []
    assert "n<" in str(rep["per_model"].iloc[0]["coverage_ci"])


def test_recent_window_isolates_a_late_breakdown():
    path = _tmp()
    _seed_resolved_log(path, n_runs=40, band=0.06)        # healthy history
    rep_all = pl.drift_report(path, recent=1000)
    rep_recent = pl.drift_report(path, recent=5)
    # The recent window must be able to differ from the all-time number; that is
    # the whole point of not reporting a long-run average.
    assert rep_all["per_model"].iloc[0]["n_recent"] > \
        rep_recent["per_model"].iloc[0]["n_recent"]


# ── Gate validation and paper portfolio ────────────────────────────────────
def test_gate_validation_groups_by_served_bucket():
    path = _tmp()
    _seed_resolved_log(path, n_runs=40, bucket_cycle=("High", "No edge"))
    g = pl.gate_validation(path)
    assert set(g["by_bucket"]["confidence_bucket"]) == {"High", "No edge"}
    # Ordering is the gate's own ranking, worst first.
    assert list(g["by_bucket"]["confidence_bucket"]) == ["No edge", "High"]
    assert g["monotonic"] in (True, False)
    assert "gate" in g["verdict"].lower()


def test_flat_gate_is_not_declared_informative():
    """
    Regression test: ties must not pass as "monotonic".

    The first check used `hits[i] <= hits[i+1]`, which every tie satisfies — so a
    gate whose buckets had IDENTICAL realised accuracy (0.517 vs 0.517, observed
    in an end-to-end run) was reported as "the gate IS informative". A gate that
    discriminates nothing being called a success is exactly the over-claim this
    project exists to avoid.
    """
    path = _tmp()
    hist = _history(n=80, seed=4)
    # Two buckets, but the SAME forecast under each: accuracy must be identical.
    for k in range(30):
        i = 10 + k
        anchor = float(hist["adj_close"].iloc[i])
        t = hist["datetime"].iloc[i + 1]
        for bucket in ("High", "No edge"):
            pl.log_forecast("A", "1d", 1, "m",
                            _forecast([t], [anchor * 1.001]), anchor,
                            hist["datetime"].iloc[i],
                            confidence_bucket=bucket, path=path)
    pl.resolve_outcomes(lambda t, i: hist, now=hist["datetime"].iloc[-1],
                        path=path, verbose=False)
    g = pl.gate_validation(path)
    hits = g["by_bucket"]["dir_hit"].tolist()
    assert hits[0] == hits[-1], hits          # genuinely flat by construction
    assert g["monotonic"] is False
    assert "FLAT" in g["verdict"]


def test_gate_validation_empty_without_buckets():
    path = _tmp()
    _seed_resolved_log(path, n_runs=20, bucket_cycle=(None,))
    g = pl.gate_validation(path)
    assert g["monotonic"] is None and "bucket" in g["verdict"]


def test_paper_portfolio_trades_only_the_final_step():
    path = _tmp()
    hist = _history(n=60)
    # 3-step forecasts: only step 3 should be traded (non-overlapping).
    for k in range(12):
        i = 10 + k * 3
        anchor = float(hist["adj_close"].iloc[i])
        dates = hist["datetime"].iloc[i + 1:i + 4].tolist()
        pl.log_forecast("ACME", "1d", 3, "m",
                        _forecast(dates, [anchor * 1.001] * 3),
                        anchor, hist["datetime"].iloc[i], path=path)
    pl.resolve_outcomes(lambda t, i: hist, now=hist["datetime"].iloc[-1],
                        path=path, verbose=False)
    pp = pl.paper_portfolio(path)
    assert "m" in pp and pp["m"]["n"] == 12          # not 36
    assert "sharpe" in pp["m"] and "max_drawdown" in pp["m"]


def test_summary_renders_end_to_end():
    path = _tmp()
    _seed_resolved_log(path, n_runs=40)
    txt = pl.summary(path)
    assert "Live prediction log" in txt
    assert "Calibration drift" in txt and "confidence gate" in txt
    assert "Paper portfolio" in txt


def test_summary_handles_an_empty_log():
    txt = pl.summary(os.path.join(tempfile.mkdtemp(), "none.jsonl"))
    assert "0 resolved" in txt and "nothing resolved yet" in txt


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All prediction-log tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
