"""
Tests for fracdiff.py — fractional differentiation.

The properties that matter are the ones that would let the transform be wrong
without looking wrong:

- **d = 1 must reduce EXACTLY to a first difference** and **d = 0 to the
  identity**. If those endpoints are off, every fractional order between them is
  off too, and the output would still be a plausible-looking stationary series.
- **Memory must actually be retained.** The entire justification for the method
  is that a fractional order keeps correlation with the level that d = 1
  destroys. If that correlation collapses anyway, the transform is doing
  nothing useful whatever its ADF p-value.
- **The window must be fixed-width.** A partially-filled window applies
  different weights to different rows, which silently makes early and late
  observations non-comparable.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fracdiff as fd


def _random_walk(n=1500, seed=0, start=100.0):
    rng = np.random.default_rng(seed)
    return start * np.exp(np.cumsum(rng.normal(0, 0.012, n)))


# ---------------------------------------------------------------------------
# The endpoints — if these are wrong, everything between them is too
# ---------------------------------------------------------------------------

def test_d_equals_one_is_exactly_a_first_difference():
    w = fd.frac_weights(1.0)
    assert np.allclose(w, [1.0, -1.0])
    x = _random_walk(400)
    got = fd.frac_diff(x, 1.0)
    assert np.allclose(got[1:], np.diff(x))
    assert np.isnan(got[0])


def test_d_equals_zero_is_the_identity():
    assert np.allclose(fd.frac_weights(0.0), [1.0])
    x = _random_walk(300)
    assert np.allclose(fd.frac_diff(x, 0.0), x)


def test_weights_follow_the_binomial_recurrence():
    d = 0.4
    w = fd.frac_weights(d, size=5)
    expected = [1.0]
    for k in range(1, 5):
        expected.append(-expected[-1] * (d - k + 1) / k)
    assert np.allclose(w, expected)
    assert w[0] == 1.0


def test_fractional_weights_decay_slowly_and_do_not_terminate():
    """
    The non-termination IS the retained memory. An integer order terminates
    after d+1 terms; a fractional one keeps contributing indefinitely.
    """
    w = fd.frac_weights(0.4, tol=1e-5)
    assert len(w) > 100, len(w)
    assert np.all(np.abs(np.diff(np.abs(w[1:]))) <= 1e-6 + np.abs(w[1:-1]))
    assert abs(w[-1]) < 1e-4


# ---------------------------------------------------------------------------
# Memory retention — the whole point of the method
# ---------------------------------------------------------------------------

def test_low_d_retains_memory_that_d_equals_one_destroys():
    x = np.log(_random_walk(3000, seed=1))
    low = fd.frac_diff(x, 0.3, tol=1e-4)
    full = fd.frac_diff(x, 1.0)
    ok_low = np.isfinite(low)
    ok_full = np.isfinite(full)
    corr_low = abs(np.corrcoef(low[ok_low], x[ok_low])[0, 1])
    corr_full = abs(np.corrcoef(full[ok_full], x[ok_full])[0, 1])
    assert corr_low > 0.8, corr_low
    assert corr_full < 0.2, corr_full
    assert corr_low > corr_full * 4


def test_memory_decreases_monotonically_with_d():
    x = np.log(_random_walk(3000, seed=2))
    corrs = []
    for d in (0.2, 0.4, 0.6, 0.8, 1.0):
        z = fd.frac_diff(x, d, tol=1e-4)
        ok = np.isfinite(z)
        corrs.append(abs(np.corrcoef(z[ok], x[ok])[0, 1]))
    assert all(a >= b - 1e-9 for a, b in zip(corrs, corrs[1:])), corrs


# ---------------------------------------------------------------------------
# Window handling
# ---------------------------------------------------------------------------

def test_leading_rows_are_nan_not_padded_with_a_partial_window():
    """
    A partial window applies different weights to different rows. Returning NaN
    is the honest answer; padding would silently make early observations
    incomparable to later ones.
    """
    x = _random_walk(500)
    w = fd.frac_weights(0.5, tol=1e-4)
    out = fd.frac_diff(x, 0.5, tol=1e-4)
    assert np.all(np.isnan(out[:len(w) - 1]))
    assert np.isfinite(out[len(w) - 1])


def test_series_shorter_than_the_window_is_all_nan():
    x = _random_walk(50)
    out = fd.frac_diff(x, 0.3, tol=1e-5)
    assert np.all(np.isnan(out))


def test_window_grows_as_d_falls_and_as_tolerance_tightens():
    """The practical constraint: a small d needs a long history."""
    assert len(fd.frac_weights(0.2, tol=1e-3)) < len(fd.frac_weights(0.2, tol=1e-5))
    assert len(fd.frac_weights(0.8, tol=1e-4)) < len(fd.frac_weights(0.2, tol=1e-4))


def test_non_finite_input_does_not_propagate_silently():
    x = _random_walk(400)
    x[100] = np.nan
    out = fd.frac_diff(x, 0.5, tol=1e-3)
    assert np.isnan(out[100])
    assert np.isfinite(out[-1])


# ---------------------------------------------------------------------------
# Stationarity tests and minimum-d
# ---------------------------------------------------------------------------

def test_adf_separates_a_random_walk_from_white_noise():
    rng = np.random.default_rng(3)
    walk = np.cumsum(rng.normal(size=1500))
    noise = rng.normal(size=1500)
    assert fd.adf_pvalue(walk) > 0.10, "a random walk should not look stationary"
    assert fd.adf_pvalue(noise) < 0.05, "white noise should look stationary"


def test_stationarity_tests_degrade_on_unusable_input():
    for fn in (fd.adf_pvalue, fd.kpss_pvalue):
        assert not np.isfinite(fn([1.0, 2.0, 3.0]))          # too short
        assert not np.isfinite(fn(np.full(200, 5.0)))        # constant


def test_min_d_finds_a_fractional_order_below_one():
    x = np.log(_random_walk(4000, seed=4))
    res = fd.min_d(x, d_grid=np.round(np.arange(0.0, 1.01, 0.1), 2), tol=1e-4)
    assert np.isfinite(res["d"])
    assert 0.0 < res["d"] <= 1.0
    scan = res["scan"]
    assert not scan.empty
    # d = 0 (the raw level) must never be judged stationary.
    assert not bool(scan[scan["d"] == 0.0].iloc[0]["stationary"])
    # Whatever d is chosen must retain more memory than d = 1 does.
    assert res["corr_with_level"] > float(
        scan[scan["d"] == 1.0].iloc[0]["corr_with_level"])


def test_min_d_returns_nan_when_nothing_qualifies():
    res = fd.min_d(np.linspace(0, 1, 60), d_grid=[0.0], tol=1e-3)
    assert not np.isfinite(res["d"])


# ---------------------------------------------------------------------------
# Feature integration
# ---------------------------------------------------------------------------

def test_add_fracdiff_features_appends_columns_without_disturbing_others():
    df = pd.DataFrame({"adj_close": _random_walk(1200),
                       "existing": np.arange(1200, dtype=float)})
    out = fd.add_fracdiff_features(df, orders=(0.3, 0.5), tol=1e-3)
    assert "fd_03" in out.columns and "fd_05" in out.columns
    assert list(df.columns) == [c for c in out.columns if not c.startswith("fd_")]
    assert out["existing"].equals(df["existing"])
    assert np.isfinite(out["fd_05"].iloc[-1])


def test_add_fracdiff_at_d_one_reproduces_the_log_return():
    """
    The A/B is only like-for-like if a d = 1 column equals the existing
    log_return_1 feature. Verified rather than assumed.
    """
    px = _random_walk(600)
    df = pd.DataFrame({"adj_close": px})
    out = fd.add_fracdiff_features(df, d=1.0)
    expected = np.r_[np.nan, np.diff(np.log(px))]
    got = out["fd_10"].values
    ok = np.isfinite(got) & np.isfinite(expected)
    assert np.allclose(got[ok], expected[ok])


def test_missing_price_column_returns_the_frame_unchanged():
    df = pd.DataFrame({"other": [1.0, 2.0, 3.0]})
    out = fd.add_fracdiff_features(df)
    assert out.equals(df)


def test_format_report_handles_an_empty_scan():
    txt = fd.format_report({"scan": pd.DataFrame(), "d": float("nan")}, "x")
    assert "no usable orders" in txt


# ---------------------------------------------------------------------------
# Diebold-Mariano: the Bartlett-kernel fix (README section 37)
# ---------------------------------------------------------------------------

def test_dm_at_h_equals_one_is_unchanged_by_the_kernel():
    """
    The lag loop does not execute at h = 1, so every single-step DM figure ever
    published by this project is bit-identical after the fix. That is what
    bounds the blast radius, and it is worth pinning rather than asserting.
    """
    from backtest import diebold_mariano
    rng = np.random.default_rng(0)
    a, b = rng.normal(size=80), rng.normal(size=80) * 1.1
    res = diebold_mariano(a, b, h=1)
    # Reproduce the h=1 statistic from first principles - no kernel involved.
    d = a ** 2 - b ** 2
    dbar, d0 = float(np.mean(d)), d - np.mean(d)
    var = float(np.mean(d0 * d0)) / len(d)
    corr = (len(d) + 1 - 2 * 1 + 1 * 0 / len(d)) / len(d)
    expected = (dbar / np.sqrt(var)) * np.sqrt(corr)
    assert res["stat"] == pytest.approx(expected, rel=1e-9)


def test_dm_variance_is_positive_where_the_rectangular_kernel_failed():
    """
    The bug. An unweighted autocovariance sum is not positive semi-definite and
    can go negative on short samples, forcing a NaN - a test that silently
    declines to run is a test that never rejects. Bartlett weights are PSD by
    construction.
    """
    from backtest import diebold_mariano

    def _rectangular(ea, eb, h):
        d = ea ** 2 - eb ** 2
        d0 = d - d.mean()
        var = float(np.mean(d0 * d0))
        for k in range(1, int(h)):
            if k < len(d):
                var += 2.0 * float(np.mean(d0[k:] * d0[:-k]))
        return var / len(d)

    rng = np.random.default_rng(7)
    rescued = 0
    for _ in range(300):
        a, b = rng.normal(size=20), rng.normal(size=20) * 1.05
        if _rectangular(a, b, 5) <= 0:                 # old version -> NaN
            res = diebold_mariano(a, b, h=5)
            assert np.isfinite(res["p_value"]), "Bartlett should still resolve"
            rescued += 1
    assert rescued > 10, (
        f"fixture failed to reproduce the negative-variance case ({rescued})")


def test_dm_never_returns_nan_on_well_behaved_short_samples():
    from backtest import diebold_mariano
    rng = np.random.default_rng(11)
    for h in (2, 5, 10):
        nan = sum(not np.isfinite(
            diebold_mariano(rng.normal(size=25), rng.normal(size=25) * 1.05,
                            h=h)["p_value"]) for _ in range(200))
        assert nan == 0, f"h={h} produced {nan} NaN p-values"


def test_dm_sign_convention_is_preserved():
    """A must be the model and B the baseline; negative means the model wins."""
    from backtest import diebold_mariano
    rng = np.random.default_rng(3)
    good = rng.normal(0, 0.5, 200)          # model: small errors
    bad = rng.normal(0, 2.0, 200)           # baseline: large errors
    res = diebold_mariano(good, bad, h=5)
    assert res["stat"] < 0
    assert res["p_value"] < 0.05
    assert res["favors"] == "model"
    flipped = diebold_mariano(bad, good, h=5)
    assert flipped["stat"] > 0 and flipped["favors"] == "baseline"


def test_dm_degenerate_input_still_returns_nan():
    """The guard stays: identical forecasts have no loss differential to test."""
    from backtest import diebold_mariano
    x = np.ones(50)
    assert not np.isfinite(diebold_mariano(x, x, h=5)["p_value"])
    assert not np.isfinite(diebold_mariano([1.0, 2.0], [1.0, 2.0])["p_value"])
