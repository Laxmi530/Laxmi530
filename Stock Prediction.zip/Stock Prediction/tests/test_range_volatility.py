"""
Tests for :mod:`range_volatility` -- range-based realized variance.

The estimators come from Sharma & Mehta (eds.), *Deep Learning Tools for
Predicting Stock Market Movements*, Ch. 18, which converts prices to volatility
with ``0.361 * [ln(High) - ln(Low)]**2`` -- Parkinson (1980), since
``1/(4 ln 2) = 0.3607``.

Two groups matter most:

* **Correctness against known answers.** A day that opens, runs, falls and
  closes flat has zero squared-return variance and obviously non-zero real
  variance; the range estimators must see it.
* **The corporate-action trap.** ``scale_to_total`` compares a within-bar range
  against a close-to-close return. The range is immune to splits; the return is
  not. Feeding it raw closes moved a real name's scale factor from 1.26 to 8.32
  during development, and ``test_scale_to_total_flags_an_unadjusted_close``
  exists so that cannot happen silently again.
"""

import numpy as np
import pandas as pd
import pytest

import range_volatility as rv


# ==========================================
# helpers
# ==========================================
def _gbm_bars(n=4000, sigma=0.02, steps=120, seed=0, drift=0.0):
    """Bars whose true per-bar variance is known to be sigma**2."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal((n, steps)) * sigma / np.sqrt(steps)
    z += drift / steps
    path = np.cumsum(z, axis=1)
    c = np.exp(path[:, -1])
    h = np.exp(path.max(axis=1))
    l = np.exp(path.min(axis=1))
    level = np.cumprod(np.r_[1.0, c])[:-1]
    return pd.DataFrame({"open": level, "high": level * h,
                         "low": level * l, "close": level * c})


# ==========================================
# 1. The book's constant
# ==========================================
def test_parkinson_uses_the_books_constant():
    """Ch. 18 writes 0.361; that is 1/(4 ln 2) to three decimals."""
    assert rv._PARKINSON_K == pytest.approx(0.361, abs=5e-4)
    # H/L of exactly e means ln(H/L) = 1, so the variance is the constant.
    v = rv.parkinson([np.e], [1.0])
    assert v[0] == pytest.approx(rv._PARKINSON_K)


# ==========================================
# 2. The failure squared returns cannot see
# ==========================================
def test_a_wide_bar_that_closes_flat_has_zero_squared_return_variance():
    """The motivating case: open 100, high 108, low 94, close 100. The
    close-to-close estimate is ZERO. The range estimators are not fooled."""
    df = pd.DataFrame({"open": [100.0, 100.0], "high": [100.0, 108.0],
                       "low": [100.0, 94.0], "close": [100.0, 100.0]})
    assert rv.estimate(df, "squared")[1] == pytest.approx(0.0)
    assert rv.estimate(df, "parkinson")[1] > 0.004
    assert rv.estimate(df, "rogers_satchell")[1] > 0.0


# ==========================================
# 3. Recovery of a known variance
# ==========================================
def test_every_estimator_recovers_the_right_order_of_magnitude():
    df = _gbm_bars()
    true = 0.02 ** 2
    for est in rv.PER_BAR:
        got = float(np.nanmean(rv.estimate(df, est)))
        assert 0.5 * true < got < 1.5 * true, f"{est}: {got:.2e} vs {true:.2e}"


def test_range_estimators_are_more_precise_than_squared_returns():
    """The whole point. Theory says ~5x for Parkinson under GBM."""
    df = _gbm_bars()
    for est in ("parkinson", "garman_klass", "rogers_satchell"):
        e = rv.efficiency(df, est)
        assert e["efficiency"] > 3.0, f"{est}: {e['efficiency']}"
    assert rv.efficiency(df, "squared")["efficiency"] == pytest.approx(1.0, abs=1e-9)


def test_rogers_satchell_is_the_one_that_survives_drift():
    """Parkinson and Garman-Klass assume a driftless bar and over-state
    variance when the bar trends; Rogers-Satchell is unbiased under drift.
    That is the case where an honest risk number matters most."""
    df = _gbm_bars(drift=0.05, seed=3)          # a strong within-bar trend
    true = 0.02 ** 2
    rs = float(np.nanmean(rv.estimate(df, "rogers_satchell")))
    pk = float(np.nanmean(rv.estimate(df, "parkinson")))
    assert abs(rs - true) < abs(pk - true)


# ==========================================
# 4. Scale invariance -- immunity to corporate actions
# ==========================================
@pytest.mark.parametrize("est", ["parkinson", "garman_klass", "rogers_satchell"])
def test_per_bar_estimators_are_invariant_to_rescaling(est):
    """ln(H/L), ln(C/O) and friends are ratios WITHIN one bar, so multiplying
    that bar's prices by any constant leaves them unchanged. This is why these
    can be computed from RAW OHLC and are immune to split/dividend adjustment."""
    df = _gbm_bars(n=500, seed=1)
    scaled = df * 7.5
    a, b = rv.estimate(df, est), rv.estimate(scaled, est)
    assert np.allclose(a[np.isfinite(a)], b[np.isfinite(b)])


def test_a_split_does_not_disturb_the_range_estimate():
    """A 1:10 split halves nothing within the bar -- open, high, low and close
    all rescale together, so the estimate is untouched."""
    df = _gbm_bars(n=300, seed=2)
    split = df.copy()
    split.iloc[150:] = split.iloc[150:] / 10.0
    a = rv.estimate(df, "parkinson")
    b = rv.estimate(split, "parkinson")
    assert np.allclose(a[np.isfinite(a)], b[np.isfinite(b)])
    # ... whereas the squared-return estimate is wrecked by exactly that split.
    s = rv.estimate(split, "squared")
    assert np.nanmax(s) > 1.0


# ==========================================
# 5. Level correction, and the trap
# ==========================================
def test_scale_to_total_maps_an_intraday_series_onto_close_to_close():
    df = _gbm_bars(n=2000, seed=4)
    p = rv.estimate(df, "parkinson")
    scaled, info = rv.scale_to_total(p, df["close"].values)
    cc = rv.estimate(df, "squared")
    assert np.nanmean(scaled) == pytest.approx(np.nanmean(cc), rel=0.02)
    assert info["implausible"] is False


def test_scale_to_total_flags_an_unadjusted_close():
    """Regression on a mistake made while building this module. The range term
    is split-immune, the close-to-close term is not, so an unadjusted series
    inflates the factor. On real data this took TATASTEEL's factor from 1.26 to
    8.32 before it was caught."""
    df = _gbm_bars(n=800, seed=5)
    raw = df.copy()
    raw.iloc[400:] = raw.iloc[400:] / 10.0      # a split, left unadjusted
    p = rv.estimate(raw, "parkinson")           # unaffected by the split
    _, info = rv.scale_to_total(p, raw["close"].values)
    assert info["implausible"] is True
    assert info["factor"] > 4.0


def test_scale_to_total_declines_on_too_little_data():
    p = np.array([1e-4] * 10)
    scaled, info = rv.scale_to_total(p, np.linspace(100, 110, 10))
    assert info["factor"] == 1.0 and np.allclose(scaled, p)


# ==========================================
# 6. Dispatch contract
# ==========================================
def test_unknown_estimator_raises():
    with pytest.raises(ValueError, match="unknown estimator"):
        rv.estimate(_gbm_bars(n=50), "not_an_estimator")


def test_missing_columns_raise_rather_than_falling_back():
    """A silent fallback to squared returns would make an A/B compare a model
    against itself and report no difference -- the worst possible failure."""
    df = pd.DataFrame({"close": [100.0, 101.0, 102.0]})
    with pytest.raises(ValueError, match="needs columns"):
        rv.estimate(df, "parkinson")


def test_garman_klass_nulls_negative_bars_rather_than_clipping():
    """Clipping a negative estimate to zero would bias the mean down; NaN
    excludes the bar from the average instead."""
    df = pd.DataFrame({"open": [100.0], "high": [100.05], "low": [99.95],
                       "close": [110.0]})            # close far outside range
    assert np.isnan(rv.estimate(df, "garman_klass")[0])


def test_yang_zhang_is_rolling_and_leaves_the_burn_in_empty():
    df = _gbm_bars(n=300, seed=6)
    v = rv.estimate(df, "yang_zhang", window=30)
    assert np.isnan(v[:30]).all()
    assert np.isfinite(v[30:]).sum() > 200
    assert np.nanmean(v) == pytest.approx(0.02 ** 2, rel=0.6)


def test_non_positive_prices_become_nan_not_an_exception():
    df = pd.DataFrame({"open": [100.0, 0.0], "high": [101.0, 0.0],
                       "low": [99.0, 0.0], "close": [100.0, 0.0]})
    v = rv.estimate(df, "parkinson")
    assert np.isfinite(v[0]) and np.isnan(v[1])


def test_compare_ranks_estimators_and_reports_cleanly():
    df = _gbm_bars(n=1500, seed=7)
    tab = rv.compare(df)
    assert set(tab["estimator"]) == set(rv.PER_BAR)
    assert tab["efficiency"].iloc[0] >= tab["efficiency"].iloc[-1]
    assert "efficiency" in rv.format_report(tab)
