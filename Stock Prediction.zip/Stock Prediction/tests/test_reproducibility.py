"""
Tests for reproducibility.set_all_seeds / run_manifest.

Confirms seeding is deterministic across RNGs and the manifest captures the
auditable fields. Network-free; manifest timestamp is injected for determinism.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import random

import numpy as np
import pandas as pd

import reproducibility as rp


def test_set_all_seeds_is_deterministic():
    rp.set_all_seeds(123)
    a_np, a_py = np.random.rand(5), [random.random() for _ in range(5)]
    rp.set_all_seeds(123)
    b_np, b_py = np.random.rand(5), [random.random() for _ in range(5)]
    assert np.allclose(a_np, b_np)
    assert a_py == b_py


def test_different_seed_differs():
    rp.set_all_seeds(1)
    a = np.random.rand(5)
    rp.set_all_seeds(2)
    b = np.random.rand(5)
    assert not np.allclose(a, b)


def test_set_all_seeds_returns_seed():
    assert rp.set_all_seeds(7) == 7


def test_manifest_fields_and_injectable_time():
    now = pd.Timestamp("2026-06-29T12:00:00Z")
    m = rp.run_manifest(ticker="RELIANCE.NS", interval="1d", horizon=5,
                        seed=42, fetched_at="2026-06-28", now=now,
                        training_rows=750)
    for key in ("seed", "python", "platform", "packages", "ticker",
                "interval", "horizon", "fetched_at", "run_at_utc"):
        assert key in m, key
    assert m["seed"] == 42
    assert m["ticker"] == "RELIANCE.NS"
    assert m["training_rows"] == 750            # extra field passed through
    assert m["run_at_utc"].startswith("2026-06-29T12:00:00")
    # Versions present for at least the core libs that are definitely installed.
    assert "numpy" in m["packages"] and "pandas" in m["packages"]


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All reproducibility tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
