"""
Tests for safe_fetch.fetch_with_fallback — retries, last-known-good cache, and
source-status tagging. Fully offline: the network call is injected, sleeps are
no-ops, and the cache is redirected to a temp dir.
"""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import safe_fetch
import data_quality as dq

_NOSLEEP = lambda _: None


def _df(n=400, end="2026-06-26", seed=1):
    rng = np.random.default_rng(seed)
    days = pd.bdate_range(end=end, periods=n)
    price = 1000 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    df = pd.DataFrame({
        "datetime": days, "open": price, "high": price * 1.003,
        "low": price * 0.997, "close": price, "adj_close": price,
        "volume": rng.integers(1e5, 1e6, n).astype(float),
    })
    df.attrs["fx_conversion"] = {"method": "none"}
    return df


def _isolate_cache():
    """Point the cache at a fresh temp dir; return a cleanup callable."""
    tmp = tempfile.mkdtemp(prefix="sf_test_")
    orig = safe_fetch._CACHE_DIR
    safe_fetch._CACHE_DIR = tmp
    def restore():
        safe_fetch._CACHE_DIR = orig
        shutil.rmtree(tmp, ignore_errors=True)
    return restore


def test_live_success_tags_live_and_caches():
    restore = _isolate_cache()
    try:
        out = safe_fetch.fetch_with_fallback(
            "ACME", "1d", fetch_fn=lambda c, i: _df(), sleep_fn=_NOSLEEP)
        assert out is not None and out.attrs["source"]["status"] == "live"
        assert os.path.exists(safe_fetch._cache_file("ACME", "1d"))
    finally:
        restore()


def test_retries_then_succeeds():
    restore = _isolate_cache()
    try:
        calls = {"n": 0}
        def flaky(c, i):
            calls["n"] += 1
            if calls["n"] < 3:
                raise ConnectionError("rate limited")
            return _df()
        out = safe_fetch.fetch_with_fallback(
            "ACME", "1d", fetch_fn=flaky, max_retries=3,
            backoff_base=0.0, sleep_fn=_NOSLEEP)
        assert out is not None and out.attrs["source"]["status"] == "live"
        assert out.attrs["source"]["attempts"] == 3
    finally:
        restore()


def test_falls_back_to_cache_on_failure():
    restore = _isolate_cache()
    try:
        # Prime the cache with one good live fetch.
        safe_fetch.fetch_with_fallback("ACME", "1d", fetch_fn=lambda c, i: _df(),
                                       sleep_fn=_NOSLEEP)
        # Now every fetch fails -> should return cached data.
        out = safe_fetch.fetch_with_fallback(
            "ACME", "1d", fetch_fn=lambda c, i: "Error: yfinance down",
            backoff_base=0.0, sleep_fn=_NOSLEEP)
        assert out is not None
        assert out.attrs["source"]["status"] == "cached_fallback"
        assert "cache_age_days" in out.attrs["source"]
    finally:
        restore()


def test_total_failure_returns_none():
    restore = _isolate_cache()
    try:
        out = safe_fetch.fetch_with_fallback(
            "NEVER_SEEN", "1d", fetch_fn=lambda c, i: None,
            backoff_base=0.0, sleep_fn=_NOSLEEP)
        assert out is None
    finally:
        restore()


def test_partial_detection():
    restore = _isolate_cache()
    try:
        safe_fetch.fetch_with_fallback("ACME", "1d", fetch_fn=lambda c, i: _df(400),
                                       sleep_fn=_NOSLEEP)
        out = safe_fetch.fetch_with_fallback(
            "ACME", "1d", fetch_fn=lambda c, i: _df(50), sleep_fn=_NOSLEEP)
        assert out.attrs["source"]["status"] == "partial"
    finally:
        restore()


def test_cached_fallback_forces_risk_cone_only_in_gate():
    # The data-quality gate must downgrade a cache-fallback serve to cone-only.
    df = _df()
    df.attrs["source"] = {"status": "cached_fallback", "cache_age_days": 1.2}
    r = dq.assess_data_quality(df, "1d", horizon=5,
                               now=pd.Timestamp("2026-06-28"))
    assert "SOURCE_CACHED_FALLBACK" in {c["code"] for c in r.codes}
    assert r.mode == "risk_cone_only"


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All safe_fetch tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
