"""
Volatility-model comparison: HAR-RV (linear) vs Vol-LSTM (deep) vs GARCH.

Book Ch. 5 ("Volatility Forecasting by LSTM") in driver form. The chapter's whole
experimental design is "build the LSTM, then benchmark it against an RNN and a
GARCH model using the cumulative squared error" — this driver runs that
comparison on this project's realized-variance setup, and adds the two things
that matter more than the book's plot:

1. **A robust variance loss.** Squared error on variance is dominated by the
   largest observations and is badly distorted by the noise in the ``r^2`` proxy.
   QLIKE (Patton 2011) is the loss shown to be robust to exactly that proxy
   noise, so it is reported alongside the book's cumulative squared error rather
   than instead of it. When the two disagree, believe QLIKE.
2. **Cone calibration, not just variance accuracy.** Both HAR-RV and Vol-LSTM
   ship a *conformal interval*, and the project's value lives in that interval.
   So the driver also runs the established coverage/width/CRPS machinery from
   ``calibration.py`` on both cones — the same A/B used for static-vs-ACI and the
   India-VIX tilt, so results are comparable to the README's existing tables.

The honest framing: a deep model beating a four-parameter OLS regression on ~900
daily bars is not the expected outcome. HAR-RV is famously hard to beat, and the
value of running this is to find out whether the LSTM's extra capacity (non-linear
dynamics, the leverage effect via the signed-return channel) buys anything at
this sample size — and to say so either way.

Usage:
    python run_vol_comparison.py [TICKER] [--quick] [--online]
        TICKER   : default RELIANCE.NS
        --quick  : fewer origins for a fast smoke run
        --online : enable Vol-LSTM's Ch. 5 online-learning fine-tune arm
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import calibration as cal
import vol_lstm_model as vl

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
_flags = {a for a in sys.argv[1:] if a.startswith("--")}
TICKER = _pos[0] if _pos else "RELIANCE.NS"
INTERVAL = "1d"
HORIZON = 5
QUICK = "--quick" in _flags
N_SPLITS = 4 if QUICK else 8
MIN_TRAIN = 400
MAX_ROWS = 1000
ONLINE_EPOCHS = 20 if "--online" in _flags else 0


def fetch(ticker):
    """Fetch daily OHLCV from yfinance, mapped to the project schema."""
    h = yf.Ticker(ticker).history(period="10y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    df = h[cols].dropna().reset_index(drop=True)
    return df.tail(MAX_ROWS).reset_index(drop=True)


# ==========================================
# GARCH reference (the book's benchmark)
# ==========================================
def garch_step_variance(returns, horizon):
    """
    Per-step variance forecast from the project's own GARCH selector.

    Reuses ``model_utils.select_best_garch`` (which searches GARCH / GJR /
    EGARCH across Normal / t / skew-t / GED by BIC) so the benchmark is the same
    volatility engine the ARIMA-GARCH model already ships — a fair fight rather
    than a straw-man GARCH(1,1). Falls back to EWMA if ``arch`` fails to fit.
    """
    r = np.asarray(returns, dtype=np.float64)
    try:
        from model_utils import select_best_garch
        # Scale to percent: `arch` optimises far more reliably on O(1) data.
        res = select_best_garch(r * 100.0)
        f = res.forecast(horizon=horizon, reindex=False)
        var_pct = np.asarray(f.variance.values)[-1, :]
        return var_pct / (100.0 ** 2)
    except Exception as exc:
        print(f"  (GARCH fit failed: {str(exc)[:80]} — using EWMA)")
        from HAR_RV_model import _fallback_variance
        return _fallback_variance(r, horizon)


def har_step_variance(returns, horizon, interval=INTERVAL):
    """Per-step variance from the HAR-RV regression (no cone, just the level)."""
    from HAR_RV_model import (_har_lags, fit_har, forecast_har_variance,
                              _fallback_variance, _EPS)
    lags = _har_lags('daily' if interval in ('1d', 'daily') else 'hourly')
    r = np.asarray(returns, dtype=np.float64)
    if len(r) < lags[2] + 15:
        return _fallback_variance(r, horizon)
    log_rv = np.log(r ** 2 + _EPS)
    lo, hi = np.percentile(log_rv, [1, 99])
    log_rv = np.clip(log_rv, lo, hi)
    coef, _ = fit_har(log_rv, lags)
    # level_offset defaults to har_level_offset(log_rv) — the data-estimated
    # log->level transform. This driver is what surfaced the old Jensen-based
    # transform's ~1.9x volatility over-statement (see the `bias_ratio` column).
    return forecast_har_variance(log_rv, coef, lags, horizon)


def lstm_step_variance(df_train, horizon, online_epochs=0):
    """
    Per-step variance from Vol-LSTM, read off its own output column.

    Uses the shipped orchestrator so the number scored here is exactly the number
    the app would serve (including the data-estimated level debiasing), rather
    than a re-implementation that could silently diverge.
    """
    out = vl.run_vol_lstm_prediction(df_train, INTERVAL, horizon,
                                     online_epochs=online_epochs)
    return np.asarray(out['volatility'].values, dtype=np.float64) ** 2


# ==========================================
# Variance-forecast scoring (book Ch. 5)
# ==========================================
def score_variance_forecasts(df, horizon=HORIZON, n_splits=N_SPLITS,
                             min_train=MIN_TRAIN):
    """
    Walk forward, collect each model's per-step variance forecast, and score it.

    Realised variance uses the same ``r^2`` proxy the models are fitted on, so
    the comparison is internally consistent. Both the book's cumulative squared
    error and the robust QLIKE loss are reported.

    Returns
    -------
    (pd.DataFrame, dict)
        ``(summary_table, cumulative_squared_error_curves)``.
    """
    prices = pd.to_numeric(df['adj_close'], errors='coerce').values.astype(float)
    n = len(prices)
    origins = np.unique(np.linspace(min_train, n - horizon - 1, n_splits,
                                    dtype=int))

    preds = {'HAR-RV': [], 'Vol-LSTM': [], 'GARCH': [], 'EWMA': []}
    actual = []

    from HAR_RV_model import _fallback_variance

    for o in origins:
        train_prices = prices[:o]
        train_ret = np.diff(np.log(train_prices[train_prices > 0]))
        realised = np.diff(np.log(prices[o - 1:o + horizon])) ** 2
        if len(realised) < horizon:
            continue

        try:
            har = har_step_variance(train_ret, horizon)
            lstm = lstm_step_variance(df.iloc[:o], horizon, ONLINE_EPOCHS)
            garch = garch_step_variance(train_ret, horizon)
            ewma = _fallback_variance(train_ret, horizon)
        except Exception as exc:
            print(f"  origin={o} skipped: {str(exc)[:100]}")
            continue

        actual.append(realised)
        preds['HAR-RV'].append(har)
        preds['Vol-LSTM'].append(lstm)
        preds['GARCH'].append(garch)
        preds['EWMA'].append(ewma)
        print(f"  origin={o}: realised vol {np.sqrt(realised.mean()):.4%} | "
              f"HAR {np.sqrt(har.mean()):.4%}  LSTM {np.sqrt(lstm.mean()):.4%}  "
              f"GARCH {np.sqrt(garch.mean()):.4%}")

    if not actual:
        return pd.DataFrame(), {}

    a = np.concatenate(actual)
    rows, curves = [], {}
    for name, chunks in preds.items():
        p = np.concatenate(chunks)
        curves[name] = vl.cumulative_squared_error(a, p)
        rows.append({
            'model': name,
            'qlike': round(vl.qlike_loss(a, p), 4),
            'cum_sq_error': float(f"{curves[name][-1]:.3e}"),
            'mean_forecast_vol_%': round(float(np.sqrt(p.mean()) * 100), 3),
            'mean_realised_vol_%': round(float(np.sqrt(a.mean()) * 100), 3),
            'bias_ratio': round(float(np.sqrt(p.mean() / a.mean())), 3),
        })
    table = pd.DataFrame(rows).sort_values('qlike').reset_index(drop=True)
    return table, curves


# ==========================================
# Cone calibration A/B
# ==========================================
def score_cones(df):
    """Coverage / width / CRPS of both conformal cones, via ``calibration``."""
    from HAR_RV_model import run_har_rv_prediction

    out = {}
    for name, fn, kwargs in (
        ("HAR-RV", run_har_rv_prediction, {}),
        ("Vol-LSTM", vl.run_vol_lstm_prediction,
         {"online_epochs": ONLINE_EPOCHS}),
    ):
        records, empirical = cal.collect_step_records(
            df, fn, INTERVAL, HORIZON, n_splits=N_SPLITS, min_train=MIN_TRAIN,
            predict_kwargs=kwargs, model_name=name)
        cq = cal.coverage_quality(records)
        cr = cal.crps_report(records, empirical)
        out[name] = {'coverage': cq, 'crps': cr, 'n': len(records)}
    return out


def main():
    print(f"=== Volatility model comparison | {TICKER} | horizon={HORIZON} | "
          f"splits={N_SPLITS}{' | online' if ONLINE_EPOCHS else ''} ===")
    df = fetch(TICKER)
    print(f"Fetched {len(df)} rows: {df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}\n")

    print("-" * 78)
    print("PART 1 — variance-forecast accuracy (book Ch. 5 benchmark)")
    print("-" * 78)
    table, curves = score_variance_forecasts(df)
    if table.empty:
        print("No origins produced a variance forecast.")
    else:
        print("\n" + table.to_string(index=False))
        print("\nRead: `qlike` is the ranking metric (robust to r^2 proxy noise); "
              "`cum_sq_error` is the book's plot as a single number. "
              "`bias_ratio` is forecast vol / realised vol — 1.0 is unbiased, "
              ">1 means the model systematically over-states volatility.")
        best = table.iloc[0]['model']
        print(f"Lowest QLIKE: {best}.")
        if 'Vol-LSTM' in table['model'].values:
            lstm_rank = int(table.index[table['model'] == 'Vol-LSTM'][0]) + 1
            print(f"Vol-LSTM ranks {lstm_rank} of {len(table)} — beating HAR-RV "
                  "on ~1000 daily bars would be a genuinely notable result; not "
                  "beating it is the expected outcome and is worth reporting "
                  "plainly.")

    print("\n" + "-" * 78)
    print("PART 2 — conformal cone calibration (where the product's value is)")
    print("-" * 78)
    cones = score_cones(df)
    for name, res in cones.items():
        print(f"\n{name}  ({res['n']} step records)")
        cq = res['coverage']
        if cq.empty:
            print("  (no intervals)")
            continue
        print(cq[['coverage', 'mean_width_%', 'tail_balance']].to_string())
        print(f"  mean |coverage-0.95| = "
              f"{np.mean(np.abs(cq['coverage'].values - 0.95)):.3f}   "
              f"mean width = {np.mean(cq['mean_width_%'].values):.2f}%")
        fh = res['crps'].get('final_horizon')
        if fh:
            print(f"  final-horizon CRPS: empirical {fh['crps_empirical']} vs "
                  f"log-normal {fh['crps_lognormal']}")

    if len(cones) == 2:
        a, b = cones['HAR-RV'], cones['Vol-LSTM']
        if not a['coverage'].empty and not b['coverage'].empty:
            ma = float(np.mean(np.abs(a['coverage']['coverage'].values - 0.95)))
            mb = float(np.mean(np.abs(b['coverage']['coverage'].values - 0.95)))
            wa = float(np.mean(a['coverage']['mean_width_%'].values))
            wb = float(np.mean(b['coverage']['mean_width_%'].values))
            print(f"\nVERDICT  miscoverage: HAR-RV {ma:.3f} vs Vol-LSTM {mb:.3f} | "
                  f"width: {wa:.2f}% vs {wb:.2f}%")
            if mb < ma and wb <= wa * 1.02:
                v = "Vol-LSTM is better calibrated at comparable or better sharpness"
            elif abs(mb - ma) < 0.01:
                v = ("a tie on coverage — compare width; the conformal layer "
                     "equalises calibration, so any difference is sharpness")
            else:
                v = "HAR-RV holds up — the four-parameter regression is hard to beat"
            print(f"-> {v}.")

    print("\nDone. Note that both cones are conformally calibrated, so coverage "
          "tends to equalise by construction; the informative differences are "
          "interval WIDTH (sharpness) and the raw variance QLIKE in Part 1.")


if __name__ == "__main__":
    main()
