"""
Run the walk-forward backtest across the full model suite on real stock data.

Fetches real daily prices via yfinance, then evaluates every ``run_*`` model
with ``backtest.walk_forward_backtest`` and writes a leaderboard. Results are
checkpointed to CSV after each model, and already-completed models are skipped
on re-launch, so the run is resumable if interrupted.

Usage:
    python run_full_backtest.py [TICKER] [--with-context]
        --with-context : attach market/VIX features (off by default).
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import os
import sys
import time
import traceback
import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import backtest as bt

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
TICKER = _pos[0] if _pos else "AAPL"
INTERVAL = "1d"
HORIZON = 5
N_SPLITS = 3
MIN_TRAIN = 400
MAX_ROWS = 700           # cap history so each re-fit stays bounded
OUT_CSV = f"backtest_{TICKER}.csv"


def fetch(ticker):
    """Fetch daily OHLCV from yfinance and map to the project schema."""
    h = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    df = h[cols].dropna().reset_index(drop=True)
    return df.tail(MAX_ROWS).reset_index(drop=True)


def build_registry():
    """(name, callable, predict_kwargs) for every model in the suite."""
    from ML_model import run_ML_prediction
    from Quantile_model import run_quantile_prediction
    from Ensemble_model import run_ensemble_prediction
    from ARIMA_GARCH import run_statistical_prediction
    from ARIMAX_model import run_arimax_prediction
    from fb_prophet_model import run_prophet_prediction
    from RegimeSwitching_model import run_regime_prediction
    from Hybrid_model import run_hybrid_prediction
    from HAR_RV_model import run_har_rv_prediction
    from DL_model import run_DL_prediction
    from Transformer_model import run_transformer_prediction
    from TCN_model import run_tcn_prediction
    from NBeats_model import run_nbeats_prediction
    from meta_ensemble import run_meta_ensemble_prediction

    # Ordered fast -> slow so the leaderboard fills in quickly.
    return [
        ("XGBoost",          run_ML_prediction,          {"model_type": "xgboost"}),
        ("LightGBM",         run_ML_prediction,          {"model_type": "lightgbm"}),
        ("Quantile-LGBM",    run_quantile_prediction,    {}),
        ("Ensemble-Stack",   run_ensemble_prediction,    {}),
        ("Meta-Ensemble",    run_meta_ensemble_prediction, {}),
        ("ARIMA+GARCH",      run_statistical_prediction, {}),
        ("ARIMAX+GARCH",     run_arimax_prediction,      {}),
        ("Prophet",          run_prophet_prediction,     {}),
        ("RegimeSwitching",  run_regime_prediction,      {}),
        ("HAR-RV",           run_har_rv_prediction,      {}),
        ("Hybrid-ARIMA+LSTM", run_hybrid_prediction,     {}),
        ("LSTM",             run_DL_prediction,          {"model_type": "LSTM"}),
        ("GRU",              run_DL_prediction,          {"model_type": "GRU"}),
        ("Transformer",      run_transformer_prediction, {}),
        ("TCN",              run_tcn_prediction,         {}),
        ("N-BEATS",          run_nbeats_prediction,      {}),
    ]


def main():
    print(f"=== Full-suite walk-forward backtest | {TICKER} | "
          f"horizon={HORIZON} | splits={N_SPLITS} ===")
    df = fetch(TICKER)
    print(f"Fetched {len(df)} rows: {df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}")

    # Market/VIX context is opt-in (--with-context): the A/B backtest showed it
    # doesn't help at this horizon. When enabled, enrich once; the harness slices
    # the enriched df row-wise so the per-row context stays aligned (no per-split
    # fetch).
    if "--with-context" in sys.argv:
        from market_context import add_market_context
        df = add_market_context(df, INTERVAL)
        print("Market-context features ENABLED.")

    # Resume support: keep results from a prior (interrupted) run.
    rows = []
    done = set()
    if os.path.exists(OUT_CSV):
        prior = pd.read_csv(OUT_CSV)
        rows = prior.to_dict("records")
        done = set(prior["model"])
        print(f"Resuming: {len(done)} models already done -> {sorted(done)}")

    for name, fn, kw in build_registry():
        if name in done:
            continue
        t0 = time.time()
        try:
            res = bt.walk_forward_backtest(
                df, fn, INTERVAL, HORIZON,
                n_splits=N_SPLITS, min_train=MIN_TRAIN,
                predict_kwargs=kw, model_name=name, verbose=False,
            )
            s = res["summary"]
            dm = res.get("dm", {})
            cov = s.loc["coverage", "model"] if "coverage" in s.index else np.nan

            def _ref(col):
                return round(s.loc["rmse", col], 4) if col in s.columns else np.nan

            row = {
                "model": name,
                "mase": round(s.loc["mase", "model"], 4),
                "rmse": round(s.loc["rmse", "model"], 4),
                "naive_rmse": _ref("naive"),
                "drift_rmse": _ref("drift"),
                "ar1_rmse": _ref("ar1"),
                "beats_naive": bool(s.loc["rmse", "model"] < s.loc["rmse", "naive"]),
                "dm_p": (round(dm["p_value"], 4)
                         if dm and np.isfinite(dm.get("p_value", np.nan)) else np.nan),
                "dm_sig": (dm.get("favors") or "ns") if dm else "ns",
                "dir_acc": round(s.loc["directional_accuracy", "model"], 4),
                "coverage": (round(cov, 4) if not np.isnan(cov) else np.nan),
                "secs": round(time.time() - t0, 1),
                "error": "",
            }
        except Exception as exc:
            traceback.print_exc()
            row = {
                "model": name, "mase": np.nan, "rmse": np.nan,
                "naive_rmse": np.nan, "drift_rmse": np.nan, "ar1_rmse": np.nan,
                "beats_naive": False, "dm_p": np.nan, "dm_sig": "ns",
                "dir_acc": np.nan, "coverage": np.nan,
                "secs": round(time.time() - t0, 1), "error": str(exc)[:150],
            }
        rows.append(row)
        pd.DataFrame(rows).to_csv(OUT_CSV, index=False)   # checkpoint
        print(f"DONE {name:18} mase={row['mase']} rmse={row['rmse']} "
              f"beats_naive={row['beats_naive']} dir_acc={row['dir_acc']} "
              f"({row['secs']}s)")

    lb = pd.DataFrame(rows).sort_values("rmse", na_position="last")
    print("\n================ LEADERBOARD (sorted by RMSE) ================")
    print(lb.to_string(index=False))
    print(f"\nNaive random-walk RMSE reference: "
          f"{lb['naive_rmse'].dropna().iloc[0] if lb['naive_rmse'].notna().any() else 'n/a'}")
    beat = lb[lb["beats_naive"] == True]["model"].tolist()
    print(f"Models that beat the random walk (RMSE): {beat if beat else 'NONE'}")


if __name__ == "__main__":
    main()
