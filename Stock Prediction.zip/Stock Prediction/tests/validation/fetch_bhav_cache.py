"""
One-time bulk fetch: populate the bhavcopy day cache for the study window.

Why a separate script rather than a flag on the panel builder
-------------------------------------------------------------
This is the only genuinely slow step in the whole universe-expansion effort
(~0.8 s/day, so ~33 minutes for a decade) and it is *pure I/O*. Separating it
means the panel build, the liquidity screen and every experiment downstream run
against a local cache in seconds, and can be re-run freely while iterating.

It deliberately does **not** accumulate the panel in memory. 2,500 days x ~1,900
names is ~4.8M rows; holding that while also downloading is how a long job dies
at hour two. Each day is fetched, written to its own cache file and dropped.

Run::

    python tests/validation/fetch_bhav_cache.py                  # 2017-01-01 .. today
    python tests/validation/fetch_bhav_cache.py 2018-01-01 2020-12-31

Re-running is cheap and safe: cached days are skipped, so an interrupted run
resumes where it stopped.
"""

import os
import sys
import time

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc          # noqa: E402


def main(start="2017-01-01", end=None):
    end = end or pd.Timestamp.today().normalize().strftime("%Y-%m-%d")
    days = pd.bdate_range(pd.Timestamp(start), pd.Timestamp(end))
    print(f"bhavcopy cache: {start} -> {end}  ({len(days)} business days)")
    print(f"cache dir: {bc.CACHE_DIR}")

    import requests
    sess = requests.Session()
    t0 = time.time()
    have = miss = fresh = 0

    for i, d in enumerate(days):
        cached = os.path.exists(bc._cache_path(d, bc.CACHE_DIR))
        f = bc.fetch_day(d, session=sess)
        if not cached:
            fresh += 1
        if f is None or not len(f):
            miss += 1
        else:
            have += 1
        if (i + 1) % 100 == 0:
            el = time.time() - t0
            rate = el / (i + 1)
            eta = rate * (len(days) - i - 1) / 60
            print(f"  {i + 1:5d}/{len(days)}  with-data={have:5d} "
                  f"empty={miss:4d}  {rate:.2f}s/day  ETA {eta:.0f} min")

    el = time.time() - t0
    print(f"\ndone in {el / 60:.1f} min | days with data: {have} | "
          f"empty (weekend/holiday): {miss} | newly fetched: {fresh}")
    return 0


if __name__ == "__main__":
    a = sys.argv[1:]
    sys.exit(main(*a) if a else main())
