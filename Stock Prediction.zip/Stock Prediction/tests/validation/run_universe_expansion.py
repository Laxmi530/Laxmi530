"""
Universe expansion: the power experiment, run on survivorship-free data.

The question
------------
Every cross-sectional null in this project was measured on 39 names. The
Fama-MacBeth rank IC came in at +0.0111 with **t = 0.92** — the right sign,
comfortably inside noise. That was read at the time as a *power* result rather
than evidence against the approach, because real cross-sectional ICs are
0.02-0.05 and detecting one needs roughly 55-60 validation names for t = 2.

This driver tests that reading directly. It runs the identical experiment —
identical features, identical labels, identical split rule, identical model — at
several universe sizes, and reports the IC and its t-statistic as a function of
breadth. Nothing else varies, so any change is attributable to breadth alone.

Two outcomes, both informative
------------------------------
* **The t-statistic rises with N and crosses 2.** The 39-name nulls were an
  artefact of sample size, and there is cross-sectional signal here.
* **The IC stays near zero as N grows.** Then the power explanation is
  exhausted: with adequate breadth the test *could* have rejected and did not.
  That is a far stronger null than any previously recorded here, and it closes
  the cross-sectional question rather than deferring it again.

The second outcome is the more likely one, on the evidence of ten prior negative
results. It is still worth running, because it is the difference between "too
small to tell" and "measured".

Why the data source matters
---------------------------
Run on yfinance the experiment would be *quietly wrong*: 26.8% of the 2017 NSE
universe is absent from today's listing file, so a 200-name universe drawn from
it would consist entirely of companies selected for having survived the study
window. This driver reads :mod:`bhavcopy` instead, where membership is whatever
actually traded on each day.

Run::

    python tests/validation/run_universe_expansion.py
    python tests/validation/run_universe_expansion.py --sizes 39,100,200,400
    python tests/validation/run_universe_expansion.py --quick

Requires the day cache: ``python tests/validation/fetch_bhav_cache.py`` first.
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                       # noqa: E402
import cross_sectional_panel as csp         # noqa: E402
import cross_sectional_model as csm         # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


QUICK = "--quick" in sys.argv
START = _arg("--start", "2018-01-01")
END = _arg("--end", "2026-06-30")
HORIZON = int(_arg("--horizon", "5"))
SIZES = [int(x) for x in _arg("--sizes",
                              "39,100" if QUICK else "39,100,200,400").split(",")]
SEED = int(_arg("--seed", "42"))


def run_one(n, actions, cache_ok=True):
    """Build, fit and evaluate at universe size ``n``. Returns a result dict."""
    print(f"\n{'=' * 78}\nUNIVERSE SIZE: {n}\n{'=' * 78}")

    panel, brep = bc.build_panel(START, END, n=n, actions=actions,
                                 verbose=True)
    if panel.empty:
        print("  no data — is the bhavcopy cache populated?")
        return None
    print(f"  panel: {brep['n_rows']:,} rows | {brep['n_symbols']} names | "
          f"{brep['n_dates']} dates")

    # Route through the existing cross-sectional pipeline unchanged.
    cs, rep = csp.build_panel(tickers=brep["universe"],
                              fetch_fn=bc.bhav_fetcher(panel),
                              verbose=False)
    if cs.empty:
        print("  cross-sectional panel empty after min_rows filter")
        return None
    print(f"  usable: {rep['n_tickers']} names ({rep['start']} -> {rep['end']}); "
          f"{len(rep['dropped'])} dropped for short history")

    feat = csp.add_ticker_features(cs)
    feat = csp.add_cross_sectional_ranks(feat)
    lab = csp.add_labels(feat, horizon=HORIZON)
    cols = csp.feature_columns(lab)
    print(f"  {len(lab):,} labelled rows, {len(cols)} features")

    s = csp.split_panel(lab, mode="combined", seed=SEED, embargo=HORIZON)
    print(f"  train {s['n_train']:,} rows / {len(s['train_tickers'])} names | "
          f"val {s['n_val']:,} rows / {len(s['val_tickers'])} names")

    if s["n_val"] < 200 or s["n_train"] < 1000:
        print("  WARNING: split too small to read as a result.")

    bundle = csm.fit_calibrated(s["train"], cols, seed=SEED)
    res = csm.evaluate(bundle, s["val"], horizon=HORIZON)

    print("\n" + csm.format_report(bundle, res))

    return {
        "n_requested": n,
        "n_usable": rep["n_tickers"],
        "n_val_names": len(s["val_tickers"]),
        "n_val_rows": s["n_val"],
        "ic_dates": res.get("ic_n_dates"),
        "rank_ic_fm": res.get("rank_ic_fm"),
        "t_stat": res.get("rank_ic_t"),
        "t_pooled": res.get("rank_ic_t_pooled"),
        "abstain": res.get("abstain_rate"),
        "long_short": res.get("long_short_spread"),
        "macro_f1": res.get("macro_f1"),
        "ece": res.get("ece"),
    }


def main():
    print("=" * 78)
    print("UNIVERSE EXPANSION  --  does the cross-sectional null survive power?")
    print("=" * 78)
    print(f"window {START} .. {END} | horizon {HORIZON}d | sizes {SIZES}")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print(f"\nNo bhavcopy cache at {bc.CACHE_DIR!r}.")
        print("Run: python tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nfetching corporate actions once for every run ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    print(f"  {len(actions)} actions "
          f"({int((actions['factor'] != 1).sum())} split/bonus, "
          f"{int((actions['dividend'] > 0).sum())} dividend)")

    out = []
    for n in SIZES:
        try:
            r = run_one(n, actions)
        except Exception as exc:
            print(f"  FAILED at n={n}: {type(exc).__name__}: {exc}")
            r = None
        if r:
            out.append(r)

    if not out:
        print("\nNo runs completed.")
        return 1

    tab = pd.DataFrame(out)
    print("\n" + "=" * 78)
    print("SUMMARY  --  rank IC and its t-statistic vs universe breadth")
    print("=" * 78)
    print(f"{'req':>5s}{'usable':>8s}{'val names':>11s}{'val rows':>10s}"
          f"{'IC dates':>10s}{'rank IC':>10s}{'FM t':>8s}{'abstain':>9s}")
    for _, r in tab.iterrows():
        print(f"{r['n_requested']:5.0f}{r['n_usable']:8.0f}"
              f"{r['n_val_names']:11.0f}{r['n_val_rows']:10.0f}"
              f"{r['ic_dates']:10.0f}{r['rank_ic_fm']:+10.4f}"
              f"{r['t_stat']:8.2f}{r['abstain']:9.4f}")

    print("\nReading this table")
    print("-" * 78)
    print("The t-statistic is the number that matters, not the IC. If |t| climbs")
    print("toward 2 as validation names grow, the earlier nulls were a power")
    print("artefact. If it stays flat near zero while breadth multiplies, the")
    print("power explanation is spent and the cross-sectional question is")
    print("answered rather than deferred.")

    ok = tab.dropna(subset=["t_stat"])
    if len(ok) >= 2:
        first, last = ok.iloc[0], ok.iloc[-1]
        print(f"\n  |t| at {first['n_val_names']:.0f} val names : "
              f"{abs(first['t_stat']):.2f}")
        print(f"  |t| at {last['n_val_names']:.0f} val names : "
              f"{abs(last['t_stat']):.2f}")
        if abs(last["t_stat"]) >= 2.0:
            print("\n  => significant at the conventional threshold. This would be")
            print("     the first positive result in this project; treat it as a")
            print("     lead to be re-tested out of sample, not a conclusion.")
        else:
            print("\n  => still not significant. With adequate breadth the test")
            print("     could have rejected and did not.")

    csv = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "universe_expansion.csv")
    tab.to_csv(csv, index=False)
    print(f"\nsaved: {csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
