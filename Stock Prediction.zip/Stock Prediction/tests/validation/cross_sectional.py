"""
Cross-sectional (ranking) signal evaluation — a research probe, separate from
the single-ticker forecasting app.

Both market-data experiments on the absolute-price forecaster failed for the
same structural reason: relative/market information helps you rank stocks
*against each other*, not predict one stock's absolute price (the unforecastable
market move dominates and is re-injected at reconstruction). This module tests
the other framing directly: each day, score every stock in a universe with a
signal computed only from past data, then ask whether higher-scored stocks
actually out-perform lower-scored ones over the next h days.

Two standard, model-free metrics:

* **Rank Information Coefficient (rank-IC)** — the Spearman rank correlation,
  computed *across stocks on each date*, between the signal and the realised
  forward return, then averaged over dates. A small but consistently positive
  rank-IC (say 0.02-0.05 with a healthy t-stat) is the textbook signature of a
  usable cross-sectional factor.
* **Long-short quintile spread** — sort stocks into quintiles by the signal each
  date; the mean forward return of the top quintile minus the bottom quintile.
  This is the return a (costless, idealised) long-short book would have earned.

Leakage control: the signal at date t uses only prices up to t; the forward
return spans t -> t+h (strictly future). Because overlapping h-day forward
windows make consecutive dates autocorrelated (which would inflate t-stats),
significance is computed on **non-overlapping** evaluation dates (stride h).
This is a probe for *whether signal exists*, not a tradeable backtest — it has
no transaction costs, liquidity, or borrow constraints.
"""

import numpy as np
import pandas as pd


def build_panel(price_dict, horizons=(5, 21)):
    """
    Assemble a long-format panel of log prices and forward returns.

    Parameters
    ----------
    price_dict : dict[str, pd.DataFrame]
        Ticker -> DataFrame with 'datetime' and 'adj_close'.
    horizons : tuple of int, optional
        Forward-return horizons (in bars) to compute. Default (5, 21).

    Returns
    -------
    pd.DataFrame
        Columns: datetime, ticker, adj_close, logp, fwd_{h} for each horizon.
        Forward return fwd_h at t is logp[t+h] - logp[t] (strictly future).
    """
    frames = []
    for tk, df in price_dict.items():
        if df is None or 'adj_close' not in getattr(df, 'columns', []):
            continue
        d = df[['datetime', 'adj_close']].copy()
        d['datetime'] = pd.to_datetime(d['datetime']).dt.normalize()
        d['adj_close'] = pd.to_numeric(d['adj_close'], errors='coerce')
        d = (d.dropna(subset=['adj_close'])
               .sort_values('datetime')
               .drop_duplicates('datetime'))
        d = d[d['adj_close'] > 0]
        if len(d) < 260:
            continue
        d['ticker'] = tk
        d['logp'] = np.log(d['adj_close'].values)
        for h in horizons:
            d[f'fwd_{h}'] = d['logp'].shift(-h) - d['logp']
        frames.append(d)
    if not frames:
        raise ValueError("No usable tickers in price_dict.")
    return pd.concat(frames, ignore_index=True)


def add_signals(panel):
    """
    Add classic, past-only cross-sectional signals to the panel.

    All signals are computed per ticker from past log prices, so they are known
    at the evaluation date and contain no look-ahead:

    - ``mom_252_21`` — 12-1 momentum: trailing ~12-month return excluding the
      most recent month (the canonical equity momentum factor).
    - ``mom_21`` — 1-month momentum (trailing ~21 bars).
    - ``rev_5`` — short-term reversal: the negative of the trailing 5-bar return
      (recent losers tend to bounce).
    - ``vol_21`` — trailing 21-bar return volatility (a low-volatility-factor
      proxy; tested as a negative-signed signal below).

    Parameters
    ----------
    panel : pd.DataFrame
        Output of :func:`build_panel`.

    Returns
    -------
    pd.DataFrame
        Panel with the signal columns added.
    """
    panel = panel.sort_values(['ticker', 'datetime']).copy()
    g = panel.groupby('ticker')['logp']
    panel['mom_252_21'] = g.shift(21) - g.shift(252)
    panel['mom_21'] = panel['logp'] - g.shift(21)
    panel['rev_5'] = -(panel['logp'] - g.shift(5))
    ret1 = panel['logp'] - g.shift(1)
    panel['vol_21'] = (
        ret1.groupby(panel['ticker']).rolling(21).std()
        .reset_index(level=0, drop=True)
    )
    return panel


def _eval_dates(panel, horizon, non_overlapping):
    """Sorted unique dates, optionally thinned to a non-overlapping stride h."""
    dates = np.sort(panel['datetime'].unique())
    if non_overlapping and horizon > 1:
        dates = dates[::horizon]
    return dates


def rank_ic(panel, signal, horizon, min_names=5, non_overlapping=True):
    """
    Mean cross-sectional rank Information Coefficient of a signal.

    For each evaluation date the Spearman rank correlation between ``signal`` and
    the ``fwd_{horizon}`` return is computed across stocks; the mean and a t-stat
    (mean / standard error over dates) summarise it. With ``non_overlapping`` the
    dates are thinned to a stride of ``horizon`` so overlapping forward windows
    don't inflate the t-stat.

    Returns
    -------
    dict
        {'ic_mean', 't_stat', 'n_dates', 'hit_rate'} where hit_rate is the
        fraction of dates with positive IC.
    """
    fwd = f'fwd_{horizon}'
    sub = panel.dropna(subset=[signal, fwd])
    ics = []
    for dt in _eval_dates(sub, horizon, non_overlapping):
        grp = sub[sub['datetime'] == dt]
        if len(grp) >= min_names:
            ic = grp[[signal, fwd]].corr(method='spearman').iloc[0, 1]
            if np.isfinite(ic):
                ics.append(ic)
    ics = np.asarray(ics, dtype=float)
    n = len(ics)
    if n < 2:
        return {'ic_mean': float('nan'), 't_stat': float('nan'),
                'n_dates': n, 'hit_rate': float('nan')}
    mean = float(ics.mean())
    sd = float(ics.std(ddof=1))
    t = mean / (sd / np.sqrt(n)) if sd > 0 else float('nan')
    return {'ic_mean': mean, 't_stat': float(t), 'n_dates': n,
            'hit_rate': float((ics > 0).mean())}


def long_short_spread(panel, signal, horizon, quantiles=5, min_names=10,
                      non_overlapping=True):
    """
    Mean top-minus-bottom quintile forward return for a signal.

    Each evaluation date, stocks are sorted into ``quantiles`` buckets by the
    signal; the spread is the top bucket's mean forward return minus the bottom
    bucket's. Reported as the per-period mean spread (in log-return units), its
    t-stat over dates, and the fraction of dates the spread was positive.

    Returns
    -------
    dict
        {'spread_mean', 't_stat', 'n_dates', 'hit_rate'}.
    """
    fwd = f'fwd_{horizon}'
    sub = panel.dropna(subset=[signal, fwd])
    spreads = []
    for dt in _eval_dates(sub, horizon, non_overlapping):
        grp = sub[sub['datetime'] == dt]
        if len(grp) >= max(min_names, quantiles * 2):
            ranks = grp[signal].rank(method='first')
            buckets = pd.qcut(ranks, quantiles, labels=False)
            top = grp[fwd][buckets == quantiles - 1].mean()
            bot = grp[fwd][buckets == 0].mean()
            if np.isfinite(top) and np.isfinite(bot):
                spreads.append(top - bot)
    spreads = np.asarray(spreads, dtype=float)
    n = len(spreads)
    if n < 2:
        return {'spread_mean': float('nan'), 't_stat': float('nan'),
                'n_dates': n, 'hit_rate': float('nan')}
    mean = float(spreads.mean())
    sd = float(spreads.std(ddof=1))
    t = mean / (sd / np.sqrt(n)) if sd > 0 else float('nan')
    return {'spread_mean': mean, 't_stat': float(t), 'n_dates': n,
            'hit_rate': float((spreads > 0).mean())}
