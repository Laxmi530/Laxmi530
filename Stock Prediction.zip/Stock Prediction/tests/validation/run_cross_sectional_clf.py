"""
Cross-sectional 3-class classifier over a pooled NSE universe (book Ch. 6).

The complement to ``run_cross_sectional.py``, which probes raw signals (rank-IC,
long-short spread) without a model. This driver builds the pooled panel, fits the
calibrated 3-class classifier, and evaluates it on **unseen names in unseen
dates**.

Why this is the one experiment that could change the project's verdict
----------------------------------------------------------------------
Every "no edge" result here — SPA p = 0.87, MASE > 1, six of seven models losing
money — was measured on ~1000 rows of a *single* ticker. That is the binding
constraint, and no additional architecture fixes it. Pooling changes both the
sample size and the question: not "what will this stock do?" (an absolute
forecast, which the evidence says is a random walk) but "which of these names
will outperform the others?" (a relative forecast, which has a far better
documented empirical basis).

What to look at, in order
-------------------------
1. **rank IC and its t-stat.** The factor-research standard. Real cross-sectional
   ICs are *small* — 0.02-0.05 is a genuine signal — so the t-stat matters more
   than the value. This project's earlier probe found the right sign at t ≈ 1 and
   concluded it needed hundreds of names; the default universe here is 40, so a
   null result is the expected outcome and is not evidence against the approach.
2. **long-short spread.** The economic read: mean forward excess return of the
   names called "buy" minus those called "short".
3. **ECE before and after calibration.** The project's derived P(up) scored
   ECE ≈ 0.31. If the calibrated classifier lands near 0.02-0.05, the honest
   probability problem is solved even if the *skill* problem is not — and those
   are separate wins.
4. **accuracy — last, and only next to the majority baseline.** The neutral class
   is the largest, so a model predicting "do nothing" always scores well.
   Macro F1 is the number that exposes that.

Usage:
    python run_cross_sectional_clf.py [--n N] [--horizon H] [--mode M] [--quick]
        --n N       : universe size (default 40, the full DEFAULT_UNIVERSE)
        --horizon H : label horizon in trading days (default 5)
        --mode M    : 'combined' (default) | 'asset' | 'time'
        --quick     : 12 tickers, for a fast smoke run
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

import cross_sectional_panel as csp
import cross_sectional_model as csm

warnings.filterwarnings("ignore")


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


QUICK = "--quick" in sys.argv
N = _arg("--n", 12 if QUICK else len(csp.DEFAULT_UNIVERSE))
HORIZON = _arg("--horizon", 5)
MODE = _arg("--mode", "combined", str)


def main():
    universe = csp.DEFAULT_UNIVERSE[:N]
    print(f"=== Cross-sectional classifier | {len(universe)} NSE names | "
          f"horizon={HORIZON}d | split={MODE} ===\n")

    print("Building panel...")
    panel, rep = csp.build_panel(universe, verbose=False)
    if panel.empty:
        print("No data fetched — cannot continue.")
        return
    print(f"  {rep['n_rows']:,} rows x {rep['n_tickers']} tickers "
          f"({rep['start']} -> {rep['end']})")
    if rep["dropped"]:
        print(f"  dropped {len(rep['dropped'])}: {list(rep['dropped'])[:5]}"
              f"{' ...' if len(rep['dropped']) > 5 else ''}")

    print("\nEngineering features...")
    feat = csp.add_ticker_features(panel)
    feat = csp.add_cross_sectional_ranks(feat)
    lab = csp.add_labels(feat, horizon=HORIZON)
    cols = csp.feature_columns(lab)
    print(f"  {len(lab):,} labelled rows, {len(cols)} features")
    dist = lab["label"].value_counts(normalize=True).sort_index()
    print(f"  class balance: short {dist.get(-1, 0):.2f} / "
          f"nothing {dist.get(0, 0):.2f} / buy {dist.get(1, 0):.2f}")

    print(f"\nSplitting ({MODE})...")
    s = csp.split_panel(lab, mode=MODE, seed=42, embargo=HORIZON)
    print(f"  train {s['n_train']:,} rows / {len(s['train_tickers'])} tickers")
    print(f"  val   {s['n_val']:,} rows / {len(s['val_tickers'])} tickers")
    if s["split_date"]:
        print(f"  split date: {s['split_date']}")
    if MODE in ("asset", "combined"):
        print(f"  val tickers (never seen in training): "
              f"{', '.join(s['val_tickers'][:8])}"
              f"{' ...' if len(s['val_tickers']) > 8 else ''}")
    if s["n_val"] < 200 or s["n_train"] < 1000:
        print("\n  WARNING: the split is very small; treat everything below as "
              "a smoke test, not a result.")

    print("\nFitting calibrated classifier...")
    bundle = csm.fit_calibrated(s["train"], cols, seed=42)

    print("\nEvaluating on unseen names / unseen dates...")
    res = csm.evaluate(bundle, s["val"], horizon=HORIZON)

    print("\n" + "=" * 78)
    print(csm.format_report(bundle, res))
    print("=" * 78)

    if not res.get("reliability", pd.DataFrame()).empty:
        print("\n-- Reliability of P(buy) (predicted vs observed) --")
        print(res["reliability"].to_string(index=False))
        print("  A calibrated column has 'gap' near zero in every populated bin.")

    if res.get("confusion") is not None and len(res["confusion"]):
        print("\n-- Confusion matrix --")
        print(res["confusion"].to_string())

    print("\n" + "-" * 78)
    print("How to read this")
    print("-" * 78)
    print("* rank IC with |t| < 2 is NOISE, whatever its sign. Real cross-"
          "sectional ICs are small (0.02-0.05) and need hundreds of names to "
          "detect; 40 is not hundreds.")
    print("* A good ECE with a null rank IC is still a win: it means the "
          "probabilities are honest even though the signal is absent. Those are "
          "separate problems and this fixes exactly one of them.")
    print("* Accuracy alone is meaningless here — the neutral class is the "
          "largest. Read macro F1 and the majority baseline next to it.")
    print("* Before believing any positive result: re-run with --mode asset and "
          "--mode time, on a different seed, and on a larger universe. A signal "
          "that survives only one split is a split artifact.")
    print("\nDone.")


if __name__ == "__main__":
    main()
