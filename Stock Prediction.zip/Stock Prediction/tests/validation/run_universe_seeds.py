"""
Seed robustness for the universe-expansion result.

Why this exists
---------------
``run_universe_expansion.py`` produced the first positive cross-sectional result
in this project: rank IC +0.0396 at **Fama-MacBeth t = 2.24** on 100 unseen
names. Before that can be reported as a finding it has to survive the objection
that killed a comparable number in [section 30] -- **it is one seed**.

The split is seeded. ``split_panel(mode='combined', seed=S)`` draws 30% of the
universe as validation names, so the seed decides *which* names the model is
scored on. Section 30 already recorded a case where seed 2024 gave a pooled
t = 2.43 -- reportable as a finding -- while the honest Fama-MacBeth read gave
1.69, noise. One seed is one draw.

The table from the size sweep carries its own warning:

    names   39    100    200    400
    FM t   1.31   0.24   2.37   2.24

Under a pure power story ``t`` should climb roughly with the square root of the
validation count. **It does not.** The dip at 100 is larger than sampling noise
should comfortably allow, which says the variance across universe draws is
substantial -- exactly the thing a single seed cannot see.

What this driver does
---------------------
Builds the panel and the features **once** (that is the expensive part, and it
does not depend on the seed), then re-splits, re-fits and re-evaluates across
many seeds. Only the split varies, so the spread in ``t`` is a direct read of how
much the headline number depends on which names happened to land in the holdout.

How to read the output
----------------------
* **median |t| well above 2, most seeds significant** -- the result is about the
  data, not the draw.
* **median near 2 with seeds scattered either side** -- marginal. The honest
  report is the distribution, not the best seed.
* **a few large seeds carrying an otherwise null distribution** -- the original
  2.24 was a lucky draw, and reporting it would have been the project's first
  false positive.

Run::

    python tests/validation/run_universe_seeds.py
    python tests/validation/run_universe_seeds.py --n 200 --seeds 10
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                       # noqa: E402
import cross_sectional_panel as csp         # noqa: E402
import cross_sectional_model as csm         # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "400"))
HORIZON = int(_arg("--horizon", "5"))
N_SEEDS = int(_arg("--seeds", "8"))


def main():
    print("=" * 78)
    print("UNIVERSE EXPANSION -- SEED ROBUSTNESS")
    print("=" * 78)
    print(f"window {START} .. {END} | n={N} | horizon={HORIZON}d | "
          f"{N_SEEDS} seeds")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print(f"\nNo bhavcopy cache at {bc.CACHE_DIR!r}. Run "
              "tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nfetching corporate actions ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    print(f"  {len(actions)} actions")

    print("building panel (once -- it does not depend on the seed) ...")
    panel, brep = bc.build_panel(START, END, n=N, actions=actions,
                                 verbose=False)
    cs, rep = csp.build_panel(tickers=brep["universe"],
                              fetch_fn=bc.bhav_fetcher(panel), verbose=False)
    feat = csp.add_ticker_features(cs)
    feat = csp.add_cross_sectional_ranks(feat)
    lab = csp.add_labels(feat, horizon=HORIZON)
    cols = csp.feature_columns(lab)
    print(f"  {rep['n_tickers']} usable names | {len(lab):,} labelled rows | "
          f"{len(cols)} features")

    rows = []
    for k in range(N_SEEDS):
        seed = 100 + k * 7            # spread out, not 0..n
        s = csp.split_panel(lab, mode="combined", seed=seed, embargo=HORIZON)
        try:
            bundle = csm.fit_calibrated(s["train"], cols, seed=seed)
            res = csm.evaluate(bundle, s["val"], horizon=HORIZON)
        except Exception as exc:
            print(f"  seed {seed}: FAILED {type(exc).__name__}: {exc}")
            continue
        rows.append({
            "seed": seed,
            "val_names": len(s["val_tickers"]),
            "val_rows": s["n_val"],
            "rank_ic": res.get("rank_ic_fm"),
            "t": res.get("rank_ic_t"),
            "abstain": res.get("abstain_rate"),
            "long_short": res.get("long_short_spread"),
        })
        r = rows[-1]
        print(f"  seed {seed:4d}: {r['val_names']:3d} val names | "
              f"IC {r['rank_ic']:+.4f} | t {r['t']:+.2f} | "
              f"abstain {r['abstain']:.4f}")

    if not rows:
        print("\nno seeds completed")
        return 1

    tab = pd.DataFrame(rows)
    t = tab["t"].astype(float)
    ic = tab["rank_ic"].astype(float)

    print("\n" + "=" * 78)
    print("DISTRIBUTION ACROSS SEEDS")
    print("=" * 78)
    print(f"  seeds run            : {len(tab)}")
    print(f"  rank IC  median      : {ic.median():+.4f}  "
          f"(min {ic.min():+.4f}, max {ic.max():+.4f})")
    print(f"  FM t     median      : {t.median():+.2f}  "
          f"(min {t.min():+.2f}, max {t.max():+.2f})")
    print(f"  seeds with t >  2.0  : {int((t > 2.0).sum())} / {len(tab)}")
    print(f"  seeds with t >  1.0  : {int((t > 1.0).sum())} / {len(tab)}")
    print(f"  seeds with t <= 0    : {int((t <= 0).sum())} / {len(tab)}")

    # The mean IC across independent draws, with a standard error over seeds.
    # Seeds share the same panel, so this is NOT an independent-sample t-test --
    # it measures dispersion attributable to the split, nothing more.
    print(f"\n  IC mean across seeds : {ic.mean():+.4f} "
          f"(sd {ic.std(ddof=1):.4f})")

    print("\nVERDICT")
    print("-" * 78)
    frac = float((t > 2.0).mean())
    if ic.median() > 0 and frac >= 0.75:
        print("  The effect survives re-drawing the validation names. Positive")
        print("  sign in the large majority of seeds and median t above 2.")
        print("  Still a lead, not a conclusion: same period, same market, one")
        print("  model. Confirm out of period before acting on it.")
    elif ic.median() > 0 and t.median() > 1.0:
        print("  Directionally consistent but NOT robustly significant. The")
        print("  headline t from a single seed overstates it; the honest")
        print("  summary is the distribution, not the best draw.")
    else:
        print("  Does NOT survive re-drawing. The single-seed result was a")
        print("  lucky draw, and reporting it would have been a false positive.")

    # Stamp the window and size into the filename. Two runs over different
    # periods are different experiments, and a fixed name silently overwrites
    # the first one's evidence with the second's.
    tag = f"n{N}_{str(START)[:7].replace('-', '')}_{str(END)[:7].replace('-', '')}"
    csv = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       f"universe_seeds_{tag}.csv")
    tab.to_csv(csv, index=False)
    print(f"\nsaved: {csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
