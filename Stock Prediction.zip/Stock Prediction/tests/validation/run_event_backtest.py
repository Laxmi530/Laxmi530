"""
What does Section 39's vectorized backtest not show you?

Hilpisch, *AI in Finance* (O'Reilly, 2020), Ch. 11, makes a point this project
has never tested: a **vectorized** backtest multiplies a signal by the return
from entry to horizon and is therefore blind to the path in between. Section 39
computes ``fwd = log(px.shift(-hold)/px)`` -- one step, anchor to horizon. Four
of the five days of every hold are unobserved.

Section 43 measured that same book at **kurtosis 13.18, skew -0.781**. Negative
skew is made of intra-period paths. So this is not a theoretical objection.

Three questions, in order
-------------------------
1. **How far underwater did the average position actually go?** Maximum adverse
   excursion needs no strategy assumption -- it is simply what the vectorized
   number omits.
2. **Do stops help?** A prediction, written before running it: they should
   *hurt*. Section 38 identified this signal as short-term **reversal**, and a
   stop-loss on a reversal trade sells precisely when the mean-reversion is
   strongest. If stops improve a reversal book, something is wrong with either
   the signal's identification or the backtest.
3. **How much does a naive stop backtest overstate itself?** A stop is not a
   guaranteed fill. The gap between ``gap_fill=True`` and ``False`` is the size
   of that lie on this data.

Run::

    python tests/validation/run_event_backtest.py
    python tests/validation/run_event_backtest.py --hold 5 --decile 10
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                   # noqa: E402
import event_backtest as eb             # noqa: E402
import strategy_metrics as sm           # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


# 2018, matching run_reversal_costs.py. Section 39 is the thing being
# re-measured, so the window must be identical -- on 2022-2024 alone this
# book shows an annualised Sharpe of 1.01 against 0.24 over the full
# period, and every number below would have been a sample-period artefact.
START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "400"))
HOLD = int(_arg("--hold", "5"))
LOOKBACK = int(_arg("--lookback", "5"))
DECILE = int(_arg("--decile", "10"))
OUT = os.path.join(_HERE, "event_backtest.csv")
PPY = 252.0 / HOLD

#: Section 39's headline, for reference.
S39_BREAKEVEN_BP = 6.1


def build_positions(panel):
    """
    Section 39's book, but carrying every position's **path**.

    The selection logic is copied from ``run_reversal_costs.build_book`` so the
    comparison is like for like: past-``LOOKBACK``-day return, bottom decile
    long, top decile short, equal weight, rebalanced every ``HOLD`` days.
    """
    panel = eb.adjust_ohlc(panel)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="close", aggfunc="last").sort_index()
    bars = {c: panel[panel["symbol"] == c].set_index("datetime").sort_index()
            for c in px.columns}
    past = np.log(px / px.shift(LOOKBACK))
    dates = px.index[LOOKBACK::HOLD]
    idx = {d: i for i, d in enumerate(px.index)}

    out = []
    for d in dates:
        i = idx[d]
        if i + HOLD >= len(px.index):
            continue
        window = px.index[i + 1:i + 1 + HOLD]
        s = past.loc[d].dropna()
        # Require a full forward window, matching §39's fwd.notna() screen.
        s = s[px.loc[window, s.index].notna().all(axis=0)]
        if len(s) < DECILE * 4:
            continue
        r = s.rank(pct=True)
        longs = r[r <= 1.0 / DECILE].index
        shorts = r[r >= 1.0 - 1.0 / DECILE].index
        if len(longs) < 3 or len(shorts) < 3:
            continue
        for side, names in ((1, longs), (-1, shorts)):
            for sym in names:
                b = bars[sym].reindex(window)
                if b[list(eb.BAR_COLUMNS)].isna().any().any():
                    continue
                out.append({"date": d, "symbol": sym, "side": side,
                            "entry": float(px.at[d, sym]), "bars": b,
                            "weight": 1.0 / len(names)})
    return out


def _book(positions, **rules):
    """Aggregate positions into a per-rebalance long-short return series."""
    recs = []
    for p in positions:
        c = eb.compare(p["entry"], p["bars"], side=p["side"], **rules)
        c.update(date=p["date"], side=p["side"], weight=p["weight"])
        recs.append(c)
    df = pd.DataFrame(recs)
    # Dollar-neutral: each leg equal-weighted, the book is long minus short.
    per = df.groupby("date").apply(
        lambda g: pd.Series({
            "event": float((g["event"] * g["weight"]).sum()),
            "vectorized": float((g["vectorized"] * g["weight"]).sum()),
        }), include_groups=False)
    return df, per


def main():
    print("=" * 78)
    print("EVENT-BASED BACKTESTING  (Hilpisch, AI in Finance, Ch. 11)")
    print("=" * 78)
    print(f"window {START}..{END} | n={N} | hold={HOLD}d | 1/{DECILE} tails")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nbuilding panel ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    positions = build_positions(panel)
    if not positions:
        print("no positions")
        return 1
    print(f"  {len(positions):,} positions over "
          f"{len({p['date'] for p in positions})} rebalances")

    base, per = _book(positions)

    # ------------------------------------------- 0. does the rebuild match?
    # This driver reconstructs Section 39's book from scratch in order to carry
    # the paths. If the reconstruction drifts from the original, every number
    # below is measuring a different strategy. The check is cheap and the
    # failure it guards against is silent -- an accidental change of window
    # made this book look 4x better before this was added.
    ref = os.path.join(_HERE, "reversal_costs_h5.csv")
    if os.path.exists(ref):
        r = pd.read_csv(ref)["gross"].to_numpy(dtype=float)
        mine = per["vectorized"].to_numpy(dtype=float)
        print("\n" + "=" * 78)
        print("0. RECONCILIATION AGAINST SECTION 39's STORED BOOK")
        print("=" * 78)
        print(f"{'':22s}{'rebalances':>12s}{'mean/reb':>12s}{'ann. SR':>10s}")
        for label, x in (("Section 39 (stored)", r), ("this rebuild", mine)):
            print(f"{label:22s}{len(x):12d}{x.mean():+12.4%}"
                  f"{sm.sharpe_ratio(x, PPY):+10.3f}")
        k = min(len(r), len(mine))
        rho = float(np.corrcoef(mine[:k], r[:k])[0, 1])
        print(f"\n  correlation of the two return series: {rho:.4f}"
              + ("  -- same book" if rho > 0.95 else
                 "  -- DIVERGED, investigate before reading on"))
        print("  The means differ because Section 39 reports LOG returns and")
        print("  this driver uses SIMPLE ones: a stop fills at a price, not at")
        print("  a log price, so every number here has to be in simple terms.")
        print("  The long leg (recent losers) is the more volatile of the two,")
        print("  so its Jensen gap is the larger and the log book sits below.")

    # ------------------------------------------------- 1. what is hidden
    print("\n" + "=" * 78)
    print("1. MAXIMUM ADVERSE EXCURSION  --  what the vectorized number omits")
    print("=" * 78)
    s = eb.summarize(base.to_dict("records"))
    print(eb.format_report(s, "NO EXIT RULES (event == vectorized by "
                              "construction)"))
    mae = base["mae"].to_numpy(dtype=float)
    print()
    print(f"  Per POSITION, over a {HOLD}-day hold:")
    for q in (0.50, 0.25, 0.10, 0.05, 0.01):
        print(f"    {int(q * 100):>3d}th pct MAE : {np.quantile(mae, q):+7.2%}")
    print(f"    share worse than -5%  : {(mae < -0.05).mean():.1%}")
    print(f"    share worse than -10% : {(mae < -0.10).mean():.1%}")
    print(f"\n  The book's mean per-rebalance return is "
          f"{per['vectorized'].mean():+.4%}.")
    print("  That is the number Section 39 reports. The average position")
    print(f"  reached {mae.mean():+.2%} against itself on the way there.")

    # ------------------------------------------------- 2. do stops help?
    print("\n" + "=" * 78)
    print("2. DO STOPS HELP A REVERSAL BOOK?")
    print("=" * 78)
    print("  Prediction, written before running: they should HURT. Stopping")
    print("  out of a reversal trade sells exactly when mean-reversion is")
    print("  strongest.\n")
    print(f"{'rule':>18s}{'mean/reb':>11s}{'ann.SR':>9s}{'vs base':>9s}"
          f"{'t paired':>10s}{'stopped':>9s}{'held':>7s}")
    rows = []
    variants = [("none", {})]
    variants += [(f"stop {int(x * 100)}%", {"stop_loss": x})
                 for x in (0.03, 0.05, 0.08, 0.10)]
    variants += [(f"trail {int(x * 100)}%", {"trailing_stop": x})
                 for x in (0.03, 0.05)]
    variants += [("stop 5% + tp 5%", {"stop_loss": 0.05, "take_profit": 0.05})]
    base_ret, base_sr, series = None, None, {}
    for label, rules in variants:
        df, p = _book(positions, **rules)
        v = p["event"].to_numpy(dtype=float)
        series[label] = v
        sr = sm.sharpe_ratio(v, PPY)
        if base_ret is None:
            base_ret, base_sr = v, sr
        # Paired, per rebalance: the rules share the same dates and the same
        # selection, so the difference series removes everything except the
        # effect of the rule itself. Comparing two Sharpes by eye does not.
        d = v - base_ret
        t = (float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d))))
             if d.std(ddof=1) > 0 else np.nan)
        st = eb.summarize(df.to_dict("records"))
        stopped = st["share_stop_loss"] + st["share_trailing_stop"]
        rows.append({"rule": label, "mean": float(v.mean()), "sharpe": sr,
                     "delta_sharpe": sr - base_sr, "t_paired": t,
                     "stopped": stopped, "bars_held": st["bars_held_mean"]})
        print(f"{label:>18s}{v.mean():+11.4%}{sr:+9.3f}{sr - base_sr:+9.3f}"
              f"{t:+10.2f}{stopped:9.1%}{st['bars_held_mean']:7.2f}")

    print("\n  't paired' tests the per-rebalance difference against no rules.")
    print("  NOT ONE RULE REACHES |t| = 2. The Sharpe column invites a story")
    print("  the difference series does not support.")

    # This is a sweep of 8 configurations and the best one is about to be
    # quoted. Section 43 built the instrument for exactly this moment.
    best = max(rows[1:], key=lambda r: r["sharpe"])
    d = sm.deflated_sharpe_ratio(series[best["rule"]],
                                 np.array([r["sharpe"] for r in rows]),
                                 periods_per_year=PPY)
    print(f"\n  Deflating the best of the sweep ({best['rule']}), per §43:")
    print(f"    observed SR (per period) : {d['observed_sr']:+.4f}")
    print(f"    SR* from {d['n_trials']} trials       : {d['sr_star']:+.4f}")
    print(f"    DEFLATED SHARPE          : {d['dsr']:.4f}")
    print(f"    PSR vs 0 (naive)         : "
          f"{sm.probabilistic_sharpe_ratio(series[best['rule']], 0.0):.4f}")

    # What the stop DOES do is reshape the distribution -- which is the thing
    # it actually promises, and it delivers on that even without a Sharpe gain.
    def _shape(x):
        z = (x - x.mean()) / x.std(ddof=1)
        return float((z ** 3).mean()), float((z ** 4).mean())

    b_skew, b_kurt = _shape(base_ret)
    print(f"\n  What a stop demonstrably changes is the SHAPE:")
    print(f"    {'':12s}{'skew':>9s}{'kurtosis':>11s}")
    print(f"    {'no rules':12s}{b_skew:+9.3f}{b_kurt:11.2f}")
    print(f"    {best['rule']:12s}{d['skew']:+9.3f}{d['kurtosis']:11.2f}")
    print("    Truncating the left tail is what a stop is for, and it does it.")
    print("    That is a distributional fact, not a risk-adjusted return.")
    for r in rows:
        if r["rule"] == best["rule"]:
            r.update(dsr=d["dsr"], sr_star=d["sr_star"], skew=d["skew"],
                     kurtosis=d["kurtosis"])

    # ------------------------------------------------- 3. the gap lie
    print("\n" + "=" * 78)
    print("3. HOW MUCH DOES A NAIVE STOP BACKTEST OVERSTATE ITSELF?")
    print("=" * 78)
    print("  A stop is not a guaranteed fill. If the bar opens through the")
    print("  level you get the open, not the stop.\n")
    print(f"{'stop':>8s}{'honest':>12s}{'assumes fill':>15s}{'overstated by':>16s}")
    gaps = []
    for x in (0.03, 0.05, 0.08):
        _, hp = _book(positions, stop_loss=x, gap_fill=True)
        _, op = _book(positions, stop_loss=x, gap_fill=False)
        d = op["event"].mean() - hp["event"].mean()
        gaps.append({"stop": x, "honest": float(hp["event"].mean()),
                     "naive": float(op["event"].mean()), "overstatement": float(d)})
        print(f"{x:8.0%}{hp['event'].mean():+12.4%}{op['event'].mean():+15.4%}"
              f"{d:+16.4%}")
    print("\n  Annualised, that overstatement is worth "
          f"{gaps[1]['overstatement'] * PPY:+.2%} on the 5% stop alone.")

    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\nwrote {OUT}")

    # ------------------------------------------------- verdict
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    print("  1. The finding that needs no strategy assumption: the average")
    print(f"     position went {mae.mean():+.2%} against itself before its horizon,")
    print(f"     {(mae < -0.05).mean():.0%} went past -5% and {(mae < -0.10).mean():.0%} past -10%, while the book")
    print(f"     earned {per['vectorized'].mean():+.4%} per rebalance. Section 39 shows none")
    print("     of that, because a vectorized backtest cannot.")
    sig = [r for r in rows[1:] if abs(r["t_paired"]) > 2]
    print(f"\n  2. Exit rules: {len(sig)} of {len(rows) - 1} reach |t| > 2 against no rules.")
    print(f"     The best point estimate ({best['rule']}) is t = "
          f"{best['t_paired']:+.2f} and deflates to")
    print(f"     DSR {best.get('dsr', float('nan')):.2f} against its own 8-trial sweep. "
          "The prediction written")
    print("     above -- that stops would HURT -- is not supported either; the")
    print("     point estimate goes the other way and neither direction is")
    print("     established. Recorded as written rather than quietly dropped.")
    print(f"\n  3. Assuming a stop fills at its level overstates the 5% rule by")
    print(f"     {gaps[1]['overstatement'] * PPY:+.2%} a year -- enough to flip its sign.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
