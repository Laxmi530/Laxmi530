"""
Does the short-term reversal signal survive transaction costs?

The open question
-----------------
Section 38 established a replicable cross-sectional signal and Section 38's
attribution identified it: **short-term reversal**, carried by `log_return_5`
at IC -0.0524 (t = -4.34), which beats the model that was supposed to learn it.
The section then says, honestly, that whether it survives costs "is a different
question this project has not asked."

This asks it. Reversal is the single factor most likely to die on costs: it
trades on a 5-day cycle, it concentrates in the names with the widest spreads,
and its edge is a few basis points a day. A statistically real signal that
cannot be traded is a **negative result**, and a more useful one than an open
question.

Why the whole window is usable
------------------------------
There is nothing to fit. The signal is a cross-sectional sort on a raw feature
with **no free parameters** -- no training, no calibration, no hyperparameters.
So there is no train/test split to respect and the full 2018-2024 panel is fair
game.

One honest qualifier: `log_return_5` was *selected* by the attribution run from
~30 candidate features, so a mild selection effect applies to its exact IC. It
is not a blind pick, and the result below should be read as the best case among
the features examined rather than an unbiased estimate.

Construction
------------
* Signal at date *t*: the past 5-day log return, ranked within that date's
  cross-section.
* **Long the bottom decile** (recent losers), **short the top decile** (recent
  winners) -- the direction the negative IC implies.
* Equal weight, dollar-neutral, **rebalanced every 5 trading days** so holding
  periods do not overlap. Overlapping daily rebalances would multiply turnover
  without adding independent information.
* Return per period is the realised spread; turnover is measured from the
  actual weight changes, not assumed.

The number that matters is the **breakeven cost** -- the round-trip cost at
which the net return reaches zero -- because it is independent of whatever cost
assumptions anyone disagrees with.

Run::

    python tests/validation/run_reversal_costs.py
    python tests/validation/run_reversal_costs.py --decile 5 --hold 10
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                       # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "400"))
LOOKBACK = int(_arg("--lookback", "5"))     # signal formation window
HOLD = int(_arg("--hold", "5"))             # rebalance period, trading days
DECILE = int(_arg("--decile", "10"))        # 10 = deciles, 5 = quintiles

#: Round-trip cost scenarios for Indian equities, in basis points of notional.
#: Components at delivery: brokerage (~3 bp discount), STT (10 bp buy + 10 bp
#: sell), exchange + SEBI + stamp (~2 bp), GST on fees, and -- dominant at size
#: -- market impact. Futures shorts carry lower STT but add roll cost.
COST_SCENARIOS = [
    (10, "institutional, futures, top-liquidity names only"),
    (25, "liquid cash equity, modest size"),
    (50, "realistic incl. mid-cap impact"),
    (100, "retail delivery, STT both sides"),
]


def build_book(panel, lookback, hold, decile):
    """Form the long-short book and return per-period gross returns + turnover."""
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    # Signal: past `lookback`-day log return. Forward: next `hold`-day return.
    past = np.log(px / px.shift(lookback))
    fwd = np.log(px.shift(-hold) / px)

    dates = px.index[lookback::hold]
    prev_w = None
    rows = []
    for d in dates:
        s = past.loc[d].dropna()
        f = fwd.loc[d]
        s = s[f.reindex(s.index).notna()]
        if len(s) < decile * 4:            # need enough names for clean tails
            continue
        r = s.rank(pct=True)
        longs = r[r <= 1.0 / decile].index          # recent losers
        shorts = r[r >= 1.0 - 1.0 / decile].index   # recent winners
        if len(longs) < 3 or len(shorts) < 3:
            continue

        w = pd.Series(0.0, index=px.columns)
        w[longs] = 1.0 / len(longs)
        w[shorts] = -1.0 / len(shorts)

        gross = float(f[longs].mean() - f[shorts].mean())

        # Notional traded, as the sum of absolute weight changes. Gross exposure
        # is 2.0 (1 long + 1 short), so a COMPLETE refresh trades 4.0: 2.0 to
        # close the old book and 2.0 to open the new one. The first period only
        # opens, hence 2.0.
        traded = (2.0 if prev_w is None
                  else float((w - prev_w).abs().sum()))
        prev_w = w
        rows.append({"date": d, "gross": gross, "traded": traded,
                     "n_long": len(longs), "n_short": len(shorts)})
    return pd.DataFrame(rows)


def summarise(book, cost_bps, periods_per_year):
    """Net return series and its annualised statistics at a given cost."""
    c = cost_bps / 10000.0
    # `traded` is notional turned over; each unit costs `c` one way.
    net = book["gross"] - book["traded"] * c / 2.0
    ann_ret = float(net.mean() * periods_per_year)
    ann_vol = float(net.std(ddof=1) * np.sqrt(periods_per_year))
    sharpe = ann_ret / ann_vol if ann_vol > 0 else np.nan
    return {"cost_bps": cost_bps, "mean_per_period": float(net.mean()),
            "ann_return": ann_ret, "ann_vol": ann_vol, "sharpe": sharpe,
            "hit_rate": float((net > 0).mean())}


def main():
    print("=" * 78)
    print("DOES SHORT-TERM REVERSAL SURVIVE TRANSACTION COSTS?")
    print("=" * 78)
    print(f"window {START} .. {END} | n={N} | signal={LOOKBACK}d past return | "
          f"hold={HOLD}d | 1/{DECILE} tails")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nbuilding survivorship-free panel ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END, chunk_months=360)
    panel, rep = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    print(f"  {rep['n_symbols']} names | {rep['n_dates']} dates | "
          f"{rep['n_rows']:,} rows")

    book = build_book(panel, LOOKBACK, HOLD, DECILE)
    if not len(book):
        print("  no rebalance periods formed")
        return 1

    ppy = 252.0 / HOLD
    print(f"\nrebalances: {len(book)} | names per leg: "
          f"{book['n_long'].median():.0f} long / {book['n_short'].median():.0f} short")
    print(f"mean notional traded per rebalance: {book['traded'].mean():.3f} "
          f"(4.000 = complete refresh of a 2x-gross book)")
    print(f"annualised notional traded: {book['traded'].mean() * ppy:.0f}x gross")

    # ------------------------------------------------------------------ gross
    g = summarise(book, 0.0, ppy)
    print("\n" + "=" * 78)
    print("GROSS (no costs)")
    print("=" * 78)
    print(f"  mean {HOLD}-day spread : {g['mean_per_period']:+.5f} "
          f"({100 * g['mean_per_period']:+.3f}%)")
    print(f"  annualised return     : {100 * g['ann_return']:+.2f}%")
    print(f"  annualised vol        : {100 * g['ann_vol']:.2f}%")
    print(f"  Sharpe                : {g['sharpe']:+.2f}")
    print(f"  periods positive      : {g['hit_rate']:.3f}")

    # -------------------------------------------------------------------- net
    print("\n" + "=" * 78)
    print("NET OF COSTS")
    print("=" * 78)
    print(f"{'round-trip':>12s}{'ann return':>13s}{'Sharpe':>9s}"
          f"{'hit':>7s}   scenario")
    for bps, label in COST_SCENARIOS:
        s = summarise(book, bps, ppy)
        print(f"{bps:9d} bp{100 * s['ann_return']:12.2f}%{s['sharpe']:9.2f}"
              f"{s['hit_rate']:7.3f}   {label}")

    # -------------------------------------------------------------- breakeven
    per_period_gross = float(book["gross"].mean())
    per_period_traded = float(book["traded"].mean())
    breakeven = (2.0 * per_period_gross / per_period_traded * 10000.0
                 if per_period_traded > 0 else np.nan)
    print("\n" + "=" * 78)
    print("BREAKEVEN")
    print("=" * 78)
    print(f"  round-trip cost at which net return = 0: {breakeven:.1f} bp")
    print("  (independent of the scenarios above -- this is the number to")
    print("   argue with, since it makes no cost assumption at all.)")

    # ------------------------------------------------------- implementability
    print("\n" + "=" * 78)
    print("IMPLEMENTABILITY OF THE SHORT LEG")
    print("=" * 78)
    try:
        from nselib import capital_market as cm
        fno = set(cm.fno_equity_list()["symbol"].astype(str).str.strip())
        uni = set(panel["symbol"].unique())
        ok = uni & fno
        print(f"  Indian cash equity has NO overnight short selling. A 5-day")
        print(f"  short leg needs stock futures, available only for F&O names.")
        print(f"  universe names            : {len(uni)}")
        print(f"  F&O-eligible (today's list): {len(ok)} ({100 * len(ok) / max(len(uni), 1):.0f}%)")
        print(f"  NOT shortable overnight   : {len(uni - fno)}")
        print("  (Today's F&O list, not point-in-time -- an upper bound.)")
    except Exception as exc:
        print(f"  (F&O check skipped: {type(exc).__name__})")

    # ------------------------------------------------------------- the verdict
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    realistic = summarise(book, 50.0, ppy)
    if breakeven >= 100:
        print("  Survives realistic costs. That would make this the project's")
        print("  first tradeable result -- verify capacity and borrow before")
        print("  believing it.")
    elif breakeven >= 50:
        print("  Marginal. Survives only at institutional execution costs, and")
        print("  the short leg is restricted to F&O names, which cuts breadth")
        print("  and therefore the IC that generated the edge.")
    else:
        print(f"  DOES NOT SURVIVE. Breakeven is {breakeven:.0f} bp round trip,")
        print("  below any realistic Indian equity cost. The signal is real and")
        print("  statistically solid; it is not tradeable at this horizon.")
        print(f"  At a realistic 50 bp the book returns "
              f"{100 * realistic['ann_return']:+.1f}%/yr "
              f"(Sharpe {realistic['sharpe']:+.2f}).")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       f"reversal_costs_h{HOLD}.csv")
    book.to_csv(out, index=False)
    print(f"\nsaved: {out}")

    # ------------------------------------------------------------- the sweep
    # The obvious objection to any turnover-driven null is "rebalance more
    # slowly". Reversal decays fast, so a longer hold trades less AND earns
    # less; whether that trade is favourable is an empirical question, and
    # leaving it unasked would make the verdict above look like a straw man.
    # The panel is already built, so the sweep is nearly free.
    print("\n" + "=" * 78)
    print("SWEEP  --  can any holding period / tail width clear realistic costs?")
    print("=" * 78)
    print(f"{'hold':>5s}{'tail':>7s}{'traded':>9s}{'gross ann':>11s}"
          f"{'Sharpe':>8s}{'breakeven':>11s}{'net@25bp':>10s}")
    sweep = []
    for hold in (5, 10, 21, 42):
        for dec in (10, 5):
            b = build_book(panel, LOOKBACK, hold, dec)
            if not len(b):
                continue
            p = 252.0 / hold
            gz = summarise(b, 0.0, p)
            n25 = summarise(b, 25.0, p)
            tr = float(b["traded"].mean())
            be = (2.0 * float(b["gross"].mean()) / tr * 10000.0
                  if tr > 0 else np.nan)
            sweep.append({"hold": hold, "tail": f"1/{dec}", "traded": tr,
                          "gross_ann": gz["ann_return"], "sharpe": gz["sharpe"],
                          "breakeven_bp": be, "net25_ann": n25["ann_return"]})
            print(f"{hold:5d}{('1/' + str(dec)):>7s}{tr:9.3f}"
                  f"{100 * gz['ann_return']:10.2f}%{gz['sharpe']:8.2f}"
                  f"{be:10.1f}bp{100 * n25['ann_return']:9.1f}%")
    if sweep:
        best = max(sweep, key=lambda r: r["breakeven_bp"])
        print(f"\n  best breakeven anywhere in the sweep: "
              f"{best['breakeven_bp']:.1f} bp "
              f"(hold={best['hold']}d, tail={best['tail']})")
        if best["breakeven_bp"] < 25:
            print("  => No configuration clears even a 25 bp round trip. The")
            print("     null is not an artefact of the 5-day rebalance choice.")
        pd.DataFrame(sweep).to_csv(
            os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "reversal_costs_sweep.csv"), index=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
