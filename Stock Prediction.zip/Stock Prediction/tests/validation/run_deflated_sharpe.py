"""
Deflated Sharpe Ratio (López de Prado, AFML §14.7.3) applied to this project.

What a Sharpe ratio cannot tell you
------------------------------------
Two things inflate a Sharpe and are invisible in the number itself:

1. **How many strategies you tried.** Run enough configurations on pure noise
   and the best one posts a respectable Sharpe, entirely from the maximum of N
   draws. Demonstrated below: the best of 500 zero-skill strategies reaches an
   annualised Sharpe near 1.9.
2. **The shape of the returns.** Negative skew and fat tails both flatter a
   Sharpe. A book that grinds up and crashes down looks excellent right until
   it does not.

Section 40 already runs SPA / Reality Check, which handles (1) across a model
set. DSR is complementary rather than redundant: it uses the **trial count and
the dispersion of their Sharpes** explicitly, and it carries PSR's **skew and
kurtosis** correction, which SPA does not.

What this driver does
---------------------
Part 1 is a calibration: N strategies with *exactly zero* true skill, keep the
best, and show that the naive PSR is fooled while DSR is not. It is the
statistic proving itself on a case where the right answer is known.

Part 2 applies it to the one place in this project with both a return series
and a countable number of trials: the Section 40 reversal book, deflated
against the eight hold x tail configurations that were actually swept.

Run::

    python tests/validation/run_deflated_sharpe.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import strategy_metrics as sm        # noqa: E402

BOOK = os.path.join(_HERE, "reversal_costs_h5.csv")
SWEEP = os.path.join(_HERE, "reversal_costs_sweep.csv")
HOLD = 5
PPY = 252.0 / HOLD


def part1_calibration():
    print("=" * 78)
    print("1. CALIBRATION  --  N strategies with EXACTLY ZERO skill")
    print("=" * 78)
    rng = np.random.default_rng(0)
    t = 750
    print(f"{'N tried':>9s}{'best SR/yr':>12s}{'PSR vs 0':>11s}"
          f"{'SR* (noise)':>13s}{'DSR':>9s}  reading")
    for n in (5, 20, 100, 500):
        rets = rng.standard_normal((n, t)) * 0.01       # mean exactly zero
        srs = np.array([r.mean() / r.std(ddof=1) for r in rets])
        best = rets[int(np.argmax(srs))]
        d = sm.deflated_sharpe_ratio(best, srs)
        psr = sm.probabilistic_sharpe_ratio(best, 0.0)
        note = ("PSR fooled, DSR not" if psr > 0.95 and d["dsr"] < 0.95
                else "both unimpressed" if d["dsr"] < 0.95 else "DSR FOOLED")
        print(f"{n:9d}{srs.max() * np.sqrt(252):12.2f}{psr:11.3f}"
              f"{d['sr_star']:13.4f}{d['dsr']:9.3f}  {note}")
    print("\n  PSR rises toward 1 as N grows -- the best of more noise looks")
    print("  better. DSR does not, because its threshold rises with N too.")


def part2_reversal():
    if not (os.path.exists(BOOK) and os.path.exists(SWEEP)):
        print("\n(reversal data absent; run run_reversal_costs.py first)")
        return
    book = pd.read_csv(BOOK)
    sweep = pd.read_csv(SWEEP)
    g = book["gross"].to_numpy(dtype=float)
    traded = book["traded"].to_numpy(dtype=float)

    print("\n" + "=" * 78)
    print("2. THE SECTION 40 REVERSAL BOOK, DEFLATED")
    print("=" * 78)
    print(f"  rebalances              : {len(g)}")
    print(f"  gross annualised Sharpe : {sm.sharpe_ratio(g, PPY):+.3f}")
    print(f"  configurations swept    : {len(sweep)}  (hold x tail)")
    print("\n  The trial count is not a guess: run_reversal_costs.py swept")
    print("  exactly these eight, and the 5-day decile book is the one that")
    print("  was reported. That is textbook selection, and DSR prices it.")

    for label, r in (("GROSS (no costs)", g),
                     ("NET at 25 bp round trip", g - traded * 0.0025 / 2.0)):
        d = sm.deflated_sharpe_ratio(r, sweep["sharpe"].to_numpy(dtype=float),
                                     periods_per_year=PPY)
        psr = sm.probabilistic_sharpe_ratio(r, 0.0)
        print(f"\n  {label}")
        print(f"    observed SR (per period)  : {d['observed_sr']:+.4f}")
        print(f"    skew                      : {d['skew']:+.3f}")
        print(f"    kurtosis (3 = Gaussian)   : {d['kurtosis']:.2f}")
        print(f"    PSR vs 0 (naive)          : {psr:.4f}")
        print(f"    SR* from {d['n_trials']} trials        : {d['sr_star']:+.4f}")
        print(f"    DEFLATED SHARPE           : {d['dsr']:.4f}")

    d = sm.deflated_sharpe_ratio(g, sweep["sharpe"].to_numpy(dtype=float),
                                 periods_per_year=PPY)
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    if d["sr_star"] > d["observed_sr"]:
        print(f"  The GROSS Sharpe ({d['observed_sr']:+.4f} per period) is BELOW the")
        print(f"  best-of-{d['n_trials']}-trials noise threshold ({d['sr_star']:+.4f}).")
        print("  So the reversal book fails multiple-testing deflation BEFORE")
        print("  any transaction cost is applied -- a stronger statement than")
        print("  Section 40 made, which only showed it dies on costs.")
    else:
        print("  The gross Sharpe clears the noise threshold; costs remain the")
        print("  binding constraint, as Section 40 reported.")
    print()
    print(f"  Returns are fat-tailed (kurtosis {d['kurtosis']:.1f} against 3 for a")
    print(f"  Gaussian) and negatively skewed ({d['skew']:+.2f}) -- exactly the")
    print("  profile a bare Sharpe flatters and PSR discounts. Section 40")
    print("  called the gross Sharpe 'thin'; it is worse than thin.")


def main():
    print("=" * 78)
    print("DEFLATED SHARPE RATIO  (Bailey & Lopez de Prado; AFML 14.7.3)")
    print("=" * 78)
    part1_calibration()
    part2_reversal()
    return 0


if __name__ == "__main__":
    sys.exit(main())
