"""
Run the calibration & probabilistic-scoring harness on real data.

This is the validation capstone for the uncertainty-first product: it does not
add a model, it checks whether the probabilistic claims the app already makes
(intervals, CRPS, P(up)/P(move), the confidence gate) are actually calibrated.

It evaluates two complementary models by default:

- **HAR-RV** — the volatility/risk model. Its conformal cone, empirical vs
  log-normal CRPS, PIT calibration and coverage quality are the headline.
- **XGBoost (direct)** — a *directional* model, so its P(up) reliability is
  meaningful (HAR-RV's is degenerate at ~0.5 by design).

and runs the nested gate validation on XGBoost (the model whose bucket actually
varies across origins).

Usage:
    python run_calibration.py [TICKER] [--with-gate] [--quick]
        TICKER      : default RELIANCE.NS
        --with-gate : also run the (slower) nested gate validation
        --quick     : fewer origins for a fast smoke run
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import sys
import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import calibration as cal

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
_flags = {a for a in sys.argv[1:] if a.startswith("--")}
TICKER = _pos[0] if _pos else "RELIANCE.NS"
INTERVAL = "1d"
HORIZON = 5
QUICK = "--quick" in _flags
N_SPLITS = 6 if QUICK else 12
MIN_TRAIN = 300
MAX_ROWS = 700


def fetch(ticker):
    """Fetch daily OHLCV from yfinance, mapped to the project schema."""
    h = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    df = h[cols].dropna().reset_index(drop=True)
    return df.tail(MAX_ROWS).reset_index(drop=True)


def _print_header(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def evaluate_model(df, name, fn, kwargs, do_reliability_up):
    """Collect records once, then print every calibration diagnostic."""
    _print_header(f"MODEL: {name}")
    records, empirical = cal.collect_step_records(
        df, fn, INTERVAL, HORIZON, n_splits=N_SPLITS, min_train=MIN_TRAIN,
        predict_kwargs=kwargs, model_name=name)
    print(f"Collected {len(records)} (origin, step) records over "
          f"{records['origin'].nunique()} origins; "
          f"{len(empirical)} origins exposed an empirical return sample.")

    # 1) Coverage quality
    cq = cal.coverage_quality(records)
    if not cq.empty:
        print("\n-- Coverage quality (per horizon) --")
        print(cq.to_string())
        print("Read: coverage near 0.95 = calibrated; high mean_width_% with "
              "good coverage = wide-but-cheap; tail_balance > 0 = misses skew "
              "DOWNSIDE (cone underestimates crash risk).")
    else:
        print("\n(model emits no intervals — coverage quality skipped)")

    # 2) CRPS
    cr = cal.crps_report(records, empirical)
    if not cr['per_step'].empty:
        print("\n-- CRPS per horizon (lower is better) --")
        print(cr['per_step'].to_string())
    if cr['final_horizon']:
        fh = cr['final_horizon']
        print(f"\n-- Final-horizon CRPS: empirical vs log-normal "
              f"(h={fh['horizon']}, n={fh['n']}) --")
        print(f"   empirical (fat-tailed) : {fh['crps_empirical']}")
        print(f"   log-normal approx      : {fh['crps_lognormal']}")
        better = ("empirical" if fh['crps_empirical'] < fh['crps_lognormal']
                  else "log-normal")
        print(f"   -> {better} scores better here (this is exactly the "
              "fat-tail-vs-Gaussian comparison the risk-panel fix is about).")

    # 3) PIT
    pit = cal.pit_values(records, empirical)
    ps = cal.pit_summary(pit)
    print("\n-- PIT calibration (F_pred(actual) should be Uniform(0,1)) --")
    print(f"   n={ps['n']}  mean={ps['mean']} (ideal 0.5)  "
          f"KS={ps['ks_stat']}  p={ps['ks_p']}")
    print(f"   histogram (10 bins): {ps['hist']}")
    print(f"   verdict: {ps['verdict']}")

    # 4) Reliability of P(move > 2%) — always meaningful
    rel_move = cal.reliability(records, empirical, kind='move', threshold_pct=2.0)
    if rel_move['n']:
        print("\n-- Reliability of P(move > 2%) --")
        print(f"   ECE={rel_move['ece']}  mean_pred={rel_move['mean_pred']}  "
              f"base_rate={rel_move['base_rate']}")
        if not rel_move['bins'].empty:
            print(rel_move['bins'].to_string(index=False))

    # 5) Reliability of P(up) — only meaningful for directional models
    if do_reliability_up:
        rel_up = cal.reliability(records, empirical, kind='up')
        if rel_up['n']:
            print("\n-- Reliability of P(up) [directional model] --")
            print(f"   ECE={rel_up['ece']}  mean_pred={rel_up['mean_pred']}  "
                  f"base_rate={rel_up['base_rate']}")
            if not rel_up['bins'].empty:
                print(rel_up['bins'].to_string(index=False))
    return records


def main():
    print(f"=== Calibration harness | {TICKER} | horizon={HORIZON} | "
          f"splits={N_SPLITS} ===")
    df = fetch(TICKER)
    print(f"Fetched {len(df)} rows: {df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}")

    from HAR_RV_model import run_har_rv_prediction
    from ML_model import run_ML_prediction

    evaluate_model(df, "HAR-RV", run_har_rv_prediction, {},
                   do_reliability_up=False)
    evaluate_model(df, "XGBoost", run_ML_prediction, {"model_type": "xgboost"},
                   do_reliability_up=True)

    # Tier 2: does adaptive conformal (ACI) actually beat static on coverage?
    _print_header("ADAPTIVE (ACI) vs STATIC conformal — HAR-RV cone")
    cmp = cal.compare_static_vs_aci(
        df, run_har_rv_prediction, INTERVAL, HORIZON,
        n_splits=N_SPLITS, min_train=MIN_TRAIN)
    print("-- Static conformal coverage --")
    print(cmp['static'][['coverage', 'mean_width_%']].to_string()
          if not cmp['static'].empty else "(none)")
    print("\n-- ACI-adaptive coverage --")
    print(cmp['aci'][['coverage', 'mean_width_%']].to_string()
          if not cmp['aci'].empty else "(none)")
    print(f"\nMean |coverage-0.95|:  static={cmp['static_miscoverage']:.3f}  "
          f"ACI={cmp['aci_miscoverage']:.3f}")
    print(f"Mean interval width %: static={cmp['static_mean_width']:.2f}  "
          f"ACI={cmp['aci_mean_width']:.2f}")
    print(f"Verdict: {cmp['verdict']}")

    if "--with-gate" in _flags:
        _print_header("GATE VALIDATION (XGBoost): does the bucket sort skill?")
        gate = cal.validate_gate(
            df, run_ML_prediction, INTERVAL, HORIZON,
            n_splits=N_SPLITS, min_train=MIN_TRAIN,
            predict_kwargs={"model_type": "xgboost"}, model_name="XGBoost")
        if gate['by_bucket'].empty:
            print("No gate results (insufficient data).")
        else:
            print("Realised next-horizon skill grouped by the PAST-only bucket:")
            print(gate['by_bucket'].to_string())
            mono = gate['monotonic']
            verdict = ("ordering holds (gate is informative)" if mono
                       else "ordering does NOT hold (gate may be weak here)"
                       if mono is False else "too few buckets to judge")
            print(f"\nMonotonic High>=...>=No-edge improvement? -> {verdict}")
            print("(A small single-ticker sample is noisy; run across several "
                  "tickers for a firm verdict.)")

    print("\nDone. These diagnostics validate the *uncertainty* outputs; they "
          "do not claim the point forecast beats a random walk.")


if __name__ == "__main__":
    main()
