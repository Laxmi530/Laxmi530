"""
End-to-end audit of the bhavcopy pipeline against yfinance.

The claim under test
--------------------
:mod:`bhavcopy` reconstructs adjusted prices from two independent ingredients —
NSE's raw daily bhavcopy and NSE's corporate-action feed — and asserts the
result is comparable with yfinance's ``adj_close``, which the whole project
models log returns off.

That is a *falsifiable* claim, and this script tries to falsify it. For names
that survive to today, both sources exist and must agree. If they do, the
adjustment logic is validated on the only ground truth available; if they do
not, the panel is wrong in a way no downstream null result would reveal.

Why agreement is the right test rather than eyeballing splits
--------------------------------------------------------------
A per-event check (does the price drop by the parsed factor?) is confounded by
the stock's genuine move that day — that is exactly why one of the 18 validation
events came in at -13% with a perfectly correct factor. Comparing the *whole
return series* against an independent adjusted source averages that noise away
and tests every event at once, including the dividends that are too small to
verify individually.

What a discrepancy means
------------------------
Not automatically a bug on our side. yfinance and NSE occasionally disagree on
dividend ex-dates by a day, and yfinance silently back-fills some actions NSE
files late. The script therefore reports the *distribution* of disagreement and
flags large single-day gaps for inspection, rather than asserting a threshold it
cannot justify.

Run::

    python tests/validation/run_bhavcopy_audit.py
    python tests/validation/run_bhavcopy_audit.py 2018-01-01 2020-12-31
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                                    # noqa: E402
from cross_sectional_panel import DEFAULT_UNIVERSE       # noqa: E402


def _yf_adj(symbol, start, end):
    """yfinance adjusted close for one NSE symbol, or None."""
    import yfinance as yf
    try:
        h = yf.Ticker(f"{symbol}.NS").history(
            start=str(start)[:10], end=str(end)[:10],
            interval="1d", auto_adjust=False)
    except Exception:
        return None
    if h is None or h.empty:
        return None
    col = "Adj Close" if "Adj Close" in h.columns else "Close"
    s = h[col].copy()
    s.index = pd.to_datetime(s.index).tz_localize(None).normalize()
    return s


def main(start="2018-01-01", end="2023-12-31", n_names=25):
    print("=" * 78)
    print("BHAVCOPY PIPELINE AUDIT  --  reconstructed adj_close vs yfinance")
    print("=" * 78)
    print(f"window: {start} .. {end}")

    names = [t.replace(".NS", "") for t in DEFAULT_UNIVERSE][:n_names]

    print("\nloading cached bhavcopy ...")
    px = bc.load_cache(start, end, symbols=names)
    if not len(px):
        print("  NO CACHED DATA. Run tests/validation/fetch_bhav_cache.py first.")
        return 1
    print(f"  {len(px):,} rows | {px['symbol'].nunique()} names | "
          f"{px['datetime'].nunique()} dates")

    print("fetching corporate actions ...")
    acts = bc.corporate_actions(start, end)
    n_px = int((acts["factor"] != 1.0).sum())
    n_dv = int((acts["dividend"] > 0).sum())
    print(f"  {len(acts)} actions ({n_px} split/bonus, {n_dv} dividend)")

    adj = bc.adjust_prices(px, acts)

    print("\ncomparing return series against yfinance ...")
    rows = []
    for sym in sorted(adj["symbol"].unique()):
        ours = adj[adj["symbol"] == sym].set_index("datetime")["adj_close"]
        theirs = _yf_adj(sym, start, end)
        if theirs is None:
            rows.append((sym, np.nan, np.nan, np.nan, 0, "no yfinance data"))
            continue
        both = pd.concat([ours.rename("ours"), theirs.rename("yf")],
                         axis=1).dropna()
        if len(both) < 60:
            rows.append((sym, np.nan, np.nan, np.nan, len(both), "too few overlaps"))
            continue
        r_ours = np.diff(np.log(both["ours"].to_numpy()))
        r_yf = np.diff(np.log(both["yf"].to_numpy()))
        corr = float(np.corrcoef(r_ours, r_yf)[0, 1])
        diff = np.abs(r_ours - r_yf)
        rows.append((sym, corr, float(diff.max()), float(diff.mean()),
                     len(both), ""))

    res = pd.DataFrame(rows, columns=["symbol", "ret_corr", "max_abs_diff",
                                      "mean_abs_diff", "n_days", "note"])

    print()
    print(f"{'symbol':14s}{'ret corr':>10s}{'max |d|':>10s}"
          f"{'mean |d|':>10s}{'days':>7s}  note")
    for _, r in res.iterrows():
        c = "  n/a" if pd.isna(r["ret_corr"]) else f"{r['ret_corr']:10.5f}"
        mx = "     n/a" if pd.isna(r["max_abs_diff"]) else f"{r['max_abs_diff']:10.5f}"
        mn = "     n/a" if pd.isna(r["mean_abs_diff"]) else f"{r['mean_abs_diff']:10.6f}"
        print(f"{r['symbol'][:13]:14s}{c}{mx}{mn}{r['n_days']:7d}  {r['note']}")

    ok = res.dropna(subset=["ret_corr"])
    print("\n" + "-" * 78)
    if len(ok):
        print(f"names compared          : {len(ok)}")
        print(f"median return corr      : {ok['ret_corr'].median():.5f}")
        print(f"names with corr > 0.999 : "
              f"{int((ok['ret_corr'] > 0.999).sum())} / {len(ok)}")
        print(f"median mean|diff|       : {ok['mean_abs_diff'].median():.6f}")
        print(f"worst max|diff|         : {ok['max_abs_diff'].max():.5f} "
              f"({ok.loc[ok['max_abs_diff'].idxmax(), 'symbol']})")

    # --- the survivorship claim, stated numerically -------------------------
    print("\n" + "-" * 78)
    print("survivorship check: names traded in-window vs today's active list")
    try:
        live = pd.read_csv(
            "https://archives.nseindia.com/content/equities/EQUITY_L.csv")
        live.columns = [c.strip() for c in live.columns]
        active = set(live["SYMBOL"].astype(str).str.strip())
        traded = bc.load_cache(start, str(pd.Timestamp(start) +
                                          pd.Timedelta(days=20))[:10])
        traded_syms = set(traded["symbol"].unique())
        gone = traded_syms - active
        print(f"  traded in the first weeks of the window : {len(traded_syms)}")
        print(f"  absent from today's EQUITY_L.csv        : {len(gone)} "
              f"({100 * len(gone) / max(len(traded_syms), 1):.1f}%)")
        print(f"  sample: {sorted(gone)[:10]}")
        print("  These are recoverable from bhavcopy and NOT from yfinance;")
        print("  a universe drawn from today's list would silently omit them.")
    except Exception as exc:
        print(f"  (skipped: {type(exc).__name__})")

    return 0


if __name__ == "__main__":
    a = sys.argv[1:]
    sys.exit(main(*a) if a else main())
