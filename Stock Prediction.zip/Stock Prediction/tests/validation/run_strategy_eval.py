"""
Economic (investment-strategy) evaluation of the model suite.

The complement to ``run_full_backtest.py``. That driver answers "whose forecast is
closest?" (RMSE / MASE / Diebold-Mariano). This one answers the question a user
of a forecast actually has: **"would acting on it have made money, after costs?"**
— using the book Ch. 3 metric set (cumulative return, Sharpe, Sortino,
information ratio, maximum drawdown, information coefficient) via
``strategy_metrics``.

Why both are needed: RMSE is dominated by the magnitude of quiet periods, P&L by
the *sign* on the few large moves, and neither is a monotone function of the
other. A model can win on RMSE and lose money, or vice versa. Costs then act as
a hard filter that no statistical metric applies.

**Expected result, stated up front.** This project's own data-snooping-robust test
(``run_spa.py``: White's Reality Check p = 0.90, Hansen's SPA p = 0.87) found no
model with a real edge over the random walk at this horizon. The honest
expectation here is therefore Sharpe ≈ 0 and negative after costs. A strongly
positive Sharpe on a handful of origins is a **red flag to investigate** (overlapping
trades, too few origins, a leak) before it is a discovery — which is why the
driver prints the origin spacing and the overlap caveat alongside every number.

Usage:
    python run_strategy_eval.py [TICKER] [--fast] [--cost BPS] [--deadband]
        TICKER      : default RELIANCE.NS
        --fast      : the quick model subset only (statistical + trees)
        --cost BPS  : one-way transaction cost in bps (default 10)
        --deadband  : only trade when the forecast move exceeds the cost hurdle
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import backtest as bt
import multiple_testing as mt
import strategy_metrics as sm

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
_flags = [a for a in sys.argv[1:] if a.startswith("--")]
TICKER = _pos[0] if _pos else "RELIANCE.NS"
INTERVAL = "1d"
HORIZON = 5
MIN_TRAIN = 300
MAX_ROWS = 900
FAST = "--fast" in _flags

COST_BPS = 10.0
if "--cost" in _flags:
    i = sys.argv.index("--cost")
    if i + 1 < len(sys.argv):
        COST_BPS = float(sys.argv[i + 1])

# Position rule. 'deadband' only trades when the claimed move clears the round-trip
# cost, which is the economic analogue of the app's abstention gate.
POSITION_MODE = 'deadband' if "--deadband" in _flags else 'sign'
DEADBAND = 2.0 * COST_BPS / 1e4 if POSITION_MODE == 'deadband' else 0.0

# n_splits chosen so the origin spacing is >= HORIZON: overlapping trades would
# make the return stream serially dependent and every risk-adjusted figure
# optimistic. See the `overlapping_origins` flag in the backtest result.
N_SPLITS = 8


def fetch(ticker):
    """Fetch daily OHLCV from yfinance, mapped to the project schema."""
    h = yf.Ticker(ticker).history(period="10y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    df = h[cols].dropna().reset_index(drop=True)
    return df.tail(MAX_ROWS).reset_index(drop=True)


def _models():
    """(name, fn, kwargs) for the suite, or the fast subset."""
    from ARIMA_GARCH import run_statistical_prediction
    from ARIMAX_model import run_arimax_prediction
    from ML_model import run_ML_prediction
    from Quantile_model import run_quantile_prediction
    from RegimeSwitching_model import run_regime_prediction
    from Ensemble_model import run_ensemble_prediction

    fast = [
        ("ARIMA+GARCH", run_statistical_prediction, {}),
        ("ARIMAX+GARCH", run_arimax_prediction, {}),
        ("RegimeSwitching", run_regime_prediction, {}),
        ("XGBoost", run_ML_prediction, {"model_type": "xgboost"}),
        ("LightGBM", run_ML_prediction, {"model_type": "lightgbm"}),
        ("Quantile-LGBM", run_quantile_prediction, {}),
        ("Ensemble-Stack", run_ensemble_prediction, {}),
    ]
    if FAST:
        return fast

    from DL_model import run_DL_prediction
    from TCN_model import run_tcn_prediction
    from CNN_LSTM_model import run_cnn_lstm_prediction
    from meta_ensemble import run_meta_ensemble_prediction
    return fast + [
        ("LSTM", run_DL_prediction, {"model_type": "LSTM"}),
        ("TCN", run_tcn_prediction, {}),
        ("CNN-LSTM", run_cnn_lstm_prediction, {}),
        ("Meta-Ensemble", run_meta_ensemble_prediction, {}),
    ]


def main():
    print(f"=== Strategy evaluation | {TICKER} | horizon={HORIZON} | "
          f"cost={COST_BPS:.0f} bps/side | mode={POSITION_MODE} ===")
    df = fetch(TICKER)
    print(f"Fetched {len(df)} rows: {df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}\n")

    rows = []
    signals = {}          # model -> per-origin signal frame, for the SPA panel
    for name, fn, kwargs in _models():
        print(f"--- {name} ---")
        try:
            res = bt.walk_forward_backtest(
                df, fn, INTERVAL, HORIZON, n_splits=N_SPLITS,
                min_train=MIN_TRAIN, predict_kwargs=kwargs, model_name=name,
                verbose=False, cost_bps=COST_BPS, position_mode=POSITION_MODE)
        except Exception as exc:
            print(f"  FAILED: {str(exc)[:140]}\n")
            continue

        strat = res.get('strategy')
        if not strat:
            print("  (too few origins for an economic read)\n")
            continue

        # Re-run the bundle with the deadband when requested (the harness itself
        # only knows the mode, not the cost-derived threshold).
        if DEADBAND > 0:
            sig = res['signals']
            strat = sm.evaluate_strategy(
                sig['pred_return'].values, sig['real_return'].values,
                interval='daily', cost_bps=COST_BPS, mode='deadband',
                deadband=DEADBAND, dates=sig['datetime'].values,
                periods_per_bar=HORIZON)

        signals[name] = res['signals']
        s = res['summary']
        rows.append({
            'model': name,
            'rmse': round(float(s.loc['rmse', 'model']), 2),
            'rmse_naive': round(float(s.loc['rmse', 'naive']), 2),
            'mase': round(float(s.loc['mase', 'model']), 3),
            'dir_acc': round(float(s.loc['directional_accuracy', 'model']), 3),
            'total_ret_%': round(strat['total_return'] * 100, 2),
            'bench_ret_%': round(strat['benchmark_total_return'] * 100, 2),
            'sharpe': round(strat['sharpe'], 3),
            'sharpe_se': round(strat['sharpe_se'], 3),
            'sig': strat['sharpe_significant'],
            'sortino': round(strat['sortino'], 3),
            'info_ratio': round(strat['information_ratio'], 3),
            'max_dd_%': round(strat['max_drawdown'] * 100, 2),
            'ic': round(strat['information_coefficient'], 4),
            'ic_t': round(strat['ic_t_stat'], 2),
            'hit_%': round(strat['hit_rate'] * 100, 1),
            'cost_%': round(strat['total_cost'] * 100, 2),
            'n': strat['n_periods'],
        })
        print(sm.format_strategy_report(strat, name))
        if strat.get('caveat'):
            print(f"  NOTE: {strat['caveat']}")
        print()

    if not rows:
        print("No model produced an economic read.")
        return

    table = pd.DataFrame(rows).sort_values('sharpe', ascending=False)
    print("=" * 78)
    print("LEADERBOARD — statistical accuracy vs economic value")
    print("=" * 78)
    print(table.to_string(index=False))

    # The interesting diagnostic is whether the two rankings even agree.
    if len(table) > 2:
        r_stat = sm._rankdata(-table['rmse'].values)     # lower RMSE = better
        r_econ = sm._rankdata(table['sharpe'].values)    # higher Sharpe = better
        rho = sm.information_coefficient(r_stat, r_econ)
        print(f"\nRank correlation between RMSE ranking and Sharpe ranking: "
              f"{rho:+.3f}")
        print("Read: near 0 (or negative) means statistical accuracy and "
              "economic value rank the models differently — the reason both "
              "tables belong in the report.")

    best = table.iloc[0]
    print(f"\nBest Sharpe: {best['model']} at {best['sharpe']:.3f} "
          f"± {best['sharpe_se']:.3f} SE over {best['n']} non-overlapping "
          f"trades -> {'OUTSIDE' if best['sig'] else 'INSIDE'} 2 SE of zero.")
    print("The SE is the ANNUALISED one (Lo 2002, scaled by sqrt(periods/yr)); a "
          "bare 1/sqrt(n) would understate it by that same factor and make noise "
          "look like a discovery. With a single-digit trade count almost nothing "
          "here can clear the bar — which is the honest headline, and exactly "
          "what run_spa.py already established.")
    n_sig = int(table['sig'].sum())
    print(f"Models with a statistically distinguishable Sharpe: {n_sig} of "
          f"{len(table)}.")
    print("\nDone. Statistical skill and profitability are separate claims; "
          "this driver reports the second without assuming the first.")


if __name__ == "__main__":
    main()
