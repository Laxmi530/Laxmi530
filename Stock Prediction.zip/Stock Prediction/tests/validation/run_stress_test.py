"""
Stress-period evaluation: does adaptive conformal (ACI) earn its keep when it
matters — i.e. in a volatility regime shift?

The calm 2023-2026 window showed ACI roughly tying static conformal on coverage
(it can't adapt to a shock that isn't there). The honest test of ACI is whether
its coverage advantage *grows* in genuinely stressed periods. This driver slices
the same ticker's long history into stress windows (the 2020 COVID crash, the
2022 drawdown) and a calm window, and for each runs the HAR-RV cone both ways
(``adaptive=False`` vs ``True``) via ``calibration.compare_static_vs_aci``,
reporting per-window coverage and interval width.

Walk-forward origins are placed *inside* each window by starting the training
history far enough before the window and setting ``min_train`` to the window's
first index, so the realised outcomes being covered fall in the stressed period.

Usage:
    python run_stress_test.py [TICKER]
        TICKER : default RELIANCE.NS
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import sys
import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import calibration as cal
from HAR_RV_model import run_har_rv_prediction

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
TICKER = _pos[0] if _pos else "RELIANCE.NS"
INTERVAL = "1d"
HORIZON = 5
N_SPLITS = 12
MIN_LEAD = 320          # min trading rows before a window so HAR-RV can calibrate

# (label, start, end). Stress windows bracket the crash + its aftermath.
WINDOWS = [
    ("COVID crash 2020", "2020-02-01", "2020-07-31"),
    ("2022 drawdown",     "2022-01-01", "2022-12-31"),
    ("Calm 2024",         "2024-01-01", "2024-12-31"),
]


def fetch_max(ticker):
    """Fetch the full available daily history (need pre-2020 for the lead)."""
    h = yf.Ticker(ticker).history(period="max", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    return h[cols].dropna().reset_index(drop=True)


def realized_vol_pct(df_win):
    """Annualised-ish daily realised vol over a window (context for the read)."""
    p = pd.to_numeric(df_win["adj_close"], errors="coerce").values
    r = np.diff(np.log(p[p > 0]))
    return float(np.std(r) * 100.0) if len(r) > 1 else float("nan")


def run_window(full, label, start, end):
    print("\n" + "-" * 70)
    print(f"WINDOW: {label}  [{start} .. {end}]")
    print("-" * 70)
    end_ts, start_ts = pd.Timestamp(end), pd.Timestamp(start)
    df_win = full[full["datetime"] <= end_ts].reset_index(drop=True)
    i_start = int((df_win["datetime"] < start_ts).sum())   # first in-window row
    in_window = df_win[(df_win["datetime"] >= start_ts)]
    if i_start < MIN_LEAD:
        print(f"  Skipped: only {i_start} rows of lead history before {start} "
              f"(need >= {MIN_LEAD}).")
        return None
    if len(df_win) - HORIZON <= i_start + 5:
        print("  Skipped: too few in-window origins.")
        return None

    print(f"  rows up to window end: {len(df_win)}; in-window rows: "
          f"{len(in_window)}; realised daily vol in window: "
          f"{realized_vol_pct(in_window):.2f}%")
    cmp = cal.compare_static_vs_aci(
        df_win, run_har_rv_prediction, INTERVAL, HORIZON,
        n_splits=N_SPLITS, min_train=i_start)
    print(f"  static : |cov-0.95|={cmp['static_miscoverage']:.3f}  "
          f"mean width={cmp['static_mean_width']:.2f}%")
    print(f"  ACI    : |cov-0.95|={cmp['aci_miscoverage']:.3f}  "
          f"mean width={cmp['aci_mean_width']:.2f}%")
    print(f"  -> {cmp['verdict']}")
    return {"window": label,
            "vol_%": round(realized_vol_pct(in_window), 2),
            "static_miscov": round(cmp["static_miscoverage"], 3),
            "aci_miscov": round(cmp["aci_miscoverage"], 3),
            "static_width": round(cmp["static_mean_width"], 2),
            "aci_width": round(cmp["aci_mean_width"], 2),
            "aci_minus_static_miscov": round(
                cmp["aci_miscoverage"] - cmp["static_miscoverage"], 3)}


def main():
    print(f"=== Stress-period ACI evaluation | {TICKER} | horizon={HORIZON} ===")
    full = fetch_max(TICKER)
    print(f"Full history: {len(full)} rows "
          f"{full['datetime'].iloc[0].date()} -> {full['datetime'].iloc[-1].date()}")

    rows = [r for r in (run_window(full, *w) for w in WINDOWS) if r]
    if not rows:
        print("\nNo window had enough history; try a ticker with longer history.")
        return

    summary = pd.DataFrame(rows)
    print("\n" + "=" * 70)
    print("SUMMARY: ACI vs static across regimes (negative aci_minus_static_"
          "miscov = ACI improved coverage)")
    print("=" * 70)
    print(summary.to_string(index=False))
    helped = summary[summary["aci_minus_static_miscov"] < 0]
    print(f"\nACI improved coverage in {len(helped)}/{len(summary)} windows. "
          "Note whether the benefit tracks volatility: in principle ACI should "
          "help most where there is a regime shift to respond to, but it can "
          "over- or under-shoot during an extreme crash (it widens, which is the "
          "right direction, but calibration in the tail is hard). Read the width "
          "column too: ACI tends to sharpen in milder regimes. These are "
          "single-ticker, small-sample reads — illustrative, not a final verdict.")


if __name__ == "__main__":
    main()
