"""
Multi-ticker, multi-split walk-forward backtest for a variance-aware ranking.

A single ticker / few-split backtest is noisy — the neural nets in particular
swing a lot run-to-run. This harness evaluates each model across several
tickers (and more walk-forward origins per ticker), then aggregates per model:

- mean and std of RMSE (and MASE) across all (ticker, split) evaluations,
- ``beats_naive_rate`` — the fraction of tickers where the model's mean RMSE
  beats the naive random walk,
- mean directional accuracy and mean interval coverage.

A model that is *consistently* a little better than the random walk is worth
far more than one that wins big on a single lucky ticker, and the std column
makes that distinction explicit.

Results are checkpointed per (ticker, model) to CSV and the run is resumable.

Usage:
    python run_multi_backtest.py [TICKERS] [--fast]
        TICKERS : comma-separated, e.g. "AAPL,MSFT,GOOGL" (default these three)
        --fast  : exclude the slow neural nets (tree + statistical models only)
        --with-nn : include a representative subset of neural nets (LSTM, N-BEATS)
        --with-context : attach market/VIX context features (off by default; the
                  A/B backtest showed they don't help at a 5-day horizon)
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import os
import sys
import time
import traceback
import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import backtest as bt

warnings.filterwarnings("ignore")

_args = [a for a in sys.argv[1:] if not a.startswith("--")]
_flags = {a for a in sys.argv[1:] if a.startswith("--")}

TICKERS = (_args[0].split(",") if _args else ["AAPL", "MSFT", "GOOGL"])
INTERVAL = "1d"
HORIZON = 5
N_SPLITS = 4
MIN_TRAIN = 400
MAX_ROWS = 700
OUT_CSV = "multi_backtest.csv"


def fetch(ticker):
    """Fetch daily OHLCV from yfinance and map to the project schema."""
    h = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    df = h[cols].dropna().reset_index(drop=True)
    return df.tail(MAX_ROWS).reset_index(drop=True)


def build_registry():
    """(name, callable, predict_kwargs) honouring the --fast / --with-nn flags."""
    from ML_model import run_ML_prediction
    from Quantile_model import run_quantile_prediction
    from Ensemble_model import run_ensemble_prediction
    from ARIMA_GARCH import run_statistical_prediction
    from ARIMAX_model import run_arimax_prediction
    from fb_prophet_model import run_prophet_prediction
    from RegimeSwitching_model import run_regime_prediction
    from HAR_RV_model import run_har_rv_prediction
    from meta_ensemble import run_meta_ensemble_prediction

    models = [
        ("XGBoost",         run_ML_prediction,          {"model_type": "xgboost"}),
        ("LightGBM",        run_ML_prediction,          {"model_type": "lightgbm"}),
        ("Quantile-LGBM",   run_quantile_prediction,    {}),
        ("Ensemble-Stack",  run_ensemble_prediction,    {}),
        ("Meta-Ensemble",   run_meta_ensemble_prediction, {}),
        ("ARIMA+GARCH",     run_statistical_prediction, {}),
        ("ARIMAX+GARCH",    run_arimax_prediction,      {}),
        ("Prophet",         run_prophet_prediction,     {}),
        ("RegimeSwitching", run_regime_prediction,      {}),
        ("HAR-RV",          run_har_rv_prediction,      {}),
    ]

    if "--fast" not in _flags:
        # Default: a representative neural-net subset (these are slow to train).
        # LSTM (recurrent) + N-BEATS (the high-variance MLP) illustrate NN spread
        # without the full 5-net cost; add others via the suite's run_* funcs.
        from DL_model import run_DL_prediction
        from NBeats_model import run_nbeats_prediction
        models += [
            ("LSTM",    run_DL_prediction,    {"model_type": "LSTM"}),
            ("N-BEATS", run_nbeats_prediction, {}),
        ]
    return models


def main():
    print(f"=== Multi-ticker backtest | tickers={TICKERS} | "
          f"horizon={HORIZON} | splits={N_SPLITS} ===")

    rows = []
    done = set()
    if os.path.exists(OUT_CSV):
        prior = pd.read_csv(OUT_CSV)
        rows = prior.to_dict("records")
        done = {(r["ticker"], r["model"]) for r in rows}
        print(f"Resuming: {len(done)} (ticker, model) pairs already done")

    registry = build_registry()

    # Market/VIX context is opt-in (--with-context): the A/B backtest showed it
    # doesn't help at this horizon and hurts the single tree models.
    use_ctx = "--with-context" in _flags
    if use_ctx:
        from market_context import add_market_context
        print("Market-context features ENABLED.")

    data = {}
    for tk in TICKERS:
        try:
            df_tk = fetch(tk)
            data[tk] = add_market_context(df_tk, INTERVAL) if use_ctx else df_tk
            print(f"  fetched {tk}: {len(data[tk])} rows")
        except Exception as exc:
            print(f"  FAILED to fetch {tk}: {exc}")

    for tk, df in data.items():
        for name, fn, kw in registry:
            if (tk, name) in done:
                continue
            t0 = time.time()
            try:
                res = bt.walk_forward_backtest(
                    df, fn, INTERVAL, HORIZON,
                    n_splits=N_SPLITS, min_train=MIN_TRAIN,
                    predict_kwargs=kw, model_name=name, verbose=False,
                )
                s = res["summary"]
                dm = res.get("dm", {})
                cov = s.loc["coverage", "model"] if "coverage" in s.index else np.nan
                row = {
                    "ticker": tk, "model": name,
                    "rmse": round(s.loc["rmse", "model"], 4),
                    "naive_rmse": round(s.loc["rmse", "naive"], 4),
                    "drift_rmse": (round(s.loc["rmse", "drift"], 4)
                                   if "drift" in s.columns else np.nan),
                    "ar1_rmse": (round(s.loc["rmse", "ar1"], 4)
                                 if "ar1" in s.columns else np.nan),
                    "mase": round(s.loc["mase", "model"], 4),
                    "beats_naive": bool(s.loc["rmse", "model"] < s.loc["rmse", "naive"]),
                    "dm_p": (round(dm["p_value"], 4)
                             if dm and np.isfinite(dm.get("p_value", np.nan)) else np.nan),
                    "dm_sig": (dm.get("favors") or "ns") if dm else "ns",
                    "dir_acc": round(s.loc["directional_accuracy", "model"], 4),
                    "coverage": (round(cov, 4) if not np.isnan(cov) else np.nan),
                    "secs": round(time.time() - t0, 1),
                }
            except Exception as exc:
                traceback.print_exc()
                row = {
                    "ticker": tk, "model": name, "rmse": np.nan,
                    "naive_rmse": np.nan, "drift_rmse": np.nan, "ar1_rmse": np.nan,
                    "mase": np.nan, "beats_naive": False, "dm_p": np.nan,
                    "dm_sig": "ns", "dir_acc": np.nan, "coverage": np.nan,
                    "secs": round(time.time() - t0, 1),
                }
            rows.append(row)
            pd.DataFrame(rows).to_csv(OUT_CSV, index=False)   # checkpoint
            print(f"DONE {tk:7} {name:16} rmse={row['rmse']} "
                  f"beats={row['beats_naive']} ({row['secs']}s)")

    _print_leaderboard(rows)


def _print_leaderboard(rows):
    """Aggregate per model across tickers and print a variance-aware ranking."""
    df = pd.DataFrame(rows)
    df = df[df["rmse"].notna()]
    if df.empty:
        print("No successful runs.")
        return

    agg = df.groupby("model").agg(
        n_tickers=("ticker", "nunique"),
        rmse_mean=("rmse", "mean"),
        rmse_std=("rmse", "std"),
        mase_mean=("mase", "mean"),
        beats_rate=("beats_naive", "mean"),
        dir_acc_mean=("dir_acc", "mean"),
        coverage_mean=("coverage", "mean"),
    ).reset_index()
    agg = agg.sort_values("rmse_mean").reset_index(drop=True)

    print("\n========= VARIANCE-AWARE LEADERBOARD (across tickers) =========")
    with pd.option_context("display.width", 200,
                           "display.max_columns", None):
        print(agg.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    consistent = agg[agg["beats_rate"] >= 0.5]["model"].tolist()
    print(f"\nBeat the random walk on >=50% of tickers: "
          f"{consistent if consistent else 'NONE'}")


if __name__ == "__main__":
    main()
