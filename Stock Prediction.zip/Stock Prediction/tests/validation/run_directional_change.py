"""
Does Directional Change tell us anything a time series does not?

Tsang, *AI for Finance* (2023), Ch. 6, makes three claims for the DC
representation. Each is testable, and none is tested in the book.

1. **Two "striking discoveries"** (6.5), found by Olsen's group across all
   major FX pairs and all thresholds: a trend ends on average at *twice* the
   threshold, and the overshoot leg takes *twice* as long as the leg that
   confirmed it. The book: "These were observations; no explanation is
   available."
2. **New volatility measures** (6.3) -- event frequency and mean trend
   magnitude -- said to be "independent of the volatility measures under Time
   Series", and orthogonal to each other.
3. **New variables for machine learning** (6.4): "Practitioners equipped with
   more variables will have a better chance to beat their competitors."

Claim 1 has an explanation, and it is not a market one. For driftless Brownian
motion the running maximum reached before a ``theta`` drawdown is
**Exponential with mean theta**. So the overshoot averages exactly one
threshold, and the trend ends at two, in any market, informative or not.
Part 1 confirms this by simulation; the book's own caveat that "the majority of
trends ended far sooner" is the exponential's median, ln 2 = 0.693.

That makes Part 2 the only interesting version of claim 1: not "do NSE
equities obey the laws" but "do they deviate from what noise already
produces". Each name is compared against a random walk matched to its own
volatility and length.

Claims 2 and 3 are answered in Parts 3 and 4 by measurement: the correlation
between the DC volatility measures and plain realised volatility, and the
Fama-MacBeth IC of the causal DC features against forward returns.

Run::

    python tests/validation/run_directional_change.py
    python tests/validation/run_directional_change.py --n 200 --horizon 5
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                  # noqa: E402
import directional_change as dc        # noqa: E402
import strategy_metrics as sm          # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


# 2018, matching run_universe_expansion.py, run_universe_attribution.py and
# run_reversal_costs.py. Section 45 showed how much this choice costs: the
# reversal book posts an annualised Sharpe of 1.01 on 2022-2024 against 0.24
# over the full period, so a section measured on a different window is not
# comparable to the ones it cites.
START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "400"))
HORIZON = int(_arg("--horizon", "5"))
SEED = int(_arg("--seed", "42"))
THETAS = (0.02, 0.03, 0.05, 0.10)
OUT = os.path.join(_HERE, "directional_change.csv")

#: Section 38's replicated cross-sectional rank IC, for scale.
SECTION_38_IC = 0.0396


# ==========================================================================
# 1. The null
# ==========================================================================
def part1_null():
    print("=" * 78)
    print("1. THE NULL  --  a driftless random walk, sampled ever more finely")
    print("=" * 78)
    print("  Theory: for driftless Brownian motion the running maximum before a")
    print("  theta drawdown is Exponential(mean theta). So OS/theta -> 1 and its")
    print("  median -> ln 2 = 0.693, with no market involved.\n")
    theta = 0.05
    rng = np.random.default_rng(SEED)
    print(f"{'steps/theta':>12s}{'events':>9s}{'DC/th':>8s}{'OS/th':>8s}"
          f"{'OS/DC':>8s}{'med OS/th':>11s}{'t_OS/t_DC':>11s}")
    for k in (1, 2, 5, 10, 25):
        # Event count falls off roughly as k^-1.7 at fixed length, so a fixed
        # path would leave the finest grid -- the one that actually tests the
        # limit -- with a few hundred events and too noisy to show convergence.
        w = pd.Series(np.exp(np.cumsum(
            rng.standard_normal(300_000 * k) * theta / k)))
        s = dc.scaling_laws(dc.dc_events(w, theta), theta)
        print(f"{k:12d}{s['n_events']:9d}{s['dc_over_theta_mean']:8.3f}"
              f"{s['os_over_theta_mean']:8.3f}{s['os_over_dc_mean']:8.3f}"
              f"{s['os_over_theta_median']:11.3f}{s['time_ratio_mean']:11.3f}")
    print(f"\n{'predicted':>12s}{'':9s}{1.0:8.3f}{1.0:8.3f}{1.0:8.3f}"
          f"{np.log(2.0):11.3f}{2.0:11.3f}")
    print("\n  Both 'striking discoveries' are properties of Brownian motion.")
    print("  A market that obeys them is telling us it is a random walk.")
    print("\n  Note the first row: at daily resolution a single session can jump")
    print("  well past theta, so the DC leg is NOT theta and OS/theta inflates")
    print("  with it. OS/DC stays at 1.0 throughout -- it is the statistic that")
    print("  survives coarse sampling, and the one Part 2 uses.")


# ==========================================================================
# 2. Real names against a volatility-matched null
# ==========================================================================
def _per_name(prices, theta, rng):
    """
    Scaling stats for one name against two nulls.

    **gauss** -- an iid Gaussian walk at the name's volatility, zero drift.
    The textbook null, and too weak on its own: real returns have volatility
    clustering and fat tails, either of which enlarges an overshoot relative to
    constant-sigma Gaussian noise without saying anything about *direction*,
    which is what DC is about.

    **flip** -- the name's own log returns with randomised signs. ``|r_t|`` is
    held fixed bar for bar, so volatility clustering and tail shape are not
    merely matched but identical, while directional structure is destroyed.

    Both nulls are driftless, and that is the trap. NSE compounded about
    +17%/yr over this window; a drifting series spends longer in up-trends, so
    its overshoot leg runs further than a driftless null's *for no reason
    connected to Directional Change at all*. Measured against ``flip`` alone
    the market appears to beat noise at t = +6, which is a restatement of the
    bull market. ``demean`` removes each name's own mean log return and leaves
    everything else untouched, and it is the comparison that answers the
    question actually being asked.
    """
    p = prices.to_numpy(dtype=float)
    if len(p) < 120:
        return None
    r = np.diff(np.log(p))
    sigma = float(np.std(r, ddof=1))
    if not np.isfinite(sigma) or sigma <= 0:
        return None
    mu = float(np.mean(r))

    real = dc.scaling_laws(dc.dc_events(prices, theta), theta)
    demean = dc.scaling_laws(dc.dc_events(
        pd.Series(np.exp(np.cumsum(np.r_[0.0, r - mu]))), theta), theta)
    gauss = dc.scaling_laws(dc.dc_events(
        pd.Series(np.exp(np.cumsum(rng.standard_normal(len(p)) * sigma))),
        theta), theta)
    # dc.sign_flip_path is the same null dc.scaling_law_test uses, shared so
    # the panel test here and the single-series test in the module cannot
    # diverge. The two designs are complementary: this one pairs each name
    # against one flip across 395 names, the module's repeats the flip within
    # a single name.
    flip = dc.scaling_laws(dc.dc_events(dc.sign_flip_path(r, rng), theta), theta)

    if not all(s.get("n_events") for s in (real, demean, gauss, flip)):
        return None
    out = {"sigma": sigma, "drift_annual": mu * 252.0,
           "real_n": real["n_events"], "real_dc_th": real["dc_over_theta_mean"]}
    for tag, s in (("real", real), ("demean", demean),
                   ("gauss", gauss), ("flip", flip)):
        out[f"{tag}_os_dc"] = s["os_over_dc_mean"]
        out[f"{tag}_time"] = s["time_ratio_mean"]
    return out


def _paired_t(a, b):
    ok = np.isfinite(a) & np.isfinite(b)
    d = a[ok] - b[ok]
    if len(d) < 3 or np.std(d, ddof=1) == 0:
        return np.nan
    return float(np.mean(d) / (np.std(d, ddof=1) / np.sqrt(len(d))))


def part2_real(by_symbol):
    print("\n" + "=" * 78)
    print("2. NSE EQUITIES AGAINST TWO NULLS")
    print("=" * 78)
    print(f"  {len(by_symbol)} names | {START} .. {END} | adjusted closes")
    print("  flip   = the name's OWN returns, signs randomised: volatility")
    print("           clustering and fat tails identical, direction destroyed.")
    print("  demean = the name's own path with its mean log return removed,")
    print("           so it is compared against a null of its own drift.\n")
    print(f"{'theta':>7s}{'names':>7s}{'ev/nm':>7s}{'drift':>8s}"
          f"{'OS/DC':>8s}{'demean':>8s}{'flip':>7s}"
          f"{'t raw':>8s}{'t demean':>10s}"
          f"{'  |':>3s}{'t_OS/t_DC':>10s}{'flip':>7s}{'t':>7s}")
    rows = []
    for theta in THETAS:
        rng = np.random.default_rng(SEED)
        recs = [x for x in (_per_name(s, theta, rng)
                            for s in by_symbol.values()) if x]
        if len(recs) < 10:
            print(f"{theta:7.1%}{len(recs):7d}   too few names with events")
            continue
        d = pd.DataFrame(recs)
        g = lambda c: d[c].to_numpy(dtype=float)   # noqa: E731
        out = {"theta": theta, "names": len(d),
               "events_per_name": float(d["real_n"].mean()),
               "dc_over_theta": float(d["real_dc_th"].mean()),
               "drift_annual": float(np.nanmean(g("drift_annual"))),
               "os_dc_real": float(np.nanmean(g("real_os_dc"))),
               "os_dc_demean": float(np.nanmean(g("demean_os_dc"))),
               "os_dc_gauss": float(np.nanmean(g("gauss_os_dc"))),
               "os_dc_flip": float(np.nanmean(g("flip_os_dc"))),
               "os_dc_t_raw": _paired_t(g("real_os_dc"), g("flip_os_dc")),
               "os_dc_t_demean": _paired_t(g("demean_os_dc"), g("flip_os_dc")),
               "time_demean": float(np.nanmean(g("demean_time"))),
               "time_flip": float(np.nanmean(g("flip_time"))),
               "time_t_demean": _paired_t(g("demean_time"), g("flip_time"))}
        rows.append(out)
        print(f"{theta:7.1%}{out['names']:7d}{out['events_per_name']:7.1f}"
              f"{out['drift_annual']:7.1%} "
              f"{out['os_dc_real']:8.3f}{out['os_dc_demean']:8.3f}"
              f"{out['os_dc_flip']:7.3f}"
              f"{out['os_dc_t_raw']:8.2f}{out['os_dc_t_demean']:10.2f}"
              f"{'  |':>3s}{out['time_demean']:10.2f}{out['time_flip']:7.2f}"
              f"{out['time_t_demean']:7.2f}")
    print("\n  Paired per name. |t| > 2 is a deviation from the flip null.")
    _subperiods(by_symbol)
    print("\n  't raw' is the number this test produces if you forget that both")
    print("  nulls are driftless. It reaches +6 and means nothing but that NSE")
    print("  rose. 't demean' is the same test with each name measured against")
    print("  its own drift, and it is the column to read.")
    print("\n  The iid Gaussian null lands within ~0.02 of the sign-flipped one")
    print("  at every threshold, so fat tails and volatility clustering are not")
    print("  driving any of this either.")
    return pd.DataFrame(rows)



def _subperiods(by_symbol, theta=0.05):
    """
    Split the window. A deviation that lives in one year is not a property of
    the market; it is a property of that year.

    2018-2024 contains the COVID crash, in which every name trended hard in one
    direction for weeks. Long runs of same-sign returns are exactly what a sign
    flip destroys, so a crash inflates the real series' overshoot against its
    own null without any standing regularity being involved.
    """
    print("")
    print("  Is the deviation a property of the market, or of one year? "
          f"(theta {theta:.0%})")
    print(f"    {'period':<18}{'names':>7}{'real':>8}{'flip':>8}{'t':>8}")
    spans = (("full 2018-2024", START, END),
             ("pre  2018-2019", "2018-01-01", "2019-12-31"),
             ("2020 only", "2020-01-01", "2020-12-31"),
             ("post 2021-2024", "2021-01-01", END))
    for label, a, b in spans:
        rng = np.random.default_rng(SEED)
        real, flip = [], []
        for s in by_symbol.values():
            w = s[(s.index >= pd.Timestamp(a)) & (s.index <= pd.Timestamp(b))]
            if len(w) < 120:
                continue
            r = np.diff(np.log(w.to_numpy(dtype=float)))
            r = r - r.mean()
            real.append(dc.scaling_laws(dc.dc_events(
                pd.Series(np.exp(np.cumsum(np.r_[0.0, r]))), theta),
                theta).get("os_over_dc_mean", np.nan))
            flip.append(dc.scaling_laws(dc.dc_events(
                dc.sign_flip_path(r, rng), theta),
                theta).get("os_over_dc_mean", np.nan))
        ra, fa = np.asarray(real, float), np.asarray(flip, float)
        print(f"    {label:<18}{len(ra):>7}{np.nanmean(ra):>8.3f}"
              f"{np.nanmean(fa):>8.3f}{_paired_t(ra, fa):>8.2f}")
    print("    A deviation confined to 2020 is a crash, not a regularity.")


# ==========================================================================
# 3. Are the DC volatility measures new information?
# ==========================================================================
def _spearman(a, b):
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() < 10:
        return np.nan
    ra = pd.Series(a[m]).rank().to_numpy()
    rb = pd.Series(b[m]).rank().to_numpy()
    if np.std(ra) == 0 or np.std(rb) == 0:
        return np.nan
    return float(np.corrcoef(ra, rb)[0, 1])


def part3_orthogonality(by_symbol, theta=0.05):
    print("\n" + "=" * 78)
    print(f"3. CHAPTER 6.3's VOLATILITY MEASURES  (theta = {theta:.0%})")
    print("=" * 78)
    print('  Tsang: DC event frequency is "independent of the volatility')
    print('  measures under Time Series", and the two DC measures are')
    print('  "orthogonal" to each other. Both are measurable.\n')
    recs = []
    for sym, s in by_symbol.items():
        if len(s) < 250:
            continue
        ev = dc.dc_events(s, theta)
        if len(ev) == 0:
            continue
        vol = dc.dc_volatility(ev, freq="ME")
        lr = np.log(s).diff()
        rv = lr.resample("ME").std() * np.sqrt(252.0)
        j = vol.join(rv.rename("realised_vol"), how="inner").dropna()
        for ts, r in j.iterrows():
            recs.append({"symbol": sym, "month": ts, "dc_count": r["dc_count"],
                         "mean_move": r["mean_move"],
                         "realised_vol": r["realised_vol"]})
    if len(recs) < 50:
        print("  too few name-months")
        return {}
    d = pd.DataFrame(recs)
    cnt = d["dc_count"].to_numpy(dtype=float)
    mv = d["mean_move"].to_numpy(dtype=float)
    rvv = d["realised_vol"].to_numpy(dtype=float)
    res = {"n_name_months": len(d),
           "rho_count_rv": _spearman(cnt, rvv),
           "rho_move_rv": _spearman(mv, rvv),
           "rho_count_move": _spearman(cnt, mv)}
    print(f"  name-months                          : {res['n_name_months']:,}")
    print(f"  rho( DC event count , realised vol ) : {res['rho_count_rv']:+.3f}")
    print(f"  rho( mean trend move, realised vol ) : {res['rho_move_rv']:+.3f}")
    print(f"  rho( DC count       , mean move    ) : {res['rho_count_move']:+.3f}")
    print()
    print(f"  Neither DC measure is a restatement of realised volatility "
          f"(max |rho| {max(abs(res['rho_count_rv']), abs(res['rho_move_rv'])):.2f}),")
    print(f"  and the two are close to orthogonal to each other "
          f"({res['rho_count_move']:+.2f}), as Chapter 6.3 claims.")
    print('  "Independent" overstates it -- more direction changes do go with a')
    print("  more volatile month -- but these are genuinely not the same")
    print("  quantity. Chapter 6.3 survives. Whether a distinct volatility")
    print("  measure is a useful one is a separate question, asked in Part 4.")
    return res


# ==========================================================================
# 4. Do the causal DC features predict anything?
# ==========================================================================
def part4_ic(by_symbol, theta=0.05):
    print("\n" + "=" * 78)
    print(f"4. FAMA-MACBETH IC OF THE DC STATE FEATURES  ({HORIZON}-day forward)")
    print("=" * 78)
    print("  Features come from dc_state, so every value is computed from bars")
    print("  up to and including its own -- the flip is dated at confirmation,")
    print("  not at the extreme it later turns out to have started from.\n")
    frames = []
    for sym, s in by_symbol.items():
        if len(s) < 250:
            continue
        st = dc.dc_state(s, theta)
        fwd = s.shift(-HORIZON) / s - 1.0
        # The benchmark. Sections 38/39 found the dominant signal in this panel
        # is short-term reversal: the trailing 5-day return alone scored an IC
        # of -0.0524 (t -4.34), stronger than the fitted model. Any DC feature
        # has to be measured against it, not against zero.
        st = st.assign(symbol=sym, date=st.index, forward=fwd.to_numpy(),
                       trailing_5=(s / s.shift(HORIZON) - 1.0).to_numpy(),
                       vol20=(np.log(s).diff().rolling(20).std()
                              * np.sqrt(252.0)).to_numpy())
        frames.append(st)
    if not frames:
        print("  no usable names")
        return pd.DataFrame()
    panel = pd.concat(frames, ignore_index=True)
    panel = panel[panel["direction"] != 0].dropna(subset=["forward"])
    # Cross-sectional demeaning: without it a feature that merely tracks the
    # market's own direction scores on beta, not on selection.
    panel["forward"] = panel["forward"] - panel.groupby("date")["forward"].transform("mean")

    print(f"  rows {len(panel):,} | names {panel['symbol'].nunique()} | "
          f"dates {panel['date'].nunique()}\n")
    print(f"{'feature':>20s}{'mean IC':>10s}{'t':>8s}{'hit':>8s}{'dates':>8s}")
    rows = []
    for f in tuple(dc.STATE_COLUMNS) + ("trailing_5",):
        ic = sm.ic_by_date(panel["date"], panel[f], panel["forward"],
                           min_names=20, rank=True)
        if len(ic) < 20:
            continue
        r = sm.fama_macbeth_ic(ic, lags=HORIZON)
        rows.append({"feature": f, **r})
        mark = "   <- the known reversal signal" if f == "trailing_5" else ""
        print(f"{f:>20s}{r['mean_ic']:+10.4f}{r['t_stat']:+8.2f}"
              f"{r['hit_rate']:8.2f}{r['n_dates']:8d}{mark}")
    # Same window as §38 now (2018-01-01), so this is a like-for-like
    # reference rather than a number from a different period.
    print(f"\n  Section 38's cross-sectional model, same window: "
          f"{SECTION_38_IC:+.4f}")
    print("  |t| > 2 with the horizon's Newey-West lag would be a finding.")

    # Redundancy: is the best DC feature a reworded trailing return?
    best = max((r for r in rows if r["feature"] != "trailing_5"),
               key=lambda r: abs(r["t_stat"]), default=None)
    if best is not None:
        rho = _spearman(panel[best["feature"]].to_numpy(dtype=float),
                        panel["trailing_5"].to_numpy(dtype=float))
        print(f"\n  rho( {best['feature']} , trailing {HORIZON}d return ) = "
              f"{rho:+.3f}")
        if abs(rho) > 0.6:
            print("  The strongest DC feature is largely the trailing return in")
            print("  event-based clothing. Its IC is the same reversal signal")
            print("  Section 39 costed at a 6.1 bp breakeven and Section 43")
            print("  showed fails multiple-testing deflation before any cost.")
        for r in rows:
            if r["feature"] == best["feature"]:
                r["rho_with_trailing"] = rho

    # A DC feature can be orthogonal to the reversal signal and still be a
    # restatement of a different known one. bars_in_trend counts how long the
    # current trend has run: a quiet stock takes longer to travel theta, so it
    # is an inverse-volatility proxy -- and low volatility is itself a
    # documented cross-sectional effect. Neutralising within volatility
    # quintiles asks whether anything survives that is actually about DC.
    if best is not None and "vol20" in panel.columns:
        v = panel.dropna(subset=["vol20"]).copy()
        rho_v = _spearman(v[best["feature"]].to_numpy(dtype=float),
                          v["vol20"].to_numpy(dtype=float))
        ic_v = sm.fama_macbeth_ic(sm.ic_by_date(
            v["date"], v["vol20"], v["forward"], min_names=20, rank=True),
            lags=HORIZON)
        v["volq"] = v.groupby("date")["vol20"].transform(
            lambda x: pd.qcut(x.rank(method="first"), 5, labels=False,
                              duplicates="drop"))
        v["neutral"] = v.groupby(["date", "volq"])[best["feature"]].transform(
            lambda x: x.rank(pct=True) - 0.5)
        ic_n = sm.fama_macbeth_ic(sm.ic_by_date(
            v["date"], v["neutral"], v["forward"], min_names=20, rank=True),
            lags=HORIZON)
        print("")
        print(f"  rho( {best['feature']} , 20d realised vol ) = {rho_v:+.3f}")
        print(f"  IC of realised vol itself          : "
              f"{ic_v['mean_ic']:+.4f}  t {ic_v['t_stat']:+.2f}")
        print(f"  IC of {best['feature']} NEUTRALISED within vol quintiles: "
              f"{ic_n['mean_ic']:+.4f}  t {ic_n['t_stat']:+.2f}")
        if abs(ic_n["t_stat"]) < 2 <= abs(best["t_stat"]):
            print("  The feature does not survive its own volatility proxy.")
        for r in rows:
            if r["feature"] == best["feature"]:
                r.update(rho_with_vol=rho_v, ic_vol_neutral=ic_n["mean_ic"],
                         t_vol_neutral=ic_n["t_stat"])

    return pd.DataFrame(rows)


def main():
    print("=" * 78)
    print("DIRECTIONAL CHANGE  (Tsang, AI for Finance, Ch. 6)")
    print("=" * 78)
    part1_null()

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nbuilding panel ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, brep = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    by_symbol = {}
    for sym, g in panel.groupby("symbol"):
        s = g.set_index("datetime")["adj_close"].astype(float).sort_index()
        s = s[np.isfinite(s.to_numpy()) & (s.to_numpy() > 0)]
        if len(s) >= 120:
            by_symbol[sym] = s
    print(f"  {len(by_symbol)} names usable")

    laws = part2_real(by_symbol)
    orth = part3_orthogonality(by_symbol)
    ics = part4_ic(by_symbol)

    if len(laws):
        laws.to_csv(OUT, index=False)
        print(f"\nwrote {OUT}")

    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    if len(laws):
        raw = laws["os_dc_t_raw"].abs().max()
        dem = laws.reindex(laws["os_dc_t_demean"].abs().sort_values(
            ascending=False).index).iloc[0]
        print(f"  Scaling laws: reproduced by a driftless random walk (Part 1),")
        print(f"  so obeying them is not evidence of anything. Against a")
        print(f"  drift-matched null the largest deviation left is theta "
              f"{dem['theta']:.0%} at t = {dem['os_dc_t_demean']:+.2f}")
        print(f"  (it is t = {raw:+.2f} if the drift is left in).")
    if orth:
        print(f"  Chapter 6.3's two volatility measures are real and distinct: "
              f"rho with")
        print(f"  realised vol {orth.get('rho_count_rv', float('nan')):+.2f} "
              f"and {orth.get('rho_move_rv', float('nan')):+.2f}, and "
              f"{orth.get('rho_count_move', float('nan')):+.2f} with each other.")
    if len(ics):
        pool = ics[ics["feature"] != "trailing_5"]
        best = pool.reindex(pool["t_stat"].abs().sort_values(
            ascending=False).index).iloc[0]
        base = ics[ics["feature"] == "trailing_5"]
        print(f"  Best DC feature: {best['feature']}, IC "
              f"{best['mean_ic']:+.4f} (t {best['t_stat']:+.2f}). It is "
              f"{float(best.get('rho_with_trailing', float('nan'))):+.2f} correlated")
        print(f"  with the trailing return, so it is NOT the reversal signal --")
        tv = float(best.get("t_vol_neutral", float("nan")))
        rv = float(best.get("rho_with_vol", float("nan")))
        print(f"  but it is {rv:+.2f} correlated with realised volatility, and")
        print(f"  neutralising within volatility quintiles leaves t = {tv:+.2f}.")
        print(f"  A different known effect, restated more weakly: realised vol")
        print(f"  itself scores a larger IC than the DC feature proxying it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
