"""
Have the model's INPUTS moved? (Leading indicator, ahead of coverage decay.)

Why this driver exists
----------------------
``run_drift_report.py`` monitors live interval coverage - the claim the product
makes, and the right headline. But it is a LAGGING indicator: at a 5-day horizon
it needs weeks of matured forecasts before it can say anything.

Feature drift is the leading indicator. If the inputs have moved away from what
a model was fitted on, its forecasts are extrapolations regardless of how its
last few intervals happened to land.

What it does
------------
Splits a ticker's history into a REFERENCE window (what a model fitted on this
data would have learned) and a CURRENT window (what it is being asked to score),
then tests every engineered feature for a distribution shift.

The verdict comes from a PERMUTATION test, not the conventional PSI bands.
Those bands (0.10 "moderate", 0.25 "significant") are folklore and PSI is biased
upward on small samples: two halves of the SAME distribution at n=50 score
PSI ~ 0.30, which the folklore would call significant drift. The permutation
null measures that noise floor directly at the actual sample size.

Usage:
    python run_feature_drift.py [--ticker T] [--current N] [--reference N]
        --ticker T     : NSE symbol (default RELIANCE.NS)
        --current N    : bars in the current window (default 250)
        --reference N  : bars in the reference window (default 750)
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import feature_drift as fd


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKER = _arg("--ticker", "RELIANCE.NS", str)
CURRENT = _arg("--current", 250)
REFERENCE = _arg("--reference", 750)


def _synthetic(n=1500, seed=0):
    rng = np.random.default_rng(seed)
    # Deliberately regime-shifted: the last quarter has triple the volatility,
    # so the driver has something real to find when run offline.
    vol = np.r_[np.full(n - 300, 0.010), np.full(300, 0.030)]
    px = 100 * np.exp(np.cumsum(rng.normal(0, 1, n) * vol))
    return pd.DataFrame({"datetime": pd.bdate_range("2019-01-02", periods=n),
                         "open": px, "high": px * 1.01, "low": px * 0.99,
                         "close": px, "adj_close": px,
                         "volume": rng.integers(1e5, 5e5, n)})


def _load():
    try:
        from get_data import get_whole_stock_data
        df = get_whole_stock_data(TICKER, "1d")
        if isinstance(df, pd.DataFrame) and len(df) > REFERENCE + CURRENT:
            print(f"  fetched {len(df)} rows for {TICKER}")
            return df.reset_index(drop=True)
    except Exception as exc:
        print(f"  fetch failed ({str(exc)[:60]}); using a synthetic "
              f"regime-shifted series")
    return _synthetic()


def main():
    print(f"=== Feature-distribution drift | {TICKER} | "
          f"reference {REFERENCE} bars vs current {CURRENT} bars ===\n")
    print("Loading data...")
    df = _load()

    print("Engineering features (the same ones the tree/ML models see)...")
    import ML_model
    feat = ML_model.create_features(df.copy(), "daily").dropna()
    drop = {"datetime", "date", "open", "high", "low", "close", "adj_close",
            "volume", "target", "y"}
    cols = [c for c in feat.select_dtypes(include=[np.number]).columns
            if c not in drop]
    print(f"  {len(feat):,} usable rows, {len(cols)} features\n")

    if len(feat) < REFERENCE + CURRENT:
        CUR = max(100, len(feat) // 4)
        REF = len(feat) - CUR
        print(f"  (history is short; using reference {REF} / current {CUR})")
    else:
        CUR, REF = CURRENT, REFERENCE

    current = feat.iloc[-CUR:]
    reference = feat.iloc[-(CUR + REF):-CUR]
    print(f"  reference: rows {len(reference):,}   current: rows {len(current):,}")

    table = fd.drift_table(reference, current, columns=cols, n_perm=300)
    summary = fd.summarise(table)

    print("\n" + "=" * 92)
    print(table.to_string(index=False))
    print("=" * 92)
    print("\n" + fd.format_report(table, summary))

    # --- the point of the permutation calibration, made explicit -------------
    testable = table[table["verdict"] != "INSUFFICIENT DATA"]
    if not testable.empty:
        folklore = int((testable["conventional"] != "stable").sum())
        actual = int((testable["verdict"] == "DRIFT").sum())
        print("\n-- Why the folklore thresholds are not used for the verdict --")
        print(f"  Conventional PSI bands would flag : {folklore} features")
        print(f"  Permutation test actually flags   : {actual} features")
        if folklore > actual:
            print("  -> the difference is the small-sample noise floor. Acting "
                  "on the folklore bands here would raise alarms that the data "
                  "cannot support, which is how monitoring gets switched off.")

    print("\nNote: this is a LEADING indicator. Coverage drift "
          "(run_drift_report.py) is the lagging one and remains the headline; "
          "the two answer different questions and neither replaces the other.")
    print("\nDone.")


if __name__ == "__main__":
    main()
