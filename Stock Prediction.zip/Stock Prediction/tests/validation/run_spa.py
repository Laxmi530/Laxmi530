"""
Run the data-snooping-robust model-selection test (White RC + Hansen SPA).

The rigorous capstone to the pairwise Diebold-Mariano work: instead of asking
"does model X beat the random walk?", it asks the honest multiple-comparison
question — "after trying K models, is there evidence that ANY of them beats the
random walk?" — using White's Reality Check and Hansen's SPA over a stationary
bootstrap of the aligned loss differentials.

Usage:
    python run_spa.py [TICKER] [--full] [--abs]
        TICKER : default RELIANCE.NS
        --full : include the slow neural nets (default: fast subset)
        --abs  : absolute-error loss instead of squared
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import sys
import warnings

import pandas as pd
import yfinance as yf

import multiple_testing as mt

warnings.filterwarnings("ignore")

_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
_flags = {a for a in sys.argv[1:] if a.startswith("--")}
TICKER = _pos[0] if _pos else "RELIANCE.NS"
INTERVAL = "1d"
HORIZON = 5
# Origin-level panel: each split is one ~independent forecast event, so we want
# many of them for a meaningful bootstrap (T = number of origins).
N_SPLITS = 40
MIN_TRAIN = 300
MAX_ROWS = 700
LOSS = "absolute" if "--abs" in _flags else "squared"


def fetch(ticker):
    h = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    cols = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    return h[cols].dropna().reset_index(drop=True).tail(MAX_ROWS).reset_index(drop=True)


def build_models():
    """(name, fn, kwargs) — fast subset by default; --full adds neural nets."""
    from ML_model import run_ML_prediction
    from Quantile_model import run_quantile_prediction
    from Ensemble_model import run_ensemble_prediction
    from ARIMA_GARCH import run_statistical_prediction
    from ARIMAX_model import run_arimax_prediction
    from RegimeSwitching_model import run_regime_prediction
    from HAR_RV_model import run_har_rv_prediction
    from meta_ensemble import run_meta_ensemble_prediction

    models = [
        ("XGBoost", run_ML_prediction, {"model_type": "xgboost"}),
        ("LightGBM", run_ML_prediction, {"model_type": "lightgbm"}),
        ("Quantile-LGBM", run_quantile_prediction, {}),
        ("Ensemble-Stack", run_ensemble_prediction, {}),
        ("Meta-Ensemble", run_meta_ensemble_prediction, {}),
        ("ARIMA+GARCH", run_statistical_prediction, {}),
        ("ARIMAX+GARCH", run_arimax_prediction, {}),
        ("RegimeSwitching", run_regime_prediction, {}),
        ("HAR-RV", run_har_rv_prediction, {}),
    ]
    if "--full" in _flags:
        from DL_model import run_DL_prediction
        from NBeats_model import run_nbeats_prediction
        from Transformer_model import run_transformer_prediction
        from TCN_model import run_tcn_prediction
        models += [
            ("LSTM", run_DL_prediction, {"model_type": "LSTM"}),
            ("GRU", run_DL_prediction, {"model_type": "GRU"}),
            ("N-BEATS", run_nbeats_prediction, {}),
            ("Transformer", run_transformer_prediction, {}),
            ("TCN", run_tcn_prediction, {}),
        ]
    return models


def main():
    print(f"=== SPA / Reality Check | {TICKER} | horizon={HORIZON} | "
          f"loss={LOSS} | benchmark=random walk ===")
    df = fetch(TICKER)
    print(f"Fetched {len(df)} rows: {df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}")

    models = build_models()
    print(f"Testing {len(models)} models on shared walk-forward origins...")
    d, names = mt.collect_loss_panel(
        df, models, INTERVAL, HORIZON, n_splits=N_SPLITS,
        min_train=MIN_TRAIN, loss=LOSS)
    if d.size == 0 or len(names) < 2:
        print("Insufficient aligned data to run the test.")
        return
    print(f"\nAligned loss panel: T={d.shape[0]} time points x K={d.shape[1]} "
          "models (vs naive random walk).")

    res = mt.summarize(d, names, n_boot=2000, seed=0)
    print("\n-- Per-model mean loss-differential vs random walk "
          "(positive = beats RW) --")
    print(res['ranking'].to_string(index=False,
                                   float_format=lambda v: f"{v:+.5f}"))
    print(f"\nWhite's Reality Check:  stat={res['rc']['stat']:.4f}  "
          f"p={res['rc']['p_value']:.4f}")
    print(f"Hansen's SPA (consistent): stat={res['spa']['stat']:.4f}  "
          f"p={res['spa']['p_value']:.4f}")
    print(f"\nVERDICT: {res['verdict']}")
    print("\n(Positive mean loss-diff for a model means lower error than the "
          "random walk on these origins; the SPA p-value says whether that is "
          "more than K-models-worth of luck.)")


if __name__ == "__main__":
    main()
