"""
Can point-in-time fundamentals be added to the cross-sectional panel? (Audit.)

Why this driver exists
----------------------
Every model in this project transforms the same OHLCV series, and six negative
results point at the *information*, not the architecture, as the binding
constraint. Fundamentals are the cheapest second axis available - no licensed
feed required - so the obvious next experiment is to add them to the pooled
panel and re-run the cross-sectional classifier at a horizon where valuation
signals plausibly act (a year, not five days).

This driver answers the question that has to come first: **is there enough
point-in-time fundamental history to run that experiment at all?** Building the
panel first and discovering the answer afterwards would mean reporting a null
that is really a data-coverage artefact - the same confusion between "no signal"
and "no power" that Section 30 had to disentangle for the abstention result.

What it measures
----------------
For each ticker: how many reporting periods ``yfinance`` returns, when the
earliest becomes *knowable* (period end + publication lag, never period end
itself), and what fraction of the panel's window that covers.

The number that decides it is ``covered_fraction`` - and, more importantly, the
implied number of independent label dates. Section 30 established that the
Fama-MacBeth t-statistic counts DATES, not rows: 574 validation dates produced
t = 0.45. A fundamentals panel with four annual observations per ticker has
n_dates = 4, which cannot detect any effect of any size.

Usage:
    python run_fundamentals_audit.py [--n N] [--annual]
        --n N     : how many tickers to audit (default 12; full universe is 40)
        --annual  : audit annual statements instead of quarterly
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import pandas as pd

import cross_sectional_panel as csp
import fundamentals as fu

warnings.filterwarnings("ignore")

PANEL_START = "2018-08-27"      # matches the panel run_cross_sectional_clf.py builds
PANEL_END = "2026-08-25"


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


N = _arg("--n", 12)
QUARTERLY = "--annual" not in sys.argv


def main():
    universe = csp.DEFAULT_UNIVERSE[:N]
    kind = "quarterly" if QUARTERLY else "annual"
    print(f"=== Point-in-time fundamentals audit | {len(universe)} NSE names | "
          f"{kind} statements ===\n")
    print(f"Target panel window: {PANEL_START} -> {PANEL_END}")
    print(f"Publication lag applied: "
          f"{fu.PUBLICATION_LAG_DAYS if QUARTERLY else fu.ANNUAL_PUBLICATION_LAG_DAYS}"
          f" days after period end\n")

    df, summary = fu.coverage_report(universe, PANEL_START, PANEL_END,
                                     quarterly=QUARTERLY, verbose=True)

    print("\n" + "=" * 78)
    print(df.to_string(index=False))
    print("=" * 78)

    print("\n-- Summary --")
    for k, v in summary.items():
        print(f"  {k:24} {v}")

    # --- The verdict, in the terms that actually decide feasibility ----------
    panel_years = summary.get("panel_years", 8.0)
    covered = summary.get("covered_fraction", 0.0)
    med_periods = summary.get("median_periods", 0.0)

    print("\n-- Feasibility --")
    print(f"  Fundamentals cover {covered:.0%} of the {panel_years:.1f}-year panel.")
    print(f"  Median reporting periods per ticker: {med_periods:.0f}")

    # With a 1-year label horizon, the number of INDEPENDENT label dates is what
    # the Fama-MacBeth t-statistic counts (Section 30). Non-overlapping annual
    # labels over the covered window is the honest upper bound.
    n_dates = max(int(summary.get("covered_years", 0.0)), 0)
    print(f"  Independent 1-year label dates available: ~{n_dates}")
    print(f"  For comparison, Section 30's null result had n_dates = 574 "
          f"and still only reached t = 0.45.")

    if med_periods < 8 or n_dates < 10:
        print("\nCONCLUSION: NOT FEASIBLE on this data source.")
        print("  yfinance returns only a handful of recent reporting periods, "
              "not a decade of history. Any cross-sectional fundamental result "
              "built on it would be a coverage artefact, not a finding - the "
              "sample cannot distinguish 'no signal' from 'no power'.")
        print("  What would change the answer: a point-in-time fundamentals "
              "vendor with restated-data history (Compustat / CapitalIQ / "
              "Refinitiv), or an archive of filings built up going forward from "
              "today. The latter costs nothing but time, and prediction_log.py "
              "already demonstrates the pattern: record now, evaluate later.")
    else:
        print("\nCONCLUSION: feasible - proceed to build the fundamental panel.")
        print("  Re-run the cross-sectional classifier with these features at a "
              "1-year horizon, and confirm on --mode asset and --mode time "
              "before believing any positive result.")

    print("\nNote: this audit deliberately uses statement data with a "
          "publication lag, NOT Ticker.info. info holds today's values, so "
          "joining it to a historical panel is look-ahead - fundamentals."
          "as_of_join refuses such a frame outright.")
    print("\nDone.")


if __name__ == "__main__":
    main()
