"""
Is the Kalman filter's NATIVE interval as trustworthy as a conformal one?

The question
------------
Klaas Ch. 4 sells state-space models partly on this: *"Most classic
probabilistic modeling techniques, such as Kalman filters, can give confidence
intervals for predictions, whereas regular deep learning cannot do this."* The
interval falls out of the state covariance - no calibration set, no held-out
residuals, nothing to tune.

That is elegant, and it is also a **Gaussian** claim. This project has measured
repeatedly that equity residuals are fat-tailed, so the elegance may cost
coverage. Every other interval here is conformal: distribution-free, calibrated
on held-out residuals, and agnostic about the model.

Two arms, on identical walk-forward origins:

* **native**    - the Kalman 95% band, ``mean +/- 1.96 * sqrt(state variance)``
* **conformal** - the same point forecast, with the half-width taken from the
  95th percentile of held-out one-step residuals, widened as ``sqrt(h)``

What to read, in order
----------------------
1. **Coverage.** Should be ~0.95. Anything below ~0.90 is a cone that lies.
2. **Mean width.** A cone can always reach 95% by being uselessly wide, so
   coverage is only meaningful next to width. Narrower at equal coverage wins.
3. **RMSE vs the random walk.** The point forecast, held to this project's only
   honest yardstick. A local-level Kalman fit IS an adaptive random walk, so
   parity here is the expected result - not a disappointment.

Usage:
    python run_kalman_eval.py [--ticker T] [--horizon H] [--origins N]
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import kalman_model as km


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKER = _arg("--ticker", "RELIANCE.NS", str)
HORIZON = _arg("--horizon", 5)
ORIGINS = _arg("--origins", 40)
MIN_TRAIN = 400


def _synthetic(n=1200, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2020-01-02", periods=n)
    # Student-t innovations: fat tails, which is the whole point of the test.
    z = rng.standard_t(df=4, size=n) / np.sqrt(4 / 2.0)
    px = 100 * np.exp(np.cumsum(0.012 * z))
    return pd.DataFrame({"datetime": dates, "open": px, "high": px * 1.01,
                         "low": px * 0.99, "close": px, "adj_close": px,
                         "volume": rng.integers(1e5, 5e5, n)})


def _load():
    try:
        from get_data import get_whole_stock_data
        df = get_whole_stock_data(TICKER, "1d")
        if isinstance(df, pd.DataFrame) and len(df) > MIN_TRAIN + 100:
            print(f"  fetched {len(df)} rows for {TICKER}")
            return df.reset_index(drop=True)
    except Exception as exc:
        print(f"  fetch failed ({str(exc)[:60]}); using synthetic fat-tailed series")
    return _synthetic()


def main():
    print(f"=== Kalman: native vs conformal intervals | horizon={HORIZON}d | "
          f"{ORIGINS} origins ===\n")
    print("Loading data...")
    df = _load()

    price_col = next((c for c in ("adj_close", "close") if c in df.columns), None)
    prices = pd.to_numeric(df[price_col], errors="coerce").values
    n = len(prices)

    usable = n - MIN_TRAIN - HORIZON
    if usable < 10:
        print("Not enough history for a walk-forward evaluation.")
        return
    step = max(1, usable // ORIGINS)
    origins = list(range(MIN_TRAIN, n - HORIZON, step))[:ORIGINS]
    print(f"  {len(origins)} non-overlapping-ish origins, "
          f"min train {MIN_TRAIN} bars\n")

    rec = []
    for i, o in enumerate(origins, 1):
        hist = df.iloc[:o].copy()
        actual = prices[o:o + HORIZON]
        if len(actual) < HORIZON or not np.all(np.isfinite(actual)):
            continue
        try:
            out = km.run_kalman_prediction(hist, "1d", HORIZON,
                                           use_conformal=True)
        except Exception:
            continue
        k = out.attrs["kalman"]
        centre = out["predicted_price"].values
        native_hw = np.array(k["native_halfwidth"])     # log units
        conf_hw = np.array(k["used_halfwidth"])         # log units
        naive = float(prices[o - 1])

        for h in range(HORIZON):
            log_a = np.log(actual[h])
            log_c = np.log(centre[h])
            rec.append({
                "origin": o, "h": h + 1,
                "err": centre[h] - actual[h],
                "naive_err": naive - actual[h],
                "cov_native": abs(log_a - log_c) <= native_hw[h],
                "cov_conformal": abs(log_a - log_c) <= conf_hw[h],
                "w_native": float(np.exp(log_c + native_hw[h])
                                  - np.exp(log_c - native_hw[h])),
                "w_conformal": float(np.exp(log_c + conf_hw[h])
                                     - np.exp(log_c - conf_hw[h])),
                "degenerate": k["degenerate_to_random_walk"],
                "phi": k["phi"],
            })
        if i % 10 == 0:
            print(f"  ...{i}/{len(origins)} origins")

    if not rec:
        print("No usable origins.")
        return
    r = pd.DataFrame(rec)

    print("\n" + "=" * 78)
    print("-- Interval calibration (target coverage 0.95) --")
    tab = r.groupby("h").agg(
        cov_native=("cov_native", "mean"),
        cov_conformal=("cov_conformal", "mean"),
        w_native=("w_native", "mean"),
        w_conformal=("w_conformal", "mean"),
    ).round(4)
    print(tab.to_string())

    cn, cc = r["cov_native"].mean(), r["cov_conformal"].mean()
    wn, wc = r["w_native"].mean(), r["w_conformal"].mean()
    print(f"\n  overall native   : coverage {cn:.3f} | mean width {wn:.2f}")
    print(f"  overall conformal: coverage {cc:.3f} | mean width {wc:.2f}")

    print("\n-- Point forecast vs the random walk --")
    rmse = float(np.sqrt(np.mean(r["err"] ** 2)))
    rmse_naive = float(np.sqrt(np.mean(r["naive_err"] ** 2)))
    print(f"  Kalman RMSE      : {rmse:.4f}")
    print(f"  random-walk RMSE : {rmse_naive:.4f}")
    print(f"  improvement      : {100*(rmse_naive-rmse)/rmse_naive:+.2f}%")

    print("\n-- Fitted structure --")
    deg = float(r.groupby("origin")["degenerate"].first().mean())
    print(f"  origins where the fit degenerated to a random walk: {deg:.0%}")
    print(f"  mean fitted phi (trend damping): "
          f"{r.groupby('origin')['phi'].first().mean():.2f}")

    print("\n-- Verdict --")
    if abs(cn - 0.95) <= 0.03 and wn <= wc * 1.05:
        print("  The NATIVE Gaussian interval is competitive: coverage near "
              "nominal at no width penalty. The book's claim holds on this "
              "data, and the conformal step buys little here.")
    elif cn < 0.90:
        print("  The NATIVE interval UNDER-COVERS. Its Gaussian assumption does "
              "not survive fat-tailed equity residuals, which is exactly why "
              "every other interval in this project is conformal. Keep "
              "use_conformal=True (the shipped default).")
    else:
        print("  Mixed: neither band dominates. Report both rather than "
              "claiming one is better - the shipped default stays conformal, "
              "since it makes the weaker assumption.")

    if abs(rmse - rmse_naive) / max(rmse_naive, 1e-12) < 0.02:
        print("  Point forecast is within 2% of the random walk, which is the "
              "EXPECTED result: a local-level fit IS an adaptive random walk. "
              "The model's value here is the interval and the fitted structure, "
              "not the point.")
    print("\nDone.")


if __name__ == "__main__":
    main()
