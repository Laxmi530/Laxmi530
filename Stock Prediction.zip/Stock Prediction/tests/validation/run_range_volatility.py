"""
A/B: does a range-based variance proxy improve the HAR-RV uncertainty cone?

The claim under test
--------------------
``HAR_RV_model`` estimates realized variance as ``r_t**2`` and its docstring
calls that "the standard proxy when sub-bar data is unavailable". Sub-bar data
is *not* unavailable -- every bar carries open, high and low, and Ch. 18 of
Sharma & Mehta converts prices to volatility with
``0.361*[ln(High) - ln(Low)]**2``, the Parkinson estimator.

A more precise variance estimate should produce a **tighter cone at the same
coverage**. That is the hypothesis, and it is the right one for this project:
the README states the product is calibrated uncertainty, not directional
accuracy, so an improvement to the interval is an improvement to the deliverable
in a way that a better point forecast would not be.

Why coverage alone is not the test
----------------------------------
A conformal layer sits downstream of the variance forecast and rescales the cone
to hit its target. That layer will absorb a *constant* bias in the variance
estimate -- an inflated sigma is cancelled by a deflated multiplier -- so
coverage can look identical whether the underlying estimate is good or bad. What
it cannot absorb is a **precision** gain: a less noisy variance series should
track the true time-varying risk better, and show up as a narrower interval for
the same hit rate.

So the metric is the pair **(coverage, width)**, and an estimator only wins if
coverage stays on target *and* width falls. A narrower cone at degraded coverage
is a worse product, not a better one.

Honest expectation
------------------
Measured efficiency on real NSE bars is **1.6-2.5x**, not the textbook ~5x --
real bars are discrete, gap overnight and trend. A 2x more precise input to a
regression whose output is then conformally rescaled may well produce no
measurable width gain at all. This project has recorded eleven negative results
by asking questions this way rather than assuming the answer.

Run::

    python tests/validation/run_range_volatility.py
    python tests/validation/run_range_volatility.py --tickers RELIANCE,TCS --splits 8
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                 # noqa: E402
import range_volatility as rvm        # noqa: E402
import calibration as cal             # noqa: E402
from HAR_RV_model import run_har_rv_prediction   # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKERS = _arg("--tickers", "RELIANCE,TCS,INFY,HDFCBANK,SBIN,TATASTEEL").split(",")
START = _arg("--start", "2019-01-01")
END = _arg("--end", "2024-06-30")
HORIZON = int(_arg("--horizon", "5"))
SPLITS = int(_arg("--splits", "8"))
ESTIMATORS = _arg("--estimators", "squared,parkinson,garman_klass,"
                                  "rogers_satchell").split(",")


def main():
    print("=" * 78)
    print("RANGE-BASED VARIANCE vs SQUARED RETURNS  --  does the cone improve?")
    print("=" * 78)
    print(f"{len(TICKERS)} names | {START} .. {END} | horizon {HORIZON} | "
          f"{SPLITS} walk-forward origins")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nloading corporate actions and panel ...")
    acts = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400),
                                END, chunk_months=360)
    panel = bc.adjust_prices(
        bc.load_cache(START, END, symbols=TICKERS), acts)

    # ---------------------------------------------------- estimator precision
    print("\n" + "=" * 78)
    print("1. MEASURED PRECISION  (theory says ~5x for Parkinson under GBM)")
    print("=" * 78)
    print(f"{'ticker':12s}" + "".join(f"{e[:11]:>13s}" for e in ESTIMATORS[1:])
          + f"{'level ratio':>13s}")
    for t in TICKERS:
        g = panel[panel["symbol"] == t].sort_values("datetime").reset_index(drop=True)
        if len(g) < 300:
            continue
        effs = []
        for e in ESTIMATORS[1:]:
            try:
                effs.append(rvm.efficiency(g, e)["efficiency"])
            except ValueError:
                effs.append(np.nan)
        _, info = rvm.scale_to_total(rvm.estimate(g, "parkinson"),
                                     g["adj_close"].values)
        flag = " !" if info["implausible"] else ""
        print(f"{t[:11]:12s}" + "".join(f"{x:12.2f}x" for x in effs)
              + f"{info['level_ratio']:13.3f}{flag}")
    print("\n  level ratio = share of close-to-close variance the intraday range")
    print("  captures. Below 1 because it excludes the overnight gap; the")
    print("  remainder is restored by scale_to_total before the regression.")

    # -------------------------------------------------------------- the A/B
    print("\n" + "=" * 78)
    print("2. CONE QUALITY  (the deliverable)")
    print("=" * 78)
    rows = []
    for t in TICKERS:
        g = panel[panel["symbol"] == t].sort_values("datetime").reset_index(drop=True)
        if len(g) < 400:
            print(f"  {t}: too short, skipped")
            continue
        df = g[["datetime", "open", "high", "low", "close", "adj_close"]].copy()
        for est in ESTIMATORS:
            try:
                # collect_step_records returns (records, empirical) -- unpack
                # it. Passing the tuple straight on raises deep inside
                # coverage_quality, which is how this was caught.
                rec, _emp = cal.collect_step_records(
                    df, run_har_rv_prediction, "1d", HORIZON,
                    n_splits=SPLITS, predict_kwargs={"rv_estimator": est},
                    model_name=f"HAR-{est}", verbose=False)
                q = cal.coverage_quality(rec)
            except Exception as exc:
                print(f"  {t}/{est}: FAILED {type(exc).__name__}: {str(exc)[:60]}")
                continue
            if q is None or not len(q):
                continue
            rows.append({
                "ticker": t, "estimator": est,
                "coverage": float(q["coverage"].mean()),
                "width": float(q["mean_width_%"].mean()),
                "miscoverage": abs(float(q["coverage"].mean()) - 0.95),
                "n": int(q["n"].sum()),
            })
        if rows:
            sub = [r for r in rows if r["ticker"] == t]
            base = next((r for r in sub if r["estimator"] == "squared"), None)
            print(f"\n  {t}")
            print(f"    {'estimator':18s}{'coverage':>10s}{'width %':>10s}"
                  f"{'vs squared':>12s}")
            for r in sub:
                d = ("  --" if base is None or r["estimator"] == "squared"
                     else f"{100 * (r['width'] / base['width'] - 1):+11.1f}%")
                print(f"    {r['estimator'][:17]:18s}{r['coverage']:10.3f}"
                      f"{r['width']:10.2f}{d:>12s}")

    if not rows:
        print("\nno results")
        return 1
    tab = pd.DataFrame(rows)

    # ------------------------------------------------------------- aggregate
    print("\n" + "=" * 78)
    print("3. AGGREGATE ACROSS NAMES")
    print("=" * 78)
    agg = tab.groupby("estimator").agg(
        coverage=("coverage", "mean"), width=("width", "mean"),
        miscoverage=("miscoverage", "mean"), names=("ticker", "nunique"))
    base = agg.loc["squared"] if "squared" in agg.index else None
    print(f"{'estimator':18s}{'coverage':>10s}{'|cov-0.95|':>12s}"
          f"{'width %':>10s}{'width vs sq':>13s}")
    for est, r in agg.iterrows():
        d = ("  --" if base is None or est == "squared"
             else f"{100 * (r['width'] / base['width'] - 1):+12.1f}%")
        print(f"{est[:17]:18s}{r['coverage']:10.3f}{r['miscoverage']:12.3f}"
              f"{r['width']:10.2f}{d:>13s}")

    # --------------------------------------------------------------- verdict
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    if base is None:
        print("  no baseline arm")
        return 1
    # A PAIRED test, not a comparison of aggregates. Each ticker supplies its
    # own width ratio, so the between-name variation (which is large -- the
    # per-ticker spread here runs from -8% to +10%) is differenced out instead
    # of being averaged into a mean that looks decisive and is not.
    #
    # This replaced a naive rule that declared a winner whenever the aggregate
    # width fell at all. On this data that rule announced rogers_satchell at
    # -1.4%, from a paired t of -0.65 -- an over-claim on noise, and precisely
    # what the rest of this project exists to avoid.
    w = tab.pivot(index="ticker", columns="estimator", values="width")
    print(f"{'estimator':18s}{'mean width d':>14s}{'sd':>8s}{'paired t':>10s}"
          f"{'wins':>8s}")
    verdicts = {}
    for est in agg.index:
        if est == "squared" or "squared" not in w.columns:
            continue
        lr = np.log(w[est] / w["squared"]).dropna()
        if len(lr) < 3:
            continue
        m, sd = float(lr.mean()), float(lr.std(ddof=1))
        tstat = m / (sd / np.sqrt(len(lr))) if sd > 0 else np.nan
        verdicts[est] = (m, tstat)
        print(f"{est[:17]:18s}{100 * m:13.2f}%{100 * sd:7.2f}%{tstat:10.2f}"
              f"{int((lr < 0).sum()):5d}/{len(lr)}")

    sig = {e: v for e, (m, v) in verdicts.items() if np.isfinite(v) and v < -2.0}
    print()
    if sig:
        best = min(sig, key=sig.get)
        print(f"  {best} gives a significantly tighter cone "
              f"(paired t = {sig[best]:.2f}).")
        print("  Confirm on a wider universe before changing the default.")
    else:
        print("  NO estimator changes the cone significantly. Every paired t is")
        print("  inside +/-2 and the win rates are coin flips, so the width")
        print("  differences are noise, not effects.")
        print()
        print("  The likely mechanism: scale_to_total restores the missing")
        print("  overnight variance with a CONSTANT factor, but the")
        print("  intraday/overnight split moves with the news cycle. The range")
        print("  estimators therefore trade sampling noise for a time-varying")
        print("  bias -- better at measuring the last bar, no better at")
        print("  forecasting the next one, which is what the cone needs.")
        print()
        print("  The shipped default stays 'squared'. The estimators remain")
        print("  available, tested and documented.")

    print()
    print(f"  (Coverage is ~{agg['coverage'].mean():.3f} for EVERY arm against a")
    print("   0.95 target, baseline included -- a property of this walk-forward")
    print("   configuration, not of the estimator choice.)")

    out = os.path.join(_HERE, "range_volatility_ab.csv")
    tab.to_csv(out, index=False)
    print(f"\nsaved: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
