"""
Which inputs drive the tree models? (Exact TreeSHAP.)

Why this driver exists
----------------------
Klaas Ch. 8 asks "why did your model make the prediction it made?" - a question
this project could not answer for any of its twenty models. It uses LIME; for
tree ensembles TreeSHAP is strictly better (exact rather than a local surrogate)
and both LightGBM and XGBoost implement it natively, so no new dependency.

But the reason to run it here is sharper than interpretability for its own sake.
This project's central finding is that most apparent edge is noise. Attribution
gives an independent way to check that from the inside:

* **Concentrated** attribution on a few economically sensible features would be
  a structured claim - and would deserve a closer look, since it is not what a
  noise-fitting model looks like.
* **Diffuse** attribution spread thinly across dozens of features is what
  fitting noise looks like: no feature carries the prediction because there is
  nothing for one to carry.

The Herfindahl index makes that concrete. A value near ``1/n`` means attribution
is spread as evenly as possible; near 1 means one feature explains everything.

Two models are examined: the single-ticker gradient-boosted regressor (the
family behind XGBoost/LightGBM in the app) and the pooled cross-sectional
classifier from Section 29.

Usage:
    python run_explain.py [--ticker T] [--horizon H] [--n N]
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import explain as ex


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKER = _arg("--ticker", "RELIANCE.NS", str)
HORIZON = _arg("--horizon", 5)
N_TICKERS = _arg("--n", 12)


def _synthetic(n=1200, seed=0):
    rng = np.random.default_rng(seed)
    px = 100 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    return pd.DataFrame({"datetime": pd.bdate_range("2020-01-02", periods=n),
                         "open": px, "high": px * 1.01, "low": px * 0.99,
                         "close": px, "adj_close": px,
                         "volume": rng.integers(1e5, 5e5, n)})


def single_ticker():
    print("=" * 78)
    print("1. Single-ticker gradient-boosted regressor")
    print("=" * 78)
    try:
        from get_data import get_whole_stock_data
        df = get_whole_stock_data(TICKER, "1d")
        if not isinstance(df, pd.DataFrame) or len(df) < 500:
            raise ValueError("short history")
        print(f"  {TICKER}: {len(df)} rows")
    except Exception as exc:
        print(f"  fetch failed ({str(exc)[:50]}); synthetic series")
        df = _synthetic()

    import ML_model
    import lightgbm as lgb

    feat = ML_model.create_features(df.copy(), "daily").dropna().reset_index(drop=True)
    drop = {"datetime", "date", "open", "high", "low", "close", "adj_close",
            "volume", "target", "target_log_return", "y"}
    cols = [c for c in feat.select_dtypes(include=[np.number]).columns
            if c not in drop]

    # Direct h-step cumulative log return, the target the app's tree models use.
    px = pd.to_numeric(feat["adj_close"], errors="coerce").values
    y = np.log(np.roll(px, -HORIZON) / px)
    ok = np.isfinite(y)
    ok[-HORIZON:] = False
    X, y = feat.loc[ok, cols], y[ok]
    print(f"  {len(X):,} samples x {len(cols)} features, horizon {HORIZON}d")

    model = lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05,
                              num_leaves=31, min_child_samples=40,
                              verbose=-1, random_state=42).fit(X, y)

    imp = ex.importance(model, X)
    conc = ex.concentration(imp)
    print()
    print(ex.format_report(imp, conc, "Single-ticker regressor"))

    e = ex.explain_prediction(model, X, row=-1)
    print(f"\n  Additivity check on the latest row: base {e['base_value']:+.6f} "
          f"+ sum(SHAP) = {e['reconstruction']:+.6f} vs prediction "
          f"{e['prediction']:+.6f}  (error {e['additivity_error']:.1e}, "
          f"ok={e['additivity_ok']})")
    return conc


def cross_sectional():
    print("\n" + "=" * 78)
    print("2. Pooled cross-sectional classifier (Section 29)")
    print("=" * 78)
    try:
        import cross_sectional_panel as csp
        import cross_sectional_model as csm
        universe = csp.DEFAULT_UNIVERSE[:N_TICKERS]
        panel, rep = csp.build_panel(universe, verbose=False)
        if panel.empty:
            print("  no panel data; skipped")
            return None
        feat = csp.add_cross_sectional_ranks(csp.add_ticker_features(panel))
        lab = csp.add_labels(feat, horizon=HORIZON)
        cols = csp.feature_columns(lab)
        split = csp.split_panel(lab, mode="combined", seed=42, embargo=HORIZON)
        print(f"  {rep['n_rows']:,} rows x {rep['n_tickers']} tickers, "
              f"{len(cols)} features")
        bundle = csm.fit_calibrated(split["train"], cols, seed=42, verbose=False)
        X = split["train"][cols]
    except Exception as exc:
        print(f"  skipped ({str(exc)[:80]})")
        return None

    imp = ex.importance(bundle["model"], X)
    conc = ex.concentration(imp)
    print()
    print(ex.format_report(imp, conc, "Cross-sectional 3-class classifier"))
    return conc


def main():
    print("=== Feature attribution, exact TreeSHAP (no shap/lime dependency) ===\n")
    c1 = single_ticker()
    c2 = cross_sectional()

    print("\n" + "=" * 78)
    print("What the concentration says")
    print("=" * 78)
    for name, c in (("single-ticker regressor", c1),
                    ("cross-sectional classifier", c2)):
        if not c:
            continue
        ratio = c["herfindahl"] / c["uniform_herfindahl"]
        print(f"\n  {name}:")
        print(f"    top feature carries {c['top_share']:.1%}; "
              f"{c['n_for_50pct']} features cover 50%, "
              f"{c['n_for_90pct']} cover 90%")
        print(f"    Herfindahl {c['herfindahl']} vs uniform "
              f"{c['uniform_herfindahl']} ({ratio:.1f}x)")
        if ratio < 2.0:
            print("    -> attribution is close to UNIFORM. No feature carries "
                  "the prediction, which is what fitting noise looks like and "
                  "is consistent with every skill result in this project.")
        elif ratio < 5.0:
            print("    -> mildly concentrated. Some structure, but not the "
                  "signature of a strong driver.")
        else:
            print("    -> CONCENTRATED. A few features carry the prediction. "
                  "Worth checking they are economically sensible and not a "
                  "leak; a concentrated attribution on a near-random target is "
                  "more often a bug than an edge.")

    print("\nNote: attribution explains what the model DID, not whether it was "
          "right. A confidently-attributed forecast from a model with no "
          "measured edge is still a forecast with no measured edge.")
    print("\nDone.")


if __name__ == "__main__":
    main()
