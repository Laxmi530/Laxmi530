"""
Cross-sectional signal probe across a universe of NSE stocks.

Fetches daily prices for a basket of liquid Indian names, builds a panel, and
reports rank-IC and long-short quintile spreads for several classic, model-free
signals at 5- and 21-day horizons. This answers the go/no-go question for a
ranking product: does *any* simple cross-sectional signal show stable skill on
this universe?

Usage:
    python run_cross_sectional.py
    python run_cross_sectional.py "RELIANCE.NS,TCS.NS,INFY.NS,..."
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import sys
import warnings

import pandas as pd
import yfinance as yf

import cross_sectional as cs

warnings.filterwarnings("ignore")

# ~20 liquid NSE large caps (a rough NIFTY subset) as the default universe.
DEFAULT_UNIVERSE = [
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "SBIN.NS", "BHARTIARTL.NS", "ITC.NS", "LT.NS", "KOTAKBANK.NS",
    "HINDUNILVR.NS", "BAJFINANCE.NS", "AXISBANK.NS", "ASIANPAINT.NS",
    "MARUTI.NS", "SUNPHARMA.NS", "TITAN.NS", "WIPRO.NS", "ULTRACEMCO.NS",
    "NESTLEIND.NS",
]

SIGNALS = ["mom_252_21", "mom_21", "rev_5", "vol_21"]
HORIZONS = (5, 21)


def fetch(ticker):
    """Daily adjusted close for one ticker, mapped to the project schema."""
    h = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
    if h is None or h.empty:
        return None
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    return h[["datetime", "adj_close"]].dropna().reset_index(drop=True)


def main():
    universe = (sys.argv[1].split(",")
                if len(sys.argv) > 1 else DEFAULT_UNIVERSE)
    print(f"=== Cross-sectional signal probe | {len(universe)} names ===")

    prices = {}
    for tk in universe:
        try:
            d = fetch(tk)
            if d is not None and len(d) > 260:
                prices[tk] = d
        except Exception as exc:
            print(f"  skip {tk}: {exc}")
    print(f"Fetched {len(prices)} usable tickers.")

    panel = cs.add_signals(cs.build_panel(prices, horizons=HORIZONS))
    span = (panel['datetime'].min().date(), panel['datetime'].max().date())
    print(f"Panel: {len(panel)} rows, {span[0]} -> {span[1]}\n")

    # Note: vol_21 is tested with a negative sign (low-vol factor) by flipping.
    panel["neg_vol_21"] = -panel["vol_21"]
    signals = ["mom_252_21", "mom_21", "rev_5", "neg_vol_21"]

    for h in HORIZONS:
        print(f"----- horizon = {h} bars "
              f"(non-overlapping stride {h}) -----")
        print(f"{'signal':12} {'rankIC':>8} {'IC t':>7} {'IC hit%':>8}"
              f" {'LS spread':>10} {'LS t':>7} {'LS hit%':>8} {'dates':>6}")
        for sig in signals:
            ic = cs.rank_ic(panel, sig, h)
            ls = cs.long_short_spread(panel, sig, h)
            print(f"{sig:12} {ic['ic_mean']:+8.4f} {ic['t_stat']:+7.2f} "
                  f"{ic['hit_rate']*100:7.1f}% {ls['spread_mean']:+10.4f} "
                  f"{ls['t_stat']:+7.2f} {ls['hit_rate']*100:7.1f}% "
                  f"{ic['n_dates']:6d}")
        print()

    print("Interpretation: a usable factor shows a consistently signed rank-IC "
          "with |t| > ~2 and an IC hit-rate clearly above 50%. The long-short "
          "spread is the idealised (costless) top-minus-bottom return.")


if __name__ == "__main__":
    main()
