"""
VaR method comparison and VaR backtesting on real data.

Book Ch. 9 ("Risk Measurement Using GAN") in driver form: estimate Value-at-Risk
five different ways, then run each one through the statistical tests that decide
whether it was actually right — Kupiec's proportion-of-failures test
(unconditional coverage) and Christoffersen's independence test (are the breaches
clustered?), plus their joint conditional-coverage test.

Why this driver exists
----------------------
The app already *reports* a 5% VaR and expected shortfall off HAR-RV's conformal
residuals, but nothing in the project ever **validated a VaR number**. Interval
coverage checks the two-sided 95% cone; that is a different question from "does
the left tail break exactly 5% of the time, and are the breaks independent?" A
VaR model can have textbook-perfect unconditional coverage and still be useless
because every breach arrives in the same week — which is the failure mode that
actually destroys a position.

What to look for
----------------
The classical methods' textbook drawbacks should show up as numbers:

* **variance-covariance** (Gaussian) — expected to *under*-reserve on equity
  data, because returns are leptokurtic. Kupiec should reject with
  ``verdict='understates risk'``.
* **historical simulation** — roughly the right *rate*, but unconditional, so its
  breaches should **cluster** in volatile stretches and Christoffersen's
  independence test should reject.
* **cornish-fisher** — the one-line skew/kurtosis repair of the Gaussian, and a
  cautionary case rather than a recommendation. Its kurtosis term scales with
  ``z^3 - 3z``, which is *positive* for ``|z| < sqrt(3)`` — and the 5% quantile
  (``z = -1.645``) is inside that range, so on a very leptokurtic history CF
  *reduces* the 5% reserve and can double the exception rate. Re-run with
  ``--alpha 0.01`` to see it behave correctly deeper in the tail.
* **fhs** (Filtered Historical Simulation) — conditional *and* fat-tailed, so it
  should pass both tests without being gratuitously wide.
* **generative** — the block-bootstrap sampler standing in for the chapter's GAN
  (see ``var_models.generative_return_samples`` for why a GAN on ~1000 daily
  returns is a bad trade for a tail estimate).

``avg_var_loss`` is printed alongside every p-value on purpose: a model can pass
coverage by simply reserving an enormous amount, and the width is what that
safety cost.

Usage:
    python run_var_backtest.py [TICKER] [--alpha A] [--horizon H] [--window W]
        TICKER      : default RELIANCE.NS
        --alpha A   : VaR tail probability (default 0.05; try 0.01)
        --horizon H : VaR horizon in trading days (default 1)
        --window W  : trailing estimation window in bars (default 250)
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd
import yfinance as yf

import var_models as vm

warnings.filterwarnings("ignore")


def _arg(flag, default, cast=float):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
TICKER = _pos[0] if _pos else "RELIANCE.NS"
ALPHA = _arg("--alpha", 0.05)
HORIZON = int(_arg("--horizon", 1, int))
WINDOW = int(_arg("--window", 250, int))


def fetch(ticker):
    """Fetch a long daily history (VaR backtests need many exceptions)."""
    h = yf.Ticker(ticker).history(period="max", interval="1d", auto_adjust=False)
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    return h[["datetime", "adj_close"]].dropna().reset_index(drop=True)


def _verdict(res):
    """One-line pass/fail read of a single method's backtest."""
    kp = res['kupiec'].get('p_value', float('nan'))
    ip = res['independence'].get('p_value', float('nan'))
    cp = res['conditional_coverage'].get('p_value', float('nan'))
    bits = []
    bits.append("rate OK" if kp == kp and kp >= 0.05
                else f"rate REJECTED ({res['kupiec'].get('direction')})"
                if kp == kp else "rate n/a")
    bits.append("independent" if ip == ip and ip >= 0.05
                else "breaches CLUSTERED" if ip == ip else "independence n/a")
    bits.append("passes joint test" if cp == cp and cp >= 0.05
                else "FAILS joint test" if cp == cp else "joint n/a")
    return "; ".join(bits)


def main():
    print(f"=== VaR backtest | {TICKER} | alpha={ALPHA} | horizon={HORIZON}d | "
          f"window={WINDOW} ===")
    df = fetch(TICKER)
    r = vm.returns_from_prices(df["adj_close"].values)
    print(f"Fetched {len(df)} bars ({df['datetime'].iloc[0].date()} -> "
          f"{df['datetime'].iloc[-1].date()}); {len(r)} returns.\n")

    if len(r) < WINDOW + 200:
        print(f"Not enough history for a meaningful backtest "
              f"(need > {WINDOW + 200} returns).")
        return

    # ── Point-in-time estimates from the full history (what would we reserve today?)
    print("-- Today's VaR estimate from each method --")
    est_rows = []
    for name, fn in vm.VAR_ESTIMATORS.items():
        e = fn(r[-max(WINDOW, 500):], ALPHA, HORIZON)
        est_rows.append({
            'method': name,
            'VaR_loss_%': round(e.get('var_loss', float('nan')) * 100, 3),
            'ES_loss_%': round(-e.get('es_return', float('nan')) * 100, 3),
        })
    print(pd.DataFrame(est_rows).to_string(index=False))
    print("Read: the Gaussian (variance-covariance) figure is usually the "
          "smallest — that is the leptokurtosis drawback, not a cheaper risk.\n")

    # ── Rolling out-of-sample backtest, method by method
    print("=" * 78)
    print("ROLLING OUT-OF-SAMPLE BACKTEST")
    print("=" * 78)
    for name in vm.VAR_ESTIMATORS:
        res = vm.backtest_var(r, method=name, alpha=ALPHA, horizon=HORIZON,
                              window=WINDOW, step=HORIZON)
        if not res['n_eval']:
            print(f"{name:<24} (no evaluations)")
            continue
        k, i = res['kupiec'], res['independence']
        print(f"\n{name}")
        print(f"  evaluations       : {res['n_eval']} (step={HORIZON}, "
              f"non-overlapping)")
        print(f"  exception rate    : {res['exception_rate']:.4f} "
              f"(expected {ALPHA})  [{k.get('exceptions')} breaches]")
        print(f"  avg VaR reserved  : {res['avg_var_loss'] * 100:.2f}% of notional")
        print(f"  mean exceedance   : {res['mean_exceedance'] * 100:.2f}% further "
              "than VaR when breached")
        print(f"  Kupiec POF        : LR={k.get('lr_stat', float('nan')):.3f}  "
              f"p={k.get('p_value', float('nan')):.4f}  -> {k.get('direction')}")
        print(f"  Christoffersen ind: LR={i.get('lr_stat', float('nan')):.3f}  "
              f"p={i.get('p_value', float('nan')):.4f}  "
              f"(n01={i.get('n01')}, n11={i.get('n11')}, "
              f"clustered={i.get('clustering')})")
        cc = res['conditional_coverage']
        print(f"  Conditional cover : LR={cc.get('lr_stat', float('nan')):.3f}  "
              f"p={cc.get('p_value', float('nan')):.4f}")
        print(f"  verdict           : {_verdict(res)}")

    # ── Ranked comparison table
    print("\n" + "=" * 78)
    print("COMPARISON (best-calibrated first, by conditional-coverage p-value)")
    print("=" * 78)
    table = vm.compare_var_methods(r, alpha=ALPHA, horizon=HORIZON,
                                   window=WINDOW, step=HORIZON)
    print(table.to_string(index=False) if not table.empty else "(empty)")

    print("\nRead: a high cc_p with a *small* avg_var_loss is the good corner — "
          "correctly calibrated without over-reserving. A high cc_p with a large "
          "avg_var_loss just means the model is expensively cautious.")
    print("Caveat on the independence test: with thousands of evaluations it is "
          "extremely powerful and will reject on almost any equity series that "
          "spans several crises, because volatility clustering is real. On a "
          "large sample compare the *relative* LR statistics across methods "
          "(a conditional method should score materially lower than an "
          "unconditional one) rather than reading the pass/fail label.")
    print("Done. This validates the RISK numbers, which is where this project's "
          "measured value sits; it makes no claim about the point forecast.")


if __name__ == "__main__":
    main()
