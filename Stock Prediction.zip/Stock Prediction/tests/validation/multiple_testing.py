"""
Multiple-testing / data-snooping correction for model selection.

The Diebold-Mariano test (``backtest.diebold_mariano``) is **pairwise**: it asks
whether *one* model beats the random walk. But the app compares **17 models**
(times several tickers), and picking the best-looking one reintroduces exactly
the bias DM was meant to avoid — with enough candidates, one will beat the
benchmark by luck alone. This is the data-snooping problem, and the honest
question becomes:

    After accounting for the fact that we tried K models, is there evidence that
    **any** of them genuinely beats the random walk?

Two standard tests answer it, both operating on the panel of loss differentials
``d_{k,t} = L_benchmark,t - L_model_k,t`` (positive = model k better than the
benchmark at time t), and both using a **stationary bootstrap** to preserve the
serial dependence that overlapping multi-step forecasts create:

- **White's Reality Check** (2000) — bootstraps the distribution of
  ``max_k sqrt(T) * mean(d_k)`` under the least-favourable null. Simple, but its
  power is dragged down by including hopeless models in the set.
- **Hansen's SPA** (2005) — studentizes each model's statistic and applies the
  *consistent* recentering that drops clearly-inferior models from the null, so
  it is more powerful (and the recommended test).

H0 for both: ``max_k E[d_k] <= 0`` — no model in the set beats the benchmark. A
small p-value rejects it (some model genuinely has an edge); a large p-value is
the honest "the apparent winner is within what K tries would produce by chance."

Depends only on numpy. The loss panel is assembled by ``collect_loss_panel``,
which reuses ``calibration.collect_step_records`` so every model is scored on the
same walk-forward origins (alignment is required for the bootstrap to keep the
cross-model dependence).
"""

import math

import numpy as np
import pandas as pd

import backtest as bt


# ==========================================================================
# Automatic block length (Politis & White, 2004)
# ==========================================================================
def _flat_top(t):
    """Flat-top lag window: 1 for |t|<=1/2, 2(1-|t|) for 1/2<|t|<=1, else 0."""
    a = abs(t)
    if a <= 0.5:
        return 1.0
    if a <= 1.0:
        return 2.0 * (1.0 - a)
    return 0.0


def auto_block_length(d):
    """
    Politis-White (2004) optimal stationary-bootstrap mean block length.

    Picks the block length from the data's own autocorrelation so the bootstrap
    captures the serial dependence (overlapping multi-step forecasts are
    correlated) — the missing ingredient that made a fixed block mis-size the
    SPA test. Computed per column and the (robust) median is returned, clipped to
    a sane range.

    Parameters
    ----------
    d : np.ndarray, shape (T, K)
        The loss-differential panel.

    Returns
    -------
    float
        Mean block length for the stationary bootstrap.
    """
    d = np.asarray(d, dtype=np.float64)
    T = d.shape[0]
    if T < 16:
        return max(2.0, math.sqrt(T))
    KN = max(5, int(math.sqrt(math.log10(T))))
    max_lag = min(T - 1, int(math.ceil(math.sqrt(T))) + KN)
    bound = 2.0 * math.sqrt(math.log10(T) / T)

    blocks = []
    for k in range(d.shape[1]):
        x = d[:, k] - d[:, k].mean()
        c0 = float(np.mean(x * x))
        if c0 <= 0:
            continue
        rho = np.array([float(np.mean(x[j:] * x[:-j])) / c0
                        for j in range(1, max_lag + 1)])
        # m_hat: first lag after which KN consecutive |rho| stay below bound.
        m_hat = 1
        for m in range(len(rho) - KN):
            if np.all(np.abs(rho[m:m + KN]) < bound):
                m_hat = m + 1
                break
        else:
            m_hat = len(rho)
        M = min(2 * m_hat, max_lag)
        lags = np.arange(1, M + 1)
        R = c0 * rho[:M]
        w = np.array([_flat_top(j / M) for j in lags])
        g0 = c0 + 2.0 * float(np.sum(w * R))                 # spectral density-ish
        G = 2.0 * float(np.sum(w * lags * R))
        if g0 <= 0:
            continue
        b = (max(G * G, 1e-12) / (g0 * g0)) ** (1.0 / 3.0) * T ** (1.0 / 3.0)
        blocks.append(b)
    if not blocks:
        return max(2.0, math.sqrt(T))
    return float(np.clip(np.median(blocks), 1.0, max(2.0, T / 3.0)))


# ==========================================================================
# Stationary bootstrap (Politis & Romano, 1994)
# ==========================================================================
def stationary_bootstrap_indices(n, n_boot, avg_block, seed=0):
    """
    Stationary-bootstrap row indices: ``(n_boot, n)`` resampling indices with
    geometric (mean ``avg_block``) blocks wrapped circularly.

    Blocks preserve the autocorrelation of the loss-differential series — the
    right resampling for serially dependent forecast errors (overlapping
    multi-step horizons). Vectorised across bootstrap replicates; one Python
    loop over time only.
    """
    rng = np.random.default_rng(seed)
    p = 1.0 / max(avg_block, 1.0)
    starts = rng.integers(0, n, size=(n_boot, n))
    restart = rng.random((n_boot, n)) < p
    idx = np.empty((n_boot, n), dtype=np.int64)
    cur = rng.integers(0, n, size=n_boot)
    for t in range(n):
        cur = np.where(restart[:, t] | (t == 0), starts[:, t], (cur + 1) % n)
        idx[:, t] = cur
    return idx


def _bootstrap_means(d, idx):
    """Bootstrap means ``f*_{b,k}`` for each replicate b and model k."""
    # d: (T, K); idx: (n_boot, T) -> d[idx]: (n_boot, T, K) -> mean over T.
    return d[idx].mean(axis=1)


def _hac_longrun_var(d, bandwidth):
    """
    Newey-West (Bartlett) long-run variance per column.

    Estimates ``omega_k^2 = Var(sqrt(T) * mean(d_k)) = gamma_0 +
    2 * sum_{j=1}^{L} (1 - j/(L+1)) gamma_j`` with the Bartlett kernel, whose
    triangular weights make the estimator **provably non-negative** and
    numerically stable — unlike the raw stationary-bootstrap kernel, whose
    near-T autocovariance terms (built from one or two samples) can collapse a
    column's variance to ~0 and blow up the studentized statistic. Bandwidth
    ``L`` is the (rounded) bootstrap block length, so the studentizer and the
    resampling capture the same serial dependence. Reduces to the sample
    variance when ``L -> 1`` (iid).
    """
    d = np.asarray(d, dtype=np.float64)
    T = d.shape[0]
    L = int(max(1, min(round(bandwidth), T - 1)))
    x = d - d.mean(axis=0, keepdims=True)
    gamma0 = np.mean(x * x, axis=0)
    var = gamma0.copy()
    for j in range(1, L + 1):
        wj = 1.0 - j / (L + 1.0)                        # Bartlett weight
        gj = np.mean(x[j:] * x[:-j], axis=0)
        var += 2.0 * wj * gj
    # Guard: keep a small fraction of gamma_0 as a floor (LRV is >= 0 under
    # Bartlett, but protect against an exactly-degenerate column).
    return np.maximum(var, np.maximum(1e-12, 1e-4 * gamma0))


# ==========================================================================
# White's Reality Check
# ==========================================================================
def whites_reality_check(d, n_boot=2000, avg_block=None, seed=0):
    """
    White's Reality Check p-value for "no model beats the benchmark".

    Parameters
    ----------
    d : np.ndarray, shape (T, K)
        Loss differentials ``L_benchmark - L_model_k`` (positive = model better).
    n_boot : int
        Bootstrap replicates.
    avg_block : float, optional
        Mean stationary-bootstrap block length; defaults to ``sqrt(T)``.
    seed : int
        Bootstrap seed (reproducible).

    Returns
    -------
    dict
        {'stat', 'p_value', 'best_model_idx', 'best_mean', 'T', 'K'}.
    """
    d = np.asarray(d, dtype=np.float64)
    T, K = d.shape
    if avg_block is None:
        avg_block = auto_block_length(d)
    f_bar = d.mean(axis=0)
    stat = float(np.sqrt(T) * np.max(f_bar))

    idx = stationary_bootstrap_indices(T, n_boot, avg_block, seed)
    f_star = _bootstrap_means(d, idx)                      # (n_boot, K)
    boot = np.sqrt(T) * np.max(f_star - f_bar, axis=1)     # recenter at f_bar
    p = float(np.mean(boot >= stat))
    return {'stat': stat, 'p_value': p, 'best_model_idx': int(np.argmax(f_bar)),
            'best_mean': float(np.max(f_bar)), 'T': T, 'K': K}


# ==========================================================================
# Hansen's SPA (consistent variant)
# ==========================================================================
def hansens_spa(d, n_boot=2000, avg_block=None, seed=0):
    """
    Hansen's Superior Predictive Ability test (consistent recentering).

    Studentizes each model's mean loss differential by its bootstrap standard
    deviation, then bootstraps ``max(0, max_k z*_k)`` with the consistent
    recentering that excludes clearly-inferior models (those whose studentized
    statistic is below ``-sqrt(2 log log T)``) from driving the null. More
    powerful than the Reality Check.

    Parameters/returns mirror :func:`whites_reality_check`, plus the per-model
    studentized statistics.

    Returns
    -------
    dict
        {'stat', 'p_value', 'best_model_idx', 'best_mean', 't_stats', 'T', 'K'}.
    """
    d = np.asarray(d, dtype=np.float64)
    T, K = d.shape
    if avg_block is None:
        avg_block = auto_block_length(d)
    f_bar = d.mean(axis=0)

    idx = stationary_bootstrap_indices(T, n_boot, avg_block, seed)
    f_star = _bootstrap_means(d, idx)                      # (n_boot, K)

    # omega_k: Newey-West (Bartlett) long-run std — Hansen's studentizer, with
    # the bandwidth tied to the bootstrap block so both capture the same serial
    # dependence. Provably non-negative (no omega->0 blow-ups).
    omega = np.sqrt(_hac_longrun_var(d, avg_block))
    omega = np.where(omega < 1e-8, 1e-8, omega)

    t_stats = np.sqrt(T) * f_bar / omega
    stat = float(max(0.0, np.max(t_stats)))

    # Consistent recentering: keep recentering (subtract f_bar) for models that
    # aren't clearly inferior; drop it (g_k = 0) for the hopeless ones so they
    # stay negative in the bootstrap and don't inflate the null.
    A = math.sqrt(2.0 * math.log(math.log(T))) if T >= 4 else 2.0
    g = np.where(t_stats >= -A, f_bar, 0.0)

    z_star = np.sqrt(T) * (f_star - g) / omega             # (n_boot, K)
    boot = np.maximum(0.0, np.max(z_star, axis=1))
    p = float(np.mean(boot >= stat))
    return {'stat': stat, 'p_value': p, 'best_model_idx': int(np.argmax(f_bar)),
            'best_mean': float(np.max(f_bar)), 't_stats': t_stats,
            'T': T, 'K': K}


# ==========================================================================
# Aligned loss panel across the model suite
# ==========================================================================
def collect_loss_panel(df, models, interval, horizon, n_splits=10,
                       min_train=300, loss='squared', verbose=True):
    """
    Build the aligned loss-differential matrix ``d`` (benchmark = random walk).

    Each model is run on the **same** walk-forward origins (via
    ``calibration.collect_step_records``). The experiment unit is the **forecast
    origin**, not the (origin, step) pair: the per-origin loss is the *mean* loss
    across that origin's horizon, and ``d_{k,o} = mean_h L_naive - mean_h
    L_model_k`` (positive = model better). This matters for the bootstrap —
    spaced origins have non-overlapping horizons and are ~independent, whereas
    the 5 steps *within* an origin are heavily autocorrelated and would make the
    RC/SPA bootstrap anti-conservative. Only origins every model produced are
    kept (inner alignment), so ``d`` is rectangular with one row per origin.

    Parameters
    ----------
    df : pd.DataFrame
        History with 'datetime' and 'adj_close'.
    models : list of (name, fn, kwargs)
        Models to test; each ``fn(df, interval, horizon, **kwargs)``.
    loss : {'squared', 'absolute'}
        Loss applied to the price error.

    Returns
    -------
    tuple(np.ndarray, list[str])
        ``(d, names)`` — ``d`` is (T, K); ``names`` are the K model names in
        column order. Models that produced no aligned points are dropped.
    """
    import calibration as cal

    def _loss(err):
        return err ** 2 if loss == 'squared' else np.abs(err)

    per_model = {}
    for name, fn, kwargs in models:
        try:
            rec, _ = cal.collect_step_records(
                df, fn, interval, horizon, n_splits=n_splits,
                min_train=min_train, predict_kwargs=kwargs, model_name=name)
        except Exception as exc:
            if verbose:
                print(f"  [{name}] skipped: {str(exc)[:80]}")
            continue
        if rec.empty:
            continue
        rec = rec.copy()
        rec['model_loss'] = _loss(rec['actual'] - rec['pred'])
        rec['naive_loss'] = _loss(rec['actual'] - rec['anchor'])   # RW = anchor
        # Aggregate to ONE loss differential per origin (mean over the horizon).
        agg = rec.groupby('origin').agg(
            model_loss=('model_loss', 'mean'),
            naive_loss=('naive_loss', 'mean'))
        per_model[name] = {int(o): float(r['naive_loss'] - r['model_loss'])
                           for o, r in agg.iterrows()}
        if verbose:
            print(f"  [{name}] {len(per_model[name])} origins")

    if not per_model:
        return np.empty((0, 0)), []

    # Inner alignment: origins present for every surviving model.
    common = set.intersection(*(set(v.keys()) for v in per_model.values()))
    keys = sorted(common)
    names = list(per_model.keys())
    d = np.array([[per_model[n][k] for n in names] for k in keys],
                 dtype=np.float64)
    return d, names


def summarize(d, names, n_boot=2000, seed=0):
    """
    Run both tests on a loss panel and return a tidy verdict.

    Returns
    -------
    dict
        {'rc', 'spa', 'ranking': DataFrame[model, mean_loss_diff, t_stat],
         'verdict': str}.
    """
    rc = whites_reality_check(d, n_boot=n_boot, seed=seed)
    spa = hansens_spa(d, n_boot=n_boot, seed=seed)
    f_bar = d.mean(axis=0)
    ranking = (pd.DataFrame({'model': names, 'mean_loss_diff': f_bar,
                             't_stat': spa['t_stats']})
               .sort_values('mean_loss_diff', ascending=False)
               .reset_index(drop=True))
    best = names[spa['best_model_idx']]
    K = len(names)
    # Lead with the conservative Reality Check for the headline claim; SPA is
    # more powerful but can be mildly liberal at small T, so treat it as
    # supporting evidence rather than the sole basis for declaring an edge.
    if rc['p_value'] < 0.05:
        verdict = (f"REJECT H0 (Reality Check p={rc['p_value']:.3f}, "
                   f"SPA p={spa['p_value']:.3f}): even after correcting for "
                   f"trying {K} models, there is evidence that at least one "
                   f"('{best}') genuinely beats the random walk.")
    elif spa['p_value'] < 0.05:
        verdict = (f"BORDERLINE: SPA rejects (p={spa['p_value']:.3f}) but the "
                   f"conservative Reality Check does not (p={rc['p_value']:.3f}). "
                   f"Given SPA's small-sample liberality, treat the apparent "
                   f"edge of '{best}' as unconfirmed.")
    else:
        verdict = (f"DO NOT reject H0 (Reality Check p={rc['p_value']:.3f}, "
                   f"SPA p={spa['p_value']:.3f}): the best model ('{best}') is "
                   f"within what trying {K} models would produce by chance — no "
                   f"data-snooping-robust edge over the random walk.")
    return {'rc': rc, 'spa': spa, 'ranking': ranking, 'verdict': verdict}
