"""
Does fractional differentiation beat plain log returns? (Falsifiable A/B.)

The design choice under test
----------------------------
Every model in this project sees d = 1 data: log returns, `log_return_1..10`,
and a cumulative-log-return target. That is *maximally* destructive
differencing - it guarantees stationarity and removes all long memory - and it
was adopted by convention, never measured.

Lopez de Prado's fractional differentiation (Kaabar Ch. 9) takes the SMALLEST d
that still passes an ADF test, keeping whatever memory that leaves. On RELIANCE
the difference is stark: at d = 0.50 the transformed series still correlates
0.88 with the price level; at d = 1 the correlation is 0.004.

So the question is direct: **does that retained memory forecast anything?**

Two arms, identical models, identical walk-forward origins:

* **baseline**  - the project's existing feature set (d = 1 throughout)
* **fracdiff**  - the same feature set plus fractionally differenced log-price
  columns at the minimum stationary d

Expectation, stated in advance
------------------------------
A NULL. Section 32 established that this project's binding constraint is
information, not representation, and a representation change cannot create
signal that is not there. It is measured anyway because - unlike "add another
architecture" - frac-diff adds NO PARAMETERS, so a null cannot be blamed on
capacity, and because it puts a number on a choice currently made by convention.

Usage:
    python run_fracdiff_eval.py [--ticker T] [--horizon H] [--origins N]
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import fracdiff as fdm


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKER = _arg("--ticker", "RELIANCE.NS", str)
HORIZON = _arg("--horizon", 5)
ORIGINS = _arg("--origins", 40)
MIN_TRAIN = 800
TOL = 1e-4


def _synthetic(n=3000, seed=0):
    rng = np.random.default_rng(seed)
    px = 100 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    return pd.DataFrame({"datetime": pd.bdate_range("2014-01-02", periods=n),
                         "open": px, "high": px * 1.01, "low": px * 0.99,
                         "close": px, "adj_close": px,
                         "volume": rng.integers(1e5, 5e5, n)})


def _load():
    try:
        from get_data import get_whole_stock_data
        df = get_whole_stock_data(TICKER, "1d")
        if isinstance(df, pd.DataFrame) and len(df) > 1500:
            print(f"  fetched {len(df):,} rows for {TICKER}")
            return df.reset_index(drop=True)
    except Exception as exc:
        print(f"  fetch failed ({str(exc)[:60]}); synthetic series")
    return _synthetic()


def main():
    print(f"=== Fractional differentiation A/B | {TICKER} | horizon {HORIZON}d "
          f"| {ORIGINS} origins ===\n")
    print("Loading data...")
    df = _load()

    px = pd.to_numeric(df["adj_close"], errors="coerce").dropna().values
    logpx = np.log(px)

    # --- Step 1: how much memory does d = 1 actually throw away? -------------
    print("\nStep 1: minimum-d scan (the choice the project made by convention)")
    res = fdm.min_d(logpx, d_grid=np.round(np.arange(0.0, 1.01, 0.1), 2), tol=TOL)
    print(fdm.format_report(res, f"{TICKER} log price (tol={TOL})"))

    d = res["d"]
    if not np.isfinite(d) or d >= 1.0:
        print("\nNo fractional order below 1 achieved stationarity; "
              "d = 1 is already minimal here and there is nothing to test.")
        return

    # --- Step 2: does the retained memory forecast anything? -----------------
    print(f"\nStep 2: walk-forward A/B at d = {d:.2f}")
    import ML_model
    import lightgbm as lgb

    feat = ML_model.create_features(df.copy(), "daily").reset_index(drop=True)
    feat = fdm.add_fracdiff_features(feat, d=d, tol=TOL)
    fd_col = [c for c in feat.columns if c.startswith("fd_")]

    drop = {"datetime", "date", "open", "high", "low", "close", "adj_close",
            "volume", "target", "target_log_return", "y"}
    base_cols = [c for c in feat.select_dtypes(include=[np.number]).columns
                 if c not in drop and not c.startswith("fd_")]
    frac_cols = base_cols + fd_col

    p = pd.to_numeric(feat["adj_close"], errors="coerce").values
    y = np.log(np.roll(p, -HORIZON) / p)
    ok = np.isfinite(y)
    ok[-HORIZON:] = False
    for c in frac_cols:
        ok &= np.isfinite(pd.to_numeric(feat[c], errors="coerce").values)

    work = feat.loc[ok].reset_index(drop=True)
    y = y[ok]
    n = len(work)
    print(f"  {n:,} usable rows after the frac-diff window "
          f"({len(fdm.frac_weights(d, tol=TOL))} bars consumed)")
    print(f"  baseline features {len(base_cols)} | + frac-diff {len(frac_cols)}")

    usable = n - MIN_TRAIN - HORIZON
    if usable < 20:
        print("  Not enough history for a walk-forward A/B.")
        return
    step = max(1, usable // ORIGINS)
    origins = list(range(MIN_TRAIN, n - HORIZON, step))[:ORIGINS]
    print(f"  {len(origins)} origins, min train {MIN_TRAIN}\n")

    rows = []
    for i, o in enumerate(origins, 1):
        # EMBARGO. Row o-1's target spans [o-1, o-1+h], which OVERLAPS the
        # evaluation target y[o]. Training on it leaks the answer: an earlier
        # version of this driver did exactly that and reported a 20% RMSE
        # improvement over the random walk - a number flatly inconsistent with
        # every other result in this project, which is what gave it away.
        train_end = o - HORIZON
        if train_end < MIN_TRAIN // 2:
            continue
        yt = y[:train_end]
        actual = float(y[o])
        naive = 0.0                       # random walk: zero expected log return
        rec = {"origin": o, "actual": actual, "naive_err": naive - actual}
        for name, cols in (("baseline", base_cols), ("fracdiff", frac_cols)):
            m = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05,
                                  num_leaves=31, min_child_samples=40,
                                  verbose=-1, random_state=42, n_jobs=1)
            m.fit(work.loc[:train_end - 1, cols], yt)
            pred = float(m.predict(work.loc[[o], cols])[0])
            rec[f"{name}_err"] = pred - actual
            rec[f"{name}_pred"] = pred
        rows.append(rec)
        if i % 10 == 0:
            print(f"  ...{i}/{len(origins)}")

    r = pd.DataFrame(rows)
    print("\n" + "=" * 78)
    print("-- Out-of-sample RMSE on the h-step cumulative log return --")
    out = {}
    for name in ("naive", "baseline", "fracdiff"):
        out[name] = float(np.sqrt(np.mean(r[f"{name}_err"] ** 2)))
        print(f"  {name:<10} {out[name]:.6f}")

    print("\n-- Verdict --")
    imp_base = 100 * (out["naive"] - out["baseline"]) / out["naive"]
    imp_frac = 100 * (out["naive"] - out["fracdiff"]) / out["naive"]
    delta = 100 * (out["baseline"] - out["fracdiff"]) / out["baseline"]
    print(f"  baseline vs random walk : {imp_base:+.2f}%")
    try:
        from backtest import diebold_mariano as _dm
        d0 = _dm(r["baseline_err"].values, r["naive_err"].values, h=HORIZON)
        print(f"    (DM vs random walk: stat {d0.get('stat', float('nan')):.3f}, "
              f"p = {d0.get('p_value', float('nan')):.3f})")
    except Exception:
        pass
    print(f"  fracdiff vs random walk : {imp_frac:+.2f}%")
    print(f"  fracdiff vs baseline    : {delta:+.2f}%")

    # Diebold-Mariano on the two feature sets, so the comparison is not read off
    # a raw RMSE difference that a handful of origins could produce by chance.
    try:
        from backtest import diebold_mariano
        dm = diebold_mariano(r["baseline_err"].values, r["fracdiff_err"].values,
                             h=HORIZON)
        print(f"  Diebold-Mariano (baseline vs fracdiff): "
              f"stat {dm.get('stat', float('nan')):.3f}, "
              f"p = {dm.get('p_value', float('nan')):.3f}  (n={dm.get('n')})")
        sig = np.isfinite(dm.get("p_value", np.nan)) and dm["p_value"] < 0.05
    except Exception as exc:
        print(f"  Diebold-Mariano unavailable ({str(exc)[:50]})")
        sig = False

    print()
    if sig and delta > 0:
        print("  FRAC-DIFF WINS, and significantly. Treat as PROVISIONAL: "
              "re-run on other tickers and horizons before believing it. One "
              "ticker crossing a threshold is what data-snooping looks like.")
    elif sig and delta < 0:
        print("  FRAC-DIFF LOSES significantly. The retained memory is noise "
              "the model fits; d = 1 is the better representation here.")
    else:
        print("  NO DIFFERENCE. The retained memory - 0.88 correlation with the "
              "price level, versus 0.004 at d = 1 - forecasts nothing at this "
              "horizon. That is the predicted outcome: frac-diff changes the "
              "REPRESENTATION, and Section 32 established the constraint is "
              "INFORMATION. Notably it adds no parameters, so this null cannot "
              "be blamed on capacity - which makes it a cleaner negative than "
              "the N-BEATS and Vol-LSTM results.")
    print("\nDone.")


if __name__ == "__main__":
    main()
