"""
Live monitoring: resolve matured predictions, then report drift, gate skill and
the paper portfolio.

Book Ch. 3's "Going live" arc, operationalised. Unlike every other driver in this
folder, this one **does not run any model and does not choose any origins**. It
reads what the app actually served (``.prediction_log/predictions.jsonl``), joins
the realised prices that have arrived since, and scores them.

That distinction is the entire point. A backtest picks its own origins, re-fits at
each one, and can be re-run until it says something nice. A forward log has none
of those degrees of freedom: the prediction was written before its outcome
existed, every served forecast is in the sample, and the only new information is
the price that showed up later. Whatever this driver reports is therefore the
closest thing to an unbiased read the project has — and, early on, the least
precise, because live samples start small.

Three questions it answers that no backtest can:

1. **Is the cone still calibrated?** A conformal interval is calibrated at fit
   time and decays silently as the regime moves. Live coverage over the last N
   resolved predictions is the number that would catch that.
2. **Did the confidence gate work?** Buckets were assigned before outcomes
   existed. If realised accuracy does not rise from "No edge" to "High", the gate
   is decoration.
3. **Would the served signals have made money?** The paper portfolio, with no
   origin selection at all.

Usage:
    python run_drift_report.py [--resolve] [--recent N] [--cost BPS]
        --resolve   : fetch prices and fill in matured outcomes first (network)
        --recent N  : size of the recent window per model (default 60)
        --cost BPS  : one-way cost for the paper portfolio (default 10)

Typical use is a scheduled ``--resolve`` run: outcomes mature on their own
schedule, so resolving daily and reading the report weekly is the natural cadence.
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import prediction_log as pl

warnings.filterwarnings("ignore")


def _arg(flag, default, cast=float):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


RECENT = int(_arg("--recent", 60, int))
COST_BPS = _arg("--cost", 10.0)
DO_RESOLVE = "--resolve" in sys.argv


def main():
    print("=== Live prediction-log report ===")
    print(f"Log: {pl.LOG_FILE}")

    raw = pl.read_log()
    if raw.empty:
        print("\nThe log is empty. Nothing has been served yet, or "
              "USE_PREDICTION_LOG is off (see config.py, or "
              "STOCKAPP_USE_PREDICTION_LOG=0).")
        print("Run the app and submit a forecast, then come back once the "
              "horizon has matured.")
        return

    print(f"Rows logged: {len(raw)}  |  models: {raw['model'].nunique()}  |  "
          f"tickers: {raw['ticker'].nunique()}")
    print(f"Unresolved:  {int(raw['realised_price'].isna().sum())}")

    if DO_RESOLVE:
        print("\nResolving matured predictions against realised prices...")
        # Resolve through safe_fetch so a transient provider failure degrades to
        # 'resolved nothing this run' rather than corrupting the log.
        from get_data import get_whole_stock_data
        from safe_fetch import fetch_with_fallback

        def _fetch(ticker, interval):
            return fetch_with_fallback(ticker, interval,
                                       fetch_fn=get_whole_stock_data)

        res = pl.resolve_outcomes(_fetch)
        print(f"  resolved {res['resolved']}, still pending "
              f"{res['still_pending']}")
    else:
        print("\n(Skipping resolution — pass --resolve to fetch prices and fill "
              "in matured outcomes.)")

    print()
    print(pl.summary(recent=RECENT))

    print("\n" + "-" * 78)
    print("How to read this")
    print("-" * 78)
    print("* Live coverage is the headline: it is the 95% claim the product "
          "actually makes, measured on forecasts nobody could have cherry-picked.")
    print("* An alert fires only when the binomial CI EXCLUDES the target. Below "
          "that bar the sample cannot tell drift from noise, and an alert that "
          "fires on noise teaches people to ignore alerts.")
    print("* The gate table is the stronger version of run_calibration.py's "
          "nested gate validation: these buckets were assigned before the "
          "outcomes existed.")
    print("* The paper portfolio has no origin selection and no re-fitting, so "
          "it is the least flattering and most trustworthy P&L number here. "
          "Expect it to be unimpressive — that is consistent with run_spa.py.")
    print("\nDone.")


if __name__ == "__main__":
    main()
