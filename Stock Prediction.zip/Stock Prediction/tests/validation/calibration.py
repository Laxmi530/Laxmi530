"""
Calibration & probabilistic-scoring harness — *validating the claims the app
now makes*, rather than adding new ones.

Once the product's value moved from the point forecast to the **uncertainty**
(HAR-RV cone, conformal intervals, a confidence gate, and P(up)/P(move)/VaR
read off an empirical distribution), the open question is no longer "is the
point forecast good?" — the backtest already answered that (mostly no). It is:

    Are the probabilistic outputs actually calibrated, or are they theatre?

A "95%" interval that only covers 80% of the time, a "High confidence" bucket
that does no better out-of-sample than "No edge", or a "P(up)=70%" that is right
55% of the time are all worse than honest silence. This module measures all of
that with proper, standard tools:

1. **CRPS** (Continuous Ranked Probability Score) — the gold-standard *proper*
   score for a full predictive distribution. It jointly rewards calibration and
   sharpness, so it is the right headline metric for a distribution-first
   product (lower is better; it generalises MAE to distributions). Computed per
   horizon, and — for models that expose an empirical fat-tailed sample
   (HAR-RV's conformal residuals) — both the empirical-sample CRPS and the
   log-normal-approximation CRPS are reported side by side, so the value of the
   fat tails is visible, not asserted.

2. **PIT** (Probability Integral Transform) — F_pred(actual) should be Uniform
   (0,1) if the predictive distribution is calibrated. We return the PIT sample
   and its deviation from uniform (KS distance), the distributional analogue of
   a coverage check at every quantile, not just 95%.

3. **Reliability** of P(up) and P(move > X%) — bin the predicted probabilities
   and compare to the realised frequency. The Expected Calibration Error (ECE)
   says whether "70%" really means 70%.

4. **Coverage quality**, not just coverage — coverage *and* mean interval width,
   their ratio (efficiency), and the lower/upper tail-miss balance. A wide band
   can always cover; a band whose misses are all on the downside is hiding
   crash risk.

5. **Gate validation** — does the live confidence label actually sort
   out-of-sample skill? A nested walk-forward assigns each origin a bucket from
   *past* data only (the same ``backtest.confidence_bucket`` rule the UI ships),
   then measures the realised next-horizon improvement over the random walk.
   "High" should beat "Low" should beat "No edge" — if not, the gate is theatre.

The module depends only on numpy / pandas (+ optional scipy for the KS p-value),
and injects the model via the same ``fn(df, interval, horizon) -> DataFrame``
contract as the rest of the suite, reusing ``backtest``'s baselines and DM test.
"""

import math

import numpy as np
import pandas as pd

import backtest as bt

_EPS = 1e-12


# ==========================================================================
# Proper scores: CRPS
# ==========================================================================
def crps_sample(samples, y):
    """
    CRPS of an empirical/ensemble predictive distribution against observation y.

    Uses the energy form ``CRPS = E|X - y| - 0.5 E|X - X'|`` with the
    O(m log m) sorted identity for the second term, so a fat-tailed Monte-Carlo
    or conformal-residual sample is scored exactly (no distributional
    assumption). Lower is better.

    Parameters
    ----------
    samples : array-like
        Draws from the predictive distribution (price units).
    y : float
        Realised value (price units).

    Returns
    -------
    float
        CRPS, or NaN if the sample is empty.
    """
    x = np.sort(np.asarray(samples, dtype=np.float64))
    m = len(x)
    if m == 0:
        return float('nan')
    term1 = float(np.mean(np.abs(x - y)))
    # Sum_{i,j}|x_i - x_j| = 2 * sum_i (2i - m - 1) x_(i), i = 1..m (ascending).
    i = np.arange(1, m + 1)
    term2 = float(np.sum((2 * i - m - 1) * x)) / (m * m)   # = 0.5 * E|X-X'|
    return term1 - term2


def crps_gaussian(mu, sigma, y):
    """
    Closed-form CRPS of a Normal(mu, sigma) predictive against y.

    Gneiting & Raftery (2007):
    ``CRPS = sigma * [ z(2Φ(z) - 1) + 2φ(z) - 1/sqrt(pi) ]``, ``z = (y-mu)/sigma``.
    Used as the *approximation* baseline to contrast with the empirical-sample
    CRPS, making the cost of re-imposing normality explicit.
    """
    if sigma <= 0:
        return abs(y - mu)
    z = (y - mu) / sigma
    cdf = 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))
    pdf = math.exp(-0.5 * z * z) / math.sqrt(2.0 * math.pi)
    return float(sigma * (z * (2.0 * cdf - 1.0) + 2.0 * pdf - 1.0 / math.sqrt(math.pi)))


def _z(p):
    """Standard-normal quantile (inverse CDF) without SciPy."""
    from statistics import NormalDist
    return NormalDist().inv_cdf(p)


def _lognormal_logret_params(anchor, median, lower, upper, conf=0.95):
    """
    Recover (mu, sigma) of the log-return predictive implied by a price interval.

    The bounds are treated as the (1±conf)/2 quantiles of a log-normal price, so
    ``mu = log(median/anchor)`` and ``sigma = (log U - log L) / (2 z)`` — the
    same mapping the UI's interval-fallback risk read uses. Returns None if the
    interval is degenerate.
    """
    if min(anchor, median, lower, upper) <= 0 or upper <= lower:
        return None
    z = _z(1.0 - (1.0 - conf) / 2.0)
    mu = math.log(median / anchor)
    sigma = (math.log(upper) - math.log(lower)) / (2.0 * z)
    return (mu, sigma) if sigma > 0 else None


def _lognormal_price_sample(anchor, mu, sigma, n=512):
    """
    Deterministic representative price sample from a log-return Normal(mu, sigma).

    Built on an evenly spaced probability grid (inverse-CDF), so it is smooth and
    reproducible (no RNG) — used to score the log-normal approximation with the
    same ``crps_sample`` machinery as the empirical path.
    """
    ps = (np.arange(1, n + 1) - 0.5) / n
    zg = np.array([_z(p) for p in ps])
    return anchor * np.exp(mu + sigma * zg)


# ==========================================================================
# Walk-forward record collection (richer than backtest.walk_forward_backtest)
# ==========================================================================
def collect_step_records(df, predict_fn, interval, horizon,
                         n_splits=8, min_train=300, predict_kwargs=None,
                         model_name='model', conf=0.95, verbose=False):
    """
    Walk-forward, retaining the *per-(origin, step)* forecast, interval and
    realised value needed for distributional scoring.

    Unlike :func:`backtest.walk_forward_backtest` (which keeps only aggregate
    metrics), this records, for every origin and every horizon step ``h``:
    anchor, realised price, point forecast, interval bounds, and the realised
    log-return. It also captures any horizon-end empirical return sample the
    model exposes via ``prediction.attrs['risk_log_returns']`` (HAR-RV), keyed
    by origin, so CRPS/PIT can use the genuine fat-tailed distribution.

    Returns
    -------
    tuple(pd.DataFrame, dict)
        ``(records, empirical)`` — ``records`` has one row per (origin, step)
        with columns [origin, step, anchor, actual, pred, lower, upper,
        realized_logret]; ``empirical`` maps origin -> horizon-end empirical
        log-return sample (np.ndarray) for models that expose one.
    """
    predict_kwargs = predict_kwargs or {}
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.sort_values('datetime').reset_index(drop=True)
    df['adj_close'] = pd.to_numeric(df['adj_close'], errors='coerce')
    prices = df['adj_close'].values.astype(np.float64)
    n = len(df)

    max_origin = n - horizon
    if max_origin <= min_train:
        raise ValueError(
            f"Not enough data: need > {min_train + horizon} rows, have {n}.")
    origins = np.unique(np.linspace(min_train, max_origin, n_splits, dtype=int))

    rows, empirical = [], {}
    for origin in origins:
        train_df = df.iloc[:origin]
        anchor = float(prices[origin - 1])
        actual = prices[origin:origin + horizon]
        try:
            fc = predict_fn(train_df, interval, horizon, **predict_kwargs)
        except Exception as exc:
            if verbose:
                print(f"  [{model_name}] origin={origin} FAILED: {exc}")
            continue
        if fc is None or 'predicted_price' not in getattr(fc, 'columns', []):
            continue
        pred = np.asarray(fc['predicted_price'].values[:horizon], dtype=np.float64)
        if len(pred) < horizon:
            continue
        lower = (fc['lower_bound'].values[:horizon]
                 if 'lower_bound' in fc.columns else np.full(horizon, np.nan))
        upper = (fc['upper_bound'].values[:horizon]
                 if 'upper_bound' in fc.columns else np.full(horizon, np.nan))

        sample = fc.attrs.get('risk_log_returns') if hasattr(fc, 'attrs') else None
        if sample is not None and len(sample) >= 20:
            empirical[int(origin)] = np.asarray(sample, dtype=np.float64)

        for hstep in range(horizon):
            if anchor <= 0 or actual[hstep] <= 0:
                continue
            rows.append({
                'origin': int(origin),
                'step': hstep + 1,
                'anchor': anchor,
                'actual': float(actual[hstep]),
                'pred': float(pred[hstep]),
                'lower': float(lower[hstep]),
                'upper': float(upper[hstep]),
                'realized_logret': math.log(actual[hstep] / anchor),
            })
    return pd.DataFrame(rows), empirical


# ==========================================================================
# Coverage quality
# ==========================================================================
def coverage_quality(records, conf=0.95):
    """
    Per-horizon coverage *and the things plain coverage hides*.

    For each step returns: empirical coverage, mean/median interval width as a
    % of the anchor, the coverage-to-width efficiency ratio, and the lower/upper
    tail-miss rates with their balance. A band that covers only by being wide
    has poor efficiency; misses skewed to the downside mean the cone
    underestimates crash risk (reviewer's point).

    Returns
    -------
    pd.DataFrame
        Indexed by step, or empty if no interval rows exist.
    """
    have = records.dropna(subset=['lower', 'upper'])
    if have.empty:
        return pd.DataFrame()
    out = []
    for step, g in have.groupby('step'):
        a, lo, hi, anc = (g['actual'].values, g['lower'].values,
                          g['upper'].values, g['anchor'].values)
        covered = (a >= lo) & (a <= hi)
        width_pct = (hi - lo) / anc * 100.0
        cov = float(np.mean(covered))
        mean_w = float(np.mean(width_pct))
        lower_miss = float(np.mean(a < lo))
        upper_miss = float(np.mean(a > hi))
        out.append({
            'step': int(step),
            'n': int(len(g)),
            'coverage': round(cov, 3),
            'target': conf,
            'mean_width_%': round(mean_w, 2),
            'median_width_%': round(float(np.median(width_pct)), 2),
            'cov_to_width': round(cov / mean_w, 4) if mean_w > 0 else float('nan'),
            'lower_miss': round(lower_miss, 3),
            'upper_miss': round(upper_miss, 3),
            'tail_balance': round(lower_miss - upper_miss, 3),
        })
    return pd.DataFrame(out).set_index('step')


# ==========================================================================
# CRPS report
# ==========================================================================
def crps_report(records, empirical=None, conf=0.95):
    """
    Per-horizon CRPS from the interval-implied log-normal predictive, plus a
    final-horizon empirical-sample CRPS where the model exposes one.

    The per-step CRPS uses the deterministic log-normal sample from each step's
    interval (uniform across all models). For the final horizon, if an empirical
    return sample is available (HAR-RV), its CRPS is reported alongside the
    log-normal CRPS over the *same* origins, so the fat-tail benefit (or cost)
    is directly comparable.

    Returns
    -------
    dict
        {'per_step': DataFrame indexed by step with 'crps_lognormal' (and 'n'),
         'final_horizon': dict or None comparing empirical vs log-normal CRPS}.
    """
    have = records.dropna(subset=['lower', 'upper'])
    per_step = []
    for step, g in have.groupby('step'):
        vals = []
        for _, r in g.iterrows():
            params = _lognormal_logret_params(
                r['anchor'], r['pred'], r['lower'], r['upper'], conf)
            if params is None:
                continue
            mu, sigma = params
            samp = _lognormal_price_sample(r['anchor'], mu, sigma)
            vals.append(crps_sample(samp, r['actual']))
        if vals:
            per_step.append({'step': int(step), 'n': len(vals),
                             'crps_lognormal': round(float(np.mean(vals)), 4)})
    per_step_df = (pd.DataFrame(per_step).set_index('step')
                   if per_step else pd.DataFrame())

    final = None
    if empirical:
        h = int(records['step'].max())
        fin = records[records['step'] == h]
        emp_crps, ln_crps = [], []
        for _, r in fin.iterrows():
            o = r['origin']
            if o not in empirical:
                continue
            # Empirical: horizon-end log-return sample -> price sample.
            price_samp = r['anchor'] * np.exp(empirical[o])
            emp_crps.append(crps_sample(price_samp, r['actual']))
            params = _lognormal_logret_params(
                r['anchor'], r['pred'], r['lower'], r['upper'], conf)
            if params is not None:
                mu, sigma = params
                ln_crps.append(crps_sample(
                    _lognormal_price_sample(r['anchor'], mu, sigma), r['actual']))
        if emp_crps:
            final = {
                'horizon': h,
                'n': len(emp_crps),
                'crps_empirical': round(float(np.mean(emp_crps)), 4),
                'crps_lognormal': (round(float(np.mean(ln_crps)), 4)
                                   if ln_crps else float('nan')),
            }
    return {'per_step': per_step_df, 'final_horizon': final}


# ==========================================================================
# PIT (distributional calibration)
# ==========================================================================
def pit_values(records, empirical=None, conf=0.95):
    """
    Probability Integral Transform F_pred(actual) for every record.

    Uses the empirical predictive CDF at the final horizon where a sample is
    available, and the interval-implied log-normal CDF otherwise. Under a
    calibrated predictive these values are Uniform(0,1).

    Returns
    -------
    np.ndarray
        PIT values in [0, 1].
    """
    have = records.dropna(subset=['lower', 'upper'])
    h = int(records['step'].max()) if len(records) else 0
    pit = []
    for _, r in have.iterrows():
        o, step = r['origin'], r['step']
        if empirical and step == h and o in empirical:
            s = empirical[o]
            pit.append(float(np.mean(s <= r['realized_logret'])))
            continue
        params = _lognormal_logret_params(
            r['anchor'], r['pred'], r['lower'], r['upper'], conf)
        if params is None:
            continue
        mu, sigma = params
        z = (r['realized_logret'] - mu) / sigma
        pit.append(0.5 * (1.0 + math.erf(z / math.sqrt(2.0))))
    return np.asarray(pit, dtype=np.float64)


def pit_summary(pit, bins=10):
    """
    Summarise a PIT sample's departure from Uniform(0,1).

    Returns the histogram (equal-width bins; a flat histogram = calibrated, a
    U-shape = over-confident, a hump = under-confident) and the KS distance to
    the uniform CDF with a p-value (SciPy if available, else None).

    Returns
    -------
    dict
        {'n', 'hist', 'bin_edges', 'ks_stat', 'ks_p', 'mean', 'verdict'}.
    """
    pit = np.asarray(pit, dtype=np.float64)
    n = len(pit)
    if n == 0:
        return {'n': 0, 'hist': [], 'bin_edges': [], 'ks_stat': float('nan'),
                'ks_p': None, 'mean': float('nan'), 'verdict': 'no data'}
    hist, edges = np.histogram(pit, bins=bins, range=(0.0, 1.0))
    ks_p = None
    try:
        from scipy.stats import kstest
        ks_stat, ks_p = kstest(pit, 'uniform')
        ks_stat = float(ks_stat)
    except Exception:
        s = np.sort(pit)
        cdf = np.arange(1, n + 1) / n
        ks_stat = float(np.max(np.abs(cdf - s)))
    # Crude shape read for the headline.
    expected = n / bins
    edge_heavy = (hist[0] + hist[-1]) / 2.0
    if edge_heavy > 1.5 * expected:
        verdict = 'U-shaped -> intervals too NARROW (over-confident)'
    elif edge_heavy < 0.5 * expected:
        verdict = 'hump-shaped -> intervals too WIDE (under-confident)'
    else:
        verdict = 'approximately uniform -> calibrated'
    return {'n': n, 'hist': hist.tolist(), 'bin_edges': edges.tolist(),
            'ks_stat': round(ks_stat, 4),
            'ks_p': (round(float(ks_p), 4) if ks_p is not None else None),
            'mean': round(float(np.mean(pit)), 4), 'verdict': verdict}


# ==========================================================================
# Reliability of probabilistic calls (P(up), P(move > X%))
# ==========================================================================
def reliability(records, empirical=None, kind='up', threshold_pct=2.0,
                conf=0.95, n_bins=10):
    """
    Reliability (calibration) curve and ECE for a probabilistic call.

    ``kind='up'`` scores the predicted P(price up) against whether the price
    actually rose; ``kind='move'`` scores predicted P(|return| > threshold)
    against whether a move that size actually occurred. Predicted probabilities
    come from the empirical sample where available, else the log-normal
    predictive. Probabilities are binned and compared to the realised frequency;
    the Expected Calibration Error (ECE) is the bin-size-weighted mean gap.

    Note: a pure random-walk point model (HAR-RV) predicts P(up)≈0.5 at every
    origin, so its 'up' reliability is intentionally degenerate — this metric is
    informative for the *directional* models.

    Returns
    -------
    dict
        {'kind', 'n', 'ece', 'bins': DataFrame, 'base_rate', 'mean_pred'}.
    """
    have = records.dropna(subset=['lower', 'upper'])
    h = int(records['step'].max()) if len(records) else 0
    t = math.log(1.0 + threshold_pct / 100.0)
    preds, outcomes = [], []
    for _, r in have.iterrows():
        o, step, rl = r['origin'], r['step'], r['realized_logret']
        if empirical and step == h and o in empirical:
            s = empirical[o]
            p_up = float(np.mean(s > 0.0))
            p_move = float(np.mean(np.abs(s) > t))
        else:
            params = _lognormal_logret_params(
                r['anchor'], r['pred'], r['lower'], r['upper'], conf)
            if params is None:
                continue
            mu, sigma = params
            cdf0 = 0.5 * (1.0 + math.erf((0.0 - mu) / (sigma * math.sqrt(2.0))))
            p_up = 1.0 - cdf0
            cdf_t = 0.5 * (1.0 + math.erf((t - mu) / (sigma * math.sqrt(2.0))))
            cdf_mt = 0.5 * (1.0 + math.erf((-t - mu) / (sigma * math.sqrt(2.0))))
            p_move = (1.0 - cdf_t) + cdf_mt
        if kind == 'up':
            preds.append(p_up)
            outcomes.append(1.0 if rl > 0.0 else 0.0)
        else:
            preds.append(p_move)
            outcomes.append(1.0 if abs(rl) > t else 0.0)

    preds = np.asarray(preds)
    outcomes = np.asarray(outcomes)
    n = len(preds)
    if n == 0:
        return {'kind': kind, 'n': 0, 'ece': float('nan'),
                'bins': pd.DataFrame(), 'base_rate': float('nan'),
                'mean_pred': float('nan')}
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(preds, edges) - 1, 0, n_bins - 1)
    rows, ece = [], 0.0
    for b in range(n_bins):
        sel = idx == b
        cnt = int(np.sum(sel))
        if cnt == 0:
            continue
        mean_p = float(np.mean(preds[sel]))
        obs = float(np.mean(outcomes[sel]))
        ece += cnt / n * abs(mean_p - obs)
        rows.append({'bin': f"{edges[b]:.1f}-{edges[b+1]:.1f}", 'n': cnt,
                     'mean_pred': round(mean_p, 3), 'observed': round(obs, 3),
                     'gap': round(mean_p - obs, 3)})
    return {'kind': kind, 'n': n, 'ece': round(ece, 4),
            'bins': pd.DataFrame(rows), 'base_rate': round(float(np.mean(outcomes)), 3),
            'mean_pred': round(float(np.mean(preds)), 3)}


# ==========================================================================
# Gate validation (does the confidence label sort out-of-sample skill?)
# ==========================================================================
def validate_gate(df, predict_fn, interval, horizon, n_splits=8,
                  min_train=300, inner_splits=3, inner_min_train=200,
                  predict_kwargs=None, model_name='model', verbose=False):
    """
    Nested walk-forward test of whether the confidence bucket is informative.

    At each outer origin the bucket is computed from an **inner** walk-forward on
    data strictly before the origin (mirroring the live gate, via
    ``backtest.confidence_bucket``), and the **realised** next-horizon RMSE
    improvement over the naive random walk is recorded. Grouping the realised
    improvement by the (past-only) bucket answers the only question that matters:
    does "High" actually do better out-of-sample than "Low"/"No edge"? If the
    ordering doesn't hold, the gate is theatre.

    Returns
    -------
    dict
        {'per_origin': DataFrame[origin, bucket, improvement, beats_naive],
         'by_bucket': DataFrame indexed by bucket with mean improvement,
         beats-naive rate and count, 'monotonic': bool or None}.
    """
    predict_kwargs = predict_kwargs or {}
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.sort_values('datetime').reset_index(drop=True)
    df['adj_close'] = pd.to_numeric(df['adj_close'], errors='coerce')
    prices = df['adj_close'].values.astype(np.float64)
    n = len(df)

    max_origin = n - horizon
    # Need enough history before each origin to run the inner gate backtest.
    start = max(min_train, inner_min_train + horizon + 10)
    if max_origin <= start:
        raise ValueError("Not enough data for nested gate validation.")
    origins = np.unique(np.linspace(start, max_origin, n_splits, dtype=int))

    per = []
    for origin in origins:
        past = df.iloc[:origin]
        # Inner gate: bucket from PAST data only.
        try:
            inner = bt.walk_forward_backtest(
                past, predict_fn, interval, horizon,
                n_splits=inner_splits, min_train=inner_min_train,
                predict_kwargs=predict_kwargs, model_name=model_name,
                verbose=False,
                # The nested gate only needs the RMSE/DM summary; skip the
                # economic block so this inner loop stays as cheap as it was.
                strategy=False)
        except Exception as exc:
            if verbose:
                print(f"  inner gate failed @ {origin}: {exc}")
            continue
        s = inner['summary']
        base = min(float(s.loc['rmse', c]) for c in ('naive', 'drift', 'ar1')
                   if c in s.columns)
        m_rmse = float(s.loc['rmse', 'model'])
        improvement = (base - m_rmse) / base if base > 0 else 0.0
        dm_p = float(inner.get('dm', {}).get('p_value', float('nan')))
        cov = (float(s.loc['coverage', 'model'])
               if 'coverage' in s.index else float('nan'))
        bucket = bt.confidence_bucket(improvement, dm_p, cov)

        # Outer realised skill on the genuinely-unseen next horizon.
        anchor = float(prices[origin - 1])
        actual = prices[origin:origin + horizon]
        try:
            fc = predict_fn(past, interval, horizon, **predict_kwargs)
            pred = np.asarray(fc['predicted_price'].values[:horizon], float)
        except Exception:
            continue
        if len(pred) < horizon:
            continue
        naive = bt.naive_forecast(anchor, horizon)
        m_out = bt.rmse(actual, pred)
        n_out = bt.rmse(actual, naive)
        out_impr = (n_out - m_out) / n_out if n_out > 0 else 0.0
        per.append({'origin': int(origin), 'bucket': bucket,
                    'improvement': round(out_impr, 4),
                    'beats_naive': bool(m_out < n_out)})
        if verbose:
            print(f"  origin={origin}: bucket={bucket} "
                  f"out_impr={out_impr:+.3f}")

    per_df = pd.DataFrame(per)
    if per_df.empty:
        return {'per_origin': per_df, 'by_bucket': pd.DataFrame(),
                'monotonic': None}

    order = ['No edge', 'Low', 'Medium', 'High']
    by = (per_df.groupby('bucket')
          .agg(n=('origin', 'size'),
               mean_improvement=('improvement', 'mean'),
               beats_naive_rate=('beats_naive', 'mean'))
          .reindex([b for b in order if b in set(per_df['bucket'])]))
    by['mean_improvement'] = by['mean_improvement'].round(4)
    by['beats_naive_rate'] = by['beats_naive_rate'].round(3)

    present = [b for b in order if b in by.index]
    monotonic = None
    if len(present) >= 2:
        vals = [by.loc[b, 'mean_improvement'] for b in present]
        monotonic = all(vals[i] <= vals[i + 1] for i in range(len(vals) - 1))
    return {'per_origin': per_df, 'by_bucket': by, 'monotonic': monotonic}


# ==========================================================================
# Adaptive (ACI) vs static conformal — does the adaptation help coverage?
# ==========================================================================
def _abs_miscoverage(cq, target=0.95):
    """Mean absolute deviation of per-horizon coverage from target."""
    if cq.empty:
        return float('nan')
    return float(np.mean(np.abs(cq['coverage'].values - target)))


def compare_static_vs_aci(df, predict_fn, interval, horizon, n_splits=10,
                          min_train=300, model_name='HAR-RV', aci_gamma=0.05):
    """
    A/B the same volatility model with static vs ACI-adaptive conformal cones.

    Runs the walk-forward record collection twice — ``adaptive=False`` and
    ``adaptive=True`` — and compares per-horizon coverage and mean interval
    width. ACI should pull coverage *toward* the 95% target under regime shift
    (lower mean |coverage − 0.95|), ideally without inflating width much. This
    is the measurement that justifies (or refutes) turning ACI on by default.

    Parameters
    ----------
    predict_fn : callable
        A model honouring an ``adaptive`` kwarg (e.g.
        ``HAR_RV_model.run_har_rv_prediction``).

    Returns
    -------
    dict
        {'static': coverage_quality DataFrame, 'aci': DataFrame,
         'static_miscoverage', 'aci_miscoverage',
         'static_mean_width', 'aci_mean_width', 'verdict'}.
    """
    rec_s, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train, predict_kwargs={'adaptive': False},
        model_name=f"{model_name}-static")
    rec_a, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train,
        predict_kwargs={'adaptive': True, 'aci_gamma': aci_gamma},
        model_name=f"{model_name}-aci")
    cq_s, cq_a = coverage_quality(rec_s), coverage_quality(rec_a)
    mis_s, mis_a = _abs_miscoverage(cq_s), _abs_miscoverage(cq_a)
    w_s = float(np.mean(cq_s['mean_width_%'])) if not cq_s.empty else float('nan')
    w_a = float(np.mean(cq_a['mean_width_%'])) if not cq_a.empty else float('nan')
    if np.isnan(mis_s) or np.isnan(mis_a):
        verdict = 'insufficient data'
    elif mis_a < mis_s - 1e-6:
        verdict = (f"ACI improves coverage (|cov-0.95|: {mis_s:.3f} -> "
                   f"{mis_a:.3f}); mean width {w_s:.2f}% -> {w_a:.2f}%")
    elif mis_a > mis_s + 1e-6:
        verdict = (f"ACI worse here (|cov-0.95|: {mis_s:.3f} -> {mis_a:.3f}); "
                   "static preferred on this sample")
    else:
        verdict = "ACI ~= static on this sample (no regime shift to adapt to)"
    return {'static': cq_s, 'aci': cq_a,
            'static_miscoverage': mis_s, 'aci_miscoverage': mis_a,
            'static_mean_width': w_s, 'aci_mean_width': w_a,
            'verdict': verdict}


def compare_iv_adjust(df, predict_fn, interval, horizon, n_splits=10,
                      min_train=300, model_name='HAR-RV'):
    """
    A/B the HAR-RV cone with vs without the India-VIX forward-vol tilt.

    Both arms use the shipping ACI-adaptive cone; the only difference is whether
    the cone is scaled by the leak-free India-VIX implied/realized factor
    (:mod:`iv_data`). The hypothesis is that injecting *forward-looking* market
    vol pulls coverage toward the 95% target when implied and realized vol
    diverge (a regime the backtest's calm window barely exercises), at a modest
    width cost. This measurement decides whether ``iv_adjust`` ships on.

    Returns
    -------
    dict
        {'off': coverage_quality DataFrame, 'on': DataFrame,
         'off_miscoverage', 'on_miscoverage', 'off_mean_width',
         'on_mean_width', 'verdict'}.
    """
    rec_off, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train, predict_kwargs={'adaptive': True, 'iv_adjust': False},
        model_name=f"{model_name}-noIV")
    rec_on, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train, predict_kwargs={'adaptive': True, 'iv_adjust': True},
        model_name=f"{model_name}-IV")
    cq_off, cq_on = coverage_quality(rec_off), coverage_quality(rec_on)
    mis_off, mis_on = _abs_miscoverage(cq_off), _abs_miscoverage(cq_on)
    w_off = float(np.mean(cq_off['mean_width_%'])) if not cq_off.empty else float('nan')
    w_on = float(np.mean(cq_on['mean_width_%'])) if not cq_on.empty else float('nan')
    if np.isnan(mis_off) or np.isnan(mis_on):
        verdict = 'insufficient data'
    elif mis_on < mis_off - 1e-6:
        verdict = (f"IV tilt improves coverage (|cov-0.95|: {mis_off:.3f} -> "
                   f"{mis_on:.3f}); mean width {w_off:.2f}% -> {w_on:.2f}%")
    elif mis_on > mis_off + 1e-6:
        verdict = (f"IV tilt worse here (|cov-0.95|: {mis_off:.3f} -> {mis_on:.3f}); "
                   "no-IV preferred on this sample")
    else:
        verdict = "IV tilt ~= no-IV on this sample (implied ~ realized)"
    return {'off': cq_off, 'on': cq_on,
            'off_miscoverage': mis_off, 'on_miscoverage': mis_on,
            'off_mean_width': w_off, 'on_mean_width': w_on,
            'verdict': verdict}


def _mean_abs_tail_balance(cq):
    """Mean |lower_miss − upper_miss| across horizons (0 = perfectly balanced)."""
    if cq is None or cq.empty or 'tail_balance' not in cq.columns:
        return float('nan')
    return float(np.mean(np.abs(cq['tail_balance'])))


def compare_asymmetric(df, predict_fn, interval, horizon, n_splits=10,
                       min_train=300, model_name='HAR-RV'):
    """
    A/B the HAR-RV cone symmetric vs **asymmetric** (separate lower/upper edges).

    Both arms use the shipping ACI-adaptive cone; the only difference is whether
    the lower and upper multipliers are calibrated separately from the signed
    residuals. The point of an asymmetric cone is not headline coverage (both
    target 95%) but **tail-miss balance**: a symmetric band on a left-skewed
    return distribution misses more often on the downside, understating crash
    risk. So the decisive metric here is mean |lower_miss − upper_miss| — lower
    is better — alongside coverage and width.

    Returns
    -------
    dict
        {'sym': DataFrame, 'asym': DataFrame, 'sym_miscoverage',
         'asym_miscoverage', 'sym_tail_imbalance', 'asym_tail_imbalance',
         'sym_mean_width', 'asym_mean_width', 'verdict'}.
    """
    rec_s, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train, predict_kwargs={'adaptive': True, 'asymmetric': False},
        model_name=f"{model_name}-sym")
    rec_a, _ = collect_step_records(
        df, predict_fn, interval, horizon, n_splits=n_splits,
        min_train=min_train, predict_kwargs={'adaptive': True, 'asymmetric': True},
        model_name=f"{model_name}-asym")
    cq_s, cq_a = coverage_quality(rec_s), coverage_quality(rec_a)
    mis_s, mis_a = _abs_miscoverage(cq_s), _abs_miscoverage(cq_a)
    tb_s, tb_a = _mean_abs_tail_balance(cq_s), _mean_abs_tail_balance(cq_a)
    w_s = float(np.mean(cq_s['mean_width_%'])) if not cq_s.empty else float('nan')
    w_a = float(np.mean(cq_a['mean_width_%'])) if not cq_a.empty else float('nan')
    if np.isnan(tb_s) or np.isnan(tb_a):
        verdict = 'insufficient data'
    elif tb_a < tb_s - 1e-6:
        verdict = (f"asymmetric improves tail balance (|miss skew|: {tb_s:.3f} -> "
                   f"{tb_a:.3f}); coverage |cov-0.95| {mis_s:.3f} -> {mis_a:.3f}, "
                   f"width {w_s:.2f}% -> {w_a:.2f}%")
    elif tb_a > tb_s + 1e-6:
        verdict = (f"asymmetric worse on tail balance ({tb_s:.3f} -> {tb_a:.3f}); "
                   "symmetric preferred on this sample")
    else:
        verdict = "asymmetric ~= symmetric on this sample (residuals near-symmetric)"
    return {'sym': cq_s, 'asym': cq_a,
            'sym_miscoverage': mis_s, 'asym_miscoverage': mis_a,
            'sym_tail_imbalance': tb_s, 'asym_tail_imbalance': tb_a,
            'sym_mean_width': w_s, 'asym_mean_width': w_a,
            'verdict': verdict}
