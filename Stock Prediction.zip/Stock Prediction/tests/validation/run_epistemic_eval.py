"""
Does MC-dropout epistemic uncertainty measure what it claims? (Falsifiable test.)

The claim
---------
``epistemic.py`` reports MODEL uncertainty - how much a forecast would move
under a different plausible fit - by running stochastic forward passes with
dropout active (Klaas, *Machine Learning for Finance*, Ch. 4). The conformal
cone cannot express this: it measures how wrong the fitted model has BEEN and
takes the model itself as given.

Adding an uncertainty number is easy. Showing it means something is not, and
this project's standing rule is that an unvalidated feature does not ship on.
So this driver states a prediction that could fail.

The prediction
--------------
Klaas Ch. 8 gives a rule of thumb: *"You should have 10 times as many samples as
there are features."* Applied to this project's deep models on ~1000 daily bars:

    DL / CNN-LSTM / TCN / Transformer   9 inputs per timestep   ~101 : 1   OK
    N-BEATS (flatten=True)              540 flattened inputs      1.7 : 1   under-determined

If epistemic spread measures parameter uncertainty, **N-BEATS should be the most
uncertain model** - it is the one starved of data relative to its input
dimension. If the ranking comes out arbitrary, the number is noise and the
feature should be withdrawn rather than shipped with a plausible story attached.

What is compared
----------------
``epistemic_share`` - the MC-dropout spread divided by the model's own
conformal sigma. Both are in log-return units, so the ratio answers "what share
of this model's uncertainty is parameter uncertainty rather than residual
noise?" An earlier version normalised by the mean prediction instead; since the
target is a cumulative log return centred near zero, that denominator was an
arbitrary near-zero number and the check correctly failed.

Usage:
    python run_epistemic_eval.py [--ticker T] [--horizon H] [--passes N]
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import config as cfg
import epistemic as epi


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


TICKER = _arg("--ticker", "RELIANCE.NS", str)
HORIZON = _arg("--horizon", 5)
PASSES = _arg("--passes", 50)

# (display name, module, function, samples-per-input ratio from Klaas' rule)
MODELS = [
    ("DL (LSTM)", "DL_model", "run_DL_prediction", 101.1),
    ("CNN-LSTM", "CNN_LSTM_model", "run_cnn_lstm_prediction", 101.1),
    ("TCN", "TCN_model", "run_tcn_prediction", 101.1),
    ("N-BEATS", "NBeats_model", "run_nbeats_prediction", 1.7),
]


def _synthetic(n=1000, seed=0):
    """Offline fallback so the driver runs without a network."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2021-01-04", periods=n)
    px = 100 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    return pd.DataFrame({"datetime": dates, "open": px, "high": px * 1.01,
                         "low": px * 0.99, "close": px, "adj_close": px,
                         "volume": rng.integers(1e5, 5e5, n)})


def _load():
    try:
        from get_data import get_whole_stock_data
        df = get_whole_stock_data(TICKER, "1d")
        if isinstance(df, pd.DataFrame) and len(df) > 400:
            print(f"  fetched {len(df)} rows for {TICKER}")
            return df
    except Exception as exc:
        print(f"  fetch failed ({str(exc)[:60]}); using synthetic series")
    return _synthetic()


def main():
    print(f"=== MC-dropout epistemic uncertainty | horizon={HORIZON}d | "
          f"{PASSES} passes ===\n")

    if not cfg.USE_EPISTEMIC:
        print("NOTE: USE_EPISTEMIC is off in config.py (the shipped default).")
        print("      Enabling it for this run only, via the environment.\n")
        os.environ[cfg.ENV_PREFIX + "USE_EPISTEMIC"] = "1"
        import importlib
        importlib.reload(cfg)

    print("Loading data...")
    df = _load()

    rows = []
    for name, mod_name, fn_name, ratio in MODELS:
        print(f"\n-- {name} --")
        try:
            mod = __import__(mod_name)
            fn = getattr(mod, fn_name)
            out = fn(df.copy(), "1d", HORIZON)
            sp = getattr(out, "attrs", {}).get("epistemic")
        except Exception as exc:
            print(f"   failed: {str(exc)[:100]}")
            continue
        print("   " + epi.format_report(name, sp))
        if sp and sp.get("available"):
            rows.append({"model": name, "samples_per_input": ratio,
                         "mean_std": sp["mean_std"],
                         "epistemic_share": sp["epistemic_share"],
                         "n_passes": sp["n_passes"]})
        else:
            rows.append({"model": name, "samples_per_input": ratio,
                         "mean_std": float("nan"),
                         "epistemic_share": float("nan"), "n_passes": 0})

    res = pd.DataFrame(rows)
    print("\n" + "=" * 78)
    print(res.to_string(index=False))
    print("=" * 78)

    ok = res.dropna(subset=["epistemic_share"])
    if len(ok) < 2:
        print("\nToo few models reported a spread to test the ordering.")
        return

    print("\n-- The falsifiable check --")
    worst = ok.loc[ok["epistemic_share"].idxmax(), "model"]
    thinnest = ok.loc[ok["samples_per_input"].idxmin(), "model"]
    print(f"  Most uncertain model         : {worst}")
    print(f"  Least data per input (Klaas) : {thinnest}")

    # Rank correlation between data-per-parameter and uncertainty. Negative is
    # the predicted direction: less data -> more epistemic uncertainty.
    if len(ok) >= 3:
        rho = float(pd.Series(ok["samples_per_input"]).rank()
                    .corr(pd.Series(ok["epistemic_share"]).rank()))
        print(f"  Rank corr(samples/input, uncertainty) = {rho:+.2f} "
              f"(negative is predicted)")
    else:
        rho = float("nan")

    if worst == thinnest:
        print("\nPASS: the most data-starved model is the most uncertain, which "
              "is what parameter uncertainty should look like. This does not "
              "make the number calibrated - it is a relative signal, and it "
              "stays off by default until a coverage claim is measured.")
    else:
        print("\nFAIL: the ordering does not follow data-per-parameter. Treat "
              "the spread as noise and do not report it as model uncertainty. "
              "Adding an uncertainty number that does not track uncertainty "
              "would be worse than having none.")

    print("\nReminder: this is reported SEPARATELY from the conformal 95% band. "
          "Folding an unvalidated epistemic term into a cone whose coverage was "
          "actually measured would trade a real guarantee for a plausible one.")
    print("\nDone.")


if __name__ == "__main__":
    main()
