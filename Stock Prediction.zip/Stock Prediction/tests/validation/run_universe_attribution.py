"""
What is the cross-sectional signal actually made of?

The question
------------
Section 38 established a replicable rank IC of 0.033-0.037 at 200+ names. That
says a signal exists. It does not say **what it is**, and a statistical result
whose mechanism is unknown is one step away from an artefact nobody has found
yet.

Three readings are asked for here, in increasing order of how much they would
change the interpretation:

1. **Magnitude** -- exact TreeSHAP over the validation rows. Section 35 ran the
   same measurement on the 39-name universe and found attribution *near-uniform*
   (Herfindahl 1.3x uniform), which was recorded as the ninth negative result:
   no driver to look at. If the 400-name model is equally flat, the signal is
   diffuse; if it concentrates, there is something specific to name.

2. **Direction** -- Spearman correlation between each feature and the model's own
   score, P(buy) - P(short). SHAP magnitude is class-agnostic by construction
   (see ``explain.shap_values``), so it says which features matter but not which
   way the model leans on them. Direction is what makes a result economically
   readable rather than merely significant.

3. **Univariate IC** -- and this is the one that matters. For every raw feature,
   the Fama-MacBeth IC of that feature *alone* against forward excess return, on
   the same validation rows and the same dates as the model. If one feature
   already scores what the model scores, then **the model is not the finding** --
   the feature is, and the honest description of Section 38 changes from "a
   learned cross-sectional signal" to "a known factor, rediscovered".

The hypothesis this is built to test
------------------------------------
The Section 38 model is 95% short by count at a 5-day horizon. That shape is
what **short-term reversal** looks like -- a well-documented equity effect where
recent losers outperform over days-to-weeks. ``rank_rev_5`` is already in the
feature set. If the univariate IC of ``rank_rev_5`` lands near the model's
0.0396, the result is real *and* explained, which is a better outcome than an
unexplained edge: an unexplained edge cannot be reasoned about when it stops
working.

A null here is informative too. If no single feature approaches the model, the
signal is genuinely a combination, and the diffuse SHAP of Section 35 was a
small-sample artefact rather than a property of the problem.

Run::

    python tests/validation/run_universe_attribution.py
    python tests/validation/run_universe_attribution.py --n 200 --seed 107
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                       # noqa: E402
import cross_sectional_panel as csp         # noqa: E402
import cross_sectional_model as csm         # noqa: E402
import explain as ex                        # noqa: E402
import strategy_metrics as sm               # noqa: E402


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "400"))
HORIZON = int(_arg("--horizon", "5"))
SEED = int(_arg("--seed", "42"))


def main():
    print("=" * 78)
    print("WHAT IS THE CROSS-SECTIONAL SIGNAL MADE OF?")
    print("=" * 78)
    print(f"window {START} .. {END} | n={N} | horizon={HORIZON}d | seed={SEED}")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nbuilding panel ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, brep = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    cs, rep = csp.build_panel(tickers=brep["universe"],
                              fetch_fn=bc.bhav_fetcher(panel), verbose=False)
    feat = csp.add_ticker_features(cs)
    feat = csp.add_cross_sectional_ranks(feat)
    lab = csp.add_labels(feat, horizon=HORIZON)
    cols = csp.feature_columns(lab)
    s = csp.split_panel(lab, mode="combined", seed=SEED, embargo=HORIZON)
    print(f"  {rep['n_tickers']} names | train {s['n_train']:,} | "
          f"val {s['n_val']:,} rows / {len(s['val_tickers'])} unseen names")

    print("fitting ...")
    bundle = csm.fit_calibrated(s["train"], cols, seed=SEED, verbose=False)
    model = bundle["model"]
    val = s["val"]
    X = val[cols]

    # ---------------------------------------------------------------- 1. size
    print("\n" + "=" * 78)
    print("1. MAGNITUDE  --  exact TreeSHAP over the validation rows")
    print("=" * 78)
    if not ex.supports(model):
        print("  model is not a supported tree ensemble; skipping")
        imp = pd.DataFrame()
    else:
        imp = ex.importance(model, X, feature_names=cols)
        conc = ex.concentration(imp)
        print(ex.format_report(imp, conc))

    # ----------------------------------------------------------- 2. direction
    print("\n" + "=" * 78)
    print("2. DIRECTION  --  Spearman(feature, model score P(buy) - P(short))")
    print("=" * 78)
    P = csm.predict_proba(bundle, val) if hasattr(csm, "predict_proba") else None
    if P is None:
        P = bundle["model"].predict_proba(X)
    score = np.asarray(P)[:, 2] - np.asarray(P)[:, 0]
    dirs = {}
    for c in cols:
        v = pd.Series(val[c].values).rank()
        dirs[c] = float(np.corrcoef(v, pd.Series(score).rank())[0, 1])

    d = (pd.Series(dirs).dropna().sort_values(key=np.abs, ascending=False)
         .head(10))
    print(f"\n{'feature':26s}{'rho(feature, score)':>22s}   leans")
    for name, rho in d.items():
        lean = "buys high values" if rho > 0 else "shorts high values"
        print(f"{name[:25]:26s}{rho:+22.3f}   {lean}")
    print(f"\n  strongest |rho| is {d.abs().max():.3f}. These are weak by "
          "construction: the score is a\n  calibrated 3-class output, not a "
          "linear combination of features.")

    # --------------------------------------------------- 3. univariate factor
    print("\n" + "=" * 78)
    print("3. UNIVARIATE IC  --  each raw feature alone vs forward excess")
    print("=" * 78)
    print("   Same rows, same dates, same Fama-MacBeth machinery as the model.")
    dates = val["datetime"].values
    fwd = val["fwd_excess"].values.astype(float)
    rows = []
    for c in cols:
        x = val[c].values.astype(float)
        if not np.isfinite(x).any() or np.nanstd(x) == 0:
            continue
        ic_s = sm.ic_by_date(dates, x, fwd)
        fm = sm.fama_macbeth_ic(ic_s, lags=HORIZON - 1)
        rows.append({
            "feature": c,
            "uni_ic": fm["mean_ic"],
            "uni_t": fm["t_stat"],
            "hit": fm["hit_rate"],
            "shap_share": (float(imp.loc[imp["feature"] == c, "share"].iloc[0])
                           if len(imp) and (imp["feature"] == c).any() else np.nan),
            "dir_vs_score": dirs.get(c, np.nan),
        })
    tab = pd.DataFrame(rows)
    tab["abs_t"] = tab["uni_t"].abs()
    tab = tab.sort_values("abs_t", ascending=False).reset_index(drop=True)

    print(f"\n{'feature':26s}{'uni IC':>9s}{'uni t':>8s}{'hit':>7s}"
          f"{'SHAP%':>8s}{'dir':>8s}")
    for _, r in tab.head(15).iterrows():
        sh = "   n/a" if pd.isna(r["shap_share"]) else f"{100 * r['shap_share']:7.1f}"
        print(f"{r['feature'][:25]:26s}{r['uni_ic']:+9.4f}{r['uni_t']:+8.2f}"
              f"{r['hit']:7.3f}{sh}{r['dir_vs_score']:+8.2f}")

    # ------------------------------------------------------------- the verdict
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    # Compute the model's own IC on THESE validation rows rather than quoting
    # the published figure. A hardcoded constant silently becomes the wrong
    # benchmark the moment anyone passes --seed or --n.
    res = csm.evaluate(bundle, val, horizon=HORIZON)
    MODEL_IC = abs(float(res.get("rank_ic_fm") or np.nan))
    best = tab.iloc[0]
    print(f"  model rank IC (this run)        : +{MODEL_IC:.4f} "
          f"(t={res.get('rank_ic_t')})")
    print(f"  best single-feature IC          : {best['uni_ic']:+.4f} "
          f"({best['feature']}, t={best['uni_t']:+.2f})")
    ratio = abs(best["uni_ic"]) / MODEL_IC if MODEL_IC else np.nan
    print(f"  ratio                           : {ratio:.2f}x")

    rev = tab[tab["feature"].str.contains("rev", case=False)]
    if len(rev):
        r = rev.iloc[0]
        print(f"\n  short-term reversal feature     : {r['feature']}")
        print(f"    univariate IC                 : {r['uni_ic']:+.4f} "
              f"(t={r['uni_t']:+.2f}, hit {r['hit']:.3f})")
        print(f"    direction vs model score      : {r['dir_vs_score']:+.2f} "
              f"({'model shorts recent winners' if r['dir_vs_score'] < 0 else 'model buys recent winners'})")

    print()
    if ratio >= 0.80:
        print("  => The signal is essentially ONE FEATURE. The model is not the")
        print("     finding; the factor is. Section 38 should be read as a known")
        print("     effect rediscovered, not as learned cross-sectional skill.")
    elif ratio >= 0.50:
        print("  => One feature carries much of it, with the model adding the")
        print("     rest. Report BOTH numbers; a single-factor baseline is the")
        print("     benchmark any model here has to beat.")
    else:
        print("  => No single feature approaches the model, so the signal is")
        print("     genuinely a combination. That also means Section 35's")
        print("     near-uniform attribution was a property of the small")
        print("     universe, not of the problem.")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       f"universe_attribution_n{N}.csv")
    tab.to_csv(out, index=False)
    print(f"\nsaved: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
