"""
Does class weighting explain the cross-sectional classifier's abstention?

The claim under test
--------------------
``run_cross_sectional_clf.py`` on 39 NSE names produced a striking result: the
model predicted "do nothing" for **6,857 of 6,887** validation rows (99.6%).
That was written up as *emergent abstention* — a model volunteering that it had
no view on names it had never seen, arriving at this project's central thesis
from a new direction.

There is a duller explanation. The label is imbalanced by construction (the
deadband makes neutral the largest class, ~42%), and the classifier is fitted
with ``class_weight=None``. An unweighted multiclass objective has a standing
incentive to drift toward the majority class, and "drifted to the majority" and
"concluded it had no view" produce *identical* accuracy columns. Only the
prediction mix separates them, and only against a counterfactual.

So this driver runs the same panel, the same split, the same seed, and the same
hyperparameters through two arms:

* **A — unweighted** (``class_weight=None``): the shipped configuration, and the
  one every published figure in README section 29 was measured under.
* **B — balanced** (``class_weight='balanced'``): weights inversely proportional
  to class frequency, which removes the majority-class incentive entirely.

How to read the outcome
-----------------------
Two of the three possible results change what the documentation should say:

1. **Abstention collapses under weighting AND skill stays null.** The 99.6% was
   an artefact of the objective, not a finding. The "emergent abstention" claim
   must be withdrawn — the model was not volunteering anything, it was taking
   the cheapest route to a good log-loss.
2. **Abstention survives weighting.** The claim is *stronger* than before: the
   model declines to call even when the objective actively pays it to call.
3. **Abstention collapses and skill appears** (rank IC t > 2). Unlikely, and it
   would need confirming on another split and seed before being believed - a
   single arm crossing a threshold is what data-snooping looks like.

Note what this does NOT test: whether weighting is *better*. Balanced weighting
distorts the probabilities the isotonic layer then has to undo, so a worse ECE
in arm B is expected and is not an argument either way. The question here is
narrow and diagnostic: does the abstention depend on the objective?

Usage:
    python run_class_weight_ab.py [--n N] [--horizon H] [--mode M] [--seeds S]
        --n N       : universe size (default: the full DEFAULT_UNIVERSE)
        --horizon H : label horizon in trading days (default 5)
        --mode M    : 'combined' (default) | 'asset' | 'time'
        --seeds S   : comma-separated seeds (default 42). More than one guards
                      against reading a single seed's noise as an effect.
        --quick     : 12 tickers, for a fast smoke run
"""

# Make project-root modules importable when run from tests/validation/.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import warnings

import numpy as np
import pandas as pd

import cross_sectional_panel as csp
import cross_sectional_model as csm

warnings.filterwarnings("ignore")

ARMS = [("unweighted (shipped)", None), ("balanced", "balanced")]


def _arg(flag, default, cast=int):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


QUICK = "--quick" in sys.argv
N = _arg("--n", 12 if QUICK else len(csp.DEFAULT_UNIVERSE))
HORIZON = _arg("--horizon", 5)
MODE = _arg("--mode", "combined", str)
SEEDS = [int(x) for x in _arg("--seeds", "42", str).split(",") if x.strip()]


def _run_arm(split, cols, weight, seed):
    """Fit and evaluate one arm. Everything but ``class_weight`` is held fixed."""
    bundle = csm.fit_calibrated(split["train"], cols, seed=seed, verbose=False,
                                class_weight=weight)
    res = csm.evaluate(bundle, split["val"], verbose=False, horizon=HORIZON)
    res["ece_raw"] = bundle["ece_raw"]
    res["ece_calibrated"] = bundle["ece_calibrated"]
    return res


def main():
    universe = csp.DEFAULT_UNIVERSE[:N]
    print(f"=== class_weight A/B | {len(universe)} NSE names | horizon={HORIZON}d "
          f"| split={MODE} | seeds={SEEDS} ===\n")

    print("Building panel (fetched once; both arms see identical data)...")
    panel, rep = csp.build_panel(universe, verbose=False)
    if panel.empty:
        print("No data fetched - cannot continue.")
        return
    print(f"  {rep['n_rows']:,} rows x {rep['n_tickers']} tickers "
          f"({rep['start']} -> {rep['end']})")

    feat = csp.add_cross_sectional_ranks(csp.add_ticker_features(panel))
    lab = csp.add_labels(feat, horizon=HORIZON)
    cols = csp.feature_columns(lab)
    dist = lab["label"].value_counts(normalize=True).sort_index()
    print(f"  {len(lab):,} labelled rows, {len(cols)} features")
    print(f"  class balance: short {dist.get(-1, 0):.3f} / "
          f"nothing {dist.get(0, 0):.3f} / buy {dist.get(1, 0):.3f}")
    print(f"  -> an unweighted objective can score "
          f"{dist.get(0, 0):.1%} accuracy by always predicting neutral.\n")

    rows = []
    for seed in SEEDS:
        # The split is seeded too, so both arms of a given seed share it exactly.
        split = csp.split_panel(lab, mode=MODE, seed=seed, embargo=HORIZON)
        print(f"seed {seed}: train {split['n_train']:,} / val {split['n_val']:,} "
              f"({len(split['val_tickers'])} unseen tickers)")
        for name, weight in ARMS:
            res = _run_arm(split, cols, weight, seed)
            rows.append({
                "seed": seed, "arm": name,
                "abstain": res.get("abstain_rate"),
                "n_long": res.get("n_long"), "n_short": res.get("n_short"),
                "macro_f1": res.get("macro_f1"),
                "accuracy": res.get("accuracy"),
                "majority": res.get("majority_baseline"),
                "ece": res.get("ece"),
                "rank_ic_fm": res.get("rank_ic_fm"), "ic_t": res.get("rank_ic_t"),
                "ic_t_pooled": res.get("rank_ic_t_pooled"),
                "n_dates": res.get("ic_n_dates"),
                "spread": res.get("long_short_spread"),
            })
            print(f"    {name:<22} abstain {res.get('abstain_rate'):.4f} | "
                  f"L/S {res.get('n_long')}/{res.get('n_short')} | "
                  f"macroF1 {res.get('macro_f1'):.3f} | "
                  f"ECE {res.get('ece'):.4f} | "
                  f"rankIC {res.get('rank_ic_fm'):+.4f} "
                  f"(FM t={res.get('rank_ic_t')} / {res.get('ic_n_dates')} dates"
                  f"; pooled t={res.get('rank_ic_t_pooled')})")

    df = pd.DataFrame(rows)
    print("\n" + "=" * 78)
    print(df.to_string(index=False))
    print("=" * 78)

    piv = df.groupby("arm", sort=False).mean(numeric_only=True)
    a, b = piv.loc[ARMS[0][0]], piv.loc[ARMS[1][0]]
    d_abstain = b["abstain"] - a["abstain"]
    d_f1 = b["macro_f1"] - a["macro_f1"]
    d_ic_t = b["ic_t"] - a["ic_t"]

    print("\n-- Verdict --")
    print(f"abstention  {a['abstain']:.4f} -> {b['abstain']:.4f} "
          f"({d_abstain:+.4f})")
    print(f"macro F1    {a['macro_f1']:.4f} -> {b['macro_f1']:.4f} ({d_f1:+.4f})")
    print(f"rank IC t   {a['ic_t']:+.2f} -> {b['ic_t']:+.2f} ({d_ic_t:+.2f})")

    skill = abs(b["ic_t"]) > 2 or abs(a["ic_t"]) > 2
    if d_abstain < -0.25 and not skill:
        print("\nCONCLUSION: the abstention is largely an ARTEFACT of the "
              "unweighted objective. It collapses once the majority-class "
              "incentive is removed, and no skill appears in its place. The "
              "'emergent abstention' reading is not supported and the write-up "
              "must be corrected.")
    elif d_abstain >= -0.10 and not skill:
        print("\nCONCLUSION: the abstention SURVIVES balanced weighting. The "
              "model declines to call even when the objective pays it to call, "
              "which makes the original reading stronger, not weaker.")
    elif skill:
        print("\nCONCLUSION: an arm shows |t| > 2 on rank IC. Treat as "
              "PROVISIONAL: re-run on other seeds, --mode asset and --mode "
              "time, and a larger universe. One arm crossing a threshold is "
              "what data-snooping looks like.")
    else:
        print("\nCONCLUSION: partial shift. The abstention depends on the "
              "objective but does not vanish; report both numbers rather than "
              "either claim.")
    print("\nNote: a worse ECE in the balanced arm is EXPECTED (weighting "
          "distorts the probabilities the isotonic layer must then undo) and is "
          "not evidence for or against either reading.")
    print("\nDone.")


if __name__ == "__main__":
    main()
