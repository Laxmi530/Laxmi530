"""
Does open interest predict anything? (Sharma & Mehta Ch. 3)

Why this one is worth running when twelve others were not
---------------------------------------------------------
Every negative result in this project so far was measured on a **transformation
of OHLCV**: more models, more architectures, fractional differencing, range
volatility, cross-sectional ranks. Fundamentals were the single attempt at a
second data axis and they died on coverage (Section 32), not on evidence.

**Open interest is the first genuinely orthogonal, obtainable data source this
project has found.** It measures *positioning* -- how many contracts are open --
and it is not derived from price at all. That makes it a different question from
"does another function of price help", which has now been answered twelve times.

The claim under test
--------------------
Ch. 3 (Bakshi, "Analyzing Open Interest") gives a 2x2 interpretation table with
no backtest, no statistics and no validation anywhere in the chapter:

===========  =========  ==================================================
Price        OI         The chapter's claim
===========  =========  ==================================================
Rising       Rising     Strongly bullish; trend continues
Rising       Falling    Short-covering rally; downtrend or sideways next
Falling      Rising     Aggressive short-selling; bearish trend continues
Falling      Falling    Forced liquidation; upward move may start
===========  =========  ==================================================

Read as a predicted sign for the next move that table is exactly

    signal = sign(delta price) * sign(delta OI)

-- +1 when the two agree, -1 when they diverge. The whole chapter reduces to one
product of two signs, which is convenient: it makes the claim a single testable
signal rather than four separate rules.

Construction
------------
* **Delta OI** from the **near-month** stock future (``nselib`` returns three
  expiries per date; the near contract is the liquid one).
* **Delta price** and the **forward return** from the *underlying*, taken from
  the survivorship-free, corporate-action-adjusted :mod:`bhavcopy` panel. Using
  the futures close for returns would mix in roll effects every time the near
  contract changes; the underlying has no such artefact.
* Evaluated two ways: **mean forward return per quadrant** (the chapter's own
  framing) and the **cross-sectional Fama-MacBeth IC** of the signal (this
  project's standard, so the number is comparable with Sections 30 and 38).

Honest prior
------------
Section 39 established that only ~38% of a liquid NSE universe is F&O-eligible,
so breadth -- the thing that made the Section 38 signal detectable at all -- is
cut by nearly two-thirds. And the table is technical-analysis folklore that the
book itself never tests. A null is the expected outcome; it would be a *better*
null than the previous twelve, because for the first time it rules out an
orthogonal data source rather than another feature of the same one.

Run::

    python tests/validation/run_open_interest.py
    python tests/validation/run_open_interest.py --n 30 --start 01-01-2023
"""

import os
import sys
import time
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                 # noqa: E402
import strategy_metrics as sm         # noqa: E402

OI_CACHE = os.environ.get("STOCKAPP_OI_CACHE", ".oi_cache")


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


START = _arg("--start", "01-01-2023")      # dd-mm-yyyy for nselib
END = _arg("--end", "31-12-2024")
N = int(_arg("--n", "50"))
HORIZONS = [int(x) for x in _arg("--horizons", "1,5").split(",")]


def fetch_oi(symbol, start, end, cache_dir=OI_CACHE):
    """Near-month futures OI per date for one symbol, cached to disk."""
    os.makedirs(cache_dir, exist_ok=True)
    p = os.path.join(cache_dir, f"oi_{symbol}_{start}_{end}.csv.gz")
    if os.path.exists(p):
        d = pd.read_csv(p, parse_dates=["datetime"])
        return d if len(d) else None

    from nselib import derivatives as dv
    try:
        raw = dv.future_price_volume_data(symbol=symbol, instrument="FUTSTK",
                                          from_date=start, to_date=end)
    except Exception:
        pd.DataFrame(columns=["datetime", "oi", "fut_close"]).to_csv(p, index=False)
        return None
    if raw is None or not len(raw):
        pd.DataFrame(columns=["datetime", "oi", "fut_close"]).to_csv(p, index=False)
        return None

    d = raw.copy()
    d.columns = [str(c).strip() for c in d.columns]
    d["datetime"] = pd.to_datetime(d["TIMESTAMP"], format="%d-%b-%Y", errors="coerce")
    d["expiry"] = pd.to_datetime(d["EXPIRY_DT"], format="%d-%b-%Y", errors="coerce")
    for c in ("OPEN_INT", "CLOSING_PRICE"):
        d[c] = pd.to_numeric(d[c].astype(str).str.replace(",", "", regex=False),
                             errors="coerce")
    d = d.dropna(subset=["datetime", "expiry", "OPEN_INT"])
    # Near month = the earliest expiry still in the future on that date. nselib
    # returns three contracts per day and only the near one is liquid.
    d = d[d["expiry"] >= d["datetime"]]
    d = d.sort_values(["datetime", "expiry"]).drop_duplicates("datetime", keep="first")
    out = d[["datetime", "OPEN_INT", "CLOSING_PRICE"]].rename(
        columns={"OPEN_INT": "oi", "CLOSING_PRICE": "fut_close"})
    out = out.sort_values("datetime").reset_index(drop=True)
    out.to_csv(p, index=False)
    time.sleep(0.3)
    return out if len(out) else None


def main():
    print("=" * 78)
    print("DOES OPEN INTEREST PREDICT ANYTHING?  (Sharma & Mehta Ch. 3)")
    print("=" * 78)
    print(f"{START} .. {END} | up to {N} F&O names | horizons {HORIZONS}d")
    print("\nThe chapter's 2x2 table reduces to  signal = sign(dPrice) * sign(dOI)")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    # ------------------------------------------------- universe: F&O + liquid
    iso_start = "-".join(reversed(START.split("-")))
    iso_end = "-".join(reversed(END.split("-")))
    from nselib import capital_market as cm
    fno = set(cm.fno_equity_list()["symbol"].astype(str).str.strip())
    _, screen = bc.liquidity_screen(
        bc.load_cache(pd.Timestamp(iso_start) - pd.Timedelta(days=365),
                      iso_start),
        iso_start, lookback_days=365, n=10 ** 6, min_turnover=5e7, min_days=150)
    liquid = [s for s in screen["symbol"] if s in fno][:N]
    print(f"\nF&O list: {len(fno)} | liquid & F&O: {len(liquid)} (using {len(liquid)})")

    # ------------------------------------------------------------- underlying
    print("loading adjusted underlying panel ...")
    acts = bc.corporate_actions(pd.Timestamp(iso_start) - pd.Timedelta(days=400),
                                iso_end, chunk_months=360)
    px = bc.adjust_prices(bc.load_cache(iso_start, iso_end, symbols=liquid), acts)

    # --------------------------------------------------------------- OI fetch
    print(f"fetching near-month futures OI (cached; first run ~{len(liquid) * 21 // 60} min) ...")
    frames, missing = [], []
    for i, s in enumerate(liquid, 1):
        o = fetch_oi(s, START, END)
        if o is None or len(o) < 100:
            missing.append(s)
            continue
        u = px[px["symbol"] == s][["datetime", "adj_close"]].copy()
        m = u.merge(o, on="datetime", how="inner").sort_values("datetime")
        if len(m) < 100:
            missing.append(s)
            continue
        m["symbol"] = s
        frames.append(m)
        if i % 10 == 0:
            print(f"  {i}/{len(liquid)} ({len(frames)} usable)")
    if not frames:
        print("no usable names")
        return 1
    panel = pd.concat(frames, ignore_index=True)
    print(f"  usable names: {panel['symbol'].nunique()} | rows {len(panel):,} | "
          f"dropped {len(missing)}")

    # ---------------------------------------------------------- build signal
    panel = panel.sort_values(["symbol", "datetime"]).reset_index(drop=True)
    g = panel.groupby("symbol", sort=False)
    panel["d_price"] = g["adj_close"].transform(lambda s: np.log(s / s.shift(1)))
    panel["d_oi"] = g["oi"].transform(lambda s: s.diff())
    panel["signal"] = np.sign(panel["d_price"]) * np.sign(panel["d_oi"])
    for h in HORIZONS:
        panel[f"fwd{h}"] = g["adj_close"].transform(
            lambda s, h=h: np.log(s.shift(-h) / s))
        # THE TRADEABLE VERSION. NSE publishes the F&O bhavcopy -- and therefore
        # open interest for date t -- AFTER the close of t. You cannot trade at
        # the close of t on a number that does not exist until afterwards. The
        # earliest possible entry is the close of t+1, so the honest forward
        # return runs from t+1, not t.
        #
        # This is not a technicality. The naive alignment scores IC +0.0198 at
        # FM t = +2.88 -- "significant" -- and the one-day lag takes it to
        # -0.0018 at t = -0.27. The entire effect was publication timing.
        panel[f"fwd{h}_lag"] = g[f"fwd{h}"].transform(lambda s: s.shift(-1))

    # ----------------------------------------------- 1. the chapter's framing
    for h in HORIZONS:
        d = panel.dropna(subset=["d_price", "d_oi", f"fwd{h}"])
        d = d[(d["d_price"] != 0) & (d["d_oi"] != 0)]
        print("\n" + "=" * 78)
        print(f"1. QUADRANT MEANS  ({h}-day forward return, market-relative)")
        print("=" * 78)
        # Market-relative, so a general drift cannot masquerade as a signal.
        d = d.copy()
        d["excess"] = d[f"fwd{h}"] - d.groupby("datetime")[f"fwd{h}"].transform("mean")
        print(f"{'price':>8s}{'OI':>8s}{'chapter says':>16s}{'n':>9s}"
              f"{'mean excess':>14s}{'hit rate':>10s}")
        for sp in (1, -1):
            for so in (1, -1):
                c = d[(np.sign(d["d_price"]) == sp) & (np.sign(d["d_oi"]) == so)]
                if not len(c):
                    continue
                says = "up" if sp * so > 0 else "down"
                hit = float((np.sign(c["excess"]) == sp * so).mean())
                print(f"{'up' if sp > 0 else 'down':>8s}"
                      f"{'up' if so > 0 else 'down':>8s}{says:>16s}"
                      f"{len(c):9d}{c['excess'].mean():+14.5f}{hit:10.3f}")

        # --------------------------------------------- 2. this project's test
        print("\n" + "=" * 78)
        print(f"2. FAMA-MACBETH IC of the signal  ({h}-day forward excess)")
        print("=" * 78)
        for label, col in ((f"naive  (trade at close t -- NOT tradeable)", f"fwd{h}"),
                           (f"HONEST (trade at close t+1)", f"fwd{h}_lag")):
            dd = panel.dropna(subset=["signal", col])
            dd = dd[dd["signal"] != 0].copy()
            dd["ex"] = dd[col] - dd.groupby("datetime")[col].transform("mean")
            ic = sm.ic_by_date(dd["datetime"].values,
                               dd["signal"].values.astype(float),
                               dd["ex"].values.astype(float))
            fm = sm.fama_macbeth_ic(ic, lags=max(h - 1, 0))
            verdict = ("SIGNIFICANT" if abs(fm["t_stat"]) >= 2.0
                       else "not significant")
            print(f"  {label:42s} IC {fm['mean_ic']:+.4f}  "
                  f"t {fm['t_stat']:+.2f}  ({fm['n_dates']} dates)  {verdict}")
        print("  The gap between those two lines is the publication lag, not a")
        print("  modelling choice. Only the second one is a result.")

    out = os.path.join(_HERE, "open_interest.csv")
    panel.to_csv(out, index=False)
    print(f"\nsaved: {out}")

    print("\n" + "=" * 78)
    print("READING THIS")
    print("=" * 78)
    print("The chapter predicts a POSITIVE IC: the signal is +1 exactly when it")
    print("says the trend continues. An IC near zero means the 2x2 table carries")
    print("no forward information. A NEGATIVE IC would mean it is backwards --")
    print("which would still be information, and worth more than nothing.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
