"""
Tests for :mod:`event_backtest` -- Hilpisch, *AI in Finance*, Ch. 11.

The three groups that matter are the three ways a stop-loss backtest lies, and
each has a test whose failure mode is *optimism* rather than a crash:

* **Gaps.** A bar that opens through the stop fills at the open, not the stop.
  ``test_a_gap_through_the_stop_fills_at_the_open`` pins the loss at the real
  one. Without it the estimator quietly caps every tail loss at the stop level,
  which is exactly the regime the strategy is being tested for.
* **Intrabar ordering.** When stop and target both trigger in one bar, daily
  data cannot say which came first; the adverse one is assumed.
* **Trailing ratchets.** The trail on bar *i* is computed from bars before *i*,
  so a ratchet and a trigger cannot both be credited to one bar's extremes.

Plus symmetry: every rule must behave identically for a short with the signs
reversed, since §39's book is dollar-neutral and half of it is short.
"""

import numpy as np
import pandas as pd
import pytest

import event_backtest as eb


def _bars(rows):
    """rows of (open, high, low, close)."""
    return pd.DataFrame(rows, columns=list(eb.BAR_COLUMNS))


# ==========================================
# 1. No rules: the event answer is the vectorized one
# ==========================================
def test_without_rules_the_position_runs_to_the_horizon():
    b = _bars([(100, 104, 96, 102), (102, 108, 99, 107), (107, 110, 105, 109)])
    r = eb.exit_position(100.0, b)
    assert r["reason"] == "horizon"
    assert r["exit_price"] == 109.0
    assert r["ret"] == pytest.approx(0.09)
    assert r["bars_held"] == 3


def test_excursions_find_the_worst_and_best_before_the_horizon():
    b = _bars([(100, 104, 96, 102), (102, 108, 88, 107), (107, 115, 105, 109)])
    e = eb.excursions(100.0, b, side=1)
    assert e["mae"] == pytest.approx(-0.12)        # low of 88
    assert e["mfe"] == pytest.approx(0.15)         # high of 115
    assert e["horizon_return"] == pytest.approx(0.09)


def test_a_recovering_position_hides_its_drawdown_from_a_vectorized_backtest():
    """The whole reason this module exists, in one assertion."""
    b = _bars([(100, 101, 99, 100), (100, 100, 88, 99), (99, 101, 98, 100)])
    c = eb.compare(100.0, b, side=1)
    assert c["vectorized"] == pytest.approx(0.0)   # flat, start to finish
    assert c["mae"] == pytest.approx(-0.12)        # after being 12% underwater


# ==========================================
# 2. Gaps -- a stop is not a guaranteed fill
# ==========================================
def test_a_stop_inside_the_bar_fills_at_the_stop():
    b = _bars([(100, 101, 94, 96)])
    r = eb.exit_position(100.0, b, stop_loss=0.05)
    assert r["reason"] == "stop_loss"
    assert r["exit_price"] == pytest.approx(95.0)
    assert r["ret"] == pytest.approx(-0.05)


def test_a_gap_through_the_stop_fills_at_the_open():
    # Opens at 88 with a 5% stop at 95: the 95 print never happened.
    b = _bars([(88, 92, 85, 90)])
    r = eb.exit_position(100.0, b, stop_loss=0.05)
    assert r["reason"] == "stop_loss"
    assert r["exit_price"] == pytest.approx(88.0)
    assert r["ret"] == pytest.approx(-0.12)


def test_disabling_gap_fill_is_the_optimistic_version():
    b = _bars([(88, 92, 85, 90)])
    honest = eb.exit_position(100.0, b, stop_loss=0.05, gap_fill=True)
    flattering = eb.exit_position(100.0, b, stop_loss=0.05, gap_fill=False)
    assert flattering["ret"] > honest["ret"]
    assert flattering["ret"] == pytest.approx(-0.05)


def test_a_gap_through_the_target_also_fills_at_the_open():
    b = _bars([(112, 115, 110, 114)])
    r = eb.exit_position(100.0, b, take_profit=0.05)
    assert r["reason"] == "take_profit"
    assert r["exit_price"] == pytest.approx(112.0)


# ==========================================
# 3. Intrabar ordering
# ==========================================
def test_when_both_trigger_in_one_bar_the_stop_is_assumed():
    b = _bars([(100, 106, 94, 100)])
    adverse = eb.exit_position(100.0, b, stop_loss=0.05, take_profit=0.05)
    assert adverse["reason"] == "stop_loss"
    assert adverse["ret"] == pytest.approx(-0.05)
    rosy = eb.exit_position(100.0, b, stop_loss=0.05, take_profit=0.05,
                            adverse_first=False)
    assert rosy["reason"] == "take_profit"
    assert rosy["ret"] > adverse["ret"]


def test_the_earlier_bar_wins_over_a_later_one():
    b = _bars([(100, 101, 94, 96), (96, 120, 95, 118)])
    r = eb.exit_position(100.0, b, stop_loss=0.05, take_profit=0.05)
    assert r["exit_bar"] == 0 and r["reason"] == "stop_loss"


# ==========================================
# 4. Trailing stops
# ==========================================
def test_a_trailing_stop_ratchets_with_the_favourable_extreme():
    # Runs to 120, then falls. A 10% trail from 120 exits near 108.
    b = _bars([(100, 110, 99, 109), (109, 120, 108, 119), (119, 119, 100, 101)])
    r = eb.exit_position(100.0, b, trailing_stop=0.10)
    assert r["reason"] == "trailing_stop"
    assert r["exit_bar"] == 2
    assert r["exit_price"] == pytest.approx(108.0)


def test_the_trail_cannot_ratchet_and_fire_on_the_same_bar():
    """
    Bar 0 runs to 130 and closes at 95. Ratcheting on that bar's own high and
    then testing its own low assumes the high came first -- unknowable from a
    daily bar, and worth ~26% of fictional profit here.
    """
    b = _bars([(100, 130, 95, 96)])
    r = eb.exit_position(100.0, b, trailing_stop=0.10)
    # The trail still sits at 90 (from entry), so this bar does not fire at 117.
    assert r["reason"] == "horizon"
    assert r["exit_price"] == pytest.approx(96.0)


def test_the_tighter_of_stop_and_trail_applies():
    b = _bars([(100, 103, 99, 102), (102, 104, 97, 98)])
    # Trail 2% from 104 -> 101.9, which is tighter than a fixed 5% stop at 95.
    r = eb.exit_position(100.0, b, stop_loss=0.05, trailing_stop=0.02)
    assert r["reason"] == "trailing_stop"
    assert r["exit_price"] == pytest.approx(103.0 * 0.98)


# ==========================================
# 5. Shorts -- half of a dollar-neutral book
# ==========================================
def test_a_short_stops_out_on_the_way_up():
    b = _bars([(100, 106, 99, 105)])
    r = eb.exit_position(100.0, b, side=-1, stop_loss=0.05)
    assert r["reason"] == "stop_loss"
    assert r["exit_price"] == pytest.approx(105.0)
    assert r["ret"] == pytest.approx(-0.05)


def test_a_short_profits_when_the_price_falls():
    b = _bars([(100, 101, 90, 92)])
    r = eb.exit_position(100.0, b, side=-1, take_profit=0.05)
    assert r["reason"] == "take_profit"
    assert r["ret"] == pytest.approx(0.05)


def test_short_excursions_mirror_long_ones():
    b = _bars([(100, 112, 96, 102)])
    long_e = eb.excursions(100.0, b, side=1)
    short_e = eb.excursions(100.0, b, side=-1)
    assert short_e["mae"] == pytest.approx(-0.12)   # the high hurts a short
    assert long_e["mae"] == pytest.approx(-0.04)
    assert short_e["mfe"] == pytest.approx(0.04)


def test_a_short_gap_through_its_stop_fills_at_the_open():
    b = _bars([(115, 118, 112, 117)])
    r = eb.exit_position(100.0, b, side=-1, stop_loss=0.05)
    assert r["exit_price"] == pytest.approx(115.0)
    assert r["ret"] == pytest.approx(-0.15)


# ==========================================
# 6. Adjustment, degenerate input, aggregation
# ==========================================
def test_adjust_ohlc_puts_every_leg_on_the_adjusted_basis():
    # A 1:10 split mid-series: raw OHLC must be rescaled with the close.
    df = pd.DataFrame({"open": [1000.0, 101.0], "high": [1010.0, 103.0],
                       "low": [990.0, 99.0], "close": [1000.0, 100.0],
                       "adj_close": [100.0, 100.0]})
    out = eb.adjust_ohlc(df)
    assert out["close"].tolist() == pytest.approx([100.0, 100.0])
    assert out["high"].tolist() == pytest.approx([101.0, 103.0])
    # Within-bar ratios are untouched, as range_volatility also relies on.
    assert (out["high"] / out["low"]).tolist() == pytest.approx(
        (df["high"] / df["low"]).tolist())


@pytest.mark.parametrize("entry", [0.0, -5.0, np.nan, None])
def test_a_bad_entry_price_returns_nan_not_an_exception(entry):
    b = _bars([(100, 101, 99, 100)])
    assert np.isnan(eb.exit_position(entry, b)["ret"])
    assert np.isnan(eb.excursions(entry, b)["mae"])


def test_no_bars_is_handled():
    empty = _bars([])
    assert eb.exit_position(100.0, empty)["bars_held"] == 0
    assert eb.summarize([])["n"] == 0
    assert eb.format_report({"n": 0}) == "no positions"


def test_summarize_reports_the_exit_mix_and_the_gap():
    rows = [eb.compare(100.0, _bars([(100, 101, 94, 95)]), stop_loss=0.05),
            eb.compare(100.0, _bars([(100, 108, 99, 107)]), stop_loss=0.05),
            eb.compare(100.0, _bars([(100, 101, 99, 100)]), stop_loss=0.05)]
    s = eb.summarize(rows)
    assert s["n"] == 3
    assert s["share_stop_loss"] == pytest.approx(1 / 3)
    assert s["share_horizon"] == pytest.approx(2 / 3)
    assert s["difference_mean"] == pytest.approx(
        s["event_mean"] - s["vectorized_mean"])
    assert "exit mix" in eb.format_report(s)


def test_a_stop_can_only_cap_a_loss_it_actually_reaches():
    # A position that never touches the stop must be identical either way.
    b = _bars([(100, 103, 98, 101)])
    assert eb.exit_position(100.0, b, stop_loss=0.05)["ret"] == pytest.approx(
        eb.exit_position(100.0, b)["ret"])
