"""
Tests for feature_drift.py and explain.py.

Both modules exist to answer a question the project could not answer before, and
both have a characteristic way of going wrong that a naive test would miss:

* **feature_drift** can fire on nothing. PSI is biased upward on small samples,
  so a fixed threshold flags identical distributions. The load-bearing test is
  that two samples from the SAME distribution are NOT flagged, at a sample size
  where the conventional bands would call it significant drift.
* **explain** can produce confident nonsense. If the library's contribution
  layout is parsed wrongly, the values still look like attributions. The
  load-bearing tests are that known drivers are recovered from a synthetic
  model, and that the additivity identity holds exactly.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import feature_drift as fd
import explain as ex


def _lgb_or_skip():
    try:
        import lightgbm  # noqa: F401
    except Exception:
        pytest.skip("LightGBM not available")


# ---------------------------------------------------------------------------
# feature_drift — not firing on noise is the whole point
# ---------------------------------------------------------------------------

def test_identical_distributions_are_not_flagged():
    rng = np.random.default_rng(0)
    n = 500
    ref = pd.DataFrame({"a": rng.normal(size=n), "b": rng.normal(size=n)})
    cur = pd.DataFrame({"a": rng.normal(size=n), "b": rng.normal(size=n)})
    t = fd.drift_table(ref, cur, n_perm=200)
    assert (t["verdict"] == "stable").all(), t.to_string()


def test_the_conventional_psi_bands_misfire_where_the_permutation_test_does_not():
    """
    The justification for the whole design. At n = 60, two samples from the
    SAME distribution score a PSI the folklore calls 'significant' - while the
    permutation null, measured at that sample size, correctly says nothing
    happened.
    """
    rng = np.random.default_rng(1)
    a, b = rng.normal(size=60), rng.normal(size=60)
    value = fd.psi(a, b)
    null = fd.psi_null(a, b, n_perm=300)
    assert value > fd.PSI_MODERATE, (
        f"fixture failed to reproduce the small-sample inflation: {value:.3f}")
    assert value < np.quantile(null, 0.95), (
        "the permutation null should not be exceeded by pure noise")


def test_a_real_shift_is_detected():
    rng = np.random.default_rng(2)
    n = 600
    ref = pd.DataFrame({"x": rng.normal(0, 1, n)})
    cur = pd.DataFrame({"x": rng.normal(1.0, 1, n)})
    t = fd.drift_table(ref, cur, n_perm=200)
    assert t.iloc[0]["verdict"] == "DRIFT"
    assert t.iloc[0]["psi_p"] < 0.05


def test_a_variance_change_is_detected_not_just_a_mean_shift():
    """A regime change is often a spread change with the mean unmoved."""
    rng = np.random.default_rng(3)
    n = 600
    ref = pd.DataFrame({"x": rng.normal(0, 1.0, n)})
    cur = pd.DataFrame({"x": rng.normal(0, 3.0, n)})
    t = fd.drift_table(ref, cur, n_perm=200)
    assert t.iloc[0]["verdict"] == "DRIFT"


def test_small_windows_report_insufficient_rather_than_a_number():
    rng = np.random.default_rng(4)
    ref = pd.DataFrame({"x": rng.normal(size=40)})
    cur = pd.DataFrame({"x": rng.normal(size=30)})
    t = fd.drift_table(ref, cur, n_perm=50)
    assert t.iloc[0]["verdict"] == "INSUFFICIENT DATA"
    assert not np.isfinite(t.iloc[0]["psi"])


def test_bins_come_from_the_reference_not_the_pool():
    """
    The reference defines the yardstick. If edges were derived from the pooled
    data, the current window could move the scale it is being measured against.
    """
    ref = np.linspace(0, 1, 500)
    edges_a = fd._bin_edges(ref, 10)
    edges_b = fd._bin_edges(ref, 10)
    assert np.array_equal(edges_a, edges_b)
    assert edges_a[0] == -np.inf and edges_a[-1] == np.inf


def test_near_constant_feature_returns_nan_rather_than_dividing_by_zero():
    const = np.full(300, 2.0)
    assert fd._bin_edges(const, 10) is None
    assert not np.isfinite(fd.psi(const, const))


def test_ks_matches_a_known_case_and_is_symmetric():
    rng = np.random.default_rng(5)
    a, b = rng.normal(size=400), rng.normal(size=400)
    d1, p1 = fd.ks_statistic(a, b)
    d2, p2 = fd.ks_statistic(b, a)
    assert d1 == pytest.approx(d2)
    assert p1 == pytest.approx(p2)
    assert 0.0 <= p1 <= 1.0
    d3, p3 = fd.ks_statistic(rng.normal(size=400), rng.normal(5, 1, 400))
    assert d3 > 0.9 and p3 < 1e-6


def test_summary_accounts_for_multiple_testing():
    """
    Testing 40 features at alpha=0.05 yields ~2 false positives by construction,
    so 'some feature drifted' is not news.
    """
    t = pd.DataFrame({"feature": [f"f{i}" for i in range(40)],
                      "verdict": ["DRIFT"] * 2 + ["stable"] * 38})
    s = fd.summarise(t)
    assert s["expected_false_positives"] == pytest.approx(2.0)
    assert s["verdict"] == "WITHIN NOISE"

    t.loc[:14, "verdict"] = "DRIFT"
    assert fd.summarise(t)["verdict"] == "WIDESPREAD DRIFT"


def test_summary_handles_empty_input():
    s = fd.summarise(pd.DataFrame())
    assert s["verdict"] == "NO DATA" and s["n_features"] == 0


# ---------------------------------------------------------------------------
# explain — exactness is the property that matters
# ---------------------------------------------------------------------------

def _known_driver_model(n=1500, k=6, seed=0):
    import lightgbm as lgb
    rng = np.random.default_rng(seed)
    cols = [f"f{i}" for i in range(k)]
    X = pd.DataFrame(rng.normal(size=(n, k)), columns=cols)
    y = 3.0 * X["f0"] - 2.0 * X["f3"] + rng.normal(0, 0.3, n)
    m = lgb.LGBMRegressor(n_estimators=150, verbose=-1, random_state=0).fit(X, y)
    return m, X


def test_known_drivers_are_recovered():
    """
    Without this, a wrongly-parsed contribution layout would still produce
    plausible-looking attributions and nothing would notice.
    """
    _lgb_or_skip()
    m, X = _known_driver_model()
    imp = ex.importance(m, X)
    assert set(imp.head(2)["feature"]) == {"f0", "f3"}
    assert imp.head(2)["share"].sum() > 0.85


def test_additivity_identity_holds_exactly():
    """base_value + sum(shap) == prediction is exact for TreeSHAP."""
    _lgb_or_skip()
    m, X = _known_driver_model()
    for row in (0, 10, -1):
        e = ex.explain_prediction(m, X, row=row)
        assert e["available"] is True
        assert e["additivity_ok"], e["additivity_error"]
        assert e["additivity_error"] < 1e-6


def test_unsupported_models_return_none_not_an_approximation():
    """
    An approximate explanation presented in the same shape as an exact one is a
    trap; the module refuses rather than degrading silently.
    """
    X = pd.DataFrame({"a": [1.0, 2.0], "b": [3.0, 4.0]})
    assert ex.supports(object()) is False
    v, b = ex.shap_values(object(), X)
    assert v is None and b is None
    assert ex.importance(object(), X).empty
    assert ex.explain_prediction(object(), X)["available"] is False


def test_concentration_separates_a_driven_model_from_a_noise_model():
    """
    The measurement the project actually cares about. A model with real drivers
    must score far from uniform; a model fitted to noise must score near it.
    """
    _lgb_or_skip()
    import lightgbm as lgb
    rng = np.random.default_rng(7)

    driven_m, driven_X = _known_driver_model(seed=7)
    c_driven = ex.concentration(ex.importance(driven_m, driven_X))

    n, k = 1500, 6
    cols = [f"f{i}" for i in range(k)]
    Xn = pd.DataFrame(rng.normal(size=(n, k)), columns=cols)
    yn = rng.normal(size=n)                       # pure noise target
    noise_m = lgb.LGBMRegressor(n_estimators=150, verbose=-1,
                                random_state=0).fit(Xn, yn)
    c_noise = ex.concentration(ex.importance(noise_m, Xn))

    driven_ratio = c_driven["herfindahl"] / c_driven["uniform_herfindahl"]
    noise_ratio = c_noise["herfindahl"] / c_noise["uniform_herfindahl"]
    assert driven_ratio > 2.5, driven_ratio
    assert noise_ratio < 2.0, noise_ratio
    assert driven_ratio > noise_ratio * 1.5


def test_importance_shares_sum_to_one():
    _lgb_or_skip()
    m, X = _known_driver_model()
    imp = ex.importance(m, X)
    assert imp["share"].sum() == pytest.approx(1.0, rel=1e-9)
    assert imp["cumulative_share"].iloc[-1] == pytest.approx(1.0, rel=1e-9)


def test_multiclass_model_is_handled():
    _lgb_or_skip()
    import lightgbm as lgb
    rng = np.random.default_rng(8)
    n, k = 1200, 5
    cols = [f"f{i}" for i in range(k)]
    X = pd.DataFrame(rng.normal(size=(n, k)), columns=cols)
    y = (X["f1"] > 0).astype(int) + (X["f2"] > 0.5).astype(int)
    m = lgb.LGBMClassifier(n_estimators=100, verbose=-1,
                           random_state=0).fit(X, y)
    imp = ex.importance(m, X)
    assert len(imp) == k
    assert imp["mean_abs_shap"].iloc[0] > 0
    assert set(imp.head(2)["feature"]) == {"f1", "f2"}
