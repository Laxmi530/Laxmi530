"""
Tests for ``var_models`` — VaR estimators and the VaR backtest battery.

The estimators are checked against cases with a known answer (a Gaussian series
whose 5% VaR is analytic), and the backtests against synthetic exception
sequences engineered to have a known verdict: correctly-calibrated, too many
breaches, or breaches deliberately clustered so the independence test *must*
reject.

Network-free and deterministic (the generative sampler runs its block-bootstrap
path; the optional GAN is never enabled here). Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import math

import numpy as np

import var_models as vm


def _gaussian_returns(n=1500, sigma=0.015, mu=0.0, seed=11):
    return np.random.default_rng(seed).normal(mu, sigma, n)


# ── Helpers ────────────────────────────────────────────────────────────────
def test_chi2_sf_known_values():
    # chi2(1) at 3.841 and chi2(2) at 5.991 are the classic 5% critical values.
    assert abs(vm._chi2_sf(3.8415, 1) - 0.05) < 1e-3
    assert abs(vm._chi2_sf(5.9915, 2) - 0.05) < 1e-3
    assert vm._chi2_sf(0.0, 1) == 1.0


def test_ewma_volatility_is_causal_and_responsive():
    r = np.concatenate([np.full(200, 0.001), np.full(20, 0.10)])
    sig = vm.ewma_volatility(r)
    assert len(sig) == len(r)
    # sigma[t] uses only bars before t, so the first shock bar is not yet priced.
    assert sig[200] < sig[210] < sig[219]
    # And the next-bar forecast is higher still than the last in-sample sigma.
    assert vm.ewma_next_sigma(r) >= sig[-1]


# ── Estimators ─────────────────────────────────────────────────────────────
def test_variance_covariance_matches_analytic_gaussian():
    sigma = 0.015
    r = _gaussian_returns(4000, sigma=sigma)
    res = vm.var_variance_covariance(r, alpha=0.05, ewma=False)
    expected_log = vm._norm_ppf(0.05) * sigma          # mu ~ 0
    assert abs(math.log1p(res['var_return']) - expected_log) < 0.002
    assert res['var_loss'] > 0                          # reported as a loss
    assert res['es_return'] < res['var_return']         # ES is worse than VaR


def test_historical_simulation_recovers_empirical_quantile():
    r = _gaussian_returns(3000)
    res = vm.var_historical_simulation(r, alpha=0.05)
    assert abs(math.log1p(res['var_return']) - np.quantile(r, 0.05)) < 1e-9
    assert res['n_obs'] == len(r)


def test_cornish_fisher_widens_when_skew_dominates():
    rng = np.random.default_rng(3)
    # Strongly left-skewed with only mild excess kurtosis: the skew term
    # dominates and CF correctly reserves MORE than the Gaussian.
    r = np.concatenate([rng.normal(0.001, 0.01, 1800),
                        -np.abs(rng.normal(0.05, 0.03, 200))])
    normal = vm.var_variance_covariance(r, alpha=0.05, ewma=False)
    cf = vm.var_cornish_fisher(r, alpha=0.05, ewma=False)
    assert cf['skew'] < 0 and cf['excess_kurtosis'] > 0
    assert cf['var_loss'] > normal['var_loss']


def test_cornish_fisher_narrows_at_5pct_when_kurtosis_dominates():
    """
    The documented cautionary case, pinned as a test.

    The kurtosis term is proportional to ``z^3 - 3z``, which is POSITIVE for
    |z| < sqrt(3) ~ 1.732 — and the 5% quantile sits at z = -1.645, inside that
    range. So when excess kurtosis is large enough to dominate the skew term, CF
    *reduces* the 5% reserve — the opposite of the naive expectation — and only
    widens further out in the tail. This test locks that behaviour in so the
    docstring can be trusted, and so the surprising Cornish-Fisher row in
    ``run_var_backtest.py``'s real-data output is a documented property rather
    than a suspected bug.
    """
    rng = np.random.default_rng(31)
    # Variance mixture: a 5% high-vol component gives enormous excess kurtosis.
    r = np.concatenate([rng.normal(0, 0.008, 1900),
                        rng.normal(0, 0.09, 100)])
    cf5 = vm.var_cornish_fisher(r, alpha=0.05, ewma=False)
    n5 = vm.var_variance_covariance(r, alpha=0.05, ewma=False)
    # Kurtosis is the dominant moment here (|K|/24 >> |S|/6 at z = -1.645).
    assert cf5['excess_kurtosis'] > 20
    assert cf5['var_loss'] < n5['var_loss'], (cf5['var_loss'], n5['var_loss'])

    # Deep in the tail, z^3 - 3z turns negative and CF widens — dramatically,
    # which is the other half of "asymptotic expansion, handle with care".
    cf1 = vm.var_cornish_fisher(r, alpha=0.005, ewma=False)
    n1 = vm.var_variance_covariance(r, alpha=0.005, ewma=False)
    assert cf1['var_loss'] > n1['var_loss']


def test_fhs_is_conditional_on_recent_volatility():
    rng = np.random.default_rng(4)
    calm = rng.normal(0, 0.005, 800)
    stressed = np.concatenate([calm, rng.normal(0, 0.04, 40)])
    var_calm = vm.var_filtered_historical_simulation(calm, n_sims=4000)
    var_stress = vm.var_filtered_historical_simulation(stressed, n_sims=4000)
    # This is the whole point of FHS: after a volatile stretch the reserve jumps.
    assert var_stress['var_loss'] > 3 * var_calm['var_loss']
    # Unconditional historical simulation barely reacts by comparison.
    hs_calm = vm.var_historical_simulation(calm)
    hs_stress = vm.var_historical_simulation(stressed)
    assert (var_stress['var_loss'] / var_calm['var_loss']
            > hs_stress['var_loss'] / hs_calm['var_loss'])


def test_fhs_scales_with_horizon():
    r = _gaussian_returns(1000)
    one = vm.var_filtered_historical_simulation(r, horizon=1, n_sims=6000)
    five = vm.var_filtered_historical_simulation(r, horizon=5, n_sims=6000)
    assert five['var_loss'] > one['var_loss']
    # Roughly sqrt-of-time for a near-i.i.d. series (loose bound: MC noise).
    assert 1.5 < five['var_loss'] / one['var_loss'] < 3.5


def test_estimators_degrade_gracefully_on_short_input():
    short = np.array([0.01, -0.02, 0.005])
    for fn in (vm.var_variance_covariance, vm.var_historical_simulation,
               vm.var_cornish_fisher, vm.var_filtered_historical_simulation):
        res = fn(short)
        assert np.isnan(res['var_return'])              # no fabricated number


# ── Generative sampler ─────────────────────────────────────────────────────
def test_block_bootstrap_preserves_scale_and_shape():
    r = _gaussian_returns(1200, sigma=0.02)
    samples, gen = vm.generative_return_samples(r, horizon=1, n_sims=20000)
    assert gen == 'block-bootstrap'
    assert abs(np.std(samples) - np.std(r)) < 0.003
    res = vm.var_generative(r, alpha=0.05, n_sims=20000)
    assert res['var_loss'] > 0 and res['es_return'] < res['var_return']


def test_generative_horizon_aggregates():
    r = _gaussian_returns(1000, sigma=0.01)
    s1, _ = vm.generative_return_samples(r, horizon=1, n_sims=20000)
    s5, _ = vm.generative_return_samples(r, horizon=5, n_sims=20000)
    assert np.std(s5) > np.std(s1)


# ── Backtests ──────────────────────────────────────────────────────────────
def test_kupiec_accepts_correct_rate_rejects_excess():
    rng = np.random.default_rng(7)
    ok = (rng.random(1000) < 0.05).astype(int)          # true 5% rate
    bad = (rng.random(1000) < 0.20).astype(int)         # 4x too many breaches
    assert vm.kupiec_pof_test(ok, 0.05)['p_value'] > 0.05
    res_bad = vm.kupiec_pof_test(bad, 0.05)
    assert res_bad['p_value'] < 0.01
    assert res_bad['reject_5pct'] and res_bad['direction'] == 'understates risk'


def test_kupiec_flags_over_reserving():
    e = np.zeros(500, dtype=int)                        # never breaches
    res = vm.kupiec_pof_test(e, 0.05)
    assert res['direction'] == 'overstates risk'
    assert res['reject_5pct']                           # 0 of 500 is too few


def test_christoffersen_detects_clustering():
    rng = np.random.default_rng(8)
    n = 1000
    independent = (rng.random(n) < 0.05).astype(int)
    # Same total count, but forced into contiguous runs.
    clustered = np.zeros(n, dtype=int)
    k = int(independent.sum())
    for start in range(0, k, 5):
        pos = 100 + (start // 5) * 60
        clustered[pos:pos + min(5, k - start)] = 1
    assert vm.christoffersen_independence_test(independent)['p_value'] > 0.05
    res = vm.christoffersen_independence_test(clustered)
    assert res['clustering'] is True
    assert res['p_value'] < 0.05


def test_conditional_coverage_combines_both():
    rng = np.random.default_rng(9)
    ok = (rng.random(1200) < 0.05).astype(int)
    cc = vm.christoffersen_conditional_coverage(ok, 0.05)
    assert cc['p_value'] > 0.05
    # LR_cc is the sum of the two component statistics, on 2 df.
    assert np.isclose(cc['lr_stat'],
                      cc['pof']['lr_stat'] + cc['independence']['lr_stat'])


def test_independence_test_undefined_without_breaches():
    res = vm.christoffersen_independence_test(np.zeros(300, dtype=int))
    assert np.isnan(res['p_value']) and not res['reject_5pct']


def test_backtest_var_calibrates_on_gaussian_data():
    r = _gaussian_returns(1400, sigma=0.012, seed=21)
    res = vm.backtest_var(r, method='variance-covariance', alpha=0.05,
                          horizon=1, window=250)
    assert res['n_eval'] > 800
    # On genuinely Gaussian data the Gaussian estimator should be well calibrated.
    assert abs(res['exception_rate'] - 0.05) < 0.025
    assert res['kupiec']['p_value'] > 0.01
    assert res['avg_var_loss'] > 0
    # Exceedance is reported as a positive magnitude (how far past the threshold).
    assert res['mean_exceedance'] >= 0
    assert set(res['records'].columns) >= {'t', 'var_return',
                                           'realised_return', 'exception'}


def test_backtest_var_flags_a_deliberately_bad_model():
    r = _gaussian_returns(1200, sigma=0.02, seed=22)

    def _too_tight(returns, alpha, horizon):
        """A VaR that reserves half of what it should — must be rejected."""
        base = vm.var_variance_covariance(returns, alpha, horizon)
        return {**base, 'var_return': base['var_return'] / 2.0}

    res = vm.backtest_var(r, estimator=_too_tight, alpha=0.05, window=250)
    assert res['exception_rate'] > 0.05
    assert res['kupiec']['reject_5pct']
    assert res['kupiec']['direction'] == 'understates risk'


def test_backtest_var_rejects_unknown_method():
    try:
        vm.backtest_var(_gaussian_returns(400), method='nope')
    except ValueError as exc:
        assert 'nope' in str(exc)
    else:
        raise AssertionError("expected ValueError for an unknown method")


def test_compare_var_methods_returns_ranked_table():
    r = _gaussian_returns(900, sigma=0.015, seed=23)
    table = vm.compare_var_methods(
        r, methods=['variance-covariance', 'historical', 'fhs'],
        alpha=0.05, horizon=1, window=250)
    assert len(table) == 3
    assert {'method', 'exception_rate', 'kupiec_p',
            'independence_p', 'cc_p'} <= set(table.columns)
    # Sorted best-calibrated first (highest conditional-coverage p-value).
    cc = table['cc_p'].dropna().values
    assert all(cc[i] >= cc[i + 1] for i in range(len(cc) - 1))


def test_returns_from_prices_drops_bad_values():
    out = vm.returns_from_prices([100.0, 0.0, 110.0, -5.0, 121.0])
    # Non-positive prices removed, then diffs of logs: 100 -> 110 -> 121.
    assert len(out) == 2 and np.allclose(out, np.log(1.1), atol=1e-9)



# ── Expected-Shortfall backtesting (Acerbi-Szekely) ────────────────────────
def test_es_null_distribution_is_centred_at_zero():
    """
    Regression test for a bug this suite caught after the fact.

    The first implementation built the H0 bootstrap by resampling the *observed*
    exceedance severities — which already encode the model's mis-calibration. The
    null therefore centred on the observed failure (measured: -1.045 instead of
    ~0), so the test could never reject on severity and reported p = 1.00 for a
    model whose realised tail was 1.9x its predicted ES. The pool is now
    re-centred to unit mean, imposing H0 while keeping the observed dispersion.
    """
    rng = np.random.default_rng(5)
    r = np.concatenate([rng.normal(0, 0.008, 3000), rng.normal(0, 0.06, 300)])
    rng.shuffle(r)
    res = vm.backtest_es(r, method='variance-covariance', alpha=0.05, window=250)
    rec = res['records']
    br = rec[rec['exception'] == 1]
    ratios = (br['realised_return'] / br['es_return']).values

    # Rebuild the null the way the fixed code does and check it centres on 0.
    n, a = res['n'], 0.05
    pool = ratios / ratios.mean()
    g = np.random.default_rng(0)
    sims = [1.0 - float(np.sum(g.choice(pool, size=int(g.binomial(n, a)),
                                        replace=True))) / (n * a)
            for _ in range(500)]
    assert abs(float(np.mean(sims))) < 0.15, float(np.mean(sims))


def test_es_rejects_gaussian_model_on_fat_tails():
    """A Gaussian ES on a fat-tailed series must be caught under-reserving."""
    rng = np.random.default_rng(5)
    r = np.concatenate([rng.normal(0, 0.008, 3000), rng.normal(0, 0.06, 300)])
    rng.shuffle(r)
    res = vm.backtest_es(r, method='variance-covariance', alpha=0.05, window=250)
    assert res['severity_ratio'] > 1.5, res['severity_ratio']
    assert res['z2'] < 0 and res['direction'] == 'under-estimates severity'
    assert res['reject_5pct'], res['p_value']


def test_es_accepts_a_correctly_specified_model():
    """On genuinely Gaussian data the Gaussian ES must NOT be rejected."""
    r = np.random.default_rng(7).normal(0, 0.015, 3300)
    res = vm.backtest_es(r, method='variance-covariance', alpha=0.05, window=250)
    assert 0.85 < res['severity_ratio'] < 1.20, res['severity_ratio']
    assert not res['reject_5pct'], res['p_value']


def test_es_historical_keeps_the_empirical_tail():
    """Historical simulation keeps the fat tail, so its severity stays near 1."""
    rng = np.random.default_rng(5)
    r = np.concatenate([rng.normal(0, 0.008, 3000), rng.normal(0, 0.06, 300)])
    rng.shuffle(r)
    hs = vm.backtest_es(r, method='historical', alpha=0.05, window=250)
    vc = vm.backtest_es(r, method='variance-covariance', alpha=0.05, window=250)
    assert hs['severity_ratio'] < vc['severity_ratio']
    assert abs(hs['severity_ratio'] - 1.0) < 0.2, hs['severity_ratio']


def test_es_untestable_without_exceptions():
    """No breaches means ES is untestable, not perfect — the report must say so."""
    res = vm.acerbi_szekely_z2(np.full(200, 0.01), np.full(200, -0.5),
                               np.full(200, -0.6))
    assert res['n_exceptions'] == 0
    assert 'untestable' in res['direction']
    assert not res['reject_5pct']


def test_es_degrades_on_tiny_samples():
    res = vm.acerbi_szekely_z2([0.01] * 5, [-0.02] * 5, [-0.03] * 5)
    assert np.isnan(res['z2']) and res['direction'] == 'n/a'


def test_compare_es_methods_table():
    rng = np.random.default_rng(11)
    r = np.concatenate([rng.normal(0, 0.01, 1500), rng.normal(0, 0.05, 150)])
    rng.shuffle(r)
    t = vm.compare_es_methods(
        r, methods=['variance-covariance', 'historical', 'fhs'], window=250)
    assert len(t) >= 2
    assert {'method', 'severity_ratio', 'z2', 'p_value', 'verdict'} <= set(t.columns)
    # Sorted by |z2| ascending (best-calibrated first).
    z = t['z2'].abs().values
    assert all(z[i] <= z[i + 1] + 1e-9 for i in range(len(z) - 1))


def test_backtest_es_rejects_unknown_method():
    try:
        vm.backtest_es(np.random.default_rng(0).normal(0, .01, 500), method='nope')
    except ValueError as exc:
        assert 'nope' in str(exc)
    else:
        raise AssertionError("expected ValueError for an unknown method")

def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All VaR-model tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
