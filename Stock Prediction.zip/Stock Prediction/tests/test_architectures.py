"""
Tests for architectures.py — declared specs and the realised-architecture record.

Two things need pinning, and they are different in kind:

1. **Introducing this module changed no network.** The defaults must reproduce
   the exact layer stacks the deep models shipped with, or every published
   figure silently refers to a different model.
2. **The manifest record cannot be decoration.** A spec that is merely stored
   next to a run, or an override that fails to reach the builder, is the
   "configuration theatre" ``test_config.py`` exists to prevent. The record has
   to come from the compiled object.
"""

import json
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import architectures as arch


# ---------------------------------------------------------------------------
# Registry integrity
# ---------------------------------------------------------------------------

def test_defaults_match_the_previously_hardcoded_stacks():
    """
    The literals these models shipped with, before the spec existed. If this
    fails, adopting the config changed the networks — which would invalidate
    every result in the README rather than merely reorganising code.
    """
    assert arch.SPECS["DL"]["recurrent_units"] == [64, 64, 32]
    assert arch.SPECS["DL"]["dropout"] == [0.3, 0.3, 0.2]
    assert arch.SPECS["DL"]["recurrent_dropout"] == 0.1
    assert arch.SPECS["DL"]["dense_units"] == 16

    assert arch.SPECS["CNN-LSTM"]["filters"] == [32, 64]
    assert arch.SPECS["CNN-LSTM"]["kernel_size"] == 3
    assert arch.SPECS["CNN-LSTM"]["pool_size"] == 2
    assert arch.SPECS["CNN-LSTM"]["lstm_units"] == [48, 24]
    assert arch.SPECS["CNN-LSTM"]["dropout"] == 0.2

    assert arch.SPECS["Vol-LSTM"]["units"] == [48, 24]
    assert arch.SPECS["Vol-LSTM"]["dropout"] == 0.2


def test_every_spec_is_json_serialisable():
    """A spec that cannot round-trip through JSON cannot be overridden or logged."""
    for name, sp in arch.SPECS.items():
        assert json.loads(json.dumps(sp)) == sp, name


def test_spec_returns_a_copy_not_the_live_registry():
    """A caller mutating its spec must not silently reconfigure every later fit."""
    sp = arch.spec("DL")
    sp["recurrent_units"] = [1]
    assert arch.SPECS["DL"]["recurrent_units"] == [64, 64, 32]


def test_unknown_model_returns_empty_rather_than_raising():
    assert arch.spec("does-not-exist") == {}
    assert arch.spec_driven("does-not-exist") is False


def test_spec_driven_flag_is_honest_about_coverage():
    """
    N-BEATS / TCN / Transformer are recorded but NOT driven from here. Claiming
    otherwise would be the worse failure: a manifest asserting control it does
    not have.
    """
    for name in arch.SPECS:
        assert arch.spec_driven(name), f"{name} is declared but not wired"
    for name in ("N-BEATS", "TCN", "Transformer"):
        assert not arch.spec_driven(name)


# ---------------------------------------------------------------------------
# Fingerprint
# ---------------------------------------------------------------------------

def test_fingerprint_is_stable_and_order_independent():
    a = arch.fingerprint({"x": 1, "y": [2, 3]})
    b = arch.fingerprint({"y": [2, 3], "x": 1})
    assert a == b
    assert a == arch.fingerprint({"x": 1, "y": [2, 3]})


def test_fingerprint_changes_when_the_architecture_changes():
    base = arch.spec("DL")
    changed = dict(base, recurrent_units=[64, 64, 16])
    assert arch.fingerprint(base) != arch.fingerprint(changed)


def test_fingerprint_never_raises_on_odd_input():
    assert arch.fingerprint({"f": lambda x: x})      # not JSON-serialisable
    assert arch.fingerprint(None)


# ---------------------------------------------------------------------------
# Realised architecture
# ---------------------------------------------------------------------------

def test_describe_degrades_instead_of_raising():
    out = arch.describe(None)
    assert out["available"] is False
    out = arch.describe(object(), "DL")
    assert out["available"] is False or "layers" in out


def test_manifest_block_skips_unavailable_records():
    block = arch.manifest_block({
        "Good": {"available": True, "n_layers": 3, "n_params": 10,
                 "optimizer": "Adam", "loss": "huber", "fingerprint": "abc",
                 "spec_driven": True},
        "Bad": {"available": False},
        "Junk": "not a dict",
    })
    assert set(block) == {"Good"}
    assert block["Good"]["fingerprint"] == "abc"


def test_manifest_block_is_compact():
    """
    The manifest is read by a human in an expander. A full layer dump for six
    models would bury the seed and versions sitting next to it, so only the
    identifying summary is stored.
    """
    full = {"available": True, "n_layers": 2, "n_params": 5,
            "optimizer": "Adam", "loss": "mse", "fingerprint": "f",
            "spec_driven": True,
            "layers": [{"type": "LSTM"}] * 40}
    block = arch.manifest_block({"M": full})
    assert "layers" not in block["M"]
    assert json.loads(json.dumps(block)) == block


def test_manifest_block_tolerates_empty_input():
    assert arch.manifest_block(None) == {}
    assert arch.manifest_block({}) == {}


# ---------------------------------------------------------------------------
# The spec actually drives the build (the part that would otherwise be theatre)
# ---------------------------------------------------------------------------

def _keras_or_skip():
    try:
        import tensorflow  # noqa: F401
    except Exception:
        pytest.skip("TensorFlow not available")


def test_cnn_lstm_reads_its_shape_from_the_spec(monkeypatch):
    """
    Override the spec, build, and confirm the network changed. If this passes
    with the default and fails here, the spec is documentation rather than
    configuration.
    """
    _keras_or_skip()
    import CNN_LSTM_model as cl

    monkeypatch.setitem(arch.SPECS, "CNN-LSTM",
                        dict(arch.SPECS["CNN-LSTM"], filters=[8],
                             lstm_units=[4, 3]))
    m = cl.build_cnn_lstm_model((32, 5), output_dim=3)
    convs = [l for l in m.layers if type(l).__name__ == "Conv1D"]
    lstms = [l for l in m.layers if type(l).__name__ == "LSTM"]
    assert [c.filters for c in convs] == [8]
    assert [l.units for l in lstms] == [4, 3]


def test_vol_lstm_reads_its_shape_from_the_spec(monkeypatch):
    _keras_or_skip()
    import vol_lstm_model as vl

    monkeypatch.setitem(arch.SPECS, "Vol-LSTM",
                        dict(arch.SPECS["Vol-LSTM"], units=[6, 5]))
    m = vl.build_vol_lstm((20, 5), 3)
    lstms = [l for l in m.layers if type(l).__name__ == "LSTM"]
    assert [l.units for l in lstms] == [6, 5]


def test_explicit_arguments_still_beat_the_spec():
    """The builders stay usable as plain functions, so tests can pin a shape."""
    _keras_or_skip()
    import CNN_LSTM_model as cl
    m = cl.build_cnn_lstm_model((32, 5), output_dim=2, filters=(16,),
                                lstm_units=(7, 6))
    assert [l.filters for l in m.layers if type(l).__name__ == "Conv1D"] == [16]
    assert [l.units for l in m.layers if type(l).__name__ == "LSTM"] == [7, 6]


def test_describe_records_a_real_built_model():
    _keras_or_skip()
    import CNN_LSTM_model as cl
    m = cl.build_cnn_lstm_model((32, 5), output_dim=2)
    rec = arch.describe(m, "CNN-LSTM")

    assert rec["available"] is True
    assert rec["n_layers"] > 0
    assert rec["n_params"] > 0
    assert rec["optimizer"]
    assert rec["spec_driven"] is True
    assert rec["declared_spec"] == arch.spec("CNN-LSTM")
    assert len(rec["fingerprint"]) == 12
    assert json.loads(json.dumps(rec)) == rec, "record must be JSON-safe"


def test_realised_fingerprint_tracks_a_real_shape_change():
    """
    The point of recording the built model rather than the requested one: two
    genuinely different networks must not share a fingerprint.
    """
    _keras_or_skip()
    import CNN_LSTM_model as cl
    a = arch.describe(cl.build_cnn_lstm_model((32, 5), 2, lstm_units=(48, 24)),
                      "CNN-LSTM")
    b = arch.describe(cl.build_cnn_lstm_model((32, 5), 2, lstm_units=(8, 4)),
                      "CNN-LSTM")
    assert a["fingerprint"] != b["fingerprint"]


def test_attach_puts_the_record_on_the_frame_and_never_raises():
    import pandas as pd
    _keras_or_skip()
    import CNN_LSTM_model as cl

    df = pd.DataFrame({"predicted_price": [1.0, 2.0]})
    arch.attach(df, cl.build_cnn_lstm_model((32, 5), 2), "CNN-LSTM")
    assert df.attrs["architecture"]["available"] is True

    # A broken model must not break the frame it annotates.
    df2 = pd.DataFrame({"predicted_price": [1.0]})
    arch.attach(df2, object(), "CNN-LSTM")
    assert "architecture" in df2.attrs


def test_every_deep_model_passes_its_registry_key_not_its_display_string():
    """
    Regression: forecast_nn_direct was first wired with ``desc`` ("CNN-LSTM
    forecasts") instead of the registry key ("CNN-LSTM"), so the manifest
    reported spec_driven=false for a model that IS spec-driven — under-claiming
    control is still misreporting it. Checked statically so it holds without
    training five networks.
    """
    import re
    expected = {
        "CNN_LSTM_model.py": "CNN-LSTM",
        "DL_model.py": "DL",
        "NBeats_model.py": "N-BEATS",
        "TCN_model.py": "TCN",
        "Transformer_model.py": "Transformer",
    }
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for fname, key in expected.items():
        src = open(os.path.join(root, fname), encoding="utf-8").read()
        call = re.search(r"forecast_nn_direct\((?:.|\n)*?\n\s*\)", src)
        assert call, f"{fname}: no forecast_nn_direct call found"
        assert f"model_name='{key}'" in call.group(0), (
            f"{fname} does not pass model_name='{key}'")


def test_names_used_by_the_models_match_the_registry():
    """A key the registry does not know silently loses its declared spec."""
    for key in ("CNN-LSTM", "DL", "Vol-LSTM"):
        assert key in arch.SPECS
        assert arch.spec_driven(key)
