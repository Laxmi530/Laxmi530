"""
Tests for the Fama-MacBeth information coefficient (strategy_metrics.py).

Why these exist
---------------
The project reported a cross-sectional rank IC with a t-statistic computed by
``ic_t_stat(ic, n_rows)`` — the ordinary correlation t-test, which assumes n
INDEPENDENT observations. On a pooled panel that assumption is false: names on
the same date share the market move, so 6,887 rows over ~570 dates carry
nothing like 6,887 independent observations, and the t-statistic is inflated by
roughly sqrt(names per date).

These tests pin the correct behaviour: IC within each date, t-tested across
dates, with a Newey-West correction for the overlap that a horizon-h forward
return sampled daily creates.
"""

import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import strategy_metrics as sm


def _panel(n_dates=200, n_names=20, ic=0.0, seed=0):
    """Build a panel whose within-date score/return correlation is ~``ic``."""
    rng = np.random.default_rng(seed)
    rows = []
    base = pd.Timestamp("2020-01-01")
    for d in range(n_dates):
        s = rng.normal(size=n_names)
        noise = rng.normal(size=n_names)
        f = ic * s + np.sqrt(max(1.0 - ic ** 2, 0.0)) * noise
        for i in range(n_names):
            rows.append((base + pd.Timedelta(days=d), s[i], f[i]))
    return pd.DataFrame(rows, columns=["date", "score", "fwd"])


# ---------------------------------------------------------------------------
# ic_by_date
# ---------------------------------------------------------------------------

def test_ic_is_computed_within_each_date():
    p = _panel(n_dates=50, n_names=15, ic=0.0)
    s = sm.ic_by_date(p["date"], p["score"], p["fwd"])
    assert len(s) == 50, "expected one IC per date"
    assert s.index.is_monotonic_increasing


def test_a_real_within_date_signal_is_detected():
    p = _panel(n_dates=250, n_names=25, ic=0.30, seed=1)
    fm = sm.fama_macbeth_ic(sm.ic_by_date(p["date"], p["score"], p["fwd"]))
    assert fm["mean_ic"] > 0.20
    assert fm["t_stat"] > 5
    assert fm["hit_rate"] > 0.8


def test_pure_noise_is_not_significant():
    p = _panel(n_dates=250, n_names=25, ic=0.0, seed=2)
    fm = sm.fama_macbeth_ic(sm.ic_by_date(p["date"], p["score"], p["fwd"]))
    assert abs(fm["t_stat"]) < 2.5, f"noise scored t={fm['t_stat']}"
    assert 0.35 < fm["hit_rate"] < 0.65


def test_narrow_cross_sections_are_skipped_not_faked():
    """
    A correlation over three names is noise. Returning an empty series is the
    honest answer — it tells the caller the cross-section cannot support the
    statistic, rather than silently producing a number from nothing.
    """
    p = _panel(n_dates=40, n_names=3, ic=0.0)
    s = sm.ic_by_date(p["date"], p["score"], p["fwd"], min_names=5)
    assert s.empty
    fm = sm.fama_macbeth_ic(s)
    assert fm["n_dates"] == 0
    assert not np.isfinite(fm["t_stat"])


def test_constant_score_on_a_date_is_skipped():
    """A date where the model gives every name the same score has no ranking."""
    p = _panel(n_dates=20, n_names=10, ic=0.0)
    first = p["date"].min()
    p.loc[p["date"] == first, "score"] = 1.0
    s = sm.ic_by_date(p["date"], p["score"], p["fwd"])
    assert first not in s.index
    assert len(s) == 19


# ---------------------------------------------------------------------------
# The correction that matters
# ---------------------------------------------------------------------------

def _market_effect_panel(n_dates=200, n_names=25, seed=3):
    """
    A panel with a shared per-date shock and ZERO within-date signal.

    Every name on a date gets the same market move added to both its score and
    its forward return. Cross-sectionally the model knows nothing: within any
    single date, score and return are independent. But pooled across dates the
    common shock induces a large apparent correlation.

    This is not a contrived case — it is the ordinary structure of an equity
    panel, which is why the distinction matters here at all.
    """
    rng = np.random.default_rng(seed)
    rows = []
    base = pd.Timestamp("2020-01-01")
    for d in range(n_dates):
        shock = rng.normal() * 2.0               # the day's market move
        s = shock + rng.normal(size=n_names)
        f = shock + rng.normal(size=n_names)     # no within-date relation
        for i in range(n_names):
            rows.append((base + pd.Timedelta(days=d), s[i], f[i]))
    return pd.DataFrame(rows, columns=["date", "score", "fwd"])


def test_pooled_t_stat_is_inflated_by_a_shared_market_effect():
    """
    The headline claim, and the reason the reported figure was changed.

    On a panel driven entirely by a common daily shock, the pooled statistic
    reports a large, wildly significant "signal" that has no cross-sectional
    content whatsoever. The Fama-MacBeth form, which removes the date effect by
    construction, correctly reports nothing.
    """
    p = _market_effect_panel()
    pooled_ic = sm.rank_information_coefficient(p["score"].values, p["fwd"].values)
    pooled_t = sm.ic_t_stat(pooled_ic, len(p))
    fm = sm.fama_macbeth_ic(sm.ic_by_date(p["date"], p["score"], p["fwd"]))

    assert len(p) == 5000 and fm["n_dates"] == 200
    # The pooled read is emphatic and wrong.
    assert pooled_ic > 0.5 and pooled_t > 20, (
        f"fixture failed to induce a pooled effect: ic={pooled_ic:.3f}")
    # The honest read finds nothing, because there is nothing.
    assert abs(fm["mean_ic"]) < 0.05
    assert abs(fm["t_stat"]) < 2.5, f"FM t={fm['t_stat']:.2f} on a null panel"


def test_newey_west_widens_the_error_on_overlapping_series():
    """
    Overlapping forward returns make consecutive ICs autocorrelated. Ignoring
    that understates the standard error — the same mistake the backtest's
    overlapping-origin caveat flags.
    """
    rng = np.random.default_rng(4)
    raw = rng.normal(size=600)
    # Impose positive serial correlation, as overlapping windows would.
    x = pd.Series(raw).rolling(5).mean().dropna().values
    se_plain = sm.newey_west_se(x, lags=0)
    se_nw = sm.newey_west_se(x, lags=4)
    assert se_nw > se_plain, "Newey-West should not shrink the standard error"


def test_newey_west_matches_plain_se_at_zero_lag():
    x = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
    expected = float(np.std(x, ddof=0) / np.sqrt(len(x)))
    assert abs(sm.newey_west_se(x, lags=0) - expected) < 1e-12


def test_degenerate_inputs_return_nan_rather_than_raising():
    assert not np.isfinite(sm.newey_west_se([1.0, 2.0], lags=0))
    fm = sm.fama_macbeth_ic(pd.Series([], dtype=float))
    assert fm["n_dates"] == 0
    assert not np.isfinite(fm["mean_ic"])


# ---------------------------------------------------------------------------
# Model determinism
# ---------------------------------------------------------------------------

def test_classifier_is_bit_reproducible_across_fits():
    """
    LightGBM's multi-threaded histogram build is not reproducible by default:
    the same seed gave abstention 0.9461 on one run and 0.9552 on the next,
    because float addition order varies with thread scheduling. An A/B is
    unreadable when an arm does not reproduce itself, so the classifier pins
    deterministic=True / force_col_wise / n_jobs=1.
    """
    import cross_sectional_model as csm

    rng = np.random.default_rng(0)
    n, k = 1500, 6
    cols = [f"f{i}" for i in range(k)]
    X = pd.DataFrame(rng.normal(size=(n, k)), columns=cols)
    y = rng.integers(0, 3, n)

    out = []
    for _ in range(2):
        m = csm.build_classifier(n_estimators=50, seed=42)
        m.fit(X, y)
        out.append(m.predict_proba(X))
    assert np.array_equal(out[0], out[1]), "same seed produced different fits"
