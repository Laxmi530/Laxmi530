"""
Tests for the nselib daily fallback in ``get_data.get_stock_data_using_nselib``.

Why these exist
---------------
This path fires only when yfinance returns nothing for a daily request, which
made it the least-exercised code in the fetch layer -- and it carried four
defects the primary path does not. Every test below pins one of them:

* ``AveragePrice`` (VWAP, and **unadjusted**) was mapped to ``adj_close``.
  Across CESC's 10:1 split that produces a -89.5% one-day return in the exact
  column the pipeline models log returns off.
* no ``Series`` filter, so pre-2003 dual-listed names returned two rows per date
* the frame arrived unsorted, not monotonic in either direction
* ``datetime`` came back as a string while the yfinance path returns
  ``datetime64``

All offline: ``capital_market.price_volume_data`` and the corporate-action fetch
are both monkeypatched, so nothing here touches NSE.
"""

import numpy as np
import pandas as pd
import pytest

import get_data as gd


# ==========================================
# helpers
# ==========================================
def _raw(rows):
    """A frame shaped like nselib's price_volume_data output."""
    return pd.DataFrame(rows)


def _row(date, close, series="EQ", vwap=None, volume="1,00,000", open_=None):
    return {
        "Symbol": "TEST", "Series": series, "Date": date,
        "PrevClose": close, "OpenPrice": open_ or close,
        "HighPrice": close, "LowPrice": close, "LastPrice": close,
        "ClosePrice": close, "AveragePrice": vwap if vwap is not None else close,
        "TotalTradedQuantity": volume, "No.ofTrades": 100,
    }


@pytest.fixture
def patched(monkeypatch):
    """Install a fake feed; the test supplies the rows."""
    state = {"rows": [], "actions": None, "raised": None}

    def fake_pvd(symbol, from_date, to_date):
        return _raw(state["rows"])

    def fake_actions(start, end, **kw):
        if state["raised"] is not None:
            raise state["raised"]
        return (state["actions"] if state["actions"] is not None
                else pd.DataFrame(columns=["symbol", "ex_date", "factor",
                                           "dividend", "rights_ratio",
                                           "rights_price", "subject"]))

    monkeypatch.setattr(gd.capital_market, "price_volume_data", fake_pvd)
    monkeypatch.setattr(gd, "get_ticker", lambda name: "TEST")
    import bhavcopy
    monkeypatch.setattr(bhavcopy, "corporate_actions", fake_actions)
    return state


# ==========================================
# 1. The VWAP bug
# ==========================================
def test_adj_close_is_not_vwap(patched):
    """Regression: AveragePrice is VWAP, not an adjusted close. Mapping it to
    adj_close fed the model a different price series AND an unadjusted one."""
    patched["rows"] = [_row("01-Jan-2020", "100", vwap="97.5"),
                       _row("02-Jan-2020", "101", vwap="98.1")]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert df["close"].tolist() == [100.0, 101.0]
    assert df["adj_close"].tolist() == [100.0, 101.0]     # from ClosePrice
    assert df["vwap"].tolist() == [97.5, 98.1]            # kept, not discarded
    assert not np.allclose(df["adj_close"], df["vwap"])


def test_vwap_is_kept_rather_than_dropped(patched):
    """It is real information -- just not an adjusted close."""
    patched["rows"] = [_row("01-Jan-2020", "100", vwap="97.5")]
    assert "vwap" in gd.get_stock_data_using_nselib("Test Co").columns


# ==========================================
# 2. The Series filter
# ==========================================
def test_non_EQ_series_rows_are_dropped(patched):
    """Before ~2003 several names traded in two series at once, so an
    unfiltered pull carries two rows per date -- 442 of RELIANCE's 6,863."""
    patched["rows"] = [
        _row("03-Jan-2000", "251.70", series="EQ", volume="44,56,424"),
        _row("03-Jan-2000", "251.70", series="BL", volume="61,300"),
        _row("04-Jan-2000", "271.85", series="EQ", volume="94,87,878"),
    ]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert len(df) == 2
    assert df["datetime"].duplicated().sum() == 0
    assert df["volume"].tolist() == [4456424, 9487878]


def test_a_repeated_date_within_EQ_keeps_the_higher_volume_row(patched):
    patched["rows"] = [
        _row("03-Jan-2000", "251.70", volume="61,300"),
        _row("03-Jan-2000", "252.90", volume="44,56,424"),
    ]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert len(df) == 1
    assert df["volume"].iloc[0] == 4456424
    assert df["close"].iloc[0] == 252.90


# ==========================================
# 3. Ordering and dtypes
# ==========================================
def test_output_is_sorted_ascending_by_date(patched):
    """The feed arrives unsorted and not monotonic in either direction."""
    patched["rows"] = [_row("05-Jan-2020", "103"), _row("01-Jan-2020", "100"),
                       _row("03-Jan-2020", "101")]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert df["datetime"].is_monotonic_increasing
    assert df["close"].tolist() == [100.0, 101.0, 103.0]


def test_datetime_is_datetime64_not_a_string(patched):
    """The yfinance path returns datetime64; a type mismatch between the two
    sources is a train/serve inconsistency waiting to happen."""
    patched["rows"] = [_row("01-Jan-2020", "100")]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert pd.api.types.is_datetime64_any_dtype(df["datetime"])


def test_indian_grouped_numbers_are_parsed(patched):
    """NSE formats volume as '44,56,424' (lakh grouping), not '4,456,424'."""
    patched["rows"] = [_row("01-Jan-2020", "1,234.50", volume="44,56,424")]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert df["close"].iloc[0] == 1234.50
    assert df["volume"].iloc[0] == 4456424


def test_zero_or_negative_close_rows_are_dropped(patched):
    patched["rows"] = [_row("01-Jan-2020", "0"), _row("02-Jan-2020", "100")]
    df = gd.get_stock_data_using_nselib("Test Co")
    assert len(df) == 1 and df["close"].iloc[0] == 100.0


# ==========================================
# 4. Adjustment, and honesty about it
# ==========================================
def test_a_split_is_adjusted_away(patched):
    """The whole point: an unadjusted 10:1 split reads as -90%."""
    patched["rows"] = [_row("01-Jan-2020", "1000"), _row("02-Jan-2020", "1000"),
                       _row("03-Jan-2020", "100"), _row("06-Jan-2020", "100")]
    patched["actions"] = pd.DataFrame([{
        "symbol": "TEST", "ex_date": pd.Timestamp("2020-01-03"),
        "factor": 10.0, "dividend": 0.0, "rights_ratio": 0.0,
        "rights_price": 0.0, "subject": "Face Value Split"}])
    df = gd.get_stock_data_using_nselib("Test Co")
    r = np.diff(np.log(df["adj_close"].to_numpy()))
    assert np.abs(r).max() < 1e-9                     # adjusted: flat
    raw = np.diff(np.log(df["close"].to_numpy()))
    assert raw.min() < -2.0                           # unadjusted: broken
    assert df.attrs["price_adjustment"]["adjusted"] is True
    assert df.attrs["price_adjustment"]["n_actions"] == 1


def test_adjust_false_declares_itself_unadjusted(patched):
    patched["rows"] = [_row("01-Jan-2020", "100"), _row("02-Jan-2020", "101")]
    df = gd.get_stock_data_using_nselib("Test Co", adjust=False)
    assert np.allclose(df["adj_close"], df["close"])
    assert df.attrs["price_adjustment"]["adjusted"] is False


def test_a_failed_action_fetch_degrades_loudly_not_silently(patched):
    """Serving unadjusted prices AS 'adj_close' without saying so is the bug
    this module replaces. A feed failure must be declared, not hidden."""
    patched["rows"] = [_row("01-Jan-2020", "100"), _row("02-Jan-2020", "101")]
    patched["raised"] = RuntimeError("NSE unreachable")
    df = gd.get_stock_data_using_nselib("Test Co")
    assert np.allclose(df["adj_close"], df["close"])
    st = df.attrs["price_adjustment"]
    assert st["adjusted"] is False
    assert "RuntimeError" in st["reason"]


def test_actions_for_other_symbols_are_ignored(patched):
    """corporate_actions returns the whole market; only this name's events
    may be applied."""
    patched["rows"] = [_row("01-Jan-2020", "100"), _row("02-Jan-2020", "100"),
                       _row("03-Jan-2020", "100")]
    patched["actions"] = pd.DataFrame([{
        "symbol": "SOMEONEELSE", "ex_date": pd.Timestamp("2020-01-02"),
        "factor": 10.0, "dividend": 0.0, "rights_ratio": 0.0,
        "rights_price": 0.0, "subject": "Face Value Split"}])
    df = gd.get_stock_data_using_nselib("Test Co")
    assert np.allclose(df["adj_close"], df["close"])


# ==========================================
# 5. Failure modes return a message, never a broken frame
# ==========================================
def test_unknown_company_returns_a_message(patched, monkeypatch):
    monkeypatch.setattr(gd, "get_ticker", lambda name: None)
    out = gd.get_stock_data_using_nselib("No Such Co")
    assert isinstance(out, str) and "No NSE symbol" in out


def test_empty_feed_returns_a_message(patched):
    patched["rows"] = []
    out = gd.get_stock_data_using_nselib("Test Co")
    assert isinstance(out, str) and "No data found" in out
