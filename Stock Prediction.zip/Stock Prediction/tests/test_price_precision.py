"""
Tests for the price-precision check in :mod:`data_quality`.

Buzzelli, *Data Quality Engineering in Financial Services*, Ch. 3, names eight
data-quality dimensions. Seven of them were already checked here; **precision**
was not, and it is the one that fails quietly: a coarse price grid does not
produce a missing value or a bad OHLC row, it produces a return series that
looks fine and is partly made of the tick.

The quantity tested is the tick as a share of **one daily standard deviation**,
not the tick in rupees and not the tick as a fraction of price. NSE's Rs 0.05
grid is 0.002% of a Rs 3,000 share and 2% of a Rs 2.40 one, so only the
volatility-relative form separates the two cases.
"""

import numpy as np
import pandas as pd
import pytest

import data_quality as dq


def _series(prices, start="2021-01-04"):
    idx = pd.bdate_range(start, periods=len(prices))
    p = np.asarray(prices, dtype=float)
    return pd.DataFrame({"datetime": idx, "open": p, "high": p * 1.002,
                         "low": p * 0.998, "close": p, "adj_close": p,
                         "volume": 1e6})


def _walk(n=400, level=1000.0, sigma=0.02, tick=0.05, seed=0):
    """A random walk snapped to a price grid, the way an exchange quotes it."""
    rng = np.random.default_rng(seed)
    p = level * np.exp(np.cumsum(rng.standard_normal(n) * sigma))
    return np.round(p / tick) * tick


def _assess(df):
    return dq.assess_data_quality(df, interval="1d",
                                  now=df["datetime"].iloc[-1])


def _code(report, code="COARSE_PRICE_GRID"):
    return next((c for c in report.codes if c["code"] == code), None)


# ==========================================
# 1. The measurement
# ==========================================
def test_a_liquid_price_shows_a_negligible_grid():
    rep = _assess(_series(_walk(level=3000.0, sigma=0.02)))
    assert rep.checks["tick_share_of_daily_move"] < 0.01
    assert _code(rep) is None


def test_a_penny_stock_grid_is_flagged():
    # Rs 2.40 on a Rs 0.05 tick: the step is ~2% of price against a ~5% day.
    rep = _assess(_series(_walk(level=2.40, sigma=0.05)))
    assert rep.checks["tick_share_of_daily_move"] > 0.15
    hit = _code(rep)
    assert hit is not None and hit["severity"] == dq.WARN


def test_the_measure_is_volatility_relative_not_price_relative():
    """
    Two names on the same Rs 0.05 grid at the same price, one twice as
    volatile. The grid matters less to the volatile one, and a check that
    looked only at tick/price could not tell them apart.
    """
    calm = _assess(_series(_walk(level=20.0, sigma=0.01, seed=1)))
    wild = _assess(_series(_walk(level=20.0, sigma=0.06, seed=1)))
    c = calm.checks["tick_share_of_daily_move"]
    w = wild.checks["tick_share_of_daily_move"]
    # 6x the volatility, but only ~2.9x the measured share: heavy quantisation
    # inflates the realised standard deviation it is divided by, so the measure
    # UNDERSTATES a coarse grid rather than overstating it. That is the safe
    # direction for a warning, and worth pinning so it is not "fixed" later.
    assert c > 2.5 * w
    # Both are on a coarse-ish grid; only the calm one is bad enough to warn.
    assert _code(calm)["severity"] == dq.WARN
    assert _code(wild)["severity"] == dq.INFO


def test_the_implied_tick_is_recovered():
    rep = _assess(_series(_walk(level=50.0, tick=0.05, sigma=0.03)))
    assert rep.checks["implied_tick"] == pytest.approx(0.05, abs=1e-6)


def test_a_finer_grid_lowers_the_measure():
    coarse = _assess(_series(_walk(level=10.0, tick=0.05, sigma=0.02, seed=2)))
    fine = _assess(_series(_walk(level=10.0, tick=0.01, sigma=0.02, seed=2)))
    assert (fine.checks["tick_share_of_daily_move"]
            < coarse.checks["tick_share_of_daily_move"])


# ==========================================
# 2. Severity boundaries
# ==========================================
def test_severity_escalates_with_the_grid():
    # Constructed to straddle the two thresholds rather than to be realistic.
    mild = _assess(_series(_walk(level=13.0, sigma=0.025, seed=3)))
    bad = _assess(_series(_walk(level=3.0, sigma=0.05, seed=3)))
    m, b = _code(mild), _code(bad)
    assert m is None or m["severity"] in (dq.INFO, dq.WARN)
    assert b is not None and b["severity"] == dq.WARN
    assert (bad.checks["tick_share_of_daily_move"]
            > mild.checks["tick_share_of_daily_move"])


def test_the_thresholds_are_ordered():
    assert 0 < dq._TICK_SHARE_WARN < dq._TICK_SHARE_CRITICAL < 1


# ==========================================
# 3. It must not break anything else
# ==========================================
def test_a_flat_price_does_not_divide_by_zero():
    # Zero volatility: the share is undefined, not infinite.
    rep = _assess(_series([100.0] * 300))
    assert "tick_share_of_daily_move" not in rep.checks
    assert np.isfinite(rep.score)


def test_a_short_series_is_skipped_silently():
    rep = _assess(_series(_walk(n=25, level=3.0)))
    assert "tick_share_of_daily_move" not in rep.checks


def test_non_positive_prices_do_not_reach_the_log():
    p = _walk(n=200, level=50.0)
    p[40] = 0.0
    rep = _assess(_series(p))
    assert np.isfinite(rep.score)
    share = rep.checks.get("tick_share_of_daily_move")
    assert share is None or np.isfinite(share)


def test_a_coarse_grid_alone_does_not_force_abstention():
    """
    A penny stock is still forecastable, just noisily. The flag informs the
    reader; it must not silently take the app offline, which would be a
    behaviour change dressed up as a data-quality check.
    """
    rep = _assess(_series(_walk(level=2.40, sigma=0.05)))
    assert rep.mode in ("normal", "warn")
    assert rep.ok
