"""
Tests for :mod:`microstructure` -- AFML Ch. 19 estimators from daily OHLCV.

The estimators are Corwin & Schultz (2012) for the bid-ask spread, Roll (1984)
for the effective spread, and Amihud/Kyle for price impact.

The tests that carry the most weight are the ones pinning behaviour that was
discovered rather than assumed:

* ``test_corwin_schultz_is_biased_upward_by_volatility`` -- the estimator
  reports ~0.26*sigma of spread when the true spread is **zero**. Quoting the
  raw number as a transaction cost would overstate costs.
* ``test_overnight_adjustment_preserves_bar_height`` -- AFML's Snippet 19.1
  omits the gap correction the original paper specifies; without it gamma is
  inflated by overnight moves and the estimate collapses.
* ``test_null_correction_recovers_a_known_spread`` and
  ``test_null_correction_errs_conservative`` -- the calibrated estimate is a
  *lower* bound, which is the safe direction for a cost study.
"""

import numpy as np
import pandas as pd
import pytest

import microstructure as ms


# ==========================================
# helpers
# ==========================================
def _bars(n=3000, sigma=0.02, steps=1000, spread=0.0, seed=0, gap=0.0):
    """
    Synthetic bars with a KNOWN spread.

    The high trades at the ask and the low at the bid, which is the assumption
    Corwin-Schultz is built on, so the true spread is exactly ``spread``.
    ``gap`` injects an overnight jump between bars.
    """
    rng = np.random.default_rng(seed)
    z = rng.standard_normal((n, steps)) * sigma / np.sqrt(steps)
    path = np.cumsum(z, axis=1)
    c = np.exp(path[:, -1])
    h = np.exp(path.max(axis=1))
    l = np.exp(path.min(axis=1))
    lvl = np.cumprod(np.r_[1.0, c])[:-1]
    if gap:
        jump = np.exp(rng.standard_normal(n) * gap)
        lvl = lvl * np.cumprod(jump)
    return pd.DataFrame({"open": lvl, "high": lvl * h * (1 + spread / 2),
                         "low": lvl * l * (1 - spread / 2),
                         "close": lvl * c})


# ==========================================
# 1. Constants and contract
# ==========================================
def test_constants_match_the_published_estimator():
    assert ms._DEN == pytest.approx(3 - 2 * np.sqrt(2))
    assert ms._K2 == pytest.approx(np.sqrt(8 / np.pi))


def test_missing_columns_raise_rather_than_returning_zero():
    """A silent zero would read as free trading in a cost study."""
    with pytest.raises(ValueError, match="needs a 'high'"):
        ms.corwin_schultz(pd.DataFrame({"low": [1.0], "close": [1.0]}))
    with pytest.raises(ValueError, match="gap_adjust"):
        ms.corwin_schultz(pd.DataFrame({"high": [2.0], "low": [1.0]}))


def test_amihud_requires_an_adjusted_price():
    with pytest.raises(ValueError, match="adj_close"):
        ms.amihud_lambda(pd.DataFrame({"close": [1.0], "volume": [1.0]}))


# ==========================================
# 2. The upward bias -- the central caveat
# ==========================================
@pytest.mark.parametrize("sigma", [0.005, 0.01, 0.02])
def test_corwin_schultz_is_biased_upward_by_volatility(sigma):
    """With a TRUE spread of zero the estimator still reports ~0.26*sigma.
    It attributes part of the price range to a spread that is not there."""
    df = _bars(n=2000, sigma=sigma, spread=0.0, seed=1)
    _, info = ms.corwin_schultz(df)
    assert info["median"] > 0.15 * sigma
    assert info["median"] < 0.45 * sigma


def test_the_bias_is_proportional_to_volatility():
    """Doubling volatility roughly doubles the spurious spread -- which is why
    a single additive constant cannot correct it and the null is simulated at
    the series' own volatility instead."""
    lo = ms.corwin_schultz(_bars(n=2000, sigma=0.01, seed=2))[1]["median"]
    hi = ms.corwin_schultz(_bars(n=2000, sigma=0.02, seed=2))[1]["median"]
    assert hi / lo == pytest.approx(2.0, rel=0.35)


def test_it_still_tracks_a_real_spread_roughly_one_for_one():
    """The bias is additive, not multiplicative: the estimator does respond to
    genuine spread. That is what makes a null correction worth doing."""
    base = ms.corwin_schultz(_bars(n=2000, spread=0.0, seed=3))[1]["median"]
    wide = ms.corwin_schultz(_bars(n=2000, spread=0.01, seed=3))[1]["median"]
    assert (wide - base) == pytest.approx(0.01, rel=0.35)


# ==========================================
# 3. The null correction
# ==========================================
def test_null_correction_recovers_a_known_spread():
    df = _bars(n=3000, sigma=0.02, spread=0.005, seed=4)
    r = ms.corwin_schultz_adjusted(df)
    assert r["adjusted_bp"] == pytest.approx(50.0, abs=20.0)
    assert r["raw_bp"] > r["adjusted_bp"]          # raw is an upper bound


def test_null_correction_returns_zero_when_there_is_no_spread():
    df = _bars(n=3000, sigma=0.02, spread=0.0, seed=5)
    assert ms.corwin_schultz_adjusted(df)["adjusted_bp"] < 12.0


def test_null_correction_errs_conservative():
    """It UNDER-states, because the volatility used to calibrate the null is
    itself inflated by the spread. For a cost study that is the safe direction:
    if even the understated spread exceeds a breakeven, the conclusion holds."""
    true_bp = 100.0
    r = ms.corwin_schultz_adjusted(_bars(n=3000, spread=true_bp / 1e4, seed=6))
    assert r["adjusted_bp"] < true_bp
    assert r["adjusted_bp"] > 0.5 * true_bp


# ==========================================
# 4. Overnight gaps -- the omission in AFML's snippet
# ==========================================
def test_overnight_adjustment_preserves_bar_height():
    """Sliding a bar to meet the previous close must not change its range --
    the range is what carries the spread."""
    h = np.array([100.0, 120.0, 80.0])
    l = np.array([98.0, 118.0, 78.0])
    c = np.array([99.0, 119.0, 79.0])
    ah, al = ms.overnight_adjust(h, l, c)
    assert np.allclose(ah - al, h - l)


def test_overnight_adjustment_closes_the_gap():
    h = np.array([100.0, 120.0])
    l = np.array([98.0, 118.0])
    c = np.array([99.0, 119.0])
    ah, al = ms.overnight_adjust(h, l, c)
    assert al[1] == pytest.approx(99.0)            # low meets the prior close
    assert ah[1] == pytest.approx(101.0)


def test_first_bar_is_untouched_having_no_previous_close():
    h, l, c = np.array([100.0, 120.0]), np.array([98.0, 118.0]), np.array([99.0, 119.0])
    ah, al = ms.overnight_adjust(h, l, c)
    assert ah[0] == 100.0 and al[0] == 98.0


def test_gaps_deflate_the_estimate_when_left_uncorrected():
    """A gap sits inside the two-bar range and inside neither one-bar range, so
    it inflates gamma alone -- pushing alpha, and the spread, down."""
    df = _bars(n=2000, spread=0.005, gap=0.02, seed=8)
    with_adj = ms.corwin_schultz(df, gap_adjust=True)[1]["median"]
    without = ms.corwin_schultz(df, gap_adjust=False)[1]["median"]
    assert with_adj > without


# ==========================================
# 5. Scale invariance
# ==========================================
def test_the_spread_estimate_is_immune_to_corporate_actions():
    """Every term is a ratio within or across adjacent bars, so a pure
    rescaling cancels -- the same property range_volatility relies on."""
    df = _bars(n=800, spread=0.004, seed=9)
    split = df.copy()
    split.iloc[400:] = split.iloc[400:] / 10.0
    a = ms.corwin_schultz(df)[1]["median"]
    b = ms.corwin_schultz(split)[1]["median"]
    assert a == pytest.approx(b, rel=0.10)


# ==========================================
# 6. Roll, Amihud, Kyle
# ==========================================
def test_roll_is_undefined_when_the_covariance_is_positive():
    """Roll's model needs NEGATIVE autocovariance in price changes. A series
    with momentum has positive, and the spread is then undefined -- NaN, not
    zero, because zero would read as a free trade.

    A perfectly linear ramp is NOT the right fixture here: its price changes
    are constant, so the covariance is numerical noise around zero rather than
    meaningfully positive. An AR(1) with a positive coefficient is."""
    rng = np.random.default_rng(20)
    r = np.zeros(600)
    for i in range(1, 600):
        r[i] = 0.6 * r[i - 1] + rng.standard_normal() * 0.01
    price = 100 * np.exp(np.cumsum(r))
    spread, info = ms.roll_spread(price, window=21)
    assert info["undefined_rate"] > 0.8
    assert np.isnan(spread[np.isfinite(spread)]).all() or \
        np.isfinite(spread).mean() < 0.2


def test_roll_reports_its_own_failure_rate():
    df = _bars(n=500, seed=10)
    _, info = ms.roll_spread(df["close"].values)
    assert 0.0 <= info["undefined_rate"] <= 1.0


def test_amihud_rises_as_liquidity_falls():
    """Same returns, a tenth of the volume, ten times the impact."""
    n = 400
    rng = np.random.default_rng(11)
    p = 100 * np.exp(np.cumsum(rng.standard_normal(n) * 0.01))
    liq = pd.DataFrame({"adj_close": p, "volume": np.full(n, 1e6)})
    thin = pd.DataFrame({"adj_close": p, "volume": np.full(n, 1e5)})
    a = np.nanmean(ms.amihud_lambda(liq))
    b = np.nanmean(ms.amihud_lambda(thin))
    assert b == pytest.approx(10 * a, rel=0.01)


def test_kyle_lambda_runs_and_is_finite_on_ordinary_data():
    df = _bars(n=400, seed=12)
    df["adj_close"] = df["close"]
    df["volume"] = 1e6
    lam = ms.kyle_lambda(df)
    assert np.isfinite(lam[-50:]).any()


# ==========================================
# 7. Reporting
# ==========================================
def test_summary_reports_the_diagnostics_not_just_the_number():
    """floor_rate and undefined_rate say how far to trust each estimate; a
    report that omitted them would present a broken estimator as a clean one."""
    s = ms.spread_summary(_bars(n=600, spread=0.003, seed=13))
    for k in ("cs_median_bp", "cs_floor_rate", "roll_undefined_rate"):
        assert k in s
    txt = ms.format_report([dict(s, symbol="TEST")])
    assert "floored" in txt and "TEST" in txt


def test_becker_parkinson_is_a_volatility_not_a_variance():
    df = _bars(n=1500, sigma=0.02, seed=14)
    v = ms.becker_parkinson_vol(df)
    assert np.nanmedian(v) == pytest.approx(0.02, rel=0.8)
