"""
Tests for ``strategy_metrics`` — the economic (investment-strategy) evaluation.

Covers the book Ch. 3 metric set: cumulative returns, Sharpe, Sortino,
information ratio, maximum drawdown, information coefficient, plus the
cost-aware strategy bundle and the "does a perfect/useless forecast score the
way it should?" sanity checks.

Network-free and deterministic. Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np

import strategy_metrics as sm


# ── Building blocks ─────────────────────────────────────────────────────────
def test_cumulative_returns_compounds():
    r = [0.10, -0.10, 0.20]
    curve = sm.cumulative_returns(r)
    assert len(curve) == 4 and curve[0] == 1.0
    assert np.isclose(curve[-1], 1.10 * 0.90 * 1.20)
    assert np.isclose(sm.total_return(r), 1.10 * 0.90 * 1.20 - 1.0)


def test_annualized_return_matches_known_case():
    # 12 periods of +1% at 12 periods/year == one year of compounding.
    r = [0.01] * 12
    ann = sm.annualized_return(r, 12)
    assert np.isclose(ann, 1.01 ** 12 - 1.0, atol=1e-9)


def test_sharpe_scales_with_frequency():
    rng = np.random.default_rng(0)
    r = rng.normal(0.0005, 0.01, 1000)
    s_daily = sm.sharpe_ratio(r, 252)
    s_hourly = sm.sharpe_ratio(r, 252 * 7)
    # Same stream, higher assumed frequency -> larger annualised Sharpe.
    assert s_hourly > s_daily > 0
    assert np.isclose(s_hourly / s_daily, np.sqrt(7.0), rtol=1e-6)


def test_sharpe_undefined_on_constant_stream():
    # No dispersion => dividing by ~0 would manufacture a huge number.
    assert np.isnan(sm.sharpe_ratio([0.01] * 50, 252))
    assert np.isnan(sm.sharpe_ratio([0.01], 252))          # too short


def test_sharpe_standard_error_is_annualised():
    # The annualisation factor is the point: a bare 1/sqrt(n) understates the
    # error by sqrt(periods_per_year) and makes noise look like a discovery.
    se_weekly = sm.sharpe_standard_error(0.0, 8, 50.4)
    assert np.isclose(se_weekly, np.sqrt(50.4 / 8), rtol=1e-6)
    assert se_weekly > 2.0                       # 8 trades => SE ~ 2.5
    # More observations shrink it; a larger |Sharpe| inflates it slightly.
    assert sm.sharpe_standard_error(0.0, 200, 50.4) < se_weekly
    assert sm.sharpe_standard_error(3.0, 8, 50.4) > se_weekly
    assert np.isnan(sm.sharpe_standard_error(1.0, 1, 252))


def test_sharpe_significance_flag_is_conservative():
    rng = np.random.default_rng(11)
    # 8 weekly trades of pure noise must never be flagged significant.
    real = rng.normal(0, 0.03, 8)
    res = sm.evaluate_strategy(rng.normal(0, 0.03, 8), real, periods_per_bar=5)
    assert res["sharpe_se"] > 1.0
    assert res["sharpe_significant"] is False
    # Even a perfect oracle over 8 trades is not statistically distinguishable.
    oracle = sm.evaluate_strategy(real, real, cost_bps=0.0, periods_per_bar=5)
    assert oracle["sharpe"] > 0
    assert oracle["sharpe_significant"] in (True, False)   # reported, not assumed
    assert np.isfinite(oracle["sharpe_se"])


def test_sortino_exceeds_sharpe_when_upside_dominates():
    # Big positive outliers inflate total vol but not downside deviation.
    r = np.array([0.01] * 40 + [0.30, 0.25] + [-0.005] * 8)
    assert sm.sortino_ratio(r, 252) > sm.sharpe_ratio(r, 252)


def test_sortino_nan_without_downside():
    assert np.isnan(sm.sortino_ratio([0.01, 0.02, 0.03], 252))


def test_max_drawdown_known_path():
    # 1.0 -> 1.2 -> 0.9 -> 1.35 : worst drawdown is 0.9/1.2 - 1 = -25%.
    r = [0.20, -0.25, 0.50]
    dd = sm.max_drawdown(r)
    assert np.isclose(dd['max_drawdown'], 0.9 / 1.2 - 1.0)
    assert dd['peak_index'] == 1 and dd['trough_index'] == 2
    assert dd['recovery_index'] == 3                       # regains the peak


def test_max_drawdown_zero_when_monotone():
    dd = sm.max_drawdown([0.01] * 20)
    assert np.isclose(dd['max_drawdown'], 0.0)
    assert np.isnan(sm.calmar_ratio([0.01] * 20, 252))     # nothing to divide by


def test_information_ratio_zero_against_itself():
    rng = np.random.default_rng(1)
    r = rng.normal(0, 0.01, 300)
    assert np.isnan(sm.information_ratio(r, r, 252))        # zero tracking error


def test_information_ratio_positive_with_constant_alpha():
    rng = np.random.default_rng(2)
    b = rng.normal(0, 0.01, 300)
    a = b + 0.001                                          # constant outperformance
    assert np.isnan(sm.information_ratio(a, b, 252)) or \
        sm.information_ratio(a, b, 252) > 0


def test_hit_rate_and_profit_factor():
    r = [0.02, -0.01, 0.03, -0.04, 0.0]
    assert np.isclose(sm.hit_rate(r), 2 / 4)               # zeros excluded
    assert np.isclose(sm.profit_factor(r), 0.05 / 0.05)


# ── Information coefficient ────────────────────────────────────────────────
def test_ic_perfect_and_inverted():
    x = np.array([0.01, -0.02, 0.03, -0.01, 0.005])
    assert np.isclose(sm.information_coefficient(x, x), 1.0)
    assert np.isclose(sm.information_coefficient(x, -x), -1.0)


def test_rank_ic_robust_to_a_single_outlier():
    rng = np.random.default_rng(3)
    pred = rng.normal(0, 1, 200)
    real = pred + rng.normal(0, 0.5, 200)
    # Inject one huge, wrong-signed point: Pearson IC drops far more than rank IC.
    pred_o, real_o = pred.copy(), real.copy()
    pred_o[0], real_o[0] = 50.0, -50.0
    drop_pearson = (sm.information_coefficient(pred, real)
                    - sm.information_coefficient(pred_o, real_o))
    drop_rank = (sm.rank_information_coefficient(pred, real)
                 - sm.rank_information_coefficient(pred_o, real_o))
    assert drop_pearson > drop_rank


def test_rankdata_handles_ties():
    ranks = sm._rankdata([10.0, 20.0, 20.0, 30.0])
    assert np.allclose(ranks, [1.0, 2.5, 2.5, 4.0])


def test_ic_t_stat_grows_with_sample():
    assert sm.ic_t_stat(0.1, 1000) > sm.ic_t_stat(0.1, 50)
    assert np.isnan(sm.ic_t_stat(float('nan'), 100))


# ── Position rules ─────────────────────────────────────────────────────────
def test_position_sign_and_deadband():
    pred = np.array([0.02, -0.001, 0.0005, -0.03])
    assert np.allclose(sm.position_from_signal(pred), [1, -1, 1, -1])
    banded = sm.position_from_signal(pred, mode='deadband', deadband=0.005)
    assert np.allclose(banded, [1, 0, 0, -1])              # small calls -> flat


def test_position_scaled_is_clipped():
    pred = np.array([-5.0, 0.0, 5.0])
    pos = sm.position_from_signal(pred, mode='scaled', scale=1.0)
    assert pos.min() >= -1.0 and pos.max() <= 1.0


# ── The bundle ─────────────────────────────────────────────────────────────
def _oracle_and_noise(n=200, seed=4):
    rng = np.random.default_rng(seed)
    real = rng.normal(0.0, 0.02, n)
    return real, rng.normal(0.0, 0.02, n)


def test_perfect_foresight_beats_random_forecast():
    real, noise = _oracle_and_noise()
    good = sm.evaluate_strategy(real, real, cost_bps=0.0)     # oracle
    bad = sm.evaluate_strategy(noise, real, cost_bps=0.0)     # unrelated
    assert good['total_return'] > bad['total_return']
    assert good['sharpe'] > bad['sharpe']
    assert np.isclose(good['information_coefficient'], 1.0)
    assert np.isclose(good['directional_hit_rate'], 1.0)
    # An oracle that is always on the right side never draws down.
    assert good['max_drawdown'] > -1e-9


def test_costs_reduce_net_return_and_are_accounted():
    real, _ = _oracle_and_noise()
    free = sm.evaluate_strategy(real, real, cost_bps=0.0)
    paid = sm.evaluate_strategy(real, real, cost_bps=50.0)
    assert paid['total_return'] < free['total_return']
    assert paid['total_cost'] > 0
    # Gross is unaffected by the cost assumption; only net moves.
    assert np.isclose(paid['gross_total_return'], free['gross_total_return'])


def test_deadband_cuts_turnover():
    rng = np.random.default_rng(5)
    real = rng.normal(0, 0.02, 300)
    pred = rng.normal(0, 0.002, 300)                        # mostly tiny calls
    plain = sm.evaluate_strategy(pred, real, mode='sign')
    banded = sm.evaluate_strategy(pred, real, mode='deadband', deadband=0.003)
    assert banded['avg_turnover'] < plain['avg_turnover']


def test_benchmark_is_buy_and_hold_on_same_periods():
    real, noise = _oracle_and_noise()
    res = sm.evaluate_strategy(noise, real, cost_bps=0.0)
    expected = float(np.prod(1.0 + np.expm1(real)) - 1.0)
    assert np.isclose(res['benchmark_total_return'], expected)


def test_report_renders_without_error():
    real, noise = _oracle_and_noise()
    text = sm.format_strategy_report(
        sm.evaluate_strategy(noise, real), name='unit-test')
    assert 'Strategy evaluation' in text and 'Sharpe' in text
    assert 'buy-and-hold' in text


def test_handles_degenerate_inputs():
    empty = sm.evaluate_strategy([], [])
    assert empty['n_periods'] == 0
    # NaN forecasts must not crash and must not take a position.
    res = sm.evaluate_strategy([np.nan] * 5, [0.01] * 5)
    assert np.allclose(res['positions'], 0.0)
    assert np.isclose(res['total_return'], 0.0)


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All strategy-metric tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
