"""
Tests for :mod:`bhavcopy` — point-in-time NSE prices and corporate-action
adjustment.

Everything here runs **offline**. The fetch layer takes an injected
``fetch_fn``/``session``, and the parsers take raw bytes or frames, so no test
touches the network. That is deliberate: a suite that silently depends on NSE
being reachable fails for reasons that have nothing to do with the code.

The tests that matter most are the ones guarding mistakes already made once:

* ``test_same_day_actions_compound`` — GPIL filed a split *and* a bonus on
  2021-10-26. Treating same-date actions as one event understates the factor by
  2x and produced an 82% error during validation.
* ``test_liquidity_screen_ignores_data_after_as_of`` — screening on liquidity
  measured inside the study window selects names using information from the test
  period.
* ``test_as_of_excludes_future_actions`` — the point-in-time guarantee that
  ``tests/audit_price_adjustment.py`` showed yfinance cannot give us.
"""

import io
import zipfile

import numpy as np
import pandas as pd
import pytest

import bhavcopy as bc


# ==========================================
# helpers
# ==========================================
def _flat_panel(symbol="AAA", start="2020-01-01", periods=8, close=100.0,
                turnover=1e8, volume=1000):
    """A constant-price panel, so any movement in adj_close is the adjustment."""
    days = pd.bdate_range(start, periods=periods)
    return pd.DataFrame({
        "datetime": days,
        "symbol": symbol,
        "open": close, "high": close, "low": close, "close": close,
        "prevclose": close, "volume": volume, "turnover": turnover,
    })


def _action(symbol, ex_date, factor=1.0, dividend=0.0, rights_ratio=0.0,
            rights_price=0.0, subject="synthetic"):
    return {"symbol": symbol, "ex_date": pd.Timestamp(ex_date),
            "factor": factor, "dividend": dividend,
            "rights_ratio": rights_ratio, "rights_price": rights_price,
            "subject": subject}


def _legacy_zip(rows):
    """Build legacy-format bhavcopy zip bytes from a list of dicts."""
    df = pd.DataFrame(rows)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("cm01JAN2020bhav.csv", df.to_csv(index=False))
    return buf.getvalue()


# ==========================================
# 1. Subject-line parsing
# ==========================================
def test_parses_a_plain_bonus():
    # 1 new share for every 4 held -> 5 shares where there were 4.
    assert bc.parse_action("Bonus 1:4")["factor"] == pytest.approx(1.25)
    assert bc.parse_action("Bonus 1:1")["factor"] == pytest.approx(2.0)
    assert bc.parse_action("Bonus 2:5")["factor"] == pytest.approx(1.4)


def test_parses_a_face_value_split():
    s = "Face Value Split From Rs 10/- Per Share To Rs 2/- Per Share"
    assert bc.parse_action(s)["factor"] == pytest.approx(5.0)


def test_parses_the_sub_division_wording_and_the_Re_spelling():
    """NSE writes 'Re 1/-' for one rupee and 'Rs' elsewhere, and inserts
    '(Sub-Division) -' in some records. Both variants are real."""
    s = ("Face Value Split (Sub-Division) - From Rs 10/- Per Share "
         "To Re 1/- Per Share")
    assert bc.parse_action(s)["factor"] == pytest.approx(10.0)


def test_parses_a_compound_bonus_and_split_in_one_subject():
    s = ("Bonus 1:2/Face Value Split (Sub-Division) From Rs 2/- Per Share "
         "To Re 1/- Per Share")
    # bonus 1:2 -> x1.5, split 2 -> 1 -> x2, compounding to x3.
    assert bc.parse_action(s)["factor"] == pytest.approx(3.0)


def test_parses_dividends_including_the_Re_dash_wording():
    assert bc.parse_action("Interim Dividend Rs 2/- Per Share")["dividend"] \
        == pytest.approx(2.0)
    assert bc.parse_action("Dividend- Re 6 Per Share (Rate Revised)")["dividend"] \
        == pytest.approx(6.0)
    assert bc.parse_action("Final Dividend Rs 1.50 Per Share")["dividend"] \
        == pytest.approx(1.50)


def test_unparseable_subjects_are_identity_not_an_error():
    """An AGM notice must adjust nothing. Returning a neutral result rather
    than raising means one odd string cannot abort a whole panel build."""
    for s in ["Annual General Meeting", "", None, "Scheme of Arrangement"]:
        r = bc.parse_action(s)
        assert r["factor"] == 1.0 and r["dividend"] == 0.0


def test_parses_a_rights_issue_including_the_awkward_spacings():
    """Regression: rights were the ONLY cause of disagreement with yfinance in
    the end-to-end audit -- BHARTIARTL 2019 and TATASTEEL 2018, the two names
    out of 24 that did not match at correlation 1.00000."""
    r = bc.parse_action("Rights 19:67 @ Premium Rs 215 Per Share")
    assert r["rights_ratio"] == pytest.approx(19 / 67)
    assert r["rights_premium"] == pytest.approx(215.0)

    # No space before '@'.
    r2 = bc.parse_action("Rights 588:1000@ Premium Rs 2/-")
    assert r2["rights_ratio"] == pytest.approx(0.588)
    assert r2["rights_premium"] == pytest.approx(2.0)

    # Words between the ratio and the '@'.
    r3 = bc.parse_action(
        "Rights - 4:25 Fully Paid Up Shares @ Premium Rs 500/- Per Share")
    assert r3["rights_ratio"] == pytest.approx(4 / 25)
    assert r3["rights_premium"] == pytest.approx(500.0)


def test_rights_do_not_leak_into_the_factor_or_the_dividend():
    r = bc.parse_action("Rights 1:23 @ Premium Rs 2378/-")
    assert r["factor"] == 1.0 and r["dividend"] == 0.0


def test_a_dividend_does_not_leak_into_the_price_factor():
    """Dividends and splits adjust differently -- absolute vs ratio -- so a
    cash dividend must never move `factor`."""
    r = bc.parse_action("Interim Dividend Rs 12/- Per Share")
    assert r["factor"] == 1.0
    assert r["dividend"] == pytest.approx(12.0)


# ==========================================
# 2. Back-adjustment
# ==========================================
def test_split_scales_history_down_and_leaves_the_present_alone():
    px = _flat_panel(periods=8)                       # 2020-01-01 .. 2020-01-10
    acts = pd.DataFrame([_action("AAA", "2020-01-06", factor=2.0)])
    out = bc.adjust_prices(px, acts)
    before = out[out["datetime"] < "2020-01-06"]["adj_close"]
    after = out[out["datetime"] >= "2020-01-06"]["adj_close"]
    assert np.allclose(before, 50.0)
    assert np.allclose(after, 100.0)


def test_dividend_adjustment_uses_the_close_before_the_ex_date():
    px = _flat_panel(periods=8, close=100.0)
    acts = pd.DataFrame([_action("AAA", "2020-01-06", dividend=5.0)])
    out = bc.adjust_prices(px, acts)
    before = out[out["datetime"] < "2020-01-06"]["adj_close"]
    assert np.allclose(before, 95.0)          # 100 * (1 - 5/100)


def test_same_day_actions_compound():
    """Regression: GPIL 2021-10-26 filed a 10->5 face value split AND a 1:1
    bonus as two separate records, true factor 4.0. Collapsing them to one
    event gives 2.0 -- an 82% error against the observed price drop."""
    px = _flat_panel(periods=8)
    acts = pd.DataFrame([
        _action("AAA", "2020-01-06", factor=2.0, subject="Face Value Split"),
        _action("AAA", "2020-01-06", factor=2.0, subject="Bonus 1:1"),
    ])
    out = bc.adjust_prices(px, acts)
    before = out[out["datetime"] < "2020-01-06"]["adj_close"]
    assert np.allclose(before, 25.0)          # 100 / (2 * 2)


def test_rights_adjustment_uses_the_theoretical_ex_rights_price():
    """1 new share for every 1 held at Rs 50, against a Rs 100 cum price:
    TERP = (100 + 1*50) / 2 = 75, so history scales by 0.75."""
    px = _flat_panel(periods=8, close=100.0)
    acts = pd.DataFrame([_action("AAA", "2020-01-06", rights_ratio=1.0,
                                 rights_price=50.0)])
    out = bc.adjust_prices(px, acts)
    before = out[out["datetime"] < "2020-01-06"]["adj_close"]
    assert np.allclose(before, 75.0)


def test_rights_at_the_market_price_are_a_no_op():
    """Issuing at the prevailing price is not dilution -- TERP equals the cum
    price and nothing should move. A formula that adjusts here is wrong."""
    px = _flat_panel(periods=8, close=100.0)
    acts = pd.DataFrame([_action("AAA", "2020-01-06", rights_ratio=0.5,
                                 rights_price=100.0)])
    out = bc.adjust_prices(px, acts)
    assert np.allclose(out["adj_close"], out["close"])


def test_as_of_excludes_future_actions():
    """The point-in-time guarantee. An origin on 2020-01-03 must not see an
    adjustment whose ex-date is 2020-01-06 -- that information did not exist."""
    px = _flat_panel(periods=8)
    acts = pd.DataFrame([_action("AAA", "2020-01-06", factor=2.0)])
    pit = bc.adjust_prices(px, acts, as_of="2020-01-03")
    assert np.allclose(pit["adj_close"], pit["close"])
    # ... and with no as_of, the same action *is* applied.
    full = bc.adjust_prices(px, acts)
    assert not np.allclose(full["adj_close"], full["close"])


def test_adjustment_is_per_symbol():
    """An action on one name must not touch another."""
    px = pd.concat([_flat_panel("AAA"), _flat_panel("BBB")], ignore_index=True)
    acts = pd.DataFrame([_action("AAA", "2020-01-06", factor=2.0)])
    out = bc.adjust_prices(px, acts)
    bbb = out[out["symbol"] == "BBB"]
    assert np.allclose(bbb["adj_close"], bbb["close"])


def test_action_before_a_symbols_history_is_a_no_op():
    px = _flat_panel(start="2020-06-01", periods=5)
    acts = pd.DataFrame([_action("AAA", "2019-01-01", factor=2.0)])
    out = bc.adjust_prices(px, acts)
    assert np.allclose(out["adj_close"], out["close"])


def test_no_actions_leaves_prices_untouched():
    px = _flat_panel()
    for acts in (None, pd.DataFrame(columns=["symbol", "ex_date", "factor",
                                             "dividend", "subject"])):
        out = bc.adjust_prices(px, acts)
        assert np.allclose(out["adj_close"], out["close"])


def test_adjusted_returns_are_clean_across_a_split():
    """The whole point: the pipeline models log returns, and an unadjusted 1:10
    split reads as -90%. After adjustment the return across the ex-date is the
    real one (here: zero)."""
    px = _flat_panel(periods=8)
    px.loc[px["datetime"] >= "2020-01-06", ["close", "open", "high", "low"]] = 10.0
    acts = pd.DataFrame([_action("AAA", "2020-01-06", factor=10.0)])
    out = bc.adjust_prices(px, acts)
    r = np.diff(np.log(out["adj_close"].to_numpy()))
    assert np.abs(r).max() < 1e-12
    raw = np.diff(np.log(out["close"].to_numpy()))
    assert raw.min() < -2.0            # the unadjusted series really is broken


# ==========================================
# 3. Format readers
# ==========================================
def test_legacy_reader_keeps_only_the_EQ_series():
    """The legacy file carries government securities, treasury bills and the
    BE/BZ surveillance segments alongside ordinary equities."""
    rows = [
        {"SYMBOL": "RELIANCE", "SERIES": "EQ", "OPEN": 1, "HIGH": 1, "LOW": 1,
         "CLOSE": 100, "LAST": 1, "PREVCLOSE": 99, "TOTTRDQTY": 5,
         "TOTTRDVAL": 500, "TIMESTAMP": "01-JAN-2020", "TOTALTRADES": 1,
         "ISIN": "X"},
        {"SYMBOL": "718GS2033", "SERIES": "GS", "OPEN": 1, "HIGH": 1, "LOW": 1,
         "CLOSE": 101, "LAST": 1, "PREVCLOSE": 100, "TOTTRDQTY": 5,
         "TOTTRDVAL": 500, "TIMESTAMP": "01-JAN-2020", "TOTALTRADES": 1,
         "ISIN": "Y"},
        {"SYMBOL": "SOMESMALLCO", "SERIES": "BE", "OPEN": 1, "HIGH": 1,
         "LOW": 1, "CLOSE": 5, "LAST": 1, "PREVCLOSE": 5, "TOTTRDQTY": 5,
         "TOTTRDVAL": 25, "TIMESTAMP": "01-JAN-2020", "TOTALTRADES": 1,
         "ISIN": "Z"},
    ]
    out = bc.read_legacy(_legacy_zip(rows), "2020-01-01")
    assert out["symbol"].tolist() == ["RELIANCE"]
    assert list(out.columns) == bc.COLUMNS
    assert out["datetime"].iloc[0] == pd.Timestamp("2020-01-01")


def test_udiff_reader_keeps_only_cash_segment_stocks():
    raw = pd.DataFrame([
        {"TckrSymb": "RELIANCE", "SctySrs": "EQ", "FinInstrmTp": "STK",
         "OpnPric": 1, "HghPric": 1, "LwPric": 1, "ClsPric": 100,
         "PrvsClsgPric": 99, "TtlTradgVol": 5, "TtlTrfVal": 500},
        {"TckrSymb": "718GS2033", "SctySrs": "GS", "FinInstrmTp": "STK",
         "OpnPric": 1, "HghPric": 1, "LwPric": 1, "ClsPric": 101,
         "PrvsClsgPric": 100, "TtlTradgVol": 5, "TtlTrfVal": 500},
        {"TckrSymb": "NIFTY", "SctySrs": "EQ", "FinInstrmTp": "IDF",
         "OpnPric": 1, "HghPric": 1, "LwPric": 1, "ClsPric": 18000,
         "PrvsClsgPric": 17900, "TtlTradgVol": 5, "TtlTrfVal": 500},
    ])
    out = bc.read_udiff(raw, "2024-03-01")
    assert out["symbol"].tolist() == ["RELIANCE"]


def test_readers_agree_on_the_normalised_schema():
    """Legacy and UDiFF are different upstream formats; downstream code must
    not be able to tell which one it got."""
    legacy = bc.read_legacy(_legacy_zip([
        {"SYMBOL": "AAA", "SERIES": "EQ", "OPEN": 10, "HIGH": 12, "LOW": 9,
         "CLOSE": 11, "LAST": 11, "PREVCLOSE": 10, "TOTTRDQTY": 7,
         "TOTTRDVAL": 77, "TIMESTAMP": "01-JAN-2020", "TOTALTRADES": 1,
         "ISIN": "X"}]), "2020-01-01")
    udiff = bc.read_udiff(pd.DataFrame([
        {"TckrSymb": "AAA", "SctySrs": "EQ", "FinInstrmTp": "STK",
         "OpnPric": 10, "HghPric": 12, "LwPric": 9, "ClsPric": 11,
         "PrvsClsgPric": 10, "TtlTradgVol": 7, "TtlTrfVal": 77}]),
        "2020-01-01")
    pd.testing.assert_frame_equal(legacy, udiff, check_dtype=False)


def test_a_zero_close_is_dropped_as_a_data_error():
    rows = [{"SYMBOL": "AAA", "SERIES": "EQ", "OPEN": 0, "HIGH": 0, "LOW": 0,
             "CLOSE": 0, "LAST": 0, "PREVCLOSE": 0, "TOTTRDQTY": 0,
             "TOTTRDVAL": 0, "TIMESTAMP": "01-JAN-2020", "TOTALTRADES": 0,
             "ISIN": "X"}]
    assert len(bc.read_legacy(_legacy_zip(rows), "2020-01-01")) == 0


def test_legacy_url_matches_nses_layout():
    u = bc.legacy_url("2018-01-02")
    assert u.endswith("/2018/JAN/cm02JAN2018bhav.csv.zip")


# ==========================================
# 4. Range fetch
# ==========================================
def test_fetch_range_skips_holidays_without_interpolating():
    """A missing day is a closed market, not a gap to fill. NSE holidays are
    irregular, so they can only be discovered, never derived."""
    days_seen = []

    def fake(day):
        days_seen.append(pd.Timestamp(day))
        if pd.Timestamp(day).day % 2 == 0:
            return None                              # "holiday"
        return _flat_panel(start=day, periods=1)

    out, rep = bc.fetch_range("2020-01-01", "2020-01-10", fetch_fn=fake,
                              verbose=False)
    assert rep["n_missing"] > 0
    assert rep["n_days"] == len(days_seen)
    assert len(out) == rep["n_days"] - rep["n_missing"]
    # No fabricated dates.
    assert set(out["datetime"]).issubset(set(days_seen))


def test_fetch_range_reports_an_empty_window_honestly():
    out, rep = bc.fetch_range("2020-01-01", "2020-01-10",
                              fetch_fn=lambda d: None, verbose=False)
    assert len(out) == 0 and rep["n_rows"] == 0 and rep["n_symbols"] == 0
    assert list(out.columns) == bc.COLUMNS


# ==========================================
# 5. Universe screen
# ==========================================
def _screen_panel():
    px = []
    for sym, turn, vol in [("LIQ", 1e8, 1000), ("MID", 6e7, 1000),
                           ("ILLIQ", 1e6, 0)]:
        px.append(_flat_panel(sym, start="2019-06-01", periods=60,
                              turnover=turn, volume=vol))
    return pd.concat(px, ignore_index=True)


def test_liquidity_screen_drops_the_illiquid_tail():
    px = _screen_panel()
    as_of = px["datetime"].max() + pd.Timedelta(days=1)
    keep, table = bc.liquidity_screen(px, as_of, lookback_days=250, n=10,
                                      min_turnover=5e7, min_days=10)
    assert "LIQ" in keep and "MID" in keep
    assert "ILLIQ" not in keep            # both too thin and 100% zero-volume
    assert len(table) == 3                # the full audit table is returned


def test_liquidity_screen_ignores_data_after_as_of():
    """Screening on liquidity measured inside the study window selects names
    using information from the test period -- the same family of mistake as
    survivorship bias, and just as capable of manufacturing a result."""
    px = _screen_panel()
    as_of = px["datetime"].max() + pd.Timedelta(days=1)
    base, _ = bc.liquidity_screen(px, as_of, lookback_days=250, n=10,
                                  min_turnover=5e7, min_days=10)

    # ILLIQ becomes the most traded name in the market -- but only AFTER as_of.
    future = _flat_panel("ILLIQ", start=as_of, periods=40,
                         turnover=1e12, volume=10 ** 7)
    after, _ = bc.liquidity_screen(pd.concat([px, future], ignore_index=True),
                                   as_of, lookback_days=250, n=10,
                                   min_turnover=5e7, min_days=10)
    assert after == base
    assert "ILLIQ" not in after


def test_liquidity_screen_ranks_by_turnover():
    px = _screen_panel()
    as_of = px["datetime"].max() + pd.Timedelta(days=1)
    keep, _ = bc.liquidity_screen(px, as_of, lookback_days=250, n=1,
                                  min_turnover=1e5, min_days=10)
    assert keep == ["LIQ"]


def test_liquidity_screen_on_an_empty_window_returns_nothing_not_an_error():
    px = _screen_panel()
    keep, table = bc.liquidity_screen(px, "2010-01-01", lookback_days=250)
    assert keep == [] and len(table) == 0


# ==========================================
# 6. Cache loading and the assembled panel
# ==========================================
def _seed_cache(tmpdir, panel):
    """Write a long panel out as one cache file per day, as fetch_day would."""
    for day, grp in panel.groupby("datetime"):
        grp.to_csv(bc._cache_path(day, str(tmpdir)), index=False)
    return str(tmpdir)


def test_load_cache_round_trips_a_panel(tmp_path):
    px = pd.concat([_flat_panel("AAA"), _flat_panel("BBB")], ignore_index=True)
    cd = _seed_cache(tmp_path, px)
    out = bc.load_cache("2020-01-01", "2020-01-10", cache_dir=cd)
    assert out["symbol"].nunique() == 2
    assert len(out) == len(px)
    assert list(out.columns) == bc.COLUMNS


def test_load_cache_filters_symbols_before_concatenating(tmp_path):
    """Subsetting after loading the whole market is the difference between a
    few hundred MB and several GB over a decade."""
    px = pd.concat([_flat_panel("AAA"), _flat_panel("BBB")], ignore_index=True)
    cd = _seed_cache(tmp_path, px)
    out = bc.load_cache("2020-01-01", "2020-01-10", symbols=["AAA"],
                        cache_dir=cd)
    assert out["symbol"].unique().tolist() == ["AAA"]


def test_load_cache_skips_empty_days_and_missing_files(tmp_path):
    px = _flat_panel("AAA", periods=3)
    cd = _seed_cache(tmp_path, px)
    # An empty file is how fetch_day records "market shut".
    pd.DataFrame(columns=bc.COLUMNS).to_csv(
        bc._cache_path("2020-01-06", cd), index=False)
    out = bc.load_cache("2020-01-01", "2020-01-10", cache_dir=cd)
    assert len(out) == 3
    assert pd.Timestamp("2020-01-06") not in set(out["datetime"])


def test_load_cache_with_nothing_cached_returns_the_empty_schema(tmp_path):
    out = bc.load_cache("2020-01-01", "2020-01-10", cache_dir=str(tmp_path))
    assert len(out) == 0 and list(out.columns) == bc.COLUMNS


def test_build_panel_screens_then_loads_then_adjusts(tmp_path):
    """Wiring test for the whole assembly, including that the screen runs on
    the pre-window lookback and the study panel carries adj_close."""
    lookback = pd.concat([
        _flat_panel("LIQ", start="2019-06-03", periods=40, turnover=1e8),
        _flat_panel("ILLIQ", start="2019-06-03", periods=40, turnover=1e5,
                    volume=0),
    ], ignore_index=True)
    study = pd.concat([
        _flat_panel("LIQ", start="2019-08-01", periods=20, turnover=1e8),
        _flat_panel("ILLIQ", start="2019-08-01", periods=20, turnover=1e5,
                    volume=0),
    ], ignore_index=True)
    cd = _seed_cache(tmp_path, pd.concat([lookback, study], ignore_index=True))

    acts = pd.DataFrame([_action("LIQ", "2019-08-15", factor=2.0)])
    panel, rep = bc.build_panel("2019-08-01", "2019-08-28", n=10,
                                lookback_days=60, cache_dir=cd, actions=acts,
                                min_turnover=5e7, min_days=10, verbose=False)

    assert rep["universe"] == ["LIQ"]          # ILLIQ screened out
    assert panel["symbol"].unique().tolist() == ["LIQ"]
    assert "adj_close" in panel.columns
    early = panel[panel["datetime"] < "2019-08-15"]["adj_close"]
    assert np.allclose(early, 50.0)            # the split was applied


# ==========================================
# 7. Integration with cross_sectional_panel
# ==========================================
def test_bhav_fetcher_matches_the_schema_build_panel_expects():
    px = bc.adjust_prices(_flat_panel("AAA"), None)
    fn = bc.bhav_fetcher(px)
    out = fn("AAA")
    for c in ["datetime", "open", "high", "low", "close", "adj_close", "volume"]:
        assert c in out.columns
    assert len(out) == len(px)


def test_bhav_fetcher_accepts_tickers_with_or_without_the_NS_suffix():
    """DEFAULT_UNIVERSE carries '.NS'; bhavcopy symbols do not. The adapter
    must take either, so an existing universe list works unmodified."""
    px = bc.adjust_prices(_flat_panel("RELIANCE"), None)
    fn = bc.bhav_fetcher(px)
    assert len(fn("RELIANCE")) == len(fn("RELIANCE.NS")) == len(px)


def test_bhav_fetcher_returns_empty_for_an_unknown_ticker_rather_than_raising():
    """build_panel already records an empty frame as a drop with a reason; an
    exception would abort the whole universe."""
    fn = bc.bhav_fetcher(bc.adjust_prices(_flat_panel("AAA"), None))
    out = fn("NOSUCHNAME")
    assert isinstance(out, pd.DataFrame) and len(out) == 0


def test_bhav_fetcher_drives_cross_sectional_build_panel_unchanged():
    """The integration claim: a survivorship-free source swaps in through the
    existing injection seam, with no change to cross_sectional_panel."""
    import cross_sectional_panel as csp
    px = pd.concat([_flat_panel("AAA", periods=40),
                    _flat_panel("BBB", periods=40)], ignore_index=True)
    # A little variation, so the panel is not degenerate.
    px["close"] = px["close"] + np.arange(len(px)) % 7
    px = bc.adjust_prices(px, None)

    panel, rep = csp.build_panel(tickers=["AAA", "BBB"],
                                 fetch_fn=bc.bhav_fetcher(px),
                                 min_rows=10, verbose=False)
    assert rep["n_tickers"] == 2
    assert set(panel["ticker"]) == {"AAA", "BBB"}
    assert "adj_close" in panel.columns
