"""
pytest bootstrap for the tests/ folder.

Adds the project root (the parent of tests/) and the tests/ folder itself to
``sys.path`` so the suites can import the app modules (``import data_quality``)
and each other (``from test_data_quality import ...``) whether run via
``pytest`` from the repo root or as plain scripts (``python tests/test_x.py``).
"""

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
