"""
Tests for console.py — the terminal mirror of the UI's decision layer.

These are contract tests, not cosmetic ones. The console is a second channel
telling a user what the app concluded, so the properties worth pinning are the
ones that would make it *lie* or *crash*, not the ones that make it pretty:

- a degraded data-quality mode must read as withheld, never as a clean run;
- the honesty verdict must survive the markdown-stripping round trip intact;
- a legacy console encoding must not turn a log line into a failed forecast.
"""

import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import console


def _capture(fn, *args, **kwargs):
    """Run ``fn`` with stdout captured, returning everything it printed."""
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        fn(*args, **kwargs)
    finally:
        sys.stdout = old
    return buf.getvalue()


FLAGS = {'market-context': False, 'IV-tilt': False, 'prediction-log': True}

ROWS = [
    ("HAR-RV", "No edge", "no edge vs random walk (DM p=0.55)"),
    ("Meta-Ensemble", "Medium", "weak edge (DM p=0.14)"),
]

CONSENSUS = {'median_price': 1423.55, 'median_pct': 0.84,
             'n_up': 1, 'n_down': 0, 'n_noedge': 1, 'n_models': 2}


# ---------------------------------------------------------------------------
# Silencing
# ---------------------------------------------------------------------------

def test_quiet_env_var_silences_every_writer():
    os.environ["STOCKAPP_QUIET"] = "1"
    try:
        out = _capture(console.startup_banner, 42, "CPU", 19, FLAGS,
                       force=True)
        out += _capture(console.run_header, "X", "1d", 5, ["a"])
        out += _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS)
        out += _capture(console.note, "log", "something")
    finally:
        del os.environ["STOCKAPP_QUIET"]
    assert out == "", f"quiet mode still printed: {out!r}"


def test_output_returns_when_not_quiet():
    out = _capture(console.run_header, "RELIANCE.NS", "1d", 5, ["a", "b"])
    assert "RELIANCE.NS" in out and "horizon 5" in out and "2 model(s)" in out


# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------

def test_banner_prints_once_per_process():
    console._BANNER_SHOWN = False
    first = _capture(console.startup_banner, 42, "CPU", 19, FLAGS)
    second = _capture(console.startup_banner, 42, "CPU", 19, FLAGS)
    assert "seed 42" in first
    assert second == "", "banner reprinted on a Streamlit rerun"


def test_banner_reports_flag_states_verbatim():
    console._BANNER_SHOWN = False
    out = _capture(console.startup_banner, 7, "GPU", 19,
                   {'market-context': False, 'prediction-log': True},
                   log_path=".prediction_log/predictions.jsonl")
    assert "market-context=off" in out
    assert "prediction-log=on" in out
    assert ".prediction_log/predictions.jsonl" in out
    # The banner must point at the guide; that pointer is the only place the
    # console explains what any of the numbers below it mean.
    assert "Reading the screen" in out


# ---------------------------------------------------------------------------
# Run summary — the parts that could mislead
# ---------------------------------------------------------------------------

def test_degraded_data_quality_reads_as_withheld():
    for mode in ("risk_cone_only", "abstain"):
        out = _capture(console.run_summary, "X", "1d", 5, mode, 31.0, ROWS)
        assert "WITHHELD" in out, f"{mode} did not announce withholding: {out}"


def test_clean_run_does_not_claim_withholding():
    out = _capture(console.run_summary, "X", "1d", 5, "ok", 96.0, ROWS)
    assert "WITHHELD" not in out
    assert "forecasts usable" in out


def test_every_model_and_its_reason_appear():
    out = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS,
                   consensus=CONSENSUS)
    for model, bucket, basis in ROWS:
        assert model in out
        assert bucket in out
        # The reason is the whole point of the Basis column; a bare bucket
        # would be the "unexplained verdict" the UI deliberately avoids.
        assert basis.split("(")[0].strip() in out


def test_unassessed_run_says_so_rather_than_implying_skill():
    out = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, [])
    assert "not assessed" in out


def test_verdict_is_rendered_not_reworded():
    verdict = console.strip_markdown(
        "**No model showed a statistically reliable edge over a random walk** "
        "for this ticker & horizon.")
    out = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS,
                   verdict=verdict)
    assert "No model showed a statistically reliable edge" in out
    assert "**" not in out


def test_novelty_line_distinguishes_off_from_a_verdict():
    off = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS)
    assert "novelty gate off" in off
    on = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS,
                  novelty_verdict="unprecedented")
    assert "unprecedented" in on


def test_log_line_only_appears_when_rows_were_written():
    silent = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS,
                      log_path="p.jsonl", n_logged=0)
    assert "logged" not in silent
    loud = _capture(console.run_summary, "X", "1d", 5, "ok", 90.0, ROWS,
                    log_path="p.jsonl", n_logged=4)
    assert "4 row(s)" in loud


# ---------------------------------------------------------------------------
# Robustness
# ---------------------------------------------------------------------------

def test_strip_markdown_collapses_bold_and_whitespace():
    assert console.strip_markdown("**a**  b\n c") == "a b c"
    assert console.strip_markdown(None) == ""
    assert console.strip_markdown("") == ""


def test_write_survives_a_legacy_console_encoding():
    """
    A Windows cmd session on a legacy code page cannot encode a rupee sign or an
    em dash. Printing must degrade to a replacement character, never raise — a
    cosmetic log line must not be able to kill a forecast.
    """
    buf = io.TextIOWrapper(io.BytesIO(), encoding="ascii", errors="strict")
    old = sys.stdout
    sys.stdout = buf
    try:
        console._write("price ₹1,423 — done")   # rupee sign, em dash
    finally:
        sys.stdout = old
    # No exception is the assertion; confirm something was actually emitted.
    buf.flush()
    assert buf.buffer.getvalue()


def test_summary_tolerates_a_non_ascii_ticker():
    out = _capture(console.run_summary, "RELIANCE—NS", "1d", 5, "ok",
                   90.0, ROWS, consensus=CONSENSUS)
    assert "RESULT" in out


def test_field_wraps_long_values_under_the_value_column():
    out = _capture(console.field, "verdict", "word " * 40)
    lines = [ln for ln in out.splitlines() if ln]
    assert len(lines) > 1
    assert all(len(ln) <= console.WIDTH for ln in lines)
    # Continuation lines align under the value, keeping the label gutter clean.
    assert lines[1].startswith(" " * 18)
