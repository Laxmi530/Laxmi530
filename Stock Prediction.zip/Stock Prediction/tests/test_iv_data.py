"""
Tests for iv_data.forward_vol_factor (India-VIX forward-vol tilt).

Network-free: synthetic VIX / NIFTY series are injected into the module cache, so
the tests are deterministic and assert the contract — internal consistency of the
multiplier, clip bounds, graceful no-op on missing data, and leak-freeness (the
factor is taken "as of" the frame's last bar, never a future VIX value).

Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import iv_data


def _idx(n=300, end="2026-06-26"):
    return pd.bdate_range(end=end, periods=n).normalize()


def _series(values, idx):
    return pd.Series(np.asarray(values, float), index=idx)


def _inject(vix_series, nifty_series):
    iv_data.clear_cache()
    iv_data._SERIES_CACHE["^INDIAVIX"] = vix_series
    iv_data._SERIES_CACHE["^NSEI"] = nifty_series


def _make_market_and_stock(n=300, seed=11, beta=1.0, noise=0.004, vix_level=15.0,
                           end="2026-06-26"):
    rng = np.random.default_rng(seed)
    idx = _idx(n, end)
    mret = rng.normal(0, 0.009, n)
    nifty = _series(20000 * np.exp(np.cumsum(mret)), idx)
    vix = _series(np.full(n, vix_level), idx)
    # Stock correlated with the index (beta) plus idiosyncratic noise.
    sret = beta * mret + rng.normal(0, noise, n)
    stock_price = 1000 * np.exp(np.cumsum(sret))
    stock_df = pd.DataFrame({"datetime": idx, "adj_close": stock_price})
    return vix, nifty, stock_df


def test_multiplier_internal_consistency():
    vix, nifty, stock = _make_market_and_stock()
    _inject(vix, nifty)
    m, info = iv_data.forward_vol_factor(stock, "1d")
    F, w = info["F"], info["linkage_r2"]
    # info F/R2 are rounded for display; the returned m uses unrounded inputs, so
    # allow a small tolerance when reconstructing from the rounded fields.
    expected = float(np.clip(1.0 + w * (F - 1.0), *iv_data._M_CLIP))
    assert abs(m - expected) < 5e-3, (m, expected, info)
    assert iv_data._M_CLIP[0] <= m <= iv_data._M_CLIP[1]
    iv_data.clear_cache()


def test_high_vix_widens_but_clipped():
    # A huge VIX makes implied >> realized -> F clips high -> m at the upper clip.
    vix, nifty, stock = _make_market_and_stock(vix_level=200.0, beta=1.2)
    _inject(vix, nifty)
    m, info = iv_data.forward_vol_factor(stock, "1d")
    assert info["F"] == iv_data._F_CLIP[1], info        # ratio hit the clamp
    assert m > 1.0 and m <= iv_data._M_CLIP[1] + 1e-9   # widened, but bounded
    iv_data.clear_cache()


def test_low_vix_tightens():
    # Tiny VIX -> implied << realized -> F < 1 -> m < 1 (cone tightens).
    vix, nifty, stock = _make_market_and_stock(vix_level=3.0, beta=1.0)
    _inject(vix, nifty)
    m, info = iv_data.forward_vol_factor(stock, "1d")
    assert info["F"] < 1.0, info
    assert m < 1.0 and m >= iv_data._M_CLIP[0] - 1e-9
    iv_data.clear_cache()


def test_graceful_no_vix():
    _, nifty, stock = _make_market_and_stock()
    _inject(pd.Series(dtype=float), nifty)              # empty VIX
    m, info = iv_data.forward_vol_factor(stock, "1d")
    assert m == 1.0 and info["reason"] == "VIX unavailable"
    iv_data.clear_cache()


def test_no_linkage_is_noop():
    # With no market correlation (w≈0), m must collapse to 1 regardless of F.
    vix, nifty, _ = _make_market_and_stock(vix_level=40.0)
    # Build a stock independent of the index.
    rng = np.random.default_rng(99)
    idx = nifty.index
    price = 500 * np.exp(np.cumsum(rng.normal(0, 0.01, len(idx))))
    stock = pd.DataFrame({"datetime": idx, "adj_close": price})
    _inject(vix, nifty)
    m, info = iv_data.forward_vol_factor(stock, "1d")
    # An independent stock has a low (but not exactly zero) sample R^2; the
    # invariant that matters is m = clip(1 + w*(F-1)) and that the tilt can never
    # exceed the full market move (since w <= 1).
    assert info["linkage_r2"] < 0.3, info
    expected = float(np.clip(1.0 + info["linkage_r2"] * (info["F"] - 1.0),
                             *iv_data._M_CLIP))
    assert abs(m - expected) < 5e-3, (m, expected, info)
    assert abs(m - 1.0) <= abs(info["F"] - 1.0) + 1e-9
    iv_data.clear_cache()


def test_leak_free_asof():
    # VIX steps up at the midpoint; a frame ending BEFORE the step must see the
    # pre-step VIX, never the later spike.
    vix, nifty, stock = _make_market_and_stock(n=300)
    half = len(vix) // 2
    vix.iloc[half:] = 60.0          # later spike
    vix.iloc[:half] = 12.0          # earlier calm
    _inject(vix, nifty)
    early = stock[stock["datetime"] <= vix.index[half - 5]].copy()
    m_e, info_e = iv_data.forward_vol_factor(early, "1d")
    assert info_e["vix"] == 12.0, info_e          # used pre-spike value only
    late = stock.copy()
    m_l, info_l = iv_data.forward_vol_factor(late, "1d")
    assert info_l["vix"] == 60.0, info_l          # full frame sees the spike
    iv_data.clear_cache()


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All iv_data tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
