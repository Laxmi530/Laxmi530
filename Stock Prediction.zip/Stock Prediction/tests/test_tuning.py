"""
Tests for ``tuning`` — grid / random / TPE search and the nested wrapper.

The searches are checked against objectives with a *known* optimum, so "did it
find the right answer" is decidable rather than a matter of taste. The nested
wrapper is checked for the property that actually matters: that it reports an
honest holdout comparison rather than the flattering inner score.

Network-free, TensorFlow-free and deterministic. Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import tuning as tn


SPACE = {'a': list(range(10)), 'b': list(range(10))}


def _quadratic(noise=0.0, seed=0):
    """Objective peaking at a=9, b=9. Higher is better."""
    rng = np.random.default_rng(seed)

    def f(c):
        val = -((c['a'] - 9) ** 2 + (c['b'] - 9) ** 2)
        return val + (rng.normal(0, noise) if noise else 0.0)
    return f


# ── Spaces and samplers ────────────────────────────────────────────────────
def test_space_size_and_grid_agree():
    sp = {'a': [1, 2, 3], 'b': ['x', 'y']}
    assert tn.space_size(sp) == 6
    grid = tn.grid_configs(sp)
    assert len(grid) == 6
    # Exhaustive and unique.
    assert len({tn._key(c) for c in grid}) == 6


def test_random_configs_are_in_space_and_reproducible():
    a = tn.random_configs(SPACE, 12, seed=3)
    b = tn.random_configs(SPACE, 12, seed=3)
    assert [tn._key(x) for x in a] == [tn._key(x) for x in b]
    assert all(c['a'] in SPACE['a'] and c['b'] in SPACE['b'] for c in a)


def test_suggested_spaces_are_well_formed():
    spaces = tn.suggest_spaces()
    assert {'har_rv', 'vol_lstm'} <= set(spaces)
    for name, sp in spaces.items():
        assert sp and all(isinstance(v, list) and v for v in sp.values()), name
        # Deliberately small: a big space on ~1000 rows is more chances for
        # noise to win, not more thoroughness.
        assert tn.space_size(sp) <= 200, (name, tn.space_size(sp))


# ── Search ─────────────────────────────────────────────────────────────────
def test_grid_search_finds_the_exact_optimum():
    res = tn.search(_quadratic(), SPACE, method='grid', verbose=False)
    assert res['best_config'] == {'a': 9, 'b': 9}
    assert np.isclose(res['best_score'], 0.0)
    assert res['n_trials'] == 100          # exhaustive, ignores n_iter


def test_tpe_beats_random_at_equal_budget():
    """
    The whole point of Bayesian optimisation, and a regression test for a real bug.

    The first TPE took the deterministic argmax of the ratio over sampled
    candidates, which made it collapse onto one configuration — it burned 12 of
    30 trials on a single point and finished WORSE than random search
    (-1.845 vs -1.296). Duplicate suppression fixed it. This asserts the
    ordering that must hold.
    """
    rand, bayes = [], []
    for seed in range(6):
        rand.append(tn.search(_quadratic(noise=0.5, seed=seed), SPACE,
                              method='random', n_iter=30, seed=seed,
                              verbose=False)['best_score'])
        bayes.append(tn.search(_quadratic(noise=0.5, seed=seed), SPACE,
                               method='bayesian', n_iter=30, seed=seed,
                               verbose=False)['best_score'])
    assert np.mean(bayes) > np.mean(rand), (np.mean(bayes), np.mean(rand))


def test_tpe_does_not_waste_budget_on_duplicates():
    res = tn.search(_quadratic(noise=0.5), SPACE, method='bayesian',
                    n_iter=30, seed=1, verbose=False)
    keys = [tn._key(c) for c in res['history']['config']]
    # Was 15/30 before duplicate suppression; must now be essentially all unique.
    assert len(set(keys)) >= 28, len(set(keys))


def test_tpe_exhausts_a_tiny_space_without_hanging():
    tiny = {'a': [0, 1], 'b': [0, 1]}          # only 4 configurations
    res = tn.search(_quadratic(), tiny, method='bayesian', n_iter=20,
                    n_startup=2, verbose=False)
    assert res['n_trials'] == 20               # falls back gracefully
    assert res['best_config'] in tn.grid_configs(tiny)


def test_failing_objective_does_not_abort_the_search():
    def flaky(c):
        if c['a'] == 3:
            raise RuntimeError("boom")
        return -abs(c['a'] - 7)
    res = tn.search(flaky, {'a': list(range(10))}, method='grid', verbose=False)
    assert res['best_config'] == {'a': 7}
    assert (res['history']['score'] == float('-inf')).sum() == 1


def test_result_carries_a_selection_bias_warning():
    res = tn.search(_quadratic(), SPACE, method='random', n_iter=7, verbose=False)
    assert '7 configurations' in res['warning']
    assert 'run_spa' in res['warning']         # points at the right next step


def test_rejects_unknown_method():
    try:
        tn.search(_quadratic(), SPACE, method='annealing', verbose=False)
    except ValueError as exc:
        assert 'annealing' in str(exc) or 'grid' in str(exc)
    else:
        raise AssertionError("expected ValueError")


# ── Nested search: the honesty machinery ───────────────────────────────────
def _frame(n=400, seed=0):
    rng = np.random.default_rng(seed)
    price = 1000 * np.exp(np.cumsum(rng.normal(0.0002, 0.013, n)))
    return pd.DataFrame({
        'datetime': pd.bdate_range('2021-01-04', periods=n),
        'open': price, 'high': price * 1.01, 'low': price * 0.99,
        'close': price, 'adj_close': price,
        'volume': rng.integers(1e5, 1e6, n),
    })


def test_nested_search_reports_an_honest_holdout_comparison():
    df = _frame()
    space = {'p': [0, 1, 2, 3]}

    # Score depends only on how much data it sees, not on `p`: tuning CANNOT
    # help, and the nested wrapper must say so rather than celebrate the inner win.
    def fit_score(train_df, cfg):
        rng = np.random.default_rng(abs(hash(str(cfg))) % 1000)
        return float(rng.normal(0, 1))

    res = tn.nested_search(df, space, fit_score, method='grid', verbose=False)
    assert res['inner_rows'] + res['holdout_rows'] >= len(df)
    assert 'holdout_score_tuned' in res and 'holdout_score_default' in res
    assert res['default_config'] == {'p': 0}      # first listed value
    assert isinstance(res['generalizes'], bool)
    # The verdict must mention the holdout either way, never just the inner score.
    assert 'holdout' in res['verdict'].lower()


def test_nested_search_detects_a_genuine_improvement():
    df = _frame()
    space = {'p': [0, 1, 2, 3]}
    # Here p=3 is genuinely better everywhere, so tuning SHOULD generalise.
    res = tn.nested_search(df, space, lambda d, c: float(c['p']),
                           method='grid', verbose=False)
    assert res['best_config'] == {'p': 3}
    assert res['improvement'] > 0 and res['generalizes'] is True
    assert 'hypothesis' in res['verdict'].lower()   # still not a confirmed gain


def test_nested_search_keeps_the_holdout_untouched_during_search():
    df = _frame()
    seen_lengths = []

    def fit_score(train_df, cfg):
        seen_lengths.append(len(train_df))
        return 1.0

    tn.nested_search(df, {'p': [0, 1]}, fit_score, method='grid',
                     holdout_frac=0.30, verbose=False)
    cut = int(len(df) * 0.70)
    # The two search trials see only the prefix; the final two calls (tuned and
    # default) score on the full frame.
    assert seen_lengths[:2] == [cut, cut]
    assert seen_lengths[2:] == [len(df), len(df)]


def test_nested_search_refuses_too_little_data():
    try:
        tn.nested_search(_frame(n=60), {'p': [0, 1]}, lambda d, c: 1.0,
                         verbose=False)
    except ValueError as exc:
        assert 'too little data' in str(exc)
    else:
        raise AssertionError("expected ValueError on a tiny frame")


def test_report_renders():
    df = _frame()
    res = tn.nested_search(df, {'p': [0, 1, 2]}, lambda d, c: float(c['p']),
                           method='grid', verbose=False)
    txt = tn.format_search_report(res, 'unit-test')
    assert 'Hyperparameter search' in txt and 'Holdout' in txt
    assert 'NOTE' in txt


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All tuning tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
