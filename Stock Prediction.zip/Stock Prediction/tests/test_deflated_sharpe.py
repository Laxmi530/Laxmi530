"""
Tests for the Probabilistic and Deflated Sharpe Ratios
(Bailey & López de Prado 2012/2014; AFML §14.7.2-3).

The headline test is ``test_dsr_is_not_fooled_by_the_best_of_n_noise_strategies``:
run N strategies with **zero** true skill, keep the best, and check that the
naive PSR declares skill while DSR does not. That is the entire purpose of the
statistic, and if it failed the rest would not matter.

The normal CDF and its inverse are implemented from scratch because this project
has **no SciPy dependency** -- the same reason ``feature_drift`` carries a
closed-form Kolmogorov distribution -- so they are tested against published
quantiles rather than assumed correct.
"""

import numpy as np
import pytest

import strategy_metrics as sm


# ==========================================
# 1. The normal CDF and its inverse, no SciPy
# ==========================================
@pytest.mark.parametrize("p,known", [
    (0.975, 1.959963985), (0.99, 2.326347874), (0.95, 1.644853627),
    (0.5, 0.0), (0.025, -1.959963985), (0.01, -2.326347874),
])
def test_inverse_normal_matches_published_quantiles(p, known):
    assert sm._norm_ppf(p) == pytest.approx(known, abs=1e-8)


@pytest.mark.parametrize("p", [0.001, 0.02, 0.05, 0.3, 0.5, 0.7, 0.95, 0.999])
def test_cdf_and_inverse_round_trip(p):
    assert sm._norm_cdf(sm._norm_ppf(p)) == pytest.approx(p, abs=1e-9)


def test_inverse_normal_rejects_out_of_range():
    for bad in (0.0, 1.0, -0.1, 1.5):
        assert np.isnan(sm._norm_ppf(bad))


def test_normal_cdf_endpoints():
    assert sm._norm_cdf(0.0) == pytest.approx(0.5)
    assert sm._norm_cdf(-8.0) < 1e-14
    assert sm._norm_cdf(8.0) > 1 - 1e-14


# ==========================================
# 2. PSR -- the shape corrections
# ==========================================
def _returns(n=1000, mu=0.0005, sd=0.01, skew=0.0, seed=0):
    """Returns with a controllable skew, via a skew-normal-ish transform."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal(n)
    if skew:
        z = z + skew * (z ** 2 - 1.0) / 2.0
        z = (z - z.mean()) / z.std(ddof=1)
    return mu + sd * z


def test_psr_is_a_probability():
    for seed in range(4):
        p = sm.probabilistic_sharpe_ratio(_returns(seed=seed))
        assert 0.0 <= p <= 1.0


def test_psr_is_one_half_when_the_observed_sharpe_equals_the_benchmark():
    """With SR_hat == SR*, the numerator is zero and the probability is 0.5 --
    a clean analytic anchor that does not depend on any approximation."""
    r = _returns(n=2000, seed=1)
    sr = float(np.mean(r) / np.std(r, ddof=1))
    assert sm.probabilistic_sharpe_ratio(r, sr) == pytest.approx(0.5, abs=1e-9)


def test_negative_skew_lowers_psr():
    """The point of PSR. A strategy that grinds up and crashes down posts a
    flattering Sharpe; the skew term in the denominator discounts it."""
    good = _returns(n=1500, skew=+1.5, seed=2)
    bad = _returns(n=1500, skew=-1.5, seed=2)
    # Same mean and sd by construction, so the plain Sharpe is ~identical.
    sr_g = np.mean(good) / np.std(good, ddof=1)
    sr_b = np.mean(bad) / np.std(bad, ddof=1)
    assert sr_g == pytest.approx(sr_b, rel=0.05)
    assert sm.probabilistic_sharpe_ratio(bad) < sm.probabilistic_sharpe_ratio(good)


def test_fat_tails_lower_psr():
    """Isolating the kurtosis term requires care, and getting it wrong is easy.

    In the PSR denominator ``1 - g3*SR + (g4-1)/4 * SR^2`` the skew term is
    **linear** in SR while the kurtosis term is **quadratic**. At a small Sharpe
    the skew term therefore dominates, and a fat-tailed sample's *incidental*
    skew will swamp the tail effect entirely -- which is what a first version of
    this test measured.

    So: symmetrise the fat draws (random sign flips give a sample skew of
    ~zero), and use a Sharpe large enough for the quadratic term to bite."""
    rng = np.random.default_rng(3)
    n, mu, sd = 20000, 0.003, 0.01         # SR ~ 0.3 per period, not 0.05

    def _standardise(x):
        return (x - x.mean()) / x.std(ddof=1) * sd + mu

    thin = _standardise(rng.standard_normal(n))
    # A Gaussian SCALE MIXTURE, not Student-t: t(3) has an undefined fourth
    # moment, so its sample kurtosis and skew are unstable enough that a single
    # outlier dominates them. A mixture of two centred normals is symmetric by
    # construction, has finite moments, and is fat-tailed by a controlled
    # amount.
    scale = np.where(rng.random(n) < 0.1, 4.0, 1.0)
    fat = _standardise(scale * rng.standard_normal(n))

    # Same Sharpe and near-zero skew in both; only the tails differ.
    assert (np.mean(thin) / np.std(thin, ddof=1)
            == pytest.approx(np.mean(fat) / np.std(fat, ddof=1), rel=1e-9))
    z_t = (thin - thin.mean()) / thin.std(ddof=1)
    z_f = (fat - fat.mean()) / fat.std(ddof=1)
    assert abs(np.mean(z_f ** 3)) < 0.35
    assert np.mean(z_f ** 4) > 2 * np.mean(z_t ** 4)      # genuinely fatter

    # Compare against a benchmark just BELOW the observed Sharpe. Against zero
    # the statistic is so large that both probabilities saturate at exactly 1.0
    # and the comparison is vacuous; shrinking the numerator lets the
    # denominator -- which is where kurtosis enters -- decide the outcome.
    sr = float(np.mean(thin) / np.std(thin, ddof=1))
    p_thin = sm.probabilistic_sharpe_ratio(thin, 0.95 * sr)
    p_fat = sm.probabilistic_sharpe_ratio(fat, 0.95 * sr)
    assert 0.5 < p_fat < 1.0 and 0.5 < p_thin < 1.0, "neither should saturate"
    assert p_fat < p_thin


def test_psr_rises_with_track_record_length():
    """Same Sharpe, more evidence for it."""
    short = sm.probabilistic_sharpe_ratio(_returns(n=60, seed=4))
    long_ = sm.probabilistic_sharpe_ratio(_returns(n=3000, seed=4))
    assert long_ > short


def test_psr_accepts_an_annualised_benchmark():
    """Passing periods_per_year must de-annualise the benchmark, not the
    observed Sharpe -- getting that backwards inverts the comparison."""
    r = _returns(n=1000, mu=0.001, seed=5)
    per = sm.probabilistic_sharpe_ratio(r, 0.5 / np.sqrt(252))
    ann = sm.probabilistic_sharpe_ratio(r, 0.5, periods_per_year=252)
    assert per == pytest.approx(ann, abs=1e-9)


def test_psr_declines_gracefully_on_degenerate_input():
    assert np.isnan(sm.probabilistic_sharpe_ratio([0.01, 0.02]))       # too short
    assert np.isnan(sm.probabilistic_sharpe_ratio([0.01] * 50))        # no dispersion


# ==========================================
# 3. The noise threshold
# ==========================================
def test_expected_max_sharpe_grows_with_the_number_of_trials():
    """More trials, a higher bar -- the best of many noise draws looks better."""
    v = 0.01
    prev = -np.inf
    for n in (2, 10, 100, 1000):
        cur = sm.expected_max_sharpe(v, n)
        assert cur > prev
        prev = cur


def test_expected_max_sharpe_scales_with_trial_dispersion():
    """Quadrupling the variance doubles the threshold -- it enters as sqrt."""
    a = sm.expected_max_sharpe(0.01, 50)
    b = sm.expected_max_sharpe(0.04, 50)
    assert b == pytest.approx(2 * a, rel=1e-9)


def test_expected_max_sharpe_is_undefined_for_a_single_trial():
    """You cannot deflate for multiplicity when there was no multiplicity."""
    assert np.isnan(sm.expected_max_sharpe(0.01, 1))
    assert np.isnan(sm.expected_max_sharpe(-1.0, 10))


# ==========================================
# 4. DSR -- the headline
# ==========================================
def test_dsr_is_not_fooled_by_the_best_of_n_noise_strategies():
    """THE test. 200 strategies with zero true skill; keep the best. The naive
    PSR calls it significant. DSR must not, because its threshold rises with
    the number of trials."""
    rng = np.random.default_rng(11)
    rets = rng.standard_normal((200, 750)) * 0.01        # mean exactly zero
    srs = np.array([r.mean() / r.std(ddof=1) for r in rets])
    best = rets[int(np.argmax(srs))]

    psr = sm.probabilistic_sharpe_ratio(best, 0.0)
    dsr = sm.deflated_sharpe_ratio(best, srs)["dsr"]

    assert psr > 0.95, "the setup should look significant naively"
    assert dsr < 0.95, "DSR must not be fooled"
    assert dsr < psr


def test_dsr_threshold_rises_with_more_trials():
    rng = np.random.default_rng(12)
    rets = rng.standard_normal((300, 600)) * 0.01
    srs = np.array([r.mean() / r.std(ddof=1) for r in rets])
    best = rets[int(np.argmax(srs))]
    few = sm.deflated_sharpe_ratio(best, srs[:10])["sr_star"]
    many = sm.deflated_sharpe_ratio(best, srs)["sr_star"]
    assert many > few


def test_dsr_still_recognises_genuine_skill():
    """It must not reject everything. A strategy with a real edge, among the
    same number of trials, should survive."""
    rng = np.random.default_rng(13)
    noise = rng.standard_normal((50, 1500)) * 0.01
    srs = [r.mean() / r.std(ddof=1) for r in noise]
    skilled = 0.004 + 0.01 * rng.standard_normal(1500)   # a large, real edge
    srs.append(skilled.mean() / skilled.std(ddof=1))
    assert sm.deflated_sharpe_ratio(skilled, np.array(srs))["dsr"] > 0.95


def test_dsr_reports_the_shape_statistics_it_used():
    r = _returns(n=800, skew=-1.0, seed=14)
    d = sm.deflated_sharpe_ratio(r, np.array([0.01, 0.02, 0.03, 0.04]))
    assert d["skew"] < 0
    assert d["kurtosis"] > 0
    assert d["n_obs"] == 800 and d["n_trials"] == 4


def test_dsr_deannualises_trial_sharpes_when_asked():
    """Passing annualised trial Sharpes without conversion inflates their
    variance by periods_per_year and so inflates the threshold."""
    rng = np.random.default_rng(15)
    r = 0.0005 + 0.01 * rng.standard_normal(1000)
    ann = np.array([0.5, 0.8, 1.1, 0.3, 0.9])
    raw = sm.deflated_sharpe_ratio(r, ann)["sr_star"]
    conv = sm.deflated_sharpe_ratio(r, ann, periods_per_year=252)["sr_star"]
    assert conv < raw
    assert conv == pytest.approx(raw / np.sqrt(252), rel=1e-9)


def test_dsr_declines_gracefully():
    d = sm.deflated_sharpe_ratio([0.01, 0.02], np.array([0.1, 0.2]))
    assert np.isnan(d["dsr"])
    d2 = sm.deflated_sharpe_ratio(_returns(n=500), np.array([0.1]))
    assert np.isnan(d2["dsr"]) and d2["n_trials"] == 1
