"""
Tests for the regime-novelty serving gate (``gating.apply_novelty_gate``) and the
pure, TensorFlow-free parts of ``autoencoder_regime``.

The gate is trust-critical — it decides when the app stops asserting a direction —
so it is unit-tested directly rather than only through the UI, matching how the
data-quality gate is treated in ``test_gates.py``.

Network-free, TensorFlow-free and deterministic. Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import gating


MODELS = ["XGBoost", "HAR-RV"]


def _conf(bucket="High"):
    return {m: {"bucket": bucket, "dm_p": 0.03, "coverage": 0.94,
                "improvement": 0.08} for m in MODELS}


# ── The gate ───────────────────────────────────────────────────────────────
def test_unprecedented_regime_withholds_direction():
    nov = {"available": True, "verdict": "unprecedented", "percentile": 0.999}
    out = gating.apply_novelty_gate(_conf("High"), MODELS, nov)
    for m in MODELS:
        assert out[m]["bucket"] == gating.WITHHELD_BUCKET
        assert "unseen market regime" in out[m]["note"]
    # And the withheld bucket suppresses the Bullish/Bearish call downstream.
    sentiment, arrow = gating.gated_direction(+50.0, out["XGBoost"]["bucket"])
    assert sentiment == gating.WITHHELD_BUCKET and arrow == gating.WITHHELD_DIRECTION


def test_unusual_regime_annotates_but_does_not_withhold():
    # Deliberately conservative: a 95th-percentile window is a normal monthly
    # event in fat-tailed data, so gating on it would abstain far too often.
    nov = {"available": True, "verdict": "unusual", "percentile": 0.97}
    out = gating.apply_novelty_gate(_conf("High"), MODELS, nov)
    for m in MODELS:
        assert out[m]["bucket"] == "High"
        assert out[m]["novelty"] == "unusual"
    assert "unusual regime" in gating.confidence_reason(out["XGBoost"])


def test_familiar_regime_is_a_noop():
    nov = {"available": True, "verdict": "familiar", "percentile": 0.30}
    before = _conf("Medium")
    out = gating.apply_novelty_gate(before, MODELS, nov)
    assert out == before


def test_unavailable_novelty_never_fires():
    for nov in ({}, None,
                {"available": False, "verdict": "unknown"},
                {"available": True, "verdict": "unknown"}):
        before = _conf("High")
        assert gating.apply_novelty_gate(before, MODELS, nov) == before


def test_gate_does_not_mutate_input():
    before = _conf("High")
    snapshot = {k: dict(v) for k, v in before.items()}
    gating.apply_novelty_gate(
        before, MODELS, {"available": True, "verdict": "unprecedented",
                         "percentile": 0.999})
    assert before == snapshot


def test_gate_handles_models_missing_from_conf_map():
    nov = {"available": True, "verdict": "unprecedented", "percentile": 0.999}
    out = gating.apply_novelty_gate({}, MODELS, nov)
    assert all(out[m]["bucket"] == gating.WITHHELD_BUCKET for m in MODELS)


def test_gate_composes_with_data_quality_gate():
    nov = {"available": True, "verdict": "familiar", "percentile": 0.2}
    step1 = gating.apply_data_quality_gate(_conf("High"), MODELS, degraded=True)
    step2 = gating.apply_novelty_gate(step1, MODELS, nov)
    # Data quality already withheld; novelty must not resurrect the call.
    assert all(step2[m]["bucket"] == gating.WITHHELD_BUCKET for m in MODELS)
    assert gating.confidence_reason(step2["XGBoost"]) == "withheld — data quality"


def test_confidence_reason_reports_novelty_withholding():
    nov = {"available": True, "verdict": "unprecedented", "percentile": 0.998}
    out = gating.apply_novelty_gate(_conf("High"), MODELS, nov)
    assert gating.confidence_reason(out["HAR-RV"]) == \
        "withheld — unseen market regime"


def test_nan_percentile_does_not_crash_the_message():
    nov = {"available": True, "verdict": "unprecedented",
           "percentile": float("nan")}
    out = gating.apply_novelty_gate(_conf("High"), MODELS, nov)
    assert "n/a" in out["XGBoost"]["note"]


# ── Pure autoencoder helpers (no TensorFlow needed) ────────────────────────
def _synthetic(n=400, seed=2):
    rng = np.random.default_rng(seed)
    price = 1000 * np.exp(np.cumsum(rng.normal(0.0002, 0.012, n)))
    return pd.DataFrame({
        "datetime": pd.bdate_range("2022-01-03", periods=n),
        "open": price, "high": price * 1.01, "low": price * 0.99,
        "close": price, "adj_close": price,
        "volume": rng.integers(1e5, 1e6, n),
    })


def test_feature_windows_shape_and_alignment():
    import autoencoder_regime as ar
    df = _synthetic()
    X, stamps, n_feat = ar.feature_windows(df, window=20)
    assert n_feat == 9                       # the shared 9-feature matrix
    assert X.shape[1] == 20 * 9              # flattened window
    assert len(stamps) == len(X)
    # Each stamp is the LAST bar of its window, so stamps are strictly increasing
    # and the final one is the last usable bar of the history.
    assert pd.Series(stamps).is_monotonic_increasing
    assert pd.Timestamp(stamps[-1]) == df["datetime"].iloc[-1]
    assert np.isfinite(X).all()


def test_feature_windows_empty_on_short_history():
    import autoencoder_regime as ar
    X, stamps, _ = ar.feature_windows(_synthetic(n=30), window=20)
    assert len(X) == 0 and len(stamps) == 0


def test_regime_novelty_returns_neutral_report_on_short_history():
    import autoencoder_regime as ar
    rep = ar.regime_novelty(_synthetic(n=40), "1d")
    # Never raises, never fabricates a verdict, and cannot trip the gate.
    assert rep["available"] is False and rep["verdict"] == "unknown"
    assert rep["cone_multiplier"] == 1.0
    assert gating.apply_novelty_gate(_conf(), MODELS, rep) == _conf()


def test_latent_codes_and_series_safe_without_a_bundle():
    import autoencoder_regime as ar
    assert len(ar.latent_codes(None)) == 0
    assert ar.novelty_series(None).empty
    assert list(ar.novelty_series({}).columns) == \
        ['datetime', 'error', 'percentile']


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All novelty-gate tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
