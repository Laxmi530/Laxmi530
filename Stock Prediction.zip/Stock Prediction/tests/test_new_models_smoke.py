"""
Smoke tests for the book-derived model additions: Vol-LSTM, CNN-LSTM and the
regime autoencoder.

These are **contract** tests, not accuracy tests. They check that each new model
honours the project-wide ``run_*_prediction(df, interval, horizon) -> DataFrame``
contract on synthetic data: right columns, right length, finite and correctly
ordered bounds, and — for the volatility models — an unbiased variance level and
a usable empirical risk sample. Forecast quality is not asserted, because on a
synthetic random walk there is nothing to be accurate about.

Requires TensorFlow and is therefore the slow suite (a few minutes on CPU); it
skips itself cleanly if TensorFlow is unavailable. Network-free and deterministic.

Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
_os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

try:
    import tensorflow  # noqa: F401
    _HAS_TF = True
except Exception:
    _HAS_TF = False

# The synthetic series: a Gaussian random walk with a KNOWN volatility, so the
# volatility models' level can be checked rather than merely smoke-run.
TRUE_SIGMA = 0.014
HORIZON = 5


def _walk(n=700, sigma=TRUE_SIGMA, seed=0):
    rng = np.random.default_rng(seed)
    price = 1000 * np.exp(np.cumsum(rng.normal(0.0002, sigma, n)))
    return pd.DataFrame({
        "datetime": pd.bdate_range("2021-01-04", periods=n),
        "open": price, "high": price * 1.01, "low": price * 0.99,
        "close": price, "adj_close": price,
        "volume": rng.integers(1e5, 1e6, n),
    })


def _assert_forecast_contract(out, horizon=HORIZON):
    """Every model in this project must satisfy exactly this."""
    assert isinstance(out, pd.DataFrame) and len(out) == horizon
    assert {"datetime", "predicted_price", "lower_bound",
            "upper_bound", "volatility"} <= set(out.columns)
    assert np.isfinite(out["predicted_price"].values).all()
    assert (out["predicted_price"] > 0).all()
    assert (out["lower_bound"] <= out["predicted_price"]).all()
    assert (out["upper_bound"] >= out["predicted_price"]).all()
    assert (out["volatility"] >= 0).all()
    assert pd.Series(out["datetime"]).is_monotonic_increasing


# ══════════════════════════════════════════════════════════════════════════
# Vol-LSTM (book Ch. 5)
# ══════════════════════════════════════════════════════════════════════════
def test_vol_lstm_channels_are_causal_and_finite():
    import vol_lstm_model as vl
    from HAR_RV_model import _har_lags
    rng = np.random.default_rng(1)
    r = rng.normal(0, 0.01, 300)
    ch, log_rv = vl.build_rv_channels(r, _har_lags("daily"))
    assert ch.shape == (300, 5) and len(log_rv) == 300
    assert np.isfinite(ch).all()
    # Channel 3 is the signed return: its sign must match the bar's return.
    nz = r != 0
    assert np.all(np.sign(ch[nz, 3]) == np.sign(r[nz]))
    # Channel 0 is log-RV itself and must be sign-independent.
    ch_flip, _ = vl.build_rv_channels(-r, _har_lags("daily"))
    assert np.allclose(ch[:, 0], ch_flip[:, 0])


def test_vol_lstm_sample_indexing_has_no_off_by_one():
    import vol_lstm_model as vl
    channels = np.arange(100 * 2, dtype=float).reshape(100, 2)
    log_rv = np.arange(100, dtype=float)
    X, Y = vl._make_samples(channels, log_rv, look_back=4, horizon=3,
                            origins=[10, 20])
    assert X.shape == (2, 4, 2) and Y.shape == (2, 3)
    # Origin 10 => window is rows 7..10 inclusive, targets are 11, 12, 13.
    assert np.allclose(X[0], channels[7:11])
    assert np.allclose(Y[0], [11.0, 12.0, 13.0])


def test_qlike_and_cse_behave():
    import vol_lstm_model as vl
    actual = np.full(50, 0.0004)
    good = np.full(50, 0.0004)
    bad = np.full(50, 0.004)
    assert vl.qlike_loss(actual, good) < vl.qlike_loss(actual, bad)
    cse = vl.cumulative_squared_error(actual, bad)
    assert len(cse) == 50 and cse[-1] > cse[0] > 0
    assert np.isclose(vl.cumulative_squared_error(actual, good)[-1], 0.0)


def test_vol_lstm_forecast_contract_and_level():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    import vol_lstm_model as vl
    out = vl.run_vol_lstm_prediction(_walk(), "1d", HORIZON)
    _assert_forecast_contract(out)

    # Point path is the random walk: flat at the last observed price, by design.
    df = _walk()
    last = float(df["adj_close"].iloc[-1])
    assert np.allclose(out["predicted_price"].values, last)

    # The debiased variance level should be the right order of magnitude. A wide
    # band (0.5x-2x) because the network is fitted on ~470 windows of noise; the
    # point is that the log->level transform is not off by ~2x as it would be
    # without the offset correction.
    diag = out.attrs["vol_model"]
    assert diag["fitted"] is True
    vol0 = diag["next_step_vol"]
    assert 0.5 * TRUE_SIGMA < vol0 < 2.0 * TRUE_SIGMA, vol0
    # The estimated offset should land near the theoretical log-chi2(1) value.
    assert 0.8 < diag["level_offset"] < 2.2, diag["level_offset"]
    # And it must be calibrated against the MODEL's own predictions when a
    # calibration block exists — the unconditional offset corrects the
    # log-chi-squared transform but leaves the network's own bias in place
    # (measured bias ratio 1.25 vs 1.03 on RELIANCE).
    assert diag["level_offset_mode"] == "model-calibrated", diag

    # Conformal multipliers land near the Gaussian 1.96 once the level is
    # unbiased — a direct check that the cone is not silently compensating for a
    # mis-scaled variance forecast.
    band = np.log(out["upper_bound"].values[0] / last)
    implied_k = band / vol0
    assert 0.8 < implied_k < 3.5, implied_k

    # Empirical risk sample for the UI panel: centred near zero (flat forecast).
    sample = out.attrs["risk_log_returns"]
    assert len(sample) >= 20 and np.isfinite(sample).all()
    assert abs(float(np.mean(sample))) < 0.10
    assert 0.0 <= out.attrs["downside_share"] <= 1.0


def test_vol_lstm_falls_back_on_short_history():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    import vol_lstm_model as vl
    out = vl.run_vol_lstm_prediction(_walk(n=120), "1d", 3)
    _assert_forecast_contract(out, horizon=3)
    # No network fitted, but still a usable EWMA cone rather than an exception.
    assert out.attrs["vol_model"]["fitted"] is False
    assert (out["upper_bound"] > out["lower_bound"]).all()


def test_vol_lstm_asymmetric_cone_runs():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    import vol_lstm_model as vl
    out = vl.run_vol_lstm_prediction(_walk(seed=5), "1d", 3, asymmetric=True)
    _assert_forecast_contract(out, horizon=3)
    if out.attrs.get("cone") == "asymmetric":
        k = out.attrs["cone_k"]
        assert k["lower"] > 0 and k["upper"] > 0


# ══════════════════════════════════════════════════════════════════════════
# CNN-LSTM (book Ch. 7)
# ══════════════════════════════════════════════════════════════════════════
def test_cnn_lstm_builds_with_causal_convs():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    from CNN_LSTM_model import build_cnn_lstm_model
    model = build_cnn_lstm_model((90, 9), output_dim=5)
    assert model.output_shape[-1] == 5
    convs = [l for l in model.layers if l.__class__.__name__ == "Conv1D"]
    assert convs, "expected Conv1D layers"
    # Causal padding is load-bearing: 'same' would let a filter see future bars.
    assert all(l.padding == "causal" for l in convs)
    assert any(l.__class__.__name__ == "LSTM" for l in model.layers)


def test_cnn_lstm_short_window_skips_pooling():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    from CNN_LSTM_model import build_cnn_lstm_model
    short = build_cnn_lstm_model((10, 9), output_dim=2)
    assert not any(l.__class__.__name__ == "MaxPooling1D"
                   for l in short.layers)
    long = build_cnn_lstm_model((90, 9), output_dim=2)
    assert any(l.__class__.__name__ == "MaxPooling1D" for l in long.layers)


def test_cnn_lstm_forecast_contract():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    from CNN_LSTM_model import run_cnn_lstm_prediction
    df = _walk(seed=2)
    out = run_cnn_lstm_prediction(df, "1d", HORIZON)
    _assert_forecast_contract(out)
    # A 5-day forecast on a 1.4%/day walk should stay within a sane band of the
    # last price; a blow-up here means the direct/conformal engine is misused.
    last = float(df["adj_close"].iloc[-1])
    assert 0.7 * last < out["predicted_price"].min() <= \
        out["predicted_price"].max() < 1.4 * last


# ══════════════════════════════════════════════════════════════════════════
# Regime autoencoder (book Ch. 4)
# ══════════════════════════════════════════════════════════════════════════
def test_autoencoder_flags_an_injected_regime_break():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    import autoencoder_regime as ar

    df = _walk(n=700, seed=1)
    bundle = ar.fit_regime_autoencoder(df, "1d")
    assert bundle is not None
    assert bundle["ref_quantiles"]["p50"] > 0
    assert len(bundle["ref_errors"]) >= 20

    calm = ar.regime_novelty(df, "1d", bundle=bundle)
    assert calm["available"] and calm["verdict"] == "familiar"
    assert calm["cone_multiplier"] == 1.0

    # Replace the tail with a violent, 6x-volatility stretch: genuinely
    # off-manifold relative to everything the AE was fitted on.
    rng = np.random.default_rng(9)
    shocked = df.copy()
    p = df["adj_close"].values.copy()
    p[-25:] = p[-26] * np.exp(np.cumsum(rng.normal(0, 0.09, 25)))
    shocked["adj_close"] = p
    shock = ar.regime_novelty(shocked, "1d", bundle=bundle)
    assert shock["verdict"] == "unprecedented", shock
    assert shock["percentile"] > 0.99
    assert 1.0 < shock["cone_multiplier"] <= 1.5

    # And the gate must actually withhold on that verdict.
    import gating
    conf = {"XGBoost": {"bucket": "High"}}
    gated = gating.apply_novelty_gate(conf, ["XGBoost"], shock)
    assert gated["XGBoost"]["bucket"] == gating.WITHHELD_BUCKET


def test_autoencoder_latent_and_series_shapes():
    if not _HAS_TF:
        print("  (TensorFlow unavailable — skipped)")
        return
    import autoencoder_regime as ar
    df = _walk(n=500, seed=4)
    bundle = ar.fit_regime_autoencoder(df, "1d", latent_dim=6)
    assert bundle is not None
    codes = ar.latent_codes(bundle, df=df)
    assert codes.ndim == 2 and codes.shape[1] == 6
    series = ar.novelty_series(bundle)
    assert list(series.columns) == ["datetime", "error", "percentile"]
    assert len(series) == len(bundle["score_errors"])
    assert series["error"].gt(0).all()


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    if not _HAS_TF:
        print("TensorFlow not available — the deep-model contract tests will "
              "self-skip; the pure helpers still run.\n")
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All new-model smoke tests passed." if not failures
          else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
