"""
Tests for the B2 downside-risk additions to HAR-RV:
  * realized semivariance split (RS- / RS+, summing to RV),
  * asymmetric cone multipliers (wider downside on a left-skewed residual
    distribution; ~symmetric on a symmetric one),
  * one-sided ACI multiplier sanity,
  * the empirical downside metrics in UI._empirical_risk (CVaR, semideviation,
    vol skew).

Network-free and deterministic. Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np

import HAR_RV_model as har


def test_level_offset_recovers_the_log_chi2_constant():
    """
    ``har_level_offset`` should land on the theoretical 1.27 for Gaussian returns.

    ``E[log chi2(1)] = -1.2704``, so the offset that maps ``E[log(r^2)]`` back to
    ``log(sigma^2)`` is +1.2704. This pins the constant the whole level transform
    depends on.
    """
    rng = np.random.default_rng(3)
    r = rng.normal(0.0, 0.02, 20000)
    log_rv = np.log(r ** 2 + har._EPS)
    offset = har.har_level_offset(log_rv)
    assert 1.15 < offset < 1.40, offset
    # And it round-trips: exp(mean(log RV) + c) recovers the true variance.
    recovered = np.exp(np.mean(log_rv) + offset)
    assert np.isclose(np.sqrt(recovered), 0.02, rtol=0.05), np.sqrt(recovered)
    assert har.har_level_offset(np.array([])) == 0.0


def test_har_variance_forecast_is_unbiased():
    """
    The regression this locks in: HAR's per-step variance must not be ~1.9x too big.

    The old transform used the log-normal Jensen correction ``exp(mu +
    resid_var/2)``. The residual of a regression on ``log(r^2)`` is
    log-chi-squared with variance ~pi^2/2 ~ 4.93, so that correction inflated the
    variance by ``e^2.46 ~ 11.7`` instead of the correct ``e^1.27 ~ 3.6`` — a
    ~1.9x over-statement in volatility terms, measured on real data by
    ``run_vol_comparison.py``. The conformal layer masked it (coverage stayed
    fine), so only a direct level check catches it.
    """
    rng = np.random.default_rng(4)
    true_sigma = 0.015
    r = rng.normal(0.0, true_sigma, 3000)
    lags = har._har_lags('daily')

    log_rv = np.log(r ** 2 + har._EPS)
    lo, hi = np.percentile(log_rv, [1, 99])
    log_rv = np.clip(log_rv, lo, hi)
    coef, resid_var = har.fit_har(log_rv, lags)

    step_var = har.forecast_har_variance(log_rv, coef, lags, horizon=5)
    fitted_vol = float(np.sqrt(step_var.mean()))
    bias_ratio = fitted_vol / true_sigma
    assert 0.85 < bias_ratio < 1.20, f"bias_ratio={bias_ratio:.3f}"

    # Demonstrate the old behaviour was genuinely biased, so this test would have
    # failed before the fix rather than passing vacuously.
    old_vol = float(np.sqrt(np.exp(
        np.mean(log_rv) + 0.5 * resid_var)))
    assert old_vol / true_sigma > 1.5, old_vol / true_sigma


def test_semivariance_splits_and_sums():
    r = np.array([0.01, -0.02, 0.0, 0.03, -0.015, -0.005])
    rs_down, rs_up = har._realized_semivariance(r)
    # Down captures only negatives, up only positives; together they are r^2.
    assert np.allclose(rs_down + rs_up, r ** 2)
    assert rs_down[1] > 0 and rs_up[1] == 0      # r=-0.02 -> downside only
    assert rs_up[3] > 0 and rs_down[3] == 0      # r=+0.03 -> upside only
    assert rs_down[2] == 0 and rs_up[2] == 0     # r=0 -> neither


def _signed(skew_left=False, n=400, seed=5):
    """Synthetic per-horizon signed standardized residuals."""
    rng = np.random.default_rng(seed)
    if skew_left:
        # Fat left tail: negative-skew mixture.
        base = rng.normal(0.1, 0.6, n)
        shocks = -np.abs(rng.normal(0, 2.0, n // 5))
        z = np.concatenate([base, shocks])
    else:
        z = rng.normal(0.0, 1.0, n)
    return {1: z, 2: z, 3: z}


def test_asymmetric_wider_downside_on_left_skew():
    sig = _signed(skew_left=True)
    k_lo, k_up = har._asymmetric_multipliers(sig, 3, adaptive=False)
    # Left-skewed residuals -> the lower edge multiplier exceeds the upper.
    assert np.all(k_lo > k_up), (k_lo, k_up)


def test_asymmetric_balanced_on_symmetric():
    sig = _signed(skew_left=False)
    k_lo, k_up = har._asymmetric_multipliers(sig, 3, adaptive=False)
    # Symmetric residuals -> lower/upper multipliers are close.
    assert np.allclose(k_lo, k_up, rtol=0.25), (k_lo, k_up)


def test_asymmetric_adaptive_runs():
    sig = _signed(skew_left=True)
    k_lo, k_up = har._asymmetric_multipliers(sig, 3, adaptive=True)
    assert np.all(k_lo > 0) and np.all(k_up > 0)
    assert np.all(k_lo >= k_up - 1e-9)           # downside still >= upside


def test_one_sided_aci_positive():
    rng = np.random.default_rng(1)
    z = np.abs(rng.normal(0, 1, 200))
    k = har._aci_one_sided(z, base_alpha=0.025)
    assert k > 0 and np.isfinite(k)
    # Too few points -> safe Gaussian fallback.
    assert har._aci_one_sided(z[:5], 0.025) == har._Z95


def test_empirical_downside_metrics():
    import risk_metrics
    rng = np.random.default_rng(7)
    # Left-skewed horizon-end log returns.
    r = np.concatenate([rng.normal(0, 0.02, 800),
                        -np.abs(rng.normal(0.04, 0.03, 200))])
    m = risk_metrics.empirical_risk(1000.0, r, threshold_pct=2.0)
    # Expected shortfall is below (worse than) VaR; both are losses here.
    assert m['cvar5_pct'] <= m['var5_pct'], m
    # Down semideviation exceeds up (left-skewed), so vol skew > 1.
    assert m['down_semidev'] > m['up_semidev']
    assert m['vol_skew'] > 1.0


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All HAR-RV downside tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
