"""
Tests for kalman_model.py — the project's only state-space model.

The properties worth pinning here are not "does it produce numbers" but:

- the filter **recovers known parameters** from a simulated process (a
  state-space fit that cannot do this is not fitting anything);
- it **admits when the data is a random walk** rather than manufacturing a
  trend, which on price series is the common and correct outcome;
- the damped trend **converges** instead of extrapolating a straight line;
- the forecast is **anchored** at the last observation and the cone widens.

The parameter-recovery test is the load-bearing one. The first implementation
scored the raw Gaussian likelihood with ``r`` fixed at 1, which on log-price
data (scale ~0.02) simply rewarded the smallest ``q`` regardless of the truth:
a known q/r of 4.0 was fitted as 0.000. Only the concentrated (profile)
likelihood compares parameter *ratios*, and only this test noticed.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import kalman_model as km


def _local_level(n=800, q=0.02 ** 2, r=0.01 ** 2, seed=0):
    """A true local-level process: random-walk state plus observation noise."""
    rng = np.random.default_rng(seed)
    level = np.cumsum(rng.normal(0, np.sqrt(q), n)) + 5.0
    return level + rng.normal(0, np.sqrt(r), n)


def _price_frame(n=900, seed=0):
    rng = np.random.default_rng(seed)
    px = 100 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    return pd.DataFrame({
        "datetime": pd.bdate_range("2021-01-04", periods=n),
        "open": px, "high": px * 1.01, "low": px * 0.99,
        "close": px, "adj_close": px,
        "volume": rng.integers(1e5, 5e5, n),
    })


# ---------------------------------------------------------------------------
# Parameter recovery — the test that caught the likelihood bug
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("q,r,expected", [
    (0.02 ** 2, 0.01 ** 2, 4.0),
    (0.005 ** 2, 0.01 ** 2, 0.25),
])
def test_fit_recovers_a_known_signal_to_noise_ratio(q, r, expected):
    """
    Within a factor of ~3 — the grid is coarse by design, and the point is that
    the estimate tracks the truth at all. The broken version returned 0.000 for
    a true ratio of 4.0.
    """
    y = _local_level(q=q, r=r)
    fit = km.fit_kalman(y)
    assert fit["ok"]
    ratio = fit["q_level"] / fit["r"]
    assert expected / 3.0 <= ratio <= expected * 3.0, (
        f"true q/r={expected}, fitted {ratio:.4f}")


def test_likelihood_is_not_monotone_in_q():
    """
    Direct guard on the bug. With the scale profiled out, the likelihood must
    have an interior optimum in q; the broken version fell monotonically, so the
    fit always slid to the smallest grid value.
    """
    y = _local_level()
    lls = [km.kalman_filter(y, ql, 0.0, 1.0, 0.0)["loglik"]
           for ql in (1e-4, 1e-2, 1.0, 4.0, 20.0)]
    assert np.all(np.isfinite(lls))
    assert np.argmax(lls) not in (0, len(lls) - 1), (
        f"likelihood optimum is at a grid edge: {lls}")


def test_more_state_noise_is_preferred_when_the_state_really_moves():
    """A fast-moving state must fit a larger q/r than a nearly-static one."""
    fast = km.fit_kalman(_local_level(q=0.05 ** 2, r=0.01 ** 2, seed=1))
    slow = km.fit_kalman(_local_level(q=0.002 ** 2, r=0.01 ** 2, seed=1))
    assert fast["q_level"] / fast["r"] > slow["q_level"] / slow["r"]


# ---------------------------------------------------------------------------
# Honest degeneration
# ---------------------------------------------------------------------------

def test_a_random_walk_is_reported_as_a_random_walk():
    """
    The behaviour that matters on price data: no slope to find, so the model
    should say so rather than fit one. A state-space model that always produces
    a trend is a trend generator, not an estimator.
    """
    rng = np.random.default_rng(3)
    y = np.cumsum(rng.normal(0, 0.012, 800)) + np.log(100.0)
    fit = km.fit_kalman(y)
    assert fit["ok"]
    assert fit["degenerate_to_random_walk"] is True


def test_a_genuine_trend_is_not_discarded():
    """The converse: a strong deterministic drift must survive the fit."""
    rng = np.random.default_rng(4)
    n = 600
    y = np.linspace(0, 3, n) + rng.normal(0, 0.01, n)
    fit = km.fit_kalman(y)
    assert fit["ok"]
    means, _ = km.forecast_kalman(fit, 10)
    assert means[-1] > means[0], "an upward drift was not extrapolated at all"


# ---------------------------------------------------------------------------
# Forecast structure
# ---------------------------------------------------------------------------

def test_damped_trend_converges_rather_than_extrapolating_forever():
    """
    phi < 1 makes the h-step increment a geometric sum. Successive increments
    must shrink; an undamped slope fitted to a run-up would extrapolate it to
    infinity, which is the failure this project's evaluation layer exists to
    catch.
    """
    fit = {"ok": True, "level": 0.0, "slope": 0.1, "phi": 0.8,
           "q_level": 1e-6, "q_slope": 1e-9, "r": 1e-4,
           "P": np.array([[1e-4, 0.0], [0.0, 1e-6]])}
    means, _ = km.forecast_kalman(fit, 12)
    steps = np.diff(means)
    assert np.all(steps > 0)
    assert np.all(np.diff(steps) < 0), "increments must shrink under damping"
    assert steps[-1] < steps[0] * 0.5


def test_forecast_variance_grows_with_horizon():
    fit = km.fit_kalman(_local_level())
    _, var = km.forecast_kalman(fit, 10)
    assert np.all(np.diff(var) > 0), "the cone must widen with horizon"


def test_forecast_on_an_unfitted_model_returns_empty():
    means, var = km.forecast_kalman({"ok": False}, 5)
    assert len(means) == 0 and len(var) == 0


def test_short_series_degrades_instead_of_raising():
    out = km.kalman_filter([1.0, 2.0], 0.1, 0.0, 1.0)
    assert not np.isfinite(out["loglik"])
    fit = km.fit_kalman([1.0, 2.0, 3.0])
    assert fit["ok"] is False


# ---------------------------------------------------------------------------
# The project-facing entry point
# ---------------------------------------------------------------------------

def test_prediction_has_the_project_schema_and_ordered_bounds():
    out = km.run_kalman_prediction(_price_frame(), "1d", 5)
    for col in ("datetime", "predicted_price", "lower_bound", "upper_bound",
                "volatility"):
        assert col in out.columns
    assert len(out) == 5
    assert (out["lower_bound"] < out["predicted_price"]).all()
    assert (out["predicted_price"] < out["upper_bound"]).all()
    assert np.all(np.diff(out["upper_bound"] - out["lower_bound"]) > 0)


def test_forecast_is_anchored_at_the_last_observed_price():
    """
    A local-level fit's one-step forecast is the filtered level, which must sit
    on top of the last price. A forecast that starts somewhere else is a bug in
    the level, not a view about the future.
    """
    df = _price_frame()
    last = float(df["adj_close"].iloc[-1])
    out = km.run_kalman_prediction(df, "1d", 3)
    assert abs(out["predicted_price"].iloc[0] - last) / last < 0.02


def test_both_band_modes_are_available_and_recorded():
    df = _price_frame()
    conf = km.run_kalman_prediction(df, "1d", 4, use_conformal=True)
    native = km.run_kalman_prediction(df, "1d", 4, use_conformal=False)
    assert conf.attrs["kalman"]["band_mode"] == "conformal"
    assert native.attrs["kalman"]["band_mode"] == "native-gaussian"
    # Both widths are recorded either way, so the comparison is always possible.
    for out in (conf, native):
        k = out.attrs["kalman"]
        assert len(k["native_halfwidth"]) == 4
        assert len(k["used_halfwidth"]) == 4


def test_attrs_report_the_fitted_parameters():
    """
    The fit must be inspectable. 'It degenerated to a random walk' is a result,
    and one that is invisible unless the parameters are surfaced.
    """
    k = km.run_kalman_prediction(_price_frame(), "1d", 3).attrs["kalman"]
    for key in ("q_level", "q_slope", "r", "phi", "loglik",
                "degenerate_to_random_walk", "n_calibration"):
        assert key in k
    assert 0.0 <= k["phi"] <= 1.0


def test_missing_price_column_raises_clearly():
    df = pd.DataFrame({"datetime": pd.bdate_range("2022-01-03", periods=100),
                       "volume": np.arange(100)})
    with pytest.raises(ValueError, match="price column"):
        km.run_kalman_prediction(df, "1d", 3)


def test_insufficient_history_raises_clearly():
    df = _price_frame(n=40)
    with pytest.raises(ValueError, match="insufficient history"):
        km.run_kalman_prediction(df, "1d", 3)
