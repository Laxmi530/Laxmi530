"""
Tests for epistemic.py (MC dropout) and the time-under-water metrics.

The epistemic tests pin two properties that would otherwise let the module lie:

1. **A model with no dropout must report "not measured", never zero.** Every
   stochastic pass through a deterministic network is identical, so the spread
   is exactly 0.0 — which reads as supreme confidence rather than the absence of
   a measurement.
2. **Sampling must not contaminate ordinary inference.** The book's TF 1.x
   recipe sets a global learning phase, which stays set and silently makes every
   later ``predict`` stochastic. Passing ``training=True`` per call is the only
   form that cannot leak; this is tested directly.
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import epistemic as epi
import strategy_metrics as sm


def _keras_or_skip():
    try:
        import tensorflow  # noqa: F401
    except Exception:
        pytest.skip("TensorFlow not available")


def _net(dropout=0.3, out=3):
    from tensorflow import keras
    from tensorflow.keras import layers
    inp = layers.Input(shape=(4,))
    x = layers.Dense(8, activation="relu")(inp)
    if dropout > 0:
        x = layers.Dropout(dropout)(x)
    y = layers.Dense(out)(x)
    m = keras.Model(inp, y)
    m.compile(loss="mse", optimizer="adam")
    return m


# ---------------------------------------------------------------------------
# has_dropout — the guard against reporting zero as confidence
# ---------------------------------------------------------------------------

def test_has_dropout_detects_an_active_layer():
    _keras_or_skip()
    assert epi.has_dropout(_net(dropout=0.3)) is True


def test_has_dropout_is_false_without_one():
    _keras_or_skip()
    assert epi.has_dropout(_net(dropout=0.0)) is False


def test_zero_rate_dropout_does_not_count():
    """rate=0 is a no-op layer; treating it as active would report a false 0."""
    _keras_or_skip()
    from tensorflow import keras
    from tensorflow.keras import layers
    inp = layers.Input(shape=(4,))
    x = layers.Dropout(0.0)(inp)
    m = keras.Model(inp, layers.Dense(2)(x))
    assert epi.has_dropout(m) is False


def test_has_dropout_never_raises_on_junk():
    assert epi.has_dropout(None) is False
    assert epi.has_dropout(object()) is False


# ---------------------------------------------------------------------------
# Sampling
# ---------------------------------------------------------------------------

def test_passes_actually_differ():
    """If dropout were not active, every pass would be identical."""
    _keras_or_skip()
    m = _net(dropout=0.5)
    x = np.random.default_rng(0).normal(size=(1, 4)).astype("float32")
    draws = epi.mc_dropout_predict(m, x, n_passes=20)
    assert draws is not None and draws.shape[0] == 20
    assert draws.std(axis=0).max() > 0, "dropout was not active during sampling"


def test_a_model_without_dropout_reports_unavailable_not_zero():
    _keras_or_skip()
    m = _net(dropout=0.0)
    x = np.zeros((1, 4), dtype="float32")
    assert epi.mc_dropout_predict(m, x) is None
    sp = epi.epistemic_spread(m, x)
    assert sp["available"] is False
    assert "mean_std" not in sp, "an unmeasurable model must not report a spread"
    assert "no active dropout" in sp["note"]


def test_sampling_does_not_leave_inference_stochastic():
    """
    The regression that matters. The book's set_learning_phase(1) recipe stays
    set on the graph and turns every later predict() random. Two ordinary
    predicts after sampling must still agree exactly.
    """
    _keras_or_skip()
    m = _net(dropout=0.5)
    x = np.random.default_rng(1).normal(size=(2, 4)).astype("float32")
    epi.mc_dropout_predict(m, x, n_passes=10)
    a = m.predict(x, verbose=0)
    b = m.predict(x, verbose=0)
    assert np.array_equal(a, b), "inference became stochastic after sampling"


def test_spread_reports_per_step_and_headline_values():
    _keras_or_skip()
    m = _net(dropout=0.4, out=3)
    x = np.random.default_rng(2).normal(size=(1, 4)).astype("float32")
    sp = epi.epistemic_spread(m, x, n_passes=30)
    assert sp["available"] is True
    assert len(sp["std_by_step"]) == 3
    assert sp["mean_std"] > 0
    assert sp["n_passes"] == 30


def test_epistemic_share_is_relative_to_the_aleatoric_scale():
    """
    The normalisation the falsifiable check forced. Dividing by the mean
    prediction was wrong: the target is a cumulative log return centred near
    zero, so that denominator was arbitrary. The conformal sigma is in the same
    units and gives a ratio that means something.
    """
    _keras_or_skip()
    m = _net(dropout=0.4)
    x = np.random.default_rng(3).normal(size=(1, 4)).astype("float32")
    sp = epi.epistemic_spread(m, x, n_passes=30, aleatoric_scale=0.02)
    assert np.isfinite(sp["epistemic_share"])
    assert sp["epistemic_share"] == pytest.approx(sp["mean_std"] / 0.02, rel=1e-9)


def test_share_is_nan_when_no_scale_is_supplied():
    _keras_or_skip()
    m = _net(dropout=0.4)
    x = np.zeros((1, 4), dtype="float32")
    sp = epi.epistemic_spread(m, x, n_passes=10)
    assert not np.isfinite(sp["epistemic_share"])
    for bad in (0.0, float("nan"), -1e-15):
        sp = epi.epistemic_spread(m, x, n_passes=10, aleatoric_scale=bad)
        assert not np.isfinite(sp["epistemic_share"]), bad


def test_attach_never_breaks_the_frame():
    df = pd.DataFrame({"predicted_price": [1.0, 2.0]})
    epi.attach(df, object(), np.zeros((1, 4)))       # broken model
    assert "epistemic" in df.attrs
    assert df.attrs["epistemic"]["available"] is False


def test_format_report_handles_the_unmeasured_case():
    assert "n/a" in epi.format_report("X", None)
    assert "n/a" in epi.format_report("X", {"available": False, "note": "no dropout"})


# ---------------------------------------------------------------------------
# Time under water (Klaas Ch. 4 - psychological tolerance bias)
# ---------------------------------------------------------------------------

def test_longest_underwater_counts_periods_below_the_high_water_mark():
    # up, then four losing periods, then a recovery beyond the old peak
    r = [0.10, -0.05, -0.05, -0.05, -0.05, 0.40]
    tuw = sm.time_under_water(r)
    assert tuw["longest_underwater"] == 4
    assert tuw["longest_losing_streak"] == 4
    assert tuw["unrecovered"] is False
    assert tuw["currently_underwater"] == 0


def test_an_unrecovered_drawdown_is_reported_separately():
    """
    A backtest ending mid-drawdown looks calmer than it was; the run an investor
    is actually sitting in is the one that decides whether they hold on.
    """
    r = [0.20, -0.05, -0.05, -0.05]
    tuw = sm.time_under_water(r)
    assert tuw["unrecovered"] is True
    assert tuw["currently_underwater"] == 3
    assert tuw["longest_underwater"] == 3


def test_a_monotonically_rising_curve_is_never_under_water():
    tuw = sm.time_under_water([0.01] * 10)
    assert tuw["longest_underwater"] == 0
    assert tuw["fraction_underwater"] == 0.0
    assert tuw["longest_losing_streak"] == 0


def test_years_are_reported_when_periods_per_year_is_given():
    r = [0.1] + [-0.01] * 126
    tuw = sm.time_under_water(r, periods_per_year=252)
    assert tuw["longest_underwater"] == 126
    assert tuw["longest_underwater_years"] == pytest.approx(0.5, abs=0.01)


def test_losing_streak_is_distinct_from_time_under_water():
    """
    The book's example is 'four months in a row' of losses; a strategy can also
    be under water without losing every period. The two must not be conflated.
    """
    r = [0.50, -0.10, 0.01, -0.10, 0.01, 0.01]
    tuw = sm.time_under_water(r)
    assert tuw["longest_losing_streak"] == 1
    assert tuw["longest_underwater"] == 5


def test_degenerate_input_returns_zeros_rather_than_raising():
    tuw = sm.time_under_water([])
    assert tuw["longest_underwater"] == 0
    tuw = sm.time_under_water([float("nan"), float("nan")])
    assert tuw["longest_underwater"] == 0


def test_drawdown_series_matches_max_drawdown():
    r = [0.10, -0.20, 0.05, -0.10, 0.30]
    dd = sm.drawdown_series(r)
    assert dd.min() == pytest.approx(sm.max_drawdown(r)["max_drawdown"], rel=1e-9)
    assert (dd <= 1e-12).all(), "drawdown must never be positive"
