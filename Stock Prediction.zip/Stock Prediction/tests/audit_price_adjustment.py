"""
One-shot data-hygiene audit: does training on yfinance's *back-adjusted* close
(``Adj Close``) leak future corporate actions (splits / dividends) into the past?

Why this matters
----------------
yfinance retro-adjusts the price series for *all* splits and dividends, including
ones that happen **after** a given bar. The whole project trains on ``adj_close``
(``model_utils.prepare_log_returns``, ``ML_model.create_features``). So:

* **Live serving** — no leak. At serve time the latest bar carries adjustment
  factor 1.0 and every earlier bar is adjusted only by actions that have
  *already* happened (legitimately known). Using ``adj_close`` is correct.
* **Walk-forward backtest** — a *small* look-ahead. When we slice *today's*
  fully-adjusted series at a past origin, the adjustment factors from actions
  between that origin and today are already baked into the origin's history.
  That can slightly distort the level path the backtest sees and the gate/
  leaderboard numbers derived from it.

This script measures the size of that backtest-only leak so we can make an
evidence-based call: fix it (point-in-time raw close) or document it as
immaterial. It does NOT change any model.

Run:
    python tests/audit_price_adjustment.py                 # default NSE basket
    python tests/audit_price_adjustment.py RELIANCE.NS TCS.NS
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import yfinance as yf

DEFAULT_TICKERS = ["RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ITC.NS"]
PERIOD = "5y"          # daily lookback to inspect
EPS = 1e-6             # return-difference threshold to count a bar as "affected"


def _fetch(ticker):
    """Return a frame with raw close and adjusted close, tz-naive, sorted."""
    raw = yf.Ticker(ticker).history(
        period=PERIOD, interval="1d", auto_adjust=False, actions=True
    )
    if raw.empty:
        return None
    raw = raw.reset_index()
    raw.columns = [c.lower().replace(" ", "_") for c in raw.columns]
    date_col = "date" if "date" in raw.columns else "datetime"
    raw[date_col] = pd.to_datetime(raw[date_col]).dt.tz_localize(None)
    raw = raw.rename(columns={date_col: "datetime"}).sort_values("datetime")
    keep = ["datetime", "close", "adj_close"]
    for extra in ("dividends", "stock_splits"):
        if extra in raw.columns:
            keep.append(extra)
    return raw[keep].reset_index(drop=True)


def audit(ticker):
    df = _fetch(ticker)
    if df is None or len(df) < 50:
        print(f"  {ticker}: no/insufficient data — skipped")
        return None

    close = df["close"].to_numpy(float)
    adj = df["adj_close"].to_numpy(float)

    # Cumulative adjustment factor (1.0 at the most recent bar by construction).
    factor = adj / close
    factor = factor / factor[-1]            # normalise so present == 1.0

    # 1. How many corporate-action "steps" sit in this window?
    step = np.abs(np.diff(factor)) / np.maximum(np.abs(factor[:-1]), 1e-12)
    action_bars = np.where(step > 1e-4)[0] + 1
    n_div = int((df["dividends"] > 0).sum()) if "dividends" in df else None
    n_split = int((df["stock_splits"] != 0).sum()) if "stock_splits" in df else None

    # 2. Return-level leak: where do adjusted and raw log-returns differ?
    r_raw = np.diff(np.log(close))
    r_adj = np.diff(np.log(adj))
    diff = np.abs(r_adj - r_raw)
    affected = int((diff > EPS).sum())
    pct_affected = 100.0 * affected / len(diff)
    max_ret_diff = float(diff.max())
    mean_ret_diff_affected = float(diff[diff > EPS].mean()) if affected else 0.0

    # 3. Backtest level-distortion: at the *earliest* origin, how much are levels
    #    rescaled by future actions vs. what a point-in-time series would show?
    #    factor[origin] != 1 means that origin's history is scaled by later events.
    max_level_distortion = float(np.abs(factor[0] - 1.0)) * 100.0
    median_level_distortion = float(np.abs(np.median(factor) - 1.0)) * 100.0

    print(f"\n=== {ticker} ===  ({len(df)} bars, {df['datetime'].iloc[0].date()} -> {df['datetime'].iloc[-1].date()})")
    print(f"  corporate-action steps in window : {len(action_bars)}"
          + (f"  (dividends={n_div}, splits={n_split})" if n_div is not None else ""))
    print(f"  bars with returns affected       : {affected}/{len(diff)} ({pct_affected:.2f}%)")
    print(f"  max single-bar return diff       : {max_ret_diff*100:.3f}%  (adjusted removes the action jump)")
    print(f"  mean return diff on affected bars: {mean_ret_diff_affected*100:.3f}%")
    print(f"  level distortion at oldest origin: {max_level_distortion:.2f}%  (future actions baked into past levels)")
    print(f"  median level distortion          : {median_level_distortion:.2f}%")

    return {
        "ticker": ticker,
        "bars": len(df),
        "action_steps": len(action_bars),
        "pct_returns_affected": round(pct_affected, 3),
        "max_ret_diff_pct": round(max_ret_diff * 100, 4),
        "max_level_distortion_pct": round(max_level_distortion, 3),
        "median_level_distortion_pct": round(median_level_distortion, 3),
    }


def main():
    tickers = sys.argv[1:] or DEFAULT_TICKERS
    print("Price-adjustment look-ahead audit (adj_close vs raw close)")
    print("=" * 64)
    rows = [r for t in tickers if (r := audit(t)) is not None]
    if not rows:
        print("\nNo data fetched.")
        return
    summary = pd.DataFrame(rows)
    print("\n" + "=" * 64)
    print("SUMMARY")
    print(summary.to_string(index=False))
    print("\nInterpretation:")
    print("  * '% returns affected' counts bars where adjusted != raw return.")
    print("    These are corporate-action bars; on them the *adjusted* return is")
    print("    the economically correct one (it removes the artificial split/")
    print("    dividend price jump). Everywhere else the two are identical, so")
    print("    every scale-invariant feature (return/ratio/RSI/vol/z-score) is")
    print("    unchanged. The residual leak is the few action bars only.")
    print("  * 'level distortion' is how much a past origin's price LEVELS are")
    print("    rescaled by actions that occur after it — the backtest-only leak.")
    print("    It is zero at live serve time (latest bar factor = 1.0).")


if __name__ == "__main__":
    main()
