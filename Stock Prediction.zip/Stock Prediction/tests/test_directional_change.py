"""
Tests for :mod:`directional_change` -- Tsang, *AI for Finance*, Ch. 6.

Three groups carry the weight:

* **The book's own worked example.** Figure 6.1 states its extremes and its
  trend magnitudes in the text (+7, -22, +21 on a 5% threshold). The event
  table must reproduce them, including the part the book does *not* say
  explicitly: the third trend is still running at the end of the data and must
  not be reported as if its end were known.
* **Causality.** ``dc_state`` promises every bar is a function of the bars up
  to it. The promise is worth exactly as much as the test that recomputes on
  truncated prefixes and demands the overlap match bit for bit. The obvious
  implementation of DC features fails this, which is why the test is here.
* **The null.** Olsen's two scaling laws are reproduced by a driftless random
  walk -- law 1 provably, since the running maximum before a ``theta`` drawdown
  is Exponential with mean ``theta``. ``test_overshoot_is_exponential_under_a_
  random_walk`` pins the mean at 1.0 and the median at ln 2, so nobody can
  later quote a market measurement of "OS/theta ~ 1" as evidence of anything.
"""

import numpy as np
import pandas as pd
import pytest

import directional_change as dc


# ==========================================
# helpers
# ==========================================
def _walk(n=4000, sigma=0.01, seed=0, drift=0.0):
    """A driftless (by default) geometric random walk."""
    rng = np.random.default_rng(seed)
    return pd.Series(100.0 * np.exp(np.cumsum(
        rng.standard_normal(n) * sigma + drift)))


#: Tsang, Figure 6.1: extremes at 110, 98, 105, 83, 104 on a 5% threshold.
FIG_61 = pd.Series([110.0, 98.0, 105.0, 90.0, 83.0, 104.0])


# ==========================================
# 1. The book's worked example
# ==========================================
def test_figure_6_1_reproduces_the_books_trend_magnitudes():
    ev = dc.dc_events(FIG_61, 0.05)
    # Section 6.3: "prices have changed by (105-98=) 7 ... (83-105=) -22"
    moves = (ev["total_move"] * ev["ext_price"]).round(2).tolist()
    assert moves == [-12.0, 7.0, -22.0]


def test_figure_6_1_withholds_the_incomplete_final_trend():
    # The book's third listed trend (83 -> 104, +21) has not ended: 104 is the
    # running extreme, not a confirmed one. Reporting it would mean treating a
    # running maximum as final, which is the whole lookahead failure in
    # miniature.
    ev = dc.dc_events(FIG_61, 0.05)
    assert len(ev) == 3
    assert ev["end_price"].iloc[-1] == 83.0


def test_figure_6_1_extremes_match_the_book():
    ev = dc.dc_events(FIG_61, 0.05)
    assert ev["ext_price"].tolist() == [110.0, 98.0, 105.0]
    assert ev["end_price"].tolist() == [98.0, 105.0, 83.0]


# ==========================================
# 2. Structural invariants of the event table
# ==========================================
def test_directions_strictly_alternate():
    ev = dc.dc_events(_walk(seed=1), 0.03)
    assert len(ev) > 20
    d = ev["direction"].to_numpy()
    assert np.all(d[1:] == -d[:-1])


def test_each_trend_starts_where_the_previous_one_ended():
    ev = dc.dc_events(_walk(seed=2), 0.03)
    assert ev["ext_price"].to_numpy()[1:] == pytest.approx(
        ev["end_price"].to_numpy()[:-1])
    assert (ev["ext_index"].to_numpy()[1:]
            == ev["end_index"].to_numpy()[:-1]).all()


def test_indices_are_ordered_within_a_trend():
    ev = dc.dc_events(_walk(seed=3), 0.03)
    assert (ev["ext_index"] <= ev["confirm_index"]).all()
    assert (ev["confirm_index"] <= ev["end_index"]).all()


def test_the_dc_leg_always_clears_the_threshold():
    theta = 0.03
    ev = dc.dc_events(_walk(seed=4), theta)
    # >= rather than ==: on discrete bars the confirming move can overshoot.
    assert (ev["dc_move"].abs() >= theta - 1e-12).all()


def test_both_legs_move_in_the_trend_direction():
    ev = dc.dc_events(_walk(seed=5), 0.03)
    d = ev["direction"].to_numpy()
    assert np.all(np.sign(ev["dc_move"].to_numpy()) == d)
    os_move = ev["os_move"].to_numpy()
    assert np.all((np.sign(os_move) == d) | (os_move == 0.0))


def test_a_bigger_threshold_yields_no_more_events():
    w = _walk(seed=6)
    counts = [len(dc.dc_events(w, t)) for t in (0.01, 0.02, 0.05, 0.10)]
    assert counts == sorted(counts, reverse=True)
    assert counts[0] > counts[-1]


def test_events_are_invariant_to_the_price_scale():
    # DC is defined on ratios, so a currency redenomination must not change it.
    w = _walk(seed=7)
    a = dc.dc_events(w, 0.04)
    b = dc.dc_events(w * 83.0, 0.04)
    assert a["ext_index"].tolist() == b["ext_index"].tolist()
    assert a["total_move"].to_numpy() == pytest.approx(b["total_move"].to_numpy())


# ==========================================
# 3. Degenerate input
# ==========================================
def test_a_monotonic_path_produces_no_completed_trend():
    assert len(dc.dc_events(pd.Series(np.linspace(100, 200, 500)), 0.05)) == 0


@pytest.mark.parametrize("bad", [0.0, -0.05, np.nan])
def test_invalid_threshold_returns_an_empty_table(bad):
    ev = dc.dc_events(_walk(seed=8), bad)
    assert len(ev) == 0
    assert list(ev.columns) == list(dc.EVENT_COLUMNS)


@pytest.mark.parametrize("n", [0, 1, 2])
def test_too_few_bars_returns_an_empty_table(n):
    assert len(dc.dc_events(pd.Series([100.0] * n), 0.05)) == 0


def test_non_positive_prices_are_dropped():
    # A halted session occasionally arrives from yfinance as 0.0; every DC
    # ratio would be inf or nan.
    s = pd.Series([100.0, 0.0, 94.0, 101.0, 90.0, 99.0, 88.0])
    ev = dc.dc_events(s, 0.05)
    assert np.isfinite(ev["total_move"].to_numpy()).all()


def test_the_first_direction_is_read_from_the_data_not_assumed():
    # Mirrored paths must give mirrored first trends. An implementation that
    # seeds `mode = up` would give the same first direction for both.
    up_first = pd.Series([100.0, 106.0, 100.0, 94.0, 100.0])
    down_first = pd.Series([100.0, 94.0, 100.0, 106.0, 100.0])
    assert dc.dc_events(up_first, 0.05)["direction"].iloc[0] == 1
    assert dc.dc_events(down_first, 0.05)["direction"].iloc[0] == -1


def test_a_dataframe_prefers_the_adjusted_close():
    # Raw closes carry splits; a 1:10 split is a -90% move and fabricates an
    # event at every threshold. Same lesson as range_volatility's scale trap.
    # Identical price action either side of a 1:10 split. The adjusted series
    # never moves 5%; the raw one manufactures a whole trend out of the split.
    df = pd.DataFrame({"close": [100.0, 101.0, 10.2, 10.1, 10.3, 10.7],
                       "adj_close": [10.0, 10.1, 10.2, 10.1, 10.3, 10.7]})
    assert len(dc.dc_events(df, 0.05)) == 0
    assert len(dc.dc_events(df[["close"]], 0.05)) == 1


# ==========================================
# 4. Causality -- the reason this module is split in two
# ==========================================
@pytest.mark.parametrize("cut", [60, 137, 400, 999])
def test_dc_state_is_invariant_to_future_bars(cut):
    """
    The guarantee: state at bar i depends on prices[:i+1] and nothing after.

    Recomputing on a prefix must leave the overlapping rows bit-identical. A
    version that backdates the direction flip to the extreme -- the natural
    thing to write, and what a groupby over the event table gives you -- fails
    this on every bar between an extreme and its confirmation.
    """
    w = _walk(n=1000, seed=11)
    full = dc.dc_state(w, 0.05)
    pre = dc.dc_state(w.iloc[:cut], 0.05)
    assert full.iloc[:cut].to_numpy() == pytest.approx(
        pre.to_numpy(), nan_ok=True, abs=0.0)


def test_direction_is_zero_until_the_first_confirmation():
    st = dc.dc_state(FIG_61, 0.05)
    # 110 -> 98 is the first confirmed change, at position 1.
    assert st["direction"].iloc[0] == 0
    assert st["direction"].iloc[1] == -1


def test_state_flips_at_the_confirmation_bar_not_the_extreme():
    w = _walk(n=800, seed=12)
    ev = dc.dc_events(w, 0.05)
    st = dc.dc_state(w, 0.05)
    assert len(ev) > 5
    for _, row in ev.iloc[1:].iterrows():
        ext_i, conf_i = int(row["ext_index"]), int(row["confirm_index"])
        if conf_i <= ext_i:
            continue                      # confirmed in the same bar
        # At the extreme the new direction is not yet known; at the
        # confirmation it is.
        assert st["direction"].iloc[ext_i] == -row["direction"]
        assert st["direction"].iloc[conf_i] == row["direction"]


def test_state_and_events_agree_on_where_each_trend_started():
    w = _walk(n=800, seed=13)
    ev = dc.dc_events(w, 0.05)
    st = dc.dc_state(w, 0.05)
    for _, row in ev.iterrows():
        conf_i = int(row["confirm_index"])
        expected = int(conf_i - row["ext_index"])
        assert st["bars_in_trend"].iloc[conf_i] == expected


def test_retrace_is_bounded_and_reaches_one_at_a_confirmation():
    w = _walk(n=800, seed=14)
    st = dc.dc_state(w, 0.05)
    r = st["retrace"].dropna().to_numpy()
    assert r.min() >= 0.0 and r.max() <= 1.0
    ev = dc.dc_events(w, 0.05)
    # The bar before a confirmation has not yet reversed a full theta.
    for _, row in ev.iloc[1:].iterrows():
        conf_i = int(row["confirm_index"])
        if conf_i > 0:
            assert st["retrace"].iloc[conf_i - 1] < 1.0


def test_overshoot_is_signed_by_progress_not_by_price():
    # Tsang's nowcasting example, 6.6: a downtrend 6x past a 5% threshold.
    # Falling prices in a downtrend are *progress*, so overshoot is positive.
    s = pd.Series([100.0, 94.0, 88.0, 82.0, 76.0, 70.0])
    st = dc.dc_state(s, 0.05)
    assert (st["overshoot"].iloc[1:] >= 0).all()
    assert st["direction"].iloc[-1] == -1


# ==========================================
# 5. The null: both "striking discoveries" are random-walk properties
# ==========================================
def test_overshoot_is_exponential_under_a_random_walk():
    """
    For driftless Brownian motion the running maximum reached before a
    ``theta`` drawdown is Exponential with mean ``theta``. So ``OS/theta`` has
    mean 1 and median ln 2 -- no market required.

    Steps are fine relative to theta so the walk approximates continuous
    monitoring; on coarse bars the confirming move overshoots and both
    statistics inflate (see ``dc_over_theta_mean``).
    """
    theta = 0.05
    w = _walk(n=300_000, sigma=theta / 12.0, seed=15)
    s = dc.scaling_laws(dc.dc_events(w, theta), theta)
    assert s["n_events"] > 400
    assert s["os_over_theta_mean"] == pytest.approx(1.0, abs=0.12)
    assert s["os_over_theta_median"] == pytest.approx(np.log(2.0), abs=0.10)


def test_the_time_law_also_holds_under_a_random_walk():
    theta = 0.05
    w = _walk(n=300_000, sigma=theta / 12.0, seed=16)
    s = dc.scaling_laws(dc.dc_events(w, theta), theta)
    assert s["time_ratio_mean"] == pytest.approx(2.0, abs=0.35)


def test_coarse_bars_inflate_the_dc_leg_beyond_the_threshold():
    # Why os_over_dc_mean exists: at daily resolution the DC leg is not theta.
    theta = 0.05
    fine = dc.scaling_laws(
        dc.dc_events(_walk(n=200_000, sigma=theta / 12.0, seed=17), theta), theta)
    coarse = dc.scaling_laws(
        dc.dc_events(_walk(n=200_000, sigma=theta, seed=17), theta), theta)
    assert fine["dc_over_theta_mean"] < 1.25
    assert coarse["dc_over_theta_mean"] > 1.4
    # The ratio of the two legs is the resolution-robust statistic.
    assert coarse["os_over_dc_mean"] == pytest.approx(1.0, abs=0.15)


# ==========================================
# 6. Volatility measures and reporting
# ==========================================
def test_dc_volatility_counts_events_in_the_period_they_end():
    idx = pd.date_range("2024-01-01", periods=400, freq="B")
    w = _walk(n=400, seed=18)
    w.index = idx
    ev = dc.dc_events(w, 0.03)
    vol = dc.dc_volatility(ev, freq="ME")
    assert vol["dc_count"].sum() == len(ev)
    assert (vol["mean_move"].dropna() > 0).all()


def test_dc_volatility_handles_an_empty_event_table():
    vol = dc.dc_volatility(dc.dc_events(pd.Series([1.0, 2.0]), 0.05))
    assert len(vol) == 0
    assert list(vol.columns) == ["dc_count", "mean_move"]


def test_scaling_laws_on_an_empty_table_reports_no_events():
    assert dc.scaling_laws(dc.dc_events(pd.Series(dtype=float), 0.05),
                           0.05)["n_events"] == 0


# ==========================================
# 7. The drift trap -- scaling_law_test's reason to exist
# ==========================================
def test_theory_constants_are_the_brownian_limits():
    # Law 1 has a closed form; these are not tuned to any dataset.
    assert dc.DRIFTLESS_THEORY["os_over_theta_mean"] == 1.0
    assert dc.DRIFTLESS_THEORY["os_over_theta_median"] == pytest.approx(
        np.log(2.0), abs=1e-12)
    assert dc.DRIFTLESS_THEORY["time_ratio_mean"] == 2.0


def test_a_driftless_walk_shows_no_deviation_from_its_own_null():
    r = dc.scaling_law_test(_walk(n=6000, sigma=0.012, seed=20), 0.05,
                            n_null=25, seed=1)
    assert r["n_events"] > 40
    assert abs(r["os_over_dc_mean"]["z"]) < 2.5
    assert r["os_over_dc_mean"]["null_mean"] == pytest.approx(1.0, abs=0.10)


def test_drift_alone_manufactures_a_deviation_unless_demeaned():
    """
    The regression guard for README §44.

    A pure random walk plus drift contains no directional structure whatsoever,
    yet measured against a driftless null it reports a large deviation -- the
    overshoot leg runs further simply because the series trends. On 395 real
    NSE names this reached t = +6.2 and replicated across four thresholds.

    ``demean=True`` is the default precisely so the wrong answer takes an
    explicit argument to obtain.
    """
    # +25%/yr on top of an otherwise ordinary walk.
    trended = _walk(n=6000, sigma=0.012, seed=21, drift=0.25 / 252.0)
    raw = dc.scaling_law_test(trended, 0.05, n_null=25, demean=False, seed=1)
    fixed = dc.scaling_law_test(trended, 0.05, n_null=25, demean=True, seed=1)

    assert raw["drift_annual"] > 0.15
    assert raw["os_over_dc_mean"]["z"] > 3.0        # the artefact
    assert abs(fixed["os_over_dc_mean"]["z"]) < 2.5  # gone once controlled
    assert abs(fixed["os_over_dc_mean"]["z"]) < abs(raw["os_over_dc_mean"]["z"])


def test_the_null_preserves_the_magnitude_distribution_exactly():
    # The point of a sign flip over a Gaussian draw: |r_t| is untouched, so
    # volatility clustering and fat tails cannot explain any deviation.
    rng = np.random.default_rng(3)
    w = _walk(n=500, seed=22)
    r = np.diff(np.log(w.to_numpy(dtype=float)))
    flipped = dc.sign_flip_path(r, rng)
    got = np.diff(np.log(flipped.to_numpy(dtype=float)))
    assert np.sort(np.abs(got)) == pytest.approx(np.sort(np.abs(r)))


def test_scaling_law_test_is_seeded_and_degrades_quietly():
    w = _walk(n=3000, seed=23)
    a = dc.scaling_law_test(w, 0.05, n_null=10, seed=5)
    b = dc.scaling_law_test(w, 0.05, n_null=10, seed=5)
    assert a["os_over_dc_mean"]["z"] == pytest.approx(b["os_over_dc_mean"]["z"])
    assert dc.scaling_law_test(pd.Series([100.0, 101.0]), 0.05)["n_events"] == 0
    assert dc.scaling_law_test(w, 0.0)["n_events"] == 0


def test_format_law_test_shows_the_theory_column_and_flags_raw_mode():
    w = _walk(n=3000, seed=24)
    assert "theory" in dc.format_law_test(dc.scaling_law_test(w, 0.05, n_null=5))
    raw = dc.format_law_test(dc.scaling_law_test(w, 0.05, n_null=5, demean=False))
    assert "NOT demeaned" in raw
    assert dc.format_law_test({"n_events": 0}) == "no completed trends"


def test_summary_and_report_render():
    w = _walk(n=2000, seed=19)
    rows = [dc.summary(w, t) for t in dc.DEFAULT_THETAS]
    text = dc.format_report(rows)
    assert "OS/theta" in text and "2." in text
    assert all(r["bars"] == 2000 for r in rows)
    assert rows[0]["events_per_year"] > rows[-1]["events_per_year"]
