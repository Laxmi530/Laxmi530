"""
Cross-sectional panel: pool many tickers into one dataset, split by **asset**.

Motivated by *Hands-On Deep Learning for Finance* (Troiano et al.), Chapter 6,
"Trading Rule Identification by CNN", whose setup is the part of that chapter
that matters most here: **2,700 NASDAQ stocks**, ~8 million rows, and an
**asset-stratified** split — fit on 700 names, validate on 300 entirely
different ones.

Why this is the highest-upside idea in the book for this project
---------------------------------------------------------------
Every "no edge" result in this repository rests on **~1000 rows of one ticker**.
White's Reality Check *p* = 0.90, Hansen's SPA *p* = 0.87, MASE > 1 almost
everywhere — all measured in that regime. The binding constraint was never the
model family; it was sample size and signal-to-noise. Adding a fifth architecture
to a 1000-row problem cannot fix that. Pooling 200 tickers turns it into a
200,000-row problem, which is a different problem.

The **asset-stratified split** is the other half, and it is a stronger
generalisation claim than the walk-forward split used everywhere else here:

* A temporal split asks *"does this pattern survive into next month?"*
* An asset split asks *"does this pattern exist in stocks the model has never
  seen?"* — which is much harder to satisfy by memorisation, because there is no
  shared price level, no shared regime history, and no shared idiosyncratic noise
  to latch onto.

This project's own cross-sectional probe (`tests/validation/cross_sectional.py`)
found 12-1 momentum with the right sign but *t* ≈ 1, and explicitly concluded it
needed **hundreds of names**. This module is the infrastructure for that.

What this module is and is not
------------------------------
It is a **panel builder**, deliberately separate from any model. It fetches a
universe, computes the existing scale-free feature set per ticker, aligns
everything on a common calendar, and produces train/validation splits that are
honest in two independent ways at once. Nothing here trains anything — the model
lives in ``cross_sectional_model.py`` — because the panel is the part that is
easy to get subtly wrong and worth testing on its own.

Three leakage traps it is built to avoid
----------------------------------------
1. **Survivorship.** Fetching "today's NIFTY constituents" and back-testing them
   over ten years silently selects the winners. The universe is therefore an
   explicit caller-supplied list, and every result records which tickers were
   used and which failed, so the selection is auditable rather than implicit.
2. **Cross-sectional look-ahead.** Any feature normalised *across* stocks at time
   t (a rank, a z-score) must use only that day's cross-section — never the full
   history's statistics. :func:`add_cross_sectional_ranks` does the former.
3. **Both splits at once.** An asset split alone still lets the model see the
   *same calendar period* in training and validation, so a market-wide regime
   present in both inflates the score. :func:`split_panel` supports asset-only,
   time-only, and — the honest default — **combined**: unseen names *and* unseen
   dates.
"""

import numpy as np
import pandas as pd

# A default NSE universe. Deliberately a literal list, not a live index scrape:
# an index membership API returns TODAY's constituents, and using those over a
# historical window is textbook survivorship bias. A fixed list is auditable and
# reproducible, and its own biases are at least visible.
DEFAULT_UNIVERSE = [
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "HINDUNILVR.NS", "ITC.NS", "SBIN.NS", "BHARTIARTL.NS", "KOTAKBANK.NS",
    "LT.NS", "AXISBANK.NS", "ASIANPAINT.NS", "MARUTI.NS", "TITAN.NS",
    "SUNPHARMA.NS", "ULTRACEMCO.NS", "WIPRO.NS", "NESTLEIND.NS", "TATAMOTORS.NS",
    "BAJFINANCE.NS", "HCLTECH.NS", "POWERGRID.NS", "NTPC.NS", "TATASTEEL.NS",
    "JSWSTEEL.NS", "GRASIM.NS", "ADANIPORTS.NS", "CIPLA.NS", "DRREDDY.NS",
    "BRITANNIA.NS", "COALINDIA.NS", "EICHERMOT.NS", "HEROMOTOCO.NS", "BPCL.NS",
    "DIVISLAB.NS", "HINDALCO.NS", "INDUSINDBK.NS", "M&M.NS", "ONGC.NS",
]

# Cross-sectional feature columns added on top of the per-ticker features.
CS_COLS = ["rank_mom_21", "rank_mom_63", "rank_vol_21", "rank_rev_5",
           "mkt_excess_21"]

_MIN_ROWS_PER_TICKER = 300


# ==========================================
# 1. Fetch and stack
# ==========================================
def build_panel(tickers=None, fetch_fn=None, min_rows=_MIN_ROWS_PER_TICKER,
                verbose=True):
    """
    Fetch every ticker and stack them into one long-format panel.

    Long format (one row per ticker-date) rather than wide, because the
    cross-sectional operations below are ``groupby(date)`` reductions and the
    panel is ragged — tickers list and delist, and forcing a rectangular frame
    would either drop history or fabricate it.

    Parameters
    ----------
    tickers : list of str, optional
        Universe. Defaults to :data:`DEFAULT_UNIVERSE`.
    fetch_fn : callable, optional
        ``fetch_fn(ticker) -> DataFrame`` with 'datetime' + OHLCV. Defaults to a
        yfinance fetcher; injected in tests so they run offline.
    min_rows : int, optional
        Tickers with less history than this are dropped (and reported).
    verbose : bool, optional
        Print per-ticker progress.

    Returns
    -------
    (pd.DataFrame, dict)
        ``(panel, report)``. The panel has columns
        ['ticker', 'datetime', 'open', 'high', 'low', 'close', 'adj_close',
        'volume']; the report records which tickers were used, which were
        dropped and why — so the universe selection is auditable rather than
        implicit (see the survivorship note in the module docstring).
    """
    tickers = list(tickers or DEFAULT_UNIVERSE)
    fetch_fn = fetch_fn or _default_fetch

    frames, used, dropped = [], [], {}
    for i, t in enumerate(tickers, 1):
        try:
            df = fetch_fn(t)
        except Exception as exc:
            dropped[t] = f"fetch failed: {str(exc)[:60]}"
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            dropped[t] = "no data"
            continue
        df = df.copy()
        df["datetime"] = pd.to_datetime(df["datetime"])
        df = df.dropna(subset=["adj_close"]).sort_values("datetime")
        if len(df) < min_rows:
            dropped[t] = f"only {len(df)} rows (< {min_rows})"
            continue
        df["ticker"] = t
        frames.append(df)
        used.append(t)
        if verbose:
            print(f"  [{i}/{len(tickers)}] {t}: {len(df)} rows")

    if not frames:
        return pd.DataFrame(), {"used": [], "dropped": dropped, "n_rows": 0}

    cols = ["ticker", "datetime", "open", "high", "low", "close",
            "adj_close", "volume"]
    panel = pd.concat(frames, ignore_index=True)
    panel = panel[[c for c in cols if c in panel.columns]]
    panel = panel.sort_values(["datetime", "ticker"]).reset_index(drop=True)

    report = {"used": used, "dropped": dropped, "n_rows": int(len(panel)),
              "n_tickers": len(used),
              "start": str(panel["datetime"].min().date()),
              "end": str(panel["datetime"].max().date())}
    if verbose:
        print(f"Panel: {report['n_rows']:,} rows x {report['n_tickers']} tickers "
              f"({report['start']} -> {report['end']}); "
              f"{len(dropped)} dropped")
    return panel, report


def _default_fetch(ticker, period="8y"):
    """yfinance fetcher mapped to the project schema."""
    import yfinance as yf
    h = yf.Ticker(ticker).history(period=period, interval="1d",
                                  auto_adjust=False)
    if h is None or h.empty:
        return pd.DataFrame()
    h = h.reset_index()
    h.columns = [c.lower().replace(" ", "_") for c in h.columns]
    h = h.rename(columns={"date": "datetime"})
    h["datetime"] = pd.to_datetime(h["datetime"]).dt.tz_localize(None)
    keep = ["datetime", "open", "high", "low", "close", "adj_close", "volume"]
    return h[[c for c in keep if c in h.columns]].dropna()


# ==========================================
# 2. Features
# ==========================================
def add_ticker_features(panel, interval="daily"):
    """
    Add the project's existing per-ticker feature set to every name in the panel.

    Reuses ``ML_model.create_features`` rather than defining a parallel set, so
    the cross-sectional experiment is testing the *pooling*, not a different
    feature engineering pipeline — otherwise a difference in results could not be
    attributed to either.

    Applied strictly **per ticker** (grouped), so no rolling window ever spans a
    ticker boundary — the most obvious way to corrupt a stacked panel.
    """
    from ML_model import create_features

    out = []
    for t, g in panel.groupby("ticker", sort=False):
        try:
            f = create_features(g.drop(columns=["ticker"]), interval)
        except Exception as exc:
            print(f"cross_sectional_panel: features failed for {t} ({exc})")
            continue
        if f.empty:
            continue
        f = f.reset_index()
        f["ticker"] = t
        out.append(f)
    if not out:
        return pd.DataFrame()
    res = pd.concat(out, ignore_index=True)
    return res.sort_values(["datetime", "ticker"]).reset_index(drop=True)


def add_cross_sectional_ranks(panel):
    """
    Add features that only exist *because* there is a cross-section.

    This is the genuinely new information pooling buys, and the reason the
    exercise is not simply "the same model with more rows". A single-ticker model
    can know a stock rose 4% last month; only a panel can know whether that was
    the best or the worst move in its universe that month — and the cross-
    sectional literature's persistent findings (momentum, short-term reversal,
    low-volatility) are all statements about *relative* position.

    Every rank is computed **within a single date's cross-section** and scaled to
    [0, 1], which is what keeps it causal: it uses other stocks' contemporaneous
    values, never any stock's future, and never full-history statistics.

    Added columns:

    * ``rank_mom_21`` / ``rank_mom_63`` — 1- and 3-month momentum rank.
    * ``rank_vol_21`` — realised-volatility rank (the low-vol axis).
    * ``rank_rev_5`` — 1-week reversal rank (short-horizon losers tend to bounce).
    * ``mkt_excess_21`` — the stock's 21-day return minus the **equal-weighted
      panel mean** for the same window, i.e. a market-neutral excess return whose
      market proxy is the universe itself rather than an external index.
    """
    df = panel.copy()
    df = df.sort_values(["ticker", "datetime"])
    g = df.groupby("ticker", sort=False)["adj_close"]

    df["_m21"] = np.log(df["adj_close"] / g.shift(21))
    df["_m63"] = np.log(df["adj_close"] / g.shift(63))
    df["_r5"] = np.log(df["adj_close"] / g.shift(5))
    ret1 = np.log(df["adj_close"] / g.shift(1))
    df["_v21"] = (ret1.groupby(df["ticker"]).rolling(21).std()
                  .reset_index(level=0, drop=True))

    def _rank(col):
        # pct=True gives a [0,1] rank within each date's cross-section, so the
        # scale is comparable across dates even as the universe size changes.
        return df.groupby("datetime")[col].rank(pct=True)

    df["rank_mom_21"] = _rank("_m21")
    df["rank_mom_63"] = _rank("_m63")
    df["rank_vol_21"] = _rank("_v21")
    df["rank_rev_5"] = _rank("_r5")
    df["mkt_excess_21"] = df["_m21"] - df.groupby("datetime")["_m21"].transform("mean")

    df = df.drop(columns=["_m21", "_m63", "_r5", "_v21"])
    for c in CS_COLS:
        df[c] = df[c].replace([np.inf, -np.inf], np.nan)
    return df.sort_values(["datetime", "ticker"]).reset_index(drop=True)


# ==========================================
# 3. Labels (book Ch. 6: buy / do nothing / short)
# ==========================================
def add_labels(panel, horizon=5, deadband=None, market_neutral=True):
    """
    Attach the book's **three-class** label: buy / do nothing / short.

    Chapter 6 frames trading as classification with an explicit "do nothing"
    class, which fits this project unusually well: its central product feature is
    **abstention**, and every existing model is a regressor forced to produce a
    direction whether or not one is warranted. A three-class target lets "no
    view" be a first-class prediction rather than a threshold applied afterwards.

    Two design choices:

    * **market_neutral** (default) — the label is built on the return *relative to
      the equal-weighted panel mean* for the same window, not the raw return. On
      a single stock that distinction is cosmetic; across a panel it is essential,
      because otherwise every name shares the market move and the classifier
      learns to predict *the index*, scoring well while carrying no
      cross-sectional information at all.
    * **deadband** — the "do nothing" band, defaulting to ±0.5 × the
      cross-sectional standard deviation of the forward return, so roughly the
      middle third of names are labelled neutral. Defining it in units of the
      realised dispersion keeps the class balance stable across calm and volatile
      periods, which a fixed percentage would not.

    The trailing ``horizon`` rows per ticker have no realised future and are
    dropped.

    Returns
    -------
    pd.DataFrame
        Panel plus 'fwd_return', 'fwd_excess', 'label' (-1 short / 0 nothing /
        +1 buy) and 'label_idx' (0/1/2, for a softmax head).
    """
    df = panel.copy().sort_values(["ticker", "datetime"])
    g = df.groupby("ticker", sort=False)["adj_close"]
    df["fwd_return"] = np.log(g.shift(-horizon) / df["adj_close"])
    df = df[df["fwd_return"].notna()].copy()
    if df.empty:
        return df

    if market_neutral:
        mkt = df.groupby("datetime")["fwd_return"].transform("mean")
        df["fwd_excess"] = df["fwd_return"] - mkt
    else:
        df["fwd_excess"] = df["fwd_return"]

    if deadband is None:
        # Per-date dispersion, so the neutral band tracks the regime.
        sd = df.groupby("datetime")["fwd_excess"].transform("std")
        band = 0.5 * sd.fillna(sd.median())
    else:
        band = pd.Series(float(deadband), index=df.index)

    df["label"] = np.select(
        [df["fwd_excess"] > band, df["fwd_excess"] < -band],
        [1, -1], default=0).astype(int)
    df["label_idx"] = df["label"] + 1          # -1/0/1 -> 0/1/2
    return df.sort_values(["datetime", "ticker"]).reset_index(drop=True)


# ==========================================
# 4. Splits
# ==========================================
def split_panel(panel, mode="combined", val_asset_frac=0.30,
                val_time_frac=0.30, seed=0, embargo=5):
    """
    Split the panel by **asset**, by **time**, or — the honest default — both.

    * ``'asset'`` — the book's stratification: some names train, others validate.
      Answers "does this pattern exist in stocks the model has never seen?", which
      is hard to satisfy by memorisation.
    * ``'time'`` — the familiar walk-forward split. Answers "does it survive into
      the future?"
    * ``'combined'`` (default) — **unseen names AND unseen dates**. An asset split
      alone still lets the model see the same calendar period on both sides, so a
      market-wide regime present in both inflates the score; a time split alone
      lets it memorise ticker-specific quirks. Only the intersection rules out
      both, which is why it is the default despite discarding the most data.

    An **embargo** of ``horizon`` bars is dropped at the time boundary so no
    training label window (which spans ``horizon`` future bars) overlaps the
    validation period — the same purge ``temporal_train_val_split`` applies.

    Returns
    -------
    dict
        {'train', 'val' (DataFrames), 'train_tickers', 'val_tickers',
        'split_date', 'mode', 'n_train', 'n_val'}.
    """
    df = panel.copy()
    tickers = sorted(df["ticker"].unique())
    rng = np.random.default_rng(seed)

    val_tickers, train_tickers = [], tickers
    if mode in ("asset", "combined"):
        n_val = max(1, int(round(len(tickers) * val_asset_frac)))
        perm = rng.permutation(len(tickers))
        val_tickers = sorted(tickers[i] for i in perm[:n_val])
        train_tickers = sorted(tickers[i] for i in perm[n_val:])

    split_date = None
    if mode in ("time", "combined"):
        dates = np.sort(df["datetime"].unique())
        split_date = pd.Timestamp(dates[int(len(dates) * (1 - val_time_frac))])

    if mode == "asset":
        train = df[df["ticker"].isin(train_tickers)]
        val = df[df["ticker"].isin(val_tickers)]
    elif mode == "time":
        emb = pd.Timedelta(days=int(embargo) * 2)      # calendar-day cushion
        train = df[df["datetime"] < split_date - emb]
        val = df[df["datetime"] >= split_date]
    elif mode == "combined":
        emb = pd.Timedelta(days=int(embargo) * 2)
        train = df[df["ticker"].isin(train_tickers)
                   & (df["datetime"] < split_date - emb)]
        val = df[df["ticker"].isin(val_tickers)
                 & (df["datetime"] >= split_date)]
    else:
        raise ValueError("mode must be 'asset', 'time' or 'combined'")

    return {"train": train.reset_index(drop=True),
            "val": val.reset_index(drop=True),
            "train_tickers": train_tickers,
            "val_tickers": val_tickers,
            "split_date": (str(split_date.date()) if split_date is not None
                           else None),
            "mode": mode,
            "n_train": int(len(train)), "n_val": int(len(val))}


def feature_columns(panel):
    """
    Model input columns: engineered + cross-sectional, never raw or forward.

    Excludes raw OHLCV (not scale-free), the identifiers, and — critically —
    every forward-looking column (`fwd_return`, `fwd_excess`, `label`,
    `label_idx`, `target_*`). Getting that exclusion list wrong is the single
    fastest way to produce a spectacular and completely fake result, so it is
    centralised here and asserted in the tests rather than rebuilt per caller.
    """
    banned = {"ticker", "datetime", "open", "high", "low", "close",
              "adj_close", "volume", "fwd_return", "fwd_excess", "label",
              "label_idx", "mkt_index"}
    return [c for c in panel.columns
            if c not in banned
            and not c.startswith("target_")
            and pd.api.types.is_numeric_dtype(panel[c])]
