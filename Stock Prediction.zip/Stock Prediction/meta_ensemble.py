"""
Cross-family meta-ensemble.

The multi-ticker backtest showed there is **no universal winner**: the tree/ML
models (Quantile-LGBM, XGBoost) won AAPL and MSFT, while the statistical models
(ARIMA/ARIMAX) won GOOGL, and the worst models (N-BEATS, Prophet) blew up by
3-10x on some tickers. The existing "Stacking Ensemble" only combines tree base
learners on the same features, so it inherits the tree family's ticker-specific
weaknesses.

This meta-ensemble instead combines **different model families** — two tree
models plus a statistical model — and aggregates them with the **median** of
the per-horizon point forecasts. The median is deliberately chosen over a mean
or a learned weighting: it is robust to a single constituent producing a wild
forecast, which is exactly the failure mode (one family misfiring on a given
ticker) we want to neutralise. Confidence bands are formed by averaging the
constituents' own intervals (all three emit calibrated bounds).

The result is a single forecast that tracks whichever family suits the current
ticker/regime without needing to know which in advance.
"""

import numpy as np
import pandas as pd

from model_utils import normalize_interval

# Complementary, reliable constituents (tree x2 + statistical x1). Each emits
# 'predicted_price' plus calibrated 'lower_bound'/'upper_bound'.
_CONSTITUENTS = [
    ('Quantile-LGBM', 'Quantile_model', 'run_quantile_prediction', {}),
    ('XGBoost', 'ML_model', 'run_ML_prediction', {'model_type': 'xgboost'}),
    ('ARIMAX+GARCH', 'ARIMAX_model', 'run_arimax_prediction', {}),
]


def _load(module_name, fn_name):
    """Import a constituent's run_* function lazily (avoids import cycles)."""
    import importlib
    return getattr(importlib.import_module(module_name), fn_name)


def run_meta_ensemble_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Median-combine complementary model families into one robust forecast.

    Runs each constituent (two tree models + one statistical model), aligns
    their forecasts by horizon step, and combines them with the per-step median
    for the point forecast and the per-step mean of the constituents' bounds for
    the interval. If a constituent raises or returns nothing usable, it is
    skipped, so the ensemble degrades gracefully rather than failing.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with datetime + OHLCV columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        Columns ['datetime', 'predicted_price', 'lower_bound', 'upper_bound',
        'volatility']. Bound columns are present when at least one constituent
        supplied intervals.

    Raises
    ------
    RuntimeError
        If no constituent produced a usable forecast.
    """
    interval = normalize_interval(interval)
    print(f"--- Starting Meta-Ensemble Prediction ({interval}) ---")

    point_stack = []
    lower_stack = []
    upper_stack = []
    datetimes = None
    used = []

    for name, module_name, fn_name, kwargs in _CONSTITUENTS:
        try:
            fn = _load(module_name, fn_name)
            out = fn(df, interval, horizon, **kwargs)
        except Exception as exc:
            print(f"  meta-ensemble: '{name}' failed, skipping ({exc})")
            continue

        if (out is None or 'predicted_price' not in getattr(out, 'columns', [])
                or len(out) < horizon):
            print(f"  meta-ensemble: '{name}' gave no usable forecast, skipping")
            continue

        point_stack.append(out['predicted_price'].values[:horizon].astype(float))
        if datetimes is None:
            datetimes = out['datetime'].values[:horizon]
        if 'lower_bound' in out.columns and 'upper_bound' in out.columns:
            lower_stack.append(out['lower_bound'].values[:horizon].astype(float))
            upper_stack.append(out['upper_bound'].values[:horizon].astype(float))
        used.append(name)

    if not point_stack:
        raise RuntimeError("Meta-ensemble: no constituent produced a forecast.")

    print(f"Meta-ensemble combining {len(used)} models via median: {used}")

    median_price = np.median(np.vstack(point_stack), axis=0)
    result = {'datetime': datetimes, 'predicted_price': median_price}

    if lower_stack:
        lower = np.mean(np.vstack(lower_stack), axis=0)
        upper = np.mean(np.vstack(upper_stack), axis=0)
        # Guard ordering against any averaging artefact.
        lower = np.minimum(lower, median_price)
        upper = np.maximum(upper, median_price)
        result['lower_bound'] = lower
        result['upper_bound'] = upper
        result['volatility'] = (upper - lower) / (2 * 1.96)

    print("Meta-Ensemble Prediction Complete.")
    return pd.DataFrame(result)
