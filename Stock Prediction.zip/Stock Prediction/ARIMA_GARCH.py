import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pmdarima as pm
from arch import arch_model
from pandas.tseries.offsets import BusinessDay


# ==========================================
# 1. Preprocessing (Stationarity)
# ==========================================
def prepare_data_statistical(df):
    """
    ARIMA/GARCH work best on Returns, not raw prices.
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime').sort_index()
    
    # df['adj_close'] = pd.to_numeric(df['adj_close'], errors='coerce')

    # Calculate Log Returns (Percentage Change)
    # log(P_t / P_t-1)
    df['log_return'] = np.log(df['adj_close'] / df['adj_close'].shift(1))
    
    # Drop NaN created by shift
    df = df.dropna()
    
    return df

# ==========================================
# 2. Train Hybrid ARIMA-GARCH
# ==========================================
def train_arima_garch(df):
    print("--- Training Statistical Models ---")
    
    # 1. Fit Auto-ARIMA (Finds best p,d,q automatically)
    # We use 'log_return' because it's stationary. Raw price is not.
    print("Fitting Auto-ARIMA to find best parameters...")
    arima_model = pm.auto_arima(
        df['log_return'],
        start_p=1, start_q=1,
        max_p=5, max_q=5,
        seasonal=False, # Stock data usually isn't seasonal in the ARIMA sense
        stepwise=True,
        suppress_warnings=True,
        trace=False
    )
    print(f"Best ARIMA Order: {arima_model.order}")

    # 2. Extract Residuals (The errors ARIMA couldn't explain)
    # GARCH models these residuals to predict volatility
    arima_residuals = arima_model.resid()

    # 3. Fit GARCH(1,1) on residuals
    print("Fitting GARCH(1,1) to model volatility...")
    garch = arch_model(arima_residuals, vol='Garch', p=1, q=1, rescale=False)
    garch_model = garch.fit(disp='off')
    
    return arima_model, garch_model

# ==========================================
# 3. Prediction Logic
# ==========================================
def generate_forecasts(df, arima_model, garch_model, horizon, interval):
    """
    Generates future prices, bounds, and handles Weekend/Night skipping.
    """
    last_price = df['adj_close'].iloc[-1]
    last_date = df.index[-1]
    
    # --- A. Get Raw Forecasts ---
    # 1. ARIMA predicts the Mean Return
    arima_pred, conf_int = arima_model.predict(n_periods=horizon, return_conf_int=True)
    
    # 2. GARCH predicts the Volatility (Variance)
    garch_pred = garch_model.forecast(horizon=horizon)
    pred_volatility = np.sqrt(garch_pred.variance.values[-1, :])
    
    # --- B. Reconstruct Prices & Dates ---
    future_data = []
    current_date = last_date
    current_price = last_price
    
    # Logic for Date Increment
    if interval == 'daily':
        date_offset = BusinessDay(n=1)
    else:
        date_offset = pd.DateOffset(hours=1)

    print(f"Constructing {horizon} step forecast...")

    for i in range(horizon):
        # 1. Increment Date (Skipping Logic)
        current_date += date_offset
        
        # Hourly specific: Skip Weekends and Nights
        if interval == 'hourly':
            # Skip Weekend
            if current_date.dayofweek >= 5:
                days_add = 7 - current_date.dayofweek
                current_date += pd.DateOffset(days=days_add)
                current_date = current_date.replace(hour=9, minute=15)
            
            # Skip Night (e.g., after 4 PM)
            if current_date.hour >= 16 or current_date.hour < 9:
                current_date += pd.DateOffset(days=1)
                current_date = current_date.replace(hour=9, minute=15)
                # Re-check weekend
                if current_date.dayofweek >= 5:
                    days_add = 7 - current_date.dayofweek
                    current_date += pd.DateOffset(days=days_add)
                    current_date = current_date.replace(hour=9, minute=15)

        # 2. Get Predicted Values for this step
        # Handle different return types from pmdarima
        step_log_return = arima_pred.iloc[i] if hasattr(arima_pred, 'iloc') else arima_pred[i]
        step_volatility = pred_volatility[i]
        
        # 3. Calculate New Price
        # Price_t = Price_{t-1} * exp(Log_Return)
        next_price = current_price * np.exp(step_log_return)
        
        # 4. Calculate Confidence Intervals (95%)
        # This creates the "Cone of Uncertainty"
        # Lower = Price * (1 - 1.96 * Volatility)
        lower_bound = next_price * (1 - 1.96 * step_volatility)
        upper_bound = next_price * (1 + 1.96 * step_volatility)
        
        future_data.append({
            'datetime': current_date,
            'predicted_price': next_price,
            'lower_bound': lower_bound,
            'upper_bound': upper_bound,
            'volatility': step_volatility # Optional: useful to see risk
        })
        
        # Update for next iteration
        current_price = next_price

    return pd.DataFrame(future_data)

# ==========================================
# 4. Main Orchestrator (Call this from UI)
# ==========================================
def run_statistical_prediction(df: pd.DataFrame, interval: str, horizon: int):
    """
    Main function to run ARIMA+GARCH prediction.
    
    Args:
        df: DataFrame with 'datetime' and 'adj_close'
        interval: 'daily' or 'hourly'
        horizon: Number of steps to predict
        
    Returns:
        pd.DataFrame: Contains ['datetime', 'predicted_price', 'lower_bound', 'upper_bound']
    """
    print(f"--- Starting Statistical Prediction ({interval}) ---")
    
    clean_df = prepare_data_statistical(df)
    arima, garch = train_arima_garch(clean_df)    
    results_df = generate_forecasts(clean_df, arima, garch, horizon, interval)
    print("Prediction Complete.")
    return results_df

