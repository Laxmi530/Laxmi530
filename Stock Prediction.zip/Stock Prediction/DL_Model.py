import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler
from pandas.tseries.offsets import BusinessDay
import os

# Suppress TensorFlow logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# ==========================================
# 1. Helper: Data Processing (Scaling & Sequences)
# ==========================================
def prepare_dl_data(df: pd.DataFrame, look_back=60):
    """
    1. Scales data to (0, 1).
    2. Converts data into 3D sequences for LSTM/GRU [Samples, Time Steps, Features].
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime').sort_index()
    
    # LSTM only needs the Target column (Univariate approach)
    # Ensure numeric
    data = df.filter(['adj_close']).values
    data = data.astype('float32')

    # Scale the data
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(data)

    # Create Sequences
    # X: Past 60 days, y: Next day
    X, y = [], []
    for i in range(look_back, len(scaled_data)):
        X.append(scaled_data[i-look_back:i, 0])
        y.append(scaled_data[i, 0])

    X, y = np.array(X), np.array(y)

    # Reshape for LSTM: [Samples, Time Steps, Features]
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))
    
    return X, y, scaler, scaled_data

# ==========================================
# 2. Helper: Build & Train Model
# ==========================================
def train_dl_model(X, y, model_type='LSTM'):
    """
    Builds a Stacked LSTM or GRU model with Dropout.
    """
    model = Sequential()
    
    # Input shape: (Look_back, 1)
    input_shape = (X.shape[1], 1)

    print(f"Building Advanced {model_type} Model...")

    if model_type == 'LSTM':
        # Layer 1: Return Sequences = True (to stack another LSTM on top)
        model.add(LSTM(units=50, return_sequences=True, input_shape=input_shape))
        model.add(Dropout(0.2)) # Prevent overfitting
        # Layer 2: Return Sequences = False (Final layer before output)
        model.add(LSTM(units=50, return_sequences=False))
        model.add(Dropout(0.2))
    
    elif model_type == 'GRU':
        # Layer 1
        model.add(GRU(units=50, return_sequences=True, input_shape=input_shape))
        model.add(Dropout(0.2))
        # Layer 2
        model.add(GRU(units=50, return_sequences=False))
        model.add(Dropout(0.2))

    # Output Layer (Predicting 1 value: Price)
    model.add(Dense(units=1)) 

    # Compile
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train with Early Stopping
    # Stop if validation loss doesn't improve for 5 epochs
    early_stop = EarlyStopping(monitor='loss', patience=5, restore_best_weights=True)
    
    print("Training Model (this may take a moment)...")
    model.fit(X, y, batch_size=32, epochs=20, callbacks=[early_stop], verbose=0)
    
    return model

# ==========================================
# 3. Helper: Recursive Prediction Logic
# ==========================================
def predict_dl_recursive(model, scaler, full_scaled_data, horizon, interval, last_date, look_back=60):
    """
    Predicts future prices by feeding predictions back into the model.
    """
    future_predictions = []
    current_date = last_date
    
    # Logic for Date Increment
    if interval == 'daily':
        date_offset = BusinessDay(n=1)
    else:
        date_offset = pd.DateOffset(hours=1)

    # Get the last 'look_back' days of data to start the prediction chain
    # Shape: (1, look_back, 1)
    current_batch = full_scaled_data[-look_back:].reshape(1, look_back, 1)

    print(f"Generating {horizon} future steps recursively...")

    for i in range(horizon):
        # 1. Update Date (Trading Logic)
        current_date += date_offset
        if interval == 'hourly':
            if current_date.dayofweek >= 5: # Skip Weekend
                days_add = 7 - current_date.dayofweek
                current_date += pd.DateOffset(days=days_add)
                current_date = current_date.replace(hour=9, minute=15)
            if current_date.hour >= 16 or current_date.hour < 9: # Skip Night
                current_date += pd.DateOffset(days=1)
                current_date = current_date.replace(hour=9, minute=15)
                if current_date.dayofweek >= 5:
                    days_add = 7 - current_date.dayofweek
                    current_date += pd.DateOffset(days=days_add)
                    current_date = current_date.replace(hour=9, minute=15)

        # 2. Predict the NEXT scaled value
        # Returns [[0.543]]
        pred_scaled = model.predict(current_batch, verbose=0)
        
        # 3. Inverse Transform to get Real Price
        pred_price = scaler.inverse_transform(pred_scaled)[0][0]
        
        # 4. Store Result
        future_predictions.append({
            'datetime': current_date,
            'predicted_price': float(pred_price)
        })

        # 5. Update the Batch for the next loop
        # Remove the first (oldest) value and append the new prediction
        # New shape must still be (1, look_back, 1)
        new_step = pred_scaled.reshape(1, 1, 1)
        current_batch = np.append(current_batch[:, 1:, :], new_step, axis=1)

    return pd.DataFrame(future_predictions)

# ==========================================
# 4. Main Orchestrator
# ==========================================
def run_DL_prediction(df: pd.DataFrame, interval: str, horizon: int, model_type='LSTM'):
    """
    Main function to run LSTM or GRU prediction.
    
    Args:
        df: DataFrame with 'datetime' and 'adj_close'
        interval: 'daily' or 'hourly'
        horizon: Number of steps to predict
        model_type: 'LSTM' or 'GRU'
        
    Returns:
        pd.DataFrame: ['datetime', 'predicted_price']
    """
    print(f"--- Starting {model_type} Prediction ({interval}) ---")
    df = df.copy() # Work on a copy to avoid affecting original data
    df['datetime'] = pd.to_datetime(df['datetime'])
    # 1. Determine Lookback based on interval
    # Daily needs more context (e.g., 60 days). Hourly can use less (e.g., 24 hours).
    look_back = 60 if interval == 'daily' else 24
    X, y, scaler, scaled_data = prepare_dl_data(df, look_back)
    last_date = df['datetime'].iloc[-1]
    model = train_dl_model(X, y, model_type)    
    results_df = predict_dl_recursive(model, scaler, scaled_data, horizon, interval, last_date, look_back)
    print(f"{model_type} Prediction Complete.")
    return results_df