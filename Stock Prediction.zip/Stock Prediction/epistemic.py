"""
Epistemic (model) uncertainty by Monte-Carlo dropout.

The distinction this module adds
--------------------------------
Every interval this project ships is **aleatoric**: the conformal cone measures
how wrong the fitted model's predictions have *been*, and widens accordingly. It
takes the model as given. What it cannot express is the other half of the
question — *how much would this forecast change if the model had been fitted
slightly differently?* That is **epistemic** uncertainty, and it is the part
that is large precisely when data is scarce.

That matters here more than it would elsewhere. Sections 30 and 32 established
that this project's binding constraint is sample size, not architecture. A cone
that says nothing about parameter uncertainty is silent on exactly the axis the
evidence says is limiting.

Klaas, *Machine Learning for Finance*, Ch. 4 ("Bayesian deep learning"):

    "Most classic probabilistic modeling techniques, such as Kalman filters, can
     give confidence intervals for predictions, whereas regular deep learning
     cannot... A simpler hack that allows us to turn regular deep networks into
     Bayesian deep networks is to activate dropout during prediction time and
     then make multiple predictions."

Each stochastic pass samples a different sub-network, so the spread across
passes approximates the posterior predictive spread (Gal & Ghahramani, 2016).
It is cheap: no retraining, no extra parameters, and every deep model here
already carries dropout layers (DL 0.3/0.3/0.2, CNN-LSTM 0.2, Vol-LSTM 0.2).

What this is NOT
----------------
- **Not a replacement for the conformal cone.** The two measure different
  things and are reported separately. Folding an unvalidated epistemic term
  into a calibrated 95% band would break a coverage guarantee that was actually
  measured, to add one that was not.
- **Not calibrated.** MC-dropout spread is a *relative* signal — useful for
  ranking models and flagging "this network is unsure here" — not a probability
  statement. It ships off by default for that reason, consistent with this
  project's rule that an unvalidated feature does not ship on.
- **Not free of the deterministic-inference contract.** ``mc_dropout_predict``
  never mutates the model or global Keras state; it passes ``training=True`` per
  call, so an ordinary ``model.predict`` afterwards is unaffected.

A falsifiable prediction
------------------------
If this measures what it claims, epistemic uncertainty should be **largest for
the model with the least data per parameter**. Section 33's audit put N-BEATS at
a 1.7:1 sample-to-input ratio against the book's 10:1 rule of thumb, while the
recurrent models sit at 101:1. ``run_epistemic_eval.py`` checks that ordering;
if the ranking came out arbitrary, the number would be noise and should be
withdrawn.
"""

import numpy as np

_EPS = 1e-12


def has_dropout(model):
    """
    Whether a Keras model contains any active dropout layer.

    Without one, every stochastic pass is identical and the reported spread is
    exactly zero — which would look like supreme confidence rather than the
    absence of a measurement. Callers must check rather than silently report 0.
    """
    try:
        for layer in getattr(model, "layers", []):
            if "dropout" in type(layer).__name__.lower():
                rate = getattr(layer, "rate", 0.0) or 0.0
                if float(rate) > 0:
                    return True
    except Exception:
        pass
    return False


def mc_dropout_predict(model, x, n_passes=50, seed=None):
    """
    Run ``n_passes`` stochastic forward passes with dropout active.

    Uses the functional ``training=True`` argument rather than Keras'
    ``set_learning_phase`` (the mechanism the book used on TF 1.x). The global
    flag leaks: it stays set on the graph and silently makes every later
    ``predict`` stochastic, which would turn the app's point forecasts random
    without anything indicating why. Per-call is the only form that cannot
    contaminate the rest of the session.

    Returns
    -------
    numpy.ndarray or None
        ``(n_passes, n_samples, n_outputs)``; None if the model cannot be
        sampled (no dropout, or the call failed).
    """
    if model is None or not has_dropout(model):
        return None
    if seed is not None:
        try:
            import tensorflow as tf
            tf.random.set_seed(int(seed))
        except Exception:
            pass
    draws = []
    for _ in range(int(max(n_passes, 2))):
        try:
            out = model(x, training=True)
            draws.append(np.asarray(out, dtype=float))
        except Exception:
            return None
    if not draws:
        return None
    return np.stack(draws, axis=0)


def epistemic_spread(model, x, n_passes=50, seed=None, aleatoric_scale=None):
    """
    Summarise model uncertainty for a single forecast origin.

    Returns
    -------
    dict
        ``available`` — False when the model carries no dropout, so a caller can
        say "not measured" rather than "zero uncertainty";
        ``std_by_step`` — per-horizon standard deviation across passes;
        ``mean_std`` — the headline scalar;
        ``mean_by_step`` — per-horizon mean of the stochastic passes;
        ``epistemic_share`` — ``mean_std`` divided by ``aleatoric_scale``, the
        model's own conformal sigma. This is the cross-model comparison; see the
        note below on why it is not normalised by the prediction level;
        ``n_passes``.

    Note on normalisation
    ---------------------
    An earlier version divided by the mean absolute prediction. That is wrong
    here and the falsifiable check caught it: the target is a **cumulative log
    return**, centred near zero, so the denominator was an arbitrary near-zero
    number (the implied values spanned 0.0015 to 0.0147 across four models) and
    the ratio measured how close each forecast happened to land to zero rather
    than how uncertain it was.

    Dividing by the model's own conformal sigma is the meaningful comparison and
    was determinable in advance: both quantities are in log-return units, and
    the ratio answers a real question — *what share of this model's uncertainty
    is parameter uncertainty rather than residual noise?*
    """
    out = {"available": False, "n_passes": int(n_passes),
           "note": "model has no active dropout layer"}
    draws = mc_dropout_predict(model, x, n_passes=n_passes, seed=seed)
    if draws is None:
        return out

    # (passes, samples, outputs) -> collapse the sample axis; serve-time x is a
    # single origin, but keeping this general lets the evaluator batch.
    flat = draws.reshape(draws.shape[0], -1)
    std_by_step = flat.std(axis=0, ddof=1)
    mean_by_step = flat.mean(axis=0)
    mean_std = float(np.mean(std_by_step))
    share = float("nan")
    if aleatoric_scale is not None:
        a = float(aleatoric_scale)
        if np.isfinite(a) and a > _EPS:
            share = float(mean_std / a)
    return {
        "available": True,
        "n_passes": int(draws.shape[0]),
        "std_by_step": [float(v) for v in std_by_step],
        "mean_by_step": [float(v) for v in mean_by_step],
        "mean_std": mean_std,
        "aleatoric_scale": (float(aleatoric_scale)
                            if aleatoric_scale is not None else float("nan")),
        "epistemic_share": share,
        "note": "",
    }


def attach(prediction_df, model, x, n_passes=50, seed=None,
           aleatoric_scale=None):
    """
    Record a model's epistemic spread on its prediction frame.

    Uses ``DataFrame.attrs``, the convention already carrying
    ``risk_log_returns`` and ``architecture``. Best-effort and silent: an
    uncertainty annotation must never be able to fail a forecast.
    """
    try:
        prediction_df.attrs["epistemic"] = epistemic_spread(
            model, x, n_passes=n_passes, seed=seed,
            aleatoric_scale=aleatoric_scale)
    except Exception:
        pass
    return prediction_df


def format_report(name, spread):
    """One-line summary for the console / validation drivers."""
    if not spread or not spread.get("available"):
        note = (spread or {}).get("note", "not measured")
        return f"{name:16} epistemic: n/a ({note})"
    share = spread.get("epistemic_share", float("nan"))
    share_s = f"{share:.3f}" if np.isfinite(share) else "n/a"
    return (f"{name:16} epistemic sd {spread['mean_std']:.5f} | "
            f"share of conformal sigma {share_s} | "
            f"{spread['n_passes']} passes")
