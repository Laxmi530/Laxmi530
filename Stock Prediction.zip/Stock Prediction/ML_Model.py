import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from pandas.tseries.offsets import BusinessDay
from sklearn.metrics import mean_absolute_error

# ==========================================
# 1. Unified Feature Engineering (Shared)
# ==========================================
def create_features(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    """
    Creates features for BOTH XGBoost and LightGBM.
    """
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime').sort_index()

    # Numeric conversion
    # df['adj_close'] = pd.to_numeric(df['adj_close'], errors='coerce')
    # df['volume'] = pd.to_numeric(df['volume'], errors='coerce')
    df = df.dropna(subset=['adj_close'])

    # Target: Log Returns
    df['target_log_return'] = np.log(df['adj_close'] / df['adj_close'].shift(1)).shift(-1)

    # Lags
    for col in ['open', 'high', 'low', 'adj_close', 'volume']:
        for i in range(1, 6): 
            df[f'{col}_lag_{i}'] = df[col].shift(i)

    # Rolling Windows
    if interval == 'daily':
        rolling_windows = [5, 10, 20]
    else:
        rolling_windows = [6, 12, 24]

    for w in rolling_windows:
        df[f'adj_close_MA_{w}'] = df['adj_close'].rolling(w).mean()
        df[f'adj_close_STD_{w}'] = df['adj_close'].rolling(w).std()
        df[f'volume_MA_{w}'] = df['volume'].rolling(w).mean()

    # Time Features
    df['year'] = df.index.year
    df['month'] = df.index.month
    df['day'] = df.index.day
    df['dayofweek'] = df.index.dayofweek
    if interval == 'hourly':
        df['hour'] = df.index.hour

    return df.dropna()

# ==========================================
# 2. Generic Model Factory
# ==========================================
def get_model_and_params(model_type: str):
    """
    Returns the specific model instance and its specific fit parameters.
    """
    if model_type == 'xgboost':
        model = xgb.XGBRegressor(
            objective='reg:squarederror',
            n_estimators=1000,
            learning_rate=0.05,
            max_depth=6,
            n_jobs=-1,
            random_state=42,
            early_stopping_rounds=50
        )
        # XGBoost specific fit params
        fit_params = {'verbose': False} 
        # Note: early_stopping_rounds is passed directly to fit() in newer sklearn wrappers, 
        # but we handle it in the train loop below for clarity.
        return model, 'xgboost'

    elif model_type == 'lightgbm':
        model = lgb.LGBMRegressor(
            objective='regression',
            n_estimators=1000,
            learning_rate=0.05,
            num_leaves=31,
            n_jobs=-1,
            random_state=42,
            verbose=-1
        )
        # LightGBM specific callbacks
        callbacks = [
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0)
        ]
        fit_params = {'callbacks': callbacks}
        return model, 'lightgbm'
    
    else:
        raise ValueError("model_type must be 'xgboost' or 'lightgbm'")

# ==========================================
# 3. Unified Training Function
# ==========================================
def train_generic_model(features_df: pd.DataFrame, target_col: str, model_type: str, test_size=0.2):
    X = features_df.drop(columns=[target_col])
    y = features_df[target_col]

    # Time-based split
    split_idx = int(len(X) * (1 - test_size))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

    print(f"Training {model_type.upper()}... (Train: {len(X_train)}, Test: {len(X_test)})")

    # Get Model
    model, engine = get_model_and_params(model_type)

    # Fit Model (Handling slight API differences)
    if engine == 'xgboost':
        model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)
    
    # lightgbm # LightGBM uses callbacks in the fit_params
    else: 
        callbacks = [lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(0)]
        model.fit(X_train, y_train, eval_set=[(X_test, y_test)], eval_metric='rmse', callbacks=callbacks)

    # Evaluate
    mae = mean_absolute_error(y_test, model.predict(X_test))
    print(f"{model_type.upper()} Test MAE: {mae:.5f}")

    # Return model and last known data state
    last_data = features_df.iloc[-1].drop(target_col)
    last_price = features_df['adj_close'].iloc[-1]
    
    return model, last_data, last_price

# ==========================================
# 4. Unified Prediction Logic (With Trading Hours)
# ==========================================
def predict_future_logic(model, last_data, last_price, horizon, interval, original_df, feature_cols):
    """
    Handles the complex logic of skipping weekends/hours and updating features.
    """
    future_preds = []
    curr_data = last_data.copy()
    curr_price = last_price
    curr_time = last_data.name

    # Logic Setup
    if interval == 'daily':
        date_offset = BusinessDay(n=1)
        rolling_windows = [5, 10, 20]
    else:
        date_offset = pd.DateOffset(hours=1)
        rolling_windows = [6, 12, 24]

    # Pre-fetch recent data for rolling calcs
    max_win = max(rolling_windows)
    recent_data = original_df.tail(max_win).copy()
    recent_data['adj_close'] = pd.to_numeric(recent_data['adj_close'], errors='coerce')
    recent_data['volume'] = pd.to_numeric(recent_data['volume'], errors='coerce')
    recent_data = recent_data.set_index('datetime').sort_index()

    print(f"Generating {horizon} future steps...")

    steps = 0
    while steps < horizon:
        curr_time += date_offset

        # --- Hourly Trading Hours Logic ---
        if interval == 'hourly':
            # Skip Weekends
            if curr_time.dayofweek >= 5:
                days_add = 7 - curr_time.dayofweek
                curr_time += pd.DateOffset(days=days_add)
                curr_time = curr_time.replace(hour=9, minute=15)
            
            # Skip Nights (Example: 4 PM to 9 AM)
            if curr_time.hour >= 16 or curr_time.hour < 9:
                curr_time += pd.DateOffset(days=1)
                curr_time = curr_time.replace(hour=9, minute=15)
                # Re-check weekend after skipping night
                if curr_time.dayofweek >= 5:
                    days_add = 7 - curr_time.dayofweek
                    curr_time += pd.DateOffset(days=days_add)
                    curr_time = curr_time.replace(hour=9, minute=15)

        # --- Feature Updates ---
        temp = pd.DataFrame(index=[curr_time])
        
        # Lags
        temp['adj_close_lag_1'] = curr_price
        for j in range(2, 6):
            temp[f'adj_close_lag_{j}'] = curr_data.get(f'adj_close_lag_{j-1}', 0)
        for col in ['volume', 'open', 'high', 'low']:
            for j in range(1, 6):
                temp[f'{col}_lag_{j}'] = curr_data.get(f'{col}_lag_{j}', 0)

        # Rolling
        new_row = pd.DataFrame({'adj_close': [curr_price], 'volume': [curr_data.get('volume_lag_1', 0)]}, index=[curr_time])
        recent_data = pd.concat([recent_data, new_row])
        
        for w in rolling_windows:
            temp[f'adj_close_MA_{w}'] = recent_data['adj_close'].rolling(w).mean().iloc[-1]
            temp[f'adj_close_STD_{w}'] = recent_data['adj_close'].rolling(w).std().iloc[-1]
            temp[f'volume_MA_{w}'] = recent_data['volume'].rolling(w).mean().iloc[-1]

        # Time
        temp['year'] = curr_time.year
        temp['month'] = curr_time.month
        temp['day'] = curr_time.day
        temp['dayofweek'] = curr_time.dayofweek
        if interval == 'hourly':
            temp['hour'] = curr_time.hour

        # Predict
        X_pred = temp.reindex(columns=feature_cols, fill_value=0)
        pred_log = model.predict(X_pred)[0]
        pred_price = curr_price * np.exp(pred_log)

        future_preds.append({'datetime': curr_time, 'predicted_price': pred_price})
        
        # Reset for next loop
        curr_price = pred_price
        curr_data = X_pred.iloc[0]
        curr_data.name = curr_time
        steps += 1

    return pd.DataFrame(future_preds)

# ==========================================
# 5. Main Orchestrator (The only function you call)
# ==========================================
def run_ML_prediction(df: pd.DataFrame, interval: str, horizon: int, model_type: str = 'xgboost'):
    """
    Main function to run the whole pipeline.
    model_type: 'xgboost' or 'lightgbm'
    """
    print(f"Data set size during initial stage {df.shape}")
    # 1. Features
    features_df = create_features(df, interval)
    print(f"Feature data set shape {features_df.shape}")
    target_col = 'target_log_return'
    feature_cols = [c for c in features_df.columns if c != target_col]
    # 2. Train
    model, last_data, last_price = train_generic_model(features_df, target_col, model_type)
    # 3. Predict
    preds = predict_future_logic(model, last_data, last_price, horizon, interval, df, feature_cols)
    return preds