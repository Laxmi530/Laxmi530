import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model, Input
import os
import warnings

from model_utils import (
    normalize_interval,
    reset_keras_seeds,
    temporal_train_val_split,
    default_keras_callbacks,
    forecast_nn_direct,
)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)


# ==========================================
# 1. N-BEATS Block (Generic)
# ==========================================
class NBeatsBlock(layers.Layer):
    """
    Generic N-BEATS block with learned basis expansion.

    Applies a stack of fully connected layers to produce two outputs:
    a backcast (reconstruction of input) and a forecast (partial
    prediction). The doubly residual topology subtracts the backcast
    from the block's input, allowing subsequent blocks to model the
    residual signal.

    Parameters
    ----------
    units : int
        Width of each fully connected hidden layer.
    backcast_dim : int
        Dimensionality of the backcast output (flattened input length).
    forecast_dim : int
        Dimensionality of the forecast output (1 for single-step).
    n_layers : int, optional
        Number of FC hidden layers. Default 4.
    """

    def __init__(self, units, backcast_dim, forecast_dim, n_layers=4,
                 **kwargs):
        """
        Initialise block with FC layers, backcast, and forecast heads.

        Parameters
        ----------
        units : int
            Hidden layer width.
        backcast_dim : int
            Output dimension for backcast branch.
        forecast_dim : int
            Output dimension for forecast branch.
        n_layers : int, optional
            Number of hidden layers. Default 4.
        **kwargs
            Forwarded to ``layers.Layer``.
        """
        super().__init__(**kwargs)
        self.hidden = [
            layers.Dense(units, activation='relu') for _ in range(n_layers)
        ]
        self.theta_b = layers.Dense(backcast_dim, activation='linear')
        self.theta_f = layers.Dense(forecast_dim, activation='linear')

    def call(self, x):
        """
        Forward pass through hidden layers then backcast/forecast split.

        Parameters
        ----------
        x : tf.Tensor
            Input tensor of shape (batch, backcast_dim).

        Returns
        -------
        tuple of tf.Tensor
            backcast : (batch, backcast_dim) — input reconstruction.
            forecast : (batch, forecast_dim) — partial prediction.
        """
        h = x
        for layer in self.hidden:
            h = layer(h)
        return self.theta_b(h), self.theta_f(h)


# ==========================================
# 2. Full N-BEATS Model
# ==========================================
def build_nbeats_model(input_dim, n_stacks=2, n_blocks=2, units=64,
                       dropout=0.2, forecast_dim=1):
    """
    Build a Generic N-BEATS model for single-step regression.

    Architecture: flattened multivariate input -> N stacks of M generic
    blocks each -> sum of all block forecasts. Each block receives the
    residual from previous blocks (input minus accumulated backcasts).
    Dropout is applied between stacks for regularisation.

    Capacity is deliberately small (64 units x 2 blocks x 2 stacks,
    dropout 0.2). The original 256-unit / 3-block configuration badly
    overfit the ~700-row training windows and produced wildly inaccurate,
    direction-flipping forecasts in the walk-forward backtest; shrinking
    the network is the first-line remedy for that overfitting.

    Parameters
    ----------
    input_dim : int
        Flattened input dimensionality (look_back * n_features).
    n_stacks : int, optional
        Number of stacks. Default 2.
    n_blocks : int, optional
        Number of blocks per stack. Default 2.
    units : int, optional
        FC hidden layer width in each block. Default 64.
    dropout : float, optional
        Dropout rate between stacks. Default 0.2.

    Returns
    -------
    tf.keras.Model
        Compiled N-BEATS model.
    """
    inputs = Input(shape=(input_dim,))
    residuals = inputs
    forecast = layers.Lambda(
        lambda t: tf.zeros((tf.shape(t)[0], forecast_dim)),
        output_shape=(forecast_dim,),
    )(inputs)

    for s in range(n_stacks):
        for b in range(n_blocks):
            backcast, block_fcast = NBeatsBlock(
                units, input_dim, forecast_dim,
                name=f'nbeats_s{s}_b{b}',
            )(residuals)
            residuals = layers.Subtract()([residuals, backcast])
            forecast = layers.Add()([forecast, block_fcast])
        if s < n_stacks - 1:
            residuals = layers.Dropout(dropout)(residuals)

    model = Model(inputs, forecast)
    model.compile(
        loss='huber',
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3, clipnorm=1.0),
    )
    return model


# ==========================================
# 3. Training Wrapper
# ==========================================
def train_nbeats(X, y, look_back, n_features, output_dim=1):
    """
    Build and train the N-BEATS model with temporal validation.

    Clears the TF session, sets random seeds, splits data temporally
    (last 10 % for validation), and trains with early stopping and
    learning-rate scheduling.

    Parameters
    ----------
    X : np.ndarray
        Flattened input of shape (n_samples, look_back * n_features).
    y : np.ndarray
        Targets of shape (n_samples,) or (n_samples, output_dim) — the
        per-horizon cumulative log returns for direct multi-horizon output.
    look_back : int
        Sequence length before flattening.
    n_features : int
        Number of per-step features.
    output_dim : int, optional
        Number of forecast outputs (= horizon for direct multi-horizon).
        Default 1.

    Returns
    -------
    tf.keras.Model
        Trained N-BEATS model.
    """
    reset_keras_seeds()

    input_dim = look_back * n_features

    X_train, X_val, y_train, y_val = temporal_train_val_split(X, y)

    print(f"Building N-BEATS model (input_dim={input_dim})...")
    model = build_nbeats_model(input_dim, forecast_dim=output_dim)

    print("Training N-BEATS...")
    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=100,
        batch_size=32,
        callbacks=default_keras_callbacks(),
        shuffle=True,
        verbose=0,
    )
    return model


# ==========================================
# 4. Main Orchestrator
# ==========================================
def run_nbeats_prediction(df, interval, horizon):
    """
    Main function to run N-BEATS prediction.

    Orchestrates data preparation (feature engineering, flattened
    sequences), model building (generic N-BEATS with doubly residual
    topology and `horizon` forecast outputs), training with temporal
    validation, and direct multi-horizon forecasting (no recursive
    feedback) with distribution-free conformal prediction intervals.
    Training data is limited to recent observations.

    Parameters
    ----------
    df : pd.DataFrame
        Raw stock DataFrame with 'datetime' and 'adj_close' columns.
    interval : str
        '1d' / 'daily' / '1 Day' or '1h' / 'hourly' / '1 Hour'.
    horizon : int
        Number of future steps to predict.

    Returns
    -------
    pd.DataFrame
        Columns: ['datetime', 'predicted_price', 'lower_bound',
        'upper_bound', 'volatility'].
    """
    interval = normalize_interval(interval)
    print(f"--- Starting N-BEATS Prediction ({interval}) ---")

    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])

    max_obs = 1000 if interval == 'daily' else 750
    if len(df) > max_obs:
        df = df.tail(max_obs).reset_index(drop=True)

    look_back = 60 if interval == 'daily' else 30

    results_df = forecast_nn_direct(
        df, interval, horizon, look_back,
        build_train_fn=lambda X, Y, od: train_nbeats(
            X, Y, look_back, X.shape[1] // look_back, output_dim=od),
        flatten=True, desc="N-BEATS forecasts",
        model_name='N-BEATS',
    )

    print("N-BEATS Prediction Complete.")
    return results_df
