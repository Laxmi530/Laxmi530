def main():
    """
    Main function to orchestrate the notice grouping process.
    """
    # ... (Your credential validation and client initialization code remains the same) ...
    # Validate credentials
    if not all([AZURE_DI_ENDPOINT, AZURE_DI_KEY]):
        print("Error: Azure credentials not found. Please set AZURE_DI_ENDPOINT and AZURE_DI_KEY in your .env file.")
        return

    # Initialize the Document Analysis Client
    document_analysis_client = DocumentAnalysisClient(
        endpoint=AZURE_DI_ENDPOINT, credential=AzureKeyCredential(AZURE_DI_KEY)
    )

    print("--- Starting Notice Grouping Project ---")

    for authority_name in os.listdir(DATA_DIRECTORY):
        authority_path = os.path.join(DATA_DIRECTORY, authority_name)
        
        if not os.path.isdir(authority_path):
            continue

        print(f"\nProcessing Authority: {authority_name}")
        
        image_groups = {}
        unprocessed_images = []
        
        # State variables for the current notice
        current_notice_identifier = None # Will store the tuple (key, value) being tracked
        current_group_name = None      # Will store 'notice_1', 'notice_2', etc.
        notice_counter = 0

        image_files = [f for f in os.listdir(authority_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        image_files.sort()
        
        if not image_files:
            print("  No images found to process.")
            continue

        for image_name in image_files:
            image_path = os.path.join(authority_path, image_name)
            
            analysis_result = analyze_document(image_path, document_analysis_client)

            if is_page_blank(analysis_result):
                print(f"      - Detected blank page: {image_name}. Adding to unprocessed list.")
                unprocessed_images.append(image_path)
                continue

            # This now returns a LIST of all found identifiers, e.g., [('invoice', '456'), ('zipcash', '123')]
            all_ids_on_page = find_all_identifiers_on_page(analysis_result, UNIQUE_IDENTIFIER_KEYS)

            # --- THE NEW, CORRECT LOGIC ---
            is_new_notice = False
            if current_notice_identifier and current_notice_identifier in all_ids_on_page:
                # The ID we are tracking is on this page. This is NOT a new notice.
                print(f"      - Continuing with '{current_group_name}' because tracked ID {current_notice_identifier} was found.")
                is_new_notice = False
            elif all_ids_on_page:
                # The tracked ID is NOT on this page, but OTHER IDs ARE. This IS a new notice.
                is_new_notice = True
            
            if is_new_notice:
                # Find the highest-priority ID from the list found on the page
                highest_priority_id = None
                for key in UNIQUE_IDENTIFIER_KEYS:
                    for found_id in all_ids_on_page:
                        if found_id[0] == key:
                            highest_priority_id = found_id
                            break
                    if highest_priority_id:
                        break
                
                # Start the new notice
                current_notice_identifier = highest_priority_id
                notice_counter += 1
                current_group_name = f"notice_{notice_counter}"
                key, value = current_notice_identifier
                print(f"      - New notice detected. Assigning to folder: '{current_group_name}' (Now tracking by: ('{key}', '{value}'))")

            # Group the image if a notice group is active
            if current_group_name:
                if current_group_name not in image_groups:
                    image_groups[current_group_name] = []
                image_groups[current_group_name].append(image_path)
            else:
                unprocessed_images.append(image_path)

        # ... (The rest of the function: organize_files and printing unprocessed images remains the same) ...
        if image_groups:
            organize_files(authority_path, image_groups)
        
        if unprocessed_images:
            print("\n  The following images could not be grouped (or were blank):")
            for img_path in unprocessed_images:
                print(f"    - {os.path.basename(img_path)}")

    print("\n--- Notice Grouping Project Finished ---")