


def find_all_identifiers_on_page(result, identifier_keys):
    """
    Searches the DI result for all unique identifiers with a strict priority:
    Key-Value Pairs are checked first. If any are found, the function returns
    immediately and does not check Tables.

    Args:
        result: The result object from Azure DI analysis.
        identifier_keys (list): A list of keys to search for.

    Returns:
        A list of tuples [(key, value), ...] from EITHER KVP or Tables,
        or an empty list if none are found.
    """
    if not result:
        return []

    # 1. Search ONLY in Key-Value Pairs first.
    kvp_identifiers = set()
    for kv_pair in result.key_value_pairs:
        key_content = kv_pair.key.content.lower().strip()
        for key_to_find in identifier_keys:
            if key_to_find in key_content and kv_pair.value:
                value_content = clean_for_filename(kv_pair.value.content)
                kvp_identifiers.add((key_to_find, value_content))

    # --- THIS IS THE CRUCIAL NEW LOGIC ---
    # If we found any identifiers in KVP, we are done. Return them immediately.
    if kvp_identifiers:
        print(f"      - Found identifiers in Key-Value Pairs: {list(kvp_identifiers)}. Prioritizing these and ignoring tables.")
        return list(kvp_identifiers)

    # 2. If and ONLY IF KVP search was empty, proceed to check Tables.
    print("      - No identifiers found in Key-Value Pairs. Checking Tables...")
    table_identifiers = set()
    for table in result.tables:
        for cell in table.cells:
            cell_content = cell.content.lower().strip()
            for key_to_find in identifier_keys:
                if key_to_find in cell_content:
                    # Find the cell in the same row, next column
                    for other_cell in table.cells:
                        if other_cell.row_index == cell.row_index and other_cell.column_index > cell.column_index:
                            value_content = clean_for_filename(other_cell.content)
                            table_identifiers.add((key_to_find, value_content))
                            break # Assume first value to the right is the one
    
    if table_identifiers:
        print(f"      - Found identifiers in Tables: {list(table_identifiers)}.")
    
    return list(table_identifiers)