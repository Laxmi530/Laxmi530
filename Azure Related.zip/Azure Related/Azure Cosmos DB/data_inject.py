import os
import uuid
import shutil
import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from file_extraction import raw_text_from_file
from db_operations import upload_documents, remove_documents, delete_index, create_index, search_index
from config import load_config_data

UPLOAD_DIR = load_config_data["FILE_PROCESSING_PATH"]
ALLOWED_EXTENSIONS = {"pdf", "docx", "xlsx", "csv", "pptx"}

class Doc_remover(BaseModel):
    file_name:str = None
    index_name:str = None

class Index_name(BaseModel):
    index_name:str = None

class Doc_search(BaseModel):
    query:str = None
    index_name:str = None

app = FastAPI(title="Insurence presale bot")

@app.post("/document_upload", summary="Uploading document to the db index")
async def document_upload(file:UploadFile = File(...)):
    try:
        file_extension = file.filename.split(".")[-1].lower()
        if file_extension not in ALLOWED_EXTENSIONS:
            raise HTTPException(status_code=400, detail="Unsupported file format. Only PDF and DOCX allowed.")
        
        unique_filename = f"{uuid.uuid4()}_{file.filename.rsplit('.', 1)[0]}.{file_extension}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)

        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        text_from_file = await raw_text_from_file(file_path)
        upload_status = upload_documents()
        return JSONResponse(content = {"Document upload status":upload_status})
    except Exception as ed:
        return str(f"Error occured: {ed}")
    finally:
        os.remove(file_path)

@app.post("/document_remove", summary="Removing document from the db index")
async def document_remove(data:Doc_remover):
    try:
        file_name = data.file_name
        index = data.index_name
        status = remove_documents(file_name, index)
        return JSONResponse(content={"Document upload status":status})
    except Exception as tr:
        return f"Error occured: {tr}"

@app.post("/delete_index", summary="Deleting index from the db")
async def del_index(data:Index_name):
    index = data.index_name
    try:
        status = delete_index(index)
        return JSONResponse(content={"Index removal status": status})
    except Exception as ew:
        return f"Error occured: {ew}"

@app.post("/index_creation", summary="Creating index in the db")
async def index_creation(data:Index_name):
    index = data.index_name
    try:
        status = create_index(index)
        return JSONResponse(content={"Index creation status": status})
    except Exception as et:
        return f"Error occured: {et}"

@app.post("/doc_as_per_query", summary="Get list of documents as per the query")
async def doc_search(data:Doc_search):
    query = data.query
    index = data.index_name
    try:
        list_doc = search_index(query, index)
        return JSONResponse(content={"Documents":list_doc})
    except Exception as er:
        return f"Error occured: {er}"
    
if __name__ == "__main__":
    uvicorn.run(app, port=8888, host="110.12.11.1")