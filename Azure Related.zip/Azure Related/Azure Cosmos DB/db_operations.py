from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, 
    SearchField,  
    SearchFieldDataType, 
    SimpleField, 
    SearchableField,
    ComplexField,
    SearchIndex,  
    SemanticConfiguration,
    SemanticPrioritizedFields,
    SemanticField,  
    SemanticSearch,
    VectorSearch,
    HnswParameters,
    VectorSearchAlgorithmConfiguration
)
from openai import OpenAI
from azure.core.credentials import AzureKeyCredential
import uuid
import time
from typing import List
from langchain_community.document_loaders import PDFPlumberLoader, Docx2txtLoader, UnstructuredWordDocumentLoader, UnstructuredPowerPointLoader

from config import load_config_data

# service_name = load_config_data["SERVICE_NAME"]
# search_service_name = load_config_data["SEARCH_SERVICE_NAME"]
end_point = load_config_data["AZURE_COSMOS_DB_URL"]
api_key = load_config_data["AZURE_COSMOS_DB_PRIMARY_KEY"]


embedding_base_url = load_config_data["MISTRAL_BASE_URL"]
embedding_api_key = load_config_data["MISTRAL_API_KEY"]
embedding_model = load_config_data["MISTRAL_EMBEDDING"]

client = OpenAI(api_key=embedding_api_key, base_url=embedding_base_url)

# endpoint = "https://{}.search.windows.net/".format(service_name)
credential = AzureKeyCredential(api_key)
# _search_index_client = SearchIndexClient(endpoint=f"https://{search_service_name}.search.windows.net/", credential= credential)
_search_index_client = SearchIndexClient(endpoint=end_point, credential= credential)


def generate_embedding(text: str) -> List[float]:
    """
    Returns the embedding vector for the given text.
    
    Parameters:
        text (str): The input text to embed.
            
    Returns:
        list[float]: The embedding vector.
    """
    response = client.embeddings.create(model=embedding_model, input=[text])
    
    return response.data[0].embedding

def create_index(knowledge_index_name:str) ->str:
    """Creates an index if it does not exist in Azure AI Search.
    
    Args:
        index_name (str): The name of the index to create.
    """
    knowledge_index_name = str(knowledge_index_name).replace("_","-")
    #checking index exits:
    status = "failed"
    search_index = None
    if knowledge_index_name not in _search_index_client.list_index_names():
        try:
            index = SearchIndex(
                name = knowledge_index_name,
                fields = [
                    SimpleField(name="id", type=SearchFieldDataType.String, key=True),
                    SearchableField(name="knowledge_id", type=SearchFieldDataType.String, analyzer_name="en.lucene"),
                    SearchableField(name="content", type=SearchFieldDataType.String, analyzer_name="en.lucene"),
                    SearchField(name="text", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),hidden=False, searchable = True, vector_search_dimensions=1536, vector_search_configuration="default"),
                    ComplexField(name="metadata", fields=[
                        SearchableField(name="source", type=SearchFieldDataType.String,filterable=True),
                        SearchableField(name="file_path", type=SearchFieldDataType.String, facetable=True, filterable=True),
                        SearchableField(name="page", type=SearchFieldDataType.String, facetable=True, filterable=True, sortable=True)

                ])],
                semantic_settings=SemanticSearch(
                    configurations=[SemanticConfiguration(
                        name='default',
                        prioritized_fields=SemanticPrioritizedFields(
                            title_field=None, prioritized_content_fields=[SemanticField(field_name='content')]))]),
                vector_search=VectorSearch(
                    algorithm_configurations=[
                        VectorSearchAlgorithmConfiguration(
                            name="default",
                            kind="hnsw",
                            hnsw_parameters=HnswParameters(metric="cosine")
                        )
                    ]
                )
            )
            print(f"Creating {knowledge_index_name} search index")
            search_index = _search_index_client.create_index(index)
            print("complete")
            status= "success"            
        except Exception as ae:
            print(f"exception in creating index {knowledge_index_name} : {ae}")
    else:        
        print(f"Search index knowledge_index_name already exists")
        status= "success" 
    return status

def delete_index(knowledge_index_name:str) -> str:
    """Deletes an index by name if it exists.
    
    Args:
        index_name (str): The name of the index to delete.
    """
    knowledge_index_name = str(knowledge_index_name).replace("_","-")
    status = "failed"
    try:
        #check if index exist 
        if knowledge_index_name in _search_index_client.list_index_names():
            _search_index_client.delete_index(knowledge_index_name)
            status = "success"
        else:
            print(f"Search index not found ")
    except Exception as ae:
        print(f"Search index deletion failed {ae}")
    return status

def upload_documents(knowledge_index_name:str, knowledge_dir, knowledge_files, chatbot_config):
    """Uploads a document to an index.
    
    Args:
        index_name (str): The name of the index.
        doc_id (str): The ID of the document.
        content (str): The content of the document.
    """
    knowledge_index_name = str(knowledge_index_name).replace("_","-")
    status = "failed"
    if knowledge_index_name not in _search_index_client.list_index_names():
       result = create_index(knowledge_index_name)

    try:
        config = chatbot_config
        all_pages = []
        data_to_upload = []
        
        if len(knowledge_files['pdf']) > 0:
            if config['pdfloader'] == "pymupdf":
                for f in knowledge_files['pdf']:
                    loader = PDFPlumberLoader(str(knowledge_dir/f))
                    data = loader.load_and_split()            
                    for item in data:
                        print(item)
                        data_to_upload.append(
                                                {
                                                "id":str(uuid.uuid4()),
                                                "knowledge_id": knowledge_index_name,
                                                "content":item.page_content,
                                                "text": generate_embedding(item.page_content),
                                                "metadata" : {
                                                    "source": str(f),
                                                    "file_path": str(knowledge_dir/f),
                                                    "page" : str(item.metadata['page'])
                                                }
                                                }
                                            )
                        item.metadata = {
                            'source':f,
                            'file_path': item.metadata['file_path'],
                            'page':item.metadata['page']}
                    all_pages.extend(data)  
                    if len(data)==0:
                        data = tesseract_main_call(str(knowledge_dir/f)) 
                        for item in data:
                            data_to_upload.append(
                                                    {
                                                    "id":str(uuid.uuid4()),
                                                    "knowledge_id": knowledge_index_name,
                                                    "content":item.page_content,
                                                    "text": generate_embedding(item.page_content),
                                                    "metadata" : {
                                                        "source": str(f),
                                                        "file_path": str(knowledge_dir+f),
                                                        "page" : str(item.metadata['page'])
                                                    }
                                                    }
                                                )                    
                        all_pages.extend(data)                         
                status="success"
                print("passeed here pdfloader")
            elif config['pdfloader'] == "azure":
                    for f in knowledge_files['pdf']:
                        data = main_call(str(knowledge_dir/f))    
                        for item in data:
                            data_to_upload.append(
                                                    {
                                                    "id":str(uuid.uuid4()),
                                                    "knowledge_id": knowledge_index_name,
                                                    "content":item.page_content,
                                                    "text": generate_embedding(item.page_content),
                                                    "metadata" : {
                                                        "source": str(f),
                                                        "file_path": str(knowledge_dir/f),
                                                        "page" : str(item.metadata['page'])
                                                    }
                                                    }
                                                )                 
                        all_pages.extend(data)

                    status="success"

        if len(knowledge_files['docx']) > 0:
            if config['docx'] == "Docx2txtLoader":
                for f in knowledge_files['docx']:
                    loader = Docx2txtLoader(str(knowledge_dir/f))
                    data = loader.load_and_split()              
                    for item in data:
                        data_to_upload.append(
                                                    {
                                                    "id":str(uuid.uuid4()),
                                                    "knowledge_id": knowledge_index_name,
                                                    "content":item.page_content,
                                                    "text": generate_embedding(item.page_content),
                                                    "metadata" : {
                                                        "source": str(f),
                                                        "file_path": str(knowledge_dir/f),
                                                        "page" : str(item.metadata['page'])
                                                    }
                                                    }
                                                )
                        item.metadata = {
                            'source':f,
                            'file_path': None,
                            'page': None}
                    all_pages.extend(data)  
                status="success"
            elif config['docx'] == "Unstructured":
                for f in knowledge_files['docx']:
                    loader = UnstructuredWordDocumentLoader(str(knowledge_dir/f))
                    data = loader.load_and_split()              
                    for item in data:
                        data_to_upload.append(
                            {
                                "id":str(uuid.uuid4()),
                                "knowledge_id": knowledge_index_name,
                                "content":item.page_content,
                                "text": generate_embedding(item.page_content),
                                "metadata" : {"source": str(f), "file_path": str(knowledge_dir+f), "page" : str(item.metadata['page'])}
                            }
                                                )
                        item.metadata = {'source':f, 'file_path': None, 'page':None}
                    all_pages.extend(data) 
                status="success"

        if len(knowledge_files['pptx']) > 0:
            if config['pptx'] == "Unstructured":
                for f in knowledge_files['pptx']:
                    loader = UnstructuredPowerPointLoader(str(knowledge_dir/f))
                    data = loader.load_and_split()              
                    for item in data:
                        data_to_upload.append(
                                                    {
                                                    "id":str(uuid.uuid4()),
                                                    "knowledge_id": knowledge_index_name,
                                                    "content":item.page_content,
                                                    "text": generate_embedding(item.page_content),
                                                    "metadata" : {
                                                        "source": str(f),
                                                        "file_path": str(knowledge_dir/f),
                                                        "page" : str(item.metadata['page'])
                                                    }
                                                    }
                                                )
                        item.metadata = {'source':f, 'file_path': None, 'page': None}
                    all_pages.extend(data) 
            all_pages.extend(data)
        print("knowledge index name is ",knowledge_index_name)

        try:
            batch_size = 100  # Adjust the batch size as needed Split the data into batches of a specified size
            batches = [data_to_upload[i:i + batch_size] for i in range(0, len(data_to_upload), batch_size)]
            # client =  SearchClient(endpoint=f"https://{search_service_name}.search.windows.net/", credential= credential, index_name = knowledge_index_name)
            client =  SearchClient(endpoint=end_point, credential= credential, index_name = knowledge_index_name)
            def upload_to_database(batch):
                try:
                    print(f"Uploading batch:")                    
                    result = client.upload_documents(documents=batch)
                    time.sleep(2)  # Simulate database upload time
                except Exception as e:
                    print(f"Error uploading batch:")
                    print(f"Error details: {str(e)}")
                    retry_delay = 3  # Adjust the delay time as needed
                    print(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    upload_to_database(batch)
            status  = "success"
            # Upload each batch to the database
            for batch in data_to_upload:
                result = upload_to_database(batch)
            print("Upload of new document succeeded: ")
        except Exception as ae:
            delete = delete_index(knowledge_index_name)
            print ("exception occured ---->", ae)
    except Exception as ae:
        print ("Exception occured in azure document upload",ae) 
    return status

def remove_documents(file_name, knowledge_index_name):
    """Removes a document from an index.
    
    Args:
        index_name (str): The name of the index.
        doc_id (str): The ID of the document to remove.
    """
    knowledge_index_name = str(knowledge_index_name).replace("_","-")
    status="failed"
    try:
        # search_client = SearchClient(endpoint=f"https://{search_service_name}.search.windows.net/", credential= credential, index_name = knowledge_index_name)
        search_client = SearchClient(endpoint=end_point, credential= credential, index_name = knowledge_index_name)       
        while True:
            filter =f"metadata/source eq '{(file_name)}'"
            r = search_client.search("", filter=filter, top=1000, include_total_count=True)
            if r.get_count() == 0:
                break
            r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])
            print(f"\tRemoved {len(r)} sections from index")
            time.sleep(1)
        status= "success"
    except Exception as ae:
        print(f"exception in remove knolwedge {ae}")
    return status

def search_index(query:str, index_name:str, k) -> list:
    """Searches for documents in an index using a query.
    
    Args:
        index_name (str): The name of the index to search.
        query (str): The search query.
    
    Returns:
        list: A list of search results.
    """
    index_name = index_name.replace("_","-")
    # search_client = SearchClient(endpoint=f"https://{search_service_name}.search.windows.net/", credential= credential, index_name = index_name)
    search_client = SearchClient(endpoint=end_point, credential= credential, index_name = index_name)
    results =  search_client.search(query_type='semantic', 
                                    query_language='en-us', 
                                    semantic_configuration_name='default', 
                                    search_text = query, 
                                    select='content,metadata', 
                                    query_caption='extractive',
                                    top=k)
    combine_result = ""
    try:        
        return results
    except Exception as ae:
        result = [{"content":"No relevent document found","metadata":{'source':"None"}}]
        print("Facing Error", ae)
        return str(combine_result)