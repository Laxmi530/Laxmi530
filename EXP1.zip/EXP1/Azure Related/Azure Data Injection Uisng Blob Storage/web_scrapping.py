"""
Comprehensive Web Scraper

Extracts structured content from web pages while maintaining the original layout.
Uses Playwright (headless browser) by default to handle JavaScript-rendered pages,
interactive tabs, expandable/collapsible sections, and lazy-loaded content.
Falls back to plain HTTP requests when Playwright is unavailable.

Supported content types:
    Headings, Paragraphs, Lists (ordered, unordered, definition),
    Tables, Forms, Links, Images, Blockquotes, Code blocks,
    Navigation, Header, Footer, Article, Section, Aside,
    Tabs (ARIA roles + Bootstrap/custom — all panels revealed),
    Accordions (HTML5 details + Bootstrap/custom — all sections expanded),
    Metadata (meta tags, Open Graph, Twitter Cards),
    JSON-LD and embedded JSON data from script tags,
    Hidden content (hidden attr, CSS display:none, aria-hidden),
    Framework pre-loaded data (Next.js __NEXT_DATA__, Nuxt, initial state).

Dependencies:
    pip install requests beautifulsoup4 lxml playwright
    playwright install chromium

Usage:
    from web_scrapping import scrape_webpage

    # From a live URL:
    result = scrape_webpage("https://example.com")
    print(result["metadata"])            # dict of all meta-tag key/value pairs
    print(result["metadata"]["title"])   # page title lives here
    print(result["web_page_content"])    # structured page text

    # From a local HTML file (e.g. abc.html):
    result = scrape_webpage("abc.html")

    # To skip Playwright and use plain HTTP requests only (URLs only):
    result = scrape_webpage("https://example.com", use_playwright=False)
"""

import asyncio
import logging
import requests
import json
import re
import time
import warnings
import sys
from pathlib import Path
from bs4 import BeautifulSoup, Tag, NavigableString, Comment
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Dict, List
from urllib.parse import urljoin, urlparse
from playwright.sync_api import sync_playwright

logger = logging.getLogger(__name__)


class WebScraper:
    """Extracts structured content from web pages preserving layout hierarchy."""

    HEADERS = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
    }

    INLINE_TAGS = frozenset({
        'a', 'abbr', 'acronym', 'b', 'bdo', 'big', 'br', 'cite', 'code',
        'dfn', 'em', 'i', 'img', 'kbd', 'label', 'mark', 'q', 'samp',
        'small', 'span', 'strong', 'sub', 'sup', 'time', 'tt', 'u', 'var',
        'del', 'ins', 'wbr', 's', 'strike',
    })

    SKIP_TAGS = frozenset({'script', 'style', 'link', 'noscript', 'svg', 'path', 'template'})

    TAB_PANEL_CLASSES = frozenset({'tab-pane', 'tab-panel', 'tabpanel'})

    def __init__(self, url_or_file: str, timeout: int = 30, use_playwright: bool = True):
        """
        Initialise the scraper for a target URL or local HTML file.

        Args:
            url_or_file (str): Either a webpage URL (e.g. https://example.com)
                or a local HTML file path (e.g. abc.html, ./page.html).
            timeout (int, optional): HTTP request timeout in seconds. Defaults to 30.
            use_playwright (bool, optional): If True (default), use a headless
                Chromium browser via the file:// protocol for local HTML
                files and for URLs alike — executing JavaScript, clicking
                tabs, and expanding accordions.  Falls back to plain disk
                read (files) or plain HTTP (URLs) when Playwright is
                unavailable.
        """
        self._is_file = self._is_html_file(url_or_file)
        if self._is_file:
            self.url = self._file_path_to_url(url_or_file)
            self._file_path = Path(url_or_file).resolve()
        else:
            self.url = url_or_file
            self._file_path = None
        self.timeout = timeout
        self.use_playwright = use_playwright
        self.soup: Optional[BeautifulSoup] = None
        self.raw_html: Optional[str] = None

    @staticmethod
    def _is_html_file(input_str: str) -> bool:
        """Determine whether *input_str* is a local HTML file path.

        Parameters
        ----------
        input_str : str
            A URL or file path string.

        Returns
        -------
        bool
            ``True`` if the string does not start with ``http://`` or
            ``https://`` and either ends with ``.html``/``.htm`` or
            resolves to an existing file on disk.
        """
        s = input_str.strip()
        if s.startswith(('http://', 'https://')):
            return False
        return s.endswith(('.html', '.htm')) or Path(s).exists()

    @staticmethod
    def _file_path_to_url(file_path: str) -> str:
        """Convert a local file path to a ``file://`` URL.

        Parameters
        ----------
        file_path : str
            Relative or absolute path to an HTML file.

        Returns
        -------
        str
            A ``file:///...`` URI suitable as a base for ``urljoin``.
        """
        p = Path(file_path).resolve()
        return p.as_uri()

    # ------------------------------------------------------------------ #
    #  Fetching
    # ------------------------------------------------------------------ #

    def fetch(self) -> None:
        """
        Fetch and parse the webpage or HTML file.

        For HTML files with *use_playwright* enabled: opens the file via
        its ``file://`` URL in a headless browser so JavaScript executes,
        tabs are clicked, and accordions are expanded — identical to the
        live-URL path.  Falls back to a plain disk read when Playwright
        is unavailable.

        For URLs: tries Playwright first (full JS rendering + interactive
        expansion) and falls back to plain HTTP requests when Playwright
        is unavailable or when *use_playwright* is False.
        """
        if self._is_file:
            if self.use_playwright:
                try:
                    self._fetch_with_playwright()
                    return
                except ImportError:
                    logger.info("Playwright not installed, falling back to disk read.")
                    warnings.warn(
                        "Playwright is not installed — falling back to plain disk read. "
                        "Install it with:  pip install playwright && playwright install chromium"
                    )
                except Exception as exc:
                    logger.debug("Playwright failed for local file, falling back to disk read: %s", exc)
                    warnings.warn(f"Playwright failed ({exc}), falling back to plain disk read.")
            self._fetch_from_file()
            return
        if self.use_playwright:
            try:
                self._fetch_with_playwright()
                return
            except ImportError:
                logger.info("Playwright not installed, falling back to plain HTTP.")
                warnings.warn(
                    "Playwright is not installed — falling back to plain HTTP. "
                    "Install it with:  pip install playwright && playwright install chromium"
                )
            except Exception as exc:
                logger.debug("Playwright failed, falling back to HTTP: %s", exc)
                warnings.warn(f"Playwright failed ({exc}), falling back to plain HTTP.")
        self._fetch_with_requests()

    _session: Optional[requests.Session] = None

    @classmethod
    def _get_session(cls) -> requests.Session:
        """Return a shared :class:`requests.Session` for connection reuse."""
        if cls._session is None:
            cls._session = requests.Session()
            cls._session.headers.update(cls.HEADERS)
        return cls._session

    def _fetch_with_requests(self, retries: int = 3,
                             backoff: float = 1.0) -> None:
        """Fetch the page with a simple HTTP GET (no JS execution).

        Retries up to *retries* times on transient network errors with
        exponential back-off.
        """
        session = self._get_session()
        last_exc: Optional[Exception] = None
        for attempt in range(1, retries + 1):
            try:
                response = session.get(
                    self.url, timeout=self.timeout, verify=True,
                )
                response.raise_for_status()
                response.encoding = response.apparent_encoding or 'utf-8'
                self.raw_html = response.text
                self._parse_html()
                return
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_exc = exc
                logger.debug(
                    "HTTP attempt %d/%d failed: %s", attempt, retries, exc,
                )
                if attempt < retries:
                    time.sleep(backoff * attempt)
        raise last_exc  # type: ignore[misc]

    def _fetch_with_playwright(self) -> None:
        """
        Fetch the page with a headless Chromium browser, execute all
        JavaScript, then click every tab and expand every collapsible
        section so all content is visible before extraction.

        Automatically detects if an asyncio event loop is already running
        (e.g. inside Jupyter / IPython) and offloads Playwright to a
        separate thread to avoid the sync-inside-async conflict.
        """
        try:
            asyncio.get_running_loop()
            in_async = True
        except RuntimeError:
            in_async = False

        if in_async:
            with ThreadPoolExecutor(max_workers=1) as pool:
                pool.submit(self._run_playwright_sync).result()
        else:
            self._run_playwright_sync()

    def _run_playwright_sync(self) -> None:
        """
        Launch a headless Chromium browser, navigate to the target URL,
        expand all interactive content, and store the final HTML.

        On Windows, Jupyter / IPython swap the default asyncio loop to
        SelectorEventLoop, which cannot launch subprocesses.  We
        temporarily restore the ProactorEventLoop policy so Playwright
        can start Chromium.
        """
        
        original_policy = None
        if sys.platform == 'win32':
            original_policy = asyncio.get_event_loop_policy()
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        try:
            self._launch_playwright()
        finally:
            if original_policy is not None:
                asyncio.set_event_loop_policy(original_policy)

    def _launch_playwright(self) -> None:
        """Start a headless Chromium browser, navigate to the URL, expand
        all interactive content (tabs, accordions, collapsibles), and
        store the fully-rendered HTML in ``self.raw_html``.

        Called by :meth:`_run_playwright_sync` after event-loop policy
        adjustments.
        """

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=self.HEADERS['User-Agent'],
                viewport={'width': 1920, 'height': 1080},
            )
            page = context.new_page()
            page.goto(
                self.url,
                wait_until='domcontentloaded',
                timeout=self.timeout * 1000,
            )

            if self._is_file:
                page.wait_for_timeout(500)
            else:
                try:
                    page.wait_for_load_state('networkidle', timeout=10000)
                except Exception:
                    logger.debug("networkidle wait timed out, proceeding.")
                self._wait_for_render(page)

            try:
                self._expand_all_content(page)
            except Exception as exc:
                logger.debug("Content expansion failed: %s", exc)

            self.raw_html = page.content()
            context.close()
            browser.close()

        self._parse_html()

    def _fetch_from_file(self) -> None:
        """Read HTML from a local file and parse it into ``self.soup``.

        Raises
        ------
        FileNotFoundError
            If the file path does not exist or was not set.
        """
        if not self._file_path or not self._file_path.exists():
            raise FileNotFoundError(f"HTML file not found: {self._file_path or 'unknown'}")
        self.raw_html = self._file_path.read_text(encoding='utf-8', errors='replace')
        self._parse_html()

    # ------------------------------------------------------------------ #
    #  Wait for JS frameworks to finish rendering
    # ------------------------------------------------------------------ #

    @staticmethod
    def _wait_for_render(page, *, poll_ms: int = 1000,
                         stable_checks: int = 3,
                         max_wait_ms: int = 30000) -> None:
        """Wait until the page body size stops growing, which signals that
        JS frameworks (React, Angular, Vue) have finished rendering.
        """
        prev_size = 0
        stable = 0
        waited = 0
        while waited < max_wait_ms:
            page.wait_for_timeout(poll_ms)
            waited += poll_ms
            cur_size = page.evaluate('() => document.body.innerHTML.length')
            if cur_size == prev_size:
                stable += 1
                if stable >= stable_checks:
                    return
            else:
                stable = 0
            prev_size = cur_size

    # ------------------------------------------------------------------ #
    #  Interactive expansion (Playwright)
    # ------------------------------------------------------------------ #

    # Selectors for elements that hide content behind a click.
    # Explicitly exclude dropdown toggles — clicking them opens an
    # overlay that blocks all subsequent interactions on the page.
    _EXPAND_SELECTORS = [
        '[aria-expanded="false"]:not([data-toggle="dropdown"]):not([data-bs-toggle="dropdown"]):not(.dropdown-toggle)',
        '[data-toggle="collapse"]',
        '[data-bs-toggle="collapse"]',
        '.accordion-button.collapsed',
        '.accordion-header',
        'details:not([open]) > summary',
    ]

    @staticmethod
    def _click_elements(page, selectors, *, delay: int = 300, max_clicks: int = 200) -> int:
        """Use Playwright's native click on every element matched by
        *selectors*.  Returns the number of elements actually clicked.

        Each element is clicked at most once (deduped by bounding-box
        position).  Stale / detached / invisible elements are silently
        skipped.
        """
        clicked_positions: set = set()
        total = 0
        for sel in selectors:
            handles = page.query_selector_all(sel)
            for handle in handles:
                if total >= max_clicks:
                    return total
                try:
                    box = handle.bounding_box()
                    if box is None:
                        continue
                    pos = (round(box['x'], 1), round(box['y'], 1))
                    if pos in clicked_positions:
                        continue
                    clicked_positions.add(pos)
                    handle.scroll_into_view_if_needed(timeout=1000)
                    handle.click(timeout=2000)
                    total += 1
                    page.wait_for_timeout(delay)
                except Exception:
                    pass
        return total

    _FORCE_REVEAL_JS = '''() => {
        /* Open all <details> elements */
        document.querySelectorAll('details').forEach(d => {
            d.open = true;
        });

        /* Show every tab pane */
        document.querySelectorAll(
            '.tab-pane, [role="tabpanel"]'
        ).forEach(el => {
            el.classList.add('show', 'active');
            el.style.removeProperty('display');
            el.style.removeProperty('visibility');
            el.style.removeProperty('height');
            el.style.removeProperty('overflow');
            el.removeAttribute('hidden');
            el.setAttribute('aria-hidden', 'false');
        });

        /* Expand every collapsible / accordion body */
        document.querySelectorAll(
            '.collapse, .accordion-collapse, .panel-collapse, .accordion-body'
        ).forEach(el => {
            el.classList.add('show');
            el.classList.remove('collapse', 'collapsed', 'collapsing');
            el.style.removeProperty('display');
            el.style.removeProperty('visibility');
            el.style.height = 'auto';
            el.style.removeProperty('overflow');
            el.removeAttribute('hidden');
        });

        /* Flip all aria-expanded to true */
        document.querySelectorAll('[aria-expanded="false"]').forEach(el => {
            el.setAttribute('aria-expanded', 'true');
            el.classList.remove('collapsed');
        });

        /* Swagger / Redoc specific: expand all operation blocks */
        document.querySelectorAll('.opblock:not(.is-open)').forEach(el => {
            el.classList.add('is-open');
        });
        document.querySelectorAll('.opblock-body').forEach(el => {
            el.style.removeProperty('display');
        });

        /* Generic: reveal common hidden-utility classes
           (skip modals, popups, cookie banners) */
        document.querySelectorAll('.d-none, .hidden, .hide').forEach(el => {
            const dominated = el.closest(
                '.modal, .popup, .cookie, .gdpr, .overlay, .dialog'
            );
            if (!dominated) {
                el.classList.remove('d-none', 'hidden', 'hide');
                el.style.removeProperty('display');
            }
        });
    }'''

    _COOKIE_DISMISS_SELECTORS = [
        '#onetrust-accept-btn-handler',
        '#accept-cookie-notification',
        '[id*="cookie"] button[class*="accept"]',
        '[id*="cookie"] button[class*="close"]',
        '[id*="consent"] button[class*="accept"]',
        '[class*="cookie-banner"] button',
        '[class*="cookie-consent"] button',
        '.gdpr-accept', '.cc-accept', '.cc-dismiss',
        'button[aria-label="Accept"]',
        'button[aria-label="Accept cookies"]',
        'button[aria-label="Accept all"]',
        'button[aria-label="Close"]',
        '[data-testid="cookie-accept"]',
        '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
        '.evidon-banner-acceptbutton',
    ]

    @classmethod
    def _dismiss_overlays(cls, page) -> None:
        """Attempt to dismiss cookie consent banners, GDPR popups, and
        similar overlays that block interaction with the page content.
        """
        for sel in cls._COOKIE_DISMISS_SELECTORS:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click(timeout=1500)
                    page.wait_for_timeout(300)
                    return
            except Exception:
                continue

    @classmethod
    def _expand_all_content(cls, page) -> None:
        """
        Click every tab, expand every accordion / collapsible section,
        and force-reveal all hidden panels so the DOM contains the full
        page content before we capture the HTML.

        Handles both traditional tab/accordion frameworks (Bootstrap,
        jQuery-UI) *and* React-style libraries (e.g. react-tabs) that
        completely unmount inactive panel content from the DOM.

        For unmounting frameworks the strategy is:
          1. Click each tab.
          2. Clone the now-visible panel into a persistent container.
          3. Move to the next tab (React unmounts the previous panel,
             but our clone survives).
          4. After all tabs, the persistent container holds every
             panel's content.
        """
        # ---- Step 0: Dismiss cookie / consent banners -----------------
        try:
            cls._dismiss_overlays(page)
        except Exception as exc:
            logger.debug("Cookie banner dismissal failed: %s", exc)

        # ---- Step 1: Expand collapsibles / accordions ----------------
        try:
            cls._click_elements(page, cls._EXPAND_SELECTORS, delay=300)
            page.wait_for_timeout(500)
            page.evaluate(cls._FORCE_REVEAL_JS)
            page.wait_for_timeout(300)

            cls._click_elements(page, cls._EXPAND_SELECTORS, delay=300)
            page.wait_for_timeout(500)
        except Exception as exc:
            logger.debug("Collapsible expansion failed: %s", exc)

        # ---- Step 2: Process every tab group -------------------------
        try:
            cls._capture_all_tab_panels(page)
        except Exception as exc:
            logger.debug("Tab panel capture failed: %s", exc)

        # ---- Step 3: Final force-reveal ------------------------------
        try:
            page.evaluate(cls._FORCE_REVEAL_JS)
            page.wait_for_timeout(500)
        except Exception as exc:
            logger.debug("Force-reveal failed: %s", exc)

    @staticmethod
    def _capture_all_tab_panels(page) -> None:
        """Click every tab in every tab group, cloning each panel into a
        persistent container so that React-style frameworks that unmount
        inactive panels don't lose content.

        Works by collecting all tab IDs up-front (stable CSS-id
        selectors), then clicking each tab via ``page.click('#id')``,
        waiting for the panel to render, and cloning it.
        """
        # Prepare a persistent container in the DOM.
        page.evaluate('''() => {
            if (!document.getElementById('__scraper_panels')) {
                const c = document.createElement('div');
                c.id = '__scraper_panels';
                c.style.display = 'block';
                document.body.appendChild(c);
            }
        }''')

        # Gather every tab group → list of {tabId, panelId, text}.
        groups = page.evaluate(r'''() => {
            const groups = [];
            const lists = document.querySelectorAll(
                '[role="tablist"], .react-tabs__tab-list, '
                + '.nav-tabs, .nav-pills'
            );
            const seen = new Set();
            for (const list of lists) {
                const tabs = list.querySelectorAll('[role="tab"], .nav-link');
                const group = [];
                for (const t of tabs) {
                    if (!t.id || seen.has(t.id)) continue;
                    seen.add(t.id);
                    group.push({
                        tabId: t.id,
                        panelId: t.getAttribute('aria-controls') || '',
                        text: t.textContent.trim()
                    });
                }
                if (group.length > 0) groups.push(group);
            }
            return groups;
        }''')

        for group in groups:
            for tab_info in group:
                tab_id = tab_info['tabId']
                panel_id = tab_info['panelId']
                label = tab_info['text']
                try:
                    page.click(f'#{tab_id}', timeout=3000)
                    page.wait_for_timeout(400)
                except Exception:
                    continue

                if not panel_id:
                    continue

                try:
                    page.evaluate(r'''([panelId, label]) => {
                        const panel = document.getElementById(panelId);
                        if (!panel) return;
                        const container =
                            document.getElementById('__scraper_panels');
                        if (!container) return;
                        const existing = container.querySelector(
                            `[data-cloned-panel="${panelId}"]`
                        );
                        if (existing) return;

                        const clone = panel.cloneNode(true);
                        clone.removeAttribute('id');
                        clone.setAttribute('data-cloned-panel', panelId);
                        clone.setAttribute('data-tab-label', label);
                        clone.style.display = 'block';
                        clone.removeAttribute('hidden');
                        container.appendChild(clone);
                    }''', [panel_id, label])
                except Exception:
                    pass

    # ------------------------------------------------------------------ #
    #  HTML parsing helper
    # ------------------------------------------------------------------ #

    def _parse_html(self) -> None:
        """Parse ``self.raw_html`` into a BeautifulSoup tree (``self.soup``).

        Tries the ``lxml`` parser first for speed and standards
        compliance; falls back to Python's built-in ``html.parser`` if
        ``lxml`` fails.
        """
        try:
            self.soup = BeautifulSoup(self.raw_html, 'lxml')
        except Exception:
            self.soup = BeautifulSoup(self.raw_html, 'html.parser')

    # ------------------------------------------------------------------ #
    #  Title
    # ------------------------------------------------------------------ #

    def extract_title(self) -> str:
        """Extract the page title using a fallback chain.

        Tries (in order): ``<title>`` tag, ``og:title`` meta tag, first
        ``<h1>`` element.

        Returns
        -------
        str
            The page title, or empty string if none found.
        """
        if not self.soup:
            return ''
        title_tag = self.soup.find('title')
        if title_tag:
            return title_tag.get_text(strip=True)
        og = self.soup.find('meta', property='og:title')
        if og and og.get('content'):
            return og['content']
        h1 = self.soup.find('h1')
        if h1:
            return h1.get_text(strip=True)
        return ''

    # ------------------------------------------------------------------ #
    #  Metadata
    # ------------------------------------------------------------------ #

    def extract_metadata(self) -> Dict[str, str]:
        """
        Extract page metadata as a dictionary.

        Collects the page title, every <meta> tag (keyed by name, property,
        or http-equiv), and the canonical URL if present.  When duplicate
        keys exist the values are joined with ' | '.

        Returns:
            Dict[str, str]: Metadata key-value pairs.  Always includes a
                'title' key (empty string if none found).
        """
        meta_dict: Dict[str, str] = {}

        if not self.soup:
            return meta_dict

        meta_dict['title'] = self.extract_title()

        for meta in self.soup.find_all('meta'):
            name = meta.get('name') or meta.get('property') or meta.get('http-equiv', '')
            content = meta.get('content', '')
            if name and content:
                if name in meta_dict:
                    meta_dict[name] = meta_dict[name] + ' | ' + content
                else:
                    meta_dict[name] = content

        canonical = self.soup.find('link', rel='canonical')
        if canonical and canonical.get('href'):
            meta_dict['canonical'] = canonical['href']

        return meta_dict

    # ------------------------------------------------------------------ #
    #  JSON helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_braced(text: str, start: int) -> Optional[str]:
        """Return the brace-balanced substring starting at *start*.

        Handles nested ``{}`` correctly, unlike a non-greedy regex.
        Returns ``None`` if *start* is out of range or the braces are
        unbalanced.
        """
        if start >= len(text) or text[start] != '{':
            return None
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if escape:
                escape = False
                continue
            if ch == '\\' and in_str:
                escape = True
                continue
            if ch == '"' and not escape:
                in_str = not in_str
                continue
            if in_str:
                continue
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
        return None

    # ------------------------------------------------------------------ #
    #  JSON from script tags
    # ------------------------------------------------------------------ #

    def extract_json_from_scripts(self) -> str:
        """Extract structured JSON data embedded in ``<script>`` tags.

        Covers JSON-LD (``application/ld+json``), ``application/json``
        script blocks, and framework-specific inline patterns (Next.js
        ``__NEXT_DATA__``, Nuxt ``__NUXT__``, ``__INITIAL_STATE__``,
        ``__DATA__``).

        Returns
        -------
        str
            Labelled JSON blocks joined by double newlines, or empty
            string if no embedded JSON is found.
        """
        if not self.soup:
            return ''
        sections: List[str] = []

        for script in self.soup.find_all('script', type='application/ld+json'):
            try:
                data = json.loads(script.string or '')
                # Original: f'[JSON-LD]\n...\n[/JSON-LD]'
                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
            except (json.JSONDecodeError, TypeError):
                pass

        for script in self.soup.find_all('script', type='application/json'):
            if script.string:
                try:
                    data = json.loads(script.string)
                    # Original: f'[Script Data: {sid}]\n...\n[/Script Data: {sid}]'
                    sections.append(json.dumps(data, indent=2, ensure_ascii=False))
                except (json.JSONDecodeError, TypeError):
                    pass

        # Next.js __NEXT_DATA__
        next_script = self.soup.find('script', attrs={'id': '__NEXT_DATA__'})
        if next_script and next_script.string:
            try:
                data = json.loads(next_script.string)
                # Original: f'[Next.js Data]\n...\n[/Next.js Data]'
                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
            except (json.JSONDecodeError, TypeError):
                pass

        # Inline script patterns (Nuxt, initial state, window data)
        var_patterns = [
            (r'window\.__NUXT__\s*=\s*', 'Nuxt Data'),
            (r'window\.__INITIAL_STATE__\s*=\s*', 'Initial State'),
            (r'window\.__DATA__\s*=\s*', 'Window Data'),
        ]
        for script in self.soup.find_all('script'):
            if script.string and not script.get('type'):
                for pattern, label in var_patterns:
                    for m in re.finditer(pattern, script.string):
                        blob = self._extract_braced(script.string, m.end())
                        if blob:
                            try:
                                data = json.loads(blob)
                                # Original: f'[{label}]\n...\n[/{label}]'
                                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
                            except (json.JSONDecodeError, TypeError):
                                pass

        return '\n\n'.join(sections)

    # ------------------------------------------------------------------ #
    #  Hidden content
    # ------------------------------------------------------------------ #

    def extract_hidden_content(self) -> str:
        """Extract text from elements hidden via HTML attribute, CSS, or ARIA.

        Detects elements with ``hidden`` attribute, ``display:none`` /
        ``visibility:hidden`` inline styles, ``aria-hidden="true"``, and
        common utility classes (``hidden``, ``d-none``, ``sr-only``, etc.).

        Returns
        -------
        str
            Plain text from hidden elements, or empty string if none found.
        """
        if not self.soup:
            return ''
        seen_ids: set = set()
        hidden_elements: List[Tag] = []

        def _add(el: Tag) -> None:
            """Register a hidden element if it hasn't been seen yet."""
            eid = id(el)
            if eid not in seen_ids:
                seen_ids.add(eid)
                hidden_elements.append(el)

        for el in self.soup.find_all(lambda tag: tag.has_attr('hidden')):
            _add(el)
        for el in self.soup.find_all(style=True):
            style = el.get('style', '').replace(' ', '').lower()
            if 'display:none' in style or 'visibility:hidden' in style:
                _add(el)
        for el in self.soup.find_all(attrs={'aria-hidden': 'true'}):
            _add(el)
        for cls in ('hidden', 'd-none', 'hide', 'invisible', 'sr-only', 'visually-hidden', 'screen-reader-text'):
            for el in self.soup.find_all(class_=cls):
                _add(el)

        lines: List[str] = []
        seen_texts: set = set()
        for el in hidden_elements:
            if el.name in self.SKIP_TAGS:
                continue
            text = ' '.join(el.get_text(separator=' ', strip=True).split())
            if text and text not in seen_texts and len(text) > 1:
                seen_texts.add(text)
                lines.append(f'  {text}')

        # Original: return '[Hidden Content]\n' + '\n'.join(lines) + '\n[/Hidden Content]'
        if lines:
            return '\n'.join(lines)
        return ''

    # ------------------------------------------------------------------ #
    #  Table processing
    # ------------------------------------------------------------------ #

    def _process_table(self, table: Tag) -> str:
        """
        Convert an HTML <table> element into a markdown-style text table.

        Handles caption, header rows, data rows, and cells that span
        multiple columns (``colspan``) or rows (``rowspan``).  Column
        widths are auto-calculated for aligned output.

        Args:
            table (Tag): A BeautifulSoup <table> element.

        Returns:
            str: The table rendered as aligned plain text, or empty string
                 if the table has no rows.
        """
        caption = table.find('caption')
        caption_text = caption.get_text(strip=True) if caption else ''

        rows = table.find_all('tr')
        if not rows:
            return ''

        grid: List[List[str]] = []
        rowspan_carry: Dict[int, List] = {}

        for row in rows:
            cells = row.find_all(['th', 'td'])
            grid_row: List[str] = []
            col_idx = 0
            cell_iter = iter(cells)

            while True:
                if col_idx in rowspan_carry:
                    text, remaining = rowspan_carry[col_idx]
                    grid_row.append(text)
                    if remaining <= 1:
                        del rowspan_carry[col_idx]
                    else:
                        rowspan_carry[col_idx] = [text, remaining - 1]
                    col_idx += 1
                    continue

                cell = next(cell_iter, None)
                if cell is None:
                    break

                text = ' '.join(cell.get_text(separator=' ', strip=True).split())
                cs = int(cell.get('colspan', 1) or 1)
                rs = int(cell.get('rowspan', 1) or 1)

                for span_i in range(cs):
                    actual_col = col_idx + span_i
                    while actual_col in rowspan_carry:
                        carry_text, remaining = rowspan_carry[actual_col]
                        grid_row.append(carry_text)
                        if remaining <= 1:
                            del rowspan_carry[actual_col]
                        else:
                            rowspan_carry[actual_col] = [carry_text, remaining - 1]
                        actual_col += 1

                    grid_row.append(text if span_i == 0 else '')
                    if rs > 1:
                        rowspan_carry[actual_col] = [text if span_i == 0 else '', rs - 1]

                col_idx = len(grid_row)

            while col_idx in rowspan_carry:
                text, remaining = rowspan_carry[col_idx]
                grid_row.append(text)
                if remaining <= 1:
                    del rowspan_carry[col_idx]
                else:
                    rowspan_carry[col_idx] = [text, remaining - 1]
                col_idx += 1

            if grid_row:
                grid.append(grid_row)

        if not grid:
            return ''

        max_cols = max(len(r) for r in grid)
        col_widths = [3] * max_cols
        for row in grid:
            for i, text in enumerate(row):
                if i < max_cols:
                    col_widths[i] = max(col_widths[i], len(text))

        lines: List[str] = []
        if caption_text:
            lines.append(f'Table: {caption_text}')

        for row_idx, row in enumerate(grid):
            cells = []
            for i in range(max_cols):
                text = row[i] if i < len(row) else ''
                cells.append(text.ljust(col_widths[i]))
            lines.append('| ' + ' | '.join(cells) + ' |')
            if row_idx == 0:
                lines.append('|' + '|'.join('-' * (w + 2) for w in col_widths) + '|')

        return '\n' + '\n'.join(lines) + '\n'

    # ------------------------------------------------------------------ #
    #  Form processing
    # ------------------------------------------------------------------ #

    def _process_form(self, form: Tag) -> str:
        """
        Extract form metadata and field descriptions from an HTML <form>.

        Captures action URL, HTTP method, and details of every input,
        textarea, select, and button element including labels, placeholders,
        and select options.

        Args:
            form (Tag): A BeautifulSoup <form> element.

        Returns:
            str: A bracketed text block describing the form and its fields.
        """
        action = form.get('action', '')
        method = (form.get('method', 'get') or 'get').upper()
        form_id = form.get('name', '') or form.get('id', '')
        # Original: header = f'[Form: {form_id}]' / '[Form]' ... footer = '[/Form...]'

        lines: List[str] = []
        if form_id:
            lines.append(form_id)
        if action:
            lines.append(f'  Action: {action}')
        lines.append(f'  Method: {method}')

        for field in form.find_all(['input', 'textarea', 'select', 'button']):
            ftype = field.get('type', field.name) if field.name == 'input' else field.name
            fname = field.get('name', '') or field.get('id', '')
            parts: List[str] = []

            fid = field.get('id', '')
            if fid:
                lbl = form.find('label', attrs={'for': fid})
                if lbl:
                    parts.append(f'Label: {lbl.get_text(strip=True)}')
            if fname:
                parts.append(f'Name: {fname}')
            ph = field.get('placeholder', '')
            if ph:
                parts.append(f'Placeholder: {ph}')
            if 'required' in field.attrs:
                parts.append('Required')
            if field.name == 'select':
                opts = [o.get_text(strip=True) for o in field.find_all('option')]
                if opts:
                    parts.append(f'Options: {", ".join(opts)}')
            if field.name == 'button' or ftype == 'submit':
                btn = field.get_text(strip=True) or field.get('value', '') or 'Submit'
                parts.append(f'Text: {btn}')
            if parts:
                # Original: f'  [{ftype.upper()}] {" | ".join(parts)}'
                lines.append(f'  {ftype.upper()} {" | ".join(parts)}')

        return '\n'.join(lines)

    # ------------------------------------------------------------------ #
    #  Inline content helper
    # ------------------------------------------------------------------ #

    def _process_inline_content(self, element: Tag) -> str:
        """Recursively build inline text from an element's children.

        Whitespace is normalised (multiple spaces collapsed to one).
        Used for headings, paragraphs, and other inline containers.

        Parameters
        ----------
        element : Tag
            The parent element whose children are processed.

        Returns
        -------
        str
            The concatenated, whitespace-normalised inline text.
        """
        parts: List[str] = []
        for child in element.children:
            parts.append(self._process_element(child))
        text = ''.join(parts)
        return ' '.join(text.split())

    # ------------------------------------------------------------------ #
    #  Children combiner
    # ------------------------------------------------------------------ #

    def _process_children(self, element: Tag, depth: int = 0) -> str:
        """Process every child of *element* and concatenate the results.

        Parameters
        ----------
        element : Tag
            Parent element whose children are iterated.
        depth : int
            Current nesting depth (passed through to child processing).

        Returns
        -------
        str
            Concatenated text from all children.
        """
        parts: List[str] = []
        for child in element.children:
            part = self._process_element(child, depth)
            if part is not None:
                parts.append(part)
        return ''.join(parts)

    # ------------------------------------------------------------------ #
    #  List processing
    # ------------------------------------------------------------------ #

    def _process_list(self, list_el: Tag, depth: int, ordered: bool) -> str:
        """
        Recursively process an HTML list (<ul> or <ol>) into indented text.

        Handles nested sub-lists by increasing the indentation depth.

        Args:
            list_el (Tag): The <ul> or <ol> BeautifulSoup element.
            depth (int): Current nesting depth (controls indentation).
            ordered (bool): True for numbered lists, False for bullet lists.

        Returns:
            str: The formatted list as plain text, or empty string if no items.
        """
        items: List[str] = []
        counter = int(list_el.get('start', 1) or 1)
        indent = '  ' * depth

        for child in list_el.children:
            if not isinstance(child, Tag) or child.name != 'li':
                continue

            li_parts: List[str] = []
            nested_parts: List[str] = []

            for sub in child.children:
                if isinstance(sub, Tag) and sub.name in ('ul', 'ol'):
                    nested = self._process_list(sub, depth + 1, sub.name == 'ol')
                    if nested.strip():
                        nested_parts.append(nested)
                else:
                    part = self._process_element(sub, depth)
                    if part:
                        li_parts.append(part)

            main_text = ' '.join(''.join(li_parts).split())
            if main_text:
                marker = f'{counter}.' if ordered else '•'
                items.append(f'{indent}{marker} {main_text}')
                for nested in nested_parts:
                    items.append(nested.rstrip('\n'))
                counter += 1

        return '\n' + '\n'.join(items) + '\n' if items else ''

    def _process_definition_list(self, dl: Tag, depth: int) -> str:
        """
        Process an HTML definition list (<dl>) into bold terms and
        indented descriptions.

        Args:
            dl (Tag): The <dl> BeautifulSoup element.
            depth (int): Current nesting depth (controls indentation).

        Returns:
            str: The formatted definition list, or empty string if empty.
        """
        items: List[str] = []
        indent = '  ' * depth
        for child in dl.children:
            if not isinstance(child, Tag):
                continue
            if child.name == 'dt':
                text = child.get_text(strip=True)
                if text:
                    items.append(f'{indent}**{text}**')
            elif child.name == 'dd':
                text = child.get_text(strip=True)
                if text:
                    items.append(f'{indent}  {text}')
        return '\n' + '\n'.join(items) + '\n' if items else ''

    # ------------------------------------------------------------------ #
    #  Semantic section helper
    # ------------------------------------------------------------------ #

    def _wrap_section(self, element: Tag, tag_label: str,
                      depth: int, *, use_label: bool = False) -> str:
        """Process children of a semantic section element.

        Original version wrapped output in ``[Tag]…[/Tag]`` markers;
        now returns plain text only.

        Args:
            element: The semantic HTML element.
            tag_label: The label (e.g. ``Header``, ``Footer``) — kept
                for call-site compatibility but no longer emitted.
            depth: Current nesting depth.
            use_label: Ignored (kept for API compatibility).
        """
        text = self._process_children(element, depth + 1)
        if not text.strip():
            return ''
        # Original: f'\n[{tag_label}]\n{text.strip()}\n[/{tag_label}]\n'
        return f'\n{text.strip()}\n'

    # ------------------------------------------------------------------ #
    #  Core recursive element processor
    # ------------------------------------------------------------------ #

    def _process_element(self, element, depth: int = 0) -> str:  # noqa: C901
        """
        Recursively convert a single BeautifulSoup node into structured text.

        Dispatches to specialised handlers based on the HTML tag name
        (headings, paragraphs, lists, tables, forms, nav, semantic sections,
        ARIA roles, etc.) and falls back to processing children for generic
        block or inline containers.

        Args:
            element: A BeautifulSoup Tag, NavigableString, or Comment.
            depth (int): Current nesting depth used for indentation.

        Returns:
            str: The structured plain-text representation of the element.
        """
        if isinstance(element, Comment):
            return ''
        if isinstance(element, NavigableString):
            return re.sub(r'\s+', ' ', str(element))
        if not isinstance(element, Tag):
            return ''

        tag = element.name
        if tag in self.SKIP_TAGS:
            return ''

        # ---------- Headings ----------
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            level = int(tag[1])
            text = self._process_inline_content(element)
            return f'\n{"#" * level} {text}\n' if text else ''

        # ---------- Paragraph ----------
        if tag == 'p':
            text = self._process_inline_content(element)
            return f'\n{text}\n' if text else ''

        # ---------- Line break / Horizontal rule ----------
        if tag == 'br':
            return '\n'
        if tag == 'hr':
            return '\n---\n'

        # ---------- Links ----------
        if tag == 'a':
            text = element.get_text(strip=True)
            href = element.get('href', '')
            if href and not href.startswith(('javascript:', '#')):
                href = urljoin(self.url, href)
                # Original: f'[{text}]({href})'
                return f'{text} ({href})' if text else ''
            return text or ''

        # ---------- Images ----------
        if tag == 'img':
            alt = element.get('alt', '').strip()
            # Original: f'[Image: {alt}]'
            return alt if alt else ''

        # ---------- Iframe ----------
        if tag == 'iframe':
            src = element.get('src', '').strip()
            title = element.get('title', '').strip()
            if src:
                src = urljoin(self.url, src)
                label = title or src
                # Original: f'\n[Embedded: {label}]\n'
                return f'\n{label}\n'
            return ''

        # ---------- Video / Audio / Picture ----------
        if tag == 'video':
            src = element.get('src', '') or ''
            poster = element.get('poster', '') or ''
            sources = [s.get('src', '') for s in element.find_all('source') if s.get('src')]
            tracks = [
                f'{t.get("kind", "subtitles")}: {urljoin(self.url, t["src"])}'
                for t in element.find_all('track') if t.get('src')
            ]
            src = src or (sources[0] if sources else '')
            parts = []
            if src:
                parts.append(urljoin(self.url, src))
            if poster:
                parts.append(f'poster={urljoin(self.url, poster)}')
            for t in tracks:
                parts.append(t)
            # Original: f'\n[Video: {" | ".join(parts)}]\n'
            return f'\n{" | ".join(parts)}\n' if parts else ''

        if tag == 'audio':
            src = element.get('src', '') or ''
            sources = [s.get('src', '') for s in element.find_all('source') if s.get('src')]
            src = src or (sources[0] if sources else '')
            if src:
                # Original: f'\n[Audio: {urljoin(self.url, src)}]\n'
                return f'\n{urljoin(self.url, src)}\n'
            return ''

        if tag == 'picture':
            img = element.find('img')
            if img:
                alt = img.get('alt', '').strip()
                # Original: f'[Image: {alt}]'
                return alt if alt else ''
            return ''

        # ---------- Inline formatting ----------
        if tag in ('strong', 'b'):
            text = self._process_inline_content(element)
            return f'**{text}**' if text else ''
        if tag in ('em', 'i'):
            text = self._process_inline_content(element)
            return f'*{text}*' if text else ''
        if tag == 'code':
            text = element.get_text()
            return f'`{text}`' if text.strip() else ''
        if tag == 'mark':
            text = self._process_inline_content(element)
            return f'=={text}==' if text else ''
        if tag in ('del', 's', 'strike'):
            text = self._process_inline_content(element)
            return f'~~{text}~~' if text else ''
        if tag == 'q':
            text = self._process_inline_content(element)
            return f'"{text}"' if text else ''
        if tag in ('sub', 'sup', 'abbr', 'time', 'small', 'kbd', 'samp', 'var', 'cite', 'dfn', 'u', 'ins', 'wbr', 'bdo', 'tt'):
            return self._process_children(element, depth)

        # ---------- Preformatted / code blocks ----------
        if tag == 'pre':
            code_el = element.find('code')
            text = code_el.get_text() if code_el else element.get_text()
            lang = ''
            if code_el:
                for cls in code_el.get('class', []):
                    if cls.startswith(('language-', 'lang-')):
                        lang = cls.split('-', 1)[1]
                        break
            return f'\n```{lang}\n{text}\n```\n'

        # ---------- Lists ----------
        if tag == 'ul':
            return self._process_list(element, depth, ordered=False)
        if tag == 'ol':
            return self._process_list(element, depth, ordered=True)
        if tag == 'dl':
            return self._process_definition_list(element, depth)
        if tag in ('li', 'dt', 'dd'):
            return ''

        # ---------- Table ----------
        if tag == 'table':
            return self._process_table(element)
        if tag in ('thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col'):
            return ''

        # ---------- Blockquote ----------
        if tag == 'blockquote':
            text = self._process_children(element, depth)
            if text.strip():
                quoted = '\n'.join(f'> {ln}' for ln in text.strip().split('\n'))
                return f'\n{quoted}\n'
            return ''

        # ---------- Form ----------
        if tag == 'form':
            return '\n' + self._process_form(element) + '\n'
        if tag in ('input', 'textarea', 'select', 'option', 'optgroup', 'button', 'fieldset', 'legend', 'label', 'datalist', 'output'):
            return ''

        # ---------- Details / Summary (HTML5 Accordion) ----------
        if tag == 'details':
            return '\n' + self._process_children(element, depth + 1) + '\n'
        if tag == 'summary':
            text = self._process_inline_content(element)
            return f'\n**{text}**\n' if text else ''

        # ---------- Navigation (skip: generic site chrome) ----------
        if tag == 'nav':
            return ''

        # ---------- Semantic structural elements ----------
        if tag in ('header', 'footer', 'aside'):
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'article':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'section':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'main':
            return '\n' + self._process_children(element, depth) + '\n'

        # ---------- Figure / Figcaption ----------
        if tag == 'figure':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'figcaption':
            text = element.get_text(strip=True)
            # Original: f'[Caption: {text}]'
            return text if text else ''

        # ---------- Address ----------
        if tag == 'address':
            text = element.get_text(separator='\n', strip=True)
            # Original: f'\n[Address]\n{text}\n[/Address]\n'
            if text:
                return f'\n{text}\n'
            return ''

        # ---------- Div with ARIA roles / common tab/accordion classes ----------
        if tag == 'div':
            role = element.get('role', '')

            if role == 'tablist':
                return ''  # Skip tab labels (Copy, Expand all, etc. often nearby)
            if role == 'tabpanel':
                text = self._process_children(element, depth + 1)
                return f'\n{text.strip()}\n' if text.strip() else ''
            if role == 'alert':
                text = self._process_children(element, depth)
                return f'\n{text.strip()}\n' if text.strip() else ''
            if role == 'dialog':
                text = self._process_children(element, depth + 1)
                return f'\n{text.strip()}\n' if text.strip() else ''

            # Bootstrap / common CSS tab-pane (content only, no [Tab Panel] wrapper)
            classes = set(element.get('class', []))
            if classes & self.TAB_PANEL_CLASSES:
                text = self._process_children(element, depth + 1)
                return f'\n{text.strip()}\n' if text.strip() else ''

        # ---------- Remaining inline elements ----------
        if tag in self.INLINE_TAGS:
            return self._process_children(element, depth)

        # ---------- Default block container (div, main, etc.) ----------
        text = self._process_children(element, depth)
        if text.strip():
            return f'\n{text}\n'
        return ''

    # ------------------------------------------------------------------ #
    #  Visible content extraction
    # ------------------------------------------------------------------ #

    def extract_visible_content(self) -> str:
        """Walk the DOM tree from ``<body>`` and build structured text.

        Dispatches each element to :meth:`_process_element` which
        handles headings, paragraphs, lists, tables, forms, semantic
        sections, and more.

        Returns
        -------
        str
            The full structured text output, or the raw ``get_text()``
            fallback if no ``<body>`` element is found.
        """
        if not self.soup:
            return ''
        body = self.soup.body
        if not body:
            return self.soup.get_text(separator='\n', strip=True)
        return self._process_element(body)

    # ------------------------------------------------------------------ #
    #  Output cleanup
    # ------------------------------------------------------------------ #

    _GENERIC_UI_PHRASES = frozenset({
        'copy', 'expand all', 'collapse all', 'expand', 'collapse',
        'true', 'false',
        'log in', 'login', 'sign up', 'sign in', 'register',
        'forgot password', 'forgot password?',
        'reset save', 'edit header', 'close',
        'send', 'cancel', 'submit',
        'header parameters', 'query parameters', 'path parameters',
        'body', 'response', 'building preview ...',
        'chat window',
    })

    _NOISE_PATTERNS = re.compile(
        r'^('
        r'true|false'
        r'|log\s*in.*|sign\s*up.*|sign\s*in.*|register'
        r'|forgot\s+password.*'
        r'|reset\s+save|edit\s+header'
        r'|building\s+preview.*'
        r'|chat\s+window'
        r'|enter\s+your\s+user\s*id\s+and\s+password.*'
        r'|get\s+access\s+to\s+.+\s+by\s+creating.*'
        r'|header\s+parameters.*'
        r'|query\s+parameters.*'
        r'|path\s+parameters.*'
        r'|.{0,10}logo.{0,10}'
        r')\s*$',
        re.IGNORECASE,
    )

    @classmethod
    def _clean_output(cls, text: str) -> str:
        """
        Normalise whitespace and remove generic UI/chrome from the output.

        Strips trailing spaces, collapses excessive newlines, and removes
        lines that are generic UI noise, JS boolean artifacts, blob URLs,
        login/signup prompts, and other non-content text.
        """
        lines = [line.rstrip() for line in text.split('\n')]
        filtered: List[str] = []
        for line in lines:
            lower = line.lower().strip()
            if not lower:
                filtered.append(line)
                continue
            if lower in cls._GENERIC_UI_PHRASES:
                continue
            if re.match(r'^(copy|expand\s+all|collapse\s+all|expand|collapse)\s*$', lower):
                continue
            if re.match(r'^&\s*$', line):
                continue
            if cls._NOISE_PATTERNS.match(lower):
                continue
            line = re.sub(r'\bExpand\s+all\b', '', line, flags=re.I)
            line = re.sub(r'\bCollapse\s+all\b', '', line, flags=re.I)
            line = re.sub(r'blob:[^\s)]+', '', line)
            line = re.sub(r'\(\s*\)', '', line)
            line = re.sub(r'\s+', ' ', line).strip()
            if not line:
                continue
            filtered.append(line)
        text = '\n'.join(filtered)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    # ------------------------------------------------------------------ #
    #  Main entry point
    # ------------------------------------------------------------------ #

    def scrape(self) -> Dict[str, object]:
        """
        Fetch and extract all content.

        Returns:
            dict with two keys:
                metadata         - Dict[str, str] of all meta-tag key/value pairs
                                   (includes 'title', 'description', OG tags, etc.)
                web_page_content - str with the structured page text
        """
        parsed = urlparse(self.url)
        if not parsed.scheme:
            raise ValueError(
                f"Invalid input '{self.url}': must be a URL (https://...) "
                f"or a local HTML file path (e.g. abc.html)."
            )
        if parsed.scheme not in ('http', 'https', 'file'):
            raise ValueError(
                f"Invalid scheme '{parsed.scheme}': use https://, http://, or a local .html file."
            )

        self.fetch()

        metadata = self.extract_metadata()

        sections: List[str] = []

        visible = self.extract_visible_content()
        if visible and visible.strip():
            sections.append(visible)

        json_data = self.extract_json_from_scripts()
        if json_data:
            sections.append(json_data)

        hidden = self.extract_hidden_content()
        if hidden:
            sections.append(hidden)

        content = '\n\n'.join(sections)
        content = self._clean_output(content)

        return {
            'metadata': metadata,
            'web_page_content': content,
        }


# ====================================================================== #
#  Public API
# ====================================================================== #

def scrape_webpage(url_or_file: str, use_playwright: bool = True) -> dict:
    """
    Scrape a webpage or parse a local HTML file and return metadata and content.

    Input can be:
        - A live URL (e.g. https://example.com): Uses Playwright by default
          to render JS, expand tabs/accordions. Falls back to plain HTTP
          if Playwright is unavailable.
        - A local HTML file (e.g. abc.html, ./page.html): Reads directly
          from disk, no network or browser needed.

    Args:
        url_or_file: Either a webpage URL or a path to an HTML file.
        use_playwright: If True (default), use a headless browser for URLs.
            Ignored for HTML files.

    Returns:
        dict with two keys:
            metadata         - Dict[str, str] containing all meta-tag
                               key/value pairs (title, description,
                               og:title, canonical, etc.)
            web_page_content - str with extracted content, structure preserved

    Raises:
        requests.RequestException: On network / HTTP errors (URLs only).
        FileNotFoundError: When HTML file does not exist.

    Example::

        >>> result = scrape_webpage('https://example.com')
        >>> result = scrape_webpage('abc.html')
    """
    scraper = WebScraper(url_or_file, use_playwright=use_playwright)
    return scraper.scrape()
