"""
Azure Blob Storage Operations Module
=====================================

Provides a unified interface for common Azure Blob Storage operations
including file/folder CRUD, copy, move, download, metadata management,
SAS token generation, and container management.

Azure Blob Storage is a flat namespace — "folders" are virtual constructs
represented by blob name prefixes (e.g., ``folder1/file.txt``). This module
abstracts that detail so callers can work with familiar folder semantics.

Requirements:
    pip install azure-storage-blob azure-identity

Usage:
    >>> from blob_operation import AzureBlobOperations
    >>> ops = AzureBlobOperations(connection_string="<your_connection_string>")
    >>> ops.create_folder("my-container", "reports/2026")
"""

import os
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from azure.storage.blob import (
    BlobServiceClient,
    BlobClient,
    ContainerClient,
    BlobSasPermissions,
    generate_blob_sas,
    ContentSettings,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


class AzureBlobOperations:
    """High-level wrapper around the Azure Blob Storage SDK.

    Supports two authentication modes:
    * **Connection string** — pass ``connection_string``.
    * **Account name + key** — pass ``account_name`` and ``account_key``.

    Parameters
    ----------
    connection_string : str, optional
        Full Azure Storage connection string.
    account_name : str, optional
        Storage account name (used with ``account_key``).
    account_key : str, optional
        Storage account key (used with ``account_name``).

    Raises
    ------
    ValueError
        If neither a connection string nor an account name/key pair is provided.
    """

    def __init__(
        self,
        connection_string: Optional[str] = None,
        account_name: Optional[str] = None,
        account_key: Optional[str] = None,
    ) -> None:
        if connection_string:
            self.blob_service_client = BlobServiceClient.from_connection_string(
                connection_string
            )
            self.account_name = (
                self.blob_service_client.account_name
            )
            self.account_key = account_key
        elif account_name and account_key:
            self.account_name = account_name
            self.account_key = account_key
            account_url = f"https://{account_name}.blob.core.windows.net"
            self.blob_service_client = BlobServiceClient(
                account_url=account_url,
                credential=account_key,
            )
        else:
            raise ValueError(
                "Provide either 'connection_string' or both 'account_name' and 'account_key'."
            )

        self.connection_string = connection_string
        logger.info("AzureBlobOperations initialised for account '%s'.", self.account_name)

    # ------------------------------------------------------------------
    # Container operations
    # ------------------------------------------------------------------

    def create_container(self, container_name: str) -> bool:
        """Create a new blob container.

        Parameters
        ----------
        container_name : str
            Name of the container to create.

        Returns
        -------
        bool
            ``True`` if the container was created, ``False`` if it already exists.
        """
        try:
            self.blob_service_client.create_container(container_name)
            logger.info("Container '%s' created.", container_name)
            return True
        except Exception as e:
            if "ContainerAlreadyExists" in str(e):
                logger.warning("Container '%s' already exists.", container_name)
                return False
            logger.error("Failed to create container '%s': %s", container_name, e)
            raise

    def delete_container(self, container_name: str) -> bool:
        """Delete an entire blob container and all its contents.

        Parameters
        ----------
        container_name : str
            Name of the container to delete.

        Returns
        -------
        bool
            ``True`` on success.

        Warns
        -----
        This is irreversible — all blobs inside the container will be lost.
        """
        try:
            self.blob_service_client.delete_container(container_name)
            logger.info("Container '%s' deleted.", container_name)
            return True
        except Exception as e:
            logger.error("Failed to delete container '%s': %s", container_name, e)
            raise

    def list_containers(self) -> list[str]:
        """List all containers in the storage account.

        Returns
        -------
        list[str]
            Container names.
        """
        containers = [
            c.name for c in self.blob_service_client.list_containers()
        ]
        logger.info("Found %d container(s).", len(containers))
        return containers

    # ------------------------------------------------------------------
    # Folder operations (virtual — implemented via blob name prefixes)
    # ------------------------------------------------------------------

    def create_folder(self, container_name: str, folder_path: str) -> bool:
        """Create a virtual folder by uploading a zero-length marker blob.

        Azure Blob Storage has no native folder concept.  A common convention
        is to create a zero-byte blob whose name ends with ``/`` so that tools
        such as Azure Storage Explorer render the folder.

        Parameters
        ----------
        container_name : str
            Target container.
        folder_path : str
            Virtual folder path (e.g., ``"reports/2026"``).
            A trailing ``/`` is appended automatically if absent.

        Returns
        -------
        bool
            ``True`` on success.
        """
        if not folder_path.endswith("/"):
            folder_path += "/"

        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=folder_path
        )
        blob_client.upload_blob(data=b"", overwrite=True)
        logger.info("Virtual folder '%s' created in container '%s'.", folder_path, container_name)
        return True

    def delete_folder(self, container_name: str, folder_path: str) -> int:
        """Delete a virtual folder and **all blobs** beneath it.

        Parameters
        ----------
        container_name : str
            Target container.
        folder_path : str
            Folder prefix to delete (e.g., ``"reports/2026"``).

        Returns
        -------
        int
            Number of blobs deleted.
        """
        if not folder_path.endswith("/"):
            folder_path += "/"

        container_client = self.blob_service_client.get_container_client(container_name)
        blobs = list(container_client.list_blobs(name_starts_with=folder_path))

        if not blobs:
            logger.warning("No blobs found under '%s' in container '%s'.", folder_path, container_name)
            return 0

        for blob in blobs:
            container_client.delete_blob(blob.name)
            logger.info("Deleted blob '%s'.", blob.name)

        logger.info("Deleted %d blob(s) under '%s'.", len(blobs), folder_path)
        return len(blobs)

    # ------------------------------------------------------------------
    # File / blob operations
    # ------------------------------------------------------------------

    def create_file(
        self,
        container_name: str,
        folder_path: str,
        file_name: str,
        content: str | bytes = "",
        content_type: Optional[str] = None,
        overwrite: bool = True,
    ) -> str:
        """Upload (create) a file inside a virtual folder.

        Parameters
        ----------
        container_name : str
            Target container.
        folder_path : str
            Virtual folder path (e.g., ``"reports/2026"``).
        file_name : str
            Name of the file to create.
        content : str | bytes
            File content — accepts both text and binary data.
        content_type : str, optional
            MIME type (e.g., ``"text/plain"``).  Auto-detected if omitted.
        overwrite : bool
            If ``True`` (default), an existing blob with the same name is replaced.

        Returns
        -------
        str
            Full blob name (e.g., ``"reports/2026/summary.txt"``).
        """
        if folder_path and not folder_path.endswith("/"):
            folder_path += "/"

        blob_name = f"{folder_path}{file_name}"
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )

        kwargs: dict = {"overwrite": overwrite}
        if content_type:
            kwargs["content_settings"] = ContentSettings(content_type=content_type)

        if isinstance(content, str):
            content = content.encode("utf-8")

        blob_client.upload_blob(data=content, **kwargs)
        logger.info("File '%s' created in container '%s'.", blob_name, container_name)
        return blob_name

    def upload_local_file(
        self,
        container_name: str,
        local_file_path: str,
        folder_path: str = "",
        blob_name: Optional[str] = None,
        overwrite: bool = True,
    ) -> str:
        """Upload a file from the local file system to blob storage.

        Parameters
        ----------
        container_name : str
            Target container.
        local_file_path : str
            Path to the local file.
        folder_path : str
            Virtual folder inside the container (default: root).
        blob_name : str, optional
            Custom blob name.  Defaults to the local file's basename.
        overwrite : bool
            Replace an existing blob with the same name (default ``True``).

        Returns
        -------
        str
            Full blob name that was created.

        Raises
        ------
        FileNotFoundError
            If ``local_file_path`` does not exist.
        """
        if not os.path.isfile(local_file_path):
            raise FileNotFoundError(f"Local file not found: {local_file_path}")

        if blob_name is None:
            blob_name = os.path.basename(local_file_path)

        if folder_path:
            if not folder_path.endswith("/"):
                folder_path += "/"
            full_blob_name = f"{folder_path}{blob_name}"
        else:
            full_blob_name = blob_name

        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=full_blob_name
        )

        with open(local_file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=overwrite)

        logger.info("Uploaded '%s' -> '%s/%s'.", local_file_path, container_name, full_blob_name)
        return full_blob_name

    def download_file(
        self,
        container_name: str,
        blob_name: str,
        local_download_path: str,
    ) -> str:
        """Download a blob to the local file system.

        Parameters
        ----------
        container_name : str
            Source container.
        blob_name : str
            Full blob name (including any virtual folder prefix).
        local_download_path : str
            Local directory **or** full file path to download into.
            If a directory is given the blob's basename is used as filename.

        Returns
        -------
        str
            Absolute path of the downloaded file.
        """
        if os.path.isdir(local_download_path):
            local_download_path = os.path.join(
                local_download_path, os.path.basename(blob_name)
            )

        os.makedirs(os.path.dirname(local_download_path) or ".", exist_ok=True)

        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )

        with open(local_download_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())

        logger.info("Downloaded '%s/%s' -> '%s'.", container_name, blob_name, local_download_path)
        return os.path.abspath(local_download_path)

    def copy_file(
        self,
        source_container: str,
        source_blob_name: str,
        dest_container: str,
        dest_blob_name: str,
    ) -> str:
        """Copy a blob from one location to another (same or different container).

        The copy is server-side — data does not transit through the client.

        Parameters
        ----------
        source_container : str
            Source container name.
        source_blob_name : str
            Full source blob name (e.g., ``"folder_a/report.pdf"``).
        dest_container : str
            Destination container name.
        dest_blob_name : str
            Full destination blob name (e.g., ``"folder_b/report.pdf"``).

        Returns
        -------
        str
            The destination blob name.
        """
        source_blob_client = self.blob_service_client.get_blob_client(
            container=source_container, blob=source_blob_name
        )
        dest_blob_client = self.blob_service_client.get_blob_client(
            container=dest_container, blob=dest_blob_name
        )

        dest_blob_client.start_copy_from_url(source_blob_client.url)
        logger.info(
            "Copied '%s/%s' -> '%s/%s'.",
            source_container, source_blob_name, dest_container, dest_blob_name,
        )
        return dest_blob_name

    def move_file(
        self,
        source_container: str,
        source_blob_name: str,
        dest_container: str,
        dest_blob_name: str,
    ) -> str:
        """Move a blob by copying it to a new location and deleting the source.

        Azure Blob Storage does not support a native move/rename — this
        method performs a server-side copy followed by a delete of the original.

        Parameters
        ----------
        source_container : str
            Source container name.
        source_blob_name : str
            Full source blob name.
        dest_container : str
            Destination container name.
        dest_blob_name : str
            Full destination blob name.

        Returns
        -------
        str
            The destination blob name.
        """
        self.copy_file(source_container, source_blob_name, dest_container, dest_blob_name)
        self.delete_file(source_container, source_blob_name)
        logger.info(
            "Moved '%s/%s' -> '%s/%s'.",
            source_container, source_blob_name, dest_container, dest_blob_name,
        )
        return dest_blob_name

    def delete_file(self, container_name: str, blob_name: str) -> bool:
        """Delete a single blob.

        Parameters
        ----------
        container_name : str
            Container that holds the blob.
        blob_name : str
            Full blob name to delete.

        Returns
        -------
        bool
            ``True`` on success.
        """
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )
        blob_client.delete_blob()
        logger.info("Deleted blob '%s' from container '%s'.", blob_name, container_name)
        return True

    def rename_file(
        self,
        container_name: str,
        old_blob_name: str,
        new_blob_name: str,
    ) -> str:
        """Rename a blob (copy to new name, then delete the old one).

        Parameters
        ----------
        container_name : str
            Container that holds the blob.
        old_blob_name : str
            Current blob name.
        new_blob_name : str
            Desired blob name.

        Returns
        -------
        str
            The new blob name.
        """
        return self.move_file(container_name, old_blob_name, container_name, new_blob_name)

    # ------------------------------------------------------------------
    # Listing & querying
    # ------------------------------------------------------------------

    def list_files(
        self,
        container_name: str,
        folder_path: str = "",
    ) -> list[str]:
        """List all blobs (files) under a given folder prefix.

        Parameters
        ----------
        container_name : str
            Target container.
        folder_path : str
            Virtual folder prefix.  Leave empty to list all blobs.

        Returns
        -------
        list[str]
            Blob names matching the prefix.
        """
        if folder_path and not folder_path.endswith("/"):
            folder_path += "/"

        container_client = self.blob_service_client.get_container_client(container_name)
        blobs = [
            blob.name
            for blob in container_client.list_blobs(name_starts_with=folder_path or None)
        ]
        logger.info(
            "Listed %d blob(s) under '%s' in container '%s'.",
            len(blobs), folder_path or "/", container_name,
        )
        return blobs

    def list_folders(self, container_name: str, folder_path: str = "") -> list[str]:
        """List immediate virtual sub-folders under a given prefix.

        Parameters
        ----------
        container_name : str
            Target container.
        folder_path : str
            Parent folder prefix.  Leave empty to list top-level folders.

        Returns
        -------
        list[str]
            Virtual folder prefixes (each ending with ``/``).
        """
        if folder_path and not folder_path.endswith("/"):
            folder_path += "/"

        container_client = self.blob_service_client.get_container_client(container_name)
        folders = []
        for blob in container_client.walk_blobs(name_starts_with=folder_path or None):
            if hasattr(blob, "prefix"):
                folders.append(blob.prefix)
        logger.info(
            "Found %d sub-folder(s) under '%s' in container '%s'.",
            len(folders), folder_path or "/", container_name,
        )
        return folders

    def blob_exists(self, container_name: str, blob_name: str) -> bool:
        """Check whether a blob exists.

        Parameters
        ----------
        container_name : str
            Container to check.
        blob_name : str
            Full blob name.

        Returns
        -------
        bool
            ``True`` if the blob exists, ``False`` otherwise.
        """
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )
        return blob_client.exists()

    # ------------------------------------------------------------------
    # Metadata & properties
    # ------------------------------------------------------------------

    def get_blob_properties(self, container_name: str, blob_name: str) -> dict:
        """Retrieve a blob's system and user-defined properties.

        Parameters
        ----------
        container_name : str
            Container name.
        blob_name : str
            Full blob name.

        Returns
        -------
        dict
            Subset of blob properties including name, size, content type,
            last modified timestamp, and user metadata.
        """
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )
        props = blob_client.get_blob_properties()
        return {
            "name": props.name,
            "size_bytes": props.size,
            "content_type": props.content_settings.content_type,
            "last_modified": str(props.last_modified),
            "etag": props.etag,
            "metadata": props.metadata,
        }

    def set_blob_metadata(
        self,
        container_name: str,
        blob_name: str,
        metadata: dict[str, str],
    ) -> bool:
        """Set user-defined metadata on a blob (replaces existing metadata).

        Parameters
        ----------
        container_name : str
            Container name.
        blob_name : str
            Full blob name.
        metadata : dict[str, str]
            Key-value pairs.  Keys must be valid C# identifiers.

        Returns
        -------
        bool
            ``True`` on success.
        """
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=blob_name
        )
        blob_client.set_blob_metadata(metadata)
        logger.info("Metadata set on '%s/%s'.", container_name, blob_name)
        return True

    # ------------------------------------------------------------------
    # SAS token generation
    # ------------------------------------------------------------------

    def generate_sas_url(
        self,
        container_name: str,
        blob_name: str,
        expiry_hours: int = 1,
        permission: str = "r",
    ) -> str:
        """Generate a Shared Access Signature (SAS) URL for a blob.

        Parameters
        ----------
        container_name : str
            Container name.
        blob_name : str
            Full blob name.
        expiry_hours : int
            How long the SAS token remains valid (default 1 hour).
        permission : str
            Permission string — any combination of ``r`` (read),
            ``w`` (write), ``d`` (delete), ``c`` (create).

        Returns
        -------
        str
            Full HTTPS URL with appended SAS token.

        Raises
        ------
        ValueError
            If ``account_key`` was not provided at init time (required for
            generating SAS tokens with this method).
        """
        if not self.account_key:
            raise ValueError(
                "account_key is required to generate SAS tokens. "
                "Pass it explicitly or extract it from the connection string."
            )

        sas_token = generate_blob_sas(
            account_name=self.account_name,
            container_name=container_name,
            blob_name=blob_name,
            account_key=self.account_key,
            permission=BlobSasPermissions(
                read="r" in permission,
                write="w" in permission,
                delete="d" in permission,
                create="c" in permission,
            ),
            expiry=datetime.now(timezone.utc) + timedelta(hours=expiry_hours),
        )

        url = f"https://{self.account_name}.blob.core.windows.net/{container_name}/{blob_name}?{sas_token}"
        logger.info("Generated SAS URL for '%s/%s' (expires in %dh).", container_name, blob_name, expiry_hours)
        return url

    # ------------------------------------------------------------------
    # Bulk / convenience helpers
    # ------------------------------------------------------------------

    def copy_folder(
        self,
        source_container: str,
        source_folder: str,
        dest_container: str,
        dest_folder: str,
    ) -> list[str]:
        """Copy all blobs from one virtual folder to another.

        Parameters
        ----------
        source_container : str
            Source container.
        source_folder : str
            Source folder prefix.
        dest_container : str
            Destination container (may be the same).
        dest_folder : str
            Destination folder prefix.

        Returns
        -------
        list[str]
            Destination blob names that were created.
        """
        if not source_folder.endswith("/"):
            source_folder += "/"
        if not dest_folder.endswith("/"):
            dest_folder += "/"

        blobs = self.list_files(source_container, source_folder)
        copied: list[str] = []

        for blob_name in blobs:
            relative = blob_name[len(source_folder):]
            dest_blob = f"{dest_folder}{relative}"
            self.copy_file(source_container, blob_name, dest_container, dest_blob)
            copied.append(dest_blob)

        logger.info(
            "Copied %d blob(s) from '%s/%s' -> '%s/%s'.",
            len(copied), source_container, source_folder, dest_container, dest_folder,
        )
        return copied

    def move_folder(
        self,
        source_container: str,
        source_folder: str,
        dest_container: str,
        dest_folder: str,
    ) -> list[str]:
        """Move all blobs from one virtual folder to another (copy + delete).

        Parameters
        ----------
        source_container : str
            Source container.
        source_folder : str
            Source folder prefix.
        dest_container : str
            Destination container.
        dest_folder : str
            Destination folder prefix.

        Returns
        -------
        list[str]
            Destination blob names.
        """
        copied = self.copy_folder(source_container, source_folder, dest_container, dest_folder)
        self.delete_folder(source_container, source_folder)
        logger.info(
            "Moved %d blob(s) from '%s/%s' -> '%s/%s'.",
            len(copied), source_container, source_folder, dest_container, dest_folder,
        )
        return copied

    def upload_directory(
        self,
        container_name: str,
        local_dir_path: str,
        remote_folder: str = "",
        overwrite: bool = True,
    ) -> list[str]:
        """Recursively upload an entire local directory to blob storage.

        Parameters
        ----------
        container_name : str
            Target container.
        local_dir_path : str
            Path to the local directory.
        remote_folder : str
            Virtual folder prefix in blob storage (default: root).
        overwrite : bool
            Replace existing blobs (default ``True``).

        Returns
        -------
        list[str]
            Blob names that were uploaded.
        """
        uploaded: list[str] = []
        for root, _, files in os.walk(local_dir_path):
            for file_name in files:
                local_path = os.path.join(root, file_name)
                relative = os.path.relpath(local_path, local_dir_path).replace("\\", "/")
                if remote_folder:
                    blob_name = f"{remote_folder.rstrip('/')}/{relative}"
                else:
                    blob_name = relative
                self.upload_local_file(
                    container_name, local_path, blob_name=blob_name, overwrite=overwrite
                )
                uploaded.append(blob_name)

        logger.info("Uploaded %d file(s) from '%s' to '%s/%s'.", len(uploaded), local_dir_path, container_name, remote_folder)
        return uploaded


# ======================================================================
# Quick-start example
# ======================================================================
if __name__ == "__main__":
    CONNECTION_STRING = "<your_connection_string>"

    ops = AzureBlobOperations(connection_string=CONNECTION_STRING)

    container = "demo-container"
    ops.create_container(container)

    ops.create_folder(container, "reports/2026")

    ops.create_file(container, "reports/2026", "summary.txt", "Hello from Azure Blob Storage!")

    ops.copy_file(container, "reports/2026/summary.txt", container, "archive/2026/summary.txt")

    ops.move_file(container, "reports/2026/summary.txt", container, "final/2026/summary.txt")

    files = ops.list_files(container, "final/2026")
    print("Files:", files)

    ops.delete_file(container, "archive/2026/summary.txt")

    ops.delete_folder(container, "final/2026")
