"""Comprehensive text extraction for document files.

Supported formats:
    .pdf        — pages, tables, annotations, and document metadata.
    .docx       — paragraphs, tables, headers/footers, footnotes, endnotes,
                  and image alt-text.
    .pptx       — slide text, speaker notes, table content, and group shapes.
    .html/.htm  — structured content via ``web_scrapping`` (headings,
                  paragraphs, lists, tables, code blocks, etc.).
    .json       — text values extracted from JSON structures (keys and
                  scalar values only, no syntax characters).
    .txt        — plain text (UTF-8).
    .md         — plain text (UTF-8).

Every extractor accepts *raw bytes* (``bytes | BytesIO``) or a
*file-system path* (``str | Path``) so callers never need to write
temp files.  The public entry point is::

    text = extract_text(file_bytes, "report.pdf")
    text = extract_text(r"C:\docs\report.pdf", "report.pdf")
"""

from __future__ import annotations

import logging
import os
import tempfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path, PurePosixPath
from typing import Optional, Union

logger = logging.getLogger(__name__)

FileInput = Union[bytes, BytesIO, str, Path]

_SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".json", ".txt", ".md", ".html", ".htm"}


def _to_bytesio(data: FileInput) -> BytesIO:
    """Normalise *data* into a seeked ``BytesIO`` stream.

    Parameters
    ----------
    data : bytes | BytesIO | str | Path
        Raw file bytes, an existing ``BytesIO`` object, or a file-system
        path (string or ``Path``) whose contents will be read.

    Returns
    -------
    BytesIO
        A ``BytesIO`` stream positioned at the beginning.
    """
    if isinstance(data, (str, Path)):
        return BytesIO(Path(data).read_bytes())
    if isinstance(data, bytes):
        return BytesIO(data)
    data.seek(0)
    return data


# ======================================================================
#  PDF
# ======================================================================

def _extract_pdf(data: FileInput) -> str:
    """Extract text from a PDF file.

    Extracts document-level metadata (title, author, subject, creator),
    page text via ``pypdf``, and annotation contents (comments, sticky
    notes, free-text annotations).

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    str
        Concatenated text with page separators (``--- Page N ---``).
    """
    from pypdf import PdfReader

    reader = PdfReader(_to_bytesio(data))
    sections: list[str] = []

    # --- Document metadata ---
    meta = reader.metadata
    if meta:
        meta_lines: list[str] = []
        for attr in ("title", "author", "subject", "creator"):
            value = getattr(meta, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))

    # --- Page content ---
    for page_num, page in enumerate(reader.pages, start=1):
        parts: list[str] = []

        page_text = page.extract_text() or ""
        if page_text.strip():
            parts.append(page_text)

        # Annotations (comments, sticky notes, free-text)
        if page.get("/Annots"):
            for annot_ref in page["/Annots"]:
                try:
                    annot = annot_ref.get_object()
                    contents = annot.get("/Contents")
                    if contents and str(contents).strip():
                        parts.append(f"[Annotation] {contents}")
                except Exception:
                    pass

        if parts:
            sections.append(f"--- Page {page_num} ---\n" + "\n".join(parts))

    return "\n\n".join(sections)


# ======================================================================
#  DOCX
# ======================================================================

def _iter_docx_block_elements(body):
    """Yield ``("paragraph", element)`` or ``("table", element)`` tuples
    for every top-level ``<w:p>`` and ``<w:tbl>`` in the document body.

    Iterating children directly preserves the original document order so
    that paragraphs and tables are interleaved correctly rather than
    extracted separately.

    Parameters
    ----------
    body : lxml.etree._Element
        The ``<w:body>`` XML element from ``doc.element.body``.

    Yields
    ------
    tuple[str, lxml.etree._Element]
        ``("paragraph", elem)`` or ``("table", elem)``.
    """
    from docx.oxml.ns import qn

    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield ("paragraph", child)
        elif child.tag == qn("w:tbl"):
            yield ("table", child)


def _extract_docx(data: FileInput) -> str:
    """Extract full content from a DOCX (Word) file.

    Covers core properties (title, author, etc.), headers, footers,
    body paragraphs and tables (in document order), footnotes, endnotes,
    and image alt-text via ``python-docx``.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw DOCX bytes.

    Returns
    -------
    str
        Structured text with sections separated by double newlines.
    """
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn

    doc = Document(_to_bytesio(data))
    sections: list[str] = []

    # --- Core properties (metadata) ---
    cp = doc.core_properties
    meta_lines: list[str] = []
    for attr in ("title", "author", "subject", "category", "keywords"):
        value = getattr(cp, attr, None)
        if value:
            meta_lines.append(f"{attr.capitalize()}: {value}")
    if meta_lines:
        sections.append("\n".join(meta_lines))

    # --- Headers and footers ---
    header_texts: list[str] = []
    footer_texts: list[str] = []
    for section in doc.sections:
        for header in (section.header, section.first_page_header):
            if header and header.is_linked_to_previous is False:
                text = "\n".join(p.text for p in header.paragraphs if p.text.strip())
                if text.strip() and text not in header_texts:
                    header_texts.append(text)
        for footer in (section.footer, section.first_page_footer):
            if footer and footer.is_linked_to_previous is False:
                text = "\n".join(p.text for p in footer.paragraphs if p.text.strip())
                if text.strip() and text not in footer_texts:
                    footer_texts.append(text)

    if header_texts:
        sections.append("[Header]\n" + "\n".join(header_texts) + "\n[/Header]")

    # --- Body: paragraphs + tables in document order ---
    body_parts: list[str] = []
    for kind, element in _iter_docx_block_elements(doc.element.body):
        if kind == "paragraph":
            para = Paragraph(element, doc)
            text = para.text.strip()
            if not text:
                continue
            style_name = (para.style.name or "").lower() if para.style else ""
            if style_name.startswith("heading"):
                level = "".join(c for c in style_name if c.isdigit()) or "1"
                body_parts.append(f"{'#' * int(level)} {text}")
            elif style_name.startswith(("list", "bullet", "toc")):
                body_parts.append(f"• {text}")
            else:
                body_parts.append(text)
        elif kind == "table":
            tbl = Table(element, doc)
            table_lines = _docx_table_to_text(tbl)
            if table_lines:
                body_parts.append(table_lines)

    if body_parts:
        sections.append("\n".join(body_parts))

    # --- Footnotes ---
    footnote_parts: list[str] = []
    try:
        for rel in doc.part.rels.values():
            if "footnotes" in (rel.reltype or ""):
                fn_xml = rel.target_part.blob
                from lxml import etree
                tree = etree.fromstring(fn_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for fn in tree.findall(".//w:footnote", ns):
                    fn_id = fn.get(qn("w:id"), "")
                    if fn_id in ("-1", "0"):
                        continue
                    texts = [t.text for t in fn.findall(".//w:t", ns) if t.text]
                    if texts:
                        footnote_parts.append(f"[{fn_id}] {''.join(texts)}")
                break
    except Exception:
        pass

    if footnote_parts:
        sections.append("[Footnotes]\n" + "\n".join(footnote_parts) + "\n[/Footnotes]")

    # --- Endnotes ---
    endnote_parts: list[str] = []
    try:
        for rel in doc.part.rels.values():
            if "endnotes" in (rel.reltype or ""):
                en_xml = rel.target_part.blob
                from lxml import etree
                tree = etree.fromstring(en_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for en in tree.findall(".//w:endnote", ns):
                    en_id = en.get(qn("w:id"), "")
                    if en_id in ("-1", "0"):
                        continue
                    texts = [t.text for t in en.findall(".//w:t", ns) if t.text]
                    if texts:
                        endnote_parts.append(f"[{en_id}] {''.join(texts)}")
                break
    except Exception:
        pass

    if endnote_parts:
        sections.append("[Endnotes]\n" + "\n".join(endnote_parts) + "\n[/Endnotes]")

    # --- Image alt-text ---
    alt_texts: list[str] = []
    try:
        for drawing in doc.element.body.iter(qn("w:drawing")):
            for docPr in drawing.iter(qn("wp:docPr")):
                desc = docPr.get("descr", "").strip()
                title_attr = docPr.get("title", "").strip()
                if desc or title_attr:
                    label = title_attr or desc
                    alt_texts.append(f"[Image: {label}]")
    except Exception:
        pass

    if alt_texts:
        sections.append("\n".join(alt_texts))

    if footer_texts:
        sections.append("[Footer]\n" + "\n".join(footer_texts) + "\n[/Footer]")

    return "\n\n".join(sections)


def _docx_table_to_text(table) -> str:
    """Render a ``python-docx`` Table as a markdown-style text table.

    Column widths are auto-calculated from cell content (minimum 3
    characters) and the first row is treated as the header with a
    separator line beneath it.

    Parameters
    ----------
    table : docx.table.Table
        A table object from ``python-docx``.

    Returns
    -------
    str
        Markdown-formatted table text, or empty string if the table
        has no rows.
    """
    rows_data: list[list[str]] = []
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
        rows_data.append(cells)
    if not rows_data:
        return ""

    max_cols = max(len(r) for r in rows_data)
    col_widths = [0] * max_cols
    for row in rows_data:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))
    col_widths = [max(w, 3) for w in col_widths]

    lines: list[str] = []
    for idx, row in enumerate(rows_data):
        padded = []
        for i in range(max_cols):
            val = row[i] if i < len(row) else ""
            padded.append(val.ljust(col_widths[i]))
        lines.append("| " + " | ".join(padded) + " |")
        if idx == 0:
            lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

    return "\n".join(lines)


# ======================================================================
#  PPTX
# ======================================================================

def _extract_pptx(data: FileInput) -> str:
    """Extract text from a PowerPoint (PPTX) presentation.

    Covers presentation-level metadata, slide titles, all shape text
    (including nested groups), tables, speaker notes, and image
    alt-text via ``python-pptx``.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PPTX bytes.

    Returns
    -------
    str
        Structured text with slide separators (``--- Slide N ---``).
    """
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    sections: list[str] = []

    # --- Presentation-level metadata ---
    try:
        cp = prs.core_properties
        meta_lines: list[str] = []
        for attr in ("title", "author", "subject", "category", "keywords"):
            value = getattr(cp, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))
    except Exception:
        pass

    for slide_num, slide in enumerate(prs.slides, start=1):
        slide_parts: list[str] = [f"--- Slide {slide_num} ---"]

        # Slide title (from layout placeholder)
        if slide.shapes.title and slide.shapes.title.text.strip():
            slide_parts.append(f"# {slide.shapes.title.text.strip()}")

        # All shapes (recursive for grouped shapes)
        for shape in slide.shapes:
            text = _pptx_shape_text(shape)
            if text:
                slide_parts.append(text)

        # Speaker notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                slide_parts.append(f"[Speaker Notes]\n{notes}\n[/Speaker Notes]")

        if len(slide_parts) > 1:  # more than just the header
            sections.append("\n".join(slide_parts))

    return "\n\n".join(sections)


def _pptx_shape_text(shape) -> str:
    """Recursively extract text from a single PPTX shape.

    Handles text frames (with paragraph indentation), tables
    (rendered as markdown), group shapes (recursed into), and image
    alt-text (via the ``cNvPr`` element's ``descr`` attribute).

    Parameters
    ----------
    shape : pptx.shapes.base.BaseShape
        A shape object from ``python-pptx``.

    Returns
    -------
    str
        Extracted text lines joined by newlines, or empty string if the
        shape contains no textual content.
    """
    parts: list[str] = []

    # Text frame (paragraphs)
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if text:
                level = para.level or 0
                if level > 0:
                    parts.append(f"{'  ' * level}• {text}")
                else:
                    parts.append(text)

    # Table
    if shape.has_table:
        table = shape.table
        rows_data: list[list[str]] = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows_data.append(cells)
        if rows_data:
            max_cols = max(len(r) for r in rows_data)
            col_widths = [3] * max_cols
            for row in rows_data:
                for i, cell in enumerate(row):
                    if i < max_cols:
                        col_widths[i] = max(col_widths[i], len(cell))
            lines: list[str] = []
            for idx, row in enumerate(rows_data):
                padded = []
                for i in range(max_cols):
                    val = row[i] if i < len(row) else ""
                    padded.append(val.ljust(col_widths[i]))
                lines.append("| " + " | ".join(padded) + " |")
                if idx == 0:
                    lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")
            parts.append("\n".join(lines))

    # Group shapes (recursive)
    if shape.shape_type is not None:
        try:
            from pptx.enum.shapes import MSO_SHAPE_TYPE
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for child_shape in shape.shapes:
                    child_text = _pptx_shape_text(child_shape)
                    if child_text:
                        parts.append(child_text)
        except Exception:
            pass

    # Alt text / description via python-pptx's cNvPr element
    try:
        from pptx.oxml.ns import qn as pptx_qn

        cNvPr = shape._element.find(f".//{pptx_qn('p:cNvPr')}")
        if cNvPr is None:
            cNvPr = shape._element.find(f".//{pptx_qn('pic:cNvPr')}")
        if cNvPr is not None:
            desc = (cNvPr.get("descr") or "").strip()
            if desc:
                parts.append(f"[Image: {desc}]")
    except Exception:
        pass

    return "\n".join(parts)


# ======================================================================
#  JSON
# ======================================================================

def _scalar_to_str(value) -> Optional[str]:
    """Convert a JSON scalar to its text representation."""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else None
    return None


def _is_scalar(value) -> bool:
    """Return ``True`` for JSON scalars (str, number, bool, null)."""
    return not isinstance(value, (dict, list))


def _flatten_json(obj, lines: list[str]) -> None:
    """Walk a parsed JSON structure and append ``key value`` lines.

    * Scalar values paired with a key produce ``key value``.
    * Lists of scalars produce the key on its own line, then the
      comma-separated values on the next line.
    * Nested dicts produce the parent key on its own line, then
      the child key-value pairs on subsequent lines.
    * A top-level list is iterated element by element.
    """
    if isinstance(obj, dict):
        for key, value in obj.items():
            if _is_scalar(value):
                text = _scalar_to_str(value)
                if text is not None:
                    lines.append(f"{key} {text}")
                else:
                    lines.append(key)
            elif isinstance(value, list) and value and all(_is_scalar(v) for v in value):
                lines.append(key)
                items = [_scalar_to_str(v) for v in value]
                lines.append(", ".join(s for s in items if s))
            else:
                lines.append(key)
                _flatten_json(value, lines)
    elif isinstance(obj, list):
        for item in obj:
            if _is_scalar(item):
                text = _scalar_to_str(item)
                if text:
                    lines.append(text)
            else:
                _flatten_json(item, lines)


def _extract_json(data: FileInput) -> str:
    """Extract text content from a JSON file.

    Parses the JSON and walks the structure recursively, keeping each
    key next to its value(s) on the same line.  Lists of scalars are
    comma-separated.  All JSON syntax characters (``{}``, ``[]``,
    ``:``) are excluded so that only human-readable text remains.

    Example output for ``{"name": "Alice", "scores": [95, 88]}``::

        name Alice
        scores
        95, 88

    Parameters
    ----------
    data : bytes | BytesIO
        Raw JSON bytes.

    Returns
    -------
    str
        Key-value lines joined by newlines.
    """
    import json

    stream = _to_bytesio(data)
    text = stream.read().decode("utf-8", errors="ignore")
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.warning("Invalid JSON: %s", exc)
        return ""

    lines: list[str] = []
    _flatten_json(obj, lines)
    return "\n".join(lines)


# ======================================================================
#  TXT / MD
# ======================================================================

def _extract_plain_text(data: FileInput) -> str:
    """Decode raw bytes as UTF-8 plain text.

    Invalid byte sequences are silently ignored (``errors="ignore"``).

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes.

    Returns
    -------
    str
        The decoded text content.
    """
    stream = _to_bytesio(data)
    return stream.read().decode("utf-8", errors="ignore")


# ======================================================================
#  HTML (delegates to web_scrapping.py)
# ======================================================================

def _extract_html(data: FileInput) -> str:
    """Extract structured text from an HTML file.

    The raw bytes are written to a temporary file and processed by
    :func:`web_scrapping.scrape_webpage` (without Playwright) to
    extract headings, paragraphs, lists, tables, and other content.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw HTML bytes.

    Returns
    -------
    str
        The extracted ``web_page_content`` from the scraper result.
    """
    from web_scrapping import scrape_webpage

    raw = _to_bytesio(data).read()

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=False)
        return result.get("web_page_content", "")
    finally:
        os.unlink(tmp_path)


# ======================================================================
#  Public API
# ======================================================================

_EXTRACTORS = {
    ".pdf": _extract_pdf,
    ".docx": _extract_docx,
    ".pptx": _extract_pptx,
    ".json": _extract_json,
    ".txt": _extract_plain_text,
    ".md": _extract_plain_text,
    ".html": _extract_html,
    ".htm": _extract_html,
}


def extract_text(data: FileInput, filename: str) -> str:
    """Extract all text from *data* based on the file extension in *filename*.

    Parameters
    ----------
    data:
        Raw file bytes or a ``BytesIO`` stream.
    filename:
        Original file name (used only to detect the extension).

    Returns
    -------
    str
        The extracted plain text.

    Raises
    ------
    ValueError
        If the file extension is not supported.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor is None:
        raise ValueError(
            f"Unsupported file type '{ext}'. "
            f"Supported: {', '.join(sorted(_SUPPORTED_EXTENSIONS))}"
        )
    logger.info("Extracting text from '%s' (type=%s)", filename, ext)
    return extractor(data)


def supported_extensions() -> set[str]:
    """Return the set of file extensions this module can handle."""
    return set(_SUPPORTED_EXTENSIONS)


# ======================================================================
#  Metadata extraction
# ======================================================================

def _to_iso8601(dt: Optional[datetime]) -> Optional[str]:
    """Convert a datetime to an ISO-8601 string suitable for Azure AI Search.

    Returns ``None`` when *dt* is falsy.  Naïve datetimes are assumed UTC.
    """
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _metadata_pdf(data: FileInput) -> dict:
    """Extract title and creation date from a PDF file.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from pypdf import PdfReader

    reader = PdfReader(_to_bytesio(data))
    meta = reader.metadata
    if not meta:
        return {}

    result: dict = {}
    if meta.title:
        result["title"] = str(meta.title)

    creation = getattr(meta, "creation_date", None) or getattr(meta, "creation_date_raw", None)
    if isinstance(creation, datetime):
        result["created_date"] = _to_iso8601(creation)
    elif isinstance(creation, str):
        try:
            from pypdf.generic import parse_iso8824_date
            result["created_date"] = _to_iso8601(parse_iso8824_date(creation))
        except Exception:
            pass

    return result


def _metadata_docx(data: FileInput) -> dict:
    """Extract title and creation date from a DOCX file's core properties.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw DOCX bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from docx import Document

    doc = Document(_to_bytesio(data))
    cp = doc.core_properties
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_pptx(data: FileInput) -> dict:
    """Extract title and creation date from a PPTX file's core properties.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PPTX bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    try:
        cp = prs.core_properties
    except Exception:
        return {}
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_plain(data: FileInput) -> dict:
    """Return empty metadata for plain-text files.

    Plain text (``.txt``, ``.md``) files have no embedded metadata.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes (unused).

    Returns
    -------
    dict
        Always an empty dict.
    """
    return {}


def _metadata_html(data: FileInput) -> dict:
    """Extract title from an HTML file via ``web_scrapping``.

    The HTML is written to a temporary file and scraped for metadata.
    Only the ``title`` (from ``<title>`` or ``og:title``) is extracted.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw HTML bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) if found in the HTML metadata.
    """
    from web_scrapping import scrape_webpage

    raw = _to_bytesio(data).read()

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=False)
        meta = result.get("metadata", {})
        out: dict = {}
        title = meta.get("title") or meta.get("og:title")
        if title:
            out["title"] = title
        return out
    finally:
        os.unlink(tmp_path)


_METADATA_EXTRACTORS = {
    ".pdf": _metadata_pdf,
    ".docx": _metadata_docx,
    ".pptx": _metadata_pptx,
    ".json": _metadata_plain,
    ".txt": _metadata_plain,
    ".md": _metadata_plain,
    ".html": _metadata_html,
    ".htm": _metadata_html,
}


def extract_metadata(data: FileInput, filename: str) -> dict:
    """Extract structured metadata from a file.

    Dispatches to a format-specific extractor based on the file extension
    in *filename*.  Returns an empty dict for unsupported formats or if
    extraction fails.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes or a ``BytesIO`` stream.
    filename : str
        Original file name (used only to detect the extension).

    Returns
    -------
    dict
        May contain:

        * ``"title"`` — document title (str).
        * ``"created_date"`` — ISO-8601 creation timestamp (str).

        Keys are omitted when the corresponding value is not available.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _METADATA_EXTRACTORS.get(ext)
    if extractor is None:
        return {}
    try:
        return extractor(data)
    except Exception:
        logger.warning("Metadata extraction failed for '%s'", filename, exc_info=True)
        return {}
