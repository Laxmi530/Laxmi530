"""Azure Blob Storage helpers for the primary indexing service.

Provides utilities for interacting with blobs in the listener storage
account:

* **Client management** — lazily-initialised ``BlobServiceClient``
  singleton authenticated via ``DefaultAzureCredential``.
* **Listing** — enumerate blobs under the ``input-files/`` folder using
  ``ContainerClient.list_blobs`` (see
  https://learn.microsoft.com/en-us/azure/storage/blobs/storage-blobs-list-python).
* **Existence check** — verify whether a blob already exists in a given
  folder (e.g. ``processed-files/``).
* **Move** — copy a blob to a destination path within the same container,
  then delete the source.

Environment variables:
    ``BLOB_LISTENER_ACCOUNT_NAME`` — storage account to connect to.
"""

from __future__ import annotations

import logging
import os

from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Well-known folder names inside the blob container
# ---------------------------------------------------------------------------
SKIP_FILE = "Do_not_delete.txt"
INPUT_FOLDER = "input-files"
PROCESSED_FOLDER = "processed-files"
DUPLICATE_FOLDER = "duplicate-files"

# ---------------------------------------------------------------------------
# Lazy singleton — avoid recreating the client on every timer tick
# ---------------------------------------------------------------------------
_listener_blob_client = None


def get_listener_blob_service_client() -> BlobServiceClient:
    """Return a lazily-initialised ``BlobServiceClient`` for the listener storage account.

    The client is created on first call using ``BLOB_LISTENER_ACCOUNT_NAME``
    and ``DefaultAzureCredential``, then cached for subsequent invocations
    within the same process.

    Returns
    -------
    BlobServiceClient
        An authenticated blob-service client.

    Raises
    ------
    KeyError
        If ``BLOB_LISTENER_ACCOUNT_NAME`` is not set.
    """
    global _listener_blob_client
    if _listener_blob_client is None:
        account_name = os.environ["BLOB_LISTENER_ACCOUNT_NAME"]
        account_url = f"https://{account_name}.blob.core.windows.net"
        _listener_blob_client = BlobServiceClient(
            account_url=account_url, credential=DefaultAzureCredential()
        )
    return _listener_blob_client


# ---------------------------------------------------------------------------
# Blob helpers — list, existence check, move
# ---------------------------------------------------------------------------


def list_input_blobs(container_client):
    """List all blobs under ``input-files/``, excluding virtual-directory markers.

    Uses ``ContainerClient.list_blobs`` with a ``name_starts_with`` filter as
    recommended by the Azure SDK documentation:
    https://learn.microsoft.com/en-us/azure/storage/blobs/storage-blobs-list-python

    Parameters
    ----------
    container_client : ContainerClient
        An authenticated container client for the target container.

    Returns
    -------
    list[BlobProperties]
        Blob property objects for each file found.
    """
    blobs = container_client.list_blobs(name_starts_with=f"{INPUT_FOLDER}/")
    return [b for b in blobs if not b.name.endswith("/")]


def blob_exists_in_folder(container_client, folder: str, blob_name: str) -> bool:
    """Return ``True`` if *blob_name* already exists under *folder*.

    Parameters
    ----------
    container_client : ContainerClient
        An authenticated container client for the target container.
    folder : str
        Folder prefix to check (e.g. ``"processed-files"``).
    blob_name : str
        The blob filename to look for.
    """
    blob_client = container_client.get_blob_client(f"{folder}/{blob_name}")
    try:
        blob_client.get_blob_properties()
        return True
    except ResourceNotFoundError:
        return False


def move_blob(
    blob_service_client: BlobServiceClient,
    container_name: str,
    source_path: str,
    dest_path: str,
) -> None:
    """Copy *source_path* to *dest_path* within the same container, then delete the source.

    Parameters
    ----------
    blob_service_client : BlobServiceClient
        An authenticated blob-service client.
    container_name : str
        Name of the blob container.
    source_path : str
        Full blob path of the source (e.g. ``"input-files/report.pdf"``).
    dest_path : str
        Full blob path of the destination (e.g. ``"processed-files/report.pdf"``).
    """
    source_client = blob_service_client.get_blob_client(
        container=container_name, blob=source_path
    )
    dest_client = blob_service_client.get_blob_client(
        container=container_name, blob=dest_path
    )
    data = source_client.download_blob().readall()
    dest_client.upload_blob(data, overwrite=True)
    source_client.delete_blob()
