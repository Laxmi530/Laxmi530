"""Unified Azure authentication and credential management for indexing.

Provides a single credential resolution chain:

1. ``AZURE_CLIENT_ID_VALUE`` + ``AZURE_CLIENT_SECRET_VALUE`` + ``AZURE_TENANT_ID``
   (already resolved by ``load_keyvault_secrets_into_environ`` at startup) →
   ``ClientSecretCredential``.
2. ``VAULT_URL`` / ``KEY_VAULT_URL`` / ``AZURE_KEY_VAULT_URL`` + ``AZURE_TENANT_ID`` +
   ``KEY_VAULT_SECRET_NAME_CLIENT_ID`` + ``KEY_VAULT_SECRET_NAME_CLIENT_SECRET`` →
   read app id and secret from Key Vault (``DefaultAzureCredential`` with
   ``exclude_environment_credential=True``), then ``ClientSecretCredential``.
3. Direct env vars (``AZURE_CLIENT_ID`` as valid GUID + ``AZURE_CLIENT_SECRET`` +
   ``AZURE_TENANT_ID``) → ``ClientSecretCredential``.
4. ``DefaultAzureCredential`` (managed identity in Azure, az login locally).

Optional bulk load: ``keyvault_bootstrap.load_secrets_from_key_vault()`` via
``KEY_VAULT_SECRET_MAPPING`` (call that before this module resolves credentials).

  TLS: TEST_OPENAI_SSL_VERIFY, SSL_CERT_FILE, REQUESTS_CA_BUNDLE

When running tests with `python test_openai.py` (not `func start`), call
`load_local_settings_json()` after `load_dotenv()` so Values from
local.settings.json are applied (same as Azure Functions local host).
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Union

from azure.identity import ClientSecretCredential, DefaultAzureCredential

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ENV_AZURE_CLIENT_ID_VALUE = "AZURE_CLIENT_ID_VALUE"
_ENV_AZURE_CLIENT_SECRET_VALUE = "AZURE_CLIENT_SECRET_VALUE"
_ENV_KV_SECRET_NAME_CLIENT_ID = "KEY_VAULT_SECRET_NAME_CLIENT_ID"
_ENV_KV_SECRET_NAME_CLIENT_SECRET = "KEY_VAULT_SECRET_NAME_CLIENT_SECRET"

# ---------------------------------------------------------------------------
# UUID / GUID validation
# ---------------------------------------------------------------------------

_UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)


def _is_uuid(s: str) -> bool:
    """Check whether *s* is a valid UUID / GUID string.

    Parameters
    ----------
    s : str
        String to test (leading/trailing whitespace is stripped).

    Returns
    -------
    bool
        ``True`` if *s* matches the standard 8-4-4-4-12 hex GUID
        pattern (e.g. ``"550e8400-e29b-41d4-a716-446655440000"``).
    """
    return bool(_UUID_RE.fullmatch(s.strip()))


# ---------------------------------------------------------------------------
# Environment cleanup
# ---------------------------------------------------------------------------


def _clean_environment_for_managed_identity() -> None:
    """Remove ``AZURE_CLIENT_ID`` / ``AZURE_CLIENT_SECRET`` from the environment
    when they contain Key Vault secret *names* instead of actual credentials.

    ``DefaultAzureCredential`` reads ``AZURE_CLIENT_ID`` and, if set, treats it
    as a user-assigned MI client ID or (via ``EnvironmentCredential``) as a
    literal SP client ID.  When it actually holds a Key Vault secret name the
    SDK fails with AADSTS700016 or 'No User Assigned … Managed Identity found'.
    """
    if not (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip():
        leg = (os.environ.get("AZURE_CLIENT_ID") or "").strip()
        if leg and not _is_uuid(leg):
            os.environ[_ENV_KV_SECRET_NAME_CLIENT_ID] = leg

    cid = (os.environ.get("AZURE_CLIENT_ID") or "").strip()
    if cid and not _is_uuid(cid):
        os.environ.pop("AZURE_CLIENT_ID", None)
        logger.warning(
            "Removed AZURE_CLIENT_ID from environment (not a GUID — likely a "
            "Key Vault secret name). Use KEY_VAULT_SECRET_NAME_CLIENT_ID instead."
        )

    kv_names_in_use = (
        (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip()
        or (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_SECRET) or "").strip()
    )
    if kv_names_in_use and "AZURE_CLIENT_SECRET" in os.environ:
        os.environ.pop("AZURE_CLIENT_SECRET", None)
        logger.warning(
            "Removed AZURE_CLIENT_SECRET from environment while using "
            "KEY_VAULT_SECRET_NAME_* (avoid EnvironmentCredential picking up a secret name)."
        )


# ---------------------------------------------------------------------------
# Vault URL
# ---------------------------------------------------------------------------


def vault_url() -> str:
    """Resolve the Azure Key Vault base URL from environment variables.

    Checks ``VAULT_URL``, ``KEY_VAULT_URL``, and ``AZURE_KEY_VAULT_URL``
    (in that order) and returns the first non-empty value, stripped of
    whitespace and trailing slashes.

    Returns
    -------
    str
        The vault URL, or an empty string if none is configured.
    """
    return (
        (
            os.getenv("VAULT_URL")
            or os.getenv("KEY_VAULT_URL")
            or os.getenv("AZURE_KEY_VAULT_URL")
            or ""
        )
        .strip()
        .rstrip("/")
    )


# ---------------------------------------------------------------------------
# Service-principal env helpers
# ---------------------------------------------------------------------------


def sp_client_id_from_env() -> str:
    """Return the resolved service principal application (client) ID.

    Reads from ``AZURE_CLIENT_ID_VALUE`` which is populated at startup
    by :func:`load_keyvault_secrets_into_environ` after resolving the
    Key Vault secret name.

    Returns
    -------
    str
        The client ID string, or empty string if not set.
    """
    return (os.environ.get(_ENV_AZURE_CLIENT_ID_VALUE) or "").strip()


def sp_client_secret_from_env() -> str:
    """Return the resolved service principal client secret.

    Reads from ``AZURE_CLIENT_SECRET_VALUE`` which is populated at
    startup by :func:`load_keyvault_secrets_into_environ`.

    Returns
    -------
    str
        The client secret string, or empty string if not set.
    """
    return (os.environ.get(_ENV_AZURE_CLIENT_SECRET_VALUE) or "").strip()


def service_principal_credentials_configured() -> bool:
    """Check whether service principal credentials are fully configured.

    Returns ``True`` when ``AZURE_TENANT_ID`` is set along with either:

    * ``AZURE_CLIENT_ID_VALUE`` + ``AZURE_CLIENT_SECRET_VALUE``
      (resolved at startup), or
    * ``AZURE_CLIENT_ID`` (valid GUID) + ``AZURE_CLIENT_SECRET``
      (direct env vars).

    Returns
    -------
    bool
        ``True`` if a ``ClientSecretCredential`` can be constructed.
    """
    tenant = (os.environ.get("AZURE_TENANT_ID") or "").strip()
    if tenant and sp_client_id_from_env() and sp_client_secret_from_env():
        return True
    return all(
        (os.environ.get(k) or "").strip()
        for k in ("AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET")
    ) and _is_uuid((os.environ.get("AZURE_CLIENT_ID") or "").strip())


# ---------------------------------------------------------------------------
# Core credential resolution (cached)
# ---------------------------------------------------------------------------

_credential_cache: Union[ClientSecretCredential, DefaultAzureCredential, None] = None


def get_cognitive_services_credential():
    """Return a cached credential for Azure Cognitive Services (OpenAI, Search, etc.).

    The credential is resolved once and cached for the process lifetime.
    Resolution order:

    1. ``AZURE_CLIENT_ID_VALUE`` + ``AZURE_CLIENT_SECRET_VALUE``
       (already resolved at startup) → ``ClientSecretCredential``.
    2. Key Vault URL + ``KEY_VAULT_SECRET_NAME_CLIENT_ID`` +
       ``KEY_VAULT_SECRET_NAME_CLIENT_SECRET`` → fetch from KV →
       ``ClientSecretCredential``.
    3. Direct env vars (``AZURE_CLIENT_ID`` must be a valid GUID) →
       ``ClientSecretCredential``.
    4. ``DefaultAzureCredential`` (managed identity in Azure, or
       ``az login`` locally).

    Returns
    -------
    ClientSecretCredential | DefaultAzureCredential
        The first viable credential from the resolution chain.
    """
    global _credential_cache
    if _credential_cache is not None:
        return _credential_cache
    _credential_cache = _resolve_credential()
    return _credential_cache


def reset_cognitive_services_credential_cache() -> None:
    """Clear the cached credential so the next call to
    :func:`get_cognitive_services_credential` re-resolves.

    Intended for test isolation — not for production use.
    """
    global _credential_cache
    _credential_cache = None


def _resolve_credential():
    """Walk the four-path resolution chain and return the first viable credential.

    See :func:`get_cognitive_services_credential` for the full resolution
    order.  This function is called once; its result is cached by the
    caller.

    Returns
    -------
    ClientSecretCredential | DefaultAzureCredential
        The first credential that can be constructed from available
        environment variables / Key Vault secrets.
    """
    from azure.identity import ClientSecretCredential, DefaultAzureCredential

    tenant_id = (os.getenv("AZURE_TENANT_ID") or "").strip()

    # Path 1: Credentials already resolved at startup (AZURE_CLIENT_ID_VALUE).
    client_id_value = sp_client_id_from_env()
    client_secret_value = sp_client_secret_from_env()
    if tenant_id and client_id_value and client_secret_value:
        logger.info("Using SP credentials from AZURE_CLIENT_ID_VALUE (resolved at startup).")
        return ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id_value,
            client_secret=client_secret_value,
        )

    # Path 2: Key Vault resolution.
    v_url = vault_url()
    name_client = (os.getenv(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip()
    name_secret = (os.getenv(_ENV_KV_SECRET_NAME_CLIENT_SECRET) or "").strip()

    if v_url and tenant_id and name_client and name_secret:
        from azure.keyvault.secrets import SecretClient

        _clean_environment_for_managed_identity()

        kv = SecretClient(
            vault_url=v_url,
            credential=DefaultAzureCredential(exclude_environment_credential=True),
        )

        def _get_secret(name: str) -> str:
            return (kv.get_secret(name).value or "").strip()

        client_id = _get_secret(name_client)
        client_secret = _get_secret(name_secret)
        if client_id and client_secret:
            os.environ["AZURE_TENANT_ID"] = tenant_id
            os.environ["AZURE_CLIENT_ID"] = client_id
            os.environ["AZURE_CLIENT_SECRET"] = client_secret
            os.environ[_ENV_AZURE_CLIENT_ID_VALUE] = client_id
            os.environ[_ENV_AZURE_CLIENT_SECRET_VALUE] = client_secret
            return ClientSecretCredential(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
            )

    # Path 3: Direct env vars (AZURE_CLIENT_ID must be a real GUID).
    if not v_url:
        client_id = (os.getenv("AZURE_CLIENT_ID") or "").strip()
        client_secret = (os.getenv("AZURE_CLIENT_SECRET") or "").strip()
        if tenant_id and client_id and _is_uuid(client_id) and client_secret:
            return ClientSecretCredential(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
            )

    # Path 4: Managed Identity / az login fallback.
    _clean_environment_for_managed_identity()
    logger.info(
        "Using DefaultAzureCredential (managed identity or dev login); "
        "set AZURE_TENANT_ID + AZURE_CLIENT_ID_VALUE + AZURE_CLIENT_SECRET_VALUE "
        "or KEY_VAULT_SECRET_NAME_* + vault URL for SP auth."
    )
    return DefaultAzureCredential(exclude_interactive_browser_credential=True)


# ---------------------------------------------------------------------------
# Key Vault secrets → os.environ (startup bootstrap)
# ---------------------------------------------------------------------------


def _resolve_sp_secrets_from_key_vault_names(client) -> None:
    """Fetch service principal credentials from Key Vault into ``os.environ``.

    Reads ``KEY_VAULT_SECRET_NAME_CLIENT_ID`` and
    ``KEY_VAULT_SECRET_NAME_CLIENT_SECRET`` to look up the corresponding
    secrets from Key Vault, then stores the resolved values in
    ``AZURE_CLIENT_ID_VALUE`` and ``AZURE_CLIENT_SECRET_VALUE``.

    No-op if both ``_VALUE`` env vars are already populated.

    Parameters
    ----------
    client : SecretClient
        An authenticated Key Vault ``SecretClient``.

    Raises
    ------
    ValueError
        If a referenced secret is missing, empty, or (for client ID)
        not a valid GUID.
    """
    if sp_client_id_from_env() and sp_client_secret_from_env():
        return

    cid_name = (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip()
    if cid_name:
        bundle = client.get_secret(cid_name)
        if not bundle or not (bundle.value or "").strip():
            raise ValueError(
                f"Key Vault secret {cid_name!r} (KEY_VAULT_SECRET_NAME_CLIENT_ID) is missing or empty."
            )
        resolved = bundle.value.strip()
        os.environ[_ENV_AZURE_CLIENT_ID_VALUE] = resolved
        if not _is_uuid(resolved):
            raise ValueError(
                f"Key Vault secret {cid_name!r} must contain the application (client) ID GUID; "
                f"got a non-GUID value."
            )

    csec_name = (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_SECRET) or "").strip()
    if csec_name:
        bundle = client.get_secret(csec_name)
        if not bundle or not (bundle.value or "").strip():
            raise ValueError(
                f"Key Vault secret {csec_name!r} (KEY_VAULT_SECRET_NAME_CLIENT_SECRET) is missing or empty."
            )
        os.environ[_ENV_AZURE_CLIENT_SECRET_VALUE] = bundle.value.strip()


def load_keyvault_secrets_into_environ() -> None:
    """Bootstrap Key Vault secrets into ``os.environ`` at startup.

    When ``AZURE_KEY_VAULT_URL`` is set, uses ``DefaultAzureCredential``
    (system-assigned managed identity) to resolve SP secrets from
    ``KEY_VAULT_SECRET_NAME_CLIENT_ID`` / ``KEY_VAULT_SECRET_NAME_CLIENT_SECRET``
    into ``AZURE_*_VALUE`` env vars.
    """
    v_url = vault_url()
    if not v_url:
        return
    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as e:
        logger.warning("Key Vault packages missing; install azure-identity and azure-keyvault-secrets: %s", e)
        return

    _clean_environment_for_managed_identity()
    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=v_url, credential=credential)

    try:
        _resolve_sp_secrets_from_key_vault_names(client)
    except Exception as e:
        logger.error("Key Vault resolve KEY_VAULT_SECRET_NAME_CLIENT_* failed: %s", e)
        raise


def load_local_settings_json() -> None:
    """Merge ``Values`` from ``local.settings.json`` into ``os.environ``.

    Only keys that are not already present in the environment are added.
    This lets test scripts (run with ``python test_openai.py``) reuse
    the same configuration as ``func host`` without duplicating values
    in ``.env``.

    The file is expected at the same directory as this module.  If it
    does not exist or cannot be parsed, the function silently returns.
    """
    path = Path(__file__).resolve().parent / "local.settings.json"
    if not path.is_file():
        return
    try:
        with path.open(encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return
    for key, value in data.get("Values", {}).items():
        if key in os.environ:
            continue
        if value is None:
            continue
        s = str(value).strip()
        if s == "":
            continue
        os.environ[key] = s


def get_client_secret_credential():
    """Return a ``ClientSecretCredential`` for service principal authentication.

    First attempts to use the cached credential from
    :func:`get_cognitive_services_credential`.  If that returned a
    ``DefaultAzureCredential``, falls back to constructing a new
    ``ClientSecretCredential`` from environment variables.

    Returns
    -------
    ClientSecretCredential
        An authenticated service principal credential.

    Raises
    ------
    ValueError
        If the required tenant ID, client ID, or client secret
        environment variables are not available.
    """
    from azure.identity import ClientSecretCredential

    cred = get_cognitive_services_credential()
    if isinstance(cred, ClientSecretCredential):
        return cred

    tenant_id = os.environ.get("AZURE_TENANT_ID")
    client_id = sp_client_id_from_env() or (os.environ.get("AZURE_CLIENT_ID") or "").strip()
    client_secret = sp_client_secret_from_env() or (os.environ.get("AZURE_CLIENT_SECRET") or "").strip()
    if not all([tenant_id, client_id, client_secret]):
        raise ValueError(
            "Set AZURE_TENANT_ID + AZURE_CLIENT_ID_VALUE + AZURE_CLIENT_SECRET_VALUE (literals or after KV resolve), "
            "or AZURE_KEY_VAULT_URL + KEY_VAULT_SECRET_NAME_CLIENT_ID + KEY_VAULT_SECRET_NAME_CLIENT_SECRET."
        )
    return ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
    )


def build_openai_azure_ad_token_provider():
    """Build a bearer-token provider for Azure OpenAI (Cognitive Services scope).

    Uses the credential from :func:`get_cognitive_services_credential`
    (same SP / Key Vault / MI resolution chain).  Prefers the SDK's
    ``get_bearer_token_provider`` when available; falls back to a simple
    synchronous ``get_token`` wrapper otherwise.

    Returns
    -------
    Callable[[], str]
        A callable that returns a fresh bearer token string each time
        it is invoked.
    """
    scope = "https://cognitiveservices.azure.com/.default"
    credential = get_cognitive_services_credential()
    if isinstance(credential, DefaultAzureCredential):
        logging.info(
            "Azure OpenAI: using DefaultAzureCredential (managed identity or dev login); "
            "set AZURE_TENANT_ID + KEY_VAULT_SECRET_NAME_CLIENT_ID + "
            "KEY_VAULT_SECRET_NAME_CLIENT_SECRET + vault URL (or env SP vars) otherwise."
        )

    try:
        from azure.identity import get_bearer_token_provider

        return get_bearer_token_provider(credential, scope)
    except ImportError:

        def _sync_token():
            return credential.get_token(scope).token

        return _sync_token


def resolve_httpx_verify():
    """Determine the ``verify`` parameter for ``httpx.Client``.

    Resolution logic:

    * ``False`` — when ``TEST_OPENAI_SSL_VERIFY`` is ``"0"``/``"false"``/``"no"``.
    * ``str`` (path) — when ``SSL_CERT_FILE`` or ``REQUESTS_CA_BUNDLE``
      points to an existing PEM bundle file.
    * ``True`` — use the system default CA certificates.

    Returns
    -------
    bool | str
        The resolved value suitable for ``httpx.Client(verify=...)``.
    """
    flag = os.environ.get("TEST_OPENAI_SSL_VERIFY", "true").lower()
    if flag in ("0", "false", "no"):
        return False
    for key in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE"):
        path = os.environ.get(key)
        if path and os.path.isfile(path):
            return path
    return True


def _old_service_principal_credentials_configured() -> bool:
    """Deprecated: kept for backward compat. Use ``service_principal_credentials_configured``."""
    return all(
        os.environ.get(k)
        for k in (
            "AZURE_TENANT_ID",
            "AZURE_CLIENT_ID",
            "AZURE_CLIENT_SECRET",
        )
    )


def create_openai_client(azure_endpoint: str, api_version: str):
    """Create an ``AzureOpenAI`` client authenticated via Microsoft Entra ID.

    Uses :func:`build_openai_azure_ad_token_provider` for token
    acquisition and :func:`resolve_httpx_verify` for TLS configuration.

    Parameters
    ----------
    azure_endpoint : str
        Full URL of the Azure OpenAI resource
        (e.g. ``"https://my-openai.openai.azure.com/"``).
    api_version : str
        Azure OpenAI REST API version string
        (e.g. ``"2024-12-01-preview"``).

    Returns
    -------
    openai.AzureOpenAI
        A configured client with a 120-second HTTP timeout.
    """
    from openai import AzureOpenAI

    import httpx

    return AzureOpenAI(
        azure_endpoint=azure_endpoint,
        api_version=api_version,
        azure_ad_token_provider=build_openai_azure_ad_token_provider(),
        http_client=httpx.Client(verify=resolve_httpx_verify(), timeout=120.0),
    )


def build_search_credential():
    """Build a credential for Azure AI Search.

    If ``AZURE_SEARCH_API_KEY`` is set, returns an ``AzureKeyCredential``.
    Otherwise falls back to the Entra ID credential from
    :func:`get_cognitive_services_credential`.

    Returns
    -------
    AzureKeyCredential | ClientSecretCredential | DefaultAzureCredential
        The credential to use with ``SearchClient`` /
        ``SearchIndexClient``.
    """
    from azure.core.credentials import AzureKeyCredential

    key = os.environ.get("AZURE_SEARCH_API_KEY")
    if key:
        return AzureKeyCredential(key)
    return get_cognitive_services_credential()


REDIS_ENTRA_SCOPE = "https://redis.azure.com/.default"


def parse_redis_host_port_from_env():
    """Resolve Redis host and port from environment variables.

    Checks ``AZURE_REDIS_HOST`` (or ``REDIS_HOST``) first.  If not set,
    parses ``REDIS_CONNECTION_STRING`` (``redis://`` or ``rediss://``).
    Port defaults to ``6380`` (Azure Cache for Redis TLS) when not
    explicitly provided.

    Returns
    -------
    tuple[str, int]
        ``(host, port)`` for the Redis connection.

    Raises
    ------
    ValueError
        If no host can be determined from the environment.
    """
    from urllib.parse import urlparse

    host = (os.environ.get("AZURE_REDIS_HOST") or os.environ.get("REDIS_HOST") or "").strip()
    port_str = os.environ.get("AZURE_REDIS_PORT", "").strip()
    if not host:
        conn = os.environ.get("REDIS_CONNECTION_STRING", "").strip()
        if conn.startswith("rediss://") or conn.startswith("redis://"):
            parsed = urlparse(conn)
            host = parsed.hostname or ""
            if not port_str and parsed.port:
                port_str = str(parsed.port)
    if not host:
        raise ValueError(
            "Set AZURE_REDIS_HOST (or REDIS_HOST), or REDIS_CONNECTION_STRING with a host, for Redis Entra."
        )
    port = int(port_str) if port_str else 6380
    return host, port


def redis_ssl_tls_kwargs():
    """Build TLS keyword arguments for ``redis.Redis``.

    Respects ``TEST_REDIS_SSL_VERIFY`` / ``TEST_OPENAI_SSL_VERIFY`` for
    certificate verification and ``SSL_CERT_FILE`` /
    ``REQUESTS_CA_BUNDLE`` for custom CA bundles.

    Returns
    -------
    dict
        Keyword arguments (``ssl``, ``ssl_ca_certs``, ``ssl_cert_reqs``)
        suitable for passing to ``redis.Redis(**kwargs)``.
    """
    import ssl

    flag = (
        os.environ.get("TEST_REDIS_SSL_VERIFY")
        or os.environ.get("TEST_OPENAI_SSL_VERIFY")
        or "true"
    ).lower()
    ca_path = os.environ.get("SSL_CERT_FILE") or os.environ.get("REQUESTS_CA_BUNDLE") or ""
    kwargs = {"ssl": True}
    if ca_path and os.path.isfile(ca_path):
        kwargs["ssl_ca_certs"] = ca_path
        kwargs["ssl_cert_reqs"] = ssl.CERT_REQUIRED
    elif flag in ("0", "false", "no"):
        kwargs["ssl_cert_reqs"] = ssl.CERT_NONE
    else:
        kwargs["ssl_cert_reqs"] = ssl.CERT_REQUIRED
    return kwargs
