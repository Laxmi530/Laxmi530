# Primary Indexing Service

Azure Functions v2 (Python) application that processes blobs uploaded to Azure Storage and indexes their content as vector embeddings in Azure AI Search. Supports context-aware chunking that preserves document structure (headings, sections) as per-chunk metadata for improved retrieval quality.

## Architecture

```
Blob Storage (input-files/)
        │
        ▼
  Event Grid event
        │
        ▼
  blob_trigger_vectorcreation  (HTTP webhook)
        │
        ├── Download blob
        ├── Extract text with heading enrichment
        │     (file_extraction_enhanced.py)
        │     Supported: .pdf, .docx, .pptx, .html, .json, .txt, .md
        │
        ├── Chunk text (4 strategies available)
        │     (chunking_strategies.py)
        │     ┌─ heading_aware (default) — splits on # headings + recursive sub-chunk
        │     ├─ hybrid — heading-aware + semantic sub-chunk
        │     ├─ semantic — embedding-based topic detection
        │     └─ recursive — fast character-boundary splitting
        │
        ├── Generate embeddings (Azure OpenAI, batched)
        │     Uses heading-prepended text for better retrieval
        │
        ├── Store chunks to blob (chunk-stored/)
        └── Upsert vectors + metadata → Azure AI Search index
              Fields: content, contentVector, section_heading,
                      parent_heading, heading_path, chunk_index, ...
```

## Project Structure

| File | Purpose |
|---|---|
| `function_app.py` | Main entry point — Event Grid webhook, blob processing pipeline, strategy selection, embedding, and index upsert |
| `indexing.py` | Azure AI Search index management (including `section_heading`, `heading_path` fields), embedding generation, chunk blob storage, and document upsert |
| `blob_helpers.py` | Azure Blob Storage utilities — lazy-initialised `BlobServiceClient` singleton, listing blobs under `input-files/`, existence checks, and move (copy + delete) within a container |
| `chunking_strategies.py` | All 4 chunking strategies in one module: `recursive`, `semantic`, `heading_aware`, `hybrid`. Returns `ChunkWithMetadata` objects with structural metadata |
| `file_extraction.py` | Base text extraction for `.pdf`, `.docx`, `.pptx`, `.html`, `.txt`, `.md`, `.json` files |
| `file_extraction_enhanced.py` | Heading-enriched text extraction — injects markdown `#` headings into PDF, DOCX, TXT, JSON output so context-aware chunking can split by document structure |
| `web_scrapping.py` | HTML content extractor with Playwright support (tabs, accordions, JS-rendered pages, cookie dismissal) |
| `azure_sp_common.py` | Unified credential resolution (Entra ID / service principal / Key Vault / managed identity) |
| `keyvault_bootstrap.py` | Optional startup bulk-load of Key Vault secrets via `KEY_VAULT_SECRET_MAPPING` |
| `host.json` | Azure Functions host configuration (route prefix, logging, extension bundle) |
| `requirements.txt` | Python dependencies |
| `local.settings.json` | Local development settings (not deployed) |

## Prerequisites

- Python 3.9+
- [Azure Functions Core Tools](https://learn.microsoft.com/en-us/azure/azure-functions/functions-run-local) v4
- An Azure subscription with:
  - **Azure Storage Account** — blob container with an `input-files/` folder
  - **Azure OpenAI** — embedding model deployment (e.g. `text-embedding-3-small`) and optionally a chat model (e.g. `gpt-4o-mini`) for semantic chunking
  - **Azure AI Search** — search service for the vector index
  - **Azure Key Vault** (optional) — for storing service principal credentials

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

If using the HTML scraper with Playwright:

```bash
playwright install chromium
```

### 2. Configure environment variables

Copy `local.settings.json` to your working directory and populate the `Values` section, or create a `.env` file in the project root.

#### Required

| Variable | Description |
|---|---|
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI resource endpoint URL |
| `AZURE_SEARCH_ENDPOINT` | Azure AI Search service endpoint URL |

#### Optional

| Variable | Default | Description |
|---|---|---|
| `AZURE_SEARCH_INDEX_NAME` | `fedex-vectors` | Target search index name |
| `AZURE_OPENAI_EMBEDDING_MODEL` | `text-embedding-3-small` | Embedding model deployment name |
| `AZURE_OPENAI_CHAT_MODEL` | `gpt-5-mini` | Chat model for semantic chunking |
| `AZURE_OPENAI_API_VERSION` | `2024-12-01-preview` | Azure OpenAI API version |
| `CHUNKING_STRATEGY` | `heading_aware` | `heading_aware` (context-aware, default), `hybrid` (heading + semantic), `recursive` (fast), or `semantic` (topic detection) |
| `CHUNK_SIZE` | `1000` | Maximum characters per chunk |
| `CHUNK_OVERLAP` | `100` | Overlapping characters between consecutive chunks |
| `EMBEDDING_BATCH_SIZE` | `50` | Number of texts per embedding API call |
| `DISABLE_SSL_VERIFY` | `false` | Disable SSL verification (dev only) |
| `RETURN_ERROR_DETAIL` | `false` | Include traceback in HTTP error responses (dev only) |

#### Authentication

The app supports four credential resolution paths (tried in order):

1. **Pre-resolved secrets** — `AZURE_CLIENT_ID_VALUE` + `AZURE_CLIENT_SECRET_VALUE` + `AZURE_TENANT_ID`
2. **Key Vault secret names** — `KEY_VAULT_SECRET_NAME_CLIENT_ID` + `KEY_VAULT_SECRET_NAME_CLIENT_SECRET` + vault URL + `AZURE_TENANT_ID`
3. **Direct environment variables** — `AZURE_CLIENT_ID` (must be a valid GUID) + `AZURE_CLIENT_SECRET` + `AZURE_TENANT_ID`
4. **DefaultAzureCredential** — managed identity in Azure, `az login` locally

Key Vault URL can be set via any of: `VAULT_URL`, `KEY_VAULT_URL`, or `AZURE_KEY_VAULT_URL`.

For bulk secret loading at startup, set `KEY_VAULT_SECRET_MAPPING`:

```
KEY_VAULT_SECRET_MAPPING=ENV_NAME=vault-secret-name;OTHER_ENV=other-secret
```

## Running Locally

```bash
func start
```

The function will be available at:

```
POST http://localhost:7071/blob_trigger_vectorcreation
```

## Deployment

### Option A — Azure Functions Core Tools

```bash
func azure functionapp publish <YOUR_FUNCTION_APP_NAME> --python
```

### Option B — Zip Deploy

Zip the project files (ensure `host.json` and `function_app.py` are at the zip root) and deploy via the Azure Portal or CLI:

```bash
az functionapp deployment source config-zip \
  -g <RESOURCE_GROUP> -n <FUNCTION_APP_NAME> --src <zipfile.zip>
```

### Portal / Application Settings

Set these in the Function App's **Configuration > Application settings**:

| Setting | Value |
|---|---|
| `FUNCTIONS_WORKER_RUNTIME` | `python` |
| `FUNCTIONS_EXTENSION_VERSION` | `~4` |
| `AzureWebJobsStorage` | Storage connection string |
| `AzureWebJobsFeatureFlags` | `EnableWorkerIndexing` (Python v2 model) |

Plus the `AZURE_OPENAI_*`, `AZURE_SEARCH_*`, and authentication variables listed above.

### CORS (for Azure Portal testing)

Add `https://portal.azure.com` to the Function App's allowed origins:

```bash
az functionapp cors add -g <RESOURCE_GROUP> -n <FUNCTION_APP_NAME> \
  --allowed-origins https://portal.azure.com
```

## API Reference

### `POST /blob_trigger_vectorcreation`

Event Grid webhook endpoint. Handles subscription validation and blob-created events.

**Request body** — Event Grid envelope (JSON array or single object):

```json
[
  {
    "eventType": "Microsoft.Storage.BlobCreated",
    "data": {
      "url": "https://<account>.blob.core.windows.net/<container>/input-files/<path>"
    }
  }
]
```

**Responses:**

| Status | Description |
|---|---|
| `200 OK` | Events processed successfully |
| `200` + `validationResponse` | Subscription validation handshake |
| `400` | Invalid request body |
| `500` | Processing error (includes error type; traceback if `RETURN_ERROR_DETAIL=true`) |

## Supported File Types

| Extension | Parser | Heading-Aware Enhancement |
|---|---|---|
| `.pdf` | `pypdf` — page-by-page text, tables, annotations, metadata | Heuristic heading injection; repeated header/footer stripping |
| `.docx` | `python-docx` — paragraphs, tables, headers/footers, footnotes, endnotes | Word heading styles detected; bold/heuristic fallback for unstyled docs |
| `.pptx` | `python-pptx` — slide text, speaker notes, table content, group shapes | Slide titles become `## Slide N: Title` headings |
| `.html`, `.htm` | `web_scrapping.py` — full DOM extraction with Playwright | Already heading-enriched by scraper |
| `.json` | Structured key-path extraction | OpenAPI/Swagger-aware (endpoints, schemas); depth-capped for regular JSON |
| `.txt` | Plain UTF-8 decode | Heuristic heading injection (setext, ALL CAPS, title-case) |
| `.md` | Plain UTF-8 decode | Native markdown headings — pass-through |

## Chunking Strategies

All strategies return `ChunkWithMetadata` objects with a uniform interface:

```python
from chunking_strategies import chunk_text, chunks_to_texts_and_metadata

chunks = chunk_text(text, strategy="heading_aware")
for c in chunks:
    print(c.section_heading, c.heading_path, c.content[:80])

# Unpack for the indexing pipeline
content_texts, embedding_texts, metadata_list = chunks_to_texts_and_metadata(chunks)
```

### Heading-Aware (default)

Context-aware chunking that splits on markdown headings (`#`, `##`, `###`, ...) using LangChain's `MarkdownHeaderTextSplitter`, then sub-chunks large sections with `RecursiveCharacterTextSplitter`. Each chunk carries structural metadata:

| Field | Example |
|---|---|
| `section_heading` | `"Authentication"` |
| `parent_heading` | `"API Overview"` |
| `heading_path` | `"API Overview > Authentication"` |
| `chunk_index` | `3` |
| `content_for_embedding` | Heading path prepended to content for better retrieval |

When using heading_aware or hybrid, `file_extraction_enhanced.py` automatically enriches extracted text with markdown headings for formats that don't natively have them:

| Format | Enhancement |
|---|---|
| HTML | Pass-through (already has `#` headings from scraper) |
| DOCX | Detects Word heading styles; falls back to bold/heuristic detection |
| PPTX | Slide titles converted to `## Slide N: Title` |
| PDF | Heuristic heading injection (numbered sections, ALL CAPS, standalone titles); repeated page headers/footers stripped |
| MD | Pass-through (native markdown) |
| TXT | Heuristic heading injection (setext underlines, ALL CAPS, title-case lines) |
| JSON | Key-path based headings; OpenAPI/Swagger-aware extraction for API specs |

### Hybrid (opt-in)

Set `CHUNKING_STRATEGY=hybrid`. Same heading-aware first pass, but uses the embedding-based `SemanticChunker` to sub-chunk large sections so boundaries align with natural topic shifts. Requires an embedding model deployment.

### Semantic (opt-in)

Set `CHUNKING_STRATEGY=semantic`. Text is split into sentences, embedded in overlapping windows, and grouped by cosine similarity. Chunk boundaries are placed at natural topic shifts rather than arbitrary character counts. No heading metadata. Requires an embedding model deployment.

### Recursive (opt-in)

Set `CHUNKING_STRATEGY=recursive`. Fast paragraph/sentence/word boundary splitting using LangChain's `RecursiveCharacterTextSplitter`. No heading metadata, no external API calls. Controlled by `CHUNK_SIZE` (default 1000) and `CHUNK_OVERLAP` (default 100).

## Web Scraper Features

The `web_scrapping.py` module provides comprehensive HTML content extraction:

- **Playwright integration** — launches a headless Chromium browser to render JavaScript-heavy pages (React, Angular, Vue)
- **Tab expansion** — clicks every tab in every tab group and clones panel content (handles React-style unmounting)
- **Accordion/collapsible expansion** — clicks expandable sections and force-reveals hidden panels
- **Cookie banner dismissal** — automatically dismisses common consent overlays (OneTrust, CookieBot, GDPR banners) before content interaction
- **Local file support** — processes local `.html` files through Playwright via `file://` protocol for full JS execution
- **Output cleanup** — filters UI noise (login prompts, blob URLs, JS boolean artifacts, generic button labels)
- **Table handling** — renders tables as aligned markdown with `colspan`/`rowspan` support
- **Graceful fallback** — falls back to plain HTTP requests (URLs) or disk read (files) when Playwright is unavailable

Usage:

```python
from web_scrapping import scrape_webpage

# Live URL (Playwright renders JS, expands tabs/accordions)
result = scrape_webpage("https://example.com")

# Local HTML file (also uses Playwright by default)
result = scrape_webpage("page.html")

# Skip Playwright, use plain HTTP only
result = scrape_webpage("https://example.com", use_playwright=False)

print(result["metadata"])            # dict of meta-tag key/value pairs
print(result["web_page_content"])    # extracted page text
```

## Search Index Schema

The Azure AI Search index includes the following fields:

| Field | Type | Description |
|---|---|---|
| `id` | String (key) | Unique document ID (`filename_chunkIndex`) |
| `content` | String (searchable) | Raw chunk text |
| `contentVector` | Vector (1536-dim) | Embedding of heading-prepended text |
| `source` | String (filterable) | Original blob URL |
| `filename` | String (filterable, searchable) | Original file name |
| `title` | String (filterable, searchable) | Document title from file metadata |
| `created_date` | DateTimeOffset (filterable, sortable) | Document creation date |
| `section_heading` | String (filterable, searchable) | Deepest heading for this chunk (e.g. `"Authentication"`) |
| `parent_heading` | String (filterable, searchable) | Parent heading (e.g. `"API Overview"`) |
| `heading_path` | String (filterable, searchable) | Full breadcrumb (e.g. `"API Overview > Authentication"`) |
| `chunk_index` | Int32 (filterable, sortable) | Chunk position within the document |

Semantic search is configured with `title` as the title field, `content` as the content field, and `filename` as the keywords field.

## Resilience Features

- **Singleton clients** — OpenAI and credential objects are created once and reused across events.
- **Cached index checks** — `ensure_search_index` queries the index only on first call; subsequent events skip the check.
- **Auto-recovery** — if `upload_documents` fails with `ResourceNotFoundError` (index deleted externally), the cache is cleared, the index is recreated, and the upload is retried.
- **Batched embeddings** — texts are sent to the embedding API in configurable batches with exponential-backoff retry.
- **Batched uploads** — documents are uploaded to the search index in batches of 1000.
- **Small chunk merging** — consecutive chunks smaller than `min_chunk_size` (100 chars) from the same section are merged to avoid fragmentation.
- **Heading-enriched embeddings** — for heading_aware/hybrid strategies, the heading path is prepended to chunk text before embedding, improving retrieval when queries reference section context.
