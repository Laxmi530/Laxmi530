"""Optional startup load of secrets from Azure Key Vault into os.environ.

Uses the same credential chain as the rest of the app (DefaultAzureCredential):
managed identity in Azure, or service principal via AZURE_CLIENT_ID /
AZURE_CLIENT_SECRET / AZURE_TENANT_ID when those are set from Key Vault
references or local .env.

Vault URL: ``VAULT_URL`` (preferred), or ``KEY_VAULT_URL`` / ``AZURE_KEY_VAULT_URL``. If none set,
this module does nothing. You can also use Key Vault references directly in
App Settings and skip this module entirely.

Mapping format (single app setting, no secret values in code):
  KEY_VAULT_SECRET_MAPPING=ENV_NAME=vault-secret-name;OTHER_ENV=other-secret

By default, existing non-empty environment variables are not overwritten.
Set ``KEY_VAULT_OVERWRITE_MAPPED=true`` to replace them (e.g. you mistakenly
set ``AZURE_CLIENT_SECRET`` to the secret *name* instead of the value).
"""

from __future__ import annotations

import logging
import os
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


def _parse_mapping(raw: str) -> List[Tuple[str, str]]:
    """Parse a ``KEY_VAULT_SECRET_MAPPING`` string into (env_name, secret_name) pairs.

    The expected format is semicolon-delimited pairs of ``ENV_NAME=vault-secret-name``.
    Blank segments and segments without ``=`` are silently skipped.

    Args:
        raw: The raw mapping string, e.g. ``"FOO=my-secret;BAR=other-secret"``.

    Returns:
        A list of ``(env_name, secret_name)`` tuples ready for Key Vault lookup.
    """
    pairs: List[Tuple[str, str]] = []
    for segment in raw.split(";"):
        segment = segment.strip()
        if not segment or "=" not in segment:
            continue
        env_name, secret_name = segment.split("=", 1)
        env_name, secret_name = env_name.strip(), secret_name.strip()
        if env_name and secret_name:
            pairs.append((env_name, secret_name))
    return pairs


def load_secrets_from_key_vault() -> Dict[str, str]:
    """Fetch secrets from Azure Key Vault and set them as environment variables.

    Reads the ``KEY_VAULT_SECRET_MAPPING`` environment variable to determine
    which Key Vault secrets to fetch and which ``os.environ`` keys to
    populate.  Existing non-empty environment variables are skipped unless
    ``KEY_VAULT_OVERWRITE_MAPPED=true`` is set.

    Authentication uses ``DefaultAzureCredential`` with
    ``exclude_environment_credential=True`` to avoid accidentally using
    ``AZURE_CLIENT_ID``/``AZURE_CLIENT_SECRET`` when they hold secret
    *names* rather than literal credentials.

    Returns
    -------
    Dict[str, str]
        Mapping of ``{env_var_name: vault_secret_name}`` for every
        secret that was successfully loaded.  Empty dict if no vault
        URL is configured or no secrets were applied.
    """
    vault_url = (
        (
            os.getenv("VAULT_URL")
            or os.getenv("KEY_VAULT_URL")
            or os.getenv("AZURE_KEY_VAULT_URL")
            or ""
        )
        .strip()
        .rstrip("/")
    )
    if not vault_url:
        return {}

    overwrite = os.getenv("KEY_VAULT_OVERWRITE_MAPPED", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )

    mapping_raw = (os.getenv("KEY_VAULT_SECRET_MAPPING") or "").strip()
    if not mapping_raw:
        logger.info(
            "Key Vault URL is set but KEY_VAULT_SECRET_MAPPING is empty — skipping Key Vault fetch."
        )
        return {}

    pairs = _parse_mapping(mapping_raw)
    if not pairs:
        logger.warning("KEY_VAULT_SECRET_MAPPING had no valid ENV=secret-name entries.")
        return {}

    from azure.identity import DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient

    # Skip EnvironmentCredential: AZURE_CLIENT_ID/SECRET may be KV secret names, not SP creds.
    credential = DefaultAzureCredential(exclude_environment_credential=True)
    client = SecretClient(vault_url=vault_url, credential=credential)

    applied: Dict[str, str] = {}
    for env_name, secret_name in pairs:
        if not overwrite and (os.getenv(env_name) or "").strip():
            continue
        try:
            bundle = client.get_secret(secret_name)
            if bundle.value is not None:
                os.environ[env_name] = bundle.value
                applied[env_name] = secret_name
                logger.info("Loaded Key Vault secret into environment: %s", env_name)
        except Exception:
            logger.exception(
                "Failed to load Key Vault secret %r for env %s", secret_name, env_name
            )
    return applied
