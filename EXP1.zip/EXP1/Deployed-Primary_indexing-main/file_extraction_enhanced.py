"""Enhanced text extraction that produces heading-enriched markdown output.

Wraps the extractors in ``file_extraction.py`` and adds heading-detection
logic for formats that lack native heading markers, so that
``context_aware_chunking.py`` can split *every* supported format by
document structure.

Format-specific enhancements
-----------------------------
===========  ======================================  ========================
Format       Already has ``#`` headings?             Enhancement
===========  ======================================  ========================
HTML/HTM     Yes (from ``web_scrapping.py``)         Pass-through
DOCX         Yes (from Word heading styles)          Pass-through
PPTX         Slide titles → ``#``                    Slide → ``## Slide N``
PDF          No (flat text from pypdf)               Heuristic heading inject
MD           Usually yes (native markdown)           Pass-through
TXT          No                                      Heuristic heading inject
JSON         No (has keys, not headings)             Key-path → ``#`` sections
===========  ======================================  ========================

Usage::

    from file_extraction_enhanced import extract_text_enhanced

    text = extract_text_enhanced(raw_bytes, "report.pdf")
    # → markdown-formatted text with ``#`` headings injected

    from context_aware_chunking import chunk_text_context_aware
    chunks = chunk_text_context_aware(text, strategy="heading_aware")

Dependencies:
    Same as ``file_extraction.py`` — no new packages required.
"""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
from io import BytesIO
from pathlib import Path, PurePosixPath
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

FileInput = Union[bytes, BytesIO, str, Path]


def _to_bytesio(data: FileInput) -> BytesIO:
    """Normalise *data* into a seeked ``BytesIO`` stream."""
    if isinstance(data, (str, Path)):
        return BytesIO(Path(data).read_bytes())
    if isinstance(data, bytes):
        return BytesIO(data)
    data.seek(0)
    return data


# ======================================================================
#  HTML / HTM — already heading-enriched by web_scrapping.py
# ======================================================================

def _extract_html_enhanced(data: FileInput) -> str:
    """Extract HTML using the existing scraper (output already has ``#`` headings)."""
    from web_scrapping import scrape_webpage

    raw = _to_bytesio(data).read()
    with tempfile.NamedTemporaryFile(mode="wb", suffix=".html", delete=False) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=False)
        return result.get("web_page_content", "")
    finally:
        os.unlink(tmp_path)


# ======================================================================
#  DOCX — already heading-enriched by file_extraction._extract_docx
# ======================================================================

def _extract_docx_enhanced(data: FileInput) -> str:
    """Extract DOCX with heuristic heading detection for unstyled documents.

    First runs the standard extractor (which converts Word heading styles
    to ``#`` markers).  If no headings are found, re-processes the document
    looking for bold standalone paragraphs, short title-case lines, and
    numbered sections — treating them as headings.
    """
    from file_extraction import _extract_docx

    standard_text = _extract_docx(data)

    heading_re = re.compile(r"^#{1,6}\s+", re.MULTILINE)
    if heading_re.search(standard_text):
        return standard_text

    logger.info("No Word heading styles found — applying bold/heuristic heading detection.")
    return _docx_with_bold_headings(data)


def _docx_with_bold_headings(data: FileInput) -> str:
    """Re-extract DOCX content, promoting bold paragraphs to markdown headings.

    Heading detection rules (in priority order):
    1. Paragraphs where ALL runs are bold and the text is short (<120 chars)
       → ``##`` heading (or ``#`` if it's the first heading in the document).
    2. Short bold text (<60 chars) at a list-paragraph level with bold runs
       → ``###`` sub-heading.
    3. Numbered sections (``1.2 Title`` pattern) → ``###`` heading.
    """
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn
    from file_extraction import _iter_docx_block_elements, _docx_table_to_text

    doc = Document(_to_bytesio(data))
    sections: List[str] = []

    cp = doc.core_properties
    meta_lines: List[str] = []
    for attr in ("title", "author", "subject", "category", "keywords"):
        value = getattr(cp, attr, None)
        if value:
            meta_lines.append(f"{attr.capitalize()}: {value}")
    if meta_lines:
        sections.append("\n".join(meta_lines))

    header_texts: List[str] = []
    footer_texts: List[str] = []
    for section in doc.sections:
        for header in (section.header, section.first_page_header):
            if header and header.is_linked_to_previous is False:
                text = "\n".join(p.text for p in header.paragraphs if p.text.strip())
                if text.strip() and text not in header_texts:
                    header_texts.append(text)
        for footer in (section.footer, section.first_page_footer):
            if footer and footer.is_linked_to_previous is False:
                text = "\n".join(p.text for p in footer.paragraphs if p.text.strip())
                if text.strip() and text not in footer_texts:
                    footer_texts.append(text)

    if header_texts:
        sections.append("[Header]\n" + "\n".join(header_texts) + "\n[/Header]")

    body_parts: List[str] = []
    first_heading_seen = False

    for kind, element in _iter_docx_block_elements(doc.element.body):
        if kind == "paragraph":
            para = Paragraph(element, doc)
            text = para.text.strip()
            if not text:
                continue

            style_name = (para.style.name or "").lower() if para.style else ""

            if style_name.startswith("heading"):
                level = "".join(c for c in style_name if c.isdigit()) or "1"
                body_parts.append(f"\n{'#' * int(level)} {text}")
                first_heading_seen = True
                continue

            heading_level = _classify_docx_paragraph(para, text, style_name, first_heading_seen)
            if heading_level is not None:
                body_parts.append(f"\n{'#' * heading_level} {text}")
                first_heading_seen = True
            elif style_name.startswith(("list", "bullet", "toc")):
                body_parts.append(f"• {text}")
            else:
                body_parts.append(text)

        elif kind == "table":
            tbl = Table(element, doc)
            table_lines = _docx_table_to_text(tbl)
            if table_lines:
                body_parts.append(table_lines)

    if body_parts:
        sections.append("\n".join(body_parts))

    if footer_texts:
        sections.append("[Footer]\n" + "\n".join(footer_texts) + "\n[/Footer]")

    return "\n\n".join(sections)


def _classify_docx_paragraph(
    para, text: str, style_name: str, first_heading_seen: bool
) -> Optional[int]:
    """Return heading level (1-3) if a paragraph looks like a heading, else None.

    Rules:
    - All runs bold + short text (<120 chars) → level 1 (first) or 2 (subsequent)
    - Bold text in list paragraph style + short (<60 chars) → level 3
    - Numbered section pattern (``1.2 Title``) → level 3
    """
    if not text or len(text) > 120:
        return None

    runs_with_text = [r for r in para.runs if r.text.strip()]
    if not runs_with_text:
        return None

    all_bold = all(r.bold for r in runs_with_text)

    if all_bold and len(text) < 120:
        if text.endswith((".", ",", ";", "?")):
            if len(text) > 60:
                return None
        if "list" in style_name and len(text) < 60:
            return 3
        if not first_heading_seen:
            return 1
        return 2

    numbered = re.match(r"^\d+\.\s+[A-Z]", text)
    if numbered and len(text) < 80:
        return 3

    return None


# ======================================================================
#  PPTX — enhanced: slide structure → markdown headings
# ======================================================================

def _extract_pptx_enhanced(data: FileInput) -> str:
    """Extract PPTX with slide-level heading structure.

    Each slide becomes a ``## Slide N: <title>`` heading so that
    context-aware chunking can split by slide and carry the slide
    title as metadata.
    """
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    sections: List[str] = []

    try:
        cp = prs.core_properties
        meta_lines: List[str] = []
        for attr in ("title", "author", "subject", "category", "keywords"):
            value = getattr(cp, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))
    except Exception:
        pass

    pres_title = ""
    try:
        pres_title = prs.core_properties.title or ""
    except Exception:
        pass
    if pres_title:
        sections.append(f"# {pres_title.strip()}")

    for slide_num, slide in enumerate(prs.slides, start=1):
        slide_title = ""
        if slide.shapes.title and slide.shapes.title.text.strip():
            slide_title = slide.shapes.title.text.strip()

        heading = f"## Slide {slide_num}: {slide_title}" if slide_title else f"## Slide {slide_num}"
        slide_parts: List[str] = [heading]

        for shape in slide.shapes:
            text = _pptx_shape_text_enhanced(shape)
            if text:
                slide_parts.append(text)

        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                slide_parts.append(f"\n**Speaker Notes:** {notes}")

        if len(slide_parts) > 1:
            sections.append("\n".join(slide_parts))

    return "\n\n".join(sections)


def _pptx_shape_text_enhanced(shape) -> str:
    """Extract text from a PPTX shape (same logic as file_extraction)."""
    parts: List[str] = []

    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if text:
                level = para.level or 0
                if level > 0:
                    parts.append(f"{'  ' * level}• {text}")
                else:
                    parts.append(text)

    if shape.has_table:
        table = shape.table
        rows_data: List[List[str]] = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows_data.append(cells)
        if rows_data:
            max_cols = max(len(r) for r in rows_data)
            col_widths = [3] * max_cols
            for row in rows_data:
                for i, cell in enumerate(row):
                    if i < max_cols:
                        col_widths[i] = max(col_widths[i], len(cell))
            lines: List[str] = []
            for idx, row in enumerate(rows_data):
                padded = []
                for i in range(max_cols):
                    val = row[i] if i < len(row) else ""
                    padded.append(val.ljust(col_widths[i]))
                lines.append("| " + " | ".join(padded) + " |")
                if idx == 0:
                    lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")
            parts.append("\n".join(lines))

    if shape.shape_type is not None:
        try:
            from pptx.enum.shapes import MSO_SHAPE_TYPE
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for child_shape in shape.shapes:
                    child_text = _pptx_shape_text_enhanced(child_shape)
                    if child_text:
                        parts.append(child_text)
        except Exception:
            pass

    return "\n".join(parts)


# ======================================================================
#  PDF — heuristic heading detection
# ======================================================================

_PDF_HEADING_PATTERNS = [
    # "1. Title", "1.2 Title", "1.2.3 Title"
    re.compile(r"^(\d+(?:\.\d+)*)\s+([A-Z][\w\s\-:,]+)$"),
    # ALL CAPS lines (likely section titles)
    re.compile(r"^([A-Z][A-Z\s\-:,]{4,})$"),
    # "CHAPTER 1: Title", "Section 2 — Title"
    re.compile(r"^(?:CHAPTER|SECTION|PART|APPENDIX)\s+\w+[\s:—–\-]+(.+)$", re.IGNORECASE),
]

_ROMAN_NUMERAL_RE = re.compile(
    r"^((?:I{1,3}|IV|VI{0,3}|IX|XI{0,3}|XIV|XV|XVI{0,3}|XIX|XX))\.\s+(.+)$",
    re.IGNORECASE,
)


def _classify_pdf_line(line: str, prev_blank: bool, next_blank: bool) -> Optional[int]:
    """Return a heading level (1-3) if *line* looks like a heading, else None.

    Heuristics (in priority order):
    - Numbered sections (``1.2.3 Title``) → depth-based level (always matched)
    - ``CHAPTER/SECTION/PART`` prefix → level 1 (always matched)
    - ALL CAPS short lines preceded by blank → level 1
    - Short title-case lines (2-8 words, <60 chars) preceded by blank → level 2
      (blank after is preferred but not required for very short titles)
    """
    stripped = line.strip()
    if not stripped or len(stripped) < 3:
        return None

    for pattern in _PDF_HEADING_PATTERNS:
        m = pattern.match(stripped)
        if m:
            groups = m.groups()
            if groups and "." in (groups[0] or ""):
                depth = groups[0].count(".") + 1
                return min(depth, 4)
            return 1

    m = _ROMAN_NUMERAL_RE.match(stripped)
    if m:
        return 2

    if not prev_blank:
        return None

    if len(stripped) >= 80:
        return None

    if stripped.endswith((".", ",", ";", ":")):
        return None

    if stripped.startswith(("•", "-", "*", "|", "(", "\"", "'")):
        return None

    if not stripped[0].isupper():
        return None

    words = stripped.split()
    word_count = len(words)
    if word_count < 2:
        return None

    last_word = words[-1].lower().rstrip(".,;:?!")
    if last_word in ("a", "an", "the", "of", "in", "to", "for", "and", "or", "is", "are", "has"):
        return None

    all_caps = stripped == stripped.upper() and any(c.isalpha() for c in stripped)
    if all_caps and next_blank:
        return 1

    alpha_words = [w for w in words if any(c.isalpha() for c in w)]
    alpha_word_count = len(alpha_words)

    if alpha_word_count <= 5 and len(stripped) < 50:
        return 2

    if next_blank and alpha_word_count <= 8 and len(stripped) < 70:
        return 2

    return None


def _next_nonblank(lines: List[str], start: int) -> str:
    """Return the stripped text of the next non-blank line from *start*, or ''."""
    for j in range(start, len(lines)):
        s = lines[j].strip()
        if s:
            return s
    return ""


def _detect_repeated_lines(pages_lines: List[List[str]], threshold: float = 0.5) -> set:
    """Identify lines that repeat across many pages (headers/footers).

    Checks the first and last few lines of each page.  Any line
    appearing on more than *threshold* fraction of pages is considered
    a repeating header or footer and should be stripped.

    Returns a set of normalised line strings to filter out.
    """
    from collections import Counter

    if len(pages_lines) < 3:
        return set()

    candidates: Counter = Counter()
    check_positions = 3

    for page_lines in pages_lines:
        seen_on_page: set = set()
        top = page_lines[:check_positions]
        bottom = page_lines[-check_positions:] if len(page_lines) > check_positions else []
        for line in top + bottom:
            norm = line.strip()
            if norm and norm not in seen_on_page:
                seen_on_page.add(norm)
                candidates[norm] += 1

    min_count = max(3, int(len(pages_lines) * threshold))
    return {line for line, count in candidates.items() if count >= min_count}


def _extract_pdf_enhanced(data: FileInput) -> str:
    """Extract PDF text with heuristic heading injection.

    Two-pass approach:
    1. Extract all pages and detect repeating headers/footers
       (lines appearing on most pages at top/bottom positions).
    2. Strip the repeated lines, then apply heading heuristics to the
       cleaned text.

    Heading hierarchy is assigned by pattern type:
    - Numbered sections like ``1.2.3 Title`` get depth-based levels.
    - ALL CAPS short lines get level 1.
    - ``CHAPTER/SECTION`` prefixed lines get level 1.
    - Other short standalone lines get level 2.
    """
    from pypdf import PdfReader

    reader = PdfReader(_to_bytesio(data))
    sections: List[str] = []

    meta = reader.metadata
    if meta:
        meta_lines: List[str] = []
        for attr in ("title", "author", "subject", "creator"):
            value = getattr(meta, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))

    all_pages_lines: List[List[str]] = []
    all_pages_annotations: List[List[str]] = []

    for page_num, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text() or ""
        if not page_text.strip():
            all_pages_lines.append([])
            all_pages_annotations.append([])
            continue

        lines = page_text.split("\n")
        all_pages_lines.append(lines)

        annotations: List[str] = []
        if page.get("/Annots"):
            for annot_ref in page["/Annots"]:
                try:
                    annot = annot_ref.get_object()
                    contents = annot.get("/Contents")
                    if contents and str(contents).strip():
                        annotations.append(f"[Annotation] {contents}")
                except Exception:
                    pass
        all_pages_annotations.append(annotations)

    repeated = _detect_repeated_lines(all_pages_lines)
    if repeated:
        logger.info(
            "PDF: detected %d repeating header/footer line(s) — stripping.",
            len(repeated),
        )

    for page_num, (lines, annotations) in enumerate(
        zip(all_pages_lines, all_pages_annotations), start=1
    ):
        if not lines:
            continue

        filtered = [l for l in lines if l.strip() not in repeated]
        if not any(l.strip() for l in filtered):
            continue

        enriched_lines: List[str] = []
        for i, line in enumerate(filtered):
            prev_blank = (i == 0) or (not filtered[i - 1].strip())
            next_blank = (i == len(filtered) - 1) or (
                not filtered[i + 1].strip() if i + 1 < len(filtered) else True
            )
            level = _classify_pdf_line(line, prev_blank, next_blank)
            if level is not None:
                next_content = _next_nonblank(filtered, i + 1)
                if next_content and next_content[0].islower():
                    enriched_lines.append(line)
                else:
                    enriched_lines.append(f"\n{'#' * level} {line.strip()}")
            else:
                enriched_lines.append(line)

        page_content = "\n".join(enriched_lines)
        if annotations:
            page_content += "\n" + "\n".join(annotations)
        sections.append(page_content)

    return "\n\n".join(sections)


# ======================================================================
#  MD — native markdown, pass-through
# ======================================================================

def _extract_md_enhanced(data: FileInput) -> str:
    """Markdown files already have heading markers — return as-is."""
    stream = _to_bytesio(data)
    return stream.read().decode("utf-8", errors="ignore")


# ======================================================================
#  TXT — heuristic heading detection
# ======================================================================

_TXT_UNDERLINE_RE = re.compile(r"^[=]{3,}$|^[-]{3,}$")


def _extract_txt_enhanced(data: FileInput) -> str:
    """Extract plain text with heuristic heading injection.

    Detects headings using:
    - Setext-style underlines (``===`` under a line → h1, ``---`` → h2)
    - ALL CAPS standalone lines surrounded by blanks → h1
    - Numbered sections (``1.2 Title``) → h2/h3
    - Short title-case lines surrounded by blanks → h3
    """
    stream = _to_bytesio(data)
    text = stream.read().decode("utf-8", errors="ignore")
    lines = text.split("\n")
    result: List[str] = []

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Setext-style: line followed by === or ---
        if i + 1 < len(lines) and stripped and _TXT_UNDERLINE_RE.match(lines[i + 1].strip()):
            underline = lines[i + 1].strip()
            if underline[0] == "=":
                result.append(f"\n# {stripped}")
            else:
                result.append(f"\n## {stripped}")
            i += 2
            continue

        prev_blank = (i == 0) or (not lines[i - 1].strip())
        next_blank = (i == len(lines) - 1) or (
            not lines[i + 1].strip() if i + 1 < len(lines) else True
        )

        if stripped:
            level = _classify_txt_line(stripped, prev_blank, next_blank)
            if level is not None:
                result.append(f"\n{'#' * level} {stripped}")
            else:
                result.append(line)
        else:
            result.append(line)

        i += 1

    return "\n".join(result)


def _classify_txt_line(stripped: str, prev_blank: bool, next_blank: bool) -> Optional[int]:
    """Return heading level if *stripped* looks like a heading in a .txt file."""
    if len(stripped) < 3:
        return None

    # Numbered sections
    m = re.match(r"^(\d+(?:\.\d+)*)\s+([A-Z][\w\s\-:,]+)$", stripped)
    if m:
        depth = m.group(1).count(".") + 1
        return min(depth + 1, 4)

    if not prev_blank or not next_blank:
        return None

    if stripped.startswith(("•", "-", "*", "|")) or stripped.endswith((".", ",", ";")):
        return None

    # ALL CAPS
    if (
        len(stripped) < 80
        and stripped == stripped.upper()
        and any(c.isalpha() for c in stripped)
    ):
        return 1

    # Short title-case line
    if len(stripped) < 60 and stripped[0].isupper():
        word_count = len(stripped.split())
        if word_count <= 8:
            return 3

    return None


# ======================================================================
#  JSON — key-path based heading injection (Swagger/OpenAPI aware)
# ======================================================================

def _is_scalar(value) -> bool:
    return not isinstance(value, (dict, list))


def _scalar_to_str(value) -> Optional[str]:
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else None
    return None


def _is_openapi(obj: dict) -> bool:
    """Return True if *obj* looks like an OpenAPI / Swagger spec."""
    return isinstance(obj, dict) and (
        "openapi" in obj or "swagger" in obj or (
            "paths" in obj and ("info" in obj or "components" in obj)
        )
    )


def _extract_json_enhanced(data: FileInput) -> str:
    """Extract JSON with structure-aware heading injection.

    Detects OpenAPI/Swagger files and uses a specialised extractor that
    groups endpoints, schemas, and parameters into meaningful sections
    instead of creating a heading for every nested key.

    For regular JSON, top-level keys become ``#`` headings and nested
    objects become ``##``/``###`` (capped at depth 3 to avoid
    over-fragmentation).
    """
    stream = _to_bytesio(data)
    raw_text = stream.read().decode("utf-8", errors="ignore")
    try:
        obj = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        logger.warning("Invalid JSON: %s", exc)
        return ""

    if isinstance(obj, dict) and _is_openapi(obj):
        logger.info("Detected OpenAPI/Swagger format — using specialised extractor.")
        return _openapi_to_markdown(obj)

    lines: List[str] = []
    _json_to_markdown(obj, lines, depth=0, max_heading_depth=3)
    return "\n".join(lines)


def _openapi_to_markdown(spec: dict) -> str:
    """Convert an OpenAPI/Swagger spec into well-structured markdown.

    Produces sections for:
    - API info (title, description, version, servers)
    - Tags
    - Each endpoint (grouped by path + method)
    - Each schema/model in components (all properties rendered inline)
    """
    lines: List[str] = []

    # --- Info ---
    info = spec.get("info", {})
    api_title = info.get("title", "API")
    lines.append(f"# {api_title}")
    if info.get("description"):
        lines.append(info["description"])
    if info.get("version"):
        lines.append(f"Version: {info['version']}")
    contact = info.get("contact", {})
    if contact.get("name"):
        lines.append(f"Contact: {contact['name']}")

    # --- Servers ---
    servers = spec.get("servers", [])
    if servers:
        lines.append("\n## Servers")
        for srv in servers:
            url = srv.get("url", "")
            desc = srv.get("description", "")
            lines.append(f"- {url}" + (f" ({desc})" if desc else ""))

    # --- Tags ---
    tags = spec.get("tags", [])
    if tags:
        lines.append("\n## Tags")
        for tag in tags:
            name = tag.get("name", "")
            desc = tag.get("description", "")
            lines.append(f"- **{name}**: {desc}" if desc else f"- **{name}**")

    # --- Paths (endpoints) ---
    paths = spec.get("paths", {})
    if paths:
        lines.append("\n## Endpoints")
        for path, methods in paths.items():
            if not isinstance(methods, dict):
                continue
            for method, operation in methods.items():
                if method.startswith("x-") or not isinstance(operation, dict):
                    continue

                summary = operation.get("summary", "")
                op_id = operation.get("operationId", "")
                description = operation.get("description", "")
                op_tags = operation.get("tags", [])

                heading = f"{method.upper()} {path}"
                if summary:
                    heading += f" - {summary}"
                lines.append(f"\n### {heading}")

                if op_id:
                    lines.append(f"Operation ID: {op_id}")
                if op_tags:
                    lines.append(f"Tags: {', '.join(op_tags)}")
                if description:
                    lines.append(description)

                # Parameters
                params = operation.get("parameters", [])
                if params:
                    lines.append("\n**Parameters:**")
                    for param in params:
                        if not isinstance(param, dict):
                            continue
                        pname = param.get("name", "")
                        pin = param.get("in", "")
                        pdesc = param.get("description", "")
                        preq = "required" if param.get("required") else "optional"
                        ptype = ""
                        schema = param.get("schema", {})
                        if isinstance(schema, dict):
                            ptype = schema.get("type", "")
                        line = f"- `{pname}` ({pin}, {ptype}, {preq})"
                        if pdesc:
                            line += f": {pdesc}"
                        lines.append(line)

                # Request body
                req_body = operation.get("requestBody", {})
                if isinstance(req_body, dict):
                    rb_desc = req_body.get("description", "")
                    if rb_desc:
                        lines.append(f"\n**Request Body:** {rb_desc}")
                    rb_content = req_body.get("content", {})
                    if isinstance(rb_content, dict):
                        for content_type, media in rb_content.items():
                            if isinstance(media, dict) and "schema" in media:
                                ref = _resolve_schema_ref(media["schema"])
                                if ref:
                                    lines.append(f"Content-Type: {content_type}, Schema: {ref}")

                # Responses
                responses = operation.get("responses", {})
                if isinstance(responses, dict):
                    lines.append("\n**Responses:**")
                    for status_code, resp in responses.items():
                        if not isinstance(resp, dict):
                            continue
                        rdesc = resp.get("description", "")
                        line = f"- {status_code}: {rdesc}" if rdesc else f"- {status_code}"
                        resp_content = resp.get("content", {})
                        if isinstance(resp_content, dict):
                            for ct, media in resp_content.items():
                                if isinstance(media, dict) and "schema" in media:
                                    ref = _resolve_schema_ref(media["schema"])
                                    if ref:
                                        line += f" (Schema: {ref})"
                        lines.append(line)

    # --- Components / Schemas ---
    components = spec.get("components", {})
    schemas = components.get("schemas", {})
    if not schemas:
        schemas = spec.get("definitions", {})

    if schemas:
        lines.append("\n## Schemas")
        for schema_name, schema_def in schemas.items():
            if not isinstance(schema_def, dict):
                continue
            lines.append(f"\n### {schema_name}")

            sdesc = schema_def.get("description", "")
            stype = schema_def.get("type", "")
            if sdesc:
                lines.append(sdesc)
            if stype:
                lines.append(f"Type: {stype}")

            required_fields = set(schema_def.get("required", []))

            # Render properties inline (no heading per property)
            properties = schema_def.get("properties", {})
            if properties:
                lines.append("\n**Properties:**")
                for prop_name, prop_def in properties.items():
                    if not isinstance(prop_def, dict):
                        lines.append(f"- `{prop_name}`")
                        continue
                    ptype = prop_def.get("type", "")
                    pdesc = prop_def.get("description", "")
                    penum = prop_def.get("enum", [])
                    pref = _resolve_schema_ref(prop_def)
                    req_marker = " (required)" if prop_name in required_fields else ""

                    parts = [f"- `{prop_name}`"]
                    type_info = ptype or pref or ""
                    if type_info:
                        parts.append(f"({type_info}{req_marker})")
                    elif req_marker:
                        parts.append(f"({req_marker.strip()})")
                    if pdesc:
                        parts.append(f": {pdesc}")
                    if penum:
                        parts.append(f" [enum: {', '.join(str(e) for e in penum[:10])}]")
                    lines.append(" ".join(parts))

            # allOf / oneOf / anyOf
            for compose_key in ("allOf", "oneOf", "anyOf"):
                compose_list = schema_def.get(compose_key, [])
                if compose_list:
                    refs = [_resolve_schema_ref(item) for item in compose_list if isinstance(item, dict)]
                    refs = [r for r in refs if r]
                    if refs:
                        lines.append(f"{compose_key}: {', '.join(refs)}")

    return "\n".join(lines)


def _resolve_schema_ref(schema: dict) -> str:
    """Extract a readable schema reference from a ``$ref`` or type."""
    if not isinstance(schema, dict):
        return ""
    ref = schema.get("$ref", "")
    if ref:
        return ref.split("/")[-1]
    stype = schema.get("type", "")
    if stype == "array":
        items = schema.get("items", {})
        if isinstance(items, dict):
            item_ref = _resolve_schema_ref(items)
            return f"array[{item_ref}]" if item_ref else "array"
    return stype


def _json_to_markdown(obj, lines: List[str], depth: int, max_heading_depth: int = 3) -> None:
    """Recursively convert a JSON structure into markdown with headings.

    Headings are only created down to *max_heading_depth* levels.
    Below that, nested content is rendered as indented key-value text
    to prevent over-fragmentation.
    """
    heading_level = min(depth + 1, 4)

    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, dict):
                if depth < max_heading_depth:
                    lines.append(f"\n{'#' * heading_level} {key}")
                    _json_to_markdown(value, lines, depth + 1, max_heading_depth)
                else:
                    _flatten_dict_inline(key, value, lines, indent=0)
            elif isinstance(value, list):
                if depth < max_heading_depth:
                    lines.append(f"\n{'#' * heading_level} {key}")
                    _json_to_markdown(value, lines, depth + 1, max_heading_depth)
                else:
                    _flatten_list_inline(key, value, lines, indent=0)
            else:
                text = _scalar_to_str(value)
                if text is not None:
                    lines.append(f"{key}: {text}")
                else:
                    lines.append(key)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, dict):
                item_label = _get_json_item_label(item, i)
                if depth < max_heading_depth:
                    lines.append(f"\n{'#' * heading_level} {item_label}")
                    _json_to_markdown(item, lines, depth + 1, max_heading_depth)
                else:
                    lines.append(f"\n**{item_label}**")
                    _flatten_dict_inline("", item, lines, indent=0)
            elif _is_scalar(item):
                text = _scalar_to_str(item)
                if text:
                    lines.append(f"- {text}")
            else:
                _json_to_markdown(item, lines, depth + 1, max_heading_depth)


def _flatten_dict_inline(parent_key: str, obj: dict, lines: List[str], indent: int) -> None:
    """Render a dict as indented key-value lines (no headings)."""
    prefix = "  " * indent
    for key, value in obj.items():
        if _is_scalar(value):
            text = _scalar_to_str(value)
            if text is not None:
                lines.append(f"{prefix}{key}: {text}")
        elif isinstance(value, list) and all(_is_scalar(v) for v in value):
            items = [_scalar_to_str(v) for v in value if _scalar_to_str(v)]
            lines.append(f"{prefix}{key}: {', '.join(items)}")
        elif isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            _flatten_dict_inline("", value, lines, indent + 1)
        elif isinstance(value, list):
            _flatten_list_inline(key, value, lines, indent)


def _flatten_list_inline(key: str, items: list, lines: List[str], indent: int) -> None:
    """Render a list as indented bullet lines (no headings)."""
    prefix = "  " * indent
    if key:
        lines.append(f"{prefix}{key}:")
    for item in items:
        if _is_scalar(item):
            text = _scalar_to_str(item)
            if text:
                lines.append(f"{prefix}- {text}")
        elif isinstance(item, dict):
            label = _get_json_item_label(item, 0)
            lines.append(f"{prefix}- {label}")
            _flatten_dict_inline("", item, lines, indent + 1)


def _get_json_item_label(item: dict, index: int) -> str:
    """Generate a label for a JSON array item (uses 'name', 'title', 'id', or index)."""
    for key in ("name", "title", "label", "id", "key", "type", "operationId"):
        val = item.get(key)
        if val and isinstance(val, str):
            return val.strip()
    return f"Item {index + 1}"


# ======================================================================
#  Public API
# ======================================================================

_ENHANCED_EXTRACTORS: Dict[str, callable] = {
    ".pdf": _extract_pdf_enhanced,
    ".docx": _extract_docx_enhanced,
    ".pptx": _extract_pptx_enhanced,
    ".json": _extract_json_enhanced,
    ".txt": _extract_txt_enhanced,
    ".md": _extract_md_enhanced,
    ".html": _extract_html_enhanced,
    ".htm": _extract_html_enhanced,
}

_SUPPORTED_EXTENSIONS = set(_ENHANCED_EXTRACTORS.keys())


def extract_text_enhanced(data: FileInput, filename: str) -> str:
    """Extract text from *data* with heading enrichment for context-aware chunking.

    Works identically to ``file_extraction.extract_text`` but enriches
    the output with markdown heading markers (``#``, ``##``, …) for
    formats that don't natively produce them (PDF, TXT, JSON).

    Parameters
    ----------
    data : bytes | BytesIO | str | Path
        Raw file bytes or a file-system path.
    filename : str
        Original file name (extension is used to select the extractor).

    Returns
    -------
    str
        Heading-enriched text ready for ``context_aware_chunking``.

    Raises
    ------
    ValueError
        If the file extension is not supported.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _ENHANCED_EXTRACTORS.get(ext)
    if extractor is None:
        raise ValueError(
            f"Unsupported file type '{ext}'. "
            f"Supported: {', '.join(sorted(_SUPPORTED_EXTENSIONS))}"
        )
    logger.info("Enhanced extraction from '%s' (type=%s)", filename, ext)
    return extractor(data)


def supported_extensions_enhanced() -> set:
    """Return the set of file extensions supported by the enhanced extractor."""
    return set(_SUPPORTED_EXTENSIONS)


# ======================================================================
#  Standalone test / demo
# ======================================================================

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if len(sys.argv) < 2:
        print("Usage: python file_extraction_enhanced.py <file_path>")
        print()
        print("Supported formats: " + ", ".join(sorted(_SUPPORTED_EXTENSIONS)))
        print()
        print("Examples:")
        print("  python file_extraction_enhanced.py report.pdf")
        print("  python file_extraction_enhanced.py document.docx")
        print("  python file_extraction_enhanced.py data.json")
        print("  python file_extraction_enhanced.py readme.md")
        print("  python file_extraction_enhanced.py notes.txt")
        print("  python file_extraction_enhanced.py page.html")
        sys.exit(1)

    file_path = Path(sys.argv[1])
    if not file_path.exists():
        print(f"File not found: {file_path}")
        sys.exit(1)

    text = extract_text_enhanced(file_path, file_path.name)

    print(f"File: {file_path.name}")
    print(f"Text length: {len(text):,} chars")
    print("=" * 70)

    # Show heading structure
    heading_re = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
    headings = heading_re.findall(text)
    if headings:
        print(f"\nDetected {len(headings)} headings:")
        for hashes, title in headings:
            indent = "  " * (len(hashes) - 1)
            print(f"  {indent}{hashes} {title}")
        print()
    else:
        print("\nNo markdown headings detected in output.\n")

    print("=" * 70)
    print("EXTRACTED TEXT (first 3000 chars):")
    print("=" * 70)
    print(text[:3000])
    if len(text) > 3000:
        print(f"\n... ({len(text) - 3000:,} more characters)")

    # If context_aware_chunking is available, demo the full pipeline
    try:
        from chunking_strategies import chunk_text

        print("\n" + "=" * 70)
        print("CONTEXT-AWARE CHUNKING DEMO:")
        print("=" * 70)

        chunks = chunk_text(
            text,
            strategy="heading_aware",
            chunk_size=1000,
            chunk_overlap=100,
            source_metadata={"filename": file_path.name},
        )

        print(f"\nTotal chunks: {len(chunks)}\n")
        for i, chunk in enumerate(chunks[:10]):
            print(f"  Chunk {i}: [{len(chunk.content)} chars] "
                  f"path='{chunk.heading_path}' "
                  f"section='{chunk.section_heading}'")
            preview = chunk.content[:120].replace("\n", "\\n")
            print(f"    > {preview}...")
            print()

        if len(chunks) > 10:
            print(f"  ... and {len(chunks) - 10} more chunks")

    except ImportError:
        print("\n(Skipping chunking demo — context_aware_chunking.py not available)")
