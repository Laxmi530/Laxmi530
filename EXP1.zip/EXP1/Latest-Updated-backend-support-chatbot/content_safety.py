"""Azure AI Content Safety integration for input/output filtering.

Provides text analysis via the Azure AI Content Safety service to detect
harmful content across four categories: Hate, SelfHarm, Sexual, and Violence.

Controlled by the ``CONTENT_SAFETY_ENABLED`` environment variable (``true``
to enable, anything else or unset to disable).

Configuration (environment variables / ``local.settings.json`` Values):
    CONTENT_SAFETY_ENABLED              : ``true`` to enable; default disabled.
    AZURE_CONTENT_SAFETY_ENDPOINT       : Content Safety resource endpoint URL.
    AZURE_CONTENT_SAFETY_KEY            : (Optional) API key.  When omitted the
                                          module authenticates with Entra ID via
                                          ``azure_sp_common.get_azure_token_credential``.
    CONTENT_SAFETY_SEVERITY_THRESHOLD   : Minimum severity (0-6) to flag as
                                          unsafe; default ``2``.

Usage from ``function_app.py``::

    from content_safety import analyse_input, analyse_output

    # Before processing a user query:
    input_result = analyse_input(query)
    if not input_result["safe"]:
        return func.HttpResponse(json.dumps(input_result), ...)

    # After generating the LLM answer:
    output_result = analyse_output(answer)
    if not output_result["safe"]:
        answer = output_result["filtered_response"]
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_content_safety_client = None

UNSAFE_INPUT_MESSAGE = (
    "I'm sorry, but your message was flagged by our content safety filters. "
    "Please rephrase your question and try again."
)

UNSAFE_OUTPUT_MESSAGE = (
    "I'm sorry, but the generated response was flagged by our content safety "
    "filters. Please try rephrasing your question."
)


def is_enabled() -> bool:
    """Return ``True`` when content safety filtering is active."""
    return os.environ.get("CONTENT_SAFETY_ENABLED", "").strip().lower() == "true"


def _get_client():
    """Lazy singleton for the Content Safety client.

    Uses an API key when ``AZURE_CONTENT_SAFETY_KEY`` is set; otherwise falls
    back to Entra ID (managed identity / service principal) via the shared
    ``azure_sp_common`` credential helper, consistent with the rest of the app.
    """
    global _content_safety_client
    if _content_safety_client is not None:
        return _content_safety_client

    from azure.ai.contentsafety import ContentSafetyClient
    from azure.core.credentials import AzureKeyCredential

    endpoint = os.environ.get("AZURE_CONTENT_SAFETY_ENDPOINT", "").strip()
    if not endpoint:
        raise ValueError(
            "AZURE_CONTENT_SAFETY_ENDPOINT must be set when CONTENT_SAFETY_ENABLED=true."
        )

    api_key = os.environ.get("AZURE_CONTENT_SAFETY_KEY", "").strip()
    if api_key:
        credential = AzureKeyCredential(api_key)
    else:
        from azure_sp_common import get_azure_token_credential
        credential = get_azure_token_credential()

    _content_safety_client = ContentSafetyClient(endpoint, credential)
    logger.info(
        "ContentSafety client initialised (endpoint=%s, auth=%s).",
        endpoint,
        "api_key" if api_key else "entra_id",
    )
    return _content_safety_client


def _severity_threshold() -> int:
    """Configurable severity cut-off (0-6). Categories at or above this level are flagged."""
    return int(os.environ.get("CONTENT_SAFETY_SEVERITY_THRESHOLD", "2"))


def _analyse_text(text: str) -> dict[str, Any]:
    """Call the Content Safety ``analyze_text`` API and return a structured result.

    Returns a dict with:
        safe (bool)            : True when all categories are below the threshold.
        flagged_categories     : List of dicts with category name and severity for
                                 every category that met or exceeded the threshold.
        details                : Full per-category severity breakdown.
    """
    from azure.ai.contentsafety.models import AnalyzeTextOptions

    client = _get_client()
    threshold = _severity_threshold()

    request = AnalyzeTextOptions(text=text)

    try:
        response = client.analyze_text(request)
    except Exception:
        logger.exception("Content Safety API call failed")
        raise

    flagged: list[dict[str, Any]] = []
    details: dict[str, int] = {}

    for item in response.categories_analysis:
        severity = item.severity or 0
        details[item.category.value if hasattr(item.category, "value") else str(item.category)] = severity
        if severity >= threshold:
            flagged.append({
                "category": item.category.value if hasattr(item.category, "value") else str(item.category),
                "severity": severity,
            })

    safe = len(flagged) == 0

    if not safe:
        logger.warning(
            "ContentSafety|flagged text (threshold=%d): %s",
            threshold,
            flagged,
        )

    return {"safe": safe, "flagged_categories": flagged, "details": details, "threshold": threshold}


def analyse_input(text: str) -> dict[str, Any]:
    """Analyse user input for harmful content.

    When content safety is disabled or the text is empty, returns
    ``{"safe": True}`` immediately.

    Returns a dict with ``safe``, ``flagged_categories``, ``details``, and
    ``message`` (a user-facing explanation when the input is unsafe).
    """
    if not is_enabled():
        logger.debug("ContentSafety|skipped (disabled) for input check")
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": False}

    if not text or not text.strip():
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": True}

    try:
        result = _analyse_text(text)
        result["enabled"] = True
        if result["safe"]:
            logger.info(
                "ContentSafety|input passed (threshold=%d): %s",
                result.get("threshold", _severity_threshold()),
                result.get("details"),
            )
        else:
            result["message"] = UNSAFE_INPUT_MESSAGE
        return result
    except Exception as exc:
        logger.error("Content safety input check failed — allowing through: %s", exc)
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": True, "error": str(exc)}


def analyse_output(text: str) -> dict[str, Any]:
    """Analyse LLM output for harmful content before returning it to the user.

    When content safety is disabled or the text is empty, returns
    ``{"safe": True}`` immediately.

    Returns a dict with ``safe``, ``flagged_categories``, ``details``,
    ``filtered_response`` (a safe replacement message when flagged), and
    ``original_response`` (the raw LLM output, for logging / auditing).
    """
    if not is_enabled():
        logger.debug("ContentSafety|skipped (disabled) for output check")
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": False}

    if not text or not text.strip():
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": True}

    try:
        result = _analyse_text(text)
        result["enabled"] = True
        if result["safe"]:
            logger.info(
                "ContentSafety|output passed (threshold=%d): %s",
                result.get("threshold", _severity_threshold()),
                result.get("details"),
            )
        else:
            result["filtered_response"] = UNSAFE_OUTPUT_MESSAGE
            result["original_response"] = text
        return result
    except Exception as exc:
        logger.error("Content safety output check failed — allowing through: %s", exc)
        return {"safe": True, "flagged_categories": [], "details": {}, "enabled": True, "error": str(exc)}
