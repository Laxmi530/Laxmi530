"""Redis cache layer for the chatbot retrieval backend.

Provides three capabilities, all gated behind ``REDIS_CACHE_ENABLED``:

1. **Conversation history** — per-session message list (recent N turns)
   stored as a Redis list, trimmed to ``REDIS_HISTORY_LIMIT`` and
   expired after ``REDIS_TTL_SECONDS``.
2. **Global Q&A cache (exact match)** — SHA-256 hash of the normalised
   query text as key; avoids re-generating answers for identical
   questions across all users/sessions.
3. **Global Q&A cache (semantic match)** — stores the query embedding
   alongside the answer; new queries are compared via cosine similarity
   and served from cache when similarity exceeds
   ``SEMANTIC_SIMILARITY_THRESHOLD``.

Authentication uses Microsoft Entra ID (``AZURE_REDIS_ENTRA_OBJECT_ID``
for the Redis ACL username, with a token refreshed before expiry).

Environment variables:
    ``REDIS_CACHE_ENABLED`` — ``true`` / ``1`` / ``yes`` / ``on`` to
    activate.
    ``AZURE_REDIS_HOST`` (or ``REDIS_HOST``) — cache hostname.
    ``AZURE_REDIS_PORT`` — port (default ``6380``).
    ``AZURE_REDIS_ENTRA_OBJECT_ID`` — Entra object-ID used as the Redis
    username (preferred); falls back to the ``oid`` claim in the token.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone

from azure_sp_common import (
    REDIS_ENTRA_SCOPE,
    get_azure_token_credential,
    parse_redis_host_port_from_env,
    redis_ssl_tls_kwargs,
    resolve_redis_entra_username,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
REDIS_HISTORY_LIMIT = 20
REDIS_TTL_SECONDS = 86400  # 24 hours

REDIS_QA_PREFIX = "chat:qa:"
REDIS_QA_SEMANTIC_PREFIX = "chat:qas:"
REDIS_QA_TTL = 604800  # 7 days
SEMANTIC_SIMILARITY_THRESHOLD = 0.9


# ---------------------------------------------------------------------------
# Redis client (Entra-authenticated, auto-refreshed)
# ---------------------------------------------------------------------------
_REDIS_ENTRA_STATE: dict = {"client": None, "expires_at": 0.0}


def _redis_cache_enabled() -> bool:
    v = (os.environ.get("REDIS_CACHE_ENABLED") or "").strip().lower()
    return v in ("1", "true", "yes", "on")


def _get_redis_client_entra():
    """Create / refresh an Entra-authenticated Redis client."""
    import redis

    global _REDIS_ENTRA_STATE
    now = time.time()
    if _REDIS_ENTRA_STATE["client"] is not None and now < _REDIS_ENTRA_STATE["expires_at"] - 120:
        return _REDIS_ENTRA_STATE["client"]
    try:
        if _REDIS_ENTRA_STATE["client"] is not None:
            _REDIS_ENTRA_STATE["client"].close()
    except Exception:
        pass

    host, port = parse_redis_host_port_from_env()
    cred = get_azure_token_credential()
    token = cred.get_token(REDIS_ENTRA_SCOPE)
    username = resolve_redis_entra_username(token.token)
    if not username:
        raise ValueError(
            "Redis Entra username (object ID): set AZURE_REDIS_ENTRA_OBJECT_ID in application settings, "
            "or ensure the Redis access token includes an oid claim. Do not use application (client) ID as the Redis username."
        )
    try:
        expires_at = float(token.expires_on)
    except (TypeError, ValueError, AttributeError):
        expires_at = now + 3500

    ssl_kw = redis_ssl_tls_kwargs()
    client = redis.Redis(
        host=host,
        port=port,
        username=username,
        password=token.token,
        decode_responses=True,
        socket_connect_timeout=10,
        socket_timeout=10,
        **ssl_kw,
    )
    _REDIS_ENTRA_STATE["client"] = client
    _REDIS_ENTRA_STATE["expires_at"] = expires_at
    return client


def get_redis_client():
    """Return a Redis client if caching is enabled and a host is configured, else ``None``."""
    if not _redis_cache_enabled():
        return None
    if not (os.environ.get("AZURE_REDIS_HOST") or os.environ.get("REDIS_HOST") or "").strip():
        return None
    try:
        return _get_redis_client_entra()
    except Exception as e:
        logger.warning("Redis Entra connection failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Conversation history (per-session)
# ---------------------------------------------------------------------------

def get_conversation_history_from_redis(redis_client, session_id: str) -> list[dict]:
    """Retrieve recent messages from the Redis list for *session_id*."""
    if not redis_client:
        return []
    try:
        key = f"chat:history:{session_id}"
        data = redis_client.lrange(key, -REDIS_HISTORY_LIMIT, -1)
        return [json.loads(m) for m in data] if data else []
    except Exception as e:
        logger.warning("Redis get failed: %s", e)
        return []


def get_conversation_history(session_id: str) -> list[dict]:
    """Convenience wrapper: obtain a client and fetch history."""
    redis_client = get_redis_client()
    return get_conversation_history_from_redis(redis_client, session_id)


def save_message_to_redis(redis_client, session_id: str, role: str, content: str) -> None:
    """Append a single message to the session's Redis list and trim."""
    if not redis_client:
        return
    try:
        key = f"chat:history:{session_id}"
        msg = json.dumps({"role": role, "content": content, "created_at": datetime.now(timezone.utc).isoformat()})
        redis_client.rpush(key, msg)
        redis_client.ltrim(key, -REDIS_HISTORY_LIMIT, -1)
        redis_client.expire(key, REDIS_TTL_SECONDS)
    except Exception as e:
        logger.warning("Redis save failed: %s", e)


def save_conversation_turn(session_id: str, user_id: str, user_query: str, assistant_answer: str) -> None:
    """Save both sides of a conversation turn to Redis."""
    redis_client = get_redis_client()
    save_message_to_redis(redis_client, session_id, "user", user_query)
    save_message_to_redis(redis_client, session_id, "assistant", assistant_answer)


# ---------------------------------------------------------------------------
# Global Q&A cache (exact + semantic)
# ---------------------------------------------------------------------------

def _cosine_similarity(a, b) -> float:
    """Cosine similarity between two vectors using numpy. Returns value in [-1, 1]."""
    if not a or not b or len(a) != len(b):
        return 0.0
    try:
        import numpy as np
        va, vb = np.asarray(a, dtype=np.float32), np.asarray(b, dtype=np.float32)
        norm_a, norm_b = np.linalg.norm(va), np.linalg.norm(vb)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(va, vb) / (norm_a * norm_b))
    except ImportError:
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)


def _qa_cache_key(query: str) -> str | None:
    """SHA-256 hash of the normalised query for exact-match lookups."""
    q = (query or "").strip().lower()
    if not q:
        return None
    return REDIS_QA_PREFIX + hashlib.sha256(q.encode("utf-8")).hexdigest()


def get_cached_answer_global(redis_client, query: str, query_embedding=None):
    """Check the global Q&A cache (shared across all users/sessions).

    Lookup order:
        1. Exact match — same question text (hash lookup, no embedding needed).
        2. Semantic match — similar meaning (embedding cosine similarity).

    Returns
    -------
    tuple[str | None, list | None, bool, float | None]
        ``(answer, sources, from_cache, cosine_similarity)``.
        *cosine_similarity* is ``1.0`` for exact match, a float for
        semantic match, or ``None`` on miss.
    """
    if not redis_client:
        return None, None, False, None
    try:
        key = _qa_cache_key(query)
        if key:
            data = redis_client.get(key)
            if data:
                cached = json.loads(data)
                return cached.get("answer", ""), cached.get("sources", []), True, 1.0

        if query_embedding is None:
            return None, None, False, None
        best_match = None
        best_sim = SEMANTIC_SIMILARITY_THRESHOLD
        highest_sim_seen = None
        cursor = 0
        for _ in range(100):
            cursor, keys = redis_client.scan(cursor, match=f"{REDIS_QA_SEMANTIC_PREFIX}*", count=50)
            for k in keys:
                if not k.startswith(REDIS_QA_SEMANTIC_PREFIX):
                    continue
                data = redis_client.get(k)
                if not data:
                    continue
                cached = json.loads(data)
                emb = cached.get("embedding")
                if not emb:
                    continue
                sim = _cosine_similarity(query_embedding, emb)
                if highest_sim_seen is None or sim > highest_sim_seen:
                    highest_sim_seen = sim
                if sim > best_sim:
                    best_sim = sim
                    best_match = cached
            if cursor == 0:
                break
        if best_match:
            return best_match.get("answer", ""), best_match.get("sources", []), True, best_sim
        return None, None, False, highest_sim_seen
    except Exception as e:
        logger.warning("Global cache get failed: %s", e)
    return None, None, False, None


def save_to_global_cache(redis_client, query: str, answer: str, sources: list, query_embedding=None) -> None:
    """Persist a Q&A pair in the global cache for cross-session reuse."""
    if not redis_client:
        return
    try:
        key = _qa_cache_key(query)
        if key:
            data = json.dumps({
                "query": (query or "").strip(),
                "answer": answer or "",
                "sources": sources or [],
            })
            redis_client.setex(key, REDIS_QA_TTL, data)

        if query_embedding is not None:
            sem_key = f"{REDIS_QA_SEMANTIC_PREFIX}{uuid.uuid4()}"
            data = json.dumps({
                "query": (query or "").strip(),
                "embedding": query_embedding,
                "answer": answer or "",
                "sources": sources or [],
            })
            redis_client.setex(sem_key, REDIS_QA_TTL, data)
    except Exception as e:
        logger.warning("Global cache save failed: %s", e)
