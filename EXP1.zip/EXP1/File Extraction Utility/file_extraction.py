"""Comprehensive text extraction for document files.

Supported formats:
    .pdf        — pages, tables, annotations, and document metadata.
    .docx       — paragraphs, tables, headers/footers, footnotes, endnotes,
                  and image alt-text.
    .pptx       — slide text, speaker notes, table content, and group shapes.
    .html/.htm  — structured content via ``web_scrapping`` (headings,
                  paragraphs, lists, tables, code blocks, etc.).
    .txt        — plain text (UTF-8).
    .md         — plain text (UTF-8).

Every extractor accepts *raw bytes* (``bytes | BytesIO``) so callers
never need to write temp files.  The public entry point is::

    text = extract_text(file_bytes, "report.pdf")
"""

from __future__ import annotations

import logging
import os
import tempfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import PurePosixPath
from typing import Optional, Union

logger = logging.getLogger(__name__)

FileInput = Union[bytes, BytesIO]

_SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".html", ".htm"}


def _to_bytesio(data: FileInput) -> BytesIO:
    if isinstance(data, bytes):
        return BytesIO(data)
    data.seek(0)
    return data


# ======================================================================
#  PDF
# ======================================================================

def _extract_pdf(data: FileInput) -> str:
    """Extract text from every page plus annotations and metadata."""
    from pypdf import PdfReader

    reader = PdfReader(_to_bytesio(data))
    sections: list[str] = []

    # --- Document metadata ---
    meta = reader.metadata
    if meta:
        meta_lines: list[str] = []
        for attr in ("title", "author", "subject", "creator"):
            value = getattr(meta, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))

    # --- Page content ---
    for page_num, page in enumerate(reader.pages, start=1):
        parts: list[str] = []

        page_text = page.extract_text() or ""
        if page_text.strip():
            parts.append(page_text)

        # Annotations (comments, sticky notes, free-text)
        if page.get("/Annots"):
            for annot_ref in page["/Annots"]:
                try:
                    annot = annot_ref.get_object()
                    contents = annot.get("/Contents")
                    if contents and str(contents).strip():
                        parts.append(f"[Annotation] {contents}")
                except Exception:
                    pass

        if parts:
            sections.append(f"--- Page {page_num} ---\n" + "\n".join(parts))

    return "\n\n".join(sections)


# ======================================================================
#  DOCX
# ======================================================================

def _iter_docx_block_elements(body):
    """Yield every ``<w:p>`` and ``<w:tbl>`` element from the document body
    in document order, so paragraphs and tables are interleaved correctly."""
    from docx.oxml.ns import qn

    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield ("paragraph", child)
        elif child.tag == qn("w:tbl"):
            yield ("table", child)


def _extract_docx(data: FileInput) -> str:
    """Extract full content: body, tables, headers, footers, footnotes, endnotes."""
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn

    doc = Document(_to_bytesio(data))
    sections: list[str] = []

    # --- Core properties (metadata) ---
    cp = doc.core_properties
    meta_lines: list[str] = []
    for attr in ("title", "author", "subject", "category", "keywords"):
        value = getattr(cp, attr, None)
        if value:
            meta_lines.append(f"{attr.capitalize()}: {value}")
    if meta_lines:
        sections.append("\n".join(meta_lines))

    # --- Headers and footers ---
    header_texts: list[str] = []
    footer_texts: list[str] = []
    for section in doc.sections:
        for header in (section.header, section.first_page_header):
            if header and header.is_linked_to_previous is False:
                text = "\n".join(p.text for p in header.paragraphs if p.text.strip())
                if text.strip() and text not in header_texts:
                    header_texts.append(text)
        for footer in (section.footer, section.first_page_footer):
            if footer and footer.is_linked_to_previous is False:
                text = "\n".join(p.text for p in footer.paragraphs if p.text.strip())
                if text.strip() and text not in footer_texts:
                    footer_texts.append(text)

    if header_texts:
        sections.append("[Header]\n" + "\n".join(header_texts) + "\n[/Header]")

    # --- Body: paragraphs + tables in document order ---
    body_parts: list[str] = []
    for kind, element in _iter_docx_block_elements(doc.element.body):
        if kind == "paragraph":
            para = Paragraph(element, doc.element.body)
            text = para.text.strip()
            if not text:
                continue
            style_name = (para.style.name or "").lower() if para.style else ""
            if style_name.startswith("heading"):
                level = "".join(c for c in style_name if c.isdigit()) or "1"
                body_parts.append(f"{'#' * int(level)} {text}")
            elif style_name.startswith(("list", "bullet", "toc")):
                body_parts.append(f"• {text}")
            else:
                body_parts.append(text)
        elif kind == "table":
            tbl = Table(element, doc.element.body)
            table_lines = _docx_table_to_text(tbl)
            if table_lines:
                body_parts.append(table_lines)

    if body_parts:
        sections.append("\n".join(body_parts))

    # --- Footnotes ---
    footnote_parts: list[str] = []
    footnotes_part = doc.part.package.part_related_by("/word/footnotes.xml") if hasattr(doc.part.package, "part_related_by") else None
    if footnotes_part is None:
        try:
            from docx.opc.constants import RELATIONSHIP_TYPE as RT
            for rel in doc.part.rels.values():
                if "footnotes" in (rel.reltype or ""):
                    fn_xml = rel.target_part.blob
                    from lxml import etree
                    tree = etree.fromstring(fn_xml)
                    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                    for fn in tree.findall(".//w:footnote", ns):
                        fn_id = fn.get(qn("w:id"), "")
                        if fn_id in ("-1", "0"):
                            continue
                        texts = [t.text for t in fn.findall(".//w:t", ns) if t.text]
                        if texts:
                            footnote_parts.append(f"[{fn_id}] {''.join(texts)}")
                    break
        except Exception:
            pass

    if footnote_parts:
        sections.append("[Footnotes]\n" + "\n".join(footnote_parts) + "\n[/Footnotes]")

    # --- Endnotes ---
    endnote_parts: list[str] = []
    try:
        for rel in doc.part.rels.values():
            if "endnotes" in (rel.reltype or ""):
                en_xml = rel.target_part.blob
                from lxml import etree
                tree = etree.fromstring(en_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for en in tree.findall(".//w:endnote", ns):
                    en_id = en.get(qn("w:id"), "")
                    if en_id in ("-1", "0"):
                        continue
                    texts = [t.text for t in en.findall(".//w:t", ns) if t.text]
                    if texts:
                        endnote_parts.append(f"[{en_id}] {''.join(texts)}")
                break
    except Exception:
        pass

    if endnote_parts:
        sections.append("[Endnotes]\n" + "\n".join(endnote_parts) + "\n[/Endnotes]")

    # --- Image alt-text ---
    alt_texts: list[str] = []
    for rel in doc.part.rels.values():
        if "image" in (rel.reltype or ""):
            pass  # images themselves don't carry alt-text in rels
    try:
        ns = {"wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
              "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
        for drawing in doc.element.body.iter(qn("w:drawing")):
            for docpr in drawing.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"):
                desc = docpr.get("descr", "")
                title = docpr.get("title", "")
                if desc or title:
                    alt_texts.append(f"[Image: {title or desc}]" + (f" {desc}" if desc and title else ""))
            for docpr in drawing.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}cNvPr"):
                pass
        # Also check inline namespace variant
        for drawing in doc.element.body.iter(qn("w:drawing")):
            for docpr in drawing.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"):
                pass  # already handled
    except Exception:
        pass

    if alt_texts:
        sections.append("\n".join(alt_texts))

    if footer_texts:
        sections.append("[Footer]\n" + "\n".join(footer_texts) + "\n[/Footer]")

    return "\n\n".join(sections)


def _docx_table_to_text(table) -> str:
    """Render a python-docx Table as a markdown-style text table."""
    rows_data: list[list[str]] = []
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
        rows_data.append(cells)
    if not rows_data:
        return ""

    max_cols = max(len(r) for r in rows_data)
    col_widths = [0] * max_cols
    for row in rows_data:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))
    col_widths = [max(w, 3) for w in col_widths]

    lines: list[str] = []
    for idx, row in enumerate(rows_data):
        padded = []
        for i in range(max_cols):
            val = row[i] if i < len(row) else ""
            padded.append(val.ljust(col_widths[i]))
        lines.append("| " + " | ".join(padded) + " |")
        if idx == 0:
            lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

    return "\n".join(lines)


# ======================================================================
#  PPTX
# ======================================================================

def _extract_pptx(data: FileInput) -> str:
    """Extract text from every slide: shapes, tables, groups, and speaker notes."""
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation(_to_bytesio(data))
    sections: list[str] = []

    # --- Presentation-level metadata ---
    try:
        cp = prs.core_properties
        meta_lines: list[str] = []
        for attr in ("title", "author", "subject", "category", "keywords"):
            value = getattr(cp, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))
    except Exception:
        pass

    for slide_num, slide in enumerate(prs.slides, start=1):
        slide_parts: list[str] = [f"--- Slide {slide_num} ---"]

        # Slide title (from layout placeholder)
        if slide.shapes.title and slide.shapes.title.text.strip():
            slide_parts.append(f"# {slide.shapes.title.text.strip()}")

        # All shapes (recursive for grouped shapes)
        for shape in slide.shapes:
            text = _pptx_shape_text(shape)
            if text:
                slide_parts.append(text)

        # Speaker notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                slide_parts.append(f"[Speaker Notes]\n{notes}\n[/Speaker Notes]")

        if len(slide_parts) > 1:  # more than just the header
            sections.append("\n".join(slide_parts))

    return "\n\n".join(sections)


def _pptx_shape_text(shape) -> str:
    """Recursively extract text from a single shape (text frame, table, or group)."""
    from pptx.shapes.group import GroupShapes

    parts: list[str] = []

    # Text frame (paragraphs)
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if text:
                level = para.level or 0
                if level > 0:
                    parts.append(f"{'  ' * level}• {text}")
                else:
                    parts.append(text)

    # Table
    if shape.has_table:
        table = shape.table
        rows_data: list[list[str]] = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows_data.append(cells)
        if rows_data:
            max_cols = max(len(r) for r in rows_data)
            col_widths = [3] * max_cols
            for row in rows_data:
                for i, cell in enumerate(row):
                    if i < max_cols:
                        col_widths[i] = max(col_widths[i], len(cell))
            lines: list[str] = []
            for idx, row in enumerate(rows_data):
                padded = []
                for i in range(max_cols):
                    val = row[i] if i < len(row) else ""
                    padded.append(val.ljust(col_widths[i]))
                lines.append("| " + " | ".join(padded) + " |")
                if idx == 0:
                    lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")
            parts.append("\n".join(lines))

    # Group shapes (recursive)
    if shape.shape_type is not None:
        try:
            from pptx.enum.shapes import MSO_SHAPE_TYPE
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for child_shape in shape.shapes:
                    child_text = _pptx_shape_text(child_shape)
                    if child_text:
                        parts.append(child_text)
        except Exception:
            pass

    # Alt text / description
    try:
        alt = shape.name or ""
        if hasattr(shape, "_element"):
            nvSpPr = shape._element.find(
                ".//{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}cNvPr"
            )
            if nvSpPr is not None:
                desc = nvSpPr.get("descr", "")
                if desc:
                    parts.append(f"[Image: {desc}]")
    except Exception:
        pass

    return "\n".join(parts)


# ======================================================================
#  TXT / MD
# ======================================================================

def _extract_plain_text(data: FileInput) -> str:
    """Decode raw bytes as UTF-8 text."""
    if isinstance(data, bytes):
        return data.decode("utf-8", errors="ignore")
    data.seek(0)
    return data.read().decode("utf-8", errors="ignore")


# ======================================================================
#  HTML (delegates to web_scrapping.py)
# ======================================================================

def _extract_html(data: FileInput) -> str:
    """Extract structured text from an HTML file via ``web_scrapping``."""
    from web_scrapping import scrape_webpage

    raw = data if isinstance(data, bytes) else (data.seek(0) or data.read())

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=False)
        return result.get("web_page_content", "")
    finally:
        os.unlink(tmp_path)


# ======================================================================
#  Public API
# ======================================================================

_EXTRACTORS = {
    ".pdf": _extract_pdf,
    ".docx": _extract_docx,
    ".pptx": _extract_pptx,
    ".txt": _extract_plain_text,
    ".md": _extract_plain_text,
    ".html": _extract_html,
    ".htm": _extract_html,
}


def extract_text(data: FileInput, filename: str) -> str:
    """Extract all text from *data* based on the file extension in *filename*.

    Parameters
    ----------
    data:
        Raw file bytes or a ``BytesIO`` stream.
    filename:
        Original file name (used only to detect the extension).

    Returns
    -------
    str
        The extracted plain text.

    Raises
    ------
    ValueError
        If the file extension is not supported.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor is None:
        raise ValueError(
            f"Unsupported file type '{ext}'. "
            f"Supported: {', '.join(sorted(_SUPPORTED_EXTENSIONS))}"
        )
    logger.info("Extracting text from '%s' (type=%s)", filename, ext)
    return extractor(data)


def supported_extensions() -> set[str]:
    """Return the set of file extensions this module can handle."""
    return set(_SUPPORTED_EXTENSIONS)


# ======================================================================
#  Metadata extraction
# ======================================================================

def _to_iso8601(dt: Optional[datetime]) -> Optional[str]:
    """Convert a datetime to an ISO-8601 string suitable for Azure AI Search.

    Returns ``None`` when *dt* is falsy.  Naïve datetimes are assumed UTC.
    """
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _metadata_pdf(data: FileInput) -> dict:
    from pypdf import PdfReader

    reader = PdfReader(_to_bytesio(data))
    meta = reader.metadata
    if not meta:
        return {}

    result: dict = {}
    if meta.title:
        result["title"] = str(meta.title)

    creation = getattr(meta, "creation_date", None) or getattr(meta, "creation_date_raw", None)
    if isinstance(creation, datetime):
        result["created_date"] = _to_iso8601(creation)
    elif isinstance(creation, str):
        try:
            from pypdf.generic import parse_iso8824_date
            result["created_date"] = _to_iso8601(parse_iso8824_date(creation))
        except Exception:
            pass

    return result


def _metadata_docx(data: FileInput) -> dict:
    from docx import Document

    doc = Document(_to_bytesio(data))
    cp = doc.core_properties
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_pptx(data: FileInput) -> dict:
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    try:
        cp = prs.core_properties
    except Exception:
        return {}
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_plain(data: FileInput) -> dict:
    return {}


def _metadata_html(data: FileInput) -> dict:
    from web_scrapping import scrape_webpage

    raw = data if isinstance(data, bytes) else (data.seek(0) or data.read())

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=False)
        meta = result.get("metadata", {})
        out: dict = {}
        title = meta.get("title") or meta.get("og:title")
        if title:
            out["title"] = title
        return out
    finally:
        os.unlink(tmp_path)


_METADATA_EXTRACTORS = {
    ".pdf": _metadata_pdf,
    ".docx": _metadata_docx,
    ".pptx": _metadata_pptx,
    ".txt": _metadata_plain,
    ".md": _metadata_plain,
    ".html": _metadata_html,
    ".htm": _metadata_html,
}


def extract_metadata(data: FileInput, filename: str) -> dict:
    """Extract structured metadata from a file.

    Returns a dict that may contain:
        ``title``        — document title (str or absent).
        ``created_date`` — ISO-8601 creation timestamp (str or absent).
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _METADATA_EXTRACTORS.get(ext)
    if extractor is None:
        return {}
    try:
        return extractor(data)
    except Exception:
        logger.warning("Metadata extraction failed for '%s'", filename, exc_info=True)
        return {}
