"""Azure Blob Storage helpers for the primary indexing service.

Provides utilities for interacting with blobs in the listener storage
account:

* **Client management** — lazily-initialised ``BlobServiceClient``
  singleton authenticated via ``DefaultAzureCredential``.
* **Listing** — enumerate blobs under the ``input-files/`` folder using
  ``ContainerClient.list_blobs`` (see
  https://learn.microsoft.com/en-us/azure/storage/blobs/storage-blobs-list-python).
* **Existence check** — verify whether a blob already exists in a given
  folder (e.g. ``processed-files/``).
* **Content-hash deduplication** — SHA-256 based duplicate detection that
  catches re-uploads even when filenames differ.
* **Move** — server-side copy within the same container, then delete source.
* **Error quarantine** — moves persistently failing blobs to
  ``error-files/`` after exceeding a configurable retry limit.

Environment variables:
    ``BLOB_LISTENER_ACCOUNT_NAME`` — storage account to connect to.
    ``MAX_PROCESSING_RETRIES`` — max retry attempts before quarantine
    (default ``3``).
"""

from __future__ import annotations

import hashlib
import logging
import os

from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Well-known folder names inside the blob container
# ---------------------------------------------------------------------------
SKIP_FILE = "Do_not_delete.txt"
INPUT_FOLDER = "input-files"
PROCESSED_FOLDER = "processed-files"
DUPLICATE_FOLDER = "duplicate-files"
ERROR_FOLDER = "error-files"
MAX_PROCESSING_RETRIES = int(os.environ.get("MAX_PROCESSING_RETRIES", "3"))

# ---------------------------------------------------------------------------
# Lazy singleton — avoid recreating the client on every timer tick
# ---------------------------------------------------------------------------
_listener_blob_client = None


def get_listener_blob_service_client() -> BlobServiceClient:
    """Return a lazily-initialised ``BlobServiceClient`` for the listener storage account.

    The client is created on first call using ``BLOB_LISTENER_ACCOUNT_NAME``
    and ``DefaultAzureCredential``, then cached for subsequent invocations
    within the same process.

    Returns
    -------
    BlobServiceClient
        An authenticated blob-service client.

    Raises
    ------
    KeyError
        If ``BLOB_LISTENER_ACCOUNT_NAME`` is not set.
    """
    global _listener_blob_client
    if _listener_blob_client is None:
        account_name = os.environ["BLOB_LISTENER_ACCOUNT_NAME"]
        account_url = f"https://{account_name}.blob.core.windows.net"
        _listener_blob_client = BlobServiceClient(
            account_url=account_url, credential=DefaultAzureCredential()
        )
    return _listener_blob_client


# ---------------------------------------------------------------------------
# Blob helpers — list, existence check, move
# ---------------------------------------------------------------------------


def list_input_blobs(container_client):
    """List all blobs under ``input-files/``, excluding virtual-directory markers.

    Uses ``ContainerClient.list_blobs`` with a ``name_starts_with`` filter as
    recommended by the Azure SDK documentation:
    https://learn.microsoft.com/en-us/azure/storage/blobs/storage-blobs-list-python

    Parameters
    ----------
    container_client : ContainerClient
        An authenticated container client for the target container.

    Returns
    -------
    list[BlobProperties]
        Blob property objects for each file found.
    """
    blobs = container_client.list_blobs(name_starts_with=f"{INPUT_FOLDER}/")
    return [b for b in blobs if not b.name.endswith("/")]


def blob_exists_in_folder(container_client, folder: str, blob_name: str) -> bool:
    """Return ``True`` if *blob_name* already exists under *folder*.

    Parameters
    ----------
    container_client : ContainerClient
        An authenticated container client for the target container.
    folder : str
        Folder prefix to check (e.g. ``"processed-files"``).
    blob_name : str
        The blob filename to look for.
    """
    blob_client = container_client.get_blob_client(f"{folder}/{blob_name}")
    try:
        blob_client.get_blob_properties()
        return True
    except ResourceNotFoundError:
        return False


# ---------------------------------------------------------------------------
# Content-hash deduplication
# ---------------------------------------------------------------------------


def compute_content_hash(data: bytes) -> str:
    """Return the SHA-256 hex digest of *data*."""
    return hashlib.sha256(data).hexdigest()


def content_hash_exists_in_folder(
    container_client,
    folder: str,
    content_hash: str,
) -> str | None:
    """Check if any blob in *folder* has a matching content hash in its metadata.

    Returns the blob name if a match is found, otherwise ``None``.
    """
    blobs = container_client.list_blobs(
        name_starts_with=f"{folder}/", include=["metadata"]
    )
    for blob in blobs:
        if blob.name.endswith("/"):
            continue
        blob_meta = blob.metadata or {}
        if blob_meta.get("content_sha256") == content_hash:
            return blob.name.split("/")[-1]
    return None


# ---------------------------------------------------------------------------
# Error quarantine helpers
# ---------------------------------------------------------------------------


def get_retry_count(blob_service_client, container_name: str, blob_path: str) -> int:
    """Read the ``retry_count`` from blob metadata (default 0)."""
    blob_client = blob_service_client.get_blob_client(
        container=container_name, blob=blob_path
    )
    try:
        props = blob_client.get_blob_properties()
        meta = props.metadata or {}
        return int(meta.get("retry_count", "0"))
    except Exception:
        return 0


def increment_retry_count(
    blob_service_client, container_name: str, blob_path: str
) -> int:
    """Increment the ``retry_count`` in blob metadata and return the new value."""
    blob_client = blob_service_client.get_blob_client(
        container=container_name, blob=blob_path
    )
    try:
        props = blob_client.get_blob_properties()
        meta = dict(props.metadata or {})
    except Exception:
        meta = {}
    new_count = int(meta.get("retry_count", "0")) + 1
    meta["retry_count"] = str(new_count)
    blob_client.set_blob_metadata(meta)
    return new_count


# ---------------------------------------------------------------------------
# Blob move (server-side copy)
# ---------------------------------------------------------------------------


def move_blob(
    blob_service_client: BlobServiceClient,
    container_name: str,
    source_path: str,
    dest_path: str,
    *,
    metadata: dict | None = None,
) -> None:
    """Server-side copy *source_path* to *dest_path*, then delete the source.

    Uses ``start_copy_from_url`` for an efficient server-side copy that
    avoids downloading and re-uploading the blob data through the client.

    Parameters
    ----------
    blob_service_client : BlobServiceClient
        An authenticated blob-service client.
    container_name : str
        Name of the blob container.
    source_path : str
        Full blob path of the source (e.g. ``"input-files/report.pdf"``).
    dest_path : str
        Full blob path of the destination (e.g. ``"processed-files/report.pdf"``).
    metadata : dict | None
        Optional metadata to set on the destination blob (e.g. content hash).
    """
    source_client = blob_service_client.get_blob_client(
        container=container_name, blob=source_path
    )
    dest_client = blob_service_client.get_blob_client(
        container=container_name, blob=dest_path
    )
    dest_client.start_copy_from_url(source_client.url, metadata=metadata)
    source_client.delete_blob()
