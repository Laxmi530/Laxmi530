"""Print the order of headings + their distance from a column ancestor."""

from __future__ import annotations

import io
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from bs4 import BeautifulSoup, Tag


def show(path: str) -> None:
    print("=" * 70)
    print(path)
    print("=" * 70)
    soup = BeautifulSoup(open(path, encoding="utf-8").read(), "lxml")
    for h in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"]):
        text = (h.get_text() or "").strip()[:60]
        # find ancestor with a forceCommunityTileLayout or js-content class
        anc = h
        tile_count = 0
        column_depth = -1
        while anc is not None and anc.name != "[document]":
            anc = anc.parent
            if not isinstance(anc, Tag):
                break
            classes = anc.get("class") or []
            if "forceCommunityTileLayout" in classes or "js-content" in classes:
                tile_count += 1
            if "cb-section_column" in classes:
                column_depth = tile_count
                break
        print(f"<{h.name}> tiles_above={tile_count} | {text!r}")


if __name__ == "__main__":
    for p in [
        "downloaded_pages/guides-best-practices.html",
        "downloaded_pages/api-authorization-docs.html",
        "downloaded_pages/quotas-and-rate-limit-guides.html",
        "downloaded_pages/shipper.html",
    ]:
        show(p)
