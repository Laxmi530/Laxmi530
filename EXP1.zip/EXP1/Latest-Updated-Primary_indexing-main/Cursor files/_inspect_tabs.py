"""Inspect the tab-panel structure of files where tabs matter."""

from __future__ import annotations

import io
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

from bs4 import BeautifulSoup


def show_tab_panels(path: str) -> None:
    print("=" * 70)
    print("FILE:", path)
    print("=" * 70)
    with open(path, encoding="utf-8") as f:
        soup = BeautifulSoup(f.read(), "lxml")

    panels = soup.find_all(
        lambda t: t.name == "div"
        and any(
            cls in (t.get("class") or [])
            for cls in (
                "slds-tabs_default__content",
                "slds-tabs_scoped__content",
                "slds-tabs_medium__content",
                "tab-pane",
                "tab-panel",
                "tabpanel",
            )
        )
    )
    for i, p in enumerate(panels):
        cls = p.get("class") or []
        pid = p.get("id") or ""
        label = (
            p.get("data-tab-label")
            or p.get("data-cloned-panel")
            or p.get("data-accordion-label")
            or p.get("aria-label")
            or ""
        )
        print(f"\n--- panel[{i}] id={pid!r} label_attr={label!r} class={cls} ---")
        headings = p.find_all(["h1", "h2", "h3", "h4", "h5", "h6"])
        print(f"   inner headings: {len(headings)}")
        for h in headings[:20]:
            print(f"     <{h.name}> {(h.get_text() or '').strip()[:90]}")


def main() -> None:
    for path in (
        "downloaded_pages/support.html",
        "downloaded_pages/shipper.html",
        "downloaded_pages/ltl-rate-overview.html",
    ):
        show_tab_panels(path)


if __name__ == "__main__":
    main()
