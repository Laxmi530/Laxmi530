"""Dump the full markdown text produced by the scraper for inspection."""

from __future__ import annotations
import io, os, sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

from web_scrapping import scrape_webpage

path = sys.argv[1] if len(sys.argv) > 1 else "downloaded_pages/shipper.html"
r = scrape_webpage(path)
print(r["web_page_content"])
