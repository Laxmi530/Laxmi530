"""Print the ui-widget grouping that wraps each h2 tile.
The hypothesis: tiles within the same ui-widget are siblings,
and ui-widgets are grouped by section.
"""
from __future__ import annotations
import io, os, sys
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from bs4 import BeautifulSoup, Tag


def show(path: str) -> None:
    print("=" * 70)
    print("FILE:", path)
    print("=" * 70)
    soup = BeautifulSoup(open(path, encoding="utf-8").read(), "lxml")
    for h in soup.find_all("h2"):
        text = (h.get_text() or "").strip()[:60]
        # walk up to ui-widget
        cur = h
        ui_widget = None
        while cur is not None and isinstance(cur, Tag):
            cls = cur.get("class") or []
            if "ui-widget" in cls:
                ui_widget = cur
                break
            cur = cur.parent
        if ui_widget is None:
            print(f"<h2> (no ui-widget) | {text!r}")
            continue
        item_id = ui_widget.get("data-item-id") or ""
        # Walk up further to find what wraps the ui-widget (its parent)
        wparent = ui_widget.parent
        wpid = ""
        wpcl = []
        wpidx = -1
        wpcount = -1
        if wparent is not None:
            wpcl = wparent.get("class") or []
            wpid = wparent.get("data-item-id") or ""
            siblings = [c for c in wparent.children if isinstance(c, Tag)]
            try:
                wpidx = siblings.index(ui_widget)
                wpcount = len(siblings)
            except ValueError:
                pass
        print(f"<h2> [ui-widget={item_id[:8]}, parent_class={wpcl}, sib_idx={wpidx}/{wpcount}] | {text!r}")


if __name__ == "__main__":
    show("downloaded_pages/guides-best-practices.html")
    show("downloaded_pages/api-authorization-docs.html")
    show("downloaded_pages/quotas-and-rate-limit-guides.html")
    show("downloaded_pages/shipper.html")
