"""Find where FedEx Freight Shipper is emitted as a heading."""
from __future__ import annotations
import io, os, sys
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from bs4 import BeautifulSoup

html = open("downloaded_pages/shipper.html", encoding="utf-8").read()
s = BeautifulSoup(html, "lxml")

for tag in s.find_all(["span", "a", "h1", "h2", "h3", "h4", "h5", "h6"]):
    txt = tag.get_text(strip=True)
    if txt == "FedEx Freight Shipper":
        print(f"<{tag.name}> classes={tag.get('class')} attrs={tag.attrs}")
        # Walk ancestors
        cur = tag
        for i in range(8):
            cur = cur.parent
            if cur is None or cur.name == "[document]":
                break
            cls = cur.get("class") or []
            print(f"  anc[{i}]: <{cur.name}> class={cls}")
        print()
