"""Print the heading_path for each chunk produced from a list of HTML files."""

from __future__ import annotations

import io
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

from web_scrapping import scrape_webpage
from chunking_strategies import chunk_text

FILES = sys.argv[1:] or [
    "downloaded_pages/quotas-and-rate-limit-guides.html",
    "downloaded_pages/ltl-rate-overview.html",
    "downloaded_pages/guides-best-practices.html",
    "downloaded_pages/api-authorization-docs.html",
    "downloaded_pages/shipper.html",
]


def main() -> None:
    for path in FILES:
        print("=" * 80)
        print("FILE:", path)
        print("=" * 80)
        r = scrape_webpage(path)
        print("TITLE:", r.get("metadata", {}).get("title"))
        chunks = chunk_text(
            r["web_page_content"],
            strategy="heading_aware",
            source_metadata=r.get("metadata", {}),
        )
        print(f"CHUNK COUNT: {len(chunks)}")
        for i, c in enumerate(chunks):
            print(f"[{i:3d}] heading_path = {c.heading_path}")
        print()


if __name__ == "__main__":
    main()
