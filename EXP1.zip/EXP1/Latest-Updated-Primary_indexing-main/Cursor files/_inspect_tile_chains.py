"""For each h2 tile, print the full ancestor chain attributes
to look for structural distinction between siblings."""

from __future__ import annotations

import io
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from bs4 import BeautifulSoup, Tag


def show(path: str, only_text_contains: list[str] | None = None) -> None:
    print("=" * 70)
    print("FILE:", path)
    print("=" * 70)
    soup = BeautifulSoup(open(path, encoding="utf-8").read(), "lxml")
    for h in soup.find_all(["h1", "h2"]):
        text = (h.get_text() or "").strip()
        if only_text_contains and not any(
            s.lower() in text.lower() for s in only_text_contains
        ):
            continue
        print(f"\n<{h.name}> {text[:60]!r}")
        # Walk ancestors up through the column, printing tile-related ones
        cur = h
        for i in range(20):
            cur = cur.parent
            if not isinstance(cur, Tag):
                break
            classes = cur.get("class") or []
            cid = cur.get("id") or ""
            # only print ancestors that have classes or id
            if classes or cid:
                print(f"  anc[{i}]: <{cur.name}> id={cid!r} class={classes}")
            if "cb-section_column" in classes:
                break
        # Walk siblings to see what comes immediately before/after
        # in the same parent
        parent = h.parent
        # find the "tile" container (closest forceCommunityTileLayout ancestor)
        tile = h
        while tile is not None and tile.name != "[document]":
            cls = (tile.get("class") or []) if isinstance(tile, Tag) else []
            if "forceCommunityTileLayout" in cls:
                break
            tile = tile.parent
        if tile is not None and isinstance(tile, Tag):
            tparent = tile.parent
            if tparent is not None:
                tile_siblings = [s for s in tparent.children if isinstance(s, Tag)]
                idx = tile_siblings.index(tile) if tile in tile_siblings else -1
                print(f"  tile_index_in_parent: {idx} of {len(tile_siblings)}")
                tcl = tile.get("class") or []
                print(f"  tile_class: {tcl}")
                tparent_cl = tparent.get("class") or []
                tparent_id = tparent.get("id") or ""
                print(f"  tile_parent: <{tparent.name}> id={tparent_id!r} class={tparent_cl}")


if __name__ == "__main__":
    show(
        "downloaded_pages/api-authorization-docs.html",
        ["Overview", "How It Works", "Getting Started", "Step 1", "Step 2", "Token Management"],
    )
    show(
        "downloaded_pages/guides-best-practices.html",
        ["API URIs", "Credential Management", "API Key and Secret Key", "OAuth token", "Coding Practices", "Error Handling"],
    )
