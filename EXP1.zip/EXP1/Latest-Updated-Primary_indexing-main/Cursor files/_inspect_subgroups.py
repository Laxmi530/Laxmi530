"""For each tile, find the immediate child ancestor of ui-widget that contains it
to detect sub-groupings within the same widget."""

from __future__ import annotations
import io, os, sys
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from bs4 import BeautifulSoup, Tag


def show(path: str) -> None:
    print("=" * 70)
    print("FILE:", path)
    print("=" * 70)
    soup = BeautifulSoup(open(path, encoding="utf-8").read(), "lxml")
    for h in soup.find_all("h2"):
        text = (h.get_text() or "").strip()[:60]
        # walk up to ui-widget
        cur = h
        widget = None
        while cur is not None and isinstance(cur, Tag):
            cls = cur.get("class") or []
            if "ui-widget" in cls:
                widget = cur
                break
            cur = cur.parent
        if widget is None:
            continue
        # Now find the chain from h2 -> widget, and find the "direct child of widget"
        chain = []
        cur = h
        while cur is not None and cur is not widget:
            chain.append(cur)
            cur = cur.parent
        if not chain:
            continue
        direct_child = chain[-1]  # the element that is a child of the widget
        # Now also find a "tile-group wrapper" - the ancestor right BEFORE the tile (forceCommunityTileLayout)
        tile_wrapper = None  # parent of the tile
        for el in chain:
            if isinstance(el, Tag):
                cls = el.get("class") or []
                if "forceCommunityTileLayout" in cls:
                    tile_wrapper = el.parent
                    break
        # Print chain summary
        widget_id = widget.get("data-item-id", "")[:8]
        # Print direct_child attrs and tile_wrapper attrs
        direct_attrs = direct_child.attrs if isinstance(direct_child, Tag) else {}
        wrap_attrs = tile_wrapper.attrs if isinstance(tile_wrapper, Tag) else {}
        # Get a fingerprint - ids and aura ids
        ddc_aura = direct_attrs.get("data-aura-rendered-by", "") if direct_attrs else ""
        wrap_aura = wrap_attrs.get("data-aura-rendered-by", "") if wrap_attrs else ""
        print(
            f"<h2> widget={widget_id} | direct_child=<{direct_child.name} aura={ddc_aura}> "
            f"| tile_wrapper=<{tile_wrapper.name if tile_wrapper else None} aura={wrap_aura}> | {text!r}"
        )


if __name__ == "__main__":
    for p in [
        "downloaded_pages/api-authorization-docs.html",
        "downloaded_pages/guides-best-practices.html",
    ]:
        show(p)
