"""Inspect the ancestor chains for specific headings to understand
why a flat-looking source HTML produces collapsed heading paths."""

from __future__ import annotations

import io
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

from bs4 import BeautifulSoup


def show_heading(soup, text_substring: str, levels: tuple[str, ...] = ("h1", "h2", "h3", "h4", "h5", "h6")) -> None:
    print("=" * 70)
    print(f"Looking for heading containing: {text_substring!r}")
    print("=" * 70)
    candidates = []
    for tag in soup.find_all(levels):
        txt = (tag.get_text() or "").strip()
        if text_substring.lower() in txt.lower():
            candidates.append(tag)
    if not candidates:
        print("  NOT FOUND")
        return
    for cand in candidates[:3]:
        txt = (cand.get_text() or "").strip()
        print(f"<{cand.name}> {txt[:100]!r}")
        cur = cand
        for i in range(10):
            cur = cur.parent
            if cur is None or cur.name == "[document]":
                break
            classes = cur.get("class", [])
            cid = cur.get("id", "")
            print(f"  ancestor[{i}]: <{cur.name}> id={cid!r} class={classes}")
        print()


def main() -> None:
    files = [
        ("downloaded_pages/guides-best-practices.html", [
            "Credential Management",
            "API Key and Secret Key",
            "OAuth token",
            "Coding Practices",
            "HTTP status codes",
            "Error Handling",
        ]),
        ("downloaded_pages/api-authorization-docs.html", [
            "Getting Started",
            "Step 1",
            "Step 2",
        ]),
        ("downloaded_pages/shipper.html", [
            "Create an API project",
            "Testing your integration",
            "Creating an API project",
        ]),
        ("downloaded_pages/quotas-and-rate-limit-guides.html", [
            "FAQs",
            "If the same 429 error",
        ]),
    ]
    for path, queries in files:
        print("\n##############")
        print("##  FILE:", path)
        print("##############")
        with open(path, encoding="utf-8") as f:
            soup = BeautifulSoup(f.read(), "lxml")
        for q in queries:
            show_heading(soup, q)


if __name__ == "__main__":
    main()
