"""Azure Functions v2 (Python) entry point for the primary indexing service.

Hosts a timer-triggered function that polls the ``input-files/`` folder in
a configured Azure Blob Storage container for new files, then processes
each through the full vector-indexing pipeline:

1. Lists blobs in the ``input-files/`` folder of the container specified by
   ``BLOB_LISTENER_CONTAINER_NAME`` in the storage account
   ``BLOB_LISTENER_ACCOUNT_NAME``.
2. Skips the placeholder ``Do_not_delete.txt`` file.
3. Checks for duplicates — if the file already exists in the
   ``processed-files/`` folder, moves it to ``duplicate-files/`` and skips.
4. Downloads the blob (supports .txt, .pdf, .docx, .html, .pptx, .md, .json,
   .csv, .xlsx, .xls, .rtf, .xml).
5. For ``.json`` files, parses the JSON directly — each top-level array
   element (or the single root object) becomes one chunk whose text is the
   JSON-serialised string.  Text extraction and chunking are bypassed.
6. For all other formats, chunks the content using a configurable strategy
   controlled by
   ``CHUNKING_STRATEGY``:
   - ``"recursive"`` — fast, deterministic recursive character splitting.
   - ``"semantic"`` — embedding-based semantic chunking that detects topic
     shifts via cosine distance between sentence groups.
   - ``"heading_aware"`` (default) — context-aware chunking that splits on
     markdown headings and attaches structural metadata (section_heading,
     heading_path, etc.) to each chunk.
   - ``"hybrid"`` — heading-aware first pass with semantic sub-chunking for
     large sections.
7. Generates embeddings in batches via Azure OpenAI.  For heading_aware and
   hybrid strategies, heading context is prepended to the text before
   embedding to improve retrieval quality.
8. Upserts the vector documents into an Azure AI Search index.
9. Moves processed files from ``input-files/`` to ``processed-files/``.

The timer interval is controlled by ``BLOB_LISTENER_TIMER_SECONDS``
(default ``300`` — i.e. every 5 minutes).

Authentication is handled by ``azure_sp_common`` (Entra ID / service
principal with Key Vault secret resolution).  Secrets are bootstrapped at
startup by ``keyvault_bootstrap``.

Environment variables (key ones):
    BLOB_LISTENER_ACCOUNT_NAME, BLOB_LISTENER_CONTAINER_NAME,
    BLOB_LISTENER_TIMER_SECONDS,
    AZURE_OPENAI_ENDPOINT, AZURE_SEARCH_ENDPOINT, AZURE_SEARCH_INDEX_NAME,
    AZURE_OPENAI_EMBEDDING_MODEL, AZURE_OPENAI_CHAT_MODEL,
    CHUNKING_STRATEGY, CHUNK_SIZE, CHUNK_OVERLAP,
    EMBEDDING_BATCH_SIZE, DISABLE_SSL_VERIFY,
    RETURN_ERROR_DETAIL.
"""

import azure.functions as func
import json
import logging
import os
import ssl
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / ".env")
if os.getenv("DISABLE_SSL_VERIFY", "").strip().lower() in ("1", "true", "yes"):
    ssl._create_default_https_context = ssl._create_unverified_context

from azure.search.documents import SearchClient

from indexing import (
    ensure_search_index,
    get_embeddings_batched,
    store_chunks_to_blob,
    upsert_documents,
    build_search_documents,
    delete_documents_for_file,
)
from blob_helpers import (
    get_listener_blob_service_client,
    list_input_blobs,
    blob_exists_in_folder,
    content_hash_exists_in_folder,
    compute_content_hash,
    move_blob,
    get_retry_count,
    increment_retry_count,
    SKIP_FILE,
    INPUT_FOLDER,
    PROCESSED_FOLDER,
    DUPLICATE_FOLDER,
    ERROR_FOLDER,
    MAX_PROCESSING_RETRIES,
)

from keyvault_bootstrap import load_secrets_from_key_vault

try:
    load_secrets_from_key_vault()
except Exception as e:
    logging.exception(
        "Key Vault mapping bootstrap failed (KEY_VAULT_SECRET_MAPPING, vault URL, MI RBAC): %s",
        e,
    )

from azure_sp_common import (
    build_search_credential,
    create_openai_client,
    load_keyvault_secrets_into_environ,
)

try:
    load_keyvault_secrets_into_environ()
except Exception as e:
    logging.exception(
        "Key Vault / Entra warmup failed (vault URL, KEY_VAULT_SECRET_NAME_*, "
        "AZURE_TENANT_ID, RBAC for managed identity): %s",
        e,
    )

# ---------------------------------------------------------------------------
# Timer schedule — derived from BLOB_LISTENER_TIMER_SECONDS (default 5 min)
# ---------------------------------------------------------------------------
_timer_seconds = int(os.environ.get("BLOB_LISTENER_TIMER_SECONDS", "300"))
if _timer_seconds < 60:
    BLOB_LISTENER_SCHEDULE = f"*/{max(1, _timer_seconds)} * * * * *"
else:
    _timer_minutes = max(1, _timer_seconds // 60)
    BLOB_LISTENER_SCHEDULE = f"0 */{_timer_minutes} * * * *"

app = func.FunctionApp()

# ---------------------------------------------------------------------------
# Lazy singleton — avoid recreating the OpenAI client on every tick
# ---------------------------------------------------------------------------
_openai_client = None


def _get_openai_client():
    """Return a lazily-initialised Azure OpenAI client singleton."""
    global _openai_client
    if _openai_client is None:
        openai_endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
        _openai_client = create_openai_client(openai_endpoint, api_version)
    return _openai_client


# ---------------------------------------------------------------------------
# Text chunking (configurable strategy)
# ---------------------------------------------------------------------------

CHUNK_SIZE = int(os.environ.get("CHUNK_SIZE", "1000"))
CHUNK_OVERLAP = int(os.environ.get("CHUNK_OVERLAP", "100"))

VALID_STRATEGIES = ("recursive", "semantic", "heading_aware", "hybrid")


def _resolve_chunking_strategy() -> str:
    """Return the active chunking strategy name.

    Priority:
    1. ``CHUNKING_STRATEGY`` env var.
    2. Default -> ``"heading_aware"``.

    Valid values: ``recursive``, ``semantic``, ``heading_aware``, ``hybrid``.
    """
    explicit = os.environ.get("CHUNKING_STRATEGY", "").strip().lower()
    if explicit in VALID_STRATEGIES:
        return explicit
    return "heading_aware"


class _AzureOpenAIEmbeddings:
    """Adapter wrapping an AzureOpenAI client to satisfy the LangChain
    ``Embeddings`` interface required by semantic and hybrid strategies.
    """

    def __init__(self, openai_client, model: str):
        self._client = openai_client
        self._model = model

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        response = self._client.embeddings.create(
            input=texts, model=self._model
        )
        return [
            item.embedding
            for item in sorted(response.data, key=lambda d: d.index)
        ]


def _chunk_text(client, text, *, strategy: str | None = None, max_chunk_size: int | None = None):
    """Split *text* into ``ChunkWithMetadata`` objects using the configured strategy."""
    from chunking_strategies import chunk_text, ChunkWithMetadata  # noqa: F811

    if not text or not text.strip():
        return []

    if max_chunk_size is None:
        max_chunk_size = CHUNK_SIZE
    if strategy is None:
        strategy = _resolve_chunking_strategy()

    logging.info(
        "Chunking strategy: %s (chunk_size=%d, chunk_overlap=%d)",
        strategy, max_chunk_size, CHUNK_OVERLAP,
    )

    embeddings = None
    if strategy in ("semantic", "hybrid"):
        embedding_model = os.environ.get(
            "AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"
        )
        embeddings = _AzureOpenAIEmbeddings(client, embedding_model)

    return chunk_text(
        text,
        strategy=strategy,
        chunk_size=max_chunk_size,
        chunk_overlap=CHUNK_OVERLAP,
        embeddings=embeddings,
    )


# ---------------------------------------------------------------------------
# Single-blob indexing pipeline
# ---------------------------------------------------------------------------


def _process_blob(
    blob_service_client,
    container_name: str,
    blob_path: str,
) -> None:
    """Download, extract, chunk, embed, and upsert a single blob.

    Parameters
    ----------
    blob_service_client : BlobServiceClient
        Authenticated client for the listener storage account.
    container_name : str
        Name of the blob container.
    blob_path : str
        Full blob path (e.g. ``"input-files/report.pdf"``).

    Raises
    ------
    Exception
        Re-raised after logging if any step in the pipeline fails.
    """
    blob_name = blob_path.split("/")[-1]
    account_name = os.environ["BLOB_LISTENER_ACCOUNT_NAME"]
    blob_url = (
        f"https://{account_name}.blob.core.windows.net/"
        f"{container_name}/{blob_path}"
    )

    logging.info("Processing blob: %s", blob_url)

    search_endpoint = os.environ["AZURE_SEARCH_ENDPOINT"]
    index_name = os.environ.get("AZURE_SEARCH_INDEX_NAME", "fedex-vectors")
    openai_embedding_model = os.environ.get(
        "AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"
    )

    blob_client = blob_service_client.get_blob_client(
        container=container_name, blob=blob_path
    )
    blob_data = blob_client.download_blob().readall()

    strategy = _resolve_chunking_strategy()
    ext = os.path.splitext(blob_name)[1].lower()

    # ------------------------------------------------------------------
    # JSON file processing is disabled — .json files are now skipped
    # in the input-files/ listing (process_input_files). The block
    # below is commented out to prevent accidental execution.
    # ------------------------------------------------------------------
    # if ext == ".json":
    #     json_data = json.loads(blob_data.decode("utf-8"))
    #     raw_chunks = json_data if isinstance(json_data, list) else [json_data]
    #
    #     chunk_texts = [
    #         json.dumps(ch) if isinstance(ch, dict) else str(ch)
    #         for ch in raw_chunks
    #     ]
    #
    #     openai_client = _get_openai_client()
    #     search_credential = build_search_credential()
    #     ensure_search_index(search_endpoint, search_credential, index_name)
    #     search_client = SearchClient(
    #         search_endpoint, index_name, credential=search_credential
    #     )
    #
    #     store_chunks_to_blob(
    #         blob_service_client, container_name, blob_path, chunk_texts,
    #     )
    #
    #     if not chunk_texts:
    #         logging.warning("No chunks generated for %s", blob_name)
    #         return
    #
    #     logging.info(
    #         "Generating embeddings for %d JSON chunks (batched)...",
    #         len(chunk_texts),
    #     )
    #     embeddings = get_embeddings_batched(
    #         openai_client, chunk_texts, openai_embedding_model
    #     )
    #
    #     documents = build_search_documents(
    #         chunk_texts, embeddings, blob_name, blob_url,
    #     )
    #
    #     total_succeeded = upsert_documents(
    #         search_client, search_endpoint, search_credential,
    #         index_name, documents,
    #     )
    #
    #     logging.info(
    #         "Successfully uploaded %d/%d vector chunks for %s",
    #         total_succeeded, len(documents), blob_name,
    #     )
    #     return

    if strategy in ("heading_aware", "hybrid"):
        from file_extraction_enhanced import (
            extract_text_enhanced,
            supported_extensions_enhanced,
        )
        from file_extraction import extract_metadata

        if ext not in supported_extensions_enhanced():
            logging.info("Unsupported file type: %s", blob_name)
            return

        content = extract_text_enhanced(blob_data, blob_name)
        file_metadata = extract_metadata(blob_data, blob_name)
    else:
        from file_extraction import extract_text, extract_metadata, supported_extensions

        if ext not in supported_extensions():
            logging.info("Unsupported file type: %s", blob_name)
            return

        content = extract_text(blob_data, blob_name)
        file_metadata = extract_metadata(blob_data, blob_name)

    openai_client = _get_openai_client()

    search_credential = build_search_credential()
    ensure_search_index(search_endpoint, search_credential, index_name)
    search_client = SearchClient(
        search_endpoint, index_name, credential=search_credential
    )

    chunks = _chunk_text(openai_client, content, strategy=strategy)
    store_chunks_to_blob(
        blob_service_client, container_name, blob_path,
        [c.content for c in chunks],
    )

    if not chunks:
        logging.warning("No chunks generated for %s", blob_name)
        return

    from chunking_strategies import chunks_to_texts_and_metadata

    content_texts, embedding_texts, metadata_list = chunks_to_texts_and_metadata(
        chunks
    )

    logging.info(
        "Generating embeddings for %d chunks (batched)...", len(embedding_texts)
    )
    embeddings = get_embeddings_batched(
        openai_client, embedding_texts, openai_embedding_model
    )

    documents = build_search_documents(
        content_texts, embeddings, blob_name, blob_url,
        title=file_metadata.get("title"),
        created_date=file_metadata.get("created_date"),
        chunk_metadata=metadata_list,
    )

    delete_documents_for_file(search_client, blob_name)

    total_succeeded = upsert_documents(
        search_client, search_endpoint, search_credential,
        index_name, documents,
    )

    logging.info(
        "Successfully uploaded %d/%d vector chunks for %s",
        total_succeeded, len(documents), blob_name,
    )


# ---------------------------------------------------------------------------
# Timer-triggered blob listener
# ---------------------------------------------------------------------------


@app.function_name(name="process_input_files")
@app.timer_trigger(
    schedule=BLOB_LISTENER_SCHEDULE,
    arg_name="timer",
    run_on_startup=False,
)
def process_input_files(timer: func.TimerRequest) -> None:
    """Poll the ``input-files/`` folder and process new blobs.

    Runs on the schedule defined by ``BLOB_LISTENER_TIMER_SECONDS``
    (default every 5 minutes).  For each blob found:

    * ``Do_not_delete.txt`` is silently skipped (Azure placeholder).
    * Files that already exist in ``processed-files/`` (by name) are
      moved to ``duplicate-files/`` and skipped.
    * Content-hash deduplication catches re-uploads with different
      filenames but identical content.
    * Files that have failed ``MAX_PROCESSING_RETRIES`` times are
      moved to ``error-files/`` (quarantined) and skipped.
    * All other files are run through the full extraction / chunking /
      embedding / upsert pipeline and then moved to ``processed-files/``.
    * A processing summary is logged at the end of each run.
    """
    if timer.past_due:
        logging.warning("Timer is past due — running immediately.")

    container_name = os.environ["BLOB_LISTENER_CONTAINER_NAME"]

    stats = {
        "processed": 0,
        "skipped_placeholder": 0,
        "skipped_duplicate_name": 0,
        "skipped_duplicate_content": 0,
        "quarantined": 0,
        "failed": 0,
        "total_chunks": 0,
    }

    try:
        blob_service_client = get_listener_blob_service_client()
        container_client = blob_service_client.get_container_client(container_name)

        input_blobs = list_input_blobs(container_client)

        if not input_blobs:
            logging.info(
                "No files found in %s/ — nothing to process.", INPUT_FOLDER
            )
            return

        logging.info(
            "Found %d file(s) in %s/.", len(input_blobs), INPUT_FOLDER
        )

        for blob in input_blobs:
            blob_path = blob.name
            blob_name = blob_path.split("/")[-1]

            if blob_name == SKIP_FILE:
                logging.info("Skipping placeholder file: %s", SKIP_FILE)
                stats["skipped_placeholder"] += 1
                continue

            if blob_exists_in_folder(container_client, PROCESSED_FOLDER, blob_name):
                logging.info(
                    "File '%s' already exists in %s/ — moving to %s/ and skipping.",
                    blob_name,
                    PROCESSED_FOLDER,
                    DUPLICATE_FOLDER,
                )
                move_blob(
                    blob_service_client,
                    container_name,
                    blob_path,
                    f"{DUPLICATE_FOLDER}/{blob_name}",
                )
                stats["skipped_duplicate_name"] += 1
                continue

            blob_client = blob_service_client.get_blob_client(
                container=container_name, blob=blob_path
            )
            blob_data = blob_client.download_blob().readall()
            content_hash = compute_content_hash(blob_data)

            existing_match = content_hash_exists_in_folder(
                container_client, PROCESSED_FOLDER, content_hash
            )
            if existing_match:
                logging.info(
                    "File '%s' has identical content to already-processed '%s' "
                    "— moving to %s/ and skipping.",
                    blob_name,
                    existing_match,
                    DUPLICATE_FOLDER,
                )
                move_blob(
                    blob_service_client,
                    container_name,
                    blob_path,
                    f"{DUPLICATE_FOLDER}/{blob_name}",
                )
                stats["skipped_duplicate_content"] += 1
                continue

            retry_count = get_retry_count(
                blob_service_client, container_name, blob_path
            )
            if retry_count >= MAX_PROCESSING_RETRIES:
                logging.error(
                    "File '%s' has failed %d times (max %d) — quarantining to %s/.",
                    blob_name,
                    retry_count,
                    MAX_PROCESSING_RETRIES,
                    ERROR_FOLDER,
                )
                move_blob(
                    blob_service_client,
                    container_name,
                    blob_path,
                    f"{ERROR_FOLDER}/{blob_name}",
                )
                stats["quarantined"] += 1
                continue

            try:
                _process_blob(blob_service_client, container_name, blob_path)

                move_blob(
                    blob_service_client,
                    container_name,
                    blob_path,
                    f"{PROCESSED_FOLDER}/{blob_name}",
                    metadata={"content_sha256": content_hash},
                )
                logging.info(
                    "Moved '%s' from %s/ to %s/.",
                    blob_name, INPUT_FOLDER, PROCESSED_FOLDER,
                )
                stats["processed"] += 1
            except Exception:
                logging.exception(
                    "Error processing blob '%s' — incrementing retry count.",
                    blob_name,
                )
                new_count = increment_retry_count(
                    blob_service_client, container_name, blob_path
                )
                logging.info(
                    "Retry count for '%s': %d / %d",
                    blob_name, new_count, MAX_PROCESSING_RETRIES,
                )
                stats["failed"] += 1

    except Exception:
        logging.exception("process_input_files failed.")

    total = sum(stats.values())
    if total > 0:
        logging.info(
            "=== Processing Summary === "
            "Processed: %d | Duplicate (name): %d | Duplicate (content): %d | "
            "Quarantined: %d | Failed: %d | Skipped (placeholder): %d",
            stats["processed"],
            stats["skipped_duplicate_name"],
            stats["skipped_duplicate_content"],
            stats["quarantined"],
            stats["failed"],
            stats["skipped_placeholder"],
        )
