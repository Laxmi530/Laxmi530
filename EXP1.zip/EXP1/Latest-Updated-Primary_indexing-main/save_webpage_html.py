"""
Save Webpage as HTML (browser-faithful)
=======================================

Downloads a fully-rendered webpage and writes it to a single
self-contained ``.html`` file on disk in a way that is **as close as
possible to what the browser actually shows**.

Designed for JavaScript-heavy pages such as Salesforce Experience
Cloud / Lightning (LWC) sites (e.g. ``my.site.com/aeh/s/...``) and
the public FedEx Developer Portal (``developer.fedex.com/api/...``)
where:

* The visible content is rendered after the initial document load.
* Information is split across hidden tab panels (``Header Parameters``,
  ``Request Body``, ``Responses`` with ``200``, ``400``, ``401``,
  ``403``, ``404`` tabs).
* Extra response codes (``500``, ``503``) live behind a ``MoreTabs``
  overflow / ``slds-tabs_default__overflow-button`` dropdown that has
  to be opened before its menu items can be clicked.
* The framework hides inactive tab panels with ``slds-hide`` /
  ``aria-hidden`` rather than unmounting them, so a click through every
  tab is sufficient to materialise their content into the DOM.

Design principles
-----------------
This module does **not** delegate to ``WebScraper.fetch()`` because
that pipeline is built for *extraction* and aggressively mutates the
DOM (clones every panel into a ``#__scraper_panels`` container,
force-reveals every ``[hidden]`` / ``slds-hide`` / sr-only mirror,
reorders ``<span>`` elements, converts ``<p>`` elements to ``<h2>``, removes
dropdown containers, etc.). The resulting saved HTML carries duplicate
content, which causes the downstream chunker to produce **more chunks
than the live URL** when the file is later re-fed to
``web_scrapping.py``.

Instead this module:

1. Renders the page in headless Chromium via Playwright.
2. Iteratively clicks every tab in every tab group (including those
   inside Shadow DOM), with multiple passes so that tabs revealed by
   activating an earlier tab also get clicked.
3. Opens overflow / "More" dropdowns and clicks each menu item so the
   hidden tabs (``500``, ``503`` …) get rendered.
4. Injects **minimal, targeted** CSS that reveals only tab-panel
   containers and SLDS hide classes — leaving ``slds-assistive-text``,
   ``sr-only``, ``visually-hidden``, etc. untouched (so accessibility
   mirror content is *not* exposed).
5. Closes any open overflow dropdowns so the saved file visually
   matches the browser at rest.
6. Injects a ``<base href="<origin>/">`` tag at the top of ``<head>``
   so every relative URL in the saved file (``/file-asset-public/…``,
   ``/resource/…``, images, stylesheets, fonts, etc.) resolves back
   to the original Salesforce origin when the file is opened locally
   in a browser. Without this the browser tries to load resources
   from the local filesystem, causing broken images and — critically
   — missing SLDS column-width CSS, which collapses table columns to
   zero width and gives the impression that content is missing.
7. Strips restrictive ``<meta http-equiv>`` tags — primarily
   ``Content-Security-Policy`` (Salesforce sets ``default-src 'self'``
   which under ``file://`` blocks every cross-origin fetch) plus
   ``X-Frame-Options`` and ``refresh``. Without this step the
   ``<base href>`` from step 6 is useless because the browser refuses
   to issue the requests in the first place.
8. Stamps each tab panel with its tab's visible label as a
   ``data-tab-label`` attribute (e.g. ``data-tab-label="200 Success"``)
   and injects a CSS rule that renders that label as a styled header
   *above* the panel using a ``::before`` pseudo-element. CSS
   pseudo-elements live in the browser's render tree only — they are
   **not** part of the DOM — so BeautifulSoup,
   ``web_scrapping.scrape_webpage`` and the downstream chunker do
   not see the header text. The chunking output is therefore
   byte-for-byte identical to a save without this step. Only a
   human opening the saved file in a browser sees clear
   ``200 Success`` / ``400 Bad Request`` / ``503 Service Unavailable``
   headers above each Response Schema table.
9. Writes ``page.content()`` to a UTF-8 ``.html`` file with no
   structural mutations — exactly one copy of each panel's content.

The resulting file can be re-fed to ``web_scrapping.scrape_webpage``
without producing duplicate chunks, because each tab panel exists
exactly once in the saved DOM.

Dependencies
------------
    pip install playwright
    playwright install chromium

Usage
-----
    # Default URL / output:
    python save_webpage_html.py

    # Custom URL / output:
    python save_webpage_html.py "https://example.com/page" "page.html"

    # Programmatic:
    from save_webpage_html import save_webpage_as_html
    save_webpage_as_html(
        "https://ruby-page-8052--fairqa.sandbox.my.site.com/aeh/s/"
        "ltl-pickup-docs?language=en_US",
        "ltl-pickup-docs.html",
    )

    # Batch (any list of URLs):
    from save_webpage_html import save_many
    save_many(
        [
            "https://.../ltl-rate-docs?language=en_US",
            "https://.../ltl-ship-docs?language=en_US",
        ],
        output_dir="downloaded_pages",
    )
"""

from __future__ import annotations

import asyncio
import logging
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urlparse

from playwright.sync_api import (
    Page,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)


# --------------------------------------------------------------------------- #
#  Configuration
# --------------------------------------------------------------------------- #

DEFAULT_URL = (
    "https://ruby-page-8052--fairqa.sandbox.my.site.com/aeh/s/"
    "ltl-pickup-docs?language=en_US"
)
DEFAULT_OUTPUT = "ltl-pickup-docs.html"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

NAV_TIMEOUT_SEC = 90              # generous for slow LWC sandboxes
RENDER_SETTLE_MS = 2500           # extra settle time after networkidle
TAB_CLICK_DELAY_MS = 600          # wait between tab clicks (LWC needs time)
OVERFLOW_OPEN_DELAY_MS = 700      # wait after opening "More" dropdown
MAX_TAB_PASSES = 4                # repeat the click loop up to N times


# Targeted reveal CSS. Only forces tab-panel containers and SLDS hide
# classes to be visible — does NOT touch generic [hidden],
# slds-assistive-text, sr-only, visually-hidden, or any other hidden
# mirror content. This keeps the saved DOM close to the live page and
# avoids exposing duplicate accessibility text that would be picked up
# as extra chunks during downstream scraping.
REVEAL_CSS = """
    [role="tabpanel"],
    .tab-pane,
    .tab-panel,
    .tabpanel,
    .slds-tabs_default__content,
    .slds-tabs_scoped__content,
    .slds-tabs_medium__content,
    .slds-tabs_large__content,
    .react-tabs__tab-panel {
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
    }
    [role="tabpanel"][aria-hidden="true"],
    [role="tabpanel"].slds-hide,
    .slds-tabs_default__content.slds-hide,
    .slds-tabs_scoped__content.slds-hide {
        display: block !important;
    }
    details[open] > summary ~ * {
        display: block !important;
    }
    .collapse.show,
    .panel-collapse.in {
        display: block !important;
        height: auto !important;
    }
    #__react_tabs_clones {
        display: block !important;
    }
    #__react_tabs_clones > [data-cloned-tab-id] {
        display: block !important;
    }
"""

# CSS that renders each tab panel's name as a styled header *above*
# its content, using a CSS ::before pseudo-element fed by the
# data-tab-label attribute. Pseudo-elements live in the browser's
# render tree only — they are NOT part of the DOM, so BeautifulSoup,
# Playwright text-extraction, web_scrapping.py, and your downstream
# chunker never see them. Effect: a human opening the saved file in
# a browser sees clear "200 Success" / "400 Bad Request" / etc.
# headers above each Response Schema table, while the chunking
# output stays byte-for-byte identical.
TAB_LABEL_CSS = """
    [data-tab-label]:not([data-tab-label=""])::before {
        content: attr(data-tab-label);
        display: block;
        margin: 1.5em 0 0.75em 0;
        padding: 0.55em 0.85em;
        background-color: #f3f4f6;
        border-left: 4px solid #ff6600;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI",
                     Helvetica, Arial, sans-serif;
        font-weight: 600;
        font-size: 1.05em;
        color: #1a1a1a;
        border-radius: 2px;
    }
"""


# JavaScript helpers, all written so they can be passed straight to
# page.evaluate(). They pierce open Shadow DOMs (Salesforce LWC uses
# them everywhere) but never modify attributes outside of clicking.

# Dismiss cookie consent banners, login/signup modals, and other
# overlay elements that can block tab clicks on pages like
# developer.fedex.com. Removes or hides the overlay and any
# associated backdrops.
DISMISS_OVERLAYS_JS = r"""
    () => {
        let dismissed = 0;
        const overlaySelectors = [
            '#onetrust-banner-sdk',
            '.optanon-alert-box-wrapper',
            '.cookie-banner',
            '[class*="cookieConsent"]',
            '[id*="cookie-banner"]',
            '[aria-label*="cookie" i]',
            '#onetrust-consent-sdk',
            '.truste-consent-overlay',
            '.evidon-consent-button',
        ];
        for (const sel of overlaySelectors) {
            for (const el of document.querySelectorAll(sel)) {
                try { el.remove(); dismissed += 1; } catch (e) {}
            }
        }

        const acceptBtnSelectors = [
            '#onetrust-accept-btn-handler',
            '[id*="cookie-accept" i]',
            'button[class*="cookie-accept" i]',
            'button[aria-label*="accept" i][aria-label*="cookie" i]',
            '.optanon-allow-all',
        ];
        for (const sel of acceptBtnSelectors) {
            const btn = document.querySelector(sel);
            if (btn) {
                try { btn.click(); dismissed += 1; } catch (e) {}
            }
        }

        const modalSelectors = [
            '.modal-backdrop',
            '.modal.show',
            '.modal.fade.in',
            '[class*="login-modal"]',
            '[class*="signup-modal"]',
            '[class*="loginOverlay"]',
            'div[role="dialog"][aria-modal="true"]',
        ];
        for (const sel of modalSelectors) {
            for (const el of document.querySelectorAll(sel)) {
                try {
                    el.style.display = 'none';
                    dismissed += 1;
                } catch (e) {}
            }
        }
        document.body.style.overflow = '';
        document.body.classList.remove('modal-open', 'no-scroll');
        document.documentElement.style.overflow = '';
        return dismissed;
    }
"""

# Expand all <details> elements and common accordion patterns
# (Bootstrap, custom data-toggle, aria-expanded) so their content
# is visible in the saved HTML. This is needed for pages like
# developer.fedex.com where endpoint descriptions may be inside
# collapsible sections.
EXPAND_COLLAPSIBLES_JS = r"""
    () => {
        let expanded = 0;

        for (const d of document.querySelectorAll('details:not([open])')) {
            try { d.setAttribute('open', ''); expanded += 1; } catch (e) {}
        }

        const collapseSelectors = [
            '.collapse:not(.show)',
            '.panel-collapse:not(.in)',
            '[data-toggle="collapse"]',
            '[data-bs-toggle="collapse"]',
        ];
        for (const sel of collapseSelectors) {
            for (const el of document.querySelectorAll(sel)) {
                try {
                    el.classList.add('show', 'in');
                    el.classList.remove('collapsed');
                    el.style.display = '';
                    el.style.height = 'auto';
                    if (el.hasAttribute('aria-expanded')) {
                        el.setAttribute('aria-expanded', 'true');
                    }
                    expanded += 1;
                } catch (e) {}
            }
        }

        function expandInShadow(root) {
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) {
                    for (const d of el.shadowRoot.querySelectorAll(
                        'details:not([open])')) {
                        try { d.setAttribute('open', ''); expanded += 1; }
                        catch (e) {}
                    }
                    expandInShadow(el.shadowRoot);
                }
            }
        }
        expandInShadow(document);

        return expanded;
    }
"""

# Expand Redoc-style response accordion sections. These are the
# clickable `> 200 Success`, `> 400 Bad Request`, etc. sections on
# developer.fedex.com API docs. They use custom styled-components
# (sc-kPVwWT) with an SVG chevron — no standard aria-expanded or
# <details> pattern. Each accordion header is a <div> containing
# <strong>CODE</strong> and <span>STATUS</span>. Clicking it
# toggles a sibling container with the response schema.
#
# Because the class names are generated (sc-*) and may change across
# builds, we identify accordion headers by structure: a <div> whose
# first child is an SVG and whose next sibling is a <strong>
# containing a 3-digit HTTP status code.
EXPAND_REDOC_ACCORDIONS_JS = r"""
    () => {
        let expanded = 0;

        const h3s = document.querySelectorAll('h3');
        for (const h3 of h3s) {
            const text = (h3.textContent || '').trim();
            if (text !== 'Responses') continue;

            const container = h3.nextElementSibling
                || h3.parentElement;
            if (!container) continue;

            const headers = container.querySelectorAll('div > svg + strong');
            for (const strong of headers) {
                const headerDiv = strong.parentElement;
                if (!headerDiv) continue;
                try {
                    headerDiv.scrollIntoView({block: 'center'});
                    headerDiv.click();
                    expanded += 1;
                } catch (e) {}
            }
        }

        // Also try direct pattern: divs with an SVG followed by
        // <strong> containing a 3-digit code (e.g. "200 ", "400 ")
        if (expanded === 0) {
            const allStrong = document.querySelectorAll('div > strong');
            for (const strong of allStrong) {
                const code = (strong.textContent || '').trim();
                if (!/^\d{3}$/.test(code)) continue;
                const headerDiv = strong.parentElement;
                if (!headerDiv) continue;
                const svg = headerDiv.querySelector('svg');
                if (!svg) continue;
                try {
                    headerDiv.scrollIntoView({block: 'center'});
                    headerDiv.click();
                    expanded += 1;
                } catch (e) {}
            }
        }

        return expanded;
    }
"""

# For react-tabs (used by developer.fedex.com for language/response
# sample tabs): click each tab and clone its panel into a persistent
# container. React-tabs unmounts the previous panel when you switch,
# so without cloning the content of earlier tabs is lost.
#
# The cloned panels are placed inside a hidden
# <div id="__react_tabs_clones"> and given a data-cloned-tab-id
# attribute matching the original panel's id to deduplicate.
CLONE_REACT_TAB_PANELS_JS = r"""
    () => {
        let cloned = 0;

        let container = document.getElementById('__react_tabs_clones');
        if (!container) {
            container = document.createElement('div');
            container.id = '__react_tabs_clones';
            container.style.display = 'none';
            document.body.appendChild(container);
        }

        const tabLists = document.querySelectorAll(
            '.react-tabs__tab-list, [data-tabs="true"] [role="tablist"]'
        );

        for (const list of tabLists) {
            const tabs = list.querySelectorAll('[role="tab"]');
            for (const tab of tabs) {
                const panelId = tab.getAttribute('aria-controls');
                if (!panelId) continue;

                // Skip if already cloned
                if (container.querySelector(
                    '[data-cloned-tab-id="' + panelId + '"]')) continue;

                try {
                    tab.click();
                } catch (e) { continue; }

                // Small sync wait for React to render
                const start = Date.now();
                while (Date.now() - start < 150) {
                    // busy-wait for React to mount the panel
                }

                const panel = document.getElementById(panelId);
                if (!panel || panel.innerHTML.length < 20) continue;

                const clone = panel.cloneNode(true);
                clone.removeAttribute('id');
                clone.setAttribute('data-cloned-tab-id', panelId);
                const label = (tab.textContent || '').trim();
                if (label) {
                    clone.setAttribute('data-tab-label', label);
                }
                clone.style.display = 'block';
                clone.classList.remove(
                    'react-tabs__tab-panel',
                    'react-tabs__tab-panel--selected'
                );
                container.appendChild(clone);
                cloned += 1;
            }
        }

        return cloned;
    }
"""

# Click every tab-like element exactly once per pass, and report how
# many we clicked so the Python side knows when to stop.
CLICK_ALL_TABS_JS = r"""
    () => {
        const selectors = [
            '[role="tab"]',
            '.slds-tabs_default__item a',
            '.slds-tabs_default__item button',
            '.slds-tabs_scoped__item a',
            '.slds-tabs_scoped__item button',
            '.slds-tabs_medium__item a',
            '.slds-vertical-tabs__nav-item a',
            '.tabs__item',
            '.nav-tabs a',
            '.nav-tabs button',
            '.nav-pills a',
            'ul.tabs > li',
            'ul.nav > li > a',
            'a[data-toggle="tab"]',
            'button[data-toggle="tab"]',
            'a[data-bs-toggle="tab"]',
            'button[data-bs-toggle="tab"]',
            '.react-tabs__tab',
        ];

        function collectClickable(root, attr) {
            const out = [];
            for (const sel of selectors) {
                for (const el of root.querySelectorAll(sel)) {
                    if (el.hasAttribute(attr)) continue;
                    el.setAttribute(attr, '1');
                    out.push(el);
                }
            }
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) {
                    out.push(...collectClickable(el.shadowRoot, attr));
                }
            }
            return out;
        }

        const targets = collectClickable(document, 'data-saver-clicked');
        let clicked = 0;
        for (const el of targets) {
            try {
                el.scrollIntoView({block: 'center', inline: 'center'});
                el.click();
                clicked += 1;
            } catch (e) { /* ignore individual click failures */ }
        }
        return clicked;
    }
"""

# Open every overflow / "More" tab dropdown trigger so its hidden
# items become clickable on the next tab-click pass.
OPEN_OVERFLOW_TRIGGERS_JS = r"""
    () => {
        const selectors = [
            '.slds-tabs_default__overflow-button button',
            '.slds-tabs_scoped__overflow-button button',
            '[class*="overflow"] button',
            'button[aria-haspopup="true"][aria-label*="More" i]',
            'button[aria-haspopup="menu"][aria-label*="More" i]',
            'button[title*="More" i]',
            'a[title*="More" i]',
            'button[aria-label*="More" i]',
            'lightning-button-menu button',
        ];

        function clickAll(root) {
            let n = 0;
            for (const sel of selectors) {
                for (const el of root.querySelectorAll(sel)) {
                    try { el.click(); n += 1; } catch (e) {}
                }
            }
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) n += clickAll(el.shadowRoot);
            }
            return n;
        }
        return clickAll(document);
    }
"""

# Click every menu item inside any open dropdown. These are the
# overflow tab items themselves (e.g. "500 Failures",
# "503 Service Unavailable"). After each click the corresponding
# panel becomes active and renders its content.
CLICK_OVERFLOW_ITEMS_JS = r"""
    () => {
        const selectors = [
            '[role="menuitem"]',
            '[role="option"]',
            'lightning-menu-item',
            'a[data-tab-value]',
            '.slds-dropdown [role="menuitem"]',
            '.slds-dropdown a',
        ];

        function collectItems(root, attr) {
            const out = [];
            for (const sel of selectors) {
                for (const el of root.querySelectorAll(sel)) {
                    if (el.hasAttribute(attr)) continue;
                    el.setAttribute(attr, '1');
                    out.push(el);
                }
            }
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) {
                    out.push(...collectItems(el.shadowRoot, attr));
                }
            }
            return out;
        }

        const items = collectItems(document, 'data-saver-overflow-clicked');
        let n = 0;
        for (const el of items) {
            try { el.click(); n += 1; } catch (e) {}
        }
        return n;
    }
"""

# Close any dropdowns we left hanging open — clicking the body usually
# does it for SLDS. This keeps the saved file looking like the page at
# rest in the browser.
CLOSE_DROPDOWNS_JS = r"""
    () => {
        function closeAll(root) {
            for (const el of root.querySelectorAll(
                '.slds-is-open, [aria-expanded="true"]'
            )) {
                el.classList.remove('slds-is-open');
                if (el.hasAttribute('aria-expanded')) {
                    el.setAttribute('aria-expanded', 'false');
                }
            }
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) closeAll(el.shadowRoot);
            }
        }
        closeAll(document);
        try { document.body.click(); } catch (e) {}
    }
"""

# Strip the temporary attributes we used to dedupe click targets
# across passes — we don't want them in the saved file.
CLEANUP_ATTRS_JS = r"""
    () => {
        function strip(root) {
            for (const el of root.querySelectorAll(
                '[data-saver-clicked], [data-saver-overflow-clicked]'
            )) {
                el.removeAttribute('data-saver-clicked');
                el.removeAttribute('data-saver-overflow-clicked');
            }
            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) strip(el.shadowRoot);
            }
        }
        strip(document);
    }
"""

# Inject (or replace) a <base href="..."> tag at the very top of
# <head> so the saved file's relative URLs (/file-asset-public/…,
# /resource/…, images, stylesheets, fonts, etc.) resolve back to the
# original Salesforce origin when the file is opened in a browser.
# Without this the browser can't load the SLDS stylesheets and the
# table columns collapse to zero width — content is present in the
# DOM but invisible visually.
INJECT_BASE_HREF_JS = r"""
    (baseHref) => {
        let head = document.head;
        if (!head) {
            head = document.createElement('head');
            document.documentElement.insertBefore(
                head, document.documentElement.firstChild
            );
        }
        let base = head.querySelector('base');
        if (!base) {
            base = document.createElement('base');
            head.insertBefore(base, head.firstChild);
        } else if (base !== head.firstChild) {
            head.insertBefore(base, head.firstChild);
        }
        base.setAttribute('href', baseHref);
    }
"""

# Strip restrictive <meta http-equiv> tags that would prevent the
# saved file from loading its cross-origin resources when opened
# locally:
#
#   * Content-Security-Policy — Salesforce sets default-src 'self',
#     which when the document is served from file:// resolves to
#     file:// and blocks every request to the original Salesforce
#     origin (CSS, fonts, images). This is the main reason saved
#     pages render with collapsed columns and broken images even
#     when <base href> is correct.
#   * X-Frame-Options — irrelevant for direct file viewing but can
#     confuse some local-preview tools.
#   * refresh — sometimes used for redirects; stripping is safer.
#
# Returns the count of removed tags so the Python side can log it.
STRIP_RESTRICTIVE_META_JS = r"""
    () => {
        const selectors = [
            'meta[http-equiv="Content-Security-Policy" i]',
            'meta[http-equiv="content-security-policy" i]',
            'meta[http-equiv="X-Frame-Options" i]',
            'meta[http-equiv="refresh" i]',
        ];
        let removed = 0;
        for (const sel of selectors) {
            for (const el of document.querySelectorAll(sel)) {
                el.remove();
                removed += 1;
            }
        }
        return removed;
    }
"""

# Walk every tab panel (light DOM + open Shadow DOMs) and write its
# visible label onto it as a data-tab-label attribute. The companion
# TAB_LABEL_CSS rule then renders that attribute as a header *above*
# the panel's content via a ::before pseudo-element.
#
# Three label-source strategies are tried in order, the first that
# yields a non-empty label wins for a given panel:
#
#   1. (PRIMARY) Hidden label span inside the panel itself.
#      Salesforce stores each tab's label as
#      `<span style="display:none">200 Success</span>` at the end of
#      its own tab panel. This source is the most reliable because
#      it is always present regardless of whether the tab is in the
#      visible tab bar or hidden inside an overflow ("More")
#      dropdown — which matters because the dropdown is closed by
#      _finalize_dom before this step runs, and SLDS removes its
#      menu items from the DOM when it closes, making the tab→panel
#      aria-controls mapping unavailable for overflow tabs.
#
#   2. (FALLBACK) Tab → panel via tab.aria-controls or
#      tab.data-tab-value matching panel.id. Catches non-Salesforce
#      tab implementations (Bootstrap, ARIA, react-tabs, …) where
#      the panel doesn't carry a hidden label of its own.
#
#   3. (FALLBACK) Panel → tab via panel.aria-labelledby pointing to
#      a tab element whose text content is the label. Last resort
#      for templates that put the label only on the tab.
#
# We never overwrite an existing data-tab-label attribute, so each
# panel keeps the label assigned by the first successful strategy.
LABEL_TAB_PANELS_JS = r"""
    () => {
        function findById(root, id) {
            try {
                if (root.getElementById) {
                    const el = root.getElementById(id);
                    if (el) return el;
                }
            } catch (e) {}
            try {
                const safe = id.replace(/(["\\\\])/g, '\\$1');
                const el = root.querySelector('[id="' + safe + '"]');
                if (el) return el;
            } catch (e) {}
            return null;
        }

        function getLabelFromHiddenSpan(panel) {
            // Look at direct child <span>s and one-level-deep
            // <div> > <span>s. We require the span to be explicitly
            // hidden via inline style="display:none" and to carry
            // short text — that pattern uniquely identifies
            // Salesforce's tab label spans without any risk of
            // picking up regular content.
            const candidates = [];
            for (const s of panel.querySelectorAll(':scope > span')) {
                candidates.push(s);
            }
            for (const s of panel.querySelectorAll(':scope > div > span')) {
                candidates.push(s);
            }
            for (const span of candidates) {
                const style = (span.getAttribute('style') || '')
                    .replace(/\s/g, '').toLowerCase();
                if (style.indexOf('display:none') === -1) continue;
                const text = (span.textContent || '').trim()
                    .replace(/\s+/g, ' ');
                if (!text || text.length > 80) continue;
                return text;
            }
            return null;
        }

        function processRoot(root) {
            let labeled = 0;

            const PANEL_SELECTOR =
                '[role="tabpanel"],'
                + ' .slds-tabs_default__content,'
                + ' .slds-tabs_scoped__content,'
                + ' .slds-tabs_medium__content,'
                + ' .slds-tabs_large__content,'
                + ' .tab-pane,'
                + ' .react-tabs__tab-panel';

            // ── Strategy 1: hidden label span inside each panel ──
            for (const panel of root.querySelectorAll(PANEL_SELECTOR)) {
                if (panel.hasAttribute('data-tab-label')) continue;
                const label = getLabelFromHiddenSpan(panel);
                if (label) {
                    panel.setAttribute('data-tab-label', label);
                    labeled += 1;
                }
            }

            // ── Strategy 2: tab → panel via aria-controls / data-tab-value ──
            const tabs = root.querySelectorAll(
                '[role="tab"][aria-controls],'
                + ' [role="menuitem"][aria-controls],'
                + ' [role="menuitem"][data-tab-value],'
                + ' lightning-menu-item[data-tab-value],'
                + ' a[data-tab-value]'
            );
            for (const tab of tabs) {
                const panelId = tab.getAttribute('aria-controls')
                                || tab.getAttribute('data-tab-value');
                if (!panelId) continue;

                let panel = findById(root, panelId);
                if (!panel) panel = findById(document, panelId);
                if (!panel) continue;
                if (panel.hasAttribute('data-tab-label')) continue;

                const label = (tab.textContent || '')
                    .trim().replace(/\s+/g, ' ');
                if (!label) continue;

                panel.setAttribute('data-tab-label', label);
                labeled += 1;
            }

            // ── Strategy 3: panel → tab via aria-labelledby ──
            const linkedPanels = root.querySelectorAll(
                '[role="tabpanel"][aria-labelledby]'
            );
            for (const panel of linkedPanels) {
                if (panel.hasAttribute('data-tab-label')) continue;
                const tabId = panel.getAttribute('aria-labelledby');
                if (!tabId) continue;

                let tab = findById(root, tabId);
                if (!tab) tab = findById(document, tabId);
                if (!tab) continue;

                const label = (tab.textContent || '')
                    .trim().replace(/\s+/g, ' ');
                if (!label) continue;

                panel.setAttribute('data-tab-label', label);
                labeled += 1;
            }

            for (const el of root.querySelectorAll('*')) {
                if (el.shadowRoot) labeled += processRoot(el.shadowRoot);
            }

            return labeled;
        }

        return processRoot(document);
    }
"""


# --------------------------------------------------------------------------- #
#  Logging
# --------------------------------------------------------------------------- #

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("save_webpage_html")


# --------------------------------------------------------------------------- #
#  Helpers
# --------------------------------------------------------------------------- #

def _wait_for_main_content(page: Page) -> None:
    """Best-effort wait for the page's primary content container.

    Tries selectors for both the Salesforce sandbox pages and the
    public ``developer.fedex.com`` portal, and returns as soon as
    any of them resolves. Silently continues on timeout — the
    subsequent settle delay still gives JS a chance to finish.
    """
    candidates = [
        "main",
        "article",
        "[role='main']",
        ".forceCommunityRichText",
        ".cms-content",
        ".comm-layout-column",
        ".caas-body",
        ".developer-content",
        ".api-docs",
        "h1",
        "h2",
        "h3",
    ]
    for selector in candidates:
        try:
            page.wait_for_selector(selector, timeout=8_000, state="attached")
            logger.debug("Main content detected via selector: %s", selector)
            return
        except PlaywrightTimeoutError:
            continue
    logger.warning("No main-content selector matched; proceeding anyway.")


def _dismiss_overlays(page: Page) -> None:
    """Dismiss cookie banners, login modals, and other overlays.

    Some sites (notably ``developer.fedex.com``) show cookie consent
    banners or login/signup modals that can cover interactive elements
    and block tab clicks. This step removes or hides them before tab
    expansion begins.
    """
    try:
        dismissed = page.evaluate(DISMISS_OVERLAYS_JS)
        if dismissed:
            logger.info("Dismissed %d overlay(s) (cookie/login/modal).", dismissed)
    except Exception as exc:
        logger.debug("Overlay dismissal failed: %s", exc)


def _expand_collapsibles(page: Page) -> None:
    """Expand ``<details>``, Bootstrap collapses, and custom accordions.

    Needed for pages like ``developer.fedex.com`` where endpoint
    descriptions or other content sections may live inside
    collapsible containers that are closed by default. Opens them so
    the saved HTML includes their content.
    """
    try:
        expanded = page.evaluate(EXPAND_COLLAPSIBLES_JS)
        if expanded:
            logger.info("Expanded %d collapsible section(s).", expanded)
    except Exception as exc:
        logger.debug("Collapsible expansion failed: %s", exc)


def _expand_redoc_accordions(page: Page) -> None:
    """Click every Redoc-style response accordion header.

    On ``developer.fedex.com`` API doc pages, the "Responses" section
    contains expandable rows like ``> 200 Success``, ``> 400 Bad
    Request``, etc. These are custom styled-components (``sc-*``
    classes) with an SVG chevron — not standard ``<details>`` or
    ``aria-expanded`` elements. Clicking each header reveals the
    response schema content beneath it.
    """
    try:
        expanded = page.evaluate(EXPAND_REDOC_ACCORDIONS_JS)
        if expanded:
            logger.info("Expanded %d Redoc response accordion(s).", expanded)
    except Exception as exc:
        logger.debug("Redoc accordion expansion failed: %s", exc)


def _clone_react_tab_panels(page: Page) -> None:
    """Click each react-tabs tab and clone its panel content.

    ``react-tabs`` (used by ``developer.fedex.com`` for language tabs
    like Payload/C#/JAVA/… and response sample tabs like 200/400/…)
    **unmounts** the inactive panel from the DOM when you switch tabs.
    This means a simple click-through loop leaves only the last-clicked
    panel's content in the DOM.

    This step clicks each tab, waits briefly for React to mount the
    panel, then clones the panel into a persistent hidden container
    (``#__react_tabs_clones``). The clones carry a ``data-tab-label``
    attribute for the CSS ``::before`` header (same approach as the
    Salesforce tab-panel labelling — no impact on chunking).
    """
    try:
        cloned = page.evaluate(CLONE_REACT_TAB_PANELS_JS)
        if cloned:
            logger.info(
                "Cloned %d react-tabs panel(s) into persistent container.",
                cloned,
            )
    except Exception as exc:
        logger.debug("React-tabs panel cloning failed: %s", exc)


def _expand_all_tabs(page: Page) -> None:
    """Iteratively click every tab and overflow item until no new ones appear.

    Multiple passes are required because (a) some pages only render
    later tabs *after* an earlier tab has been activated and (b)
    "More" overflow menus must be opened before their hidden items
    become clickable.
    """
    for pass_no in range(1, MAX_TAB_PASSES + 1):
        try:
            tabs_clicked = page.evaluate(CLICK_ALL_TABS_JS)
        except Exception as exc:
            tabs_clicked = 0
            logger.debug("Tab-click pass %d failed: %s", pass_no, exc)
        page.wait_for_timeout(TAB_CLICK_DELAY_MS)

        try:
            triggers_opened = page.evaluate(OPEN_OVERFLOW_TRIGGERS_JS)
        except Exception as exc:
            triggers_opened = 0
            logger.debug("Overflow-trigger pass %d failed: %s", pass_no, exc)
        page.wait_for_timeout(OVERFLOW_OPEN_DELAY_MS)

        try:
            items_clicked = page.evaluate(CLICK_OVERFLOW_ITEMS_JS)
        except Exception as exc:
            items_clicked = 0
            logger.debug("Overflow-item pass %d failed: %s", pass_no, exc)
        page.wait_for_timeout(TAB_CLICK_DELAY_MS)

        logger.info(
            "Pass %d/%d → tabs clicked: %d | overflow triggers opened: %d "
            "| overflow items clicked: %d",
            pass_no, MAX_TAB_PASSES,
            tabs_clicked, triggers_opened, items_clicked,
        )

        if tabs_clicked == 0 and triggers_opened == 0 and items_clicked == 0:
            logger.info("No new clickables found — stopping early.")
            break


def _finalize_dom(page: Page) -> None:
    """Inject reveal CSS, close dropdowns, and strip temporary attributes."""
    try:
        page.add_style_tag(content=REVEAL_CSS)
    except Exception as exc:
        logger.debug("Reveal-CSS injection failed: %s", exc)

    try:
        page.evaluate(CLOSE_DROPDOWNS_JS)
    except Exception as exc:
        logger.debug("Close-dropdowns step failed: %s", exc)

    try:
        page.evaluate(CLEANUP_ATTRS_JS)
    except Exception as exc:
        logger.debug("Attribute cleanup failed: %s", exc)


def _inject_base_href(page: Page, url: str) -> None:
    """Add a ``<base href>`` tag pointing to *url*'s origin.

    Ensures the saved HTML's relative resource URLs (images,
    stylesheets, fonts, etc.) resolve back to the original site when
    the file is opened locally in a browser.
    """
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        logger.debug("Cannot derive base href from URL: %s", url)
        return
    base_href = f"{parsed.scheme}://{parsed.netloc}/"
    try:
        page.evaluate(INJECT_BASE_HREF_JS, base_href)
        logger.info("Injected <base href=\"%s\"> for offline rendering.", base_href)
    except Exception as exc:
        logger.debug("Base-href injection failed: %s", exc)


def _strip_restrictive_meta(page: Page) -> None:
    """Remove ``<meta http-equiv>`` tags that would block resource loads.

    Salesforce sets a strict ``Content-Security-Policy`` meta tag with
    ``default-src 'self'``. When the saved file is opened from
    ``file://``, ``'self'`` resolves to the local filesystem and the
    browser blocks every request to the original Salesforce origin —
    which means the SLDS stylesheets, fonts, and images all fail to
    load even with a correct ``<base href>``. Stripping the CSP meta
    lets the browser fetch those resources normally.
    """
    try:
        removed = page.evaluate(STRIP_RESTRICTIVE_META_JS)
        if removed:
            logger.info(
                "Stripped %d restrictive <meta http-equiv> tag(s) "
                "(CSP / X-Frame-Options / refresh) for offline rendering.",
                removed,
            )
    except Exception as exc:
        logger.debug("Restrictive-meta stripping failed: %s", exc)


def _label_tab_panels(page: Page) -> None:
    """Stamp each tab panel with its tab's label and inject styling CSS.

    Adds a ``data-tab-label="200 Success"`` attribute to every tab
    panel by reading the visible text of its corresponding tab (via
    ``aria-controls`` / ``data-tab-value``), then injects a CSS rule
    that renders that attribute as a styled header *above* the panel
    content using a ``::before`` pseudo-element.

    Important: pseudo-element content is **not** part of the DOM, so
    BeautifulSoup, Playwright text extraction, ``web_scrapping.py``
    and your downstream chunker do **not** see the new header text.
    The chunking output is therefore byte-for-byte identical to
    before this step ran. Only a human opening the saved file in a
    browser sees the helpful headers.
    """
    try:
        labeled = page.evaluate(LABEL_TAB_PANELS_JS)
    except Exception as exc:
        labeled = 0
        logger.debug("Tab-panel labelling failed: %s", exc)

    try:
        page.add_style_tag(content=TAB_LABEL_CSS)
    except Exception as exc:
        logger.debug("Tab-label CSS injection failed: %s", exc)

    logger.info(
        "Labelled %d tab panel(s) with their tab name "
        "(visible only via CSS — chunking output unchanged).",
        labeled,
    )


# --------------------------------------------------------------------------- #
#  Playwright runner (handles Jupyter / Windows event-loop quirks)
# --------------------------------------------------------------------------- #

def _run_playwright_save(
    url: str,
    output: Path,
    headless: bool,
    timeout_sec: int,
) -> Path:
    """Synchronous Playwright worker — performs the actual download.

    On Windows, Jupyter / IPython swap the default asyncio loop to
    ``SelectorEventLoop``, which cannot launch subprocesses. We
    temporarily restore the ``WindowsProactorEventLoopPolicy`` so
    Playwright can start Chromium, then restore the original policy
    when done.
    """
    original_policy = None
    if sys.platform == "win32":
        original_policy = asyncio.get_event_loop_policy()
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    try:
        logger.info("Launching headless Chromium…")
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=headless)
            context = browser.new_context(
                user_agent=USER_AGENT,
                viewport={"width": 1920, "height": 1080},
                ignore_https_errors=True,
            )
            page = context.new_page()
            page.set_default_timeout(timeout_sec * 1000)

            logger.info("Navigating to %s", url)
            page.goto(url, wait_until="domcontentloaded", timeout=timeout_sec * 1000)

            try:
                page.wait_for_load_state("networkidle", timeout=15_000)
            except PlaywrightTimeoutError:
                logger.warning("networkidle wait timed out — continuing.")

            _wait_for_main_content(page)
            page.wait_for_timeout(RENDER_SETTLE_MS)

            _dismiss_overlays(page)
            _expand_collapsibles(page)
            _expand_redoc_accordions(page)
            _clone_react_tab_panels(page)
            _expand_all_tabs(page)
            _finalize_dom(page)
            _inject_base_href(page, url)
            _strip_restrictive_meta(page)
            _label_tab_panels(page)

            page.wait_for_timeout(500)

            html = page.content()
            output.write_text(html, encoding="utf-8")
            logger.info("Saved %d bytes → %s", len(html), output)

            context.close()
            browser.close()
    finally:
        if original_policy is not None:
            asyncio.set_event_loop_policy(original_policy)

    return output


# --------------------------------------------------------------------------- #
#  Public API
# --------------------------------------------------------------------------- #

def save_webpage_as_html(
    url: str = DEFAULT_URL,
    output_path: str | Path = DEFAULT_OUTPUT,
    *,
    headless: bool = True,
    timeout_sec: int = NAV_TIMEOUT_SEC,
) -> Path:
    """Download *url* as a fully-rendered HTML file (browser-faithful).

    Automatically detects whether an asyncio event loop is already
    running (e.g. inside Jupyter / IPython) and offloads the
    synchronous Playwright call to a worker thread to avoid the
    "Sync API inside the asyncio loop" error.

    Parameters
    ----------
    url:
        The webpage to download.
    output_path:
        File path where the resulting HTML will be written. Parent
        directories are created automatically.
    headless:
        Run Chromium in headless mode (default ``True``). Set to
        ``False`` for visual debugging.
    timeout_sec:
        Maximum time (seconds) to wait for navigation. Defaults to 90.

    Returns
    -------
    pathlib.Path
        Absolute path of the written HTML file.
    """
    output = Path(output_path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    try:
        asyncio.get_running_loop()
        in_async = True
    except RuntimeError:
        in_async = False

    if in_async:
        logger.info(
            "Detected running asyncio loop (Jupyter/IPython) — "
            "running Playwright in a worker thread."
        )
        with ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(
                _run_playwright_save, url, output, headless, timeout_sec
            ).result()

    return _run_playwright_save(url, output, headless, timeout_sec)


# --------------------------------------------------------------------------- #
#  Batch helper
# --------------------------------------------------------------------------- #

_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")
_GENERIC_LAST_SEGMENTS = frozenset({
    "docs", "docs.html", "docs.htm", "index", "index.html", "index.htm",
    "default", "default.html", "page", "page.html",
})


def _safe_filename_from_url(url: str) -> str:
    """Derive a deterministic filesystem-safe filename from a URL.

    Uses the last non-empty path segment (e.g. ``ltl-pickup-docs``)
    and appends ``.html``. Falls back to the URL host if the path is
    empty.

    When the last segment is generic (``docs.html``, ``index.html``,
    etc.) — common on sites like ``developer.fedex.com`` where every
    API doc page ends in ``/v1/docs.html`` — extra path segments are
    prepended to avoid collisions. For example::

        .../catalog/track/v1/docs.html        → track-v1-docs.html
        .../catalog/ltl-freight/v1/docs.html  → ltl-freight-v1-docs.html
    """
    parsed = urlparse(url)
    parts = [p for p in parsed.path.split("/") if p]
    if not parts:
        base = parsed.netloc or "page"
    else:
        last = parts[-1]
        last_lower = last.lower().rsplit(".", 1)[0] if "." in last else last.lower()
        if last_lower in _GENERIC_LAST_SEGMENTS or last.lower() in _GENERIC_LAST_SEGMENTS:
            meaningful = [
                p for p in parts[:-1]
                if p.lower() not in ("api", "en-us", "catalog", "s", "aeh")
            ]
            if meaningful:
                base = "-".join(meaningful[-2:]) + "-" + last
            else:
                base = "-".join(parts[-3:]) if len(parts) >= 3 else last
        else:
            base = last
    base = _SAFE_NAME_RE.sub("-", base).strip("-") or "page"
    if not base.lower().endswith((".html", ".htm")):
        base += ".html"
    return base


def save_many(
    urls: Iterable[str],
    output_dir: str | Path = ".",
    *,
    headless: bool = True,
    timeout_sec: int = NAV_TIMEOUT_SEC,
    continue_on_error: bool = True,
) -> dict[str, Path | str]:
    """Download a list of URLs to ``output_dir``.

    The output filename for each URL is derived from its last path
    segment (``ltl-pickup-docs?language=en_US`` →
    ``ltl-pickup-docs.html``). Existing files are overwritten.

    Parameters
    ----------
    urls:
        Iterable of URLs to download.
    output_dir:
        Directory where ``.html`` files will be written. Created if
        missing.
    headless:
        Forwarded to :func:`save_webpage_as_html`.
    timeout_sec:
        Forwarded to :func:`save_webpage_as_html`.
    continue_on_error:
        If ``True`` (default), errors are logged and the loop
        continues. The returned dict maps URL → ``Path`` (success) or
        ``str`` error message (failure).

    Returns
    -------
    dict[str, pathlib.Path | str]
        Mapping of input URL to output path or error message.
    """
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    results: dict[str, Path | str] = {}
    for url in urls:
        target = out_dir / _safe_filename_from_url(url)
        try:
            results[url] = save_webpage_as_html(
                url, target, headless=headless, timeout_sec=timeout_sec
            )
        except Exception as exc:
            logger.error("Failed to save %s: %s", url, exc)
            results[url] = f"ERROR: {exc}"
            if not continue_on_error:
                raise
    return results


# --------------------------------------------------------------------------- #
#  Command-line entry-point
# --------------------------------------------------------------------------- #

def _parse_cli_args(argv: list[str]) -> tuple[str, str]:
    url = argv[1] if len(argv) > 1 else DEFAULT_URL
    output = argv[2] if len(argv) > 2 else DEFAULT_OUTPUT
    return url, output


def main(argv: Optional[list[str]] = None) -> int:
    argv = list(sys.argv if argv is None else argv)
    url, output = _parse_cli_args(argv)
    try:
        path = save_webpage_as_html(url, output)
    except Exception as exc:
        logger.error("Failed to save webpage: %s", exc)
        return 1
    logger.info("Done. HTML available at: %s", path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
