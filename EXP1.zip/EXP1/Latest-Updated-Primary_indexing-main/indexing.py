"""Azure AI Search indexing operations.

Provides helpers for the full vector-indexing lifecycle:

1. **Index management** — create-if-missing with a local cache to avoid
   redundant REST calls on every event.
2. **Embedding generation** — batched calls to Azure OpenAI with
   exponential-backoff retry.
3. **Chunk blob storage** — persist individual chunks back to Azure Blob
   Storage under a ``chunk-stored/`` prefix.
4. **Document upsert** — upload vector documents to Azure AI Search in
   batches, with automatic index re-creation on ``ResourceNotFoundError``.

All functions are pure helpers that receive their clients / credentials as
arguments — no global state is mutated outside the ``_index_cache`` set
used to skip duplicate ``get_index`` calls.

Environment variables read at import time:
    ``EMBEDDING_BATCH_SIZE`` — number of texts per embedding API call
    (default ``50``).
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any

from azure.core.exceptions import ResourceNotFoundError
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    HnswAlgorithmConfiguration,
    HnswParameters,
    SearchField,
    SearchFieldDataType,
    SearchIndex,
    SemanticConfiguration,
    SemanticField,
    SemanticPrioritizedFields,
    SemanticSearch,
    VectorSearch,
    VectorSearchProfile,
)
from azure.search.documents.models import VectorizedQuery

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
EMBEDDING_BATCH_SIZE = int(os.environ.get("EMBEDDING_BATCH_SIZE", "50"))
UPLOAD_BATCH_SIZE = 1000

# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------
_index_cache: set[str] = set()


def ensure_search_index(
    search_endpoint: str,
    credential,
    index_name: str,
    *,
    vector_dimensions: int = 1536,
    force: bool = False,
) -> None:
    """Verify the Azure AI Search index exists; create it if missing.

    The index schema includes fields for ``id``, ``content``, ``source``,
    ``filename``, ``title``, ``created_date``, and a ``contentVector``
    field configured with HNSW vector search and semantic reranking.

    A module-level cache (``_index_cache``) prevents redundant
    ``get_index`` REST calls after the first successful check within the
    same process.

    Parameters
    ----------
    search_endpoint : str
        Full URL of the Azure AI Search service
        (e.g. ``"https://my-search.search.windows.net"``).
    credential
        An ``AzureKeyCredential`` or token credential (e.g.
        ``DefaultAzureCredential``) authorised for index management.
    index_name : str
        Name of the target search index.
    vector_dimensions : int
        Dimensionality of the embedding vectors (default ``1536`` for
        ``text-embedding-3-small``).
    force : bool
        When ``True``, bypass the local cache and re-check the service.

    Raises
    ------
    Exception
        Propagated from the Azure SDK if index creation fails.
    """
    if not force and index_name in _index_cache:
        return

    index_client = SearchIndexClient(search_endpoint, credential)

    try:
        index_client.get_index(index_name)
        _index_cache.add(index_name)
        logger.info("Index '%s' already exists — proceeding.", index_name)
        return
    except ResourceNotFoundError:
        logger.info("Index '%s' does not exist — creating it now.", index_name)
    except Exception as exc:
        logger.warning(
            "Could not verify index existence, will attempt creation: %s", exc
        )

    fields = [
        SearchField(
            name="id",
            type=SearchFieldDataType.String,
            key=True,
            filterable=True,
        ),
        SearchField(
            name="content",
            type=SearchFieldDataType.String,
            searchable=True,
        ),
        SearchField(
            name="source",
            type=SearchFieldDataType.String,
            filterable=True,
        ),
        SearchField(
            name="filename",
            type=SearchFieldDataType.String,
            filterable=True,
            searchable=True,
        ),
        SearchField(
            name="title",
            type=SearchFieldDataType.String,
            filterable=True,
            searchable=True,
        ),
        SearchField(
            name="created_date",
            type=SearchFieldDataType.DateTimeOffset,
            filterable=True,
            sortable=True,
        ),
        SearchField(
            name="section_heading",
            type=SearchFieldDataType.String,
            searchable=True,
            filterable=True,
        ),
        SearchField(
            name="parent_heading",
            type=SearchFieldDataType.String,
            searchable=True,
            filterable=True,
        ),
        SearchField(
            name="heading_path",
            type=SearchFieldDataType.String,
            searchable=True,
            filterable=True,
        ),
        SearchField(
            name="chunk_index",
            type=SearchFieldDataType.Int32,
            filterable=True,
            sortable=True,
        ),
        SearchField(
            name="contentVector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=vector_dimensions,
            vector_search_profile_name="vector-profile",
        ),
    ]
    vector_search = VectorSearch(
        profiles=[
            VectorSearchProfile(
                name="vector-profile",
                algorithm_configuration_name="hnsw-config",
            )
        ],
        algorithms=[
            HnswAlgorithmConfiguration(
                name="hnsw-config",
                parameters=HnswParameters(
                    m=4,
                    ef_construction=400,
                    ef_search=500,
                    metric="cosine",
                ),
            )
        ],
    )

    semantic_config = SemanticConfiguration(
        name="primary-semantic-config",
        prioritized_fields=SemanticPrioritizedFields(
            title_field=SemanticField(field_name="title"),
            content_fields=[SemanticField(field_name="content")],
            keywords_fields=[SemanticField(field_name="filename")],
        ),
    )
    semantic_search = SemanticSearch(
        default_configuration_name="primary-semantic-config",
        configurations=[semantic_config],
    )

    index = SearchIndex(
        name=index_name,
        fields=fields,
        vector_search=vector_search,
        semantic_search=semantic_search,
    )
    try:
        index_client.create_or_update_index(index)
        _index_cache.add(index_name)
        logger.info("Index '%s' created successfully.", index_name)
    except Exception as exc:
        _index_cache.discard(index_name)
        logger.error("Error creating index: %s", exc)
        raise


def invalidate_index_cache(index_name: str) -> None:
    """Remove *index_name* from the local cache.

    After invalidation the next :func:`ensure_search_index` call will
    re-query the Azure AI Search service to verify existence.

    Parameters
    ----------
    index_name : str
        Name of the index to remove from the cache.
    """
    _index_cache.discard(index_name)


# ---------------------------------------------------------------------------
# Embeddings — batched with retry
# ---------------------------------------------------------------------------


def get_embeddings_batched(
    client,
    texts: list[str],
    model: str = "text-embedding-3-small",
    *,
    batch_size: int | None = None,
    max_retries: int = 3,
) -> list[list[float] | None]:
    """Generate embeddings for *texts* in batches via Azure OpenAI.

    Texts are split into batches of ``batch_size`` (default from
    ``EMBEDDING_BATCH_SIZE`` env var) and sent to the Azure OpenAI
    embeddings endpoint.  Transient failures are retried up to
    *max_retries* times with exponential back-off (2^attempt seconds).

    Parameters
    ----------
    client : openai.AzureOpenAI
        An authenticated Azure OpenAI client.
    texts : list[str]
        Texts to embed.  Order is preserved in the output.
    model : str
        Deployment name of the embedding model.
    batch_size : int | None
        Texts per API call.  ``None`` uses ``EMBEDDING_BATCH_SIZE``.
    max_retries : int
        Maximum retry attempts per batch before raising.

    Returns
    -------
    list[list[float] | None]
        Embedding vectors aligned with *texts*.  A slot is ``None``
        only if its batch was never successfully processed (should not
        happen unless ``max_retries`` is 0).

    Raises
    ------
    Exception
        Re-raised from the Azure OpenAI SDK after exhausting retries.
    """
    if batch_size is None:
        batch_size = EMBEDDING_BATCH_SIZE

    all_embeddings: list[Any] = [None] * len(texts)

    for batch_start in range(0, len(texts), batch_size):
        batch_texts = texts[batch_start : batch_start + batch_size]

        for attempt in range(max_retries):
            try:
                response = client.embeddings.create(
                    input=batch_texts, model=model
                )
                for item in response.data:
                    all_embeddings[batch_start + item.index] = item.embedding
                break
            except Exception:
                if attempt < max_retries - 1:
                    time.sleep(2**attempt)
                    continue
                raise

    return all_embeddings


# ---------------------------------------------------------------------------
# Chunk blob storage
# ---------------------------------------------------------------------------


def _cleanup_old_chunks(
    blob_service_client,
    container_name: str,
    chunk_folder: str,
) -> int:
    """Delete all existing chunk blobs under *chunk_folder*.

    Prevents stale chunks from a previous run from lingering when the
    new run produces fewer chunks than the old one.

    Returns the number of blobs deleted.
    """
    container_client = blob_service_client.get_container_client(container_name)
    old_blobs = list(
        container_client.list_blobs(name_starts_with=f"{chunk_folder}/")
    )
    deleted = 0
    for blob in old_blobs:
        try:
            container_client.delete_blob(blob.name)
            deleted += 1
        except Exception:
            logger.warning("Failed to delete stale chunk blob: %s", blob.name)
    if deleted:
        logger.info(
            "Cleaned up %d stale chunk(s) from %s/", deleted, chunk_folder
        )
    return deleted


def store_chunks_to_blob(
    blob_service_client,
    container_name: str,
    blob_path: str,
    chunks: list,
) -> str:
    """Persist each chunk as a separate blob under ``chunk-stored/``.

    Cleans up any stale chunks from a previous run before writing,
    then writes chunks as UTF-8 text files named ``chunk_0.txt``,
    ``chunk_1.txt``, etc., mirroring the original blob's directory
    structure under the ``chunk-stored/`` prefix.

    Parameters
    ----------
    blob_service_client : BlobServiceClient
        An authenticated Azure Blob Storage client.
    container_name : str
        Name of the blob container.
    blob_path : str
        Original blob path (e.g. ``"input-files/reports/q1.pdf"``).
        The ``"input-files/"`` prefix is stripped for the output path.
    chunks : list
        List of chunk texts (str) or dicts to store.

    Returns
    -------
    str
        The folder path where chunks were written
        (e.g. ``"chunk-stored/reports/q1"``).
    """
    rel_path = (
        blob_path.replace("input-files/", "", 1)
        if blob_path.startswith("input-files/")
        else blob_path
    )
    dir_part = os.path.dirname(rel_path)
    base_no_ext = os.path.splitext(os.path.basename(rel_path))[0]
    chunk_folder = (
        f"chunk-stored/{dir_part}/{base_no_ext}"
        if dir_part
        else f"chunk-stored/{base_no_ext}"
    )

    _cleanup_old_chunks(blob_service_client, container_name, chunk_folder)

    for idx, ch in enumerate(chunks):
        chunk_blob_path = f"{chunk_folder}/chunk_{idx}.txt"
        chunk_client = blob_service_client.get_blob_client(
            container=container_name, blob=chunk_blob_path
        )
        chunk_text = json.dumps(ch) if isinstance(ch, dict) else str(ch)
        chunk_client.upload_blob(chunk_text.encode("utf-8"), overwrite=True)

    logger.info("Stored %d chunks to %s/", len(chunks), chunk_folder)
    return chunk_folder


# ---------------------------------------------------------------------------
# Document upsert
# ---------------------------------------------------------------------------


def delete_documents_for_file(
    search_client: SearchClient,
    filename: str,
    *,
    batch_size: int = UPLOAD_BATCH_SIZE,
) -> int:
    """Delete all existing index documents that belong to *filename*.

    Searches for documents matching the filename and deletes them in
    batches.  This ensures re-indexing a file does not leave ghost
    documents from a previous run that had a different chunk count.

    Returns the number of documents deleted.
    """
    doc_id_prefix = re.sub(r"[^a-zA-Z0-9_-]", "_", filename)
    try:
        results = search_client.search(
            search_text="*",
            filter=f"filename eq '{filename}'",
            select=["id"],
            top=5000,
        )
        ids_to_delete = [{"id": doc["id"]} for doc in results]
    except Exception:
        logger.debug(
            "Filter search for filename=%r failed; falling back to id-prefix scan.",
            filename,
        )
        ids_to_delete = []

    if not ids_to_delete:
        return 0

    deleted = 0
    for i in range(0, len(ids_to_delete), batch_size):
        batch = ids_to_delete[i : i + batch_size]
        try:
            result = search_client.delete_documents(batch)
            deleted += sum(1 for r in result if r.succeeded)
        except Exception as exc:
            logger.warning("Failed to delete document batch: %s", exc)
    if deleted:
        logger.info(
            "Deleted %d old document(s) for file '%s' before re-indexing.",
            deleted, filename,
        )
    return deleted


def upsert_documents(
    search_client: SearchClient,
    search_endpoint: str,
    credential,
    index_name: str,
    documents: list[dict],
    *,
    batch_size: int = UPLOAD_BATCH_SIZE,
) -> int:
    """Upload *documents* to Azure AI Search in batches.

    If the index has been deleted externally (``ResourceNotFoundError``),
    it is automatically recreated via :func:`ensure_search_index` and the
    full upload is retried.

    Parameters
    ----------
    search_client : SearchClient
        An authenticated client for the target search index.
    search_endpoint : str
        Full URL of the Azure AI Search service (needed for index
        re-creation on ``ResourceNotFoundError``).
    credential
        Credential for index management (same as passed to
        :func:`ensure_search_index`).
    index_name : str
        Name of the target search index.
    documents : list[dict]
        List of document dicts to upload (each must include an ``"id"``
        key matching the index schema).
    batch_size : int
        Number of documents per upload call (default ``1000``).

    Returns
    -------
    int
        Total number of documents successfully uploaded.
    """
    total_succeeded = 0
    try:
        for i in range(0, len(documents), batch_size):
            batch = documents[i : i + batch_size]
            result = search_client.upload_documents(batch)
            total_succeeded += sum(1 for r in result if r.succeeded)
    except ResourceNotFoundError:
        logger.warning(
            "Index '%s' was not found (may have been deleted externally). "
            "Recreating index and retrying upload...",
            index_name,
        )
        invalidate_index_cache(index_name)
        ensure_search_index(
            search_endpoint, credential, index_name, force=True
        )
        search_client = SearchClient(
            search_endpoint, index_name, credential=credential
        )
        total_succeeded = 0
        for i in range(0, len(documents), batch_size):
            batch = documents[i : i + batch_size]
            result = search_client.upload_documents(batch)
            total_succeeded += sum(1 for r in result if r.succeeded)

    return total_succeeded


def build_search_documents(
    chunk_texts: list[str],
    embeddings: list[list[float] | None],
    blob_name: str,
    source_url: str,
    *,
    title: str | None = None,
    created_date: str | None = None,
    chunk_metadata: list[dict] | None = None,
) -> list[dict]:
    """Build a list of Azure AI Search document dicts from chunks and embeddings.

    Each document receives a unique ``id`` derived from ``blob_name``
    (non-alphanumeric characters replaced with ``_``) suffixed with the
    chunk index.

    Parameters
    ----------
    chunk_texts : list[str]
        Ordered list of chunk text strings.
    embeddings : list[list[float] | None]
        Embedding vectors aligned with *chunk_texts*.
    blob_name : str
        Original file name (used for the ``filename`` and ``id`` fields).
    source_url : str
        Full blob URL stored in the ``source`` field.
    title : str | None
        Document title extracted from file metadata (optional).
    created_date : str | None
        ISO-8601 datetime string for the document creation date (optional).
    chunk_metadata : list[dict] | None
        Per-chunk metadata dicts aligned with *chunk_texts*.  Each dict
        may contain ``section_heading``, ``parent_heading``,
        ``heading_path``, and ``chunk_index`` keys from context-aware
        chunking.  ``None`` omits these fields.

    Returns
    -------
    list[dict]
        Documents ready for :func:`upsert_documents`.
    """
    doc_id = re.sub(r"[^a-zA-Z0-9_-]", "_", blob_name)
    documents = []
    for idx in range(len(chunk_texts)):
        doc = {
            "id": f"{doc_id}_{idx}",
            "content": chunk_texts[idx],
            "source": source_url,
            "filename": blob_name,
            "contentVector": embeddings[idx],
        }
        if title:
            doc["title"] = title
        if created_date:
            doc["created_date"] = created_date

        if chunk_metadata and idx < len(chunk_metadata):
            meta = chunk_metadata[idx]
            for key in ("section_heading", "parent_heading", "heading_path"):
                val = meta.get(key, "")
                if val:
                    doc[key] = val
            if "chunk_index" in meta:
                doc["chunk_index"] = meta["chunk_index"]

        documents.append(doc)
    return documents


# ---------------------------------------------------------------------------
# Hybrid search + semantic reranking
# ---------------------------------------------------------------------------

DEFAULT_SEMANTIC_CONFIG = "primary-semantic-config"


def hybrid_search(
    search_client: SearchClient,
    query: str,
    query_vector: list[float],
    *,
    top: int = 5,
    vector_field: str = "contentVector",
    semantic_configuration: str = DEFAULT_SEMANTIC_CONFIG,
    select: list[str] | None = None,
    filters: str | None = None,
    query_caption: str = "extractive",
    query_answer: str = "extractive",
) -> list[dict]:
    """Run a hybrid search (keyword + vector) with semantic reranking.

    Combines full-text BM25 scoring on ``content`` with vector
    similarity on ``contentVector``, then applies Azure AI Search
    semantic reranker to re-score and surface the most relevant results.

    Parameters
    ----------
    search_client:
        An initialised ``SearchClient`` for the target index.
    query:
        Natural-language search query (used for both keyword and
        semantic reranking).
    query_vector:
        Embedding vector of the query (same model used at index time).
    top:
        Maximum number of results to return (default 5).
    vector_field:
        Name of the vector field in the index.
    semantic_configuration:
        Name of the semantic configuration on the index.
    select:
        Fields to include in results.  ``None`` returns all fields.
    filters:
        OData ``$filter`` expression (e.g. ``"filename eq 'report.pdf'"``)
    query_caption:
        Caption type — ``"extractive"`` (default) or ``"none"``.
    query_answer:
        Answer type  — ``"extractive"`` (default) or ``"none"``.

    Returns
    -------
    list[dict]
        Each dict contains the selected fields plus ``@search.score``,
        ``@search.reranker_score``, and ``@search.captions`` when
        available.
    """
    if select is None:
        select = [
            "id", "content", "source", "filename", "title", "created_date",
            "section_heading", "parent_heading", "heading_path", "chunk_index",
        ]

    vector_query = VectorizedQuery(
        vector=query_vector,
        k_nearest_neighbors=top,
        fields=vector_field,
    )

    results = search_client.search(
        search_text=query,
        vector_queries=[vector_query],
        select=select,
        filter=filters,
        query_type="semantic",
        semantic_configuration_name=semantic_configuration,
        query_caption=query_caption,
        query_answer=query_answer,
        top=top,
    )

    output: list[dict] = []
    for result in results:
        doc = {field: result.get(field) for field in select}
        doc["@search.score"] = result.get("@search.score")
        doc["@search.reranker_score"] = result.get("@search.reranker_score")

        captions = result.get("@search.captions")
        if captions:
            doc["@search.captions"] = [
                {"text": c.text, "highlights": c.highlights}
                for c in captions
            ]

        output.append(doc)

    return output
