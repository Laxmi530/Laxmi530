"""
Salesforce Lightning (SLDS) handling for the Web Scraper.

This module isolates the Salesforce Lightning-specific browser
interaction code that was previously embedded in
``web_scrapping.py``.  It is imported and used by
``WebScraper`` during the dynamic-content expansion phase
(``_expand_all_content``).

Public API
----------
capture_slds_tab_groups(page) -> None
    Click every tab in every SLDS (Salesforce Lightning) tab group
    so the lazy-rendered panel content is materialised in the DOM
    before HTML extraction.

The behaviour and logic are identical to the original
``WebScraper._capture_slds_tab_groups`` static method — this file
exists purely to keep ``web_scrapping.py`` smaller and to group
all SLDS-specific logic in one place.
"""

from __future__ import annotations


def capture_slds_tab_groups(page) -> None:
    """Click every tab in every SLDS (Salesforce Lightning) tab group
    to trigger lazy content rendering.

    Only *clicks* tabs — does **not** clone panels.  The subsequent
    ``_FORCE_REVEAL_JS`` call (Step 3) makes all panels visible in
    the original DOM, so cloning is unnecessary and would cause
    duplicate output.

    Also marks each ``lightning-tab-bar`` with
    ``data-scraper-slds-handled`` so ``_capture_all_tab_panels``
    skips these already-processed groups.
    """
    group_count = page.evaluate(r'''() => {
        const containers = document.querySelectorAll(
            '.slds-tabs_default.js-tabset,'
            + ' .slds-tabs_scoped.js-tabset'
        );
        let idx = 0;
        containers.forEach(c => {
            c.setAttribute('data-scraper-slds-group', '' + idx);
            idx++;
        });
        return idx;
    }''')

    if group_count == 0:
        return

    for gi in range(group_count):
        gis = str(gi)

        # ── Visible tabs: click each to trigger rendering ─
        tab_values = page.evaluate(r'''(gi) => {
            const c = document.querySelector(
                '[data-scraper-slds-group="' + gi + '"]'
            );
            if (!c) return [];
            const bar = c.querySelector('lightning-tab-bar');
            if (!bar || !bar.shadowRoot) return [];
            const result = [];
            bar.shadowRoot.querySelectorAll(
                'a[role="tab"][data-tab-value]'
            ).forEach(a => {
                result.push(a.getAttribute('data-tab-value'));
            });
            return result;
        }''', gis)

        for tv in tab_values:
            try:
                page.evaluate(r'''([gi, tv]) => {
                    const c = document.querySelector(
                        '[data-scraper-slds-group="' + gi + '"]'
                    );
                    if (!c) return;
                    const bar = c.querySelector('lightning-tab-bar');
                    if (!bar || !bar.shadowRoot) return;
                    const a = bar.shadowRoot.querySelector(
                        'a[data-tab-value="' + tv + '"]'
                    );
                    if (a) a.click();
                }''', [gis, tv])
                page.wait_for_timeout(800)
            except Exception:
                continue

        # ── Overflow / "More" tabs ────────────────────────
        overflow_names = page.evaluate(r'''(gi) => {
            const c = document.querySelector(
                '[data-scraper-slds-group="' + gi + '"]'
            );
            if (!c) return [];
            const bar = c.querySelector('lightning-tab-bar');
            if (!bar || !bar.shadowRoot) return [];
            const ovLi = bar.shadowRoot.querySelector('[data-overflow]');
            if (!ovLi) return [];
            const menu = ovLi.querySelector('lightning-button-menu');
            if (!menu || !menu.shadowRoot) return [];
            const btn = menu.shadowRoot.querySelector('button');
            if (btn) btn.click();
            const names = [];
            menu.querySelectorAll('lightning-menu-item').forEach(mi => {
                const sel = mi.getAttribute(
                    'data-target-selection-name') || '';
                if (sel) names.push(sel);
            });
            return names;
        }''', gis)

        if not overflow_names:
            # Mark tab bar as handled even if no overflow
            page.evaluate(r'''(gi) => {
                const c = document.querySelector(
                    '[data-scraper-slds-group="' + gi + '"]'
                );
                if (!c) return;
                const bar = c.querySelector('lightning-tab-bar');
                if (bar) bar.setAttribute(
                    'data-scraper-slds-handled', 'true');
            }''', gis)
            continue

        page.wait_for_timeout(500)

        for sel_name in overflow_names:
            try:
                page.evaluate(r'''([gi, selName]) => {
                    const c = document.querySelector(
                        '[data-scraper-slds-group="' + gi + '"]'
                    );
                    if (!c) return;
                    const bar = c.querySelector('lightning-tab-bar');
                    if (!bar || !bar.shadowRoot) return;
                    const ovLi = bar.shadowRoot.querySelector(
                        '[data-overflow]');
                    if (!ovLi) return;
                    const menu = ovLi.querySelector(
                        'lightning-button-menu');
                    if (!menu) return;
                    const item = menu.querySelector(
                        '[data-target-selection-name="'
                        + selName + '"]');
                    if (item) item.click();
                }''', [gis, sel_name])

                page.wait_for_timeout(800)

                # Re-open overflow menu for next item
                page.evaluate(r'''(gi) => {
                    const c = document.querySelector(
                        '[data-scraper-slds-group="' + gi + '"]'
                    );
                    if (!c) return;
                    const bar = c.querySelector('lightning-tab-bar');
                    if (!bar || !bar.shadowRoot) return;
                    const ovLi = bar.shadowRoot.querySelector(
                        '[data-overflow]');
                    if (!ovLi) return;
                    const menu = ovLi.querySelector(
                        'lightning-button-menu');
                    if (!menu || !menu.shadowRoot) return;
                    const btn = menu.shadowRoot.querySelector('button');
                    if (btn) btn.click();
                }''', gis)

                page.wait_for_timeout(500)
            except Exception:
                continue

        # Mark this group's tab bar as handled
        page.evaluate(r'''(gi) => {
            const c = document.querySelector(
                '[data-scraper-slds-group="' + gi + '"]'
            );
            if (!c) return;
            const bar = c.querySelector('lightning-tab-bar');
            if (bar) bar.setAttribute(
                'data-scraper-slds-handled', 'true');
        }''', gis)
