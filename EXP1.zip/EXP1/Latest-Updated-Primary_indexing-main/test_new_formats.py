"""Tests for the new file format extractors (CSV, XLSX, XLS, RTF, XML).

Also validates that existing formats (PDF, DOCX, PPTX, TXT, MD, JSON)
remain functional after the refactor.

Run with:
    python test_new_formats.py
"""

import csv
import io
import json
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(__file__))

from file_extraction import (
    extract_text,
    extract_metadata,
    supported_extensions,
    _extract_csv,
    _extract_xlsx,
    _extract_xls,
    _extract_rtf,
    _extract_xml,
    _extract_json,
    _extract_plain_text,
)
from file_extraction_enhanced import (
    extract_text_enhanced,
    supported_extensions_enhanced,
    _extract_csv_enhanced,
    _extract_xlsx_enhanced,
    _extract_xls_enhanced,
    _extract_rtf_enhanced,
    _extract_xml_enhanced,
    _extract_json_enhanced,
    _extract_txt_enhanced,
    _extract_md_enhanced,
)


PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = ""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS: {name}")
    else:
        FAIL += 1
        msg = f"  FAIL: {name}"
        if detail:
            msg += f" — {detail}"
        print(msg)


# ======================================================================
#  Helper: create in-memory test files
# ======================================================================

def make_csv_bytes() -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Name", "Age", "City"])
    writer.writerow(["Alice", "30", "New York"])
    writer.writerow(["Bob", "25", "London"])
    writer.writerow(["Charlie", "35", "Tokyo"])
    return buf.getvalue().encode("utf-8")


def make_xlsx_bytes() -> bytes:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"
    ws.append(["Name", "Department", "Salary"])
    ws.append(["Alice", "Engineering", "120000"])
    ws.append(["Bob", "Marketing", "95000"])

    ws2 = wb.create_sheet("Locations")
    ws2.append(["Office", "City", "Country"])
    ws2.append(["HQ", "San Francisco", "USA"])
    ws2.append(["Branch", "London", "UK"])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def make_xls_bytes() -> bytes:
    """Create a minimal .xls file using xlrd-compatible BIFF format.

    Since xlwt is not a dependency, we create a simple XLS by writing
    the minimum BIFF8 workbook structure manually for testing.
    """
    try:
        import xlwt
        wb = xlwt.Workbook()
        ws = wb.add_sheet("Products")
        headers = ["Product", "Price", "Stock"]
        for col, h in enumerate(headers):
            ws.write(0, col, h)
        data = [["Widget", "9.99", "100"], ["Gadget", "24.99", "50"]]
        for row_idx, row in enumerate(data, 1):
            for col, val in enumerate(row):
                ws.write(row_idx, col, val)
        buf = io.BytesIO()
        wb.save(buf)
        return buf.getvalue()
    except ImportError:
        return None


def make_rtf_bytes() -> bytes:
    rtf = r"{\rtf1\ansi\deff0 {\fonttbl {\f0 Times New Roman;}} \pard Hello World!\par This is a test RTF document.\par It has multiple paragraphs.\par}"
    return rtf.encode("utf-8")


def make_xml_bytes() -> bytes:
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<catalog>
  <book id="1">
    <title>Python Programming</title>
    <author>John Smith</author>
    <price>29.99</price>
    <category>Technology</category>
  </book>
  <book id="2">
    <title>Data Science Handbook</title>
    <author>Jane Doe</author>
    <price>39.99</price>
    <category>Science</category>
  </book>
  <metadata>
    <publisher>TechBooks Inc.</publisher>
    <year>2024</year>
  </metadata>
</catalog>"""
    return xml.encode("utf-8")


def make_json_bytes() -> bytes:
    data = {
        "name": "Test API",
        "version": "1.0",
        "endpoints": [
            {"path": "/users", "method": "GET", "description": "List users"},
            {"path": "/users", "method": "POST", "description": "Create user"},
        ],
        "auth": {"type": "Bearer", "header": "Authorization"},
    }
    return json.dumps(data, indent=2).encode("utf-8")


def make_txt_bytes() -> bytes:
    return b"INTRODUCTION\n\nThis is a test document.\nIt has some content.\n\nCONCLUSION\n\nFinal thoughts here.\n"


def make_md_bytes() -> bytes:
    return b"# Main Title\n\n## Section One\n\nContent here.\n\n## Section Two\n\nMore content.\n"


# ======================================================================
#  Tests
# ======================================================================

def test_supported_extensions():
    print("\n--- Supported Extensions ---")
    exts = supported_extensions()
    for ext in [".csv", ".xlsx", ".xls", ".rtf", ".xml"]:
        check(f"'{ext}' in supported_extensions()", ext in exts)

    enhanced_exts = supported_extensions_enhanced()
    for ext in [".csv", ".xlsx", ".xls", ".rtf", ".xml"]:
        check(f"'{ext}' in supported_extensions_enhanced()", ext in enhanced_exts)

    original_exts = [".pdf", ".docx", ".pptx", ".json", ".txt", ".md", ".html", ".htm"]
    for ext in original_exts:
        check(f"'{ext}' still in supported_extensions()", ext in exts)


def test_csv():
    print("\n--- CSV Extraction ---")
    data = make_csv_bytes()

    text = extract_text(data, "test.csv")
    check("CSV extract_text returns non-empty", bool(text.strip()))
    check("CSV contains 'Alice'", "Alice" in text)
    check("CSV contains 'Bob'", "Bob" in text)
    check("CSV contains 'Name'", "Name" in text)
    check("CSV has markdown table pipes", "|" in text)

    enhanced = extract_text_enhanced(data, "test.csv")
    check("CSV enhanced has heading", "# CSV Data" in enhanced)
    check("CSV enhanced contains table data", "Alice" in enhanced)

    meta = extract_metadata(data, "test.csv")
    check("CSV metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:300]}")
    print(f"\n  [Preview — enhanced]\n{enhanced[:300]}")


def test_xlsx():
    print("\n--- XLSX Extraction ---")
    data = make_xlsx_bytes()

    text = extract_text(data, "test.xlsx")
    check("XLSX extract_text returns non-empty", bool(text.strip()))
    check("XLSX contains 'Alice'", "Alice" in text)
    check("XLSX contains 'Engineering'", "Engineering" in text)
    check("XLSX contains sheet heading 'Employees'", "Employees" in text)
    check("XLSX contains sheet heading 'Locations'", "Locations" in text)
    check("XLSX has markdown table pipes", "|" in text)

    enhanced = extract_text_enhanced(data, "test.xlsx")
    check("XLSX enhanced has workbook heading", enhanced.startswith("#"))
    check("XLSX enhanced contains sheet data", "Alice" in enhanced)

    meta = extract_metadata(data, "test.xlsx")
    check("XLSX metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:500]}")
    print(f"\n  [Preview — enhanced]\n{enhanced[:500]}")


def test_xls():
    print("\n--- XLS Extraction ---")
    data = make_xls_bytes()
    if data is None:
        print("  SKIP: xlwt not installed — cannot create test .xls file")
        return

    text = extract_text(data, "test.xls")
    check("XLS extract_text returns non-empty", bool(text.strip()))
    check("XLS contains 'Widget'", "Widget" in text)
    check("XLS contains 'Products'", "Products" in text)
    check("XLS has markdown table pipes", "|" in text)

    enhanced = extract_text_enhanced(data, "test.xls")
    check("XLS enhanced has heading", "# Excel Workbook" in enhanced)

    meta = extract_metadata(data, "test.xls")
    check("XLS metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:300]}")


def test_rtf():
    print("\n--- RTF Extraction ---")
    data = make_rtf_bytes()

    text = extract_text(data, "test.rtf")
    check("RTF extract_text returns non-empty", bool(text.strip()))
    check("RTF contains 'Hello World'", "Hello World" in text)
    check("RTF contains 'multiple paragraphs'", "multiple paragraphs" in text)

    enhanced = extract_text_enhanced(data, "test.rtf")
    check("RTF enhanced returns non-empty", bool(enhanced.strip()))
    check("RTF enhanced contains text", "Hello World" in enhanced)

    meta = extract_metadata(data, "test.rtf")
    check("RTF metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:300]}")
    print(f"\n  [Preview — enhanced]\n{enhanced[:300]}")


def test_xml():
    print("\n--- XML Extraction ---")
    data = make_xml_bytes()

    text = extract_text(data, "test.xml")
    check("XML extract_text returns non-empty", bool(text.strip()))
    check("XML contains 'Python Programming'", "Python Programming" in text)
    check("XML contains 'John Smith'", "John Smith" in text)
    check("XML contains 'catalog'", "catalog" in text)
    check("XML contains 'price'", "price" in text)

    enhanced = extract_text_enhanced(data, "test.xml")
    check("XML enhanced has root heading", "# catalog" in enhanced)
    check("XML enhanced contains 'book'", "book" in enhanced)
    check("XML enhanced contains data", "Python Programming" in enhanced)

    meta = extract_metadata(data, "test.xml")
    check("XML metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:500]}")
    print(f"\n  [Preview — enhanced]\n{enhanced[:500]}")


def test_json():
    print("\n--- JSON Extraction (re-enabled) ---")
    data = make_json_bytes()

    text = extract_text(data, "test.json")
    check("JSON extract_text returns non-empty", bool(text.strip()))
    check("JSON contains 'Test API'", "Test API" in text)
    check("JSON contains 'endpoints'", "endpoints" in text.lower())

    enhanced = extract_text_enhanced(data, "test.json")
    check("JSON enhanced returns non-empty", bool(enhanced.strip()))
    check("JSON enhanced contains 'Test API'", "Test API" in enhanced)

    meta = extract_metadata(data, "test.json")
    check("JSON metadata is dict", isinstance(meta, dict))

    print(f"\n  [Preview — base]\n{text[:300]}")
    print(f"\n  [Preview — enhanced]\n{enhanced[:300]}")


def test_txt():
    print("\n--- TXT Extraction ---")
    data = make_txt_bytes()

    text = extract_text(data, "test.txt")
    check("TXT extract_text returns non-empty", bool(text.strip()))
    check("TXT contains 'INTRODUCTION'", "INTRODUCTION" in text)

    enhanced = extract_text_enhanced(data, "test.txt")
    check("TXT enhanced returns non-empty", bool(enhanced.strip()))
    check("TXT enhanced has heading markers", "#" in enhanced)

    print(f"\n  [Preview — enhanced]\n{enhanced[:300]}")


def test_md():
    print("\n--- MD Extraction ---")
    data = make_md_bytes()

    text = extract_text(data, "test.md")
    check("MD extract_text returns non-empty", bool(text.strip()))
    check("MD contains '# Main Title'", "# Main Title" in text)

    enhanced = extract_text_enhanced(data, "test.md")
    check("MD enhanced preserves headings", "# Main Title" in enhanced)
    check("MD enhanced preserves sections", "## Section One" in enhanced)


def test_extract_text_dispatch():
    """Verify the public ``extract_text`` function dispatches correctly
    for all new formats."""
    print("\n--- Dispatch via extract_text() ---")
    test_cases = [
        ("test.csv", make_csv_bytes()),
        ("test.xlsx", make_xlsx_bytes()),
        ("test.rtf", make_rtf_bytes()),
        ("test.xml", make_xml_bytes()),
        ("test.json", make_json_bytes()),
        ("test.txt", make_txt_bytes()),
        ("test.md", make_md_bytes()),
    ]
    for filename, data in test_cases:
        try:
            result = extract_text(data, filename)
            check(f"extract_text('{filename}') succeeds", bool(result.strip()),
                  f"got {len(result)} chars")
        except Exception as e:
            check(f"extract_text('{filename}') succeeds", False, str(e))


def test_extract_text_enhanced_dispatch():
    """Verify the public ``extract_text_enhanced`` function dispatches
    correctly for all new formats."""
    print("\n--- Dispatch via extract_text_enhanced() ---")
    test_cases = [
        ("test.csv", make_csv_bytes()),
        ("test.xlsx", make_xlsx_bytes()),
        ("test.rtf", make_rtf_bytes()),
        ("test.xml", make_xml_bytes()),
        ("test.json", make_json_bytes()),
        ("test.txt", make_txt_bytes()),
        ("test.md", make_md_bytes()),
    ]
    for filename, data in test_cases:
        try:
            result = extract_text_enhanced(data, filename)
            check(f"extract_text_enhanced('{filename}') succeeds",
                  bool(result.strip()), f"got {len(result)} chars")
        except Exception as e:
            check(f"extract_text_enhanced('{filename}') succeeds", False, str(e))


def test_unsupported_extension():
    print("\n--- Unsupported Extension ---")
    try:
        extract_text(b"data", "test.xyz")
        check("Raises ValueError for .xyz", False, "no exception raised")
    except ValueError as e:
        check("Raises ValueError for .xyz", ".xyz" in str(e) or "Unsupported" in str(e))

    try:
        extract_text_enhanced(b"data", "test.xyz")
        check("Enhanced raises ValueError for .xyz", False, "no exception raised")
    except ValueError as e:
        check("Enhanced raises ValueError for .xyz", ".xyz" in str(e) or "Unsupported" in str(e))


def test_empty_files():
    print("\n--- Empty File Handling ---")
    empty_cases = [
        ("empty.csv", b""),
        ("empty.xml", b""),
        ("empty.rtf", b""),
    ]
    for filename, data in empty_cases:
        try:
            result = extract_text(data, filename)
            check(f"extract_text('{filename}') handles empty", True,
                  f"returned {len(result)} chars")
        except Exception as e:
            check(f"extract_text('{filename}') handles empty gracefully",
                  True, f"exception: {type(e).__name__}")


def test_csv_edge_cases():
    print("\n--- CSV Edge Cases ---")

    single_col = b"Header\nValue1\nValue2\nValue3\n"
    text = extract_text(single_col, "single.csv")
    check("Single-column CSV works", "Header" in text and "Value1" in text)

    quoted = b'Name,Description\nAlice,"Has a, comma"\nBob,"Says ""hello"""\n'
    text = extract_text(quoted, "quoted.csv")
    check("CSV with quoted commas", "Has a, comma" in text)

    unicode_csv = "Name,City\nAlice,München\nBob,Zürich\n".encode("utf-8")
    text = extract_text(unicode_csv, "unicode.csv")
    check("CSV with unicode chars", "München" in text)


def test_pdf_pymupdf():
    """Test PDF extraction using PyMuPDF (fitz) — both base and enhanced."""
    print("\n--- PDF Extraction (PyMuPDF) ---")

    import fitz

    doc = fitz.open()

    # Page 1: Title page with large font
    page1 = doc.new_page()
    page1.insert_text((72, 100), "Annual Report 2024", fontsize=24, fontname="helv")
    page1.insert_text((72, 140), "Company Overview", fontsize=18, fontname="helv")
    page1.insert_text((72, 180), "This document provides a comprehensive overview of the company.", fontsize=11, fontname="helv")

    # Page 2: Body with a bold heading and normal text
    page2 = doc.new_page()
    page2.insert_text((72, 80), "Financial Summary", fontsize=16, fontname="hebo")
    page2.insert_text((72, 120), "Revenue grew by 15% year over year, reaching $2.5 billion.", fontsize=11, fontname="helv")
    page2.insert_text((72, 150), "Operating costs remained stable at $1.8 billion.", fontsize=11, fontname="helv")
    page2.insert_text((72, 200), "Key Metrics", fontsize=14, fontname="hebo")
    page2.insert_text((72, 230), "Customer satisfaction: 94%", fontsize=11, fontname="helv")
    page2.insert_text((72, 260), "Employee retention: 91%", fontsize=11, fontname="helv")

    # Page 3: More content
    page3 = doc.new_page()
    page3.insert_text((72, 80), "Future Outlook", fontsize=16, fontname="hebo")
    page3.insert_text((72, 120), "The company plans to expand into three new markets.", fontsize=11, fontname="helv")

    pdf_bytes = doc.tobytes()
    doc.close()

    # Test base extraction
    text = extract_text(pdf_bytes, "report.pdf")
    check("PDF base: non-empty", bool(text.strip()))
    check("PDF base: contains 'Annual Report'", "Annual Report" in text)
    check("PDF base: contains 'Revenue'", "Revenue" in text)
    check("PDF base: contains 'Financial Summary'", "Financial Summary" in text)
    check("PDF base: contains 'Future Outlook'", "Future Outlook" in text)

    # Test enhanced extraction (should produce headings based on font size)
    enhanced = extract_text_enhanced(pdf_bytes, "report.pdf")
    check("PDF enhanced: non-empty", bool(enhanced.strip()))
    check("PDF enhanced: contains heading markers", "#" in enhanced)
    check("PDF enhanced: contains 'Annual Report'", "Annual Report" in enhanced)
    check("PDF enhanced: contains 'Financial Summary'", "Financial Summary" in enhanced)

    heading_lines = [l for l in enhanced.split("\n") if l.strip().startswith("#")]
    check("PDF enhanced: detected headings from font size", len(heading_lines) >= 2,
          f"found {len(heading_lines)} heading(s)")

    # Test metadata
    meta = extract_metadata(pdf_bytes, "report.pdf")
    check("PDF metadata: is dict", isinstance(meta, dict))

    print(f"\n  [Preview - base]\n{text[:400]}")
    print(f"\n  [Preview - enhanced]\n{enhanced[:500]}")
    print(f"\n  Headings detected:")
    for h in heading_lines[:10]:
        print(f"    {h.strip()}")


def test_pdf_with_metadata():
    """Test that PyMuPDF correctly extracts PDF metadata."""
    print("\n--- PDF Metadata (PyMuPDF) ---")

    import fitz

    doc = fitz.open()
    doc.set_metadata({
        "title": "Test Document Title",
        "author": "Test Author",
        "subject": "Testing PyMuPDF",
    })
    page = doc.new_page()
    page.insert_text((72, 100), "Hello from PyMuPDF", fontsize=12)
    pdf_bytes = doc.tobytes()
    doc.close()

    meta = extract_metadata(pdf_bytes, "meta_test.pdf")
    check("PDF meta: title extracted", meta.get("title") == "Test Document Title")
    check("PDF meta: is dict", isinstance(meta, dict))

    text = extract_text(pdf_bytes, "meta_test.pdf")
    check("PDF text: contains metadata header", "Title:" in text or "Author:" in text)
    check("PDF text: contains body", "Hello from PyMuPDF" in text)

    print(f"  Metadata: {meta}")


def test_pdf_pdfplumber_backend():
    """Test the pdfplumber backend for PDF extraction (Apache-2.0 licensed)."""
    print("\n--- PDF Extraction (pdfplumber backend) ---")

    import fitz

    doc = fitz.open()

    page1 = doc.new_page()
    page1.insert_text((72, 100), "Report Title", fontsize=22, fontname="helv")
    page1.insert_text((72, 150), "This is body text in the report.", fontsize=11, fontname="helv")

    page2 = doc.new_page()
    page2.insert_text((72, 80), "Section Heading", fontsize=16, fontname="hebo")
    page2.insert_text((72, 120), "Details about this section go here.", fontsize=11, fontname="helv")

    pdf_bytes = doc.tobytes()
    doc.close()

    import file_extraction
    import file_extraction_enhanced

    original_lib = file_extraction._PDF_LIBRARY
    original_lib_enh = file_extraction_enhanced._PDF_LIBRARY

    try:
        file_extraction._PDF_LIBRARY = "pdfplumber"
        file_extraction_enhanced._PDF_LIBRARY = "pdfplumber"

        # Base extraction
        text = extract_text(pdf_bytes, "plumber_test.pdf")
        check("pdfplumber base: non-empty", bool(text.strip()))
        check("pdfplumber base: contains 'Report Title'", "Report Title" in text)
        check("pdfplumber base: contains 'body text'", "body text" in text)
        check("pdfplumber base: contains 'Section Heading'", "Section Heading" in text)

        # Enhanced extraction with heading detection
        enhanced = extract_text_enhanced(pdf_bytes, "plumber_test.pdf")
        check("pdfplumber enhanced: non-empty", bool(enhanced.strip()))
        check("pdfplumber enhanced: has heading markers", "#" in enhanced)
        check("pdfplumber enhanced: contains 'Report Title'", "Report Title" in enhanced)

        heading_lines = [l for l in enhanced.split("\n") if l.strip().startswith("#")]
        check("pdfplumber enhanced: detected headings", len(heading_lines) >= 1,
              f"found {len(heading_lines)} heading(s)")

        # Metadata
        meta = extract_metadata(pdf_bytes, "plumber_meta.pdf")
        check("pdfplumber meta: is dict", isinstance(meta, dict))

        print(f"\n  [Preview - pdfplumber base]\n{text[:300]}")
        print(f"\n  [Preview - pdfplumber enhanced]\n{enhanced[:400]}")
        print(f"\n  Headings detected:")
        for h in heading_lines[:10]:
            print(f"    {h.strip()}")

    finally:
        file_extraction._PDF_LIBRARY = original_lib
        file_extraction_enhanced._PDF_LIBRARY = original_lib_enh


def test_xml_edge_cases():
    print("\n--- XML Edge Cases ---")

    ns_xml = b"""<?xml version="1.0"?>
<root xmlns:ns="http://example.com">
  <ns:item>Test Value</ns:item>
</root>"""
    text = extract_text(ns_xml, "ns.xml")
    check("XML with namespaces", "Test Value" in text)

    attr_xml = b"""<config env="production" version="2.1">
  <setting name="timeout" value="30"/>
  <setting name="retries" value="3"/>
</config>"""
    text = extract_text(attr_xml, "attrs.xml")
    check("XML with attributes", "timeout" in text and "production" in text)


# ======================================================================
#  Main
# ======================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  FILE FORMAT EXTRACTOR TESTS")
    print("=" * 70)

    tests = [
        test_supported_extensions,
        test_csv,
        test_xlsx,
        test_xls,
        test_rtf,
        test_xml,
        test_json,
        test_txt,
        test_md,
        test_pdf_pymupdf,
        test_pdf_with_metadata,
        test_pdf_pdfplumber_backend,
        test_extract_text_dispatch,
        test_extract_text_enhanced_dispatch,
        test_unsupported_extension,
        test_empty_files,
        test_csv_edge_cases,
        test_xml_edge_cases,
    ]

    for test_fn in tests:
        try:
            test_fn()
        except Exception:
            print(f"\n  ERROR in {test_fn.__name__}:")
            traceback.print_exc()
            FAIL += 1

    print("\n" + "=" * 70)
    print(f"  RESULTS: {PASS} passed, {FAIL} failed")
    print("=" * 70)

    sys.exit(1 if FAIL > 0 else 0)
