"""Comprehensive text extraction for document files.

Supported formats:
    .pdf        — pages, tables, annotations, and document metadata.
    .docx       — paragraphs, tables, headers/footers, footnotes, endnotes,
                  and image alt-text.
    .pptx       — slide text, speaker notes, table content, and group shapes.
    .html/.htm  — structured content via ``web_scrapping`` (headings,
                  paragraphs, lists, tables, code blocks, etc.).
    .json       — text values extracted from JSON structures (keys and
                  scalar values only, no syntax characters).
    .csv        — comma-separated values rendered as markdown tables.
    .xlsx       — Excel workbooks (all sheets, tables rendered as markdown).
    .xls        — legacy Excel files (all sheets, tables rendered as markdown).
    .rtf        — Rich Text Format (plain-text extraction via ``striprtf``).
    .xml        — XML documents (tag-based text extraction with structure).
    .txt        — plain text (UTF-8).
    .md         — plain text (UTF-8).

Every extractor accepts *raw bytes* (``bytes | BytesIO``) or a
*file-system path* (``str | Path``) so callers never need to write
temp files.  The public entry point is::

    text = extract_text(file_bytes, "report.pdf")
    text = extract_text(r"C:\\docs\\report.pdf", "report.pdf")
"""

from __future__ import annotations

import logging
import os
import re
import tempfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path, PurePosixPath
from typing import Optional, Union

logger = logging.getLogger(__name__)

FileInput = Union[bytes, BytesIO, str, Path]

_SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".pptx", ".json", ".txt", ".md", ".html", ".htm",
    ".csv", ".xlsx", ".xls", ".rtf", ".xml",
}


def _to_bytesio(data: FileInput) -> BytesIO:
    """Normalise *data* into a seeked ``BytesIO`` stream.

    Parameters
    ----------
    data : bytes | BytesIO | str | Path
        Raw file bytes, an existing ``BytesIO`` object, or a file-system
        path (string or ``Path``) whose contents will be read.

    Returns
    -------
    BytesIO
        A ``BytesIO`` stream positioned at the beginning.
    """
    if isinstance(data, (str, Path)):
        return BytesIO(Path(data).read_bytes())
    if isinstance(data, bytes):
        return BytesIO(data)
    data.seek(0)
    return data


# ======================================================================
#  PDF — library selection
# ======================================================================
#
# Set ``PDF_LIBRARY`` env var to choose the PDF backend:
#   - ``"pymupdf"`` (default) — PyMuPDF / fitz.  Best quality, but uses
#     AGPL-3.0 which may not be suitable for proprietary / corporate use.
#   - ``"pdfplumber"`` — pdfplumber (Apache-2.0).  Permissively licensed
#     alternative with per-character font info for heading detection.
#
# Both provide font-size and bold metadata for robust heading-aware chunking.

_PDF_LIBRARY = os.environ.get("PDF_LIBRARY", "pymupdf").strip().lower()


# ======================================================================
#  PDF — PyMuPDF / fitz backend
# ======================================================================

def _extract_pdf_pymupdf(data: FileInput) -> str:
    """Extract text from a PDF file using PyMuPDF (fitz).

    Extracts document-level metadata (title, author, subject, creator),
    page text with font-size awareness, and annotation contents.
    PyMuPDF provides per-span font information enabling much better
    text extraction than pypdf.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    str
        Concatenated text with page separators (``--- Page N ---``).
    """
    import fitz

    raw = _to_bytesio(data).read()
    doc = fitz.open(stream=raw, filetype="pdf")
    sections: list[str] = []

    meta = doc.metadata
    if meta:
        meta_lines: list[str] = []
        for key, label in [("title", "Title"), ("author", "Author"),
                           ("subject", "Subject"), ("creator", "Creator")]:
            value = meta.get(key, "")
            if value and value.strip():
                meta_lines.append(f"{label}: {value.strip()}")
        if meta_lines:
            sections.append("\n".join(meta_lines))

    for page_num in range(len(doc)):
        page = doc[page_num]
        parts: list[str] = []

        page_text = page.get_text("text") or ""
        if page_text.strip():
            parts.append(page_text.strip())

        annots = page.annots()
        if annots:
            for annot in annots:
                content = annot.info.get("content", "")
                if content and content.strip():
                    parts.append(f"[Annotation] {content.strip()}")

        if parts:
            sections.append(f"--- Page {page_num + 1} ---\n" + "\n".join(parts))

    doc.close()
    return "\n\n".join(sections)


# ======================================================================
#  PDF — pdfplumber backend (Apache-2.0 licensed)
# ======================================================================

def _extract_pdf_pdfplumber(data: FileInput) -> str:
    """Extract text from a PDF file using pdfplumber.

    Extracts document-level metadata and full page text.
    pdfplumber is built on pdfminer.six and provides per-character
    font information while using a permissive Apache-2.0 license.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    str
        Concatenated text with page separators (``--- Page N ---``).
    """
    import pdfplumber

    stream = _to_bytesio(data)
    pdf = pdfplumber.open(stream)
    sections: list[str] = []

    meta = pdf.metadata or {}
    if meta:
        meta_lines: list[str] = []
        for key, label in [("Title", "Title"), ("Author", "Author"),
                           ("Subject", "Subject"), ("Creator", "Creator")]:
            value = meta.get(key, "")
            if value and str(value).strip():
                meta_lines.append(f"{label}: {str(value).strip()}")
        if meta_lines:
            sections.append("\n".join(meta_lines))

    for page_num, page in enumerate(pdf.pages, start=1):
        parts: list[str] = []

        page_text = page.extract_text() or ""
        if page_text.strip():
            parts.append(page_text.strip())

        if parts:
            sections.append(f"--- Page {page_num} ---\n" + "\n".join(parts))

    pdf.close()
    return "\n\n".join(sections)


def _extract_pdf(data: FileInput) -> str:
    """Extract text from a PDF, dispatching to the configured backend.

    Uses ``PDF_LIBRARY`` env var: ``"pymupdf"`` (default) or ``"pdfplumber"``.
    """
    if _PDF_LIBRARY == "pdfplumber":
        return _extract_pdf_pdfplumber(data)
    return _extract_pdf_pymupdf(data)


# ======================================================================
#  PDF (OLD — pypdf-based, kept for reference)
# ======================================================================

# def _extract_pdf_pypdf(data: FileInput) -> str:
#     """Extract text from a PDF file.
#
#     Extracts document-level metadata (title, author, subject, creator),
#     page text via ``pypdf``, and annotation contents (comments, sticky
#     notes, free-text annotations).
#
#     Parameters
#     ----------
#     data : bytes | BytesIO
#         Raw PDF bytes.
#
#     Returns
#     -------
#     str
#         Concatenated text with page separators (``--- Page N ---``).
#     """
#     from pypdf import PdfReader
#
#     reader = PdfReader(_to_bytesio(data))
#     sections: list[str] = []
#
#     # --- Document metadata ---
#     meta = reader.metadata
#     if meta:
#         meta_lines: list[str] = []
#         for attr in ("title", "author", "subject", "creator"):
#             value = getattr(meta, attr, None)
#             if value:
#                 meta_lines.append(f"{attr.capitalize()}: {value}")
#         if meta_lines:
#             sections.append("\n".join(meta_lines))
#
#     # --- Page content ---
#     for page_num, page in enumerate(reader.pages, start=1):
#         parts: list[str] = []
#
#         page_text = page.extract_text() or ""
#         if page_text.strip():
#             parts.append(page_text)
#
#         # Annotations (comments, sticky notes, free-text)
#         if page.get("/Annots"):
#             for annot_ref in page["/Annots"]:
#                 try:
#                     annot = annot_ref.get_object()
#                     contents = annot.get("/Contents")
#                     if contents and str(contents).strip():
#                         parts.append(f"[Annotation] {contents}")
#                 except Exception:
#                     pass
#
#         if parts:
#             sections.append(f"--- Page {page_num} ---\n" + "\n".join(parts))
#
#     return "\n\n".join(sections)


# ======================================================================
#  DOCX
# ======================================================================

def _iter_docx_block_elements(body):
    """Yield ``("paragraph", element)`` or ``("table", element)`` tuples
    for every top-level ``<w:p>`` and ``<w:tbl>`` in the document body.

    Iterating children directly preserves the original document order so
    that paragraphs and tables are interleaved correctly rather than
    extracted separately.

    Parameters
    ----------
    body : lxml.etree._Element
        The ``<w:body>`` XML element from ``doc.element.body``.

    Yields
    ------
    tuple[str, lxml.etree._Element]
        ``("paragraph", elem)`` or ``("table", elem)``.
    """
    from docx.oxml.ns import qn

    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield ("paragraph", child)
        elif child.tag == qn("w:tbl"):
            yield ("table", child)


_HEADING_STYLE_RE = re.compile(r"^heading\s+(\d+)$", re.IGNORECASE)


def _get_docx_heading_level(style_name: str) -> Optional[int]:
    """Return normalized heading level (1-6) from a Word paragraph style name.

    Handles standard styles ('Heading 1', 'Heading 2') and non-standard
    naming conventions ('heading 10', 'heading 20', 'heading 30') where
    10/20/30 map to levels 1/2/3.  Also recognizes the 'Title' style as
    level 1.  Returns None for non-heading styles.
    """
    if not style_name:
        return None

    if style_name.lower() == "title":
        return 1

    m = _HEADING_STYLE_RE.match(style_name)
    if m:
        num = int(m.group(1))
        # Normalize "10/20/30/..." → "1/2/3/..." for non-standard styles
        if num >= 10 and num % 10 == 0:
            level = num // 10
        else:
            level = num
        return min(max(level, 1), 6)

    return None


def _extract_docx(data: FileInput) -> str:
    """Extract full content from a DOCX (Word) file.

    Covers core properties (title, author, etc.), headers, footers,
    body paragraphs and tables (in document order), footnotes, endnotes,
    and image alt-text via ``python-docx``.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw DOCX bytes.

    Returns
    -------
    str
        Structured text with sections separated by double newlines.
    """
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn

    doc = Document(_to_bytesio(data))
    sections: list[str] = []

    # --- Core properties (metadata) ---
    cp = doc.core_properties
    meta_lines: list[str] = []
    for attr in ("title", "author", "subject", "category", "keywords"):
        value = getattr(cp, attr, None)
        if value:
            meta_lines.append(f"{attr.capitalize()}: {value}")
    if meta_lines:
        sections.append("\n".join(meta_lines))

    # --- Headers and footers ---
    header_texts: list[str] = []
    footer_texts: list[str] = []
    for section in doc.sections:
        for header in (section.header, section.first_page_header):
            if header and header.is_linked_to_previous is False:
                text = "\n".join(p.text for p in header.paragraphs if p.text.strip())
                if text.strip() and text not in header_texts:
                    header_texts.append(text)
        for footer in (section.footer, section.first_page_footer):
            if footer and footer.is_linked_to_previous is False:
                text = "\n".join(p.text for p in footer.paragraphs if p.text.strip())
                if text.strip() and text not in footer_texts:
                    footer_texts.append(text)

    if header_texts:
        sections.append("[Header]\n" + "\n".join(header_texts) + "\n[/Header]")

    # --- Body: paragraphs + tables in document order ---
    body_parts: list[str] = []
    for kind, element in _iter_docx_block_elements(doc.element.body):
        if kind == "paragraph":
            para = Paragraph(element, doc)
            text = para.text.strip()
            if not text:
                continue
            style_name = (para.style.name or "").strip() if para.style else ""
            level = _get_docx_heading_level(style_name)
            if level is not None:
                body_parts.append(f"{'#' * level} {text}")
            elif style_name.lower().startswith(("list", "bullet", "toc")):
                body_parts.append(f"• {text}")
            else:
                body_parts.append(text)
        elif kind == "table":
            tbl = Table(element, doc)
            table_lines = _docx_table_to_text(tbl)
            if table_lines:
                body_parts.append(table_lines)

    if body_parts:
        sections.append("\n".join(body_parts))

    # --- Footnotes ---
    footnote_parts: list[str] = []
    try:
        for rel in doc.part.rels.values():
            if "footnotes" in (rel.reltype or ""):
                fn_xml = rel.target_part.blob
                from lxml import etree
                tree = etree.fromstring(fn_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for fn in tree.findall(".//w:footnote", ns):
                    fn_id = fn.get(qn("w:id"), "")
                    if fn_id in ("-1", "0"):
                        continue
                    texts = [t.text for t in fn.findall(".//w:t", ns) if t.text]
                    if texts:
                        footnote_parts.append(f"[{fn_id}] {''.join(texts)}")
                break
    except Exception:
        pass

    if footnote_parts:
        sections.append("[Footnotes]\n" + "\n".join(footnote_parts) + "\n[/Footnotes]")

    # --- Endnotes ---
    endnote_parts: list[str] = []
    try:
        for rel in doc.part.rels.values():
            if "endnotes" in (rel.reltype or ""):
                en_xml = rel.target_part.blob
                from lxml import etree
                tree = etree.fromstring(en_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for en in tree.findall(".//w:endnote", ns):
                    en_id = en.get(qn("w:id"), "")
                    if en_id in ("-1", "0"):
                        continue
                    texts = [t.text for t in en.findall(".//w:t", ns) if t.text]
                    if texts:
                        endnote_parts.append(f"[{en_id}] {''.join(texts)}")
                break
    except Exception:
        pass

    if endnote_parts:
        sections.append("[Endnotes]\n" + "\n".join(endnote_parts) + "\n[/Endnotes]")

    # --- Image alt-text ---
    alt_texts: list[str] = []
    try:
        for drawing in doc.element.body.iter(qn("w:drawing")):
            for docPr in drawing.iter(qn("wp:docPr")):
                desc = docPr.get("descr", "").strip()
                title_attr = docPr.get("title", "").strip()
                if desc or title_attr:
                    label = title_attr or desc
                    alt_texts.append(f"[Image: {label}]")
    except Exception:
        pass

    if alt_texts:
        sections.append("\n".join(alt_texts))

    if footer_texts:
        sections.append("[Footer]\n" + "\n".join(footer_texts) + "\n[/Footer]")

    return "\n\n".join(sections)


def _docx_table_to_text(table) -> str:
    """Render a ``python-docx`` Table as a markdown-style text table.

    Column widths are auto-calculated from cell content (minimum 3
    characters) and the first row is treated as the header with a
    separator line beneath it.

    Parameters
    ----------
    table : docx.table.Table
        A table object from ``python-docx``.

    Returns
    -------
    str
        Markdown-formatted table text, or empty string if the table
        has no rows.
    """
    rows_data: list[list[str]] = []
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
        rows_data.append(cells)
    if not rows_data:
        return ""

    max_cols = max(len(r) for r in rows_data)
    col_widths = [0] * max_cols
    for row in rows_data:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))
    col_widths = [max(w, 3) for w in col_widths]

    lines: list[str] = []
    for idx, row in enumerate(rows_data):
        padded = []
        for i in range(max_cols):
            val = row[i] if i < len(row) else ""
            padded.append(val.ljust(col_widths[i]))
        lines.append("| " + " | ".join(padded) + " |")
        if idx == 0:
            lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

    return "\n".join(lines)


# ======================================================================
#  PPTX
# ======================================================================

def _extract_pptx(data: FileInput) -> str:
    """Extract text from a PowerPoint (PPTX) presentation.

    Covers presentation-level metadata, slide titles, all shape text
    (including nested groups), tables, speaker notes, and image
    alt-text via ``python-pptx``.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PPTX bytes.

    Returns
    -------
    str
        Structured text with slide separators (``--- Slide N ---``).
    """
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    sections: list[str] = []

    # --- Presentation-level metadata ---
    try:
        cp = prs.core_properties
        meta_lines: list[str] = []
        for attr in ("title", "author", "subject", "category", "keywords"):
            value = getattr(cp, attr, None)
            if value:
                meta_lines.append(f"{attr.capitalize()}: {value}")
        if meta_lines:
            sections.append("\n".join(meta_lines))
    except Exception:
        pass

    for slide_num, slide in enumerate(prs.slides, start=1):
        slide_parts: list[str] = [f"--- Slide {slide_num} ---"]

        # Slide title (from layout placeholder)
        if slide.shapes.title and slide.shapes.title.text.strip():
            slide_parts.append(f"# {slide.shapes.title.text.strip()}")

        # All shapes (recursive for grouped shapes)
        for shape in slide.shapes:
            text = _pptx_shape_text(shape)
            if text:
                slide_parts.append(text)

        # Speaker notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                slide_parts.append(f"[Speaker Notes]\n{notes}\n[/Speaker Notes]")

        if len(slide_parts) > 1:  # more than just the header
            sections.append("\n".join(slide_parts))

    return "\n\n".join(sections)


def _pptx_shape_text(shape) -> str:
    """Recursively extract text from a single PPTX shape.

    Handles text frames (with paragraph indentation), tables
    (rendered as markdown), group shapes (recursed into), and image
    alt-text (via the ``cNvPr`` element's ``descr`` attribute).

    Parameters
    ----------
    shape : pptx.shapes.base.BaseShape
        A shape object from ``python-pptx``.

    Returns
    -------
    str
        Extracted text lines joined by newlines, or empty string if the
        shape contains no textual content.
    """
    parts: list[str] = []

    # Text frame (paragraphs)
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if text:
                level = para.level or 0
                if level > 0:
                    parts.append(f"{'  ' * level}• {text}")
                else:
                    parts.append(text)

    # Table
    if shape.has_table:
        table = shape.table
        rows_data: list[list[str]] = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows_data.append(cells)
        if rows_data:
            max_cols = max(len(r) for r in rows_data)
            col_widths = [3] * max_cols
            for row in rows_data:
                for i, cell in enumerate(row):
                    if i < max_cols:
                        col_widths[i] = max(col_widths[i], len(cell))
            lines: list[str] = []
            for idx, row in enumerate(rows_data):
                padded = []
                for i in range(max_cols):
                    val = row[i] if i < len(row) else ""
                    padded.append(val.ljust(col_widths[i]))
                lines.append("| " + " | ".join(padded) + " |")
                if idx == 0:
                    lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")
            parts.append("\n".join(lines))

    # Group shapes (recursive)
    if shape.shape_type is not None:
        try:
            from pptx.enum.shapes import MSO_SHAPE_TYPE
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for child_shape in shape.shapes:
                    child_text = _pptx_shape_text(child_shape)
                    if child_text:
                        parts.append(child_text)
        except Exception:
            pass

    # Alt text / description via python-pptx's cNvPr element
    try:
        from pptx.oxml.ns import qn as pptx_qn

        cNvPr = shape._element.find(f".//{pptx_qn('p:cNvPr')}")
        if cNvPr is None:
            cNvPr = shape._element.find(f".//{pptx_qn('pic:cNvPr')}")
        if cNvPr is not None:
            desc = (cNvPr.get("descr") or "").strip()
            if desc:
                parts.append(f"[Image: {desc}]")
    except Exception:
        pass

    return "\n".join(parts)


# ======================================================================
#  JSON
# ======================================================================

def _scalar_to_str(value) -> Optional[str]:
    """Convert a JSON scalar to its text representation."""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else None
    return None


def _is_scalar(value) -> bool:
    """Return ``True`` for JSON scalars (str, number, bool, null)."""
    return not isinstance(value, (dict, list))


def _flatten_json(obj, lines: list[str]) -> None:
    """Walk a parsed JSON structure and append ``key value`` lines.

    * Scalar values paired with a key produce ``key value``.
    * Lists of scalars produce the key on its own line, then the
      comma-separated values on the next line.
    * Nested dicts produce the parent key on its own line, then
      the child key-value pairs on subsequent lines.
    * A top-level list is iterated element by element.
    """
    if isinstance(obj, dict):
        for key, value in obj.items():
            if _is_scalar(value):
                text = _scalar_to_str(value)
                if text is not None:
                    lines.append(f"{key} {text}")
                else:
                    lines.append(key)
            elif isinstance(value, list) and value and all(_is_scalar(v) for v in value):
                lines.append(key)
                items = [_scalar_to_str(v) for v in value]
                lines.append(", ".join(s for s in items if s))
            else:
                lines.append(key)
                _flatten_json(value, lines)
    elif isinstance(obj, list):
        for item in obj:
            if _is_scalar(item):
                text = _scalar_to_str(item)
                if text:
                    lines.append(text)
            else:
                _flatten_json(item, lines)


def _extract_json(data: FileInput) -> str:
    """Extract text content from a JSON file.

    Parses the JSON and walks the structure recursively, keeping each
    key next to its value(s) on the same line.  Lists of scalars are
    comma-separated.  All JSON syntax characters (``{}``, ``[]``,
    ``:``) are excluded so that only human-readable text remains.

    Example output for ``{"name": "Alice", "scores": [95, 88]}``::

        name Alice
        scores
        95, 88

    Parameters
    ----------
    data : bytes | BytesIO
        Raw JSON bytes.

    Returns
    -------
    str
        Key-value lines joined by newlines.
    """
    import json

    stream = _to_bytesio(data)
    text = stream.read().decode("utf-8", errors="ignore")
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.warning("Invalid JSON: %s", exc)
        return ""

    lines: list[str] = []
    _flatten_json(obj, lines)
    return "\n".join(lines)


# ======================================================================
#  TXT / MD
# ======================================================================

def _extract_plain_text(data: FileInput) -> str:
    """Decode raw bytes as UTF-8 plain text.

    Invalid byte sequences are silently ignored (``errors="ignore"``).

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes.

    Returns
    -------
    str
        The decoded text content.
    """
    stream = _to_bytesio(data)
    return stream.read().decode("utf-8", errors="ignore")


# ======================================================================
#  CSV
# ======================================================================

def _extract_csv(data: FileInput) -> str:
    """Extract text from a CSV file, rendered as a markdown table.

    Handles automatic encoding detection (tries UTF-8 first, then
    latin-1 as fallback).  The first row is treated as the header.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw CSV bytes.

    Returns
    -------
    str
        Markdown-formatted table, or empty string if the file is empty.
    """
    import csv

    raw = _to_bytesio(data).read()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1", errors="ignore")

    lines = text.splitlines()
    if not lines:
        return ""

    reader = csv.reader(lines)
    rows_data: list[list[str]] = [row for row in reader if any(cell.strip() for cell in row)]
    if not rows_data:
        return ""

    max_cols = max(len(r) for r in rows_data)
    col_widths = [0] * max_cols
    for row in rows_data:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell.strip()))
    col_widths = [max(w, 3) for w in col_widths]

    table_lines: list[str] = []
    for idx, row in enumerate(rows_data):
        padded = []
        for i in range(max_cols):
            val = row[i].strip() if i < len(row) else ""
            padded.append(val.ljust(col_widths[i]))
        table_lines.append("| " + " | ".join(padded) + " |")
        if idx == 0:
            table_lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

    return "\n".join(table_lines)


# ======================================================================
#  XLSX (Excel — openpyxl)
# ======================================================================

def _extract_xlsx(data: FileInput) -> str:
    """Extract text from all sheets of an Excel (.xlsx) workbook.

    Each sheet is rendered as a markdown table preceded by a sheet-level
    heading (``## Sheet: <name>``).  Empty sheets are skipped.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw XLSX bytes.

    Returns
    -------
    str
        Concatenated sheet content separated by double newlines.
    """
    from openpyxl import load_workbook

    wb = load_workbook(_to_bytesio(data), read_only=True, data_only=True)
    sections: list[str] = []

    for sheet in wb.worksheets:
        rows_data: list[list[str]] = []
        for row in sheet.iter_rows(values_only=True):
            cells = [str(c).strip() if c is not None else "" for c in row]
            if any(cells):
                rows_data.append(cells)

        if not rows_data:
            continue

        sheet_lines: list[str] = [f"## Sheet: {sheet.title}"]

        max_cols = max(len(r) for r in rows_data)
        col_widths = [0] * max_cols
        for row in rows_data:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(cell))
        col_widths = [max(w, 3) for w in col_widths]

        for idx, row in enumerate(rows_data):
            padded = []
            for i in range(max_cols):
                val = row[i] if i < len(row) else ""
                padded.append(val.ljust(col_widths[i]))
            sheet_lines.append("| " + " | ".join(padded) + " |")
            if idx == 0:
                sheet_lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

        sections.append("\n".join(sheet_lines))

    wb.close()
    return "\n\n".join(sections)


# ======================================================================
#  XLS (legacy Excel — xlrd)
# ======================================================================

def _extract_xls(data: FileInput) -> str:
    """Extract text from all sheets of a legacy Excel (.xls) workbook.

    Uses ``xlrd`` for the older BIFF format.  Each sheet is rendered
    as a markdown table preceded by a sheet heading.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw XLS bytes.

    Returns
    -------
    str
        Concatenated sheet content separated by double newlines.
    """
    import xlrd

    raw = _to_bytesio(data).read()
    wb = xlrd.open_workbook(file_contents=raw)
    sections: list[str] = []

    for sheet in wb.sheets():
        if sheet.nrows == 0:
            continue

        rows_data: list[list[str]] = []
        for row_idx in range(sheet.nrows):
            cells = [str(sheet.cell_value(row_idx, col)).strip() for col in range(sheet.ncols)]
            if any(cells):
                rows_data.append(cells)

        if not rows_data:
            continue

        sheet_lines: list[str] = [f"## Sheet: {sheet.name}"]

        max_cols = max(len(r) for r in rows_data)
        col_widths = [0] * max_cols
        for row in rows_data:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(cell))
        col_widths = [max(w, 3) for w in col_widths]

        for idx, row in enumerate(rows_data):
            padded = []
            for i in range(max_cols):
                val = row[i] if i < len(row) else ""
                padded.append(val.ljust(col_widths[i]))
            sheet_lines.append("| " + " | ".join(padded) + " |")
            if idx == 0:
                sheet_lines.append("|" + "|".join("-" * (w + 2) for w in col_widths) + "|")

        sections.append("\n".join(sheet_lines))

    return "\n\n".join(sections)


# ======================================================================
#  RTF (Rich Text Format — striprtf)
# ======================================================================

def _extract_rtf(data: FileInput) -> str:
    """Extract plain text from an RTF file.

    Uses ``striprtf`` to strip RTF control words and return the
    human-readable text content.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw RTF bytes.

    Returns
    -------
    str
        Plain text content of the RTF document.
    """
    from striprtf.striprtf import rtf_to_text

    raw = _to_bytesio(data).read()
    try:
        rtf_content = raw.decode("utf-8")
    except UnicodeDecodeError:
        rtf_content = raw.decode("latin-1", errors="ignore")

    return rtf_to_text(rtf_content)


# ======================================================================
#  XML
# ======================================================================

def _extract_xml(data: FileInput) -> str:
    """Extract text content from an XML document.

    Walks the element tree and renders each element's tag and text
    content in a structured, readable format.  Attributes are included
    inline.  Nesting is represented via indentation.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw XML bytes.

    Returns
    -------
    str
        Structured text representation of the XML document.
    """
    import xml.etree.ElementTree as ET

    raw = _to_bytesio(data).read()
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        logger.warning("Invalid XML: %s", exc)
        return ""

    lines: list[str] = []
    _walk_xml_element(root, lines, depth=0)
    return "\n".join(lines)


def _walk_xml_element(element, lines: list[str], depth: int) -> None:
    """Recursively walk an XML element tree, appending readable lines."""
    tag = element.tag
    if "}" in tag:
        tag = tag.split("}", 1)[1]

    text = (element.text or "").strip()
    tail = (element.tail or "").strip()

    attrs = element.attrib
    attr_str = ""
    if attrs:
        attr_parts = [f"{k}={v}" for k, v in attrs.items()]
        attr_str = f" ({', '.join(attr_parts)})"

    indent = "  " * depth

    children = list(element)
    if not children and text:
        lines.append(f"{indent}{tag}{attr_str}: {text}")
    elif children:
        lines.append(f"{indent}{tag}{attr_str}:")
        if text:
            lines.append(f"{indent}  {text}")
        for child in children:
            _walk_xml_element(child, lines, depth + 1)
    elif attr_str:
        lines.append(f"{indent}{tag}{attr_str}")

    if tail:
        lines.append(f"{indent}{tail}")


# ======================================================================
#  HTML (delegates to web_scrapping.py)
# ======================================================================

def _extract_html(data: FileInput) -> str:
    """Extract structured text from an HTML file.

    The raw bytes are written to a temporary file and processed by
    :func:`web_scrapping.scrape_webpage` (without Playwright) to
    extract headings, paragraphs, lists, tables, and other content.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw HTML bytes.

    Returns
    -------
    str
        The extracted ``web_page_content`` from the scraper result.
    """
    from web_scrapping import scrape_webpage

    raw = _to_bytesio(data).read()

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=True)
        return result.get("web_page_content", "")
    finally:
        os.unlink(tmp_path)


# ======================================================================
#  Public API
# ======================================================================

_EXTRACTORS = {
    ".pdf": _extract_pdf,
    ".docx": _extract_docx,
    ".pptx": _extract_pptx,
    ".json": _extract_json,
    ".csv": _extract_csv,
    ".xlsx": _extract_xlsx,
    ".xls": _extract_xls,
    ".rtf": _extract_rtf,
    ".xml": _extract_xml,
    ".txt": _extract_plain_text,
    ".md": _extract_plain_text,
    ".html": _extract_html,
    ".htm": _extract_html,
}


def extract_text(data: FileInput, filename: str) -> str:
    """Extract all text from *data* based on the file extension in *filename*.

    Parameters
    ----------
    data:
        Raw file bytes or a ``BytesIO`` stream.
    filename:
        Original file name (used only to detect the extension).

    Returns
    -------
    str
        The extracted plain text.

    Raises
    ------
    ValueError
        If the file extension is not supported.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor is None:
        raise ValueError(
            f"Unsupported file type '{ext}'. "
            f"Supported: {', '.join(sorted(_SUPPORTED_EXTENSIONS))}"
        )
    logger.info("Extracting text from '%s' (type=%s)", filename, ext)
    return extractor(data)


def supported_extensions() -> set[str]:
    """Return the set of file extensions this module can handle."""
    return set(_SUPPORTED_EXTENSIONS)


# ======================================================================
#  Metadata extraction
# ======================================================================

def _to_iso8601(dt: Optional[datetime]) -> Optional[str]:
    """Convert a datetime to an ISO-8601 string suitable for Azure AI Search.

    Returns ``None`` when *dt* is falsy.  Naïve datetimes are assumed UTC.
    """
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _metadata_pdf_pymupdf(data: FileInput) -> dict:
    """Extract title and creation date from a PDF file using PyMuPDF.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    import fitz

    raw = _to_bytesio(data).read()
    doc = fitz.open(stream=raw, filetype="pdf")
    meta = doc.metadata
    doc.close()

    if not meta:
        return {}

    result: dict = {}
    title = meta.get("title", "")
    if title and title.strip():
        result["title"] = title.strip()

    creation = meta.get("creationDate", "")
    if creation:
        parsed = _parse_pdf_date(creation)
        if parsed:
            result["created_date"] = _to_iso8601(parsed)

    return result


def _metadata_pdf_pdfplumber(data: FileInput) -> dict:
    """Extract title and creation date from a PDF file using pdfplumber.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PDF bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    import pdfplumber

    stream = _to_bytesio(data)
    pdf = pdfplumber.open(stream)
    meta = pdf.metadata or {}
    pdf.close()

    if not meta:
        return {}

    result: dict = {}
    title = meta.get("Title", "")
    if title and str(title).strip():
        result["title"] = str(title).strip()

    creation = meta.get("CreationDate", "")
    if creation:
        parsed = _parse_pdf_date(str(creation))
        if parsed:
            result["created_date"] = _to_iso8601(parsed)

    return result


def _metadata_pdf(data: FileInput) -> dict:
    """Extract PDF metadata, dispatching to the configured backend.

    Uses ``PDF_LIBRARY`` env var: ``"pymupdf"`` (default) or ``"pdfplumber"``.
    """
    if _PDF_LIBRARY == "pdfplumber":
        return _metadata_pdf_pdfplumber(data)
    return _metadata_pdf_pymupdf(data)


def _parse_pdf_date(date_str: str) -> Optional[datetime]:
    """Parse a PDF date string (``D:YYYYMMDDHHmmSS``) into a datetime."""
    if not date_str:
        return None
    cleaned = date_str.strip()
    if cleaned.startswith("D:"):
        cleaned = cleaned[2:]
    cleaned = cleaned.replace("'", "").rstrip("Z")
    for fmt in ("%Y%m%d%H%M%S", "%Y%m%d%H%M", "%Y%m%d", "%Y"):
        try:
            return datetime.strptime(cleaned[:len(fmt.replace("%", ""))], fmt).replace(
                tzinfo=timezone.utc
            )
        except (ValueError, IndexError):
            continue
    return None


# def _metadata_pdf_pypdf(data: FileInput) -> dict:
#     """Extract title and creation date from a PDF file (OLD — pypdf-based).
#
#     Parameters
#     ----------
#     data : bytes | BytesIO
#         Raw PDF bytes.
#
#     Returns
#     -------
#     dict
#         May contain ``"title"`` (str) and/or ``"created_date"``
#         (ISO-8601 str).
#     """
#     from pypdf import PdfReader
#
#     reader = PdfReader(_to_bytesio(data))
#     meta = reader.metadata
#     if not meta:
#         return {}
#
#     result: dict = {}
#     if meta.title:
#         result["title"] = str(meta.title)
#
#     creation = getattr(meta, "creation_date", None) or getattr(meta, "creation_date_raw", None)
#     if isinstance(creation, datetime):
#         result["created_date"] = _to_iso8601(creation)
#     elif isinstance(creation, str):
#         try:
#             from pypdf.generic import parse_iso8824_date
#             result["created_date"] = _to_iso8601(parse_iso8824_date(creation))
#         except Exception:
#             pass
#
#     return result


def _metadata_docx(data: FileInput) -> dict:
    """Extract title and creation date from a DOCX file's core properties.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw DOCX bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from docx import Document

    doc = Document(_to_bytesio(data))
    cp = doc.core_properties
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_pptx(data: FileInput) -> dict:
    """Extract title and creation date from a PPTX file's core properties.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw PPTX bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from pptx import Presentation

    prs = Presentation(_to_bytesio(data))
    try:
        cp = prs.core_properties
    except Exception:
        return {}
    result: dict = {}
    if cp.title:
        result["title"] = cp.title
    if cp.created:
        result["created_date"] = _to_iso8601(cp.created)
    return result


def _metadata_plain(data: FileInput) -> dict:
    """Return empty metadata for plain-text files.

    Plain text (``.txt``, ``.md``) files have no embedded metadata.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes (unused).

    Returns
    -------
    dict
        Always an empty dict.
    """
    return {}


def _metadata_xlsx(data: FileInput) -> dict:
    """Extract title and creation date from an XLSX workbook's core properties.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw XLSX bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) and/or ``"created_date"``
        (ISO-8601 str).
    """
    from openpyxl import load_workbook

    wb = load_workbook(_to_bytesio(data), read_only=True)
    result: dict = {}
    try:
        props = wb.properties
        if props.title:
            result["title"] = props.title
        if props.created:
            result["created_date"] = _to_iso8601(props.created)
    except Exception:
        pass
    wb.close()
    return result


def _metadata_html(data: FileInput) -> dict:
    """Extract title from an HTML file via ``web_scrapping``.

    The HTML is written to a temporary file and scraped for metadata.
    Only the ``title`` (from ``<title>`` or ``og:title``) is extracted.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw HTML bytes.

    Returns
    -------
    dict
        May contain ``"title"`` (str) if found in the HTML metadata.
    """
    from web_scrapping import scrape_webpage

    raw = _to_bytesio(data).read()

    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".html", delete=False
    ) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        result = scrape_webpage(tmp_path, use_playwright=True)
        meta = result.get("metadata", {})
        out: dict = {}
        title = meta.get("title") or meta.get("og:title")
        if title:
            out["title"] = title
        return out
    finally:
        os.unlink(tmp_path)


_METADATA_EXTRACTORS = {
    ".pdf": _metadata_pdf,
    ".docx": _metadata_docx,
    ".pptx": _metadata_pptx,
    ".json": _metadata_plain,
    ".csv": _metadata_plain,
    ".xlsx": _metadata_xlsx,
    ".xls": _metadata_plain,
    ".rtf": _metadata_plain,
    ".xml": _metadata_plain,
    ".txt": _metadata_plain,
    ".md": _metadata_plain,
    ".html": _metadata_html,
    ".htm": _metadata_html,
}


def extract_metadata(data: FileInput, filename: str) -> dict:
    """Extract structured metadata from a file.

    Dispatches to a format-specific extractor based on the file extension
    in *filename*.  Returns an empty dict for unsupported formats or if
    extraction fails.

    Parameters
    ----------
    data : bytes | BytesIO
        Raw file bytes or a ``BytesIO`` stream.
    filename : str
        Original file name (used only to detect the extension).

    Returns
    -------
    dict
        May contain:

        * ``"title"`` — document title (str).
        * ``"created_date"`` — ISO-8601 creation timestamp (str).

        Keys are omitted when the corresponding value is not available.
    """
    ext = PurePosixPath(filename).suffix.lower()
    extractor = _METADATA_EXTRACTORS.get(ext)
    if extractor is None:
        return {}
    try:
        return extractor(data)
    except Exception:
        logger.warning("Metadata extraction failed for '%s'", filename, exc_info=True)
        return {}
