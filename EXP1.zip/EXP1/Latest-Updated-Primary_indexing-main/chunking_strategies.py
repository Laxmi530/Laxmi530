"""Unified chunking strategies with per-chunk metadata.

Consolidates all chunking methods into a single importable module:

1. **recursive** — Fast, deterministic ``RecursiveCharacterTextSplitter``
   that splits on paragraph/sentence/word boundaries.

2. **semantic** — Embedding-based ``SemanticChunker`` that detects topic
   shifts via cosine distance between sentence-group embeddings.

3. **heading_aware** (context-aware) — Splits on markdown headings using
   ``MarkdownHeaderTextSplitter``, then sub-chunks large sections with
   ``RecursiveCharacterTextSplitter``.  Each chunk carries heading
   hierarchy metadata.

4. **hybrid** — Heading-aware first pass + semantic sub-chunking for
   large sections so boundaries align with natural topic shifts.

Every strategy returns ``List[ChunkWithMetadata]`` — a uniform output
format with structural metadata ready for the indexing pipeline::

    from chunking_strategies import chunk_text, ChunkWithMetadata

    chunks = chunk_text(text, strategy="heading_aware")
    for c in chunks:
        print(c.heading_path, c.content[:80])

Dependencies (already in requirements.txt):
    ``langchain-text-splitters``, ``langchain-core``, ``langchain-community``,
    ``numpy``
"""

from __future__ import annotations

import copy
import logging
import re
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, cast

import numpy as np
from langchain_community.utils.math import cosine_similarity
from langchain_core.documents import BaseDocumentTransformer, Document
from langchain_core.embeddings import Embeddings
from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)

logger = logging.getLogger(__name__)

# =====================================================================
#  Output data structure (shared by all strategies)
# =====================================================================

@dataclass
class ChunkWithMetadata:
    """A single text chunk enriched with structural metadata."""

    content: str
    heading_path: str = ""
    section_heading: str = ""
    parent_heading: str = ""
    chunk_index: int = 0
    metadata: Dict[str, str] = field(default_factory=dict)
    content_for_embedding: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# =====================================================================
#  Heading helpers (used by heading_aware & hybrid)
# =====================================================================

HEADERS_TO_SPLIT_ON = [
    ("#", "h1"),
    ("##", "h2"),
    ("###", "h3"),
    ("####", "h4"),
    ("#####", "h5"),
    ("######", "h6"),
]

_HEADING_RE = re.compile(r"^#{1,6}\s+", re.MULTILINE)


def _has_markdown_headings(text: str) -> bool:
    """Return True if *text* contains at least one markdown heading."""
    return bool(_HEADING_RE.search(text))


def _build_heading_path(metadata: Dict[str, str]) -> str:
    """Build a breadcrumb string from heading-level metadata.

    Example: ``{"h1": "API", "h3": "Intro"}`` -> ``"API > Intro"``
    """
    parts = []
    for level in ("h1", "h2", "h3", "h4", "h5", "h6"):
        val = metadata.get(level, "").strip()
        if val:
            parts.append(val)
    return " > ".join(parts)


def _extract_section_and_parent(metadata: Dict[str, str]) -> Tuple[str, str]:
    """Return ``(deepest_heading, its_parent)`` from heading metadata."""
    headings = []
    for level in ("h1", "h2", "h3", "h4", "h5", "h6"):
        val = metadata.get(level, "").strip()
        if val:
            headings.append(val)
    section = headings[-1] if headings else ""
    parent = headings[-2] if len(headings) >= 2 else ""
    return section, parent


def _wrap_chunks(
    raw_chunks: List[Dict[str, Any]],
    *,
    start_index: int = 0,
) -> List[ChunkWithMetadata]:
    """Convert raw dicts (content + heading metadata) into ChunkWithMetadata."""
    results: List[ChunkWithMetadata] = []
    for i, item in enumerate(raw_chunks):
        content = item["content"]
        meta = {k: v for k, v in item.items() if k != "content"}

        heading_path = _build_heading_path(meta)
        section, parent = _extract_section_and_parent(meta)

        embedding_text = f"{heading_path}\n\n{content}" if heading_path else content

        results.append(ChunkWithMetadata(
            content=content,
            heading_path=heading_path,
            section_heading=section,
            parent_heading=parent,
            chunk_index=start_index + i,
            metadata=meta,
            content_for_embedding=embedding_text,
        ))
    return results


def _merge_small_chunks(
    chunks: List[ChunkWithMetadata],
    min_chunk_size: int,
) -> List[ChunkWithMetadata]:
    """Merge consecutive chunks smaller than *min_chunk_size* with same heading path."""
    if not chunks or min_chunk_size <= 0:
        return chunks

    merged: List[ChunkWithMetadata] = []
    buffer: Optional[ChunkWithMetadata] = None

    for chunk in chunks:
        if buffer is None:
            buffer = chunk
            continue

        same_section = buffer.heading_path == chunk.heading_path

        if same_section and len(buffer.content) < min_chunk_size:
            buffer = ChunkWithMetadata(
                content=buffer.content + "\n" + chunk.content,
                heading_path=buffer.heading_path,
                section_heading=buffer.section_heading,
                parent_heading=buffer.parent_heading,
                chunk_index=buffer.chunk_index,
                metadata=buffer.metadata,
                content_for_embedding=(
                    f"{buffer.heading_path}\n\n{buffer.content}\n{chunk.content}"
                    if buffer.heading_path
                    else buffer.content + "\n" + chunk.content
                ),
            )
        else:
            merged.append(buffer)
            buffer = chunk

    if buffer is not None:
        merged.append(buffer)

    return merged


# Regex: keeps only word characters (letters, digits, underscore)
_MULTI_BLANK_LINES_RE = re.compile(r"\n{3,}")
_MULTI_SPACES_RE = re.compile(r"[^\S\n]{2,}")
_UNICODE_CONTROL_RE = re.compile(
    r"[\u200b\u200c\u200d\u00ad\ufeff\u2028\u2029\u00a0]"
)


def normalize_text(text: str) -> str:
    """Normalize text before chunking for consistent, high-quality results.

    Applies the following transformations:
    - Strips Unicode control characters (zero-width spaces, soft hyphens,
      BOM, non-breaking spaces, line/paragraph separators).
    - Normalizes line endings to ``\\n``.
    - Collapses 3+ consecutive blank lines into 2.
    - Collapses runs of multiple spaces/tabs (within a line) into one space.
    - Strips leading/trailing whitespace from the whole text.
    """
    if not text:
        return text
    text = _UNICODE_CONTROL_RE.sub("", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _MULTI_BLANK_LINES_RE.sub("\n\n", text)
    text = _MULTI_SPACES_RE.sub(" ", text)
    return text.strip()


_WORD_CHAR_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _is_noise_chunk(content: str, *, min_alpha_chars: int = 30) -> bool:
    """Return True if *content* has no meaningful text.

    A chunk is considered noise when it consists entirely of whitespace,
    punctuation, and/or repeated separator characters (dashes, equals,
    underscores, asterisks, etc.) without any real words.

    ``min_alpha_chars`` is the minimum number of alphanumeric characters
    (across all words) required for a chunk to be considered meaningful.
    """
    if not content or not content.strip():
        return True
    alpha_chars = sum(len(m.group()) for m in _WORD_CHAR_RE.finditer(content))
    return alpha_chars < min_alpha_chars


def _filter_noise_chunks(
    chunks: List[ChunkWithMetadata],
    *,
    min_alpha_chars: int = 10,
) -> List[ChunkWithMetadata]:
    """Remove chunks that contain no meaningful text content.

    Drops chunks made up entirely of separator/decorative characters
    (long runs of dashes, equals signs, etc.) that add no value to the
    search index or embeddings.
    """
    kept: List[ChunkWithMetadata] = []
    dropped = 0
    for chunk in chunks:
        if _is_noise_chunk(chunk.content, min_alpha_chars=min_alpha_chars):
            dropped += 1
            logger.debug(
                "Dropping noise chunk (index=%d, len=%d): %.60s…",
                chunk.chunk_index,
                len(chunk.content),
                chunk.content.replace("\n", "\\n"),
            )
        else:
            kept.append(chunk)
    if dropped:
        logger.info("Filtered out %d noise chunk(s) with no meaningful text.", dropped)
    return kept


# =====================================================================
#  Strategy 1: Recursive Character Splitting
# =====================================================================

def chunk_recursive(
    text: str,
    *,
    chunk_size: int = 1000,
    chunk_overlap: int = 100,
) -> List[ChunkWithMetadata]:
    """Split *text* using ``RecursiveCharacterTextSplitter``.

    Fast, deterministic splitting on paragraph/sentence/word boundaries.
    No heading awareness or structural metadata — each chunk gets a plain
    ``chunk_index`` only.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    plain_chunks = splitter.split_text(text)
    return [
        ChunkWithMetadata(
            content=c,
            chunk_index=i,
            content_for_embedding=c,
        )
        for i, c in enumerate(plain_chunks)
    ]


# =====================================================================
#  Strategy 2: Semantic Chunking
# =====================================================================

BreakpointThresholdType = Literal[
    "percentile", "standard_deviation", "interquartile", "gradient"
]
BREAKPOINT_DEFAULTS: Dict[BreakpointThresholdType, float] = {
    "percentile": 95,
    "standard_deviation": 3,
    "interquartile": 1.5,
    "gradient": 95,
}


def _combine_sentences(sentences: List[dict], buffer_size: int = 1) -> List[dict]:
    """Build combined sentence windows for embedding."""
    for i in range(len(sentences)):
        combined_sentence = ""
        for j in range(i - buffer_size, i):
            if j >= 0:
                combined_sentence += sentences[j]["sentence"] + " "
        combined_sentence += sentences[i]["sentence"]
        for j in range(i + 1, i + 1 + buffer_size):
            if j < len(sentences):
                combined_sentence += " " + sentences[j]["sentence"]
        sentences[i]["combined_sentence"] = combined_sentence
    return sentences


def _calculate_cosine_distances(
    sentences: List[dict],
) -> Tuple[List[float], List[dict]]:
    """Calculate cosine distances between consecutive sentence embeddings."""
    distances = []
    for i in range(len(sentences) - 1):
        embedding_current = sentences[i]["combined_sentence_embedding"]
        embedding_next = sentences[i + 1]["combined_sentence_embedding"]
        similarity = cosine_similarity([embedding_current], [embedding_next])[0][0]
        distance = 1 - similarity
        distances.append(distance)
        sentences[i]["distance_to_next"] = distance
    return distances, sentences


class SemanticChunker(BaseDocumentTransformer):
    """Split text based on semantic similarity using embeddings.

    Groups consecutive sentences whose embeddings are semantically
    similar.  Chunk boundaries are placed where cosine distance between
    adjacent sentence-group embeddings exceeds a threshold.
    """

    def __init__(
        self,
        embeddings: Embeddings,
        buffer_size: int = 1,
        add_start_index: bool = False,
        breakpoint_threshold_type: BreakpointThresholdType = "percentile",
        breakpoint_threshold_amount: Optional[float] = None,
        number_of_chunks: Optional[int] = None,
        sentence_split_regex: str = r"(?<=[.?!])\s+",
        min_chunk_size: Optional[int] = None,
    ):
        self._add_start_index = add_start_index
        self.embeddings = embeddings
        self.buffer_size = buffer_size
        self.breakpoint_threshold_type = breakpoint_threshold_type
        self.number_of_chunks = number_of_chunks
        self.sentence_split_regex = sentence_split_regex
        if breakpoint_threshold_amount is None:
            self.breakpoint_threshold_amount = BREAKPOINT_DEFAULTS[
                breakpoint_threshold_type
            ]
        else:
            self.breakpoint_threshold_amount = breakpoint_threshold_amount
        self.min_chunk_size = min_chunk_size

    def _calculate_breakpoint_threshold(
        self, distances: List[float]
    ) -> Tuple[float, List[float]]:
        if self.breakpoint_threshold_type == "percentile":
            return cast(
                float, np.percentile(distances, self.breakpoint_threshold_amount)
            ), distances
        elif self.breakpoint_threshold_type == "standard_deviation":
            return cast(
                float,
                np.mean(distances)
                + self.breakpoint_threshold_amount * np.std(distances),
            ), distances
        elif self.breakpoint_threshold_type == "interquartile":
            q1, q3 = np.percentile(distances, [25, 75])
            iqr = q3 - q1
            return np.mean(
                distances
            ) + self.breakpoint_threshold_amount * iqr, distances
        elif self.breakpoint_threshold_type == "gradient":
            distance_gradient = np.gradient(distances, range(0, len(distances)))
            return cast(
                float,
                np.percentile(distance_gradient, self.breakpoint_threshold_amount),
            ), distance_gradient
        else:
            raise ValueError(
                f"Unknown breakpoint_threshold_type: {self.breakpoint_threshold_type}"
            )

    def _threshold_from_clusters(self, distances: List[float]) -> float:
        if self.number_of_chunks is None:
            raise ValueError(
                "This should never be called if number_of_chunks is None."
            )
        x1, y1 = len(distances), 0.0
        x2, y2 = 1.0, 100.0
        x = max(min(self.number_of_chunks, x1), x2)
        if x2 == x1:
            y = y2
        else:
            y = y1 + ((y2 - y1) / (x2 - x1)) * (x - x1)
        y = min(max(y, 0), 100)
        return cast(float, np.percentile(distances, y))

    def _calculate_sentence_distances(
        self, single_sentences_list: List[str]
    ) -> Tuple[List[float], List[dict]]:
        _sentences = [
            {"sentence": x, "index": i}
            for i, x in enumerate(single_sentences_list)
        ]
        sentences = _combine_sentences(_sentences, self.buffer_size)
        embeddings = self.embeddings.embed_documents(
            [x["combined_sentence"] for x in sentences]
        )
        for i, sentence in enumerate(sentences):
            sentence["combined_sentence_embedding"] = embeddings[i]
        return _calculate_cosine_distances(sentences)

    def split_text(self, text: str) -> List[str]:
        """Split *text* into semantically coherent chunks."""
        single_sentences_list = re.split(self.sentence_split_regex, text)

        if len(single_sentences_list) == 1:
            return single_sentences_list
        if (
            self.breakpoint_threshold_type == "gradient"
            and len(single_sentences_list) == 2
        ):
            return single_sentences_list

        distances, sentences = self._calculate_sentence_distances(
            single_sentences_list
        )

        if self.number_of_chunks is not None:
            breakpoint_distance_threshold = self._threshold_from_clusters(distances)
            breakpoint_array = distances
        else:
            (
                breakpoint_distance_threshold,
                breakpoint_array,
            ) = self._calculate_breakpoint_threshold(distances)

        indices_above_thresh = [
            i
            for i, x in enumerate(breakpoint_array)
            if x > breakpoint_distance_threshold
        ]

        chunks = []
        start_index = 0

        for index in indices_above_thresh:
            end_index = index
            group = sentences[start_index : end_index + 1]
            combined_text = " ".join([d["sentence"] for d in group])
            if self.min_chunk_size is not None and len(combined_text) < self.min_chunk_size:
                continue
            chunks.append(combined_text)
            start_index = index + 1

        if start_index < len(sentences):
            combined_text = " ".join(
                [d["sentence"] for d in sentences[start_index:]]
            )
            chunks.append(combined_text)
        return chunks

    def create_documents(
        self, texts: List[str], metadatas: Optional[List[dict]] = None
    ) -> List[Document]:
        _metadatas = metadatas or [{}] * len(texts)
        documents = []
        for i, text in enumerate(texts):
            start_index = 0
            for chunk in self.split_text(text):
                metadata = copy.deepcopy(_metadatas[i])
                if self._add_start_index:
                    metadata["start_index"] = start_index
                new_doc = Document(page_content=chunk, metadata=metadata)
                documents.append(new_doc)
                start_index += len(chunk)
        return documents

    def split_documents(self, documents: Sequence[Document]) -> List[Document]:
        texts, metadatas = [], []
        for doc in documents:
            texts.append(doc.page_content)
            metadatas.append(doc.metadata)
        return self.create_documents(texts, metadatas=metadatas)

    def transform_documents(
        self, documents: Sequence[Document], **kwargs: Any
    ) -> Sequence[Document]:
        return self.split_documents(list(documents))


def chunk_semantic(
    text: str,
    embeddings: Embeddings,
    *,
    breakpoint_threshold_type: BreakpointThresholdType = "percentile",
    breakpoint_threshold_amount: Optional[float] = None,
) -> List[ChunkWithMetadata]:
    """Split *text* using embedding-based semantic chunking.

    Returns ``ChunkWithMetadata`` objects (no heading metadata since
    semantic chunking is structure-agnostic).
    """
    chunker = SemanticChunker(
        embeddings=embeddings,
        breakpoint_threshold_type=breakpoint_threshold_type,
        breakpoint_threshold_amount=breakpoint_threshold_amount,
    )
    plain_chunks = chunker.split_text(text)
    return [
        ChunkWithMetadata(
            content=c,
            chunk_index=i,
            content_for_embedding=c,
        )
        for i, c in enumerate(plain_chunks)
    ]


# =====================================================================
#  Strategy 3: Heading-Aware (Context-Aware)
# =====================================================================

_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```", re.MULTILINE)
_JSON_BRACE_RE = re.compile(
    r"\{[^{}]*(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}[^{}]*)*\}",
    re.DOTALL,
)


def _protect_code_blocks(text: str, chunk_size: int) -> Tuple[str, Dict[str, str]]:
    """Replace fenced code blocks and large JSON objects with placeholders.

    Returns the modified text and a mapping of placeholder -> original content.
    Blocks smaller than chunk_size/3 are left inline (they won't cause splits).
    """
    placeholders: Dict[str, str] = {}
    counter = 0

    def _replace(match: re.Match) -> str:
        nonlocal counter
        content = match.group(0)
        if len(content) < chunk_size // 3:
            return content
        key = f"__CODE_BLOCK_{counter}__"
        counter += 1
        placeholders[key] = content
        return key

    text = _CODE_BLOCK_RE.sub(_replace, text)
    text = _JSON_BRACE_RE.sub(_replace, text)
    return text, placeholders


def _restore_code_blocks(chunks: List[Dict[str, Any]], placeholders: Dict[str, str]) -> List[Dict[str, Any]]:
    """Restore original code blocks from placeholders in chunk content."""
    if not placeholders:
        return chunks
    restored = []
    for chunk in chunks:
        content = chunk["content"]
        for key, original in placeholders.items():
            if key in content:
                content = content.replace(key, original)
        entry = dict(chunk)
        entry["content"] = content
        restored.append(entry)
    return restored


def chunk_heading_aware(
    text: str,
    *,
    chunk_size: int = 1000,
    chunk_overlap: int = 100,
    strip_headers: bool = False,
) -> List[ChunkWithMetadata]:
    """Split *text* by markdown headings, then sub-chunk large sections.

    Stage 1: ``MarkdownHeaderTextSplitter`` splits on ``#`` - ``######``.
    Stage 2: Code/JSON blocks that exceed chunk_size/3 are protected from
    splitting so they remain intact.
    Stage 3: ``RecursiveCharacterTextSplitter`` breaks any section that
    exceeds *chunk_size* characters.  Heading metadata propagates to
    every sub-chunk.
    Stage 4: Protected blocks are restored to their original content.
    """
    md_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=HEADERS_TO_SPLIT_ON,
        strip_headers=strip_headers,
    )
    header_docs = md_splitter.split_text(text)

    recursive_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    all_placeholders: Dict[str, str] = {}
    protected_docs = []
    for doc in header_docs:
        protected_text, placeholders = _protect_code_blocks(doc.page_content, chunk_size)
        all_placeholders.update(placeholders)
        protected_docs.append(Document(page_content=protected_text, metadata=doc.metadata))

    sub_docs = recursive_splitter.split_documents(protected_docs)

    raw: List[Dict[str, Any]] = []
    for doc in sub_docs:
        entry = dict(doc.metadata)
        entry["content"] = doc.page_content
        raw.append(entry)

    raw = _restore_code_blocks(raw, all_placeholders)

    return _wrap_chunks(raw)


# =====================================================================
#  Strategy 4: Hybrid (Heading-Aware + Semantic sub-chunk)
# =====================================================================

def chunk_hybrid(
    text: str,
    embeddings: Embeddings,
    *,
    chunk_size: int = 1000,
    chunk_overlap: int = 100,
    strip_headers: bool = False,
    semantic_threshold_type: BreakpointThresholdType = "percentile",
    semantic_threshold_amount: float = 95,
) -> List[ChunkWithMetadata]:
    """Split *text* by headings, then apply semantic sub-chunking.

    Stage 1: ``MarkdownHeaderTextSplitter`` for heading boundaries.
    Stage 2: For sections exceeding *chunk_size*, use ``SemanticChunker``
    to find natural topic-shift boundaries.  Sections that are already
    small enough are kept as-is.
    """
    md_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=HEADERS_TO_SPLIT_ON,
        strip_headers=strip_headers,
    )
    header_docs = md_splitter.split_text(text)

    semantic_chunker = SemanticChunker(
        embeddings=embeddings,
        breakpoint_threshold_type=semantic_threshold_type,
        breakpoint_threshold_amount=semantic_threshold_amount,
    )

    recursive_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    raw: List[Dict[str, Any]] = []
    for doc in header_docs:
        section_text = doc.page_content
        section_meta = dict(doc.metadata)

        if len(section_text) <= chunk_size:
            entry = dict(section_meta)
            entry["content"] = section_text
            raw.append(entry)
        else:
            try:
                sub_texts = semantic_chunker.split_text(section_text)
            except Exception as exc:
                logger.warning(
                    "Semantic sub-chunking failed, falling back to recursive: %s",
                    exc,
                )
                sub_texts = recursive_splitter.split_text(section_text)

            for sub_text in sub_texts:
                if len(sub_text) > chunk_size:
                    for micro in recursive_splitter.split_text(sub_text):
                        entry = dict(section_meta)
                        entry["content"] = micro
                        raw.append(entry)
                else:
                    entry = dict(section_meta)
                    entry["content"] = sub_text
                    raw.append(entry)

    return _wrap_chunks(raw)


# =====================================================================
#  Unified entry point
# =====================================================================

def chunk_text(
    text: str,
    *,
    strategy: str = "heading_aware",
    chunk_size: int = 2000,
    chunk_overlap: int = 200,
    min_chunk_size: int = 200,
    strip_headers: bool = False,
    embeddings=None,
    source_metadata: Optional[Dict[str, str]] = None,
) -> List[ChunkWithMetadata]:
    """Split *text* using any of the four chunking strategies.

    Automatically detects whether the text contains markdown headings.
    For heading-aware and hybrid strategies, heading-based splitting is
    used when headings are present; otherwise falls back to recursive.

    Text is normalized before chunking (Unicode control characters
    stripped, line endings unified, excessive blank lines collapsed)
    to ensure consistent chunk counts across different environments.

    Parameters
    ----------
    text : str
        The document text to chunk.
    strategy : str
        ``"heading_aware"`` (default), ``"hybrid"``, ``"semantic"``,
        or ``"recursive"``.
    chunk_size : int
        Maximum chunk size in characters.
    chunk_overlap : int
        Overlap between consecutive chunks.
    min_chunk_size : int
        Minimum chunk size.  Consecutive chunks from the same section
        that are smaller than this are merged together (default 200).
    strip_headers : bool
        Remove headings from chunk body (metadata only).
    embeddings
        Required for ``"hybrid"`` and ``"semantic"`` strategies.
        Must implement ``embed_documents``.
    source_metadata : dict | None
        Extra metadata to attach to every chunk (e.g. filename, source URL).

    Returns
    -------
    List[ChunkWithMetadata]
        Ordered chunks with structural metadata.
    """
    if not text or not text.strip():
        return []

    text = normalize_text(text)

    has_headings = _has_markdown_headings(text)

    if strategy == "semantic":
        if embeddings is None:
            raise ValueError(
                "The 'semantic' strategy requires an embeddings object."
            )
        chunks = chunk_semantic(text, embeddings)

    elif strategy == "hybrid" and has_headings:
        if embeddings is None:
            raise ValueError(
                "The 'hybrid' strategy requires an embeddings object."
            )
        chunks = chunk_hybrid(
            text,
            embeddings,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            strip_headers=strip_headers,
        )

    elif strategy in ("heading_aware", "hybrid") and has_headings:
        chunks = chunk_heading_aware(
            text,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            strip_headers=strip_headers,
        )

    else:
        if strategy in ("heading_aware", "hybrid") and not has_headings:
            logger.info(
                "No markdown headings detected - falling back to recursive chunking."
            )
        chunks = chunk_recursive(
            text,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    if min_chunk_size > 0:
        chunks = _merge_small_chunks(chunks, min_chunk_size)

    chunks = _filter_noise_chunks(chunks)

    if source_metadata:
        for chunk in chunks:
            chunk.metadata.update(source_metadata)

    for i, chunk in enumerate(chunks):
        chunk.chunk_index = i

    return chunks


# =====================================================================
#  Pipeline convenience helpers
# =====================================================================

def chunks_to_texts_and_metadata(
    chunks: List[ChunkWithMetadata],
) -> Tuple[List[str], List[str], List[Dict[str, Any]]]:
    """Unpack chunks into parallel lists for the indexing pipeline.

    Returns
    -------
    tuple
        ``(content_texts, embedding_texts, metadata_list)``

        * *content_texts* - raw chunk body (stored in the search index).
        * *embedding_texts* - heading-prepended text (used for embedding).
        * *metadata_list* - per-chunk metadata dicts.
    """
    content_texts: List[str] = []
    embedding_texts: List[str] = []
    metadata_list: List[Dict[str, Any]] = []

    for chunk in chunks:
        content_texts.append(chunk.content)
        embedding_texts.append(chunk.content_for_embedding)
        metadata_list.append({
            "section_heading": chunk.section_heading,
            "parent_heading": chunk.parent_heading,
            "heading_path": chunk.heading_path,
            "chunk_index": chunk.chunk_index,
            **chunk.metadata,
        })

    return content_texts, embedding_texts, metadata_list


# =====================================================================
#  Standalone test / demo
# =====================================================================
if __name__ == "__main__":
    import sys
    from pathlib import Path

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if len(sys.argv) > 1:
        src = Path(sys.argv[1])
        if not src.exists():
            print(f"File not found: {src}")
            sys.exit(1)
        text = src.read_text(encoding="utf-8", errors="replace")
    else:
        default = Path(__file__).resolve().parent / "output_url.txt"
        if default.exists():
            text = default.read_text(encoding="utf-8", errors="replace")
            print(f"Using default test file: {default}\n")
        else:
            print("Usage: python chunking_strategies.py [markdown_file] [strategy]")
            sys.exit(1)

    strategy = sys.argv[2] if len(sys.argv) > 2 else "heading_aware"

    print(f"Strategy: {strategy}")
    print(f"Text length: {len(text):,} chars")
    print(f"Has markdown headings: {_has_markdown_headings(text)}")
    print("=" * 70)

    chunks = chunk_text(
        text,
        strategy=strategy,
        chunk_size=1000,
        chunk_overlap=100,
        source_metadata={"filename": "test_doc", "source": "demo"},
    )

    content_texts, embedding_texts, metadata_list = chunks_to_texts_and_metadata(
        chunks
    )

    print(f"\nTotal chunks: {len(chunks)}\n")

    for i, chunk in enumerate(chunks):
        print(f"{'-' * 70}")
        print(f"CHUNK {i}")
        print(f"  heading_path:    {chunk.heading_path}")
        print(f"  section_heading: {chunk.section_heading}")
        print(f"  parent_heading:  {chunk.parent_heading}")
        print(f"  chunk_index:     {chunk.chunk_index}")
        print(f"  metadata:        {chunk.metadata}")
        print(f"  content length:  {len(chunk.content)} chars")
        print(f"  embed length:    {len(chunk.content_for_embedding)} chars")
        preview = chunk.content[:200].replace("\n", "\\n")
        print(f"  content preview: {preview}...")
        print()

    print(f"{'=' * 70}")
    print(f"Summary: {len(chunks)} chunks from {len(text):,} chars")
    avg_len = sum(len(c.content) for c in chunks) / len(chunks) if chunks else 0
    print(f"Average chunk size: {avg_len:.0f} chars")
    unique_sections = {c.section_heading for c in chunks if c.section_heading}
    print(f"Unique sections: {len(unique_sections)}")
    for s in sorted(unique_sections):
        count = sum(1 for c in chunks if c.section_heading == s)
        print(f"  [{count} chunks] {s}")
