"""
Comprehensive Web Scraper

Extracts structured content from web pages while maintaining the original layout.
Uses Playwright (headless browser) by default to handle JavaScript-rendered pages,
interactive tabs, expandable/collapsible sections, and lazy-loaded content.
Falls back to plain HTTP requests when Playwright is unavailable.

Supported content types:
    Headings, Paragraphs, Lists (ordered, unordered, definition),
    Tables, Forms, Links, Images, Blockquotes, Code blocks,
    Navigation, Header, Footer, Article, Section, Aside,
    Tabs (ARIA roles + Bootstrap/custom — all panels revealed),
    Accordions (HTML5 details + Bootstrap/custom — all sections expanded),
    Metadata (meta tags, Open Graph, Twitter Cards),
    JSON-LD and embedded JSON data from script tags,
    Hidden content (hidden attr, CSS display:none, aria-hidden),
    Framework pre-loaded data (Next.js __NEXT_DATA__, Nuxt, initial state).

Dependencies:
    pip install requests beautifulsoup4 lxml playwright
    playwright install chromium

Usage:
    from web_scrapping import scrape_webpage

    # From a live URL:
    result = scrape_webpage("https://example.com")
    print(result["metadata"])            # dict of all meta-tag key/value pairs
    print(result["metadata"]["title"])   # page title lives here
    print(result["web_page_content"])    # structured page text

    # From a local HTML file (e.g. abc.html):
    result = scrape_webpage("abc.html")

    # To skip Playwright and use plain HTTP requests only (URLs only):
    result = scrape_webpage("https://example.com", use_playwright=False)
"""

import asyncio
import logging
import requests
import json
import re
import time
import warnings
import sys
from pathlib import Path
from bs4 import BeautifulSoup, Tag, NavigableString, Comment
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Dict, List, Tuple
from urllib.parse import urljoin, urlparse
from playwright.sync_api import sync_playwright

from salesforce_lightning import capture_slds_tab_groups

logger = logging.getLogger(__name__)


class WebScraper:
    """Extracts structured content from web pages preserving layout hierarchy."""

    HEADERS = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
    }

    INLINE_TAGS = frozenset({
        'a', 'abbr', 'acronym', 'b', 'bdo', 'big', 'br', 'cite', 'code',
        'dfn', 'em', 'i', 'img', 'kbd', 'label', 'mark', 'q', 'samp',
        'small', 'span', 'strong', 'sub', 'sup', 'time', 'tt', 'u', 'var',
        'del', 'ins', 'wbr', 's', 'strike',
    })

    SKIP_TAGS = frozenset({'script', 'style', 'link', 'noscript', 'svg', 'path', 'template'})

    TAB_PANEL_CLASSES = frozenset({
        'tab-pane', 'tab-panel', 'tabpanel',
        'slds-tabs_default__content',
        'slds-tabs_scoped__content',
        'slds-tabs_medium__content',
    })

    # CSS classes / element names that bound a "logical column" inside the
    # rendered DOM.  When walking back from a tab panel to find the
    # heading that establishes its surrounding section we never cross
    # one of these boundaries — otherwise we end up picking up sidebar /
    # mega-nav headings (e.g. an ``<h6>Developer Portal</h6>`` in a
    # different SLDS column) instead of the actual content heading.
    _ISOLATION_CLASSES = frozenset({
        'cb-section_column',
        'cb-section_row',
        'cb-section',
        'forceCommunitySection',
        'comm-layout-column',
    })

    def __init__(self, url_or_file: str, timeout: int = 30, use_playwright: bool = True):
        """
        Initialise the scraper for a target URL or local HTML file.

        Args:
            url_or_file (str): Either a webpage URL (e.g. https://example.com)
                or a local HTML file path (e.g. abc.html, ./page.html).
            timeout (int, optional): HTTP request timeout in seconds. Defaults to 30.
            use_playwright (bool, optional): If True (default), use a headless
                Chromium browser via the file:// protocol for local HTML
                files and for URLs alike — executing JavaScript, clicking
                tabs, and expanding accordions.  Falls back to plain disk
                read (files) or plain HTTP (URLs) when Playwright is
                unavailable.
        """
        self._is_file = self._is_html_file(url_or_file)
        if self._is_file:
            self.url = self._file_path_to_url(url_or_file)
            self._file_path = Path(url_or_file).resolve()
        else:
            self.url = url_or_file
            self._file_path = None
        self.timeout = timeout
        self.use_playwright = use_playwright
        self.soup: Optional[BeautifulSoup] = None
        self.raw_html: Optional[str] = None
        # Tracking state used while walking the DOM to decide what
        # heading level to emit for tab-panel labels and to keep
        # heading-like markup inside tab panels nested at the right
        # depth so each tab forms a coherent chunkable section.
        self._current_heading_level: int = 0
        # When > 0, we are processing the children of a tab panel that
        # was emitted with a markdown heading at this level.  Real
        # inner headings are forced to be at least one level deeper so
        # they nest under the tab label in the heading-aware
        # breadcrumb path; "fake" inner headings (body text wrongly
        # styled as a heading) are demoted to bold paragraphs by
        # :meth:`_is_fake_heading`.
        self._tab_panel_level: int = 0
        # When True, every inner heading inside the current tab panel
        # is demoted to a bold paragraph regardless of whether it
        # looks fake.  Set by :meth:`_is_qa_style_panel` for FAQ-style
        # tabs whose ``<h2>`` tags are mostly Q&A questions, so the
        # tab still collapses into a single chunkable section.
        self._force_demote_inner_headings: bool = False

    @staticmethod
    def _is_html_file(input_str: str) -> bool:
        """Determine whether *input_str* is a local HTML file path.

        Parameters
        ----------
        input_str : str
            A URL or file path string.

        Returns
        -------
        bool
            ``True`` if the string does not start with ``http://`` or
            ``https://`` and either ends with ``.html``/``.htm`` or
            resolves to an existing file on disk.
        """
        s = input_str.strip()
        if s.startswith(('http://', 'https://')):
            return False
        return s.endswith(('.html', '.htm')) or Path(s).exists()

    @staticmethod
    def _file_path_to_url(file_path: str) -> str:
        """Convert a local file path to a ``file://`` URL.

        Parameters
        ----------
        file_path : str
            Relative or absolute path to an HTML file.

        Returns
        -------
        str
            A ``file:///...`` URI suitable as a base for ``urljoin``.
        """
        p = Path(file_path).resolve()
        return p.as_uri()

    # ------------------------------------------------------------------ #
    #  Fetching
    # ------------------------------------------------------------------ #

    def fetch(self) -> None:
        """
        Fetch and parse the webpage or HTML file.

        For HTML files with *use_playwright* enabled: opens the file via
        its ``file://`` URL in a headless browser so JavaScript executes,
        tabs are clicked, and accordions are expanded — identical to the
        live-URL path.  Falls back to a plain disk read when Playwright
        is unavailable.

        For URLs: tries Playwright first (full JS rendering + interactive
        expansion) and falls back to plain HTTP requests when Playwright
        is unavailable or when *use_playwright* is False.
        """
        if self._is_file:
            if self.use_playwright:
                try:
                    self._fetch_with_playwright()
                    return
                except ImportError:
                    logger.info("Playwright not installed, falling back to disk read.")
                    warnings.warn(
                        "Playwright is not installed — falling back to plain disk read. "
                        "Install it with:  pip install playwright && playwright install chromium"
                    )
                except Exception as exc:
                    logger.debug("Playwright failed for local file, falling back to disk read: %s", exc)
                    warnings.warn(f"Playwright failed ({exc}), falling back to plain disk read.")
            self._fetch_from_file()
            return
        if self.use_playwright:
            try:
                self._fetch_with_playwright()
                return
            except ImportError:
                logger.info("Playwright not installed, falling back to plain HTTP.")
                warnings.warn(
                    "Playwright is not installed — falling back to plain HTTP. "
                    "Install it with:  pip install playwright && playwright install chromium"
                )
            except Exception as exc:
                logger.debug("Playwright failed, falling back to HTTP: %s", exc)
                warnings.warn(f"Playwright failed ({exc}), falling back to plain HTTP.")
        self._fetch_with_requests()

    _session: Optional[requests.Session] = None

    @classmethod
    def _get_session(cls) -> requests.Session:
        """Return a shared :class:`requests.Session` for connection reuse."""
        if cls._session is None:
            cls._session = requests.Session()
            cls._session.headers.update(cls.HEADERS)
        return cls._session

    def _fetch_with_requests(self, retries: int = 3,
                             backoff: float = 1.0) -> None:
        """Fetch the page with a simple HTTP GET (no JS execution).

        Retries up to *retries* times on transient network errors with
        exponential back-off.
        """
        session = self._get_session()
        last_exc: Optional[Exception] = None
        for attempt in range(1, retries + 1):
            try:
                response = session.get(
                    self.url, timeout=self.timeout, verify=True,
                )
                response.raise_for_status()
                response.encoding = response.apparent_encoding or 'utf-8'
                self.raw_html = response.text
                self._parse_html()
                return
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_exc = exc
                logger.debug(
                    "HTTP attempt %d/%d failed: %s", attempt, retries, exc,
                )
                if attempt < retries:
                    time.sleep(backoff * attempt)
        raise last_exc  # type: ignore[misc]

    def _fetch_with_playwright(self) -> None:
        """
        Fetch the page with a headless Chromium browser, execute all
        JavaScript, then click every tab and expand every collapsible
        section so all content is visible before extraction.

        Automatically detects if an asyncio event loop is already running
        (e.g. inside Jupyter / IPython) and offloads Playwright to a
        separate thread to avoid the sync-inside-async conflict.
        """
        try:
            asyncio.get_running_loop()
            in_async = True
        except RuntimeError:
            in_async = False

        if in_async:
            with ThreadPoolExecutor(max_workers=1) as pool:
                pool.submit(self._run_playwright_sync).result()
        else:
            self._run_playwright_sync()

    def _run_playwright_sync(self) -> None:
        """
        Launch a headless Chromium browser, navigate to the target URL,
        expand all interactive content, and store the final HTML.

        On Windows, Jupyter / IPython swap the default asyncio loop to
        SelectorEventLoop, which cannot launch subprocesses.  We
        temporarily restore the ProactorEventLoop policy so Playwright
        can start Chromium.
        """
        
        original_policy = None
        if sys.platform == 'win32':
            original_policy = asyncio.get_event_loop_policy()
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        try:
            self._launch_playwright()
        finally:
            if original_policy is not None:
                asyncio.set_event_loop_policy(original_policy)

    def _launch_playwright(self) -> None:
        """Start a headless Chromium browser, navigate to the URL, expand
        all interactive content (tabs, accordions, collapsibles), and
        store the fully-rendered HTML in ``self.raw_html``.

        Called by :meth:`_run_playwright_sync` after event-loop policy
        adjustments.
        """

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=self.HEADERS['User-Agent'],
                viewport={'width': 1920, 'height': 1080},
            )
            page = context.new_page()
            page.goto(
                self.url,
                wait_until='domcontentloaded',
                timeout=self.timeout * 1000,
            )

            if self._is_file:
                page.wait_for_timeout(500)
            else:
                try:
                    page.wait_for_load_state('networkidle', timeout=10000)
                except Exception:
                    logger.debug("networkidle wait timed out, proceeding.")
                self._wait_for_render(page)

            try:
                self._expand_all_content(page)
            except Exception as exc:
                logger.debug("Content expansion failed: %s", exc)

            self.raw_html = page.content()
            context.close()
            browser.close()

        self._parse_html()

    def _fetch_from_file(self) -> None:
        """Read HTML from a local file and parse it into ``self.soup``.

        Raises
        ------
        FileNotFoundError
            If the file path does not exist or was not set.
        """
        if not self._file_path or not self._file_path.exists():
            raise FileNotFoundError(f"HTML file not found: {self._file_path or 'unknown'}")
        self.raw_html = self._file_path.read_text(encoding='utf-8', errors='replace')
        self._parse_html()

    # ------------------------------------------------------------------ #
    #  Wait for JS frameworks to finish rendering
    # ------------------------------------------------------------------ #

    @staticmethod
    def _wait_for_render(page, *, poll_ms: int = 1000,
                         stable_checks: int = 3,
                         max_wait_ms: int = 30000) -> None:
        """Wait until the page body size stops growing, which signals that
        JS frameworks (React, Angular, Vue) have finished rendering.
        """
        prev_size = 0
        stable = 0
        waited = 0
        while waited < max_wait_ms:
            page.wait_for_timeout(poll_ms)
            waited += poll_ms
            cur_size = page.evaluate('() => document.body.innerHTML.length')
            if cur_size == prev_size:
                stable += 1
                if stable >= stable_checks:
                    return
            else:
                stable = 0
            prev_size = cur_size

    # ------------------------------------------------------------------ #
    #  Interactive expansion (Playwright)
    # ------------------------------------------------------------------ #

    # Selectors for elements that hide content behind a click.
    # Explicitly exclude dropdown toggles — clicking them opens an
    # overlay that blocks all subsequent interactions on the page.
    _EXPAND_SELECTORS = [
        '[aria-expanded="false"]:not([data-toggle="dropdown"]):not([data-bs-toggle="dropdown"]):not(.dropdown-toggle)',
        '[data-toggle="collapse"]',
        '[data-bs-toggle="collapse"]',
        '.accordion-button.collapsed',
        '.accordion-header',
        'details:not([open]) > summary',
    ]

    @staticmethod
    def _click_elements(page, selectors, *, delay: int = 300, max_clicks: int = 200) -> int:
        """Use Playwright's native click on every element matched by
        *selectors*.  Returns the number of elements actually clicked.

        Each element is clicked at most once (deduped by bounding-box
        position).  Stale / detached / invisible elements are silently
        skipped.
        """
        clicked_positions: set = set()
        total = 0
        for sel in selectors:
            handles = page.query_selector_all(sel)
            for handle in handles:
                if total >= max_clicks:
                    return total
                try:
                    box = handle.bounding_box()
                    if box is None:
                        continue
                    pos = (round(box['x'], 1), round(box['y'], 1))
                    if pos in clicked_positions:
                        continue
                    clicked_positions.add(pos)
                    handle.scroll_into_view_if_needed(timeout=1000)
                    handle.click(timeout=2000)
                    total += 1
                    page.wait_for_timeout(delay)
                except Exception:
                    pass
        return total

    _FORCE_REVEAL_JS = '''() => {
        /* Open all <details> elements */
        document.querySelectorAll('details').forEach(d => {
            d.open = true;
        });

        /* Show every tab pane */
        document.querySelectorAll(
            '.tab-pane, [role="tabpanel"]'
        ).forEach(el => {
            el.classList.add('show', 'active');
            el.classList.remove('slds-hide');
            el.classList.add('slds-show');
            el.style.removeProperty('display');
            el.style.removeProperty('visibility');
            el.style.removeProperty('height');
            el.style.removeProperty('overflow');
            el.removeAttribute('hidden');
            el.setAttribute('aria-hidden', 'false');
        });

        /* SLDS (Salesforce Lightning) tab panels */
        document.querySelectorAll(
            '.slds-tabs_default__content, .slds-tabs_scoped__content'
        ).forEach(el => {
            el.classList.remove('slds-hide');
            el.classList.add('slds-show');
            el.style.removeProperty('display');
            el.style.removeProperty('visibility');
            el.removeAttribute('hidden');
        });

        /* Expand every collapsible / accordion body */
        document.querySelectorAll(
            '.collapse, .accordion-collapse, .panel-collapse, .accordion-body'
        ).forEach(el => {
            el.classList.add('show');
            el.classList.remove('collapse', 'collapsed', 'collapsing');
            el.style.removeProperty('display');
            el.style.removeProperty('visibility');
            el.style.height = 'auto';
            el.style.removeProperty('overflow');
            el.removeAttribute('hidden');
        });

        /* Flip all aria-expanded to true */
        document.querySelectorAll('[aria-expanded="false"]').forEach(el => {
            el.setAttribute('aria-expanded', 'true');
            el.classList.remove('collapsed');
        });

        /* Swagger / Redoc specific: expand all operation blocks */
        document.querySelectorAll('.opblock:not(.is-open)').forEach(el => {
            el.classList.add('is-open');
        });
        document.querySelectorAll('.opblock-body').forEach(el => {
            el.style.removeProperty('display');
        });

        /* Generic: reveal common hidden-utility classes
           (skip modals, popups, cookie banners) */
        document.querySelectorAll('.d-none, .hidden, .hide, .slds-hide').forEach(el => {
            const dominated = el.closest(
                '.modal, .popup, .cookie, .gdpr, .overlay, .dialog'
            );
            if (!dominated) {
                el.classList.remove('d-none', 'hidden', 'hide', 'slds-hide');
                el.style.removeProperty('display');
            }
        });
    }'''

    _FORCE_REVEAL_SHADOW_JS = r'''() => {
        function revealInShadow(root) {
            root.querySelectorAll('details').forEach(d => { d.open = true; });

            root.querySelectorAll(
                '.tab-pane, [role="tabpanel"]'
            ).forEach(el => {
                el.classList.add('show', 'active');
                el.classList.remove('slds-hide');
                el.classList.add('slds-show');
                el.style.removeProperty('display');
                el.style.removeProperty('visibility');
                el.style.removeProperty('height');
                el.style.removeProperty('overflow');
                el.removeAttribute('hidden');
                el.setAttribute('aria-hidden', 'false');
            });

            root.querySelectorAll(
                '.slds-tabs_default__content, .slds-tabs_scoped__content'
            ).forEach(el => {
                el.classList.remove('slds-hide');
                el.classList.add('slds-show');
                el.style.removeProperty('display');
                el.removeAttribute('hidden');
            });

            root.querySelectorAll(
                '.collapse, .accordion-collapse, .panel-collapse, .accordion-body'
            ).forEach(el => {
                el.classList.add('show');
                el.classList.remove('collapse', 'collapsed', 'collapsing');
                el.style.removeProperty('display');
                el.style.height = 'auto';
                el.removeAttribute('hidden');
            });

            root.querySelectorAll('[aria-expanded="false"]').forEach(el => {
                el.setAttribute('aria-expanded', 'true');
                el.classList.remove('collapsed');
            });

            root.querySelectorAll('.slds-accordion__section').forEach(section => {
                section.classList.add('slds-is-open');
                const content = section.querySelector('.slds-accordion__content');
                if (content) {
                    content.style.removeProperty('display');
                    content.style.height = 'auto';
                    content.removeAttribute('hidden');
                }
            });

            root.querySelectorAll('.d-none, .hidden, .hide, .slds-hide').forEach(el => {
                if (!el.closest(
                    '.modal, .popup, .cookie, .gdpr, .overlay, .dialog'
                )) {
                    el.classList.remove('d-none', 'hidden', 'hide', 'slds-hide');
                    el.style.removeProperty('display');
                }
            });

            root.querySelectorAll('*').forEach(el => {
                if (el.shadowRoot) revealInShadow(el.shadowRoot);
            });
        }

        document.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) revealInShadow(el.shadowRoot);
        });
    }'''

    _COOKIE_DISMISS_SELECTORS = [
        '#onetrust-accept-btn-handler',
        '#accept-cookie-notification',
        '[id*="cookie"] button[class*="accept"]',
        '[id*="cookie"] button[class*="close"]',
        '[id*="consent"] button[class*="accept"]',
        '[class*="cookie-banner"] button',
        '[class*="cookie-consent"] button',
        '.gdpr-accept', '.cc-accept', '.cc-dismiss',
        'button[aria-label="Accept"]',
        'button[aria-label="Accept cookies"]',
        'button[aria-label="Accept all"]',
        'button[aria-label="Close"]',
        '[data-testid="cookie-accept"]',
        '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
        '.evidon-banner-acceptbutton',
    ]

    @classmethod
    def _dismiss_overlays(cls, page) -> None:
        """Attempt to dismiss cookie consent banners, GDPR popups, and
        similar overlays that block interaction with the page content.
        """
        for sel in cls._COOKIE_DISMISS_SELECTORS:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click(timeout=1500)
                    page.wait_for_timeout(300)
                    return
            except Exception:
                continue

    @classmethod
    def _expand_all_content(cls, page) -> None:
        """
        Click every tab, expand every accordion / collapsible section,
        and force-reveal all hidden panels so the DOM contains the full
        page content before we capture the HTML.

        Handles both traditional tab/accordion frameworks (Bootstrap,
        jQuery-UI) *and* React-style libraries (e.g. react-tabs) that
        completely unmount inactive panel content from the DOM.

        For unmounting frameworks the strategy is:
          1. Click each tab.
          2. Clone the now-visible panel into a persistent container.
          3. Move to the next tab (React unmounts the previous panel,
             but our clone survives).
          4. After all tabs, the persistent container holds every
             panel's content.
        """
        # ---- Step 0: Dismiss cookie / consent banners -----------------
        try:
            cls._dismiss_overlays(page)
        except Exception as exc:
            logger.debug("Cookie banner dismissal failed: %s", exc)

        # ---- Step 1: Expand collapsibles / accordions ----------------
        try:
            cls._click_elements(page, cls._EXPAND_SELECTORS, delay=300)
            page.wait_for_timeout(500)
            page.evaluate(cls._FORCE_REVEAL_JS)
            page.wait_for_timeout(300)

            cls._click_elements(page, cls._EXPAND_SELECTORS, delay=300)
            page.wait_for_timeout(500)
        except Exception as exc:
            logger.debug("Collapsible expansion failed: %s", exc)

        # ---- Step 1b: Shadow DOM force-reveal ------------------------
        try:
            page.evaluate(cls._FORCE_REVEAL_SHADOW_JS)
            page.wait_for_timeout(300)
        except Exception as exc:
            logger.debug("Shadow DOM force-reveal failed: %s", exc)

        # ---- Step 1c: Iterative accordion expansion ------------------
        #      Handles mutual-exclusion accordions and Shadow DOM
        #      elements that _click_elements cannot reach.
        try:
            cls._expand_shadow_dom_accordions(page)
        except Exception as exc:
            logger.debug("Shadow DOM accordion expansion failed: %s", exc)

        # ---- Step 2: SLDS tab groups (container-scoped) ----------------
        #      Must run before generic tab capture because SLDS tab
        #      groups often share duplicate panel IDs across groups.
        try:
            cls._capture_slds_tab_groups(page)
        except Exception as exc:
            logger.debug("SLDS tab group capture failed: %s", exc)

        # ---- Step 2b: Process remaining tab groups -------------------
        try:
            cls._capture_all_tab_panels(page)
        except Exception as exc:
            logger.debug("Tab panel capture failed: %s", exc)

        # ---- Step 2c: Handle overflow / "More" menu tabs -------------
        try:
            cls._capture_overflow_tab_panels(page)
        except Exception as exc:
            logger.debug("Overflow tab capture failed: %s", exc)

        # ---- Step 3: Final force-reveal ------------------------------
        try:
            page.evaluate(cls._FORCE_REVEAL_JS)
            page.evaluate(cls._FORCE_REVEAL_SHADOW_JS)
            page.wait_for_timeout(500)
        except Exception as exc:
            logger.debug("Force-reveal failed: %s", exc)

        # ---- Step 4: Remove redundant clones -------------------------
        # For frameworks (like SLDS) where the original panel retains its
        # content after tab switching, the clones in __scraper_panels are
        # duplicates.  Remove any clone whose original panel now has
        # substantial content visible in the DOM.
        try:
            page.evaluate(r'''() => {
                const container = document.getElementById('__scraper_panels');
                if (!container) return;
                const clones = container.querySelectorAll('[data-cloned-panel]');
                for (const clone of clones) {
                    const origId = clone.getAttribute('data-cloned-panel');
                    const orig = document.getElementById(origId);
                    if (orig && orig.innerHTML.length > 150) {
                        clone.remove();
                    }
                }
                if (!container.children.length) container.remove();
            }''')
        except Exception as exc:
            logger.debug("Clone cleanup failed: %s", exc)

        # ---- Step 5: Clean up UI chrome & fix DOM ordering -------------
        try:
            page.evaluate(r'''() => {
                /* 5a. Make hidden label-spans inside SLDS tab panels
                   truly visible so extract_hidden_content won't
                   duplicate them. */
                document.querySelectorAll(
                    '.slds-tabs_default__content span[style],'
                    + ' .slds-tabs_scoped__content span[style]'
                ).forEach(el => {
                    if (el.style.display === 'none') {
                        el.style.display = '';
                    }
                });

                /* 5b. Move label <span>s to the TOP of each SLDS tab
                   panel so the status-code name appears before the
                   Response Schema table.  The DOM currently stores
                   <div>(schema)</div><span>label</span> — we need
                   <span>label</span><div>(schema)</div>.  */
                document.querySelectorAll(
                    '.slds-tabs_default__content,'
                    + ' .slds-tabs_scoped__content'
                ).forEach(panel => {
                    const spans = panel.querySelectorAll(
                        ':scope > span'
                    );
                    for (const span of spans) {
                        if (span.textContent.trim().length < 80) {
                            panel.prepend(span);
                        }
                    }
                });

                /* 5c. Convert large-font paragraphs to headings.
                   Salesforce renders section labels as
                   <p><span style="font-size:20px">Responses</span></p>
                   and page titles (on pages without a real <h1>) as
                   <p><span style="font-size:36px">FedEx Freight
                   Shipper</span></p>.  We promote very large sizes
                   (>= 32px) to <h1> so the styled page-title becomes
                   the breadcrumb root on pages that lack a real
                   <h1>, and sizes 18-31 to <h2> for in-page section
                   labels (e.g. 28px sub-section titles like
                   "Service Types"). */
                document.querySelectorAll('p').forEach(p => {
                    if (p.closest('h1, h2, h3, h4, h5, h6')) return;
                    const span = p.querySelector(
                        'span[style*="font-size"]');
                    if (!span) return;
                    const size = parseInt(span.style.fontSize);
                    if (!size || p.textContent.trim().length >= 60) return;
                    let newTag = null;
                    if (size >= 32) newTag = 'h1';
                    else if (size >= 18) newTag = 'h2';
                    if (!newTag) return;
                    const h = document.createElement(newTag);
                    h.innerHTML = p.innerHTML;
                    p.parentNode.replaceChild(h, p);
                });

                /* 5d. Remove overflow dropdown containers */
                function cleanDropdowns(root) {
                    root.querySelectorAll('.slds-dropdown')
                        .forEach(el => { el.remove(); });
                    root.querySelectorAll('*').forEach(el => {
                        if (el.shadowRoot) cleanDropdowns(el.shadowRoot);
                    });
                }
                cleanDropdowns(document);

                /* 5e. Remove cookie/consent banner elements */
                document.querySelectorAll(
                    '#onetrust-banner-sdk,'
                    + ' .optanon-alert-box-wrapper,'
                    + ' .cookie-banner,'
                    + ' [class*="cookieConsent"],'
                    + ' [id*="cookie-banner"],'
                    + ' [aria-label*="cookie" i]'
                ).forEach(el => { el.remove(); });
            }''')
        except Exception as exc:
            logger.debug("UI chrome cleanup failed: %s", exc)

    @staticmethod
    def _capture_all_tab_panels(page) -> None:
        """Click every tab in every tab group, cloning each panel into a
        persistent container so that React-style frameworks that unmount
        inactive panels don't lose content.

        Handles:
        - Standard DOM tabs (Bootstrap, jQuery-UI, React-tabs)
        - Shadow DOM tabs (Salesforce Lightning / LWC, Shoelace, etc.)
        - Overflow "More" menus that hide extra tabs behind a dropdown
        - Tab IDs starting with digits (invalid CSS ``#id`` selectors)
        """
        page.evaluate('''() => {
            if (!document.getElementById('__scraper_panels')) {
                const c = document.createElement('div');
                c.id = '__scraper_panels';
                c.style.display = 'block';
                document.body.appendChild(c);
            }
        }''')

        # Gather every tab group, piercing Shadow DOM boundaries.
        groups = page.evaluate(r'''() => {
            const groups = [];
            const seen = new Set();

            function collectTabs(root) {
                const lists = root.querySelectorAll(
                    '[role="tablist"], .react-tabs__tab-list, '
                    + '.nav-tabs, .nav-pills'
                );
                for (const list of lists) {
                    const tabs = list.querySelectorAll(
                        'a[role="tab"], button[role="tab"], '
                        + '[role="tab"].nav-link, .nav-link'
                    );
                    const group = [];
                    for (const t of tabs) {
                        const controls = t.getAttribute('aria-controls') || '';
                        const text = t.textContent.trim();
                        if (!text || !controls) continue;
                        const key = controls || t.id || text;
                        if (seen.has(key)) continue;
                        seen.add(key);
                        group.push({
                            tabId: t.id || '',
                            panelId: controls,
                            text: text
                        });
                    }
                    if (group.length > 0) groups.push(group);
                }

                /* Recurse into Shadow DOMs, skipping tab bars
                   already processed by _capture_slds_tab_groups */
                const allEls = root.querySelectorAll('*');
                for (const el of allEls) {
                    if (el.shadowRoot
                        && !el.hasAttribute('data-scraper-slds-handled')) {
                        collectTabs(el.shadowRoot);
                    }
                }
            }

            collectTabs(document);
            return groups;
        }''')

        for group in groups:
            for tab_info in group:
                tab_id = tab_info['tabId']
                panel_id = tab_info['panelId']
                label = tab_info['text']

                # Click via JS (handles Shadow DOM and numeric IDs).
                try:
                    clicked = page.evaluate(r'''([tabId, panelId, label]) => {
                        function findInShadow(root, tabId, panelId, label) {
                            /* Try by ID first */
                            if (tabId) {
                                let el = root.getElementById
                                    ? root.getElementById(tabId) : null;
                                if (el) { el.click(); return true; }
                            }
                            /* Try by aria-controls */
                            let el = root.querySelector(
                                '[aria-controls="' + panelId + '"]'
                            );
                            if (el) { el.click(); return true; }
                            /* Recurse into Shadow DOMs */
                            const allEls = root.querySelectorAll('*');
                            for (const child of allEls) {
                                if (child.shadowRoot) {
                                    if (findInShadow(child.shadowRoot,
                                                     tabId, panelId, label))
                                        return true;
                                }
                            }
                            return false;
                        }
                        return findInShadow(document, tabId, panelId, label);
                    }''', [tab_id, panel_id, label])
                    if not clicked:
                        continue
                    page.wait_for_timeout(800)
                except Exception:
                    continue

                if not panel_id:
                    continue

                try:
                    page.evaluate(r'''([panelId, label]) => {
                        const panel = document.getElementById(panelId);
                        if (!panel) return;
                        const container =
                            document.getElementById('__scraper_panels');
                        if (!container) return;
                        const existing = container.querySelector(
                            '[data-cloned-panel="' + panelId + '"]'
                        );
                        if (existing) return;

                        const clone = panel.cloneNode(true);
                        clone.removeAttribute('id');
                        clone.setAttribute('data-cloned-panel', panelId);
                        clone.setAttribute('data-tab-label', label);
                        clone.setAttribute('role', 'tabpanel');
                        clone.classList.remove('slds-hide');
                        clone.classList.add('slds-show');
                        clone.style.display = 'block';
                        clone.removeAttribute('hidden');
                        container.appendChild(clone);
                    }''', [panel_id, label])
                except Exception:
                    pass

        # Overflow tabs are handled by _expand_all_content after this call.

    @staticmethod
    def _capture_overflow_tab_panels(page) -> None:
        """Expand overflow / "More" dropdown menus in tab bars and click
        each hidden tab so its panel content gets rendered and cloned.

        Covers Salesforce Lightning (SLDS) ``lightning-button-menu``
        overflow tabs and generic ``[data-toggle="tab"]`` links inside
        dropdown menus.
        """
        overflow_tabs = page.evaluate(r'''() => {
            const results = [];
            const panels = document.querySelectorAll('[role="tabpanel"]');
            for (const p of panels) {
                if (p.innerHTML.length < 150
                    && !document.querySelector(
                        '[data-cloned-panel="' + p.id + '"]')) {
                    const label = p.querySelector('span');
                    results.push({
                        panelId: p.id,
                        label: label ? label.textContent.trim() : p.id
                    });
                }
            }
            return results;
        }''')

        if not overflow_tabs:
            return

        # Open the overflow "More" menu if present.
        try:
            page.evaluate(r'''() => {
                function clickInShadow(root) {
                    const btns = root.querySelectorAll(
                        '.slds-tabs_default__overflow-button button, '
                        + '[data-overflow] button'
                    );
                    for (const b of btns) {
                        b.click();
                        return true;
                    }
                    const allEls = root.querySelectorAll('*');
                    for (const el of allEls) {
                        if (el.shadowRoot && clickInShadow(el.shadowRoot))
                            return true;
                    }
                    return false;
                }
                clickInShadow(document);
            }''')
            page.wait_for_timeout(500)
        except Exception:
            pass

        # Click each overflow menu item to activate hidden tabs.
        for ot in overflow_tabs:
            panel_id = ot['panelId']
            label = ot['label']
            try:
                page.evaluate(r'''([panelId, label]) => {
                    function findAndClick(root) {
                        /* Look for menu items referencing this panel */
                        const items = root.querySelectorAll(
                            '[role="menuitem"], [role="option"], '
                            + 'lightning-menu-item, a[data-tab-value]'
                        );
                        for (const item of items) {
                            const text = item.textContent.trim();
                            if (text === label) {
                                item.click();
                                return true;
                            }
                        }
                        /* Also try links with data-tab-value matching */
                        const links = root.querySelectorAll(
                            '[data-tab-value], [aria-controls]'
                        );
                        for (const link of links) {
                            if (link.getAttribute('aria-controls') === panelId
                                || link.getAttribute('data-tab-value') === panelId) {
                                link.click();
                                return true;
                            }
                        }
                        /* Recurse into shadow DOMs */
                        const allEls = root.querySelectorAll('*');
                        for (const el of allEls) {
                            if (el.shadowRoot && findAndClick(el.shadowRoot))
                                return true;
                        }
                        return false;
                    }
                    findAndClick(document);
                }''', [panel_id, label])
                page.wait_for_timeout(1500)
            except Exception:
                continue

            try:
                page.evaluate(r'''([panelId, label]) => {
                    const panel = document.getElementById(panelId);
                    if (!panel || panel.innerHTML.length < 150) return;
                    const container =
                        document.getElementById('__scraper_panels');
                    if (!container) return;
                    if (container.querySelector(
                        '[data-cloned-panel="' + panelId + '"]')) return;
                    const clone = panel.cloneNode(true);
                    clone.removeAttribute('id');
                    clone.setAttribute('data-cloned-panel', panelId);
                    clone.setAttribute('data-tab-label', label);
                    clone.setAttribute('role', 'tabpanel');
                    clone.classList.remove('slds-hide');
                    clone.classList.add('slds-show');
                    clone.style.display = 'block';
                    clone.removeAttribute('hidden');
                    container.appendChild(clone);
                }''', [panel_id, label])
            except Exception:
                pass

    _FIND_IN_SHADOW_JS = r'''
        function findInShadow(root, selector) {
            const el = root.querySelector(selector);
            if (el) return el;
            const all = root.querySelectorAll('*');
            for (const child of all) {
                if (child.shadowRoot) {
                    const f = findInShadow(child.shadowRoot, selector);
                    if (f) return f;
                }
            }
            return null;
        }
        function findPanelById(root, panelId) {
            try {
                const el = root.querySelector('[id="' + panelId + '"]');
                if (el) return el;
            } catch(e) {}
            if (root.getElementById) {
                try {
                    const el = root.getElementById(panelId);
                    if (el) return el;
                } catch(e) {}
            }
            const all = root.querySelectorAll('*');
            for (const child of all) {
                if (child.shadowRoot) {
                    const f = findPanelById(child.shadowRoot, panelId);
                    if (f) return f;
                }
            }
            return null;
        }
    '''

    @staticmethod
    def _expand_shadow_dom_accordions(page) -> None:
        """Iteratively click expandable/accordion elements — including
        those inside Shadow DOM — and clone their content into a
        persistent container.

        Uses depth-first expansion: after opening a section, it expands
        and clones all nested sub-items within it before moving to the
        next sibling section.  This handles mutual-exclusion accordions
        at every nesting level (e.g. Response sections that close
        siblings, and status-code sub-items within each Response).
        """
        page.evaluate('''() => {
            if (!document.getElementById('__scraper_panels')) {
                const c = document.createElement('div');
                c.id = '__scraper_panels';
                c.style.display = 'block';
                document.body.appendChild(c);
            }
        }''')

        for pass_num in range(4):
            count = page.evaluate(r'''(passNum) => {
                let idx = 0;
                const prefix = '__sdacc_' + passNum + '_';

                function findCollapsed(root) {
                    const collapsed = root.querySelectorAll(
                        '[aria-expanded="false"]'
                        + ':not([data-toggle="dropdown"])'
                        + ':not([data-bs-toggle="dropdown"])'
                        + ':not(.dropdown-toggle)'
                        + ':not([data-scraper-sd-done])'
                    );
                    for (const el of collapsed) {
                        if (!el.getAttribute('data-scraper-sd-id')) {
                            el.setAttribute('data-scraper-sd-id', prefix + idx);
                            idx++;
                        }
                    }

                    try {
                        root.querySelectorAll('details:not([open])').forEach(d => {
                            const s = d.querySelector(':scope > summary');
                            if (s && !s.getAttribute('data-scraper-sd-id')
                                && !s.getAttribute('data-scraper-sd-done')) {
                                s.setAttribute('data-scraper-sd-id', prefix + idx);
                                idx++;
                            }
                        });
                    } catch(e) {}

                    root.querySelectorAll('*').forEach(el => {
                        if (el.shadowRoot) findCollapsed(el.shadowRoot);
                    });
                }

                findCollapsed(document);
                return idx;
            }''', pass_num)

            if count == 0:
                break

            for i in range(count):
                exp_id = f'__sdacc_{pass_num}_{i}'

                try:
                    result = page.evaluate(r'''(expId) => {
                        function find(root) {
                            const el = root.querySelector(
                                '[data-scraper-sd-id="' + expId + '"]'
                            );
                            if (el) return el;
                            const all = root.querySelectorAll('*');
                            for (const child of all) {
                                if (child.shadowRoot) {
                                    const f = find(child.shadowRoot);
                                    if (f) return f;
                                }
                            }
                            return null;
                        }

                        const el = find(document);
                        if (!el) return null;

                        try {
                            el.scrollIntoView({block: 'center'});
                        } catch(e) {}
                        el.click();
                        el.setAttribute('data-scraper-sd-done', 'true');

                        return {
                            controls: el.getAttribute('aria-controls') || '',
                            text: (el.textContent || '').trim().substring(0, 200)
                        };
                    }''', exp_id)

                    if not result:
                        continue

                    page.wait_for_timeout(600)

                    controls = result.get('controls', '')
                    label = result.get('text', '')

                    if not controls:
                        continue

                    # ── Depth-first: expand nested sub-items ──────
                    # Before cloning this panel, find and expand all
                    # collapsed elements within it (e.g. status-code
                    # sub-items inside a Response section).  Each
                    # sub-item's content is cloned individually to
                    # handle mutual-exclusion at the nested level.
                    for sub_pass in range(3):
                        nested_count = page.evaluate(
                            r'''([panelId, subPass, parentPass, parentIdx]) => {
                            ''' + WebScraper._FIND_IN_SHADOW_JS + r'''
                            const panel = findPanelById(document, panelId);
                            if (!panel) return 0;

                            let idx = 0;
                            const prefix = '__sdnest_'
                                + parentPass + '_' + parentIdx + '_'
                                + subPass + '_';

                            function tagCollapsed(root) {
                                root.querySelectorAll(
                                    '[aria-expanded="false"]'
                                    + ':not([data-toggle="dropdown"])'
                                    + ':not([data-bs-toggle="dropdown"])'
                                    + ':not(.dropdown-toggle)'
                                    + ':not([data-scraper-sd-done])'
                                ).forEach(el => {
                                    if (!el.getAttribute('data-scraper-sd-id')) {
                                        el.setAttribute(
                                            'data-scraper-sd-id', prefix + idx
                                        );
                                        idx++;
                                    }
                                });
                                root.querySelectorAll('*').forEach(el => {
                                    if (el.shadowRoot)
                                        tagCollapsed(el.shadowRoot);
                                });
                            }
                            tagCollapsed(panel);
                            return idx;
                        }''', [controls, sub_pass, pass_num, i])

                        if nested_count == 0:
                            break

                        for j in range(nested_count):
                            nested_id = (
                                f'__sdnest_{pass_num}_{i}_{sub_pass}_{j}'
                            )

                            try:
                                nested_result = page.evaluate(
                                    r'''(expId) => {
                                    ''' + WebScraper._FIND_IN_SHADOW_JS + r'''
                                    const el = findInShadow(
                                        document,
                                        '[data-scraper-sd-id="' + expId + '"]'
                                    );
                                    if (!el) return null;

                                    try {
                                        el.scrollIntoView({block: 'center'});
                                    } catch(e) {}
                                    el.click();
                                    el.setAttribute(
                                        'data-scraper-sd-done', 'true'
                                    );

                                    return {
                                        controls:
                                            el.getAttribute('aria-controls')
                                            || '',
                                        text: (el.textContent || '')
                                            .trim().substring(0, 200)
                                    };
                                }''', nested_id)

                                if not nested_result:
                                    continue

                                page.wait_for_timeout(500)

                                nc = nested_result.get('controls', '')
                                nl = nested_result.get('text', '')

                                if not nc:
                                    continue

                                page.evaluate(
                                    r'''([panelId, label, expId]) => {
                                    ''' + WebScraper._FIND_IN_SHADOW_JS + r'''
                                    const panel =
                                        findPanelById(document, panelId);
                                    if (!panel
                                        || panel.innerHTML.length < 30) return;

                                    const container =
                                        document.getElementById(
                                            '__scraper_panels');
                                    if (!container) return;

                                    const cloneKey = 'sdnest_' + expId;
                                    if (container.querySelector(
                                        '[data-cloned-accordion="'
                                        + cloneKey + '"]'
                                    )) return;

                                    const clone = panel.cloneNode(true);
                                    clone.removeAttribute('id');
                                    clone.setAttribute(
                                        'data-cloned-accordion', cloneKey);
                                    clone.setAttribute(
                                        'data-original-panel-id', panelId);
                                    clone.setAttribute(
                                        'data-accordion-label', label);
                                    clone.style.display = 'block';
                                    clone.removeAttribute('hidden');
                                    clone.setAttribute(
                                        'aria-hidden', 'false');
                                    container.appendChild(clone);
                                }''', [nc, nl, nested_id])

                            except Exception:
                                continue
                    # ── End nested expansion ───────────────────────

                    # Clone the parent panel (after nested sub-items
                    # have been expanded and individually cloned).
                    page.evaluate(
                        r'''([panelId, label, expId]) => {
                        ''' + WebScraper._FIND_IN_SHADOW_JS + r'''
                        const panel = findPanelById(document, panelId);
                        if (!panel || panel.innerHTML.length < 30) return;

                        const container =
                            document.getElementById('__scraper_panels');
                        if (!container) return;

                        const cloneKey = 'sdacc_' + expId;
                        if (container.querySelector(
                            '[data-cloned-accordion="' + cloneKey + '"]'
                        )) return;

                        const clone = panel.cloneNode(true);
                        clone.removeAttribute('id');
                        clone.setAttribute(
                            'data-cloned-accordion', cloneKey);
                        clone.setAttribute(
                            'data-original-panel-id', panelId);
                        clone.setAttribute(
                            'data-accordion-label', label);
                        clone.style.display = 'block';
                        clone.removeAttribute('hidden');
                        clone.setAttribute('aria-hidden', 'false');
                        container.appendChild(clone);
                    }''', [controls, label, exp_id])

                except Exception:
                    continue

        # Remove accordion clones whose original panels are still
        # visible with content (avoids duplicating the last-expanded
        # panel which remains open in the live DOM).
        try:
            page.evaluate(r'''() => {
                const container = document.getElementById('__scraper_panels');
                if (!container) return;
                container.querySelectorAll('[data-cloned-accordion]').forEach(
                    clone => {
                        const origId =
                            clone.getAttribute('data-original-panel-id');
                        if (!origId) return;
                        const orig = document.getElementById(origId);
                        if (!orig || orig.innerHTML.length < 100) return;
                        try {
                            const s = window.getComputedStyle(orig);
                            if (s.display !== 'none'
                                && s.visibility !== 'hidden'
                                && !orig.hasAttribute('hidden')
                                && orig.getAttribute('aria-hidden') !== 'true'
                            ) {
                                clone.remove();
                            }
                        } catch(e) {}
                    }
                );
            }''')
        except Exception:
            pass

    @staticmethod
    def _capture_slds_tab_groups(page) -> None:
        """Click every tab in every SLDS (Salesforce Lightning) tab group
        to trigger lazy content rendering.

        Implementation lives in :mod:`salesforce_lightning` to keep this
        module focused on generic web-scraping logic.  Behaviour is
        unchanged from the original in-line version.
        """
        capture_slds_tab_groups(page)

    # ------------------------------------------------------------------ #
    #  HTML parsing helper
    # ------------------------------------------------------------------ #

    def _parse_html(self) -> None:
        """Parse ``self.raw_html`` into a BeautifulSoup tree (``self.soup``).

        Tries the ``lxml`` parser first for speed and standards
        compliance; falls back to Python's built-in ``html.parser`` if
        ``lxml`` fails.
        """
        try:
            self.soup = BeautifulSoup(self.raw_html, 'lxml')
        except Exception:
            self.soup = BeautifulSoup(self.raw_html, 'html.parser')

    # ------------------------------------------------------------------ #
    #  Title
    # ------------------------------------------------------------------ #

    def extract_title(self) -> str:
        """Extract the page title using a fallback chain.

        Tries (in order): ``<title>`` tag, ``og:title`` meta tag, first
        ``<h1>`` element.

        Returns
        -------
        str
            The page title, or empty string if none found.
        """
        if not self.soup:
            return ''
        title_tag = self.soup.find('title')
        if title_tag:
            return title_tag.get_text(strip=True)
        og = self.soup.find('meta', property='og:title')
        if og and og.get('content'):
            return og['content']
        h1 = self.soup.find('h1')
        if h1:
            return h1.get_text(strip=True)
        return ''

    # ------------------------------------------------------------------ #
    #  Metadata
    # ------------------------------------------------------------------ #

    def extract_metadata(self) -> Dict[str, str]:
        """
        Extract page metadata as a dictionary.

        Collects the page title, every <meta> tag (keyed by name, property,
        or http-equiv), and the canonical URL if present.  When duplicate
        keys exist the values are joined with ' | '.

        Returns:
            Dict[str, str]: Metadata key-value pairs.  Always includes a
                'title' key (empty string if none found).
        """
        meta_dict: Dict[str, str] = {}

        if not self.soup:
            return meta_dict

        meta_dict['title'] = self.extract_title()

        for meta in self.soup.find_all('meta'):
            name = meta.get('name') or meta.get('property') or meta.get('http-equiv', '')
            content = meta.get('content', '')
            if name and content:
                if name in meta_dict:
                    meta_dict[name] = meta_dict[name] + ' | ' + content
                else:
                    meta_dict[name] = content

        canonical = self.soup.find('link', rel='canonical')
        if canonical and canonical.get('href'):
            meta_dict['canonical'] = canonical['href']

        return meta_dict

    # ------------------------------------------------------------------ #
    #  JSON helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_braced(text: str, start: int) -> Optional[str]:
        """Return the brace-balanced substring starting at *start*.

        Handles nested ``{}`` correctly, unlike a non-greedy regex.
        Returns ``None`` if *start* is out of range or the braces are
        unbalanced.
        """
        if start >= len(text) or text[start] != '{':
            return None
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if escape:
                escape = False
                continue
            if ch == '\\' and in_str:
                escape = True
                continue
            if ch == '"' and not escape:
                in_str = not in_str
                continue
            if in_str:
                continue
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
        return None

    # ------------------------------------------------------------------ #
    #  JSON from script tags
    # ------------------------------------------------------------------ #

    def extract_json_from_scripts(self) -> str:
        """Extract structured JSON data embedded in ``<script>`` tags.

        Covers JSON-LD (``application/ld+json``), ``application/json``
        script blocks, and framework-specific inline patterns (Next.js
        ``__NEXT_DATA__``, Nuxt ``__NUXT__``, ``__INITIAL_STATE__``,
        ``__DATA__``).

        Returns
        -------
        str
            Labelled JSON blocks joined by double newlines, or empty
            string if no embedded JSON is found.
        """
        if not self.soup:
            return ''
        sections: List[str] = []

        for script in self.soup.find_all('script', type='application/ld+json'):
            try:
                data = json.loads(script.string or '')
                # Original: f'[JSON-LD]\n...\n[/JSON-LD]'
                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
            except (json.JSONDecodeError, TypeError):
                pass

        for script in self.soup.find_all('script', type='application/json'):
            if script.string:
                try:
                    data = json.loads(script.string)
                    # Original: f'[Script Data: {sid}]\n...\n[/Script Data: {sid}]'
                    sections.append(json.dumps(data, indent=2, ensure_ascii=False))
                except (json.JSONDecodeError, TypeError):
                    pass

        # Next.js __NEXT_DATA__
        next_script = self.soup.find('script', attrs={'id': '__NEXT_DATA__'})
        if next_script and next_script.string:
            try:
                data = json.loads(next_script.string)
                # Original: f'[Next.js Data]\n...\n[/Next.js Data]'
                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
            except (json.JSONDecodeError, TypeError):
                pass

        # Inline script patterns (Nuxt, initial state, window data)
        var_patterns = [
            (r'window\.__NUXT__\s*=\s*', 'Nuxt Data'),
            (r'window\.__INITIAL_STATE__\s*=\s*', 'Initial State'),
            (r'window\.__DATA__\s*=\s*', 'Window Data'),
        ]
        for script in self.soup.find_all('script'):
            if script.string and not script.get('type'):
                for pattern, label in var_patterns:
                    for m in re.finditer(pattern, script.string):
                        blob = self._extract_braced(script.string, m.end())
                        if blob:
                            try:
                                data = json.loads(blob)
                                # Original: f'[{label}]\n...\n[/{label}]'
                                sections.append(json.dumps(data, indent=2, ensure_ascii=False))
                            except (json.JSONDecodeError, TypeError):
                                pass

        return '\n\n'.join(sections)

    # ------------------------------------------------------------------ #
    #  Hidden content
    # ------------------------------------------------------------------ #

    def extract_hidden_content(self) -> str:
        """Extract text from elements hidden via HTML attribute, CSS, or ARIA.

        Detects elements with ``hidden`` attribute, ``display:none`` /
        ``visibility:hidden`` inline styles, ``aria-hidden="true"``, and
        common utility classes (``hidden``, ``d-none``, ``sr-only``, etc.).

        Returns
        -------
        str
            Plain text from hidden elements, or empty string if none found.
        """
        if not self.soup:
            return ''
        seen_ids: set = set()
        hidden_elements: List[Tag] = []

        def _add(el: Tag) -> None:
            """Register a hidden element if it hasn't been seen yet."""
            eid = id(el)
            if eid not in seen_ids:
                seen_ids.add(eid)
                hidden_elements.append(el)

        for el in self.soup.find_all(lambda tag: tag.has_attr('hidden')):
            _add(el)
        for el in self.soup.find_all(style=True):
            style = el.get('style', '').replace(' ', '').lower()
            if 'display:none' in style or 'visibility:hidden' in style:
                _add(el)
        for el in self.soup.find_all(attrs={'aria-hidden': 'true'}):
            _add(el)
        for cls in ('hidden', 'd-none', 'hide', 'invisible', 'sr-only', 'visually-hidden', 'screen-reader-text'):
            for el in self.soup.find_all(class_=cls):
                _add(el)

        lines: List[str] = []
        seen_texts: set = set()
        for el in hidden_elements:
            if el.name in self.SKIP_TAGS:
                continue
            text = ' '.join(el.get_text(separator=' ', strip=True).split())
            if text and text not in seen_texts and len(text) > 1:
                seen_texts.add(text)
                lines.append(f'  {text}')

        # Original: return '[Hidden Content]\n' + '\n'.join(lines) + '\n[/Hidden Content]'
        if lines:
            return '\n'.join(lines)
        return ''

    # ------------------------------------------------------------------ #
    #  Table processing
    # ------------------------------------------------------------------ #

    def _process_table(self, table: Tag) -> str:
        """
        Convert an HTML <table> element into a markdown-style text table.

        Handles caption, header rows, data rows, and cells that span
        multiple columns (``colspan``) or rows (``rowspan``).  Column
        widths are auto-calculated for aligned output.

        Args:
            table (Tag): A BeautifulSoup <table> element.

        Returns:
            str: The table rendered as aligned plain text, or empty string
                 if the table has no rows.
        """
        caption = table.find('caption')
        caption_text = caption.get_text(strip=True) if caption else ''

        rows = table.find_all('tr')
        if not rows:
            return ''

        grid: List[List[str]] = []
        rowspan_carry: Dict[int, List] = {}

        for row in rows:
            cells = row.find_all(['th', 'td'])
            grid_row: List[str] = []
            col_idx = 0
            cell_iter = iter(cells)

            while True:
                if col_idx in rowspan_carry:
                    text, remaining = rowspan_carry[col_idx]
                    grid_row.append(text)
                    if remaining <= 1:
                        del rowspan_carry[col_idx]
                    else:
                        rowspan_carry[col_idx] = [text, remaining - 1]
                    col_idx += 1
                    continue

                cell = next(cell_iter, None)
                if cell is None:
                    break

                text = ' '.join(cell.get_text(separator=' ', strip=True).split())
                cs = int(cell.get('colspan', 1) or 1)
                rs = int(cell.get('rowspan', 1) or 1)

                for span_i in range(cs):
                    actual_col = col_idx + span_i
                    while actual_col in rowspan_carry:
                        carry_text, remaining = rowspan_carry[actual_col]
                        grid_row.append(carry_text)
                        if remaining <= 1:
                            del rowspan_carry[actual_col]
                        else:
                            rowspan_carry[actual_col] = [carry_text, remaining - 1]
                        actual_col += 1

                    grid_row.append(text if span_i == 0 else '')
                    if rs > 1:
                        rowspan_carry[actual_col] = [text if span_i == 0 else '', rs - 1]

                col_idx = len(grid_row)

            while col_idx in rowspan_carry:
                text, remaining = rowspan_carry[col_idx]
                grid_row.append(text)
                if remaining <= 1:
                    del rowspan_carry[col_idx]
                else:
                    rowspan_carry[col_idx] = [text, remaining - 1]
                col_idx += 1

            if grid_row:
                grid.append(grid_row)

        if not grid:
            return ''

        max_cols = max(len(r) for r in grid)
        col_widths = [3] * max_cols
        for row in grid:
            for i, text in enumerate(row):
                if i < max_cols:
                    col_widths[i] = max(col_widths[i], len(text))

        lines: List[str] = []
        if caption_text:
            lines.append(f'Table: {caption_text}')

        for row_idx, row in enumerate(grid):
            cells = []
            for i in range(max_cols):
                text = row[i] if i < len(row) else ''
                cells.append(text.ljust(col_widths[i]))
            lines.append('| ' + ' | '.join(cells) + ' |')
            if row_idx == 0:
                lines.append('|' + '|'.join('-' * (w + 2) for w in col_widths) + '|')

        return '\n' + '\n'.join(lines) + '\n'

    # ------------------------------------------------------------------ #
    #  Form processing
    # ------------------------------------------------------------------ #

    def _process_form(self, form: Tag) -> str:
        """
        Extract form metadata and field descriptions from an HTML <form>.

        Captures action URL, HTTP method, and details of every input,
        textarea, select, and button element including labels, placeholders,
        and select options.

        Args:
            form (Tag): A BeautifulSoup <form> element.

        Returns:
            str: A bracketed text block describing the form and its fields.
        """
        action = form.get('action', '')
        method = (form.get('method', 'get') or 'get').upper()
        form_id = form.get('name', '') or form.get('id', '')
        # Original: header = f'[Form: {form_id}]' / '[Form]' ... footer = '[/Form...]'

        lines: List[str] = []
        if form_id:
            lines.append(form_id)
        if action:
            lines.append(f'  Action: {action}')
        lines.append(f'  Method: {method}')

        for field in form.find_all(['input', 'textarea', 'select', 'button']):
            ftype = field.get('type', field.name) if field.name == 'input' else field.name
            fname = field.get('name', '') or field.get('id', '')
            parts: List[str] = []

            fid = field.get('id', '')
            if fid:
                lbl = form.find('label', attrs={'for': fid})
                if lbl:
                    parts.append(f'Label: {lbl.get_text(strip=True)}')
            if fname:
                parts.append(f'Name: {fname}')
            ph = field.get('placeholder', '')
            if ph:
                parts.append(f'Placeholder: {ph}')
            if 'required' in field.attrs:
                parts.append('Required')
            if field.name == 'select':
                opts = [o.get_text(strip=True) for o in field.find_all('option')]
                if opts:
                    parts.append(f'Options: {", ".join(opts)}')
            if field.name == 'button' or ftype == 'submit':
                btn = field.get_text(strip=True) or field.get('value', '') or 'Submit'
                parts.append(f'Text: {btn}')
            if parts:
                # Original: f'  [{ftype.upper()}] {" | ".join(parts)}'
                lines.append(f'  {ftype.upper()} {" | ".join(parts)}')

        return '\n'.join(lines)

    # ------------------------------------------------------------------ #
    #  Inline content helper
    # ------------------------------------------------------------------ #

    def _process_inline_content(self, element: Tag) -> str:
        """Recursively build inline text from an element's children.

        Whitespace is normalised (multiple spaces collapsed to one).
        Used for headings, paragraphs, and other inline containers.

        Parameters
        ----------
        element : Tag
            The parent element whose children are processed.

        Returns
        -------
        str
            The concatenated, whitespace-normalised inline text.
        """
        parts: List[str] = []
        for child in element.children:
            parts.append(self._process_element(child))
        text = ''.join(parts)
        return ' '.join(text.split())

    # ------------------------------------------------------------------ #
    #  Children combiner
    # ------------------------------------------------------------------ #

    def _process_children(self, element: Tag, depth: int = 0) -> str:
        """Process every child of *element* and concatenate the results.

        Parameters
        ----------
        element : Tag
            Parent element whose children are iterated.
        depth : int
            Current nesting depth (passed through to child processing).

        Returns
        -------
        str
            Concatenated text from all children.
        """
        parts: List[str] = []
        for child in element.children:
            part = self._process_element(child, depth)
            if part is not None:
                parts.append(part)
        return ''.join(parts)

    # ------------------------------------------------------------------ #
    #  List processing
    # ------------------------------------------------------------------ #

    def _process_list(self, list_el: Tag, depth: int, ordered: bool) -> str:
        """
        Recursively process an HTML list (<ul> or <ol>) into indented text.

        Handles nested sub-lists by increasing the indentation depth.

        Args:
            list_el (Tag): The <ul> or <ol> BeautifulSoup element.
            depth (int): Current nesting depth (controls indentation).
            ordered (bool): True for numbered lists, False for bullet lists.

        Returns:
            str: The formatted list as plain text, or empty string if no items.
        """
        items: List[str] = []
        counter = int(list_el.get('start', 1) or 1)
        indent = '  ' * depth

        for child in list_el.children:
            if not isinstance(child, Tag) or child.name != 'li':
                continue

            li_parts: List[str] = []
            nested_parts: List[str] = []

            for sub in child.children:
                if isinstance(sub, Tag) and sub.name in ('ul', 'ol'):
                    nested = self._process_list(sub, depth + 1, sub.name == 'ol')
                    if nested.strip():
                        nested_parts.append(nested)
                else:
                    part = self._process_element(sub, depth)
                    if part:
                        li_parts.append(part)

            main_text = ' '.join(''.join(li_parts).split())
            if main_text:
                marker = f'{counter}.' if ordered else '•'
                items.append(f'{indent}{marker} {main_text}')
                for nested in nested_parts:
                    items.append(nested.rstrip('\n'))
                counter += 1

        return '\n' + '\n'.join(items) + '\n' if items else ''

    def _process_definition_list(self, dl: Tag, depth: int) -> str:
        """
        Process an HTML definition list (<dl>) into bold terms and
        indented descriptions.

        Args:
            dl (Tag): The <dl> BeautifulSoup element.
            depth (int): Current nesting depth (controls indentation).

        Returns:
            str: The formatted definition list, or empty string if empty.
        """
        items: List[str] = []
        indent = '  ' * depth
        for child in dl.children:
            if not isinstance(child, Tag):
                continue
            if child.name == 'dt':
                text = child.get_text(strip=True)
                if text:
                    items.append(f'{indent}**{text}**')
            elif child.name == 'dd':
                text = child.get_text(strip=True)
                if text:
                    items.append(f'{indent}  {text}')
        return '\n' + '\n'.join(items) + '\n' if items else ''

    # ------------------------------------------------------------------ #
    #  Semantic section helper
    # ------------------------------------------------------------------ #

    def _wrap_section(self, element: Tag, tag_label: str,
                      depth: int, *, use_label: bool = False) -> str:
        """Process children of a semantic section element.

        Original version wrapped output in ``[Tag]…[/Tag]`` markers;
        now returns plain text only.

        Args:
            element: The semantic HTML element.
            tag_label: The label (e.g. ``Header``, ``Footer``) — kept
                for call-site compatibility but no longer emitted.
            depth: Current nesting depth.
            use_label: Ignored (kept for API compatibility).
        """
        text = self._process_children(element, depth + 1)
        if not text.strip():
            return ''
        # Original: f'\n[{tag_label}]\n{text.strip()}\n[/{tag_label}]\n'
        return f'\n{text.strip()}\n'

    # ------------------------------------------------------------------ #
    #  Fake-heading detection
    # ------------------------------------------------------------------ #

    # Bullet-like prefixes that mark a list item / body line wrongly
    # wrapped in a ``<h1>``..``<h6>`` tag by the page authors.
    _FAKE_HEADING_BULLET_RE = re.compile(r'^[\-\u2013\u2014\u2022\u25AA\u25B6\u25E6*]\s+')
    # Numbered/lettered list prefix, e.g. ``"1. "``, ``"a) "``, ``"(1) "``.
    _FAKE_HEADING_NUMBERED_RE = re.compile(r'^\(?[0-9A-Za-z]{1,2}[\.\)]\s+')
    # ``key=value`` style assignment with no whitespace around ``=`` —
    # a strong indicator of a code line such as
    # ``grant_type=client_credentials``.
    _FAKE_HEADING_ASSIGN_RE = re.compile(r'\w=\S')
    # Angle-bracket placeholder like ``<access_token>`` /
    # ``<your-client-id>`` — sample/code text rather than a real
    # heading.
    _FAKE_HEADING_PLACEHOLDER_RE = re.compile(r'<\w[\w-]*>')
    # ``Header-Name: value`` with a hyphenated leading word — picks up
    # HTTP header lines like ``Content-Type: application/x-www-form-urlencoded``
    # while leaving multi-word descriptive titles such as
    # ``Request Body schema: application/json`` alone (no hyphen
    # before the colon).
    _FAKE_HEADING_HTTP_HEADER_RE = re.compile(
        r'^[A-Z][A-Za-z0-9]*(-[A-Za-z0-9]+)+\s*:\s+\S')
    # Token boundaries used when counting "lowercase content words" —
    # any whitespace splits the heading into tokens.
    _FAKE_HEADING_WS_RE = re.compile(r'\s+')

    @classmethod
    def _is_fake_heading(cls, text: str) -> bool:
        """Return ``True`` when *text* looks like body content that was
        wrongly wrapped in an ``<h1>``..``<h6>`` tag.

        Many CMS-driven pages (Salesforce Experience Cloud sites in
        particular) emit each body paragraph or list item inside a
        heading tag (e.g. an ``<h3>`` for every Q&A answer or numbered
        step).  When the heading-aware chunker sees those markers it
        creates a separate chunk per "heading", yielding nonsensical
        breadcrumb paths whose last element is the body text itself.

        We treat a heading as "fake" — and emit it as a bold paragraph
        instead — when it looks like a sentence, code line, or list
        item rather than a section title:

        * empty after trimming whitespace and BOM characters;
        * longer than 150 characters (almost certainly a paragraph);
        * ends with sentence- or clause-terminal punctuation
          (``.``, ``!``, ``?``, ``:``, ``;``);
        * starts with a bullet glyph (``-``, ``*``, ``\u2022`` ...);
        * starts with a numbered list prefix *and* is long enough
          (>50 chars) to be a list item rather than a section title
          like ``"1. Creating an API project"``;
        * looks like a code line / URL / JSON fragment (contains
          ``://``, ``key=value``, an ``<placeholder>`` token, or
          starts with a punctuation character such as ``{``, ``}``,
          ``[``, ``]``, ``<``, ``&``, ``=``, ``"``);
        * is an HTTP-header style line ``Foo-Bar: value``;
        * reads like a sentence — i.e. contains 4 or more "lowercase
          content words" (length >= 2 starting with ``a``-``z``) —
          which catches sentence-fragment table rows wrongly wrapped
          in ``<h*>`` such as ``"Renewal Request a new token before
          or upon expiry"`` while leaving normal title-case headings
          (e.g. ``"Quotas & rate limits guide"`` with only 3
          lowercase words) untouched.
        """
        if not text:
            return True
        s = text.replace('\ufeff', '').strip()
        # Strip outer markdown emphasis markers ("**foo**" / "*foo*")
        # left over by `_process_inline_content` when the original tag
        # nests a <strong>/<b>/<em>/<i> covering its full content.
        s = re.sub(r'^(\*+)(.*?)\1$', r'\2', s).strip()
        if not s:
            return True
        if len(s) > 150:
            return True
        if s[-1] in '.!?:;':
            return True
        if cls._FAKE_HEADING_BULLET_RE.match(s):
            return True
        if cls._FAKE_HEADING_NUMBERED_RE.match(s) and len(s) > 50:
            return True
        if '://' in s:
            return True
        if s[0] in '{}[]<>&="':
            return True
        if cls._FAKE_HEADING_ASSIGN_RE.search(s):
            return True
        if cls._FAKE_HEADING_PLACEHOLDER_RE.search(s):
            return True
        if cls._FAKE_HEADING_HTTP_HEADER_RE.match(s):
            return True
        # Sentence detection: a real section title rarely contains
        # more than three lowercase "content" words.  Page-titles such
        # as "Quotas & rate limits guide" (3 lowercase words) stay,
        # but body sentences such as "Revocation Tokens can be revoked
        # upon client deregistration" (6 lowercase words) are demoted.
        lc_count = 0
        for tok in cls._FAKE_HEADING_WS_RE.split(s):
            if len(tok) >= 2 and 'a' <= tok[0] <= 'z':
                lc_count += 1
                if lc_count >= 4:
                    return True
        return False

    # ------------------------------------------------------------------ #
    #  Sub-section H2 demotion
    # ------------------------------------------------------------------ #

    @staticmethod
    def _h2_widget_id(h: Tag) -> Optional[str]:
        """Return the ``data-item-id`` of the closest ``ui-widget``
        ancestor of *h*, or a synthetic id derived from ``id(...)`` for
        ``ui-widget`` ancestors that lack the attribute.

        ``ui-widget`` is the wrapper Salesforce Lightning Experience
        Cloud uses around a logically-grouped set of content tiles.
        Tiles in the same widget belong to the same conceptual section,
        which we use when deciding whether to treat sibling ``<h2>``
        tags as a section header + its sub-section headers.
        """
        cur: Optional[Tag] = h.parent if isinstance(h, Tag) else None
        while cur is not None and isinstance(cur, Tag):
            classes = cur.get('class') or []
            if 'ui-widget' in classes:
                return cur.get('data-item-id') or f'auto-{id(cur)}'
            cur = cur.parent
        return None

    def _h2_has_body_map(self, h2_seq: List[Tag]) -> List[bool]:
        """For each ``<h2>`` in *h2_seq* (in document order) return
        whether it has any non-trivial text content before the next
        ``<h2>``.

        A "no-body" ``<h2>`` (returns ``False``) is one that is
        immediately followed by another ``<h2>`` with only whitespace
        / empty wrappers between — typical of a tile that exists only
        to label the following tiles (e.g. ``Credential Management``
        followed by ``API Key and Secret Key``, ``OAuth token``, ...).
        """
        if not h2_seq or self.soup is None:
            return []

        body_root = self.soup.body or self.soup
        h2_id_to_index = {id(h): i for i, h in enumerate(h2_seq)}
        h2_ids = set(h2_id_to_index.keys())

        has_body = [False] * len(h2_seq)
        current_idx = -1
        h2_descendant_ids: set = set()

        def visit(node) -> None:
            nonlocal current_idx, h2_descendant_ids
            if isinstance(node, Tag):
                if id(node) in h2_ids:
                    current_idx = h2_id_to_index[id(node)]
                    h2_descendant_ids = {id(d) for d in node.descendants}
                    return
                if node.name in ('script', 'style', 'meta', 'link',
                                 'noscript', 'svg', 'path', 'template'):
                    return
                for child in node.children:
                    visit(child)
            elif isinstance(node, NavigableString) and not isinstance(node, Comment):
                if current_idx < 0 or has_body[current_idx]:
                    return
                if id(node) in h2_descendant_ids:
                    return
                txt = str(node).strip()
                if txt and len(txt) > 3:
                    has_body[current_idx] = True

        visit(body_root)

        if h2_seq:
            has_body[-1] = True
        return has_body

    def _annotate_subsection_h2s(self) -> None:
        """Mark ``<h2>`` elements that should be demoted to ``<h3>``.

        When a ``<h2>`` has no body content before the next ``<h2>`` we
        treat it as a section parent.  Subsequent ``<h2>`` tags that
        share the same ``ui-widget`` ancestor (same Salesforce content
        tile group) are marked via ``data-scraper-demote-h2`` so the
        markdown emitter writes them as ``###`` instead of ``##`` —
        producing breadcrumb paths like ``Page > Section > Sub-section``
        even though the source HTML uses a flat ``<h2>`` sequence.

        The demotion stops as soon as we cross into a different
        ``ui-widget`` so unrelated top-level sections are not pulled
        under the wrong parent.
        """
        if self.soup is None:
            return
        body_root = self.soup.body or self.soup
        h2_seq = body_root.find_all('h2')
        if len(h2_seq) < 2:
            return

        widget_ids = [self._h2_widget_id(h) for h in h2_seq]
        has_body = self._h2_has_body_map(h2_seq)

        in_demote = False
        demote_widget: Optional[str] = None
        for i, h2 in enumerate(h2_seq):
            if not has_body[i] and i + 1 < len(h2_seq):
                in_demote = True
                demote_widget = widget_ids[i]
                continue
            if in_demote:
                if widget_ids[i] is not None and widget_ids[i] == demote_widget:
                    h2['data-scraper-demote-h2'] = '1'
                else:
                    in_demote = False
                    demote_widget = None

    # ------------------------------------------------------------------ #
    #  Tab panel helper
    # ------------------------------------------------------------------ #

    def _extract_tabpanel_label(self, element: Tag) -> Tuple[str, Optional[Tag]]:
        """Find the tab/accordion label for *element*.

        Tries (in order):
        1. ``data-tab-label`` attribute (set by clone-based tab capture).
        2. ``data-accordion-label`` attribute (set by accordion capture).
        3. ``aria-label`` attribute on the panel itself.
        4. The first short ``<span>`` direct child — Salesforce SLDS panels
           render their status-code label as a hidden ``<span>`` that the
           ``_expand_all_content`` step reorders to the top of the panel.

        Returns
        -------
        tuple
            ``(label_text, label_span)`` where *label_span* is the ``<span>``
            element to skip when later processing children (or ``None`` if
            the label came from an attribute).
        """
        for attr in ('data-tab-label', 'data-accordion-label', 'aria-label'):
            val = (element.get(attr) or '').strip()
            if val and len(val) <= 80:
                return val, None

        for child in element.children:
            if isinstance(child, Comment):
                continue
            if isinstance(child, NavigableString):
                if str(child).strip():
                    return '', None
                continue
            if isinstance(child, Tag):
                if child.name == 'span':
                    text = ' '.join(child.get_text(separator=' ', strip=True).split())
                    if text and len(text) <= 80:
                        return text, child
                return '', None

        return '', None

    def _is_inside_tab_panel(self, el: Tag, exclude: Optional[Tag] = None) -> bool:
        """Return True if *el* lives inside a tab/accordion panel.

        Used when computing the structural heading for a tab label so we
        skip headings emitted by sibling tab panels (e.g. each FAQ Q.
        inside a previous tab) and only pick up real section headings.
        """
        walker = el.parent
        while walker is not None and isinstance(walker, Tag):
            if walker is exclude:
                walker = walker.parent
                continue
            if walker.get('role') == 'tabpanel':
                return True
            cls = set(walker.get('class', []))
            if cls & self.TAB_PANEL_CLASSES:
                return True
            if walker.has_attr('data-tab-label') or walker.has_attr('data-cloned-panel'):
                return True
            walker = walker.parent
        return False

    def _find_panel_isolation_ancestor(self, panel: Tag) -> Optional[Tag]:
        """Return the closest ancestor that bounds the panel's column.

        Walking back for a heading is restricted to descendants of this
        ancestor so we never cross into a sibling layout column or a
        sidebar / mega-nav block.
        """
        walker = panel.parent
        while walker is not None and isinstance(walker, Tag):
            if walker.name in ('main', 'article', 'section'):
                return walker
            cls = set(walker.get('class', []))
            if cls & self._ISOLATION_CLASSES:
                return walker
            if walker.name == 'body':
                return walker
            walker = walker.parent
        return None

    def _find_section_heading_level(self, panel: Tag) -> int:
        """Find the heading level establishing *panel*'s outer section.

        Walks back through document order from the panel and returns
        the level of the first heading that is:

        * Inside the panel's isolation ancestor (so we don't pick up
          headings from a different layout column / sidebar), and
        * Not itself inside another tab panel (which would be a
          heading from a sibling tab's content, e.g. a previous FAQ's
          ``Q.`` heading).

        Returns 0 when no such heading exists — the caller then falls
        back to a sensible default.
        """
        isolation = self._find_panel_isolation_ancestor(panel)
        cur: Optional[Tag] = panel
        for _ in range(5000):
            if cur is None:
                return 0
            cur = cur.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
            if cur is None:
                return 0
            if isolation is not None:
                anc = cur
                inside = False
                while anc is not None and isinstance(anc, Tag):
                    if anc is isolation:
                        inside = True
                        break
                    anc = anc.parent
                if not inside:
                    return 0
            if not self._is_inside_tab_panel(cur):
                try:
                    return int(cur.name[1])
                except (ValueError, IndexError):
                    return 0
        return 0

    def _process_tabpanel(self, element: Tag, depth: int) -> str:
        """Process a tab-panel-like ``<div>``.

        If a tab label is found, prepend a markdown heading at one level
        deeper than the surrounding section so the breadcrumb path
        becomes ``Page > Section > TabLabel``.  Real headings inside
        the panel are kept as sub-section headings nested at least one
        level below the tab label, while body text wrongly wrapped in
        an ``<h*>`` tag (e.g. each FAQ ``Q. ...?`` or numbered step) is
        demoted to a bold paragraph by :meth:`_is_fake_heading` — so a
        structured tab keeps its proper sub-headings.

        FAQ-style panels (where most inner ``<h2>`` tags are themselves
        fake — Q&A questions and answers wrapped in heading tags) are
        detected up front and *all* of their inner heading-like markup
        is demoted to bold so the entire tab forms one chunkable
        section, preserving the existing Q&A behaviour.
        """
        label, label_span = self._extract_tabpanel_label(element)

        if not label:
            text = self._process_children(element, depth + 1)
            return f'\n{text.strip()}\n' if text.strip() else ''

        section_level = self._find_section_heading_level(element)
        if section_level <= 0:
            # No structural heading found within the panel's column, so
            # the tab group is effectively a top-level section.  Use h2.
            section_level = 1
        panel_level = max(2, min(section_level + 1, 6))

        heading_md = f'\n{"#" * panel_level} {label}\n'

        saved_level = self._current_heading_level
        saved_panel_level = self._tab_panel_level
        saved_force_demote = self._force_demote_inner_headings
        self._current_heading_level = panel_level
        self._tab_panel_level = panel_level
        self._force_demote_inner_headings = self._is_qa_style_panel(element)

        parts: List[str] = []
        for child in element.children:
            if child is label_span:
                continue
            part = self._process_element(child, depth + 1)
            if part:
                parts.append(part)

        self._current_heading_level = saved_level
        self._tab_panel_level = saved_panel_level
        self._force_demote_inner_headings = saved_force_demote

        body = ''.join(parts).strip()
        if body:
            return heading_md + body + '\n'
        return heading_md

    def _is_qa_style_panel(self, panel: Tag) -> bool:
        """Whether *panel*'s inner ``<h2>`` tags are predominantly fake
        — i.e. body text wrapped in headings (typical Q&A FAQ tabs).

        When ``True`` we collapse the entire tab into a single chunk by
        demoting *every* inner ``<h*>`` (including legitimate-looking
        ones) to bold, mirroring the long-standing behaviour for
        Salesforce FAQ-style tab panels.  When ``False`` we let real
        sub-headings inside the tab keep their heading status so the
        breadcrumb correctly reflects nested sections.
        """
        h2s = [
            h for h in panel.find_all('h2')
            if not self._is_inside_tab_panel(h, exclude=panel)
        ]
        if len(h2s) < 3:
            return False
        fake = 0
        for h in h2s:
            text = h.get_text(separator=' ', strip=True)
            if self._is_fake_heading(text):
                fake += 1
        return fake / len(h2s) > 0.5

    # ------------------------------------------------------------------ #
    #  Core recursive element processor
    # ------------------------------------------------------------------ #

    def _process_element(self, element, depth: int = 0) -> str:  # noqa: C901
        """
        Recursively convert a single BeautifulSoup node into structured text.

        Dispatches to specialised handlers based on the HTML tag name
        (headings, paragraphs, lists, tables, forms, nav, semantic sections,
        ARIA roles, etc.) and falls back to processing children for generic
        block or inline containers.

        Args:
            element: A BeautifulSoup Tag, NavigableString, or Comment.
            depth (int): Current nesting depth used for indentation.

        Returns:
            str: The structured plain-text representation of the element.
        """
        if isinstance(element, Comment):
            return ''
        if isinstance(element, NavigableString):
            return re.sub(r'\s+', ' ', str(element))
        if not isinstance(element, Tag):
            return ''

        tag = element.name
        if tag in self.SKIP_TAGS:
            return ''

        # ---------- Headings ----------
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            level = int(tag[1])
            text = self._process_inline_content(element)
            if not text:
                return ''
            # Strip a single layer of outer emphasis ("**...**" / "*...*")
            # produced when the heading wraps its full content in
            # <strong>/<b>/<em>/<i>; those markers should not bleed
            # into the heading-aware breadcrumb path.
            text_stripped = text.strip()
            m = re.match(r'^(\*+)(.+?)\1$', text_stripped)
            if m:
                text = m.group(2).strip()
                if not text:
                    return ''
            if self._is_fake_heading(text):
                # Body text wrongly wrapped in a heading tag — emit as a
                # bold paragraph so the heading-aware chunker doesn't
                # treat each sentence as its own section.
                return f'\n**{text}**\n'
            if self._force_demote_inner_headings:
                # Inside a Q&A-style tab panel: collapse all inner
                # heading-like markup into bold paragraphs so the tab
                # forms one chunkable section.
                return f'\n**{text}**\n'
            if (
                tag == 'h2'
                and isinstance(element, Tag)
                and element.get('data-scraper-demote-h2')
            ):
                # Tagged by :meth:`_annotate_subsection_h2s` as a sub-
                # heading of an immediately preceding "no-body" h2
                # within the same Salesforce ui-widget tile group.
                level = 3
            if self._tab_panel_level > 0:
                # Inside a tab panel: ensure inner real headings nest
                # at least one level below the tab label.
                level = min(max(level, self._tab_panel_level + 1), 6)
            self._current_heading_level = level
            return f'\n{"#" * level} {text}\n'

        # ---------- Paragraph ----------
        if tag == 'p':
            text = self._process_inline_content(element)
            return f'\n{text}\n' if text else ''

        # ---------- Line break / Horizontal rule ----------
        if tag == 'br':
            return '\n'
        if tag == 'hr':
            return '\n---\n'

        # ---------- Links ----------
        if tag == 'a':
            text = element.get_text(strip=True)
            href = element.get('href', '')
            if href and not href.startswith(('javascript:', '#')):
                href = urljoin(self.url, href)
                # Original: f'[{text}]({href})'
                return f'{text} ({href})' if text else ''
            return text or ''

        # ---------- Images ----------
        if tag == 'img':
            alt = element.get('alt', '').strip()
            # Original: f'[Image: {alt}]'
            return alt if alt else ''

        # ---------- Iframe ----------
        if tag == 'iframe':
            src = element.get('src', '').strip()
            title = element.get('title', '').strip()
            if src:
                src = urljoin(self.url, src)
                label = title or src
                # Original: f'\n[Embedded: {label}]\n'
                return f'\n{label}\n'
            return ''

        # ---------- Video / Audio / Picture ----------
        if tag == 'video':
            src = element.get('src', '') or ''
            poster = element.get('poster', '') or ''
            sources = [s.get('src', '') for s in element.find_all('source') if s.get('src')]
            tracks = [
                f'{t.get("kind", "subtitles")}: {urljoin(self.url, t["src"])}'
                for t in element.find_all('track') if t.get('src')
            ]
            src = src or (sources[0] if sources else '')
            parts = []
            if src:
                parts.append(urljoin(self.url, src))
            if poster:
                parts.append(f'poster={urljoin(self.url, poster)}')
            for t in tracks:
                parts.append(t)
            # Original: f'\n[Video: {" | ".join(parts)}]\n'
            return f'\n{" | ".join(parts)}\n' if parts else ''

        if tag == 'audio':
            src = element.get('src', '') or ''
            sources = [s.get('src', '') for s in element.find_all('source') if s.get('src')]
            src = src or (sources[0] if sources else '')
            if src:
                # Original: f'\n[Audio: {urljoin(self.url, src)}]\n'
                return f'\n{urljoin(self.url, src)}\n'
            return ''

        if tag == 'picture':
            img = element.find('img')
            if img:
                alt = img.get('alt', '').strip()
                # Original: f'[Image: {alt}]'
                return alt if alt else ''
            return ''

        # ---------- Inline formatting ----------
        if tag in ('strong', 'b'):
            text = self._process_inline_content(element)
            return f'**{text}**' if text else ''
        if tag in ('em', 'i'):
            text = self._process_inline_content(element)
            return f'*{text}*' if text else ''
        if tag == 'code':
            text = element.get_text()
            return f'`{text}`' if text.strip() else ''
        if tag == 'mark':
            text = self._process_inline_content(element)
            return f'=={text}==' if text else ''
        if tag in ('del', 's', 'strike'):
            text = self._process_inline_content(element)
            return f'~~{text}~~' if text else ''
        if tag == 'q':
            text = self._process_inline_content(element)
            return f'"{text}"' if text else ''
        if tag in ('sub', 'sup', 'abbr', 'time', 'small', 'kbd', 'samp', 'var', 'cite', 'dfn', 'u', 'ins', 'wbr', 'bdo', 'tt'):
            return self._process_children(element, depth)

        # ---------- Preformatted / code blocks ----------
        if tag == 'pre':
            code_el = element.find('code')
            text = code_el.get_text() if code_el else element.get_text()
            lang = ''
            if code_el:
                for cls in code_el.get('class', []):
                    if cls.startswith(('language-', 'lang-')):
                        lang = cls.split('-', 1)[1]
                        break
            return f'\n```{lang}\n{text}\n```\n'

        # ---------- Lists ----------
        if tag == 'ul':
            return self._process_list(element, depth, ordered=False)
        if tag == 'ol':
            return self._process_list(element, depth, ordered=True)
        if tag == 'dl':
            return self._process_definition_list(element, depth)
        if tag in ('li', 'dt', 'dd'):
            return ''

        # ---------- Table ----------
        if tag == 'table':
            return self._process_table(element)
        if tag in ('thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col'):
            return ''

        # ---------- Blockquote ----------
        if tag == 'blockquote':
            text = self._process_children(element, depth)
            if text.strip():
                quoted = '\n'.join(f'> {ln}' for ln in text.strip().split('\n'))
                return f'\n{quoted}\n'
            return ''

        # ---------- Form ----------
        if tag == 'form':
            return '\n' + self._process_form(element) + '\n'
        if tag in ('input', 'textarea', 'select', 'option', 'optgroup', 'button', 'fieldset', 'legend', 'label', 'datalist', 'output'):
            return ''

        # ---------- Details / Summary (HTML5 Accordion) ----------
        if tag == 'details':
            return '\n' + self._process_children(element, depth + 1) + '\n'
        if tag == 'summary':
            text = self._process_inline_content(element)
            return f'\n**{text}**\n' if text else ''

        # ---------- Navigation (skip: generic site chrome) ----------
        if tag == 'nav':
            return ''

        # ---------- Semantic structural elements ----------
        if tag in ('header', 'footer', 'aside'):
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'article':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'section':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'main':
            return '\n' + self._process_children(element, depth) + '\n'

        # ---------- Figure / Figcaption ----------
        if tag == 'figure':
            return '\n' + self._process_children(element, depth) + '\n'
        if tag == 'figcaption':
            text = element.get_text(strip=True)
            # Original: f'[Caption: {text}]'
            return text if text else ''

        # ---------- Address ----------
        if tag == 'address':
            text = element.get_text(separator='\n', strip=True)
            # Original: f'\n[Address]\n{text}\n[/Address]\n'
            if text:
                return f'\n{text}\n'
            return ''

        # ---------- Div with ARIA roles / common tab/accordion classes ----------
        if tag == 'div':
            role = element.get('role', '')

            if role == 'tablist':
                return ''  # Skip tab labels (Copy, Expand all, etc. often nearby)

            classes = set(element.get('class', []))
            is_tabpanel = (
                role == 'tabpanel'
                or bool(classes & self.TAB_PANEL_CLASSES)
                or element.has_attr('data-tab-label')
                or element.has_attr('data-cloned-panel')
                or element.has_attr('data-accordion-label')
            )
            if is_tabpanel:
                return self._process_tabpanel(element, depth)

            if role == 'alert':
                text = self._process_children(element, depth)
                return f'\n{text.strip()}\n' if text.strip() else ''
            if role == 'dialog':
                text = self._process_children(element, depth + 1)
                return f'\n{text.strip()}\n' if text.strip() else ''

        # ---------- Remaining inline elements ----------
        if tag in self.INLINE_TAGS:
            return self._process_children(element, depth)

        # ---------- Default block container (div, main, etc.) ----------
        text = self._process_children(element, depth)
        if text.strip():
            return f'\n{text}\n'
        return ''

    # ------------------------------------------------------------------ #
    #  Visible content extraction
    # ------------------------------------------------------------------ #

    def extract_visible_content(self) -> str:
        """Walk the DOM tree from ``<body>`` and build structured text.

        Dispatches each element to :meth:`_process_element` which
        handles headings, paragraphs, lists, tables, forms, semantic
        sections, and more.

        Returns
        -------
        str
            The full structured text output, or the raw ``get_text()``
            fallback if no ``<body>`` element is found.
        """
        if not self.soup:
            return ''
        body = self.soup.body
        if not body:
            return self.soup.get_text(separator='\n', strip=True)
        self._current_heading_level = 0
        self._tab_panel_level = 0
        self._force_demote_inner_headings = False
        # Tag h2 elements that act as sub-headings of a preceding
        # "no-body" h2 so the heading emitter writes them as ###.
        self._annotate_subsection_h2s()
        return self._process_element(body)

    # ------------------------------------------------------------------ #
    #  Output cleanup
    # ------------------------------------------------------------------ #

    _GENERIC_UI_PHRASES = frozenset({
        'copy', 'expand all', 'collapse all', 'expand', 'collapse',
        'true', 'false',
        'log in', 'login', 'sign up', 'sign in', 'register',
        'forgot password', 'forgot password?',
        'reset save', 'edit header', 'close',
        'send', 'cancel', 'submit',
        'header parameters', 'query parameters', 'path parameters',
        'body', 'response', 'building preview ...',
        'chat window',
    })

    _NOISE_PATTERNS = re.compile(
        r'^('
        r'true|false'
        r'|log\s*in.*|sign\s*up.*|sign\s*in.*|register'
        r'|forgot\s+password.*'
        r'|reset\s+save|edit\s+header'
        r'|building\s+preview.*'
        r'|chat\s+window'
        r'|enter\s+your\s+user\s*id\s+and\s+password.*'
        r'|get\s+access\s+to\s+.+\s+by\s+creating.*'
        r'|header\s+parameters.*'
        r'|query\s+parameters.*'
        r'|path\s+parameters.*'
        r'|.{0,10}logo.{0,10}'
        r')\s*$',
        re.IGNORECASE,
    )

    _SECTION_HEADING_NAMES = frozenset({
        'header parameters',
        'query parameters',
        'path parameters',
        'request body schema: application/json',
        'request body schema',
        'request parameters',
    })

    @classmethod
    def _fix_heading_hierarchy(cls, text: str) -> str:
        """Demote section headings that follow a non-first endpoint heading.

        On multi-endpoint API doc pages the first endpoint title is H1
        (``#``) and subsequent endpoint titles are H2 (``##``), the same
        level as their sub-section headers (Header Parameters, Request
        Body, Responses).  This flattens the hierarchy and breaks
        chunking paths.

        This method detects H2 lines whose text does NOT match a known
        section name (like "Header Parameters") and treats them as
        endpoint-name headings.  All section-name H2 lines that follow
        are demoted to H3 (``###``).  When a ``Responses`` H2 is
        demoted to H3, any tab-label H3 lines that follow it (the
        injected ``200 Success`` / ``400 Bad Request`` panel labels)
        are demoted to H4 so the breadcrumb path stays
        ``endpoint > Responses > 200 Success`` instead of collapsing
        ``Responses`` out of the path.
        """
        lines = text.split('\n')
        result: List[str] = []
        demote = False
        demote_response_panels = False

        for line in lines:
            stripped = line.strip()
            if stripped.startswith('## ') and not stripped.startswith('### '):
                heading_text = stripped[3:].strip().replace('\ufeff', '')
                lower = heading_text.lower()
                is_section = (
                    lower in cls._SECTION_HEADING_NAMES
                    or lower.startswith('responses')
                )
                if is_section and demote:
                    demote_response_panels = lower.startswith('responses')
                    result.append('###' + line[2:])
                    continue
                if not is_section:
                    demote = True
                demote_response_panels = False
                result.append(line)
                continue

            if (
                demote_response_panels
                and stripped.startswith('### ')
                and not stripped.startswith('#### ')
            ):
                result.append('#' + line)
                continue

            result.append(line)

        return '\n'.join(result)

    @classmethod
    def _clean_output(cls, text: str) -> str:
        """
        Normalise whitespace and remove generic UI/chrome from the output.

        Strips trailing spaces, collapses excessive newlines, and removes
        lines that are generic UI noise, JS boolean artifacts, blob URLs,
        login/signup prompts, and other non-content text.
        """
        lines = [line.rstrip() for line in text.split('\n')]
        filtered: List[str] = []
        for line in lines:
            lower = line.lower().strip()
            if not lower:
                filtered.append(line)
                continue
            if lower in cls._GENERIC_UI_PHRASES:
                continue
            if re.match(r'^(copy|expand\s+all|collapse\s+all|expand|collapse)\s*$', lower):
                continue
            if re.match(r'^&\s*$', line):
                continue
            if cls._NOISE_PATTERNS.match(lower):
                continue
            line = re.sub(r'\bExpand\s+all\b', '', line, flags=re.I)
            line = re.sub(r'\bCollapse\s+all\b', '', line, flags=re.I)
            line = re.sub(r'blob:[^\s)]+', '', line)
            line = re.sub(r'\(\s*\)', '', line)
            line = re.sub(r'\s+', ' ', line).strip()
            if not line:
                continue
            filtered.append(line)
        text = '\n'.join(filtered)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    # ------------------------------------------------------------------ #
    #  Main entry point
    # ------------------------------------------------------------------ #

    def scrape(self) -> Dict[str, object]:
        """
        Fetch and extract all content.

        Returns:
            dict with two keys:
                metadata         - Dict[str, str] of all meta-tag key/value pairs
                                   (includes 'title', 'description', OG tags, etc.)
                web_page_content - str with the structured page text
        """
        parsed = urlparse(self.url)
        if not parsed.scheme:
            raise ValueError(
                f"Invalid input '{self.url}': must be a URL (https://...) "
                f"or a local HTML file path (e.g. abc.html)."
            )
        if parsed.scheme not in ('http', 'https', 'file'):
            raise ValueError(
                f"Invalid scheme '{parsed.scheme}': use https://, http://, or a local .html file."
            )

        self.fetch()

        metadata = self.extract_metadata()

        sections: List[str] = []

        visible = self.extract_visible_content()
        if visible and visible.strip():
            sections.append(visible)

        json_data = self.extract_json_from_scripts()
        if json_data:
            sections.append(json_data)

        hidden = self.extract_hidden_content()
        if hidden:
            sections.append(hidden)

        content = '\n\n'.join(sections)
        content = self._clean_output(content)
        content = self._fix_heading_hierarchy(content)

        return {
            'metadata': metadata,
            'web_page_content': content,
        }


# ====================================================================== #
#  Public API
# ====================================================================== #

def scrape_webpage(url_or_file: str, use_playwright: bool = True) -> dict:
    """
    Scrape a webpage or parse a local HTML file and return metadata and content.

    Input can be:
        - A live URL (e.g. https://example.com): Uses Playwright by default
          to render JS, expand tabs/accordions. Falls back to plain HTTP
          if Playwright is unavailable.
        - A local HTML file (e.g. abc.html, ./page.html): Reads directly
          from disk, no network or browser needed.

    Args:
        url_or_file: Either a webpage URL or a path to an HTML file.
        use_playwright: If True (default), use a headless browser for URLs.
            Ignored for HTML files.

    Returns:
        dict with two keys:
            metadata         - Dict[str, str] containing all meta-tag
                               key/value pairs (title, description,
                               og:title, canonical, etc.)
            web_page_content - str with extracted content, structure preserved

    Raises:
        requests.RequestException: On network / HTTP errors (URLs only).
        FileNotFoundError: When HTML file does not exist.

    Example::

        >>> result = scrape_webpage('https://example.com')
        >>> result = scrape_webpage('abc.html')
    """
    scraper = WebScraper(url_or_file, use_playwright=use_playwright)
    return scraper.scrape()
