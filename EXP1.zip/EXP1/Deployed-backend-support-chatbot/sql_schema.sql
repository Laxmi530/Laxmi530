-- Run this script on your SQL Server to create tables for chatbot conversation history.
-- Required for SQL_SERVER_CONNECTION_STRING to work.

CREATE TABLE ChatSessions (
    SessionId UNIQUEIDENTIFIER PRIMARY KEY,
    UserId NVARCHAR(100) NOT NULL,
    StartedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    LastActivityAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE ChatMessages (
    MessageId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SessionId UNIQUEIDENTIFIER NOT NULL,
    Role NVARCHAR(20) NOT NULL,
    Content NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    SourcesJson NVARCHAR(MAX) NULL,
    RequestHeadersJson NVARCHAR(MAX) NULL,
    ExecutionTimeMs INT NULL,
    FromCache BIT NULL,
    CONSTRAINT FK_ChatMessages_Session FOREIGN KEY (SessionId) REFERENCES ChatSessions(SessionId)
);

CREATE INDEX IX_ChatMessages_SessionId ON ChatMessages(SessionId);
CREATE INDEX IX_ChatMessages_CreatedAt ON ChatMessages(CreatedAt);
CREATE INDEX IX_ChatSessions_UserId ON ChatSessions(UserId);
