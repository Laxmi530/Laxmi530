---
name: Content safety observability
overview: Add structured logging and response metadata so you can verify content safety is running (or disabled) in Azure Function invocation details, Application Insights traces, and API response bodies.
todos:
  - id: add-pass-skip-logs
    content: Add INFO log on pass and DEBUG log on skip in analyse_input() and analyse_output() in content_safety.py
    status: completed
  - id: add-response-field
    content: Add content_safety object to the JSON response body in function_app.py (both success and blocked paths)
    status: completed
  - id: add-telemetry-fields
    content: Add content safety fields to the ChatConversation telemetry log in function_app.py
    status: completed
isProject: false
---

# Content Safety Observability

## Current gap

The content safety module only logs when it **blocks** something (WARNING level). When it passes or is disabled, there is no trace, making it impossible to confirm the feature is active from invocation details.

## Changes

### 1. Add pass/skip logging in `content_safety.py`

In `analyse_input()` and `analyse_output()`:

- When **disabled** (`is_enabled()` returns False): log at DEBUG level so it appears when you turn on verbose logging:
  ```python
  logger.debug("ContentSafety|skipped (disabled) for %s check", "input")
  ```

- When check **passes** (content is safe): log at INFO level with the per-category severities so you can see the actual scores:
  ```python
  logger.info("ContentSafety|input passed (threshold=%d): %s", threshold, details)
  ```

- When check **fails** (content flagged): already logs at WARNING -- no change needed.

This gives you three distinct log lines to search for in Application Insights:
  - `ContentSafety|skipped` -- feature is off
  - `ContentSafety|input passed` / `ContentSafety|output passed` -- ran and content was clean
  - `ContentSafety|input blocked` / `ContentSafety|output blocked` -- ran and content was flagged

### 2. Add `content_safety` field to the JSON response in `function_app.py`

Add a `content_safety` object to the response JSON so the caller (frontend) can see the status:

```python
"content_safety": {
    "enabled": True,
    "input_safe": True,
    "output_safe": True,         # or False when replaced
    "input_details": {...},      # per-category severities
    "output_details": {...},
}
```

This goes into the `response_data` dict (around line 434) and also into the blocked-input `400` response.

When content safety is disabled, the field would be:
```python
"content_safety": {"enabled": False}
```

### 3. Include content safety status in the telemetry log

The existing `ChatConversation|{...}` structured telemetry log (around line 420) already gets picked up by Application Insights. Add `content_safety_enabled`, `input_safe`, and `output_safe` fields to it so you can query/filter in App Insights:

```python
telemetry = {
    ...
    "content_safety_enabled": True,
    "content_safety_input_safe": True,
    "content_safety_output_safe": True,
}
```

### Files changed

- [content_safety.py](content_safety.py) -- add INFO/DEBUG logs for pass and skip paths in `analyse_input()`, `analyse_output()`, and `_analyse_text()`
- [function_app.py](function_app.py) -- add `content_safety` to response JSON and telemetry dict

### How to verify in Azure Portal

After deploying, in the Function App **Invocation Details** (Monitor tab) or **Application Insights > Transaction Search**:

- Search for `ContentSafety|input passed` -- confirms the check ran and the input was clean
- Search for `ContentSafety|skipped` -- confirms the feature is disabled
- Search for `ContentSafety|input blocked` -- confirms a block happened
- In the API response JSON, look for the `content_safety` object
- In App Insights, query: `traces | where message contains "ContentSafety"` to see all content safety activity
