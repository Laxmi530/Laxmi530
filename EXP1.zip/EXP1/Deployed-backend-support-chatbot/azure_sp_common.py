"""
Shared helpers for local test scripts: service principal auth + httpx TLS options.

OpenAI / Search auth:
  - Optional service principal: AZURE_TENANT_ID + credential values.
  - Key Vault secret *names* (not AZURE_CLIENT_ID / AZURE_CLIENT_SECRET — those are reserved by Azure SDK
    EnvironmentCredential inside DefaultAzureCredential; putting secret names there breaks MI auth with AADSTS700016):
    KEY_VAULT_SECRET_NAME_CLIENT_ID, KEY_VAULT_SECRET_NAME_CLIENT_SECRET
    Resolved into AZURE_CLIENT_ID_VALUE / AZURE_CLIENT_SECRET_VALUE when AZURE_KEY_VAULT_URL is set.
  - Without Key Vault (e.g. local): AZURE_CLIENT_ID_VALUE and AZURE_CLIENT_SECRET_VALUE = literal app id + secret.
  - If those are not set: DefaultAzureCredential (e.g. Function App system-assigned MI in Azure).
  TLS: TEST_OPENAI_SSL_VERIFY, SSL_CERT_FILE, REQUESTS_CA_BUNDLE

Key Vault (optional, Azure Functions with system-assigned managed identity):
  Set AZURE_KEY_VAULT_URL to https://<vault-name>.vault.azure.net/
  Secrets loaded (only if the env var is not already set): Redis-cache-username -> AZURE_REDIS_ENTRA_OBJECT_ID.
  Prefer setting AZURE_REDIS_ENTRA_OBJECT_ID on the Function App (Application settings) so it is read from the environment;
  Redis username is the Entra object ID — not application/client id. If unset, falls back to oid from the Redis token.
  SP: KEY_VAULT_SECRET_NAME_CLIENT_ID / KEY_VAULT_SECRET_NAME_CLIENT_SECRET for Key Vault secret names, or
  AZURE_CLIENT_ID_VALUE / AZURE_CLIENT_SECRET_VALUE for literals. Do not put secret names in AZURE_CLIENT_ID.
  AZURE_TENANT_ID remains in app settings / local.settings.json.

When running tests with `python test_openai.py` (not `func start`), call
`load_local_settings_json()` after `load_dotenv()` so Values from
fedex-chatbot-backend/local.settings.json are applied (same as Azure Functions local host).
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
from pathlib import Path

# Key Vault secret names (as stored in the vault) -> app environment variable names
KEY_VAULT_SECRET_ENV_MAP = (
    ("Redis-cache-username", "AZURE_REDIS_ENTRA_OBJECT_ID"),
)

# Resolved SP credential values after Key Vault lookup (set only by load_keyvault_secrets_into_environ)
_ENV_AZURE_CLIENT_ID_VALUE = "AZURE_CLIENT_ID_VALUE"
_ENV_AZURE_CLIENT_SECRET_VALUE = "AZURE_CLIENT_SECRET_VALUE"
# Key Vault secret *names* for SP credentials — NOT AZURE_CLIENT_ID / AZURE_CLIENT_SECRET (those are read by
# azure-identity EnvironmentCredential as literal client id + secret and break DefaultAzureCredential if misused).
_ENV_KV_SECRET_NAME_CLIENT_ID = "KEY_VAULT_SECRET_NAME_CLIENT_ID"
_ENV_KV_SECRET_NAME_CLIENT_SECRET = "KEY_VAULT_SECRET_NAME_CLIENT_SECRET"


def _is_uuid_string(s: str) -> bool:
    """True if s looks like an Entra application (client) ID GUID."""
    return bool(
        re.fullmatch(
            r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
            s.strip(),
        )
    )


def sp_client_id_from_env() -> str:
    """
    Service principal application (client) ID.
    From AZURE_CLIENT_ID_VALUE (Key Vault resolution or local literal).
    """
    return (os.environ.get(_ENV_AZURE_CLIENT_ID_VALUE) or "").strip()


def sp_client_secret_from_env() -> str:
    """
    Service principal client secret.
    From AZURE_CLIENT_SECRET_VALUE (Key Vault resolution or local literal).
    """
    return (os.environ.get(_ENV_AZURE_CLIENT_SECRET_VALUE) or "").strip()


def _remove_environment_credential_env_pollution() -> None:
    """
    DefaultAzureCredential uses EnvironmentCredential first; it reads AZURE_CLIENT_ID / AZURE_CLIENT_SECRET
    as literal SP credentials. If those vars hold Key Vault secret names, AAD returns AADSTS700016.
    Strip misleading values before constructing DefaultAzureCredential or SecretClient(..., DefaultAzureCredential()).
    """
    # One-time compat: mistaken secret name in AZURE_CLIENT_ID -> KEY_VAULT_SECRET_NAME_CLIENT_ID
    if not (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip():
        leg = (os.environ.get("AZURE_CLIENT_ID") or "").strip()
        if leg and not _is_uuid_string(leg):
            os.environ[_ENV_KV_SECRET_NAME_CLIENT_ID] = leg

    cid = (os.environ.get("AZURE_CLIENT_ID") or "").strip()
    if cid and not _is_uuid_string(cid):
        os.environ.pop("AZURE_CLIENT_ID", None)
        logging.warning(
            "Removed AZURE_CLIENT_ID from environment (not a GUID — often a Key Vault secret name). "
            "Use KEY_VAULT_SECRET_NAME_CLIENT_ID for the vault secret name, not AZURE_CLIENT_ID."
        )
    use_kv_sp_names = (
        (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip()
        or (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_SECRET) or "").strip()
    )
    if use_kv_sp_names and "AZURE_CLIENT_SECRET" in os.environ:
        os.environ.pop("AZURE_CLIENT_SECRET", None)
        logging.warning(
            "Removed AZURE_CLIENT_SECRET from environment while using KEY_VAULT_SECRET_NAME_CLIENT_ID / "
            "KEY_VAULT_SECRET_NAME_CLIENT_SECRET (avoid EnvironmentCredential picking up a secret name)."
        )


def _resolve_sp_secrets_from_key_vault_names(client) -> None:
    """
    KEY_VAULT_SECRET_NAME_CLIENT_ID / KEY_VAULT_SECRET_NAME_CLIENT_SECRET are Key Vault secret *names* only.
    Fetch each secret's value into AZURE_CLIENT_ID_VALUE / AZURE_CLIENT_SECRET_VALUE.
    """
    if (os.environ.get(_ENV_AZURE_CLIENT_ID_VALUE) or "").strip() and (
        os.environ.get(_ENV_AZURE_CLIENT_SECRET_VALUE) or ""
    ).strip():
        return

    cid_name = (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_ID) or "").strip()
    if cid_name:
        bundle = client.get_secret(cid_name)
        if not bundle or not (bundle.value or "").strip():
            raise ValueError(
                f"Key Vault secret {cid_name!r} (KEY_VAULT_SECRET_NAME_CLIENT_ID) is missing or empty."
            )
        resolved = bundle.value.strip()
        os.environ[_ENV_AZURE_CLIENT_ID_VALUE] = resolved
        if not _is_uuid_string(resolved):
            raise ValueError(
                f"Key Vault secret {cid_name!r} must contain the application (client) ID GUID; "
                f"got a non-GUID value."
            )

    csec_name = (os.environ.get(_ENV_KV_SECRET_NAME_CLIENT_SECRET) or "").strip()
    if csec_name:
        bundle = client.get_secret(csec_name)
        if not bundle or not (bundle.value or "").strip():
            raise ValueError(
                f"Key Vault secret {csec_name!r} (KEY_VAULT_SECRET_NAME_CLIENT_SECRET) is missing or empty."
            )
        os.environ[_ENV_AZURE_CLIENT_SECRET_VALUE] = bundle.value.strip()


def _ensure_sp_secrets_resolved_from_key_vault() -> None:
    """
    Resolve Key Vault secret names into AZURE_*_VALUE on first use.

    Import-time load_keyvault_secrets_into_environ() may have been skipped or failed silently (e.g. function_app
    catches exceptions). If AZURE_KEY_VAULT_URL is set but *_VALUE is still missing, fetch now before building
    ClientSecretCredential.
    """
    vault_url = (os.environ.get("AZURE_KEY_VAULT_URL") or "").strip()
    if not vault_url:
        return
    if (os.environ.get(_ENV_AZURE_CLIENT_ID_VALUE) or "").strip() and (
        os.environ.get(_ENV_AZURE_CLIENT_SECRET_VALUE) or ""
    ).strip():
        return
    _remove_environment_credential_env_pollution()
    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient

        credential = DefaultAzureCredential()
        client = SecretClient(vault_url=vault_url, credential=credential)
        _resolve_sp_secrets_from_key_vault_names(client)
        logging.info("Key Vault: resolved SP secrets from KEY_VAULT_SECRET_NAME_CLIENT_* (lazy path).")
    except Exception:
        logging.exception("Key Vault SP resolution (lazy) failed")
        raise


def load_keyvault_secrets_into_environ() -> None:
    """
    When AZURE_KEY_VAULT_URL is set, fetch secrets using
    DefaultAzureCredential (system-assigned managed identity in Azure Functions).
    - SP first: KEY_VAULT_SECRET_NAME_CLIENT_ID / KEY_VAULT_SECRET_NAME_CLIENT_SECRET -> AZURE_*_VALUE.
    - Then fixed map: Redis-cache-username -> AZURE_REDIS_ENTRA_OBJECT_ID (only if unset); failures are logged
      and do not block SP resolution.
    """
    vault_url = (os.environ.get("AZURE_KEY_VAULT_URL") or "").strip()
    if not vault_url:
        return
    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as e:
        logging.warning("Key Vault packages missing; install azure-identity and azure-keyvault-secrets: %s", e)
        return

    _remove_environment_credential_env_pollution()
    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=vault_url, credential=credential)

    try:
        _resolve_sp_secrets_from_key_vault_names(client)
    except Exception as e:
        logging.error("Key Vault resolve KEY_VAULT_SECRET_NAME_CLIENT_* failed: %s", e)
        raise

    for secret_name, env_key in KEY_VAULT_SECRET_ENV_MAP:
        if (os.environ.get(env_key) or "").strip():
            continue
        try:
            bundle = client.get_secret(secret_name)
            if bundle.value:
                os.environ[env_key] = bundle.value.strip()
        except Exception as e:
            logging.warning(
                "Key Vault get_secret(%r) -> %s failed (optional); Redis Entra username may stay unset: %s",
                secret_name,
                env_key,
                e,
            )


def load_local_settings_json() -> None:
    """
    Merge Values from local.settings.json into os.environ for keys not already set.
    Lets test scripts reuse the same config as `func host` without duplicating .env.
    """
    path = Path(__file__).resolve().parent / "local.settings.json"
    if not path.is_file():
        return
    try:
        with path.open(encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return
    for key, value in data.get("Values", {}).items():
        if key in os.environ:
            continue
        if value is None:
            continue
        s = str(value).strip()
        if s == "":
            continue
        os.environ[key] = s


def _validate_sp_client_id_is_guid(client_id: str) -> None:
    """
    Entra application (client) IDs are GUIDs. Validates resolved id (AZURE_CLIENT_ID_VALUE), not the KV secret name.
    """
    if not client_id or _is_uuid_string(client_id):
        return
    extra = ""
    if (os.environ.get("AZURE_KEY_VAULT_URL") or "").strip():
        extra = (
            " AZURE_KEY_VAULT_URL is set — check that the Function App managed identity has "
            "Key Vault Secrets User (or Get/List on secrets), secret names match the vault, and review logs "
            "for 'Key Vault bootstrap failed' or 'Lazy Key Vault SP resolution failed'."
        )
    raise ValueError(
        "Resolved client id must be a GUID. "
        "Use KEY_VAULT_SECRET_NAME_CLIENT_ID / KEY_VAULT_SECRET_NAME_CLIENT_SECRET for Key Vault secret names "
        "(not AZURE_CLIENT_ID — that is used by azure-identity EnvironmentCredential). "
        "Set AZURE_KEY_VAULT_URL so values load into AZURE_CLIENT_ID_VALUE / AZURE_CLIENT_SECRET_VALUE. "
        "For local dev, set AZURE_CLIENT_ID_VALUE and AZURE_CLIENT_SECRET_VALUE to literals."
        + extra
    )


def get_client_secret_credential():
    """Azure Identity ClientSecretCredential from environment (no defaults)."""
    try:
        from azure.identity import ClientSecretCredential
    except ImportError as e:
        raise ImportError(
            "Missing package azure-identity. Run: pip install -r requirements.txt"
        ) from e

    _ensure_sp_secrets_resolved_from_key_vault()

    tenant_id = os.environ.get("AZURE_TENANT_ID")
    client_id = sp_client_id_from_env()
    client_secret = sp_client_secret_from_env()
    if not all([tenant_id, client_id, client_secret]):
        raise ValueError(
            "Set AZURE_TENANT_ID, AZURE_CLIENT_ID_VALUE, and AZURE_CLIENT_SECRET_VALUE (literals or after KV resolve), "
            "or AZURE_KEY_VAULT_URL + KEY_VAULT_SECRET_NAME_CLIENT_ID + KEY_VAULT_SECRET_NAME_CLIENT_SECRET."
        )
    _validate_sp_client_id_is_guid(client_id)
    return ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
    )


_cached_token_credential = None


def get_azure_token_credential():
    """
    ClientSecretCredential when service principal env vars are set; otherwise
    DefaultAzureCredential (managed identity in Azure, az login locally).
    Cached after first resolution to avoid repeated probe-chain delays.
    """
    global _cached_token_credential
    if _cached_token_credential is not None:
        return _cached_token_credential

    from azure.identity import DefaultAzureCredential

    if service_principal_credentials_configured():
        _cached_token_credential = get_client_secret_credential()
    else:
        _remove_environment_credential_env_pollution()
        logging.info(
            "Using DefaultAzureCredential (managed identity or dev login); "
            "set AZURE_TENANT_ID + AZURE_CLIENT_ID_VALUE + AZURE_CLIENT_SECRET_VALUE or KV secret name env vars."
        )
        _cached_token_credential = DefaultAzureCredential(exclude_interactive_browser_credential=True)

    return _cached_token_credential


def build_openai_azure_ad_token_provider():
    """
    Token provider for Azure OpenAI (scope: Cognitive Services).
    Uses ClientSecretCredential when tenant + client id + secret are set; otherwise
    DefaultAzureCredential (e.g. system-assigned managed identity on the Function App).
    """
    scope = "https://cognitiveservices.azure.com/.default"

    credential = get_azure_token_credential()

    try:
        from azure.identity import get_bearer_token_provider

        return get_bearer_token_provider(credential, scope)
    except ImportError:

        def _sync_token():
            return credential.get_token(scope).token

        return _sync_token


def resolve_httpx_verify():
    """
    Value for httpx.Client(verify=...).
    - False: TEST_OPENAI_SSL_VERIFY is false
    - str: path to PEM bundle
    - True: default CAs
    """
    flag = os.environ.get("TEST_OPENAI_SSL_VERIFY", "true").lower()
    if flag in ("0", "false", "no"):
        return False
    for key in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE"):
        path = os.environ.get(key)
        if path and os.path.isfile(path):
            return path
    return True


def service_principal_credentials_configured() -> bool:
    """True when tenant + app id + secret are set (used by function_app and tests)."""
    return bool(
        (os.environ.get("AZURE_TENANT_ID") or "").strip()
        and sp_client_id_from_env()
        and sp_client_secret_from_env()
    )


def create_openai_client(azure_endpoint: str, api_version: str):
    """
    Azure OpenAI via Microsoft Entra: service principal env vars if set, otherwise
    DefaultAzureCredential (managed identity in Azure, or az login locally).
    """
    from openai import AzureOpenAI

    import httpx

    return AzureOpenAI(
        azure_endpoint=azure_endpoint,
        api_version=api_version,
        azure_ad_token_provider=build_openai_azure_ad_token_provider(),
        http_client=httpx.Client(verify=resolve_httpx_verify(), timeout=120.0),
    )


def build_search_credential():
    """
    Search: same as OpenAI — service principal or DefaultAzureCredential (RBAC / managed identity).
    """
    return get_azure_token_credential()


REDIS_ENTRA_SCOPE = "https://redis.azure.com/.default"


def _jwt_payload_dict(access_token: str) -> dict | None:
    """Decode JWT payload (no signature verification; local read of claims only)."""
    try:
        parts = access_token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        pad = -len(payload_b64) % 4
        if pad:
            payload_b64 += "=" * pad
        raw = base64.urlsafe_b64decode(payload_b64.encode("ascii"))
        return json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError, AttributeError):
        return None


def redis_entra_object_id_from_access_token(access_token: str) -> str | None:
    """
    Entra object ID (oid claim) from an access token for Redis.
    Azure Cache for Redis expects this as the username — not the application (client) ID (appid).
    """
    payload = _jwt_payload_dict(access_token)
    if not payload:
        return None
    oid = (payload.get("oid") or "").strip()
    return oid or None


def redis_entra_object_id_from_env() -> str:
    """Entra object ID for Redis from AZURE_REDIS_ENTRA_OBJECT_ID (Function App application setting / env)."""
    return (os.environ.get("AZURE_REDIS_ENTRA_OBJECT_ID") or "").strip()


def resolve_redis_entra_username(access_token: str) -> str | None:
    """
    Redis ACL username: prefer AZURE_REDIS_ENTRA_OBJECT_ID from the environment (application setting),
    else oid from the Redis access token. Never use the application (client) id (e.g. AZURE_CLIENT_ID_VALUE) for Redis.
    """
    env_oid = redis_entra_object_id_from_env()
    if env_oid:
        return env_oid
    return redis_entra_object_id_from_access_token(access_token)


def parse_redis_host_port_from_env():
    """Host/port for Redis Entra from AZURE_REDIS_HOST or REDIS_HOST."""
    host = (os.environ.get("AZURE_REDIS_HOST") or os.environ.get("REDIS_HOST") or "").strip()
    port_str = os.environ.get("AZURE_REDIS_PORT", "").strip()
    if not host:
        raise ValueError(
            "Set AZURE_REDIS_HOST or REDIS_HOST (and optionally AZURE_REDIS_PORT) for Redis Entra."
        )
    port = int(port_str) if port_str else 6380
    return host, port


def redis_ssl_tls_kwargs():
    """TLS options for redis.Redis (align with test_rediscache / corporate SSL)."""
    import ssl

    flag = (
        os.environ.get("TEST_REDIS_SSL_VERIFY")
        or os.environ.get("TEST_OPENAI_SSL_VERIFY")
        or "true"
    ).lower()
    ca_path = os.environ.get("SSL_CERT_FILE") or os.environ.get("REQUESTS_CA_BUNDLE") or ""
    kwargs = {"ssl": True}
    if ca_path and os.path.isfile(ca_path):
        kwargs["ssl_ca_certs"] = ca_path
        kwargs["ssl_cert_reqs"] = ssl.CERT_REQUIRED
    elif flag in ("0", "false", "no"):
        kwargs["ssl_cert_reqs"] = ssl.CERT_NONE
    else:
        kwargs["ssl_cert_reqs"] = ssl.CERT_REQUIRED
    return kwargs
