# FedEx Migration Assistant — Chatbot Retrieval Backend

Azure Functions (Python v2) backend that powers a RAG-based chatbot for FedEx SOAP-to-REST migration guidance. It combines **Azure AI Search** (hybrid BM25 + vector with semantic reranking), **Azure OpenAI** chat completions, **Azure AI Content Safety**, and **Azure AI Language PII masking** to answer user questions grounded in internal migration documents while filtering harmful content and redacting personally identifiable information.

## Architecture

```
┌─────────────┐    POST /api/http_trigger_from_chatbot    ┌───────────────────┐
│   Frontend   │ ──────────────────────────────────────▶  │  Azure Functions  │
│  (any client)│ ◀──────────────────────────────────────  │  (Python v2)      │
└─────────────┘           JSON response                   └────────┬──────────┘
                                                                   │
                  ┌────────────────────────────────────────────────┤
                  │                    │                    │       │
                  ▼                    ▼                    ▼       ▼
          ┌──────────────┐   ┌─────────────────┐   ┌──────────┐  ┌──────────────┐  ┌──────────────┐
          │ Azure OpenAI │   │ Azure AI Search  │   │  Redis   │  │ Azure AI     │  │ Azure AI     │
          │  - Embeddings│   │  - Hybrid search │   │  Cache   │  │ Content      │  │ Language     │
          │  - Chat (GPT)│   │  - Semantic rank │   │(optional)│  │ Safety       │  │ PII Masking  │
          └──────────────┘   └─────────────────┘   └──────────┘  │ (optional)   │  │ (optional)   │
                                                                  └──────────────┘  └──────────────┘
```

## Request / Response Flow

1. **Intent shortcuts** — Greetings, goodbyes, and thank-you messages return canned responses without calling any external service.
2. **Content safety (input)** — When enabled, the user query is checked via Azure AI Content Safety for harmful content (Hate, SelfHarm, Sexual, Violence). Blocked queries return a 400 immediately.
3. **PII masking (input)** — When enabled, the user query is scanned via Azure AI Language for personally identifiable information (names, emails, phone numbers, etc.). Detected PII is replaced with category placeholders (e.g. `[PERSON]`, `[EMAIL]`) before the query reaches embeddings, search, the LLM, or cache.
4. **Exact-match cache** — SHA-256 hash lookup in Redis (if enabled). Returns immediately on hit.
5. **Embedding** — Query text is embedded via Azure OpenAI (`text-embedding-3-small` by default).
6. **Semantic cache** — Cosine similarity search across cached embeddings (threshold ≥ 0.9).
7. **Hybrid search** — BM25 keyword + vector ANN search on Azure AI Search, fused via Reciprocal Rank Fusion (RRF), then re-scored by the semantic reranker.
8. **Chat completion** — Retrieved documents are passed as context to Azure OpenAI (`gpt-4o` by default) with conversation history.
9. **Content safety (output)** — When enabled, the LLM response is checked for harmful content. Flagged answers are replaced with a safe message before being returned or cached.
10. **PII masking (output)** — When enabled, the LLM response is scanned for PII. Any detected PII is redacted before the answer is returned to the user or cached.
11. **Cache write** — Answer and embedding are saved to Redis for future queries.

## Project Structure

```
├── function_app.py          # HTTP trigger, search, LLM orchestration, content safety integration
├── chatbot_prompt.py        # System prompt, canned responses, intent detection, prompt-injection defences
├── content_safety.py        # Azure AI Content Safety: input/output text analysis and filtering
├── pii_masking.py           # Azure AI Language: PII detection and masking for input/output
├── redis_cache.py           # Optional Redis layer (conversation history + global Q&A cache)
├── azure_sp_common.py       # Auth helpers (Managed Identity / Service Principal / Key Vault), TLS, Redis utilities
├── requirements.txt         # Python dependencies
├── host.json                # Azure Functions host configuration
├── local.settings.json      # Local dev settings (never commit real secrets)
├── package-deploy.ps1       # Zip-packaging script for Kudu / az CLI deployment
├── sql_schema.sql           # Reference SQL Server schema for conversation history
└── .funcignore              # Files excluded from Azure Functions publish
```

## Prerequisites

- **Python 3.9+**
- **Azure Functions Core Tools v4** — [Install guide](https://learn.microsoft.com/azure/azure-functions/functions-run-local)
- **Azure resources:**
  - Azure OpenAI (with `text-embedding-3-small` and `gpt-4o` deployments)
  - Azure AI Search (with a `fedex-vectors` index and `default` semantic configuration)
  - Azure AI Content Safety (optional — for input/output harmful content filtering)
  - Azure AI Language (optional — for PII detection and masking via Text Analytics)
  - Azure Cache for Redis (optional — Entra-authenticated, port 6380/TLS)
  - Azure Key Vault (optional — for secret bootstrapping via Managed Identity)

## Configuration

All configuration is via environment variables. For local development, set them in `local.settings.json` under `Values`. In Azure, set them as **Application Settings** on the Function App.

### Required

| Variable | Description |
|---|---|
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI resource endpoint URL |
| `AZURE_SEARCH_ENDPOINT` | Azure AI Search service endpoint URL |
| `AZURE_SEARCH_INDEX_NAME` | Search index name (default: `fedex-vectors`) |

### Optional — Models & Search

| Variable | Default | Description |
|---|---|---|
| `AZURE_OPENAI_API_VERSION` | `2024-12-01-preview` | OpenAI API version |
| `AZURE_OPENAI_EMBEDDING_MODEL` | `text-embedding-3-small` | Embedding deployment name |
| `AZURE_OPENAI_CHAT_DEPLOYMENT` | `gpt-4o` | Chat completion deployment name |
| `AZURE_OPENAI_CHAT_TEMPERATURE` | `0.3` | LLM temperature |
| `AZURE_OPENAI_CHAT_MAX_TOKENS` | `4096` | Max response tokens |
| `SEARCH_TOP_K` | `3` | Number of search results to retrieve |
| `SEARCH_VECTOR_K` | `max(top_k, 50)` | Vector candidate count before reranking |
| `AZURE_SEARCH_SEMANTIC_CONFIGURATION` | `primary-semantic-config` | Semantic configuration name on the index |

### Optional — Authentication

The backend supports two auth modes for Azure OpenAI and AI Search:

| Mode | Variables |
|---|---|
| **Managed Identity** (recommended for Azure) | No extra config — uses `DefaultAzureCredential` (system-assigned MI) |
| **Service Principal** | `AZURE_TENANT_ID`, `AZURE_CLIENT_ID_VALUE`, `AZURE_CLIENT_SECRET_VALUE` |
| **Service Principal via Key Vault** | `AZURE_TENANT_ID`, `AZURE_KEY_VAULT_URL`, `KEY_VAULT_SECRET_NAME_CLIENT_ID`, `KEY_VAULT_SECRET_NAME_CLIENT_SECRET` |

### Optional — Redis Cache

| Variable | Description |
|---|---|
| `REDIS_CACHE_ENABLED` | `true` to enable caching (default: disabled) |
| `AZURE_REDIS_HOST` (or `REDIS_HOST`) | Redis hostname |
| `AZURE_REDIS_PORT` | Redis port (default: `6380`) |
| `AZURE_REDIS_ENTRA_OBJECT_ID` | Entra object ID used as the Redis ACL username |

### Optional — Content Safety

Azure AI Content Safety filters harmful user input and LLM output across four categories: Hate, SelfHarm, Sexual, and Violence. When disabled, all checks are skipped with zero overhead.

| Variable | Default | Description |
|---|---|---|
| `CONTENT_SAFETY_ENABLED` | `false` | Set to `true` to enable content filtering |
| `AZURE_CONTENT_SAFETY_ENDPOINT` | — | Content Safety resource endpoint URL (required when enabled) |
| `AZURE_CONTENT_SAFETY_KEY` | — | API key (optional; omit to use Entra ID / Managed Identity) |
| `CONTENT_SAFETY_SEVERITY_THRESHOLD` | `2` | Minimum severity (0–6) to flag content as unsafe |

Authentication follows the same pattern as the rest of the app: if `AZURE_CONTENT_SAFETY_KEY` is set, it uses the API key; otherwise it authenticates via Entra ID (`DefaultAzureCredential` / service principal), so no extra auth configuration is needed if your Function App already has a Managed Identity with the **Cognitive Services User** role on the Content Safety resource.

### Optional — PII Masking

Azure AI Language PII masking detects and redacts personally identifiable information (names, emails, phone numbers, addresses, SSNs, etc.) in both user input and LLM output. When enabled, PII in the user query is replaced with category placeholders (e.g. `[PERSON]`, `[EMAIL]`) before it reaches embeddings, search, the LLM, or cache. The LLM response is also scanned and masked before being returned to the user.

| Variable | Default | Description |
|---|---|---|
| `PII_MASKING_ENABLED` | `false` | Set to `true` to enable PII masking |
| `AZURE_LANGUAGE_ENDPOINT` | — | Azure AI Language resource endpoint URL (required when enabled) |
| `AZURE_LANGUAGE_KEY` | — | API key (optional; omit to use Entra ID / Managed Identity) |
| `PII_MASKING_CATEGORIES` | all | Comma-separated PII categories to detect (e.g. `Person,Email,PhoneNumber`). Omit to detect all categories |
| `PII_MASKING_MIN_CONFIDENCE` | `0.0` | Minimum confidence score (0.0–1.0) for an entity to be redacted |

Authentication follows the same pattern as the rest of the app: if `AZURE_LANGUAGE_KEY` is set, it uses the API key; otherwise it authenticates via Entra ID (`DefaultAzureCredential` / service principal), so no extra auth configuration is needed if your Function App already has a Managed Identity with the **Cognitive Services User** role on the Language resource.

### Optional — TLS / SSL

| Variable | Description |
|---|---|
| `TEST_OPENAI_SSL_VERIFY` | `false` to disable SSL verification (dev only) |
| `SSL_CERT_FILE` | Path to a custom CA bundle PEM file |
| `REQUESTS_CA_BUNDLE` | Alternative CA bundle path |

## Local Development

1. **Clone and install dependencies:**

   ```bash
   cd chatbot-retrieval-backend
   python -m venv .venv
   .venv\Scripts\activate        # Windows
   # source .venv/bin/activate   # macOS/Linux
   pip install -r requirements.txt
   ```

2. **Configure `local.settings.json`** with your Azure resource endpoints and credentials. Never commit secrets to source control.

3. **Run the function locally:**

   ```bash
   func start
   ```

4. **Test with curl or Postman:**

   ```bash
   curl -X POST http://localhost:7071/api/http_trigger_from_chatbot \
     -H "Content-Type: application/json" \
     -d '{"query": "How do I migrate from SOAP to REST?", "userId": "dev_user"}'
   ```

## API Reference

### `POST /api/http_trigger_from_chatbot`

Also accepts `GET` with query parameters.

**Request body:**

```json
{
  "query": "How do I migrate from SOAP to REST?",
  "userId": "user123",
  "sessionId": "optional-uuid"
}
```

| Field | Required | Description |
|---|---|---|
| `query` | Yes | The user's question |
| `userId` | No | User identifier (default: `test_user`) |
| `sessionId` | No | UUID for conversation continuity; auto-generated if missing |

**Response (200):**

```json
{
  "query": "How do I migrate from SOAP to REST?",
  "answer": "To migrate from SOAP to REST, you'll need to...",
  "sources": [
    {
      "context": "The actual text content of the retrieved chunk...",
      "title": "FedEx API Migration Guide",
      "section_heading": "SOAP to REST Migration Steps",
      "heading_path": "Migration Guide > SOAP to REST Migration Steps",
      "score": 0.033,
      "reranker_score": 3.2,
      "chunk_index": 12
    }
  ],
  "sessionId": "a1b2c3d4-...",
  "from_cache": false,
  "cosine_similarity": null,
  "execution_time_ms": 2340.5,
  "content_safety": {
    "enabled": true,
    "input_safe": true,
    "input_details": {"Hate": 0, "SelfHarm": 0, "Sexual": 0, "Violence": 0},
    "output_safe": true,
    "output_details": {"Hate": 0, "SelfHarm": 0, "Sexual": 0, "Violence": 0}
  },
  "pii_masking": {
    "enabled": true,
    "input_pii_detected": true,
    "input_entities_masked": 2,
    "output_pii_detected": false,
    "output_entities_masked": 0
  }
}
```

When content safety is disabled, the `content_safety` field is `{"enabled": false}`.
When PII masking is disabled, the `pii_masking` field is `{"enabled": false}`.

**Error responses:**

| Status | Condition |
|---|---|
| `400` | Missing or empty `query` |
| `400` | Missing `userId` |
| `400` | Content safety flagged the input (includes `content_safety` object with `flagged_categories`) |
| `500` | Internal error (embedding failure, search error, etc.) |

## Deployment

### Zip Deploy (Kudu)

1. **Package the function app:**

   ```powershell
   .\package-deploy.ps1
   ```

   > **Note:** The script includes all required Python modules (`chatbot_prompt.py`, `content_safety.py`, `pii_masking.py`, `redis_cache.py`). If you add new modules, remember to add them to the `$files` array in the script.

2. **Deploy via Azure CLI:**

   ```bash
   az functionapp deployment source config-zip \
     -g <resource-group> -n <function-app-name> \
     --src functionapp-deploy.zip
   ```

   Or upload `functionapp-deploy.zip` through **Kudu** > **Zip Push Deploy**.

### Azure Portal Testing

1. Navigate to your **Function App** > **Functions** > `http_trigger_from_chatbot`.
2. Click **Code + Test** > **Test/Run**.
3. Set method to `POST`, add header `Content-Type: application/json`, and paste a JSON body.
4. Click **Run**.

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| `Connection error` on `/embeddings` | Azure OpenAI firewall blocking the Function App | Add Function App outbound IPs to the Azure OpenAI **Networking** allowlist, or enable VNet integration if using private endpoints |
| `AADSTS700016` | `AZURE_CLIENT_ID` set to a Key Vault secret name instead of a GUID | Use `KEY_VAULT_SECRET_NAME_CLIENT_ID` for the secret name; remove `AZURE_CLIENT_ID` from app settings |
| Redis connection failures | Missing `REDIS_CACHE_ENABLED=true` or wrong `AZURE_REDIS_HOST` | Verify env vars and ensure the Redis firewall allows the Function App |
| `Key Vault bootstrap failed` | Managed Identity lacks Key Vault access | Grant **Key Vault Secrets User** role to the Function App's system-assigned identity |
| Import errors after deploy | Python modules missing from the deploy zip | Ensure all `.py` modules are listed in the `$files` array in `package-deploy.ps1` |
| Content safety always returns `enabled: false` | `CONTENT_SAFETY_ENABLED` not set to `true` | Set `CONTENT_SAFETY_ENABLED=true` in Application Settings |
| Content safety errors in logs | Missing or wrong `AZURE_CONTENT_SAFETY_ENDPOINT` | Verify the endpoint URL and ensure the Function App identity has **Cognitive Services User** role |
| PII masking always returns `enabled: false` | `PII_MASKING_ENABLED` not set to `true` | Set `PII_MASKING_ENABLED=true` in Application Settings |
| PII masking errors in logs | Missing or wrong `AZURE_LANGUAGE_ENDPOINT` | Verify the endpoint URL and ensure the Function App identity has **Cognitive Services User** role on the Language resource |

## Security Notes

- **`local.settings.json`** is excluded from deployment by `.funcignore` — never commit it with real credentials.
- The HTTP trigger uses `AuthLevel.ANONYMOUS`. For production, consider adding authentication (e.g., Azure AD / EasyAuth, API key via `AuthLevel.FUNCTION`).
- **Content safety** (`content_safety.py`) — Azure AI Content Safety filters both user input and LLM output for harmful content (Hate, SelfHarm, Sexual, Violence). Controlled by `CONTENT_SAFETY_ENABLED`. Fail-open by default: if the Content Safety API is unreachable, requests are allowed through with an error logged.
- **PII masking** (`pii_masking.py`) — Azure AI Language PII detection redacts personally identifiable information from user input (before it reaches the LLM, search, or cache) and from LLM output (before it is returned to the caller). Controlled by `PII_MASKING_ENABLED`. Fail-open by default: if the Language API is unreachable, requests are allowed through with an error logged.
- **Prompt-injection defences** (`chatbot_prompt.py`) — extraction detection, instruction-leak filtering, and history sanitization provide an additional layer of protection independent of content safety.
