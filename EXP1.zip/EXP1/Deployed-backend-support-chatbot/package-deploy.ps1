# Builds functionapp-deploy.zip with the correct flat layout for Azure Functions Python.
# Run from this folder:  .\package-deploy.ps1
# Upload the zip in Kudu (Zip push deploy) or: az functionapp deployment source config-zip -g RG -n APP --src functionapp-deploy.zip

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location $root

$files = @(
    "host.json",
    "function_app.py",
    "azure_sp_common.py",
    "chatbot_prompt.py",
    "content_safety.py",
    "redis_cache.py",
    "pii_masking.py",
    "requirements.txt"
)
foreach ($f in $files) {
    $p = Join-Path $root $f
    if (-not (Test-Path $p)) {
        Write-Error "Missing $f - run this script from fedex-chatbot-backend (folder that contains function_app.py)."
    }
}

$paths = $files | ForEach-Object { Join-Path $root $_ }
$out = Join-Path $root "functionapp-deploy.zip"
if (Test-Path $out) {
    Remove-Item $out -Force
}

Compress-Archive -LiteralPath $paths -DestinationPath $out -CompressionLevel Optimal -Force
Write-Host "Created: $out"
Write-Host "Verify: expand the zip - the FIRST screen must show host.json AND function_app.py side by side (not inside another folder)."
