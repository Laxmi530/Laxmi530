"""Azure AI Language PII detection and masking for input/output.

Uses the ``recognize_pii_entities`` API from Azure AI Language (Text Analytics)
to detect and redact personally identifiable information (PII) in user queries
and LLM responses before they are processed, cached, or returned to the caller.

Controlled by the ``PII_MASKING_ENABLED`` environment variable (``true``
to enable, anything else or unset to disable).

Configuration (environment variables / ``local.settings.json`` Values):
    PII_MASKING_ENABLED              : ``true`` to enable; default disabled.
    AZURE_LANGUAGE_ENDPOINT          : Azure AI Language resource endpoint URL.
    AZURE_LANGUAGE_KEY               : (Optional) API key.  When omitted the
                                       module authenticates with Entra ID via
                                       ``azure_sp_common.get_azure_token_credential``.
    PII_MASKING_CATEGORIES           : Comma-separated PII categories to detect
                                       (e.g. ``Person,Email,PhoneNumber``).
                                       Default: all categories.
    PII_MASKING_MIN_CONFIDENCE       : Minimum confidence score (0.0–1.0) for an
                                       entity to be redacted; default ``0.0``
                                       (redact everything detected).

Usage from ``function_app.py``::

    from pii_masking import mask_pii_input, mask_pii_output, is_enabled as pii_masking_enabled

    # Before processing a user query:
    pii_input = mask_pii_input(query)
    masked_query = pii_input["redacted_text"]

    # After generating the LLM answer:
    pii_output = mask_pii_output(answer)
    masked_answer = pii_output["redacted_text"]
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_language_client = None


def is_enabled() -> bool:
    """Return ``True`` when PII masking is active."""
    return os.environ.get("PII_MASKING_ENABLED", "").strip().lower() == "true"


def _get_client():
    """Lazy singleton for the Text Analytics client.

    Uses an API key when ``AZURE_LANGUAGE_KEY`` is set; otherwise falls back to
    Entra ID (managed identity / service principal) via the shared
    ``azure_sp_common`` credential helper, consistent with the rest of the app.
    """
    global _language_client
    if _language_client is not None:
        return _language_client

    from azure.ai.textanalytics import TextAnalyticsClient
    from azure.core.credentials import AzureKeyCredential

    endpoint = os.environ.get("AZURE_LANGUAGE_ENDPOINT", "").strip()
    if not endpoint:
        raise ValueError(
            "AZURE_LANGUAGE_ENDPOINT must be set when PII_MASKING_ENABLED=true."
        )

    api_key = os.environ.get("AZURE_LANGUAGE_KEY", "").strip()
    if api_key:
        credential = AzureKeyCredential(api_key)
    else:
        from azure_sp_common import get_azure_token_credential
        credential = get_azure_token_credential()

    _language_client = TextAnalyticsClient(endpoint=endpoint, credential=credential)
    logger.info(
        "PII masking client initialised (endpoint=%s, auth=%s).",
        endpoint,
        "api_key" if api_key else "entra_id",
    )
    return _language_client


def _configured_categories() -> list[str] | None:
    """Return the explicit list of PII categories to detect, or ``None`` for all."""
    raw = os.environ.get("PII_MASKING_CATEGORIES", "").strip()
    if not raw:
        return None
    return [c.strip() for c in raw.split(",") if c.strip()]


def _min_confidence() -> float:
    return float(os.environ.get("PII_MASKING_MIN_CONFIDENCE", "0.0"))


def _recognise_pii(text: str) -> dict[str, Any]:
    """Call ``recognize_pii_entities`` and return a structured result.

    Returns a dict with:
        redacted_text      : Text with PII replaced by category placeholders.
        entities           : List of detected PII entities (category, text,
                             confidence_score, offset, length).
        has_pii (bool)     : True when at least one entity was detected and redacted.
    """
    from azure.ai.textanalytics import PiiEntityCategory

    client = _get_client()
    categories = _configured_categories()
    min_conf = _min_confidence()

    kwargs: dict[str, Any] = {}
    if categories:
        mapped = []
        for cat in categories:
            try:
                mapped.append(PiiEntityCategory(cat))
            except (ValueError, KeyError):
                mapped.append(cat)
        kwargs["categories_filter"] = mapped

    try:
        results = client.recognize_pii_entities([text], **kwargs)
        result = results[0]
    except Exception:
        logger.exception("PII masking API call failed")
        raise

    if result.is_error:
        err = result.error
        logger.error("PII masking returned an error: %s — %s", err.code, err.message)
        raise RuntimeError(f"PII detection error: {err.code} — {err.message}")

    entities: list[dict[str, Any]] = []
    for entity in result.entities:
        if entity.confidence_score < min_conf:
            continue
        entities.append({
            "category": entity.category,
            "text": entity.text,
            "confidence_score": round(entity.confidence_score, 4),
            "offset": entity.offset,
            "length": entity.length,
        })

    redacted = result.redacted_text
    has_pii = len(entities) > 0

    if has_pii:
        logger.info(
            "PII masking|detected %d entit%s: %s",
            len(entities),
            "y" if len(entities) == 1 else "ies",
            [e["category"] for e in entities],
        )

    return {"redacted_text": redacted, "entities": entities, "has_pii": has_pii}


def mask_pii_input(text: str) -> dict[str, Any]:
    """Detect and mask PII in user input.

    When PII masking is disabled or the text is empty, returns
    ``{"redacted_text": text, "has_pii": False}`` immediately (pass-through).

    Returns a dict with ``redacted_text``, ``entities``, ``has_pii``,
    and ``enabled``.
    """
    if not is_enabled():
        logger.debug("PII masking|skipped (disabled) for input")
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": False}

    if not text or not text.strip():
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": True}

    try:
        result = _recognise_pii(text)
        result["enabled"] = True
        if result["has_pii"]:
            logger.info(
                "PII masking|input: masked %d entit%s",
                len(result["entities"]),
                "y" if len(result["entities"]) == 1 else "ies",
            )
        return result
    except Exception as exc:
        logger.error("PII masking input check failed — passing through unmasked: %s", exc)
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": True, "error": str(exc)}


def mask_pii_output(text: str) -> dict[str, Any]:
    """Detect and mask PII in LLM output before returning to the user.

    When PII masking is disabled or the text is empty, returns
    ``{"redacted_text": text, "has_pii": False}`` immediately (pass-through).

    Returns a dict with ``redacted_text``, ``entities``, ``has_pii``,
    ``enabled``, and ``original_text`` (for auditing, only when PII was found).
    """
    if not is_enabled():
        logger.debug("PII masking|skipped (disabled) for output")
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": False}

    if not text or not text.strip():
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": True}

    try:
        result = _recognise_pii(text)
        result["enabled"] = True
        if result["has_pii"]:
            result["original_text"] = text
            logger.info(
                "PII masking|output: masked %d entit%s",
                len(result["entities"]),
                "y" if len(result["entities"]) == 1 else "ies",
            )
        return result
    except Exception as exc:
        logger.error("PII masking output check failed — passing through unmasked: %s", exc)
        return {"redacted_text": text, "entities": [], "has_pii": False, "enabled": True, "error": str(exc)}
