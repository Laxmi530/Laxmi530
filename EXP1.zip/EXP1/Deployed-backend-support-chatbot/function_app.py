import azure.functions as func
import logging
import os
import json
import time
import uuid

from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery

from azure_sp_common import (
    build_search_credential,
    create_openai_client,
    load_keyvault_secrets_into_environ,
)
from chatbot_prompt import (
    SAFE_INSTRUCTION_REFUSAL,
    GREETING_RESPONSE,
    GOODBYE_RESPONSE,
    THANKS_RESPONSE,
    NO_RESULTS_RESPONSE,
    get_system_prompt,
    build_user_message,
    is_greeting,
    is_goodbye,
    is_thanks,
    user_requests_prompt_extraction,
    response_leaks_instructions,
    sanitize_conversation_history,
)
from redis_cache import (
    get_redis_client,
    get_conversation_history,
    get_cached_answer_global,
    save_to_global_cache,
    save_conversation_turn,
)
from content_safety import analyse_input, analyse_output, is_enabled as content_safety_enabled
from pii_masking import mask_pii_input, mask_pii_output, is_enabled as pii_masking_enabled

# System-assigned MI: set AZURE_KEY_VAULT_URL + grant Key Vault access; may load secrets only if env vars unset.
# Redis (optional): set REDIS_CACHE_ENABLED=true to enable. AZURE_REDIS_ENTRA_OBJECT_ID in app settings for Entra username (preferred over Key Vault).
# Also: KEY_VAULT_SECRET_NAME_CLIENT_ID / KEY_VAULT_SECRET_NAME_CLIENT_SECRET -> AZURE_*_VALUE, or literal *_VALUE for local.
# Do not raise here: a Key Vault failure would prevent the worker from registering any functions.
try:
    load_keyvault_secrets_into_environ()
except Exception as e:
    logging.exception("Key Vault bootstrap failed (check AZURE_KEY_VAULT_URL, RBAC, secret names): %s", e)

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# Lazy singletons for OpenAI and Search clients (avoid re-creating on every request)
_openai_client = None
_search_client = None

def _get_openai_client():
    global _openai_client
    if _openai_client is None:
        openai_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
        _openai_client = create_openai_client(openai_endpoint, api_version)
    return _openai_client


def _get_search_client():
    global _search_client
    if _search_client is None:
        search_endpoint = os.environ.get("AZURE_SEARCH_ENDPOINT")
        index_name = os.environ.get("AZURE_SEARCH_INDEX_NAME", "fedex-vectors")
        _search_client = SearchClient(
            endpoint=search_endpoint,
            index_name=index_name,
            credential=build_search_credential(),
        )
    return _search_client


def get_embedding(client, text, model="text-embedding-3-small"):
    """Generate embedding for the query text."""
    try:
        response = client.embeddings.create(input=text, model=model)
        return response.data[0].embedding
    except Exception as e:
        logging.error(f"Error generating embedding: {str(e)}")
        raise


def _expand_with_neighbor_chunks(search_client, results, select_fields, max_neighbors=1):
    """Fetch adjacent chunks (by chunk_index) for each result to reassemble truncated content.

    For each retrieved chunk, fetches chunks with chunk_index ± 1..max_neighbors from the
    same document (same filename + heading_path).  Deduplicates and preserves original order,
    appending neighbor content so the LLM sees complete sections instead of mid-JSON cuts.
    """
    if not results:
        return results

    seen_ids = {doc.get("id") for doc in results}
    neighbor_filters = []

    for doc in results:
        chunk_idx = doc.get("chunk_index")
        filename = doc.get("filename", "")
        heading_path = doc.get("heading_path", "")
        if chunk_idx is None or not filename:
            continue
        for offset in range(-max_neighbors, max_neighbors + 1):
            if offset == 0:
                continue
            neighbor_idx = chunk_idx + offset
            if neighbor_idx < 0:
                continue
            neighbor_filters.append(
                f"(filename eq '{filename}' and chunk_index eq {neighbor_idx})"
            )

    if not neighbor_filters:
        return results

    batch_size = 10
    neighbors_by_key = {}
    for i in range(0, len(neighbor_filters), batch_size):
        batch_filter = " or ".join(neighbor_filters[i:i + batch_size])
        try:
            neighbor_results = search_client.search(
                search_text="*",
                filter=batch_filter,
                select=select_fields,
                top=len(neighbor_filters[i:i + batch_size]),
            )
            for nr in neighbor_results:
                nid = nr.get("id")
                if nid and nid not in seen_ids:
                    ndoc = {field: nr.get(field) for field in select_fields}
                    key = (ndoc.get("filename", ""), ndoc.get("chunk_index"))
                    neighbors_by_key[key] = ndoc
                    seen_ids.add(nid)
        except Exception as e:
            logging.warning("Neighbor chunk fetch failed: %s", e)

    expanded = []
    for doc in results:
        expanded.append(doc)
        chunk_idx = doc.get("chunk_index")
        filename = doc.get("filename", "")
        if chunk_idx is None:
            continue
        for offset in range(1, max_neighbors + 1):
            key = (filename, chunk_idx + offset)
            if key in neighbors_by_key:
                neighbor = neighbors_by_key.pop(key)
                neighbor["@search.score"] = doc.get("@search.score")
                neighbor["@search.reranker_score"] = doc.get("@search.reranker_score")
                expanded.append(neighbor)

    return expanded


def search_knowledge_base(query, query_vector, search_client, top_k=3):
    """Hybrid search (keyword + vector) with semantic reranking, aligned with Primary_indexing ``indexing.hybrid_search``.

    The indexer creates a semantic configuration named ``default`` (see Primary_indexing ``ensure_search_index``).
    Override with env ``AZURE_SEARCH_SEMANTIC_CONFIGURATION`` if your index uses a different name.
    Vector candidate count uses ``SEARCH_VECTOR_K`` when set; otherwise ``max(top_k, 50)`` for a wider pool before rerank.

    Returns a list of dicts with selected fields plus ``@search.score``,
    ``@search.reranker_score``, and ``@search.captions`` when available.
    """
    semantic_configuration = os.environ.get(
        "AZURE_SEARCH_SEMANTIC_CONFIGURATION", "default"
    )
    vector_k = int(
        os.environ.get("SEARCH_VECTOR_K", str(max(top_k, 50)))
    )
    select = [
        "id",
        "content",
        "source",
        "filename",
        "title",
        "created_date",
        "section_heading",
        "parent_heading",
        "heading_path",
        "chunk_index",
    ]
    # --- HYBRID SEARCH: vector similarity (ANN) ---
    # VectorizedQuery sends the query embedding to the HNSW index for approximate
    # nearest-neighbor lookup.  k_nearest_neighbors controls how many vector
    # candidates are retrieved (default 50) before fusion with BM25 keyword results.
    vector_query = VectorizedQuery(
        vector=query_vector,
        k_nearest_neighbors=vector_k,
        fields="contentVector",
    )

    # --- HYBRID SEARCH: keyword (BM25) + vector fusion ---
    # "search_text" triggers the BM25 keyword leg; "vector_queries" triggers the
    # vector leg.  Azure AI Search fuses both score signals using Reciprocal Rank
    # Fusion (RRF) to produce a single ranked list.  "top" limits the final output.
    base_params = {
        "search_text": query,          # BM25 full-text keyword search
        "vector_queries": [vector_query],  # ANN vector search
        "select": select,
        "top": top_k,
    }

    def _extract_results(results):
        """Normalize raw search results into structured dicts with scores and captions."""
        output = []
        for result in results:
            doc = {field: result.get(field) for field in select}
            # @search.score — hybrid (BM25 + vector) fused score
            doc["@search.score"] = result.get("@search.score")
            # @search.reranker_score — semantic reranker score (0–4 scale, only
            # present when query_type="semantic" succeeds)
            doc["@search.reranker_score"] = result.get("@search.reranker_score")

            captions = result.get("@search.captions")
            if captions:
                doc["@search.captions"] = [
                    {"text": c.text, "highlights": c.highlights}
                    for c in captions
                ]
            output.append(doc)
        return output

    expand_neighbors = os.environ.get("SEARCH_EXPAND_NEIGHBORS", "true").lower() in ("1", "true", "yes")
    max_neighbors = int(os.environ.get("SEARCH_MAX_NEIGHBOR_CHUNKS", "2"))

    try:
        logging.info(
            "Hybrid semantic search (config=%s, vector_k=%s, top=%s) for query: %s...",
            semantic_configuration,
            vector_k,
            top_k,
            query[:50],
        )
        results = search_client.search(
            **base_params,
            query_type="semantic",
            semantic_configuration_name=semantic_configuration,
            query_caption="extractive",
            query_answer="extractive",
        )
        extracted = _extract_results(results)
    except Exception:
        logging.info(
            "Falling back to hybrid search without semantic reranking (config=%s)",
            semantic_configuration,
        )
        results = search_client.search(**base_params)
        extracted = _extract_results(results)

    if expand_neighbors and extracted:
        extracted = _expand_with_neighbor_chunks(
            search_client, extracted, select, max_neighbors=max_neighbors,
        )

    return extracted


_MAX_CONTINUATION_ROUNDS = 2


def generate_response(openai_client, query, context_docs, conversation_history, model="gpt-4o", temperature=0, max_tokens=4096, seed=42):
    """Generate response using retrieved context and conversation history.

    If the model's reply is truncated (finish_reason == 'length'), a
    continuation request is sent automatically (up to _MAX_CONTINUATION_ROUNDS)
    and the parts are stitched together so the user always receives a
    complete answer.
    """
    if user_requests_prompt_extraction(query):
        logging.info("Blocked prompt-extraction request (query pattern).")
        return SAFE_INSTRUCTION_REFUSAL

    history = sanitize_conversation_history(conversation_history)
    user_content = build_user_message(query, context_docs)

    messages = [{"role": "system", "content": get_system_prompt()}]
    for msg in history:
        messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": user_content})

    try:
        response = openai_client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            seed=seed,
        )
        out = response.choices[0].message.content
        finish = response.choices[0].finish_reason

        rounds = 0
        while finish == "length" and rounds < _MAX_CONTINUATION_ROUNDS:
            rounds += 1
            logging.info("Response truncated (finish_reason='length'), requesting continuation %d.", rounds)
            messages.append({"role": "assistant", "content": out})
            messages.append({"role": "user", "content": "Your previous response was cut off. Please continue exactly where you left off."})
            response = openai_client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                seed=seed,
            )
            continuation = response.choices[0].message.content
            out += continuation
            finish = response.choices[0].finish_reason

        if response_leaks_instructions(out):
            logging.info("Stripped assistant output that appeared to leak instructions.")
            return SAFE_INSTRUCTION_REFUSAL
        return out
    except Exception as e:
        logging.error(f"Error generating response: {str(e)}")
        raise


@app.route(route="http_trigger_from_chatbot", methods=["GET", "POST"])
def http_trigger_from_chatbot(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing chatbot query request.")

    try:
        req_body = {}
        if req.get_body():
            try:
                req_body = req.get_json() or {}
            except ValueError:
                pass

        query = req.params.get("query") or req_body.get("query", "")
        user_id = req.params.get("userId","test_user") or req_body.get("userId", "test_user")
        session_id = req.params.get("sessionId") or req_body.get("sessionId", "")

        # Log request headers (redact Authorization value for security)
        try:
            headers_dict = dict(req.headers) if req.headers else {}
        except Exception as e:
            logging.warning(f"Failed to extract headers: {e}")
            headers_dict = {}
        headers_dict = {str(k): str(v) for k, v in headers_dict.items()}
        if "Authorization" in headers_dict and headers_dict["Authorization"]:
            headers_dict["Authorization"] = "[REDACTED]"
        logging.info(f"RequestHeaders|{json.dumps(headers_dict)}")

        logging.info(f"session id from front end: {session_id} for user: {user_id}")
        if not query or not query.strip():
            return func.HttpResponse(
                json.dumps({"error": "Please ask a question."}),
                mimetype="application/json",
                status_code=400,
            )

        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "Please provide a 'userId' parameter"}),
                mimetype="application/json",
                status_code=400,
            )

        if not session_id:
            session_id = str(uuid.uuid4())
            logging.info(f"Created new session: {session_id} for user: {user_id}")
        else:
            # Ensure session_id is a valid UUID for consistent session ids
            try:
                uuid.UUID(session_id)
            except (ValueError, TypeError):
                session_id = str(uuid.uuid4())
                logging.info(f"Invalid sessionId format; created new session: {session_id}")

        query_normalized = query.strip().lower()
        t_start = time.perf_counter()

        def elapsed_ms():
            return round((time.perf_counter() - t_start) * 1000, 2)

        if is_greeting(query_normalized):
            answer = GREETING_RESPONSE
            save_conversation_turn(session_id, user_id, query, answer)
            return func.HttpResponse(
                json.dumps({"query": query, "answer": answer, "sources": [], "sessionId": session_id, "execution_time_ms": elapsed_ms()}, indent=2),
                mimetype="application/json",
                status_code=200,
            )
        if is_goodbye(query_normalized):
            answer = GOODBYE_RESPONSE
            save_conversation_turn(session_id, user_id, query, answer)
            return func.HttpResponse(
                json.dumps({"query": query, "answer": answer, "sources": [], "sessionId": session_id, "execution_time_ms": elapsed_ms()}, indent=2),
                mimetype="application/json",
                status_code=200,
            )
        if is_thanks(query_normalized):
            answer = THANKS_RESPONSE
            save_conversation_turn(session_id, user_id, query, answer)
            return func.HttpResponse(
                json.dumps({"query": query, "answer": answer, "sources": [], "sessionId": session_id, "execution_time_ms": elapsed_ms()}, indent=2),
                mimetype="application/json",
                status_code=200,
            )

        input_safety = analyse_input(query)
        if not input_safety["safe"]:
            logging.warning("ContentSafety|input blocked for session %s: %s", session_id, input_safety.get("flagged_categories"))
            return func.HttpResponse(
                json.dumps({
                    "query": query,
                    "error": input_safety.get("message", "Your message was flagged by content safety filters."),
                    "sessionId": session_id,
                    "execution_time_ms": elapsed_ms(),
                    "content_safety": {
                        "enabled": True,
                        "input_safe": False,
                        "input_details": input_safety.get("details", {}),
                        "flagged_categories": input_safety.get("flagged_categories", []),
                    },
                }, indent=2),
                mimetype="application/json",
                status_code=400,
            )

        pii_input = mask_pii_input(query)
        if pii_input["has_pii"]:
            logging.info("PII masking|input masked for session %s: %d entities", session_id, len(pii_input.get("entities", [])))
            query = pii_input["redacted_text"]

        embedding_model = os.environ.get("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
        chat_model = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4o")
        chat_temperature = float(os.environ.get("AZURE_OPENAI_CHAT_TEMPERATURE", "0"))
        chat_max_tokens = int(os.environ.get("AZURE_OPENAI_CHAT_MAX_TOKENS", "4096"))
        top_k = int(os.environ.get("SEARCH_TOP_K", "3"))
        chat_seed = int(os.environ.get("AZURE_OPENAI_CHAT_SEED", "42"))

        openai_client = _get_openai_client()
        search_client = _get_search_client()

        redis_client = get_redis_client()

        # 1. Check exact-match cache (no embedding needed)
        cached_answer, cached_sources, from_cache, cosine_sim = get_cached_answer_global(redis_client, query)
        if from_cache and cached_answer:
            logging.info(f"Returning cached answer from global cache for query: {query[:50]}...")
            save_conversation_turn(session_id, user_id, query, cached_answer)
            try:
                logging.info(f"ChatConversation|{json.dumps({'event': 'chat_turn', 'session_id': session_id, 'user_id': user_id, 'query': (query or '')[:500], 'answer': cached_answer[:500], 'sources_count': len(cached_sources or []), 'from_cache': True})}")
            except Exception:
                pass
            return func.HttpResponse(
                json.dumps({
                    "query": query,
                    "answer": cached_answer,
                    "sources": cached_sources or [],
                    "sessionId": session_id,
                    "from_cache": True,
                    "cosine_similarity": cosine_sim,
                    "execution_time_ms": elapsed_ms(),
                }, indent=2),
                mimetype="application/json",
                status_code=200,
            )

        conversation_history = get_conversation_history(session_id)
        logging.info(f"Retrieved {len(conversation_history)} messages from history for session {session_id}")

        query_vector = get_embedding(openai_client, query, embedding_model)

        # 2. Check semantic cache (similar questions, different wording)
        cached_answer, cached_sources, from_cache, cosine_sim = get_cached_answer_global(redis_client, query, query_vector)
        cache_miss_cosine_sim = cosine_sim  # Keep for response when we proceed to search
        if from_cache and cached_answer:
            logging.info(f"Returning cached answer from semantic cache for query: {query[:50]}...")
            save_conversation_turn(session_id, user_id, query, cached_answer)
            try:
                logging.info(f"ChatConversation|{json.dumps({'event': 'chat_turn', 'session_id': session_id, 'user_id': user_id, 'query': (query or '')[:500], 'answer': cached_answer[:500], 'sources_count': len(cached_sources or []), 'from_cache': True})}")
            except Exception:
                pass
            return func.HttpResponse(
                json.dumps({
                    "query": query,
                    "answer": cached_answer,
                    "sources": cached_sources or [],
                    "sessionId": session_id,
                    "from_cache": True,
                    "cosine_similarity": cosine_sim,
                    "execution_time_ms": elapsed_ms(),
                }, indent=2),
                mimetype="application/json",
                status_code=200,
            )

        search_results = search_knowledge_base(query, query_vector, search_client, top_k)

        output_safety = {"safe": True, "details": {}, "flagged_categories": []}
        pii_output = {"redacted_text": "", "entities": [], "has_pii": False, "enabled": pii_masking_enabled()}
        if not search_results:
            answer = NO_RESULTS_RESPONSE
            sources = []
        else:
            answer = generate_response(
                openai_client, query, search_results, conversation_history, chat_model, chat_temperature, chat_max_tokens, chat_seed
            )
            output_safety = analyse_output(answer)
            if not output_safety["safe"]:
                logging.warning("ContentSafety|output blocked for session %s: %s", session_id, output_safety.get("flagged_categories"))
                answer = output_safety["filtered_response"]

            pii_output = mask_pii_output(answer)
            if pii_output["has_pii"]:
                logging.info("PII masking|output masked for session %s: %d entities", session_id, len(pii_output.get("entities", [])))
                answer = pii_output["redacted_text"]

            sources = []
            for doc in search_results:
                src = {
                    "context": doc.get("content", ""),
                    "score": doc.get("@search.score", 0),
                    "reranker_score": doc.get("@search.reranker_score"),
                }
                if doc.get("title"):
                    src["title"] = doc["title"]
                if doc.get("section_heading"):
                    src["section_heading"] = doc["section_heading"]
                if doc.get("heading_path"):
                    src["heading_path"] = doc["heading_path"]
                if doc.get("chunk_index") is not None:
                    src["chunk_index"] = doc["chunk_index"]
                if doc.get("@search.captions"):
                    src["captions"] = doc["@search.captions"]
                sources.append(src)
            save_to_global_cache(redis_client, query, answer, sources, query_vector)

        save_conversation_turn(session_id, user_id, query, answer)

        cs_enabled = content_safety_enabled()
        pii_enabled = pii_masking_enabled()

        # Custom telemetry for Application Insights (structured log, no extra deps)
        try:
            telemetry = {
                "event": "chat_turn",
                "session_id": session_id,
                "user_id": user_id,
                "query": (query or "")[:500],
                "answer": (answer or "")[:500],
                "sources_count": len(sources),
                "content_safety_enabled": cs_enabled,
                "content_safety_input_safe": input_safety.get("safe", True),
                "content_safety_output_safe": output_safety.get("safe", True),
                "pii_masking_enabled": pii_enabled,
                "pii_input_detected": pii_input.get("has_pii", False),
                "pii_input_entity_count": len(pii_input.get("entities", [])),
                "pii_output_detected": pii_output.get("has_pii", False),
                "pii_output_entity_count": len(pii_output.get("entities", [])),
            }
            logging.info(f"ChatConversation|{json.dumps(telemetry)}")
        except Exception:
            pass
        response_data = {
            "query": query,
            "answer": answer,
            "sources": sources,
            "sessionId": session_id,
            "from_cache": False,
            "cosine_similarity": cache_miss_cosine_sim,
            "execution_time_ms": elapsed_ms(),
            "content_safety": {
                "enabled": cs_enabled,
                "input_safe": input_safety.get("safe", True),
                "input_details": input_safety.get("details", {}),
                "output_safe": output_safety.get("safe", True),
                "output_details": output_safety.get("details", {}),
            } if cs_enabled else {"enabled": False},
            "pii_masking": {
                "enabled": pii_enabled,
                "input_pii_detected": pii_input.get("has_pii", False),
                "input_entities_masked": len(pii_input.get("entities", [])),
                "output_pii_detected": pii_output.get("has_pii", False),
                "output_entities_masked": len(pii_output.get("entities", [])),
            } if pii_enabled else {"enabled": False},
        }

        return func.HttpResponse(
            json.dumps(response_data, indent=2),
            mimetype="application/json",
            status_code=200,
        )

    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500,
        )
