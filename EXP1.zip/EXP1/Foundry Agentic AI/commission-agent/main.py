"""Hosted commission agent (Microsoft Agent Framework, `responses` protocol).

The agent is a thin orchestrator: it decides which ruleset version to use,
sequences the deterministic tools, and explains results by citing the rule trace.
It performs NO arithmetic itself -- all numbers come from the function tools in
``tools.py``, which wrap the deterministic engine.

Local run:   python main.py   (serves the `responses` protocol on :8088)
Deploy:      see README.md -> "deploy agent to foundry"
"""

import logging
import os

from agent_framework import Agent
from agent_framework.foundry import FoundryChatClient
from agent_framework_foundry_hosting import ResponsesHostServer
from azure.identity import DefaultAzureCredential
from dotenv import load_dotenv

from tools import (
    list_ruleset_versions,
    get_commission_ruleset,
    compute_commissions,
    reconcile_against_expected,
)

load_dotenv(override=False)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("commission-agent")


INSTRUCTIONS = """\
You are the Commission Orchestrator agent. You calculate sales commissions by
applying a versioned, deterministic ruleset to order data in an Excel workbook,
then reconciling and explaining the results.

CRITICAL RULES:
- You NEVER do arithmetic yourself. All gross margins, tiers, rates, and amounts
  come exclusively from the tools. Do not invent or recompute numbers.
- Always ground rule explanations in the structured ruleset returned by
  `get_commission_ruleset` and the per-order `trace` returned by
  `compute_commissions`. Cite the matrix cell and which of R1-R4 fired.

TYPICAL FLOW:
1. If the user asks what rules apply, call `get_commission_ruleset`.
2. To calculate a workbook, call `compute_commissions` with the workbook name.
   Use `write_back=true` to fill GrossMargin/Tier/CommissionRate/CommissionAmount.
3. If the user wants validation, call `reconcile_against_expected` and report the
   pass/mismatch summary. For each mismatch, explain (using the rule trace) why
   the ruleset-derived value differs from the doc's expected value, and state that
   the expected table -- not the engine -- appears to be the source of the
   discrepancy unless the user says otherwise.
4. When explaining a specific order, summarize its trace in plain language with
   rule citations (e.g. "Recurring/Large/high = 9.0%, +0.5% R2, total 9.5%").

Be concise and precise. Default ruleset version is the registry default unless the
user specifies one.
"""


def build_agent() -> Agent:
    client = FoundryChatClient(
        project_endpoint=os.environ["FOUNDRY_PROJECT_ENDPOINT"],
        model=os.environ["AZURE_AI_MODEL_DEPLOYMENT_NAME"],
        credential=DefaultAzureCredential(),
    )
    return Agent(
        client=client,
        name="commission-orchestrator",
        instructions=INSTRUCTIONS,
        tools=[
            list_ruleset_versions,
            get_commission_ruleset,
            compute_commissions,
            reconcile_against_expected,
        ],
        default_options={"store": False},
    )


def main():
    logger.info("Starting commission-orchestrator hosted agent (responses protocol).")
    server = ResponsesHostServer(build_agent())
    server.run()


if __name__ == "__main__":
    main()
