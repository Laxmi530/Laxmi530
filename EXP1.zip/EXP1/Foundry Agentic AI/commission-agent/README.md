# Commission Orchestrator — Foundry Hosted Agent

A hosted Microsoft Foundry agent (Microsoft Agent Framework, `responses` protocol)
that calculates sales commissions by applying a **versioned, deterministic ruleset**
to order data in an Excel workbook, then reconciles and explains the results.

It implements the spec in `../Test_Doc.docx` against the data in `../Test_Workbook.xlsx`.

## Design principle

The LLM **orchestrates and explains**; it never does arithmetic. All gross
margins, tiers, rates, and amounts are produced by a deterministic Python engine
exposed to the agent as function tools. This makes results correct, auditable, and
repeatable — and it lets the agent surface inconsistencies instead of guessing.

```
User ──► Agent (LLM orchestrator)
            ├─ get_commission_ruleset()        → structured rules for citation
            ├─ compute_commissions()           → deterministic GM/Tier/Rate/Amount + rule trace
            └─ reconcile_against_expected()     → cell-by-cell pass/mismatch vs the doc
```

## Project layout

| Path | Role |
|------|------|
| `commission/rules.py` | **Versioned rule registry** (rate matrix, GM bands, tier, R1–R4). Add a new version here to onboard a new ruleset. |
| `commission/engine.py` | **Deterministic engine** — computes results + a step-by-step rule trace. No LLM. |
| `commission/workbook.py` | Reads input columns, writes `GrossMargin/Tier/CommissionRate/CommissionAmount` back (matched by header name). |
| `commission/reconcile.py` | Cell-by-cell comparison vs an expected table. |
| `commission/golden.py` | Expected-results table transcribed from `Test_Doc.docx`. |
| `tools.py` | Agent Framework `@tool` wrappers — the only way the LLM touches the logic. |
| `main.py` | Hosted-agent entrypoint (`ResponsesHostServer`) + orchestrator instructions. |
| `run_local.py` | **Runs the full pipeline deterministically without Foundry** — proves correctness. |
| `agent.yaml`, `Dockerfile` | Foundry deployment config. |

## Run the deterministic core locally (no Azure needed)

```bash
python run_local.py
```

This reads `data/Test_Workbook.xlsx`, fills the four computed columns into
`data/Test_Workbook_filled.xlsx`, and prints a reconciliation report.

### Validation result

13 of 15 rows match the doc's expected table exactly. **Two rows diverge — and the
engine is right, the doc's expected table is wrong:**

| Order | Engine (per stated rules) | Doc "expected" | Why the doc is inconsistent |
|-------|---------------------------|----------------|------------------------------|
| **ORD005** | rate 2.0% → **$1,900** | 1.0% → $950 | The doc subtracted the R3 high-discount penalty, but `DiscountPct = 20%` is **not > 25%**, so R3 must not fire. |
| **ORD006** | **Small**, 7.5% → **$3,375** | Large, 9.5% → $4,275 | `OrderValue = 45,000 < 50,000`, so the tier is **Small**, not Large (the doc mislabeled it). |

This is exactly the value of the deterministic + reconcile design: it catches
spec/data inconsistencies instead of silently propagating them. Decide whether to
fix the doc or adjust the ruleset, then re-run.

## Run as a hosted agent locally

```bash
python -m venv .venv
.venv\Scripts\activate           # Windows
pip install -r requirements.txt
copy .env.example .env           # fill in FOUNDRY_PROJECT_ENDPOINT + model deployment
python main.py                   # serves the responses protocol on :8088
```

Test request:

```bash
curl -X POST http://localhost:8088/responses \
  -H "Content-Type: application/json" \
  -d '{"input": "Calculate commissions for Test_Workbook.xlsx and reconcile against expected.", "stream": false}'
```

> Auth/connection errors without real Azure credentials are expected; the server
> still starts and accepts requests.

## Environment variables

| Variable | Purpose |
|----------|---------|
| `FOUNDRY_PROJECT_ENDPOINT` | Project endpoint. **Injected by Foundry in production** — set locally only. |
| `AZURE_AI_MODEL_DEPLOYMENT_NAME` | Model deployment backing the orchestrator (e.g. `gpt-4o`). |
| `COMMISSION_DATA_DIR` | Directory the agent resolves workbook names against (default `data`). |

## Deploy to Foundry

This project is already structured for the Foundry `deploy` workflow (it mirrors
the official `agent-framework/responses` sample: `agent.yaml`, `Dockerfile`,
port 8088, `ResponsesHostServer` as the default entrypoint). To deploy, say
**"deploy agent to foundry"** and the deploy sub-skill will containerize, push to
ACR, and create the hosted agent.

## Scale-up path (multi-agent)

Today this is one orchestrator over deterministic tools — lowest latency, easiest
to test. Because the engine and rule registry are isolated, promoting the steps to
connected sub-agents (Rule-Parser → Calculator → Validator → Explainer) is a
refactor, not a rewrite. Do that when multi-month aggregation, rep-level rollups,
or multiple concurrent rulesets arrive.
