"""Agent Framework function tools exposed to the hosted agent.

These are the *only* way the LLM touches commission logic. Each tool returns a
plain JSON-serializable dict so the model can reason over structured results and
cite the per-row trace when explaining a commission. No arithmetic happens in the
model -- it happens here, deterministically.

Workbook paths are resolved under COMMISSION_DATA_DIR (default: ./data) so the
agent only deals with file *names*, never absolute host paths.
"""

from __future__ import annotations

import os
from typing import Annotated, Optional

from pydantic import Field

from commission import (
    get_ruleset,
    list_versions,
    DEFAULT_VERSION,
    read_orders,
    write_results,
    calculate_batch,
    reconcile,
    GOLDEN_EXPECTED,
)

try:  # available inside the hosted agent runtime
    from agent_framework import tool
except Exception:  # pragma: no cover - allows importing tools without the SDK
    def tool(*args, **kwargs):
        def _wrap(fn):
            return fn
        if args and callable(args[0]):
            return args[0]
        return _wrap


DATA_DIR = os.environ.get("COMMISSION_DATA_DIR", "data")


def _resolve(workbook_name: str) -> str:
    if os.path.isabs(workbook_name):
        return workbook_name
    return os.path.join(DATA_DIR, workbook_name)


@tool(approval_mode="never_require")
def list_ruleset_versions() -> dict:
    """List available commission ruleset versions in the registry."""
    return {"versions": list_versions(), "default": DEFAULT_VERSION}


@tool(approval_mode="never_require")
def get_commission_ruleset(
    version: Annotated[str, Field(description="Ruleset version, e.g. 'v1'.")] = DEFAULT_VERSION,
) -> dict:
    """Return the structured commission ruleset (rate matrix, bands, R1-R4) for grounding and citation."""
    return get_ruleset(version).to_dict()


@tool(approval_mode="never_require")
def compute_commissions(
    workbook_name: Annotated[str, Field(description="Workbook file name under the data dir, e.g. 'Test_Workbook.xlsx'.")],
    version: Annotated[str, Field(description="Ruleset version to apply.")] = DEFAULT_VERSION,
    write_back: Annotated[bool, Field(description="If true, write GrossMargin/Tier/CommissionRate/CommissionAmount back into the workbook.")] = True,
) -> dict:
    """Deterministically compute commissions for every order in the workbook.

    Reads the input columns, applies the selected ruleset via the engine, and
    (optionally) writes the four computed columns back. Returns per-order results
    including a step-by-step rule trace the agent can use to explain each amount.
    """
    path = _resolve(workbook_name)
    ruleset = get_ruleset(version)
    orders = read_orders(path)
    results = calculate_batch(orders, ruleset)

    saved_path = None
    if write_back:
        saved_path = write_results(path, results)

    return {
        "workbook": path,
        "ruleset_version": version,
        "rows": len(results),
        "written_to": saved_path,
        "results": [
            {
                "order_id": r.order_id,
                "gross_margin": r.gross_margin,
                "tier": r.tier,
                "band": r.band,
                "base_rate": r.base_rate,
                "final_rate": r.final_rate,
                "commission_amount": r.commission_amount,
                "trace": r.trace,
            }
            for r in results
        ],
    }


@tool(approval_mode="never_require")
def reconcile_against_expected(
    workbook_name: Annotated[str, Field(description="Workbook file name under the data dir.")],
    version: Annotated[str, Field(description="Ruleset version to apply.")] = DEFAULT_VERSION,
) -> dict:
    """Compute commissions and reconcile them cell-by-cell against the doc's expected results.

    Returns a pass/mismatch report. Mismatches indicate the doc's hand-authored
    expected table diverges from the stated ruleset for that order.
    """
    path = _resolve(workbook_name)
    ruleset = get_ruleset(version)
    orders = read_orders(path)
    results = calculate_batch(orders, ruleset)
    report = reconcile(results, GOLDEN_EXPECTED)
    return report.to_dict()
