"""Deterministic commission calculation engine.

All arithmetic lives here -- the LLM never computes numbers, it only orchestrates
these calls and narrates the resulting trace. Given a raw order and a ``RuleSet``,
:func:`calculate_order` returns the gross margin, tier, final rate and commission
amount, plus a step-by-step ``trace`` listing exactly which matrix cell and which
override rules (R1-R4) fired. The trace is what the agent cites when explaining a
commission.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class OrderInput:
    order_id: str
    sales_rep: str
    order_type: str          # "Order" | "Recurring"
    order_value: float
    cogs: float
    discount_pct: float      # fraction, e.g. 0.10
    contract_months: int


@dataclass
class CommissionResult:
    order_id: str
    gross_margin: float
    tier: str
    band: str
    base_rate: float
    final_rate: float
    commission_amount: float
    trace: List[str] = field(default_factory=list)

    def rounded(self, rate_dp: int = 4, amount_dp: int = 2) -> "CommissionResult":
        return CommissionResult(
            order_id=self.order_id,
            gross_margin=round(self.gross_margin, 6),
            tier=self.tier,
            band=self.band,
            base_rate=round(self.base_rate, rate_dp),
            final_rate=round(self.final_rate, rate_dp),
            commission_amount=round(self.commission_amount, amount_dp),
            trace=self.trace,
        )


def _norm_order_type(value: str) -> str:
    v = (value or "").strip().lower()
    if v in ("recurring", "subscription"):
        return "Recurring"
    return "Order"


def calculate_order(order: OrderInput, ruleset) -> CommissionResult:
    """Compute a single order's commission deterministically against ``ruleset``."""
    trace: List[str] = []

    order_type = _norm_order_type(order.order_type)

    # --- Gross margin -------------------------------------------------------
    if order.order_value == 0:
        gross_margin = 0.0
    else:
        gross_margin = (order.order_value - order.cogs) / order.order_value
    trace.append(
        f"GrossMargin = (OrderValue - COGS) / OrderValue = "
        f"({order.order_value:,.0f} - {order.cogs:,.0f}) / {order.order_value:,.0f} "
        f"= {gross_margin:.4%}"
    )

    # --- Tier ---------------------------------------------------------------
    tier = "Large" if order.order_value >= ruleset.tier_threshold else "Small"
    trace.append(
        f"Tier = '{tier}' (OrderValue {order.order_value:,.0f} "
        f"{'>=' if tier == 'Large' else '<'} {ruleset.tier_threshold:,.0f})"
    )

    # --- Band + base rate from matrix --------------------------------------
    band = ruleset.band_for_margin(gross_margin)
    base_rate = ruleset.rate_matrix[(order_type, tier, band)]
    trace.append(
        f"Band = '{band}' -> matrix[{order_type}/{tier}/{band}] base rate = {base_rate:.2%}"
    )

    # --- R1: loss-leader zero-out ------------------------------------------
    if gross_margin < ruleset.loss_leader_gm_floor:
        trace.append(
            f"R1 fired: GM {gross_margin:.2%} < {ruleset.loss_leader_gm_floor:.0%} "
            f"-> commission rate forced to 0 (loss-leader)."
        )
        result = CommissionResult(
            order_id=order.order_id,
            gross_margin=gross_margin,
            tier=tier,
            band=band,
            base_rate=base_rate,
            final_rate=0.0,
            commission_amount=0.0,
            trace=trace,
        )
        return result.rounded()

    rate = base_rate

    # --- R2: recurring long-contract bonus ---------------------------------
    if order_type == "Recurring" and order.contract_months >= ruleset.recurring_bonus_min_months:
        rate += ruleset.recurring_bonus_rate
        trace.append(
            f"R2 fired: Recurring with ContractMonths {order.contract_months} "
            f">= {ruleset.recurring_bonus_min_months} -> +{ruleset.recurring_bonus_rate:.1%} "
            f"(rate now {rate:.3%})."
        )
    else:
        trace.append("R2 not applied.")

    # --- R3: high-discount penalty -----------------------------------------
    if order.discount_pct > ruleset.high_discount_threshold:
        rate -= ruleset.high_discount_penalty
        trace.append(
            f"R3 fired: DiscountPct {order.discount_pct:.0%} > "
            f"{ruleset.high_discount_threshold:.0%} -> -{ruleset.high_discount_penalty:.1%} "
            f"(rate now {rate:.3%})."
        )
    else:
        trace.append("R3 not applied.")

    # Floor at 0.
    final_rate = max(0.0, rate)
    if final_rate != rate:
        trace.append(f"Rate floored at 0 (was {rate:.3%}).")

    # --- R4: commission amount ---------------------------------------------
    commission_amount = order.order_value * final_rate
    trace.append(
        f"R4: CommissionAmount = OrderValue x FinalRate = "
        f"{order.order_value:,.0f} x {final_rate:.3%} = {commission_amount:,.2f}"
    )

    result = CommissionResult(
        order_id=order.order_id,
        gross_margin=gross_margin,
        tier=tier,
        band=band,
        base_rate=base_rate,
        final_rate=final_rate,
        commission_amount=commission_amount,
        trace=trace,
    )
    return result.rounded()


def calculate_batch(orders: List[OrderInput], ruleset) -> List[CommissionResult]:
    return [calculate_order(o, ruleset) for o in orders]
