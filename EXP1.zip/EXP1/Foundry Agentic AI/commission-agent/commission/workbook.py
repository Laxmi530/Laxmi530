"""Excel workbook I/O for the commission agent.

Reads the input columns (OrderID, SalesRep, OrderType, OrderValue, COGS,
DiscountPct, ContractMonths) and writes the four computed columns back
(GrossMargin, Tier, CommissionRate, CommissionAmount). Columns are matched by
header name in row 1, not by fixed position, so the layout can vary.
"""

from __future__ import annotations

from typing import List, Optional

import openpyxl

from .engine import OrderInput, CommissionResult


INPUT_HEADERS = {
    "order_id": "OrderID",
    "sales_rep": "SalesRep",
    "order_type": "OrderType",
    "order_value": "OrderValue",
    "cogs": "COGS",
    "discount_pct": "DiscountPct",
    "contract_months": "ContractMonths",
}

OUTPUT_HEADERS = {
    "gross_margin": "GrossMargin",
    "tier": "Tier",
    "commission_rate": "CommissionRate",
    "commission_amount": "CommissionAmount",
}


def _header_map(ws) -> dict:
    """Map header text -> 1-based column index from row 1."""
    mapping = {}
    for col in range(1, ws.max_column + 1):
        val = ws.cell(row=1, column=col).value
        if val is not None and str(val).strip():
            mapping[str(val).strip()] = col
    return mapping


def read_orders(path: str, sheet: Optional[str] = None) -> List[OrderInput]:
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet] if sheet else wb.active
    headers = _header_map(ws)

    missing = [h for h in INPUT_HEADERS.values() if h not in headers]
    if missing:
        raise ValueError(f"Workbook is missing required input columns: {missing}")

    orders: List[OrderInput] = []
    for row in range(2, ws.max_row + 1):
        oid = ws.cell(row=row, column=headers["OrderID"]).value
        if oid is None or str(oid).strip() == "":
            continue
        orders.append(
            OrderInput(
                order_id=str(oid).strip(),
                sales_rep=str(ws.cell(row=row, column=headers["SalesRep"]).value or "").strip(),
                order_type=str(ws.cell(row=row, column=headers["OrderType"]).value or "").strip(),
                order_value=float(ws.cell(row=row, column=headers["OrderValue"]).value or 0),
                cogs=float(ws.cell(row=row, column=headers["COGS"]).value or 0),
                discount_pct=float(ws.cell(row=row, column=headers["DiscountPct"]).value or 0),
                contract_months=int(ws.cell(row=row, column=headers["ContractMonths"]).value or 0),
            )
        )
    return orders


def write_results(
    path: str,
    results: List[CommissionResult],
    sheet: Optional[str] = None,
    out_path: Optional[str] = None,
) -> str:
    """Write computed columns back next to each OrderID. Returns the saved path.

    Missing output-header columns are created to the right of existing data.
    """
    wb = openpyxl.load_workbook(path)
    ws = wb[sheet] if sheet else wb.active
    headers = _header_map(ws)

    # Ensure output columns exist; create any that are missing.
    next_col = ws.max_column + 1
    for header in OUTPUT_HEADERS.values():
        if header not in headers:
            ws.cell(row=1, column=next_col, value=header)
            headers[header] = next_col
            next_col += 1

    # Index existing rows by OrderID.
    oid_col = headers["OrderID"]
    row_by_oid = {}
    for row in range(2, ws.max_row + 1):
        oid = ws.cell(row=row, column=oid_col).value
        if oid is not None and str(oid).strip():
            row_by_oid[str(oid).strip()] = row

    for r in results:
        row = row_by_oid.get(r.order_id)
        if row is None:
            continue
        gm = ws.cell(row=row, column=headers["GrossMargin"], value=r.gross_margin)
        gm.number_format = "0.00%"
        ws.cell(row=row, column=headers["Tier"], value=r.tier)
        rate = ws.cell(row=row, column=headers["CommissionRate"], value=r.final_rate)
        rate.number_format = "0.000%"
        amt = ws.cell(row=row, column=headers["CommissionAmount"], value=r.commission_amount)
        amt.number_format = "#,##0.00"

    saved = out_path or path
    wb.save(saved)
    return saved
