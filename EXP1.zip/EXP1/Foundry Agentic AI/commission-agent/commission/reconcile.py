"""Reconcile engine output against an expected (golden) table cell-by-cell.

Implements test scenario #4 from the spec. The engine (which faithfully applies
the ruleset / Excel formulas) is treated as the source of truth; the golden table
is the doc's hand-authored expected values. Any divergence is reported so a human
can decide whether the engine or the doc is wrong.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .engine import CommissionResult


@dataclass
class RowDiff:
    order_id: str
    field: str
    computed: float | str
    expected: float | str

    def __str__(self) -> str:
        return (
            f"{self.order_id}.{self.field}: computed={self.computed} "
            f"expected={self.expected}"
        )


@dataclass
class ReconcileReport:
    total: int = 0
    passed: int = 0
    diffs: List[RowDiff] = field(default_factory=list)
    missing_expected: List[str] = field(default_factory=list)

    @property
    def failed(self) -> int:
        return len({d.order_id for d in self.diffs})

    def summary(self) -> str:
        status = "PASS" if not self.diffs else "MISMATCH"
        lines = [
            f"Reconciliation: {status} | rows={self.total} "
            f"passed={self.passed} mismatched={self.failed}"
        ]
        for d in self.diffs:
            lines.append(f"  - {d}")
        if self.missing_expected:
            lines.append(f"  (no expected entry for: {', '.join(self.missing_expected)})")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "status": "pass" if not self.diffs else "mismatch",
            "total": self.total,
            "passed": self.passed,
            "mismatched": self.failed,
            "diffs": [vars(d) for d in self.diffs],
            "missing_expected": self.missing_expected,
        }


def reconcile(
    results: List[CommissionResult],
    expected: Dict[str, dict],
    rate_tol: float = 1e-4,
    amount_tol: float = 0.01,
) -> ReconcileReport:
    report = ReconcileReport(total=len(results))
    for r in results:
        exp = expected.get(r.order_id)
        if exp is None:
            report.missing_expected.append(r.order_id)
            continue

        row_ok = True
        if exp.get("tier") is not None and r.tier != exp["tier"]:
            report.diffs.append(RowDiff(r.order_id, "tier", r.tier, exp["tier"]))
            row_ok = False
        if exp.get("rate") is not None and abs(r.final_rate - exp["rate"]) > rate_tol:
            report.diffs.append(RowDiff(r.order_id, "rate", r.final_rate, exp["rate"]))
            row_ok = False
        if exp.get("amount") is not None and abs(r.commission_amount - exp["amount"]) > amount_tol:
            report.diffs.append(
                RowDiff(r.order_id, "amount", r.commission_amount, exp["amount"])
            )
            row_ok = False

        if row_ok:
            report.passed += 1

    return report
