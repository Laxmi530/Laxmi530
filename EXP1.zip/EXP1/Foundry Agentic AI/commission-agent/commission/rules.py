"""Versioned commission rule registry.

This is the single source of truth for commission logic. Rules are encoded as
structured, versioned config (not magic numbers buried in code, and not parsed
live from prose by the LLM). To onboard a new ruleset, add a new ``RuleSet``
version here and reference it by ``version`` -- the deterministic engine and the
agent stay unchanged.

The structure mirrors the spec in ``Test_Doc.docx``:
  * a rate matrix keyed by (order_type, tier, gross_margin_band)
  * gross-margin band thresholds
  * the tier threshold
  * the additional override rules R1-R4
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, Tuple


# Band labels used as the third key of the rate matrix.
BAND_LOW = "low"      # GM < low_max
BAND_MEDIUM = "medium"  # low_max <= GM <= medium_max
BAND_HIGH = "high"    # GM > medium_max


@dataclass(frozen=True)
class RuleSet:
    """A single, immutable, versioned commission ruleset."""

    version: str
    description: str

    # Tier: Large if order_value >= tier_threshold else Small.
    tier_threshold: float

    # Gross-margin band boundaries (as fractions, e.g. 0.20 == 20%).
    band_low_max: float      # GM strictly below this -> low band
    band_medium_max: float   # GM at or below this (and >= band_low_max) -> medium; above -> high

    # Rate matrix: (order_type, tier, band) -> base rate (fraction).
    rate_matrix: Dict[Tuple[str, str, str], float]

    # R1: loss-leader rule -> zero the commission when GM is below this.
    loss_leader_gm_floor: float

    # R2: recurring long-contract bonus.
    recurring_bonus_min_months: int
    recurring_bonus_rate: float

    # R3: high-discount penalty.
    high_discount_threshold: float
    high_discount_penalty: float

    def band_for_margin(self, gross_margin: float) -> str:
        """Map a gross-margin fraction to a band label.

        Mirrors the IFS order in the spec: ``< low_max`` -> low,
        ``<= medium_max`` -> medium, otherwise high. The medium band is
        inclusive of its upper bound (GM == medium_max is medium).
        """
        if gross_margin < self.band_low_max:
            return BAND_LOW
        if gross_margin <= self.band_medium_max:
            return BAND_MEDIUM
        return BAND_HIGH

    def to_dict(self) -> dict:
        """JSON-serializable view (stringifies the tuple matrix keys)."""
        d = asdict(self)
        d["rate_matrix"] = {
            "|".join(k): v for k, v in self.rate_matrix.items()
        }
        return d


# --- v1: the ruleset transcribed from Test_Doc.docx ------------------------- #

COMMISSION_RULES_V1 = RuleSet(
    version="v1",
    description="Sandbox commission ruleset transcribed from Test_Doc.docx.",
    tier_threshold=50_000.0,
    band_low_max=0.20,
    band_medium_max=0.40,
    rate_matrix={
        ("Order", "Large", BAND_LOW): 0.020,
        ("Order", "Large", BAND_MEDIUM): 0.040,
        ("Order", "Large", BAND_HIGH): 0.060,
        ("Order", "Small", BAND_LOW): 0.010,
        ("Order", "Small", BAND_MEDIUM): 0.025,
        ("Order", "Small", BAND_HIGH): 0.045,
        ("Recurring", "Large", BAND_LOW): 0.035,
        ("Recurring", "Large", BAND_MEDIUM): 0.060,
        ("Recurring", "Large", BAND_HIGH): 0.090,
        ("Recurring", "Small", BAND_LOW): 0.020,
        ("Recurring", "Small", BAND_MEDIUM): 0.040,
        ("Recurring", "Small", BAND_HIGH): 0.070,
    },
    loss_leader_gm_floor=0.10,          # R1
    recurring_bonus_min_months=24,      # R2
    recurring_bonus_rate=0.005,         # R2
    high_discount_threshold=0.25,       # R3
    high_discount_penalty=0.010,        # R3
)


_REGISTRY: Dict[str, RuleSet] = {
    COMMISSION_RULES_V1.version: COMMISSION_RULES_V1,
}

DEFAULT_VERSION = "v1"


def get_ruleset(version: str = DEFAULT_VERSION) -> RuleSet:
    """Return a registered ruleset by version, or raise ``KeyError``."""
    if version not in _REGISTRY:
        raise KeyError(
            f"Unknown ruleset version '{version}'. "
            f"Available: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[version]


def list_versions() -> list[str]:
    return sorted(_REGISTRY)
