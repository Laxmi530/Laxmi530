"""Deterministic commission domain package.

The agent (LLM) orchestrates and explains; this package owns all rules and math.
"""

from .rules import get_ruleset, list_versions, DEFAULT_VERSION
from .engine import OrderInput, CommissionResult, calculate_order, calculate_batch
from .workbook import read_orders, write_results
from .reconcile import reconcile, ReconcileReport
from .golden import GOLDEN_EXPECTED

__all__ = [
    "get_ruleset",
    "list_versions",
    "DEFAULT_VERSION",
    "OrderInput",
    "CommissionResult",
    "calculate_order",
    "calculate_batch",
    "read_orders",
    "write_results",
    "reconcile",
    "ReconcileReport",
    "GOLDEN_EXPECTED",
]
