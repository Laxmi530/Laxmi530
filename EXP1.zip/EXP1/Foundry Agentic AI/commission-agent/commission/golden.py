"""Expected results table transcribed from the 'EXPECTED RESULTS' section of
Test_Doc.docx. Used by the reconciler to validate engine output cell-by-cell.

Each entry: order_id -> (tier, final_rate, commission_amount).
Gross margin is informational in the doc and recomputed by the engine.
"""

GOLDEN_EXPECTED = {
    "ORD001": {"tier": "Large", "rate": 0.040, "amount": 3000.00},
    "ORD002": {"tier": "Small", "rate": 0.025, "amount": 300.00},
    "ORD003": {"tier": "Large", "rate": 0.095, "amount": 5700.00},
    "ORD004": {"tier": "Small", "rate": 0.030, "amount": 240.00},
    "ORD005": {"tier": "Large", "rate": 0.010, "amount": 950.00},
    "ORD006": {"tier": "Large", "rate": 0.095, "amount": 4275.00},
    "ORD007": {"tier": "Small", "rate": 0.045, "amount": 1350.00},
    "ORD008": {"tier": "Large", "rate": 0.020, "amount": 2200.00},
    "ORD009": {"tier": "Small", "rate": 0.065, "amount": 1625.00},
    "ORD010": {"tier": "Small", "rate": 0.000, "amount": 0.00},
    "ORD011": {"tier": "Large", "rate": 0.095, "amount": 7600.00},
    "ORD012": {"tier": "Small", "rate": 0.045, "amount": 1800.00},
    "ORD013": {"tier": "Small", "rate": 0.070, "amount": 1050.00},
    "ORD014": {"tier": "Large", "rate": 0.030, "amount": 1950.00},
    "ORD015": {"tier": "Small", "rate": 0.045, "amount": 337.50},
}
