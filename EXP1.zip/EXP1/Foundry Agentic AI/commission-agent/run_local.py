"""Deterministic end-to-end pipeline WITHOUT the LLM / Foundry.

This proves the commission core is correct independently of the agent runtime.
It reads the workbook, computes all rows via the engine, writes a filled copy,
and reconciles against the doc's expected table -- printing any divergences.

Usage:
    python run_local.py [workbook_path]
"""

import sys

from commission import (
    get_ruleset,
    read_orders,
    write_results,
    calculate_batch,
    reconcile,
    GOLDEN_EXPECTED,
)


def main(path: str = "data/Test_Workbook.xlsx") -> int:
    ruleset = get_ruleset("v1")
    orders = read_orders(path)
    results = calculate_batch(orders, ruleset)

    print(f"Computed {len(results)} orders using ruleset {ruleset.version}\n")
    header = f"{'OrderID':<8}{'Tier':<7}{'GM':>9}{'Band':>8}{'Rate':>9}{'Commission':>14}"
    print(header)
    print("-" * len(header))
    for r in results:
        print(
            f"{r.order_id:<8}{r.tier:<7}{r.gross_margin*100:>8.2f}%"
            f"{r.band:>8}{r.final_rate*100:>8.2f}%{r.commission_amount:>14,.2f}"
        )

    out = write_results(path, results, out_path=path.replace(".xlsx", "_filled.xlsx"))
    print(f"\nWrote filled workbook -> {out}")

    report = reconcile(results, GOLDEN_EXPECTED)
    print("\n" + report.summary())

    if report.diffs:
        print("\nDivergence detail (engine applies the stated ruleset/formulas):")
        for r in results:
            if r.order_id in {d.order_id for d in report.diffs}:
                print(f"\n[{r.order_id}] trace:")
                for line in r.trace:
                    print(f"    - {line}")
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:]))
