# Learning Agentic AI with Microsoft Agent Framework (MAF) + Foundry

A progressive, hands-on guide. Each lesson has runnable code and a "try this" exercise.
Paced for someone who already understands agents, tools, and orchestration (e.g. from LangChain/LangGraph).

---

## ⚠️ Read this first: version churn

The Python package was reorganized around **v1.2**. Names that changed:

- `AzureOpenAIChatClient` (old) → use `OpenAIChatClient` from `agent_framework.openai` with Azure routing inputs
- `@ai_function` (old) → **`@tool`**
- `MagenticBuilder` moved from `agent_framework` → **`agent_framework.orchestrations`**
- `create_agent(...)` → **`.as_agent(...)`**

Pin your version and ignore older blog samples that mix these:

```bash
pip show agent-framework        # check what you actually have
```

Two ways to build the same agent (use either; they're equivalent):

```python
agent = client.as_agent(name="X", instructions="...")          # convenience form
# is the same as
from agent_framework import ChatAgent
agent = ChatAgent(chat_client=client, name="X", instructions="...")  # explicit form
```

---

## Lesson 0 — Setup

```bash
pip install agent-framework-openai      # OpenAI + Azure OpenAI providers
pip install mcp --pre                   # needed for MCP tools (Lesson 4)
# optional extras you'll want later:
pip install agent-framework             # full meta-package (Foundry, workflows, etc.)
```

Environment variables:

```bash
# --- OpenAI ---
export OPENAI_API_KEY="sk-..."
export OPENAI_CHAT_MODEL="gpt-4o-mini"

# --- Azure OpenAI ---
export AZURE_OPENAI_ENDPOINT="https://<resource>.openai.azure.com"
export AZURE_OPENAI_CHAT_MODEL="gpt-4o-mini"   # = your DEPLOYMENT name, not the base model
export AZURE_OPENAI_API_VERSION="2024-10-21"
az login                                        # for credential-based Azure auth
```

> Gotcha: if `OPENAI_API_KEY` is set, the generic clients stay on OpenAI even when
> `AZURE_OPENAI_*` vars exist. Passing an explicit Azure input (`azure_endpoint`/`credential`)
> forces Azure routing.

---

## Lesson 1 — Your first agent (OpenAI and Azure)

Two client classes:
- `OpenAIChatClient` → Responses API (richest hosted-tool support) — your default
- `OpenAIChatCompletionClient` → Chat Completions API (simplest, broadest model support)

**OpenAI:**

```python
import asyncio
from agent_framework.openai import OpenAIChatClient

async def main():
    agent = OpenAIChatClient(model="gpt-4o-mini").as_agent(
        name="Assistant",
        instructions="You are a helpful assistant. Be concise.",
    )
    result = await agent.run("Explain agentic AI in two sentences.")
    print(result)

asyncio.run(main())
```

**Azure OpenAI** — same client class, Azure routing inputs added:

```python
import asyncio, os
from agent_framework.openai import OpenAIChatClient
from azure.identity import AzureCliCredential

async def main():
    client = OpenAIChatClient(
        model=os.environ["AZURE_OPENAI_CHAT_MODEL"],       # deployment name
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        credential=AzureCliCredential(),                    # or api_key="..."
    )
    agent = client.as_agent(name="Assistant", instructions="You are helpful.")
    print(await agent.run("Hello from Azure!"))

asyncio.run(main())
```

**Try this:** swap `gpt-4o-mini` for another deployment; add `stream=True` to `agent.run(...)`
and iterate over chunks (`async for chunk in ...: print(chunk.text, end="")`).

---

## Lesson 2 — Add a tool

`@tool` turns a plain function into a tool. The docstring + type hints become the schema
the model sees (same idea as LangChain's `@tool`). The framework runs the call loop for you.

```python
import asyncio
from agent_framework import tool
from agent_framework.openai import OpenAIChatClient

@tool
def get_weather(location: str) -> str:
    """Get the current weather for a given location."""
    return f"The weather in {location} is sunny, 25°C."

@tool
def convert_currency(amount: float, from_ccy: str, to_ccy: str) -> str:
    """Convert an amount between two currencies (toy fixed rate)."""
    return f"{amount} {from_ccy} = {amount * 1.1:.2f} {to_ccy}"

async def main():
    agent = OpenAIChatClient(model="gpt-4o-mini").as_agent(
        name="Helper",
        instructions="Use tools when needed. Don't guess values you can look up.",
        tools=[get_weather, convert_currency],
    )
    print(await agent.run("What's the weather in Tokyo, and what's 100 USD in EUR?"))

asyncio.run(main())
```

**Try this:** add `@tool(approval_mode="always_require")` to one tool to force a human
approval step before it runs (Lesson 8 covers HITL properly).

---

## Lesson 3 — Memory with sessions

A session carries conversation state across `.run()` calls.

```python
import asyncio
from agent_framework.openai import OpenAIChatClient

async def main():
    agent = OpenAIChatClient(model="gpt-4o-mini").as_agent(
        name="Assistant", instructions="You are helpful."
    )
    session = await agent.create_session()

    print(await agent.run("My name is Alice and I love hiking.", session=session))
    print(await agent.run("Suggest a weekend activity for me.", session=session))  # remembers

asyncio.run(main())
```

**Try this:** run the second message *without* the session and watch it forget. For durable,
cross-process memory, look up **context providers** (MAF's pluggable memory layer).

---

## Lesson 4 — MCP tools (high value)

MAF treats any MCP server as a tool source. Two transports you'll use most:
`MCPStdioTool` (local process) and `MCPStreamableHTTPTool` (remote HTTP/SSE).

```python
import asyncio
from agent_framework import ChatAgent, MCPStdioTool
from agent_framework.openai import OpenAIChatClient

async def main():
    client = OpenAIChatClient(model="gpt-4o-mini")

    # Launches a local MCP server process; tools are auto-discovered.
    async with MCPStdioTool(
        name="filesystem",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        description="File system operations",
    ) as fs_tool:
        agent = ChatAgent(chat_client=client, name="FileAgent", tools=fs_tool)
        print(await agent.run("List the files in /tmp and summarize what you find."))

asyncio.run(main())
```

Remote HTTP MCP server:

```python
from agent_framework import ChatAgent, MCPStreamableHTTPTool

async with MCPStreamableHTTPTool(
    name="web-api",
    url="https://api.example.com/mcp",
    headers={"Authorization": "Bearer <token>"},
) as mcp_tool:
    agent = ChatAgent(chat_client=client, name="ApiAgent", tools=mcp_tool)
    print(await agent.run("Fetch the latest record."))
```

> ⚠️ **The #1 MCP gotcha:** keep the tool alive inside its `async with` block for as long as
> the agent runs. Exit too early and you get
> `MCP server not connected, please call connect() before using this method`.

**Try this:** point `MCPStdioTool` at a different server (e.g. `mcp/duckduckgo` via Docker)
and combine two MCP tools by passing `tools=[tool_a, tool_b]`.

---

## Lesson 5 — Grounding / RAG (concept + where it lives)

A useful agent answers from *your* data. On Foundry the standard knowledge tools are:
- **Azure AI Search** — vector RAG over your documents
- **Bing grounding** — live web results, source-cited

With the Responses client you also get hosted tools created via `client.get_*_tool()`:

```python
client = OpenAIChatClient(model="gpt-4o-mini")
code = client.get_code_interpreter_tool()
web  = client.get_web_search_tool()
files = client.get_file_search_tool(vector_store_ids=["vs_abc123"])  # your indexed docs

agent = client.as_agent(
    name="Researcher",
    instructions="Use search and files to answer with sources.",
    tools=[code, web, files],
)
```

**Try this:** create a vector store of a few PDFs, pass its id to `get_file_search_tool`,
and ask a question only your docs can answer.

---

## Lesson 6 — Multi-agent, deterministic (sequential & parallel)

Before reaching for an LLM orchestrator, use a **graph workflow** when the topology is fixed.
This is your LangGraph equivalent. Agents are auto-wrapped as executors.

**Sequential** (writer → reviewer):

```python
import asyncio
from agent_framework import WorkflowBuilder
from agent_framework.openai import OpenAIChatClient

client = OpenAIChatClient(model="gpt-4o-mini")
writer   = client.as_agent(name="Writer",   instructions="Draft a short paragraph.")
reviewer = client.as_agent(name="Reviewer", instructions="Tighten and fix the draft.")

async def main():
    workflow = (
        WorkflowBuilder(start_executor=writer)
        .add_edge(writer, reviewer)      # writer's output flows into reviewer
        .build()
    )
    events = await workflow.run("Write about why observability matters for agents.")
    print(events.get_outputs())

asyncio.run(main())
```

**Conditional routing** (branch on content) — e.g. spam vs. normal:

```python
workflow = (
    WorkflowBuilder(start_executor=classifier)
    .add_edge(classifier, normal_handler, condition=lambda r: not r.is_spam)
    .add_edge(classifier, spam_handler,   condition=lambda r: r.is_spam)
    .build()
)
```

**Parallel fan-out / fan-in** — run specialists concurrently, then aggregate:

```python
workflow = (
    WorkflowBuilder(start_executor=splitter)
    .add_edge(splitter, researcher)
    .add_edge(splitter, budget_analyst)
    .add_edge(splitter, activities_curator)
    .add_fan_in_edge([researcher, budget_analyst, activities_curator], aggregator)
    .build()
)
```

> There are also higher-level `Sequential`/`Concurrent` builders in
> `agent_framework.orchestrations` — verify the exact names against your installed version.

**Try this:** add a third agent (a fact-checker) between writer and reviewer.

---

## Lesson 7 — Multi-agent with an LLM orchestrator (Magentic)

When the plan should be decided *by a model* (dynamic planning, agent selection, replanning),
use **Magentic** (Magentic-One design). Closest analog: a LangGraph supervisor / CrewAI
hierarchical process.

```python
import asyncio
from agent_framework.openai import OpenAIChatClient
from agent_framework.orchestrations import MagenticBuilder

client = OpenAIChatClient(model="gpt-4o-mini")
researcher = client.as_agent(name="Researcher", instructions="Find and summarize facts.")
writer     = client.as_agent(name="Writer",     instructions="Turn notes into prose.")

async def main():
    workflow = (
        MagenticBuilder()
        .participants(researcher=researcher, writer=writer)
        .with_standard_manager(          # the manager's own LLM, for planning
            chat_client=client,
            max_round_count=10,
            max_stall_count=3,
        )
        .with_plan_review(enable=True)   # optional: approve the plan before it runs (HITL)
        .build()
    )
    async for event in workflow.run(
        "Research agentic AI benefits and write a short article.", stream=True
    ):
        print(event)

asyncio.run(main())
```

> ⚠️ The orchestration builder API churns most. Some versions use the fluent
> `.participants(...).with_standard_manager(...)` form above; others use a constructor form:
> `MagenticBuilder(participants=[...], manager_agent=manager, max_round_count=10).build()`.
> If one errors, check `agent_framework.orchestrations` in your installed version and the
> canonical sample:
> https://github.com/microsoft/agent-framework/tree/main/python/samples/getting_started/workflows/orchestration

**Rule of thumb:** fixed pipeline → Lesson 6 graph. Open-ended task needing planning → Magentic.

---

## Lesson 8 — Human-in-the-loop & tool approval

Two layers of control:

1. **Tool approval** — gate individual tool calls:
   ```python
   @tool(approval_mode="always_require")
   def delete_record(record_id: str) -> str:
       """Permanently delete a record."""
       ...
   ```
2. **Plan review** (Magentic) — `.with_plan_review(enable=True)` lets a human APPROVE / REVISE /
   REPLAN before execution; `.with_human_input_on_stall()` intervenes if the team gets stuck.

**Try this:** wrap an action tool with approval and observe the request the framework surfaces
before the tool fires.

---

## Lesson 9 — Observability (don't skip)

Coming from LangSmith, you'll feel the absence immediately. MAF gives you:
- **DevUI** — local visual tracing of the orchestration graph, agent turns, and streaming.
- **OpenTelemetry traces** — exportable to your APM.
- **Evaluations** — to score agent/workflow outputs over time.

This is *non-negotiable* for multi-agent systems — it's how you find which agent stalled or
why a workflow looped. Set this up early, not after things break. Check the docs for the
current DevUI launch command for your version (`agent-framework-devui`).

---

## Lesson 10 — From local SDK to Foundry (the platform step)

Everything above is the SDK running locally. "Foundry" proper = the **managed runtime** that
hosts your agents with built-in tools, state, and observability. The same agent code deploys
as a **hosted agent**.

```python
import asyncio
from agent_framework import ChatAgent
from agent_framework.azure import AzureAIAgentClient
from azure.identity.aio import AzureCliCredential

async def main():
    async with AzureCliCredential() as credential:
        agent = ChatAgent(
            chat_client=AzureAIAgentClient(async_credential=credential),
            name="FoundryAgent",
            instructions="You are a helpful assistant hosted on Foundry.",
        )
        print(await agent.run("Hello from a Foundry-hosted agent!"))

asyncio.run(main())
```

Env for a Foundry project:

```bash
export AZURE_AI_PROJECT_ENDPOINT="https://<resource>.services.ai.azure.com/api/projects/<project>"
export AZURE_AI_MODEL_DEPLOYMENT_NAME="gpt-4o"
```

> **Credential shift:** `AzureCliCredential` is fine locally, but in production use a specific
> credential like **ManagedIdentityCredential** — `DefaultAzureCredential` everywhere causes
> latency and unintended credential probing. This is the single most common production mistake.

Once hosted, you build with Foundry's own knowledge tools (Azure AI Search, Bing, SharePoint,
Fabric) and action tools (Logic Apps, Azure Functions), and the platform handles state,
governance, and observability. Check the Microsoft Foundry provider docs for the current
deploy CLI.

---

## Suggested learning order (1–2 weeks, part-time)

1. Lessons 0–3 in one sitting (you already know the concepts).
2. **Lesson 4 (MCP)** — highest leverage given your background.
3. **Lesson 6 (graph workflows)** — your real LangGraph equivalent.
4. Lesson 7 (Magentic) once you've felt the deterministic version.
5. Lessons 8–9 (HITL + observability) before any real build.
6. **Lesson 10 (Foundry deploy)** — crossing from SDK to platform.

## Key references

- GitHub (samples + source of truth): https://github.com/microsoft/agent-framework
- Python samples, in order: https://github.com/microsoft/agent-framework/tree/main/python/samples
- Microsoft Learn — Agent Framework: https://learn.microsoft.com/en-us/agent-framework/
- Foundry Agent Service docs: https://learn.microsoft.com/en-us/azure/ai-foundry/agents/overview

> Because the API is moving fast, when a snippet errors: (1) `pip show agent-framework` to confirm
> your version, (2) check the matching sample in the GitHub repo, (3) prefer the official Learn
> page over blog posts.
