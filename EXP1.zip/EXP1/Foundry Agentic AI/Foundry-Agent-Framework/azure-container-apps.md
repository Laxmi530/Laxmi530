# Deploy to Azure Container Apps (self-hosted option)

Container Apps is the sweet spot for this workload: scale-to-zero, revisions,
managed identity, and no Kubernetes to operate.

## 1. Build & push the image
```bash
az acr build \
  --registry <yourRegistry> \
  --image multi-agent-foundry:$(git rev-parse --short HEAD) .
```

## 2. Create the app with a user-assigned managed identity
```bash
# Create the identity once
az identity create -g <rg> -n maf-identity
CLIENT_ID=$(az identity show -g <rg> -n maf-identity --query clientId -o tsv)
PRINCIPAL_ID=$(az identity show -g <rg> -n maf-identity --query principalId -o tsv)

# Grant it access to the Foundry project (Azure AI User role)
az role assignment create \
  --assignee-object-id $PRINCIPAL_ID --assignee-principal-type ServicePrincipal \
  --role "Azure AI User" \
  --scope <foundry-project-resource-id>

az containerapp create \
  -g <rg> -n multi-agent-foundry \
  --environment <capEnv> \
  --image <yourRegistry>.azurecr.io/multi-agent-foundry:<tag> \
  --user-assigned maf-identity \
  --ingress external --target-port 8000 \
  --min-replicas 1 --max-replicas 10 \
  --env-vars \
    AZURE_CLIENT_ID=$CLIENT_ID \
    FOUNDRY_PROJECT_ENDPOINT=<endpoint> \
    FOUNDRY_MODEL=<deployment-name> \
    APPLICATIONINSIGHTS_CONNECTION_STRING=secretref:appinsights \
    TAVILY_API_KEY=secretref:tavily
```

## 3. Secrets (never as plain env vars)
```bash
az containerapp secret set -g <rg> -n multi-agent-foundry \
  --secrets tavily=<key> appinsights="<connstr>"
```

## 4. Autoscale on concurrency (LLM calls are IO-bound)
```bash
az containerapp update -g <rg> -n multi-agent-foundry \
  --scale-rule-name http-concurrency --scale-rule-type http \
  --scale-rule-http-concurrency 20
```

Health probes: point liveness at `/healthz` and readiness at `/readyz`.

Notes
- No API keys in the image: the managed identity authenticates to Foundry.
- Pin the image to the git SHA so rollbacks are a one-command revision swap.
- For Kubernetes/AKS the same image works; use Workload Identity instead of
  the Container Apps managed identity binding.
