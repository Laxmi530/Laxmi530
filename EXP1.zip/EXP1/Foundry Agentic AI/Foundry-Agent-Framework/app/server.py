"""FastAPI server — the production surface.

Endpoints:
  GET  /healthz        liveness
  GET  /readyz         readiness
  GET  /memory         inspect stored memory
  POST /memory/clear   clear memory (also DELETE /memory)
  POST /upload         upload a document for the DocumentAgent to read
  POST /chat           run a task, return the final answer
  POST /chat/stream    Server-Sent Events stream
"""

from __future__ import annotations

import json
import logging
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

logger = logging.getLogger(__name__)

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .config import get_settings
from .observability import configure_observability
from .orchestrator import MultiAgentSystem

# File types the DocumentAgent's read_document tool can parse.
_ALLOWED_UPLOAD_SUFFIXES = {".pdf", ".docx", ".txt", ".md", ".log", ".xlsx", ".xls", ".csv"}

_system: MultiAgentSystem | None = None


def _require_system() -> MultiAgentSystem:
    """Return the initialised system, or 503 if startup hasn't completed.

    An explicit check (not `assert`) so it survives `python -O` and returns a
    clear status instead of an opaque 500.
    """
    if _system is None:
        raise HTTPException(status_code=503, detail="Service starting; not ready yet.")
    return _system


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _system
    configure_observability()
    _system = MultiAgentSystem.create()
    yield
    _system = None


app = FastAPI(title="Multi-Agent Foundry", version="0.1.0", lifespan=lifespan)


class ChatRequest(BaseModel):
    task: str


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/readyz")
async def readyz() -> dict[str, str]:
    return {"status": "ready" if _system is not None else "starting"}


@app.get("/memory")
async def get_memory_state() -> dict[str, object]:
    """Inspect what the agent team currently remembers."""
    system = _require_system()
    if system.memory is None:
        return {"enabled": False, "facts": [], "recent_tasks": []}
    return {"enabled": True, **system.memory.snapshot()}


def _clear_memory() -> dict[str, object]:
    """Forget everything and return the (now-empty) state.

    Clearing only empties the store; the same store keeps working afterwards, so
    new questions are remembered again immediately — no restart needed.
    """
    system = _require_system()
    if system.memory is None:
        return {"status": "cleared", "enabled": False, "facts": [], "recent_tasks": []}
    system.memory.clear()
    return {"status": "cleared", "enabled": True, **system.memory.snapshot()}


@app.post("/memory/clear")
async def clear_memory_post() -> dict[str, object]:
    """Clear memory (easy to hit from a browser / curl / the UI)."""
    return _clear_memory()


@app.delete("/memory")
async def clear_memory_delete() -> dict[str, object]:
    """Clear memory (RESTful variant; same effect as POST /memory/clear)."""
    return _clear_memory()


@app.post("/upload")
async def upload_document(file: UploadFile = File(...)) -> dict[str, str]:
    """Save an uploaded document and return the server path the DocumentAgent reads.

    The agent runs in this process, so a server-side path is exactly what it
    needs. Files land in ``UPLOAD_DIR`` under a unique name to avoid collisions.
    """
    _require_system()
    settings = get_settings()

    original = Path(file.filename or "upload").name  # strip any client path
    suffix = Path(original).suffix.lower()
    if suffix not in _ALLOWED_UPLOAD_SUFFIXES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix}'. Allowed: "
            + ", ".join(sorted(_ALLOWED_UPLOAD_SUFFIXES)),
        )

    data = await file.read()
    max_bytes = settings.upload_max_mb * 1024 * 1024
    if len(data) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.upload_max_mb} MB limit.")

    upload_dir = Path(settings.upload_dir)
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / f"{uuid.uuid4().hex}_{original}"
    dest.write_bytes(data)
    logger.info("Uploaded %s -> %s (%d bytes)", original, dest, len(data))
    return {"filename": original, "path": str(dest.resolve())}


@app.post("/chat")
async def chat(req: ChatRequest) -> dict[str, str]:
    system = _require_system()
    try:
        answer = await system.run(req.task)
        return {"answer": answer}
    except Exception as exc:
        logger.exception("Error in /chat")
        return {"answer": f"Error: {exc}"}


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest) -> StreamingResponse:
    system = _require_system()
    logger.info("POST /chat/stream task=%r", req.task[:80])

    async def event_gen():
        try:
            logger.info("Starting stream for task...")
            async for executor_id, delta in system.stream(req.task):
                payload = json.dumps({"agent": executor_id, "delta": delta})
                yield f"data: {payload}\n\n"
            yield "data: [DONE]\n\n"
            logger.info("Stream completed successfully")
        except Exception as exc:
            logger.exception("Error in /chat/stream generator")
            error_payload = json.dumps({"error": str(exc)})
            yield f"data: {error_payload}\n\n"
            yield "data: [DONE]\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")
