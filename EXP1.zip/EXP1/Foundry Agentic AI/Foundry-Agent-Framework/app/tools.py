"""Function tools exposed to agents.

Two categories:
  - Web search  (DuckDuckGo, no API key needed)
  - Finance     (yfinance, unofficial Yahoo Finance scraper)
"""

from __future__ import annotations

import asyncio
import functools
import json
import logging
from pathlib import Path
from typing import Annotated

try:
    from agent_framework import tool
except ImportError:
    from agent_framework import ai_function as tool  # type: ignore[attr-defined]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Web search
# ---------------------------------------------------------------------------

_MAX_RESULTS = 5
_TIMEOUT_S = 15


def _run_search(query: str) -> list[dict]:
    """Thin wrapper around ddgs so it can be monkeypatched in tests."""
    from ddgs import DDGS

    with DDGS(timeout=_TIMEOUT_S) as ddgs:
        return list(ddgs.text(query, max_results=_MAX_RESULTS))


@tool
async def web_search(
    query: Annotated[str, "The search query. Be specific; include entities and timeframes."],
) -> str:
    """Search the public web (DuckDuckGo) for current information and return ranked snippets."""
    last_err: Exception | None = None
    results: list[dict] = []
    for attempt in range(3):
        try:
            # ddgs is blocking; run it off the event loop so the async server
            # (and the SSE stream) stays responsive during the multi-second call.
            results = await asyncio.to_thread(_run_search, query)
            if results:
                break
            await asyncio.sleep(1.5 * (attempt + 1))
        except Exception as exc:
            last_err = exc
            logger.warning("web_search attempt %d failed: %s", attempt + 1, exc)
            await asyncio.sleep(1.5 * (attempt + 1))

    if not results:
        if last_err:
            return f"Web search failed after retries: {last_err}"
        return f"No results found for: {query} (possibly rate-limited; try again shortly)."

    lines = [f"Search results for '{query}':"]
    for i, r in enumerate(results, 1):
        title = r.get("title", "(untitled)")
        url = r.get("href") or r.get("url") or ""
        body = (r.get("body") or "").strip().replace("\n", " ")
        if len(body) > 400:
            body = body[:400] + "…"
        lines.append(f"{i}. {title}\n   {url}\n   {body}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Finance (yfinance)
# ---------------------------------------------------------------------------


def _safe(value):
    """JSON-serialise numpy/pandas scalars defensively."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


@tool
async def get_stock_quote(
    ticker: Annotated[str, "Stock ticker symbol, e.g. 'MSFT', 'AAPL', 'NVDA'."],
) -> str:
    """Return the latest price snapshot and key stats for a single ticker as JSON."""
    import yfinance as yf

    try:
        info = await asyncio.to_thread(lambda: yf.Ticker(ticker).info)
    except Exception as exc:
        logger.warning("get_stock_quote(%s) failed: %s", ticker, exc)
        return json.dumps({"ticker": ticker, "error": str(exc)})

    if not info or info.get("regularMarketPrice") is None:
        return json.dumps({"ticker": ticker, "error": "No data; check the symbol."})

    snapshot = {
        "ticker": ticker.upper(),
        "name": info.get("shortName"),
        "currency": info.get("currency"),
        "price": _safe(info.get("regularMarketPrice")),
        "previous_close": _safe(info.get("regularMarketPreviousClose")),
        "day_high": _safe(info.get("dayHigh")),
        "day_low": _safe(info.get("dayLow")),
        "market_cap": _safe(info.get("marketCap")),
        "trailing_pe": _safe(info.get("trailingPE")),
        "dividend_yield": _safe(info.get("dividendYield")),
        "fifty_two_week_high": _safe(info.get("fiftyTwoWeekHigh")),
        "fifty_two_week_low": _safe(info.get("fiftyTwoWeekLow")),
    }
    return json.dumps(snapshot)


@tool
async def get_price_history(
    ticker: Annotated[str, "Stock ticker symbol, e.g. 'MSFT'."],
    period: Annotated[str, "Window: 1mo, 3mo, 6mo, 1y, 2y, 5y, max."] = "6mo",
    interval: Annotated[str, "Bar size: 1d, 1wk, 1mo."] = "1d",
) -> str:
    """Return historical OHLCV bars as JSON records."""
    import yfinance as yf

    try:
        hist = await asyncio.to_thread(
            lambda: yf.Ticker(ticker).history(period=period, interval=interval)
        )
    except Exception as exc:
        logger.warning("get_price_history(%s) failed: %s", ticker, exc)
        return json.dumps({"ticker": ticker, "error": str(exc)})

    if hist.empty:
        return json.dumps({"ticker": ticker, "error": "No history returned."})

    hist = hist.reset_index()
    date_col = "Date" if "Date" in hist.columns else hist.columns[0]
    records = [
        {
            "date": str(row[date_col])[:10],
            "open": _safe(row.get("Open")),
            "high": _safe(row.get("High")),
            "low": _safe(row.get("Low")),
            "close": _safe(row.get("Close")),
            "volume": _safe(row.get("Volume")),
        }
        for _, row in hist.iterrows()
    ]
    return json.dumps({"ticker": ticker.upper(), "period": period,
                       "interval": interval, "bars": records})


@tool
async def get_fundamentals(
    ticker: Annotated[str, "Stock ticker symbol, e.g. 'MSFT'."],
) -> str:
    """Return headline fundamentals (revenue, margins, valuation multiples) as JSON."""
    import yfinance as yf

    try:
        info = await asyncio.to_thread(lambda: yf.Ticker(ticker).info)
    except Exception as exc:
        return json.dumps({"ticker": ticker, "error": str(exc)})

    fundamentals = {
        "ticker": ticker.upper(),
        "sector": info.get("sector"),
        "industry": info.get("industry"),
        "total_revenue": _safe(info.get("totalRevenue")),
        "gross_margins": _safe(info.get("grossMargins")),
        "operating_margins": _safe(info.get("operatingMargins")),
        "profit_margins": _safe(info.get("profitMargins")),
        "return_on_equity": _safe(info.get("returnOnEquity")),
        "debt_to_equity": _safe(info.get("debtToEquity")),
        "forward_pe": _safe(info.get("forwardPE")),
        "price_to_book": _safe(info.get("priceToBook")),
        "beta": _safe(info.get("beta")),
    }
    return json.dumps(fundamentals)


# ---------------------------------------------------------------------------
# Documents (PDF / DOCX / TXT / Excel / CSV)
# ---------------------------------------------------------------------------


@functools.lru_cache(maxsize=1)
def _token_encoder():
    """Tiktoken encoder for measuring/truncating document text (None if unavailable)."""
    try:
        import tiktoken

        try:
            return tiktoken.get_encoding("o200k_base")  # GPT-4o/5-family
        except Exception:
            return tiktoken.get_encoding("cl100k_base")
    except Exception:
        return None


def _count_tokens(text: str) -> int:
    enc = _token_encoder()
    return len(enc.encode(text)) if enc is not None else max(1, len(text) // 4)


def _truncate_to_tokens(text: str, budget: int) -> tuple[str, int]:
    """Return (text capped at `budget` tokens, full token count of the original)."""
    enc = _token_encoder()
    if enc is None:
        approx = max(1, len(text) // 4)
        if approx <= budget:
            return text, approx
        return text[: budget * 4], approx
    tokens = enc.encode(text)
    total = len(tokens)
    if total <= budget:
        return text, total
    return enc.decode(tokens[:budget]), total


def _extract_pdf(path: Path) -> str:
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    parts = []
    for i, page in enumerate(reader.pages, 1):
        text = (page.extract_text() or "").strip()
        if text:
            parts.append(f"[Page {i}]\n{text}")
    return "\n\n".join(parts)


def _extract_docx(path: Path) -> str:
    import docx

    document = docx.Document(str(path))
    parts = [p.text for p in document.paragraphs if p.text.strip()]
    # Include table cells too — contracts/reports often put data in tables.
    for table in document.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def _extract_spreadsheet(path: Path) -> str:
    import pandas as pd

    if path.suffix.lower() == ".csv":
        sheets = {"CSV": pd.read_csv(path)}
    else:
        sheets = pd.read_excel(path, sheet_name=None)  # all sheets
    parts = []
    for name, df in sheets.items():
        parts.append(f"[Sheet: {name}] ({len(df)} rows x {len(df.columns)} cols)\n{df.to_string(index=False)}")
    return "\n\n".join(parts)


def _read_document_sync(raw_path: str, token_budget: int) -> str:
    path = Path(raw_path.strip().strip('"').strip("'")).expanduser()
    if not path.exists():
        return f"Error: file not found: {path}"
    if not path.is_file():
        return f"Error: not a file: {path}"

    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            text = _extract_pdf(path)
        elif suffix == ".docx":
            text = _extract_docx(path)
        elif suffix in (".txt", ".md", ".log"):
            text = path.read_text(encoding="utf-8", errors="replace")
        elif suffix in (".xlsx", ".xls", ".csv"):
            text = _extract_spreadsheet(path)
        else:
            return (
                f"Error: unsupported file type '{suffix}'. "
                "Supported: .pdf, .docx, .txt, .md, .xlsx, .xls, .csv"
            )
    except Exception as exc:
        logger.warning("read_document(%s) failed: %s", path, exc)
        return f"Error reading {path.name}: {exc}"

    text = text.strip()
    if not text:
        return f"'{path.name}' contained no extractable text (it may be scanned/image-only)."

    # Large documents are capped at a token budget so they fit the model context
    # window (a 100-page file is far larger than any single request can hold).
    capped, total_tokens = _truncate_to_tokens(text, token_budget)
    label = suffix.lstrip(".").upper()
    if len(capped) < len(text):
        header = (
            f"Document: {path.name} ({label}; ~{total_tokens} tokens total, showing the "
            f"first {token_budget}. TRUNCATED — summarise the shown portion and clearly "
            f"note the document was cut off and a full summary needs the rest.)"
        )
    else:
        header = f"Document: {path.name} ({label}; ~{total_tokens} tokens)"
    return f"{header}\n\n{capped}"


@tool
async def read_document(
    path: Annotated[
        str,
        "Absolute path to a local document to read. Supported: .pdf, .docx, "
        ".txt, .md, .xlsx, .xls, .csv.",
    ],
) -> str:
    """Extract the text/contents of a local document (PDF, Word, text, Excel, CSV) for summarisation or Q&A.

    Large documents are truncated to a configurable token budget (``DOC_TOKEN_BUDGET``,
    default 16000) so they fit the model context window.
    """
    from .config import get_settings

    budget = get_settings().doc_token_budget
    return await asyncio.to_thread(_read_document_sync, path, budget)