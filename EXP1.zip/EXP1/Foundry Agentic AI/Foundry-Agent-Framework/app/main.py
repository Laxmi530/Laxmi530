"""CLI entry point.

    python -m app.main "Compare NVDA and AMD: pull 1y prices, compute annualised
    volatility and correlation, and summarise the latest news driving each."
"""

from __future__ import annotations

import asyncio
import sys

# Agent replies often contain emoji / smart quotes. The default Windows console
# is cp1252 and raises UnicodeEncodeError on those, aborting the CLI mid-print.
# Switch stdout/stderr to UTF-8 (replacing anything truly unencodable).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass

from .observability import configure_observability
from .orchestrator import MultiAgentSystem


async def _main(task: str) -> None:
    configure_observability()
    system = MultiAgentSystem.create()

    print(f"\n=== Task ===\n{task}\n\n=== Working ===")
    last_speaker = None
    async for executor_id, delta in system.stream(task):
        if executor_id != last_speaker:
            print(f"\n\n[{executor_id}] ", end="", flush=True)
            last_speaker = executor_id
        print(delta, end="", flush=True)
    print("\n\n=== Done ===")


def main() -> None:
    if len(sys.argv) < 2:
        print('Usage: python -m app.main "<your question>"')
        raise SystemExit(2)
    asyncio.run(_main(" ".join(sys.argv[1:])))


if __name__ == "__main__":
    main()
