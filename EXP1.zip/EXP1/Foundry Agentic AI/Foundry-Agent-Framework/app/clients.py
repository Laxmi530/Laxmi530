"""Foundry chat-client factory.

Credential strategy:
* Local dev  -> AzureCliCredential (run `az login` once).
* Production -> ManagedIdentityCredential (assign the Container App / AKS pod a
  managed identity with the `Azure AI User` role on the Foundry project).

A single ``FoundryChatClient`` is used for both the specialist agents and the
Magentic manager. This is the pattern shown in the official Agent Framework
docs. ``FoundryChatClient`` is the full client (Responses API + function
invocation + middleware + telemetry); its middleware layer manages local
conversation history correctly so the worker agents' tool-call/result pairs
stay intact when the manager replays them while building its progress ledger.

Note: do *not* use ``RawFoundryChatClient`` for the manager. It is the bare
base client (also the Responses API — not Chat Completions) without the
function-invocation/middleware layers. With it, the manager's progress-ledger
request strips a replayed worker ``function_call`` but keeps its
``function_call_output``, producing the orphaned-tool-output 400:
``No tool call found for function call output with call_id ...``.
"""

from __future__ import annotations

import os

from agent_framework.foundry import FoundryChatClient
from azure.identity import AzureCliCredential, ManagedIdentityCredential

from .config import get_settings


def _credential():
    if os.getenv("AZURE_CLIENT_ID") or os.getenv("MSI_ENDPOINT"):
        return ManagedIdentityCredential(client_id=os.getenv("AZURE_CLIENT_ID"))
    return AzureCliCredential()


def build_chat_client() -> FoundryChatClient:
    settings = get_settings()
    return FoundryChatClient(
        project_endpoint=settings.foundry_project_endpoint,
        model=settings.foundry_model,
        credential=_credential(),
    )
