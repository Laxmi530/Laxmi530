"""Agent definitions — triage front door + three specialists + one manager.

All prompt text (descriptions and instructions) lives in `prompts.py`; this
module only wires those onto `Agent(...)` objects with their clients and tools.
"""

from __future__ import annotations

from collections.abc import Sequence

from agent_framework import Agent, BaseChatClient, ContextProvider
from agent_framework.foundry import FoundryChatClient

from . import prompts
from .prompts import ESCALATE_TOKEN
from .tools import (
    get_fundamentals,
    get_price_history,
    get_stock_quote,
    read_document,
    web_search,
)

# Optional context providers (e.g. memory) shared by all agents.
ContextProviders = Sequence[ContextProvider] | None

# Re-exported so existing imports (`from .agents import ESCALATE_TOKEN`) keep working.
__all__ = [
    "ESCALATE_TOKEN",
    "build_triage_agent",
    "build_research_agent",
    "build_finance_agent",
    "build_quant_agent",
    "build_document_agent",
    "build_manager_agent",
]


def build_triage_agent(client: FoundryChatClient, context_providers: ContextProviders = None) -> Agent:
    """Fast front door: answers simple/general questions directly, escalates the rest.

    A single cheap call so trivial or general-knowledge inputs (greetings, small
    talk, concept questions, things answerable from memory) don't pay for the full
    Magentic orchestration. It escalates anything needing fresh/external data or
    real computation. See ``prompts.TRIAGE_INSTRUCTIONS``.
    """
    return Agent(
        name="TriageAgent",
        description=prompts.TRIAGE_DESCRIPTION,
        instructions=prompts.TRIAGE_INSTRUCTIONS,
        client=client,
        context_providers=context_providers,
    )


def build_research_agent(client: FoundryChatClient, context_providers: ContextProviders = None) -> Agent:
    return Agent(
        name="ResearchAgent",
        description=prompts.RESEARCH_DESCRIPTION,
        instructions=prompts.RESEARCH_INSTRUCTIONS,
        tools=[web_search],
        client=client,
        context_providers=context_providers,
    )


def build_finance_agent(client: FoundryChatClient, context_providers: ContextProviders = None) -> Agent:
    return Agent(
        name="FinanceAgent",
        description=prompts.FINANCE_DESCRIPTION,
        instructions=prompts.FINANCE_INSTRUCTIONS,
        tools=[get_stock_quote, get_price_history, get_fundamentals],
        client=client,
        context_providers=context_providers,
    )


def build_quant_agent(client: FoundryChatClient, context_providers: ContextProviders = None) -> Agent:
    return Agent(
        name="QuantAnalystAgent",
        description=prompts.QUANT_DESCRIPTION,
        instructions=prompts.QUANT_INSTRUCTIONS,
        tools=client.get_code_interpreter_tool(),
        client=client,
        context_providers=context_providers,
    )


def build_document_agent(client: FoundryChatClient, context_providers: ContextProviders = None) -> Agent:
    return Agent(
        name="DocumentAgent",
        description=prompts.DOCUMENT_DESCRIPTION,
        instructions=prompts.DOCUMENT_INSTRUCTIONS,
        tools=[read_document],
        client=client,
        context_providers=context_providers,
    )


def build_manager_agent(client: BaseChatClient, context_providers: ContextProviders = None) -> Agent:
    return Agent(
        name="OrchestratorManager",
        # store=False keeps the manager's Responses API calls stateless: no
        # previous_response_id is ever carried between turns. The Magentic
        # manager replays the specialist agents' full transcripts (including
        # their tool-call/result pairs) on every progress-ledger turn. Under
        # server-side storage the replayed `function_call` is stripped (assumed
        # already stored) while its `function_call_output` is kept, orphaning the
        # output and triggering "No tool call found for function call output with
        # call_id ..." (400) -> reset -> replan, until max_reset_count aborts the
        # run. Statelessly, both items are sent inline together and stay paired.
        default_options={"store": False},
        description=prompts.MANAGER_DESCRIPTION,
        instructions=prompts.MANAGER_INSTRUCTIONS,
        client=client,
        context_providers=context_providers,
    )
