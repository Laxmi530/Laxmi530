"""Observability — OpenTelemetry wiring.

With an Application Insights connection string the traces land in Azure Monitor;
without one we fall back to plain logging so local dev still works.
"""

from __future__ import annotations

import logging

from .config import get_settings


def configure_observability() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=settings.log_level.upper(),
        format="%(asctime)s %(levelname)s %(name)s :: %(message)s",
    )

    if not settings.appinsights_connection_string:
        logging.getLogger(__name__).info(
            "No App Insights connection string set; telemetry stays local."
        )
        return

    from azure.monitor.opentelemetry import configure_azure_monitor

    configure_azure_monitor(
        connection_string=settings.appinsights_connection_string,
        instrumentation_options={"azure_sdk": {"enabled": True}},
    )
    logging.getLogger(__name__).info("Azure Monitor OpenTelemetry exporter configured.")
