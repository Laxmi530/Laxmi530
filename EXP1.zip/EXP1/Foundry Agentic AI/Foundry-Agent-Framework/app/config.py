"""Centralised, typed configuration.

Everything the app needs comes from the environment so the same image runs
unchanged in dev, staging and prod. No secrets in code.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Foundry
    foundry_project_endpoint: str = Field(..., alias="FOUNDRY_PROJECT_ENDPOINT")
    foundry_model: str = Field("gpt-5.4-mini", alias="FOUNDRY_MODEL")

    # Observability
    appinsights_connection_string: str = Field(
        "", alias="APPLICATIONINSIGHTS_CONNECTION_STRING"
    )

    # Runtime / orchestration knobs
    log_level: str = Field("INFO", alias="LOG_LEVEL")
    max_round_count: int = Field(20, alias="MAX_ROUND_COUNT")
    max_stall_count: int = Field(5, alias="MAX_STALL_COUNT")
    max_reset_count: int = Field(5, alias="MAX_RESET_COUNT")
    enable_plan_review: bool = Field(False, alias="ENABLE_PLAN_REVIEW")

    # Memory (persists across requests/restarts via a JSON file)
    memory_enabled: bool = Field(True, alias="MEMORY_ENABLED")
    memory_path: str = Field(".agent_memory.json", alias="MEMORY_PATH")
    memory_max_tasks: int = Field(10, alias="MEMORY_MAX_TASKS")

    # Document uploads (where /upload saves files for the DocumentAgent to read)
    upload_dir: str = Field(".uploads", alias="UPLOAD_DIR")
    upload_max_mb: int = Field(25, alias="UPLOAD_MAX_MB")
    # Max tokens of document text sent to the LLM (large docs are truncated to this).
    doc_token_budget: int = Field(16000, alias="DOC_TOKEN_BUDGET")


@lru_cache
def get_settings() -> Settings:
    """Cached singleton so we parse the environment exactly once."""
    return Settings()  # type: ignore[call-arg]
