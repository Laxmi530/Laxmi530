"""Magentic orchestration.

The Magentic manager dynamically decides which specialist acts next, tracks a
progress ledger, detects stalls and replans.

Each workflow instance is single-use, so we build a fresh one per request
while reusing the shared chat client and settings.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

from agent_framework import AgentResponse, AgentResponseUpdate
from agent_framework.foundry import FoundryChatClient
from agent_framework.orchestrations import MagenticBuilder

from .agents import (
    ESCALATE_TOKEN,
    build_document_agent,
    build_finance_agent,
    build_manager_agent,
    build_quant_agent,
    build_research_agent,
    build_triage_agent,
)
from .clients import build_chat_client
from .config import Settings, get_settings
from .memory import MemoryContextProvider, MemoryStore, get_memory

logger = logging.getLogger(__name__)


@dataclass
class MultiAgentSystem:
    client: FoundryChatClient
    settings: Settings
    memory: MemoryStore | None = None

    @classmethod
    def create(cls) -> "MultiAgentSystem":
        settings = get_settings()
        client = build_chat_client()
        memory = get_memory() if settings.memory_enabled else None
        logger.info(
            "MultiAgentSystem initialised (memory %s).",
            "enabled" if memory else "disabled",
        )
        return cls(client=client, settings=settings, memory=memory)

    def _context_providers(self):
        """Shared context providers (memory) attached to every agent."""
        if self.memory is None:
            return None
        return [MemoryContextProvider(self.memory)]

    async def _triage(self, task: str) -> str | None:
        """One cheap call. Returns a direct answer, or None to escalate.

        Keeps trivial inputs (greetings, small talk, memory-answerable questions)
        off the heavy Magentic path so they respond in a couple of seconds.
        """
        agent = build_triage_agent(self.client, self._context_providers())
        try:
            answer = (await agent.run(task)).text or ""
        except Exception:
            logger.exception("Triage failed; escalating to the full workflow.")
            return None
        if ESCALATE_TOKEN in answer:
            return None
        return answer.strip() or None

    def _build_workflow(self):
        """Build a fresh single-use Magentic workflow."""
        providers = self._context_providers()
        research = build_research_agent(self.client, providers)
        finance = build_finance_agent(self.client, providers)
        quant = build_quant_agent(self.client, providers)
        document = build_document_agent(self.client, providers)
        # The manager uses the same full FoundryChatClient as the participants
        # (the official Agent Framework pattern). Using the bare
        # RawFoundryChatClient here triggers the orphaned function_call_output
        # 400 in the progress ledger — see app/clients.py.
        manager = build_manager_agent(self.client, providers)

        return MagenticBuilder(
            participants=[research, finance, quant, document],
            manager_agent=manager,
            intermediate_outputs=True,
            max_round_count=self.settings.max_round_count,
            max_stall_count=self.settings.max_stall_count,
            max_reset_count=self.settings.max_reset_count,
            enable_plan_review=self.settings.enable_plan_review,
        ).build()

    async def stream(self, task: str) -> AsyncIterator[tuple[str, str]]:
        """Yield (executor_id, text_delta) tuples as the workflow runs."""
        if self.memory is not None:
            self.memory.note_task(task)

        # Fast path: answer simple/conversational messages without the full team.
        direct = await self._triage(task)
        if direct is not None:
            yield ("OrchestratorManager", direct)
            return

        workflow = self._build_workflow()
        async for event in workflow.run(task, stream=True):
            if event.type == "output" and isinstance(event.data, AgentResponseUpdate):
                delta = str(event.data)
                if not delta:
                    continue
                yield (event.executor_id, delta)
            elif event.type == "output" and isinstance(event.data, AgentResponse):
                if event.data.messages:
                    text = event.data.messages[-1].text
                    if text:
                        yield (getattr(event, "executor_id", "system"), text)

    async def run(self, task: str) -> str:
        """Run to completion and return the manager's synthesised answer."""
        if self.memory is not None:
            self.memory.note_task(task)

        # Fast path: answer simple/conversational messages without the full team.
        direct = await self._triage(task)
        if direct is not None:
            return direct

        workflow = self._build_workflow()
        final_text = ""
        async for event in workflow.run(task, stream=True):
            if event.type == "output":
                if isinstance(event.data, AgentResponse) and event.data.messages:
                    final_text = event.data.messages[-1].text
                elif isinstance(event.data, AgentResponseUpdate):
                    final_text += str(event.data)
        return final_text or "(no final answer produced)"