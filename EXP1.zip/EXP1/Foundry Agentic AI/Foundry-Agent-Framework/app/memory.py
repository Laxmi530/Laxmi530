"""Persistent memory for the agent team.

The Agent Framework's memory primitive is the ``ContextProvider`` (see
https://learn.microsoft.com/en-us/agent-framework/get-started/memory). A
provider's ``before_run`` adds context before the model is called, and its
``after_run`` processes the response / inputs afterwards. State is normally kept
in ``session.state`` — but this app builds a *fresh* Magentic workflow (and
therefore a fresh session) per HTTP request, so session state would not survive
between requests.

To get memory that persists across requests *and* server restarts, the
``ContextProvider`` here is backed by a small JSON file on disk
(``MemoryStore``). Two kinds of memory are kept:

* ``facts``        — durable things the user explicitly asked us to remember
                     (preferences, their name, etc.).
* ``recent_tasks`` — a capped, rolling list of the user's recent questions, so
                     the team has conversational continuity.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from pathlib import Path
from typing import Any

from agent_framework import ContextProvider

from .config import get_settings

logger = logging.getLogger(__name__)

_MAX_FACTS = 50
_MAX_FACT_LEN = 280

# Split a message into clauses so a greedy capture can't swallow the rest of the
# sentence (".?!;" and newlines, plus " and " which usually joins two facts).
_CLAUSE_SPLIT = re.compile(r"[.?!;\n]+|\band\b", re.IGNORECASE)


def _clip(text: str) -> str:
    return text.strip().strip(",").strip()[:_MAX_FACT_LEN]


def _name(text: str) -> str:
    # Keep just the first one or two name-like tokens, title-cased.
    words = re.findall(r"[A-Za-z][\w'’-]*", text)[:2]
    return " ".join(w.capitalize() for w in words)


# (pattern, formatter): each matched clause becomes a clean, well-formed fact.
# Patterns are anchored to a clause, so they capture only that clause.
_FACT_RULES = [
    (re.compile(r"\b(?:my name is|call me)\s+(.+)", re.IGNORECASE),
     lambda s: f"The user's name is {_name(s)}." if _name(s) else ""),
    (re.compile(r"\bi prefer\s+(.+)", re.IGNORECASE),
     lambda s: f"The user prefers {_clip(s)}."),
    (re.compile(r"\bi(?:'m| am)\s+(?:a|an)\s+(.+)", re.IGNORECASE),
     lambda s: f"The user is a {_clip(s)}."),
    (re.compile(r"\b(?:remember that|remember|note that)\s*:?\s+(.+)", re.IGNORECASE),
     lambda s: _clip(s)),
]


class MemoryStore:
    """Thread-safe, JSON-file-backed store of facts and recent questions."""

    def __init__(self, path: str | Path, max_tasks: int = 10) -> None:
        self.path = Path(path)
        self.max_tasks = max_tasks
        self._lock = threading.Lock()
        self.facts: list[str] = []
        self.recent_tasks: list[str] = []
        self._load()

    # -- persistence --------------------------------------------------------
    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.facts = [str(f) for f in data.get("facts", [])]
            self.recent_tasks = [str(t) for t in data.get("recent_tasks", [])]
        except Exception as exc:  # corrupt/locked file shouldn't break a request
            logger.warning("Could not load memory from %s: %s", self.path, exc)

    def _save(self) -> None:
        try:
            self.path.write_text(
                json.dumps(
                    {"facts": self.facts, "recent_tasks": self.recent_tasks},
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("Could not persist memory to %s: %s", self.path, exc)

    # -- mutations ----------------------------------------------------------
    def add_fact(self, fact: str) -> bool:
        """Store a durable fact. Returns True if it was new."""
        fact = fact.strip().rstrip(".").strip()
        if not fact:
            return False
        fact = fact[:_MAX_FACT_LEN]
        with self._lock:
            if any(fact.lower() == existing.lower() for existing in self.facts):
                return False
            self.facts.append(fact)
            del self.facts[:-_MAX_FACTS]  # keep only the most recent _MAX_FACTS
            self._save()
        logger.info("Memory: stored fact %r", fact)
        return True

    def note_task(self, task: str) -> None:
        """Record the user's latest question (deduped, capped)."""
        task = task.strip()
        if not task:
            return
        with self._lock:
            # Move to most-recent if already present, else append.
            self.recent_tasks = [t for t in self.recent_tasks if t.lower() != task.lower()]
            self.recent_tasks.append(task)
            del self.recent_tasks[: -self.max_tasks]
            self._save()

    def clear(self) -> None:
        with self._lock:
            self.facts.clear()
            self.recent_tasks.clear()
            self._save()
        logger.info("Memory: cleared.")

    # -- reads --------------------------------------------------------------
    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"facts": list(self.facts), "recent_tasks": list(self.recent_tasks)}

    def render(self) -> str:
        """Render memory as an instruction block, or '' when empty."""
        with self._lock:
            if not self.facts and not self.recent_tasks:
                return ""
            lines = ["Relevant memory from earlier conversations with this user:"]
            if self.facts:
                lines.append("Known facts / preferences:")
                lines.extend(f"- {f}" for f in self.facts)
            if self.recent_tasks:
                lines.append("Recent questions they asked (most recent last):")
                lines.extend(f"- {t}" for t in self.recent_tasks[-self.max_tasks:])
            lines.append(
                "Use this only if it is relevant to the current request; do not "
                "mention it otherwise."
            )
            return "\n".join(lines)

    def extract_facts(self, text: str) -> list[str]:
        """Pull out explicit 'remember…' / preference facts from a message.

        Works clause-by-clause (sentences split further on 'and') so a greedy
        capture stops at the clause boundary instead of eating the whole line.
        """
        found: list[str] = []
        for clause in _CLAUSE_SPLIT.split(text):
            clause = clause.strip()
            if not clause:
                continue
            for pattern, formatter in _FACT_RULES:
                m = pattern.search(clause)
                if m:
                    fact = formatter(m.group(1)).strip()
                    if fact:
                        found.append(fact)
                    break
        return found


class MemoryContextProvider(ContextProvider):
    """Injects stored memory into each agent run and captures new facts.

    Attached to the agents via ``context_providers=[...]``. ``before_run``
    prepends the rendered memory as instructions; ``after_run`` scans the user's
    input for explicit facts to remember. All durable state lives in the shared
    ``MemoryStore`` (a file), not in ``session.state``, so it survives across
    requests and restarts.
    """

    DEFAULT_SOURCE_ID = "agent_memory"

    def __init__(self, store: MemoryStore, source_id: str | None = None) -> None:
        super().__init__(source_id or self.DEFAULT_SOURCE_ID)
        self.store = store

    async def before_run(self, *, agent: Any, session: Any, context: Any, state: dict[str, Any]) -> None:
        rendered = self.store.render()
        if rendered:
            context.extend_instructions(self.source_id, rendered)

    async def after_run(self, *, agent: Any, session: Any, context: Any, state: dict[str, Any]) -> None:
        # The fact patterns are specific and add_fact() dedupes, so scanning all
        # input messages is safe even when this fires several times per request.
        for msg in getattr(context, "input_messages", None) or []:
            text = getattr(msg, "text", "") or ""
            for fact in self.store.extract_facts(text):
                self.store.add_fact(fact)


_store: MemoryStore | None = None


def get_memory() -> MemoryStore:
    """Process-wide singleton memory store, configured from settings."""
    global _store
    if _store is None:
        settings = get_settings()
        _store = MemoryStore(settings.memory_path, max_tasks=settings.memory_max_tasks)
    return _store
