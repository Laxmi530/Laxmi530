"""Streamlit UI for Multi-Agent Foundry."""

import json
import os

import requests
import streamlit as st

# Defaults to the port the server actually listens on (see README and
# azure-container-apps.md, both 8000). Override with API_BASE if needed.
# Use 127.0.0.1, not "localhost": on Windows "localhost" resolves to ::1 first,
# and if the server is bound to IPv4 each request stalls on the IPv6 attempt
# before falling back — that adds seconds to every health check.
API_BASE = os.getenv("API_BASE", "http://127.0.0.1:8001")


@st.cache_data(ttl=5, show_spinner=False)
def check_server(base: str) -> tuple[bool, bool]:
    """Health/readiness probe, cached briefly so it doesn't run on the hot path.

    Streamlit re-runs the whole script on every interaction (including hitting
    Enter to submit a query). Without caching, these two network calls would run
    before your message can render, adding latency to each submit.
    """
    try:
        health = requests.get(f"{base}/healthz", timeout=2).json()
        ready = requests.get(f"{base}/readyz", timeout=2).json()
        return health.get("status") == "ok", ready.get("status") == "ready"
    except Exception:
        return False, False

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="Multi-Agent Foundry",
    page_icon="🤖",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Custom styling
# ---------------------------------------------------------------------------

st.markdown("""
<style>
    .agent-badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 600;
        margin-bottom: 4px;
    }
    .badge-research   { background: #dbeafe; color: #1e40af; }
    .badge-finance    { background: #dcfce7; color: #166534; }
    .badge-quant      { background: #fef3c7; color: #92400e; }
    .badge-document   { background: #fee2e2; color: #991b1b; }
    .badge-manager    { background: #f3e8ff; color: #6b21a8; }
    .status-dot       { height: 10px; width: 10px; border-radius: 50%; display: inline-block; margin-right: 6px; }
    .status-ok        { background-color: #22c55e; }
    .status-fail      { background-color: #ef4444; }

    /* User messages: avatar on the RIGHT, content right-aligned.
       Streamlit >=1.5x exposes the avatar as data-testid="stChatMessageAvatarUser";
       older builds used "chatAvatarIcon-user". Target both so this works across
       versions. Assistant messages keep the default (avatar on the LEFT). */
    .stChatMessage:has([data-testid="stChatMessageAvatarUser"]),
    .stChatMessage:has([data-testid="chatAvatarIcon-user"]) {
        flex-direction: row-reverse;
    }
    .stChatMessage:has([data-testid="stChatMessageAvatarUser"]) .stMarkdown,
    .stChatMessage:has([data-testid="chatAvatarIcon-user"]) .stMarkdown {
        text-align: right;
    }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Agent badge helper
# ---------------------------------------------------------------------------

AGENT_STYLES = {
    "ResearchAgent": ("Research Agent", "badge-research"),
    "FinanceAgent": ("Finance Agent", "badge-finance"),
    "QuantAnalystAgent": ("Quant Analyst", "badge-quant"),
    "DocumentAgent": ("Document Agent", "badge-document"),
    "OrchestratorManager": ("Manager", "badge-manager"),
}


def agent_badge(agent_id: str) -> str:
    label, css = AGENT_STYLES.get(agent_id, (agent_id, "badge-manager"))
    return f'<span class="agent-badge {css}">{label}</span>'

# ---------------------------------------------------------------------------
# Sidebar — server health + info
# ---------------------------------------------------------------------------

with st.sidebar:
    st.title("Multi-Agent Foundry")
    st.caption("Powered by Microsoft Agent Framework")

    st.divider()

    st.subheader("Server Status")
    health_ok, ready_ok = check_server(API_BASE)

    dot_h = "status-ok" if health_ok else "status-fail"
    dot_r = "status-ok" if ready_ok else "status-fail"
    st.markdown(
        f'<span class="status-dot {dot_h}"></span> Health: **{"OK" if health_ok else "Down"}**',
        unsafe_allow_html=True,
    )
    st.markdown(
        f'<span class="status-dot {dot_r}"></span> Ready: **{"Yes" if ready_ok else "No"}**',
        unsafe_allow_html=True,
    )

    if not health_ok:
        st.error("Server is not running. Start it with:\n\n`uvicorn app.server:app --reload`")

    st.divider()

    st.subheader("Agent Team")
    for aid, (label, css) in AGENT_STYLES.items():
        st.markdown(agent_badge(aid), unsafe_allow_html=True)
    st.caption(
        "The Manager plans and routes tasks to specialists. Research finds web "
        "info, Finance pulls market data, Quant runs computations, and Document "
        "reads/summarises files you attach."
    )

    st.divider()

    # -- Document attachment -------------------------------------------------
    st.subheader("Attach a document")
    upload = st.file_uploader(
        "PDF, Word, text, Excel or CSV",
        type=["pdf", "docx", "txt", "md", "log", "xlsx", "xls", "csv"],
        key="uploader",
        label_visibility="collapsed",
    )
    if upload is not None:
        sig = f"{upload.name}:{upload.size}"
        if st.session_state.get("attached_sig") != sig:
            try:
                resp = requests.post(
                    f"{API_BASE}/upload",
                    files={"file": (upload.name, upload.getvalue())},
                    timeout=60,
                )
                resp.raise_for_status()
                st.session_state.attached = resp.json()  # {filename, path}
                st.session_state.attached_sig = sig
            except Exception as exc:
                st.error(f"Upload failed: {exc}")

    if st.session_state.get("attached"):
        st.caption(f"📎 **{st.session_state.attached['filename']}** — ask about it below.")
        if st.button("Remove attachment", use_container_width=True):
            st.session_state.pop("attached", None)
            st.session_state.pop("attached_sig", None)
            st.rerun()

    st.divider()

    if st.button("Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ---------------------------------------------------------------------------
# Chat state
# ---------------------------------------------------------------------------

if "messages" not in st.session_state:
    st.session_state.messages = []

# ---------------------------------------------------------------------------
# Render chat history
# ---------------------------------------------------------------------------

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant" and msg.get("agent_blocks"):
            for block in msg["agent_blocks"]:
                st.markdown(agent_badge(block["agent"]), unsafe_allow_html=True)
                st.markdown(block["text"])
        else:
            st.markdown(msg["content"])

# ---------------------------------------------------------------------------
# Chat input
# ---------------------------------------------------------------------------

if prompt := st.chat_input("Ask a any question..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # If a document is attached, tell the agents where to find it (server path).
    task = prompt
    attached = st.session_state.get("attached")
    if attached:
        task = (
            f"{prompt}\n\n[The user attached a document. Read it from this server "
            f"path if relevant: {attached['path']} (original name: {attached['filename']})]"
        )

    with st.chat_message("assistant"):
        if not health_ok:
            st.error("Server is not reachable. Please start it first.")
            st.stop()

        status_area = st.empty()
        status_area.info("Agents are working on your request...")

        try:
            resp = requests.post(
                f"{API_BASE}/chat/stream",
                json={"task": task},
                stream=True,
                timeout=300,
            )
            resp.raise_for_status()

            agent_blocks: list[dict] = []
            current_agent = None
            current_text = ""
            display_container = st.container()

            for line in resp.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data: "):
                    continue

                payload = line[6:].strip()
                if payload == "[DONE]":
                    break

                try:
                    data = json.loads(payload)
                except json.JSONDecodeError:
                    continue

                if "error" in data:
                    status_area.empty()
                    st.error(f"Agent error: {data['error']}")
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": f"Error: {data['error']}",
                        "agent_blocks": [],
                    })
                    st.stop()

                agent_id = data.get("agent", "")
                delta = data.get("delta", "")

                if agent_id != current_agent:
                    if current_agent and current_text:
                        agent_blocks.append({"agent": current_agent, "text": current_text.strip()})
                    current_agent = agent_id
                    current_text = ""

                current_text += delta

                with display_container:
                    st.empty()

            if current_agent and current_text:
                agent_blocks.append({"agent": current_agent, "text": current_text.strip()})

            status_area.empty()

            if agent_blocks:
                with display_container:
                    for block in agent_blocks:
                        st.markdown(agent_badge(block["agent"]), unsafe_allow_html=True)
                        st.markdown(block["text"])
            else:
                with display_container:
                    st.warning("No response received from agents.")

            st.session_state.messages.append({
                "role": "assistant",
                "content": "\n\n".join(b["text"] for b in agent_blocks),
                "agent_blocks": agent_blocks,
            })

        except requests.exceptions.ConnectionError:
            status_area.empty()
            st.error(
                f"Could not connect to the server at {API_BASE}. Is it running on "
                "that port? Start it with `uvicorn app.server:app --port 8000`, or "
                "set API_BASE to match your server's port."
            )
        except requests.exceptions.ChunkedEncodingError:
            status_area.empty()
            st.error(
                "The server closed the connection mid-stream. The server process "
                "stopped or crashed during the request — check the server terminal "
                "for the actual error. Common causes: the server was restarted (e.g. "
                "`--reload` reloading on a file change) or `az login` expired."
            )
        except requests.exceptions.Timeout:
            status_area.empty()
            st.error("Request timed out. The task may be too complex.")
        except Exception as e:
            status_area.empty()
            st.error(f"Error: {e}")
