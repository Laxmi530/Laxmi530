"""Tool-level unit tests.

Tools are the only place the system touches the outside world, so they're where
deterministic tests pay off. We monkeypatch the network calls so tests run
offline and fast.
"""

from __future__ import annotations

import asyncio
import json

import app.tools as tools


async def _noop_sleep(*_):
    return None


def test_get_stock_quote_handles_missing_symbol(monkeypatch):
    class _FakeTicker:
        def __init__(self, *_):
            self.info = {}

    import yfinance
    monkeypatch.setattr(yfinance, "Ticker", _FakeTicker)
    out = json.loads(asyncio.run(tools.get_stock_quote("ZZZZ")))
    assert "error" in out


def test_web_search_formats_results(monkeypatch):
    fake = [
        {"title": "Acme reports earnings", "href": "https://x.test/1", "body": "Acme beat estimates."},
        {"title": "Acme hires CEO", "url": "https://x.test/2", "body": "New leadership."},
    ]
    monkeypatch.setattr(tools, "_run_search", lambda q: fake)
    out = asyncio.run(tools.web_search("acme news"))
    assert "Acme reports earnings" in out
    assert "https://x.test/1" in out
    assert "https://x.test/2" in out


def test_web_search_empty_is_graceful(monkeypatch):
    monkeypatch.setattr(tools, "_run_search", lambda q: [])
    monkeypatch.setattr(tools.asyncio, "sleep", _noop_sleep)
    out = asyncio.run(tools.web_search("nothing here"))
    assert "No results" in out


def test_web_search_retries_then_reports(monkeypatch):
    def boom(_q):
        raise RuntimeError("rate limited")

    monkeypatch.setattr(tools, "_run_search", boom)
    monkeypatch.setattr(tools.asyncio, "sleep", _noop_sleep)
    out = asyncio.run(tools.web_search("anything"))
    assert "failed after retries" in out
