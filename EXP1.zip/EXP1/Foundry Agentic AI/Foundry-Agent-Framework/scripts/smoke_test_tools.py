"""Smoke-test the tools with NO Azure/Foundry required.

    python scripts/smoke_test_tools.py
"""

from __future__ import annotations

import asyncio

from app.tools import get_stock_quote, web_search


async def main() -> None:
    print(">>> DuckDuckGo web_search('Microsoft Agent Framework 1.0')")
    print(await web_search("Microsoft Agent Framework 1.0"))
    print("\n" + "=" * 60 + "\n")

    print(">>> yfinance get_stock_quote('MSFT')")
    print(await get_stock_quote("MSFT"))


if __name__ == "__main__":
    asyncio.run(main())
