"""Smoke-test Foundry connectivity with a SINGLE agent.

    az login
    python scripts/smoke_test_agent.py
"""

from __future__ import annotations

import asyncio

from app.agents import build_research_agent
from app.clients import build_chat_client
from app.observability import configure_observability


async def main() -> None:
    configure_observability()
    agent = build_research_agent(build_chat_client())
    result = await agent.run("What did Microsoft announce at Build 2026 about Agent Framework?")
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
