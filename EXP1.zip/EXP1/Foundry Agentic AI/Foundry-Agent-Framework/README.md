# Multi-Agent Foundry

A multi-agent system on **Microsoft Agent Framework (MAF) 1.0** and **Microsoft Foundry**.
A lightweight **triage** front door answers simple/general questions in a single
call; anything needing fresh data or computation is escalated to a **Magentic
manager** that coordinates four specialists.

| Agent | Role | Tools |
|---|---|---|
| `TriageAgent` | Fast front door: answers greetings/concepts/general-knowledge directly, or escalates | — (single call) |
| `ResearchAgent` | Web facts, news, qualitative context | `web_search` (DuckDuckGo) |
| `FinanceAgent` | Structured market data | `get_stock_quote`, `get_price_history`, `get_fundamentals` (yfinance) |
| `QuantAnalystAgent` | Computation: returns, volatility, correlation | Foundry hosted **Code Interpreter** |
| `DocumentAgent` | Reads & summarises local documents | `read_document` (PDF / DOCX / TXT / Excel / CSV) |
| `OrchestratorManager` | Plans, routes, synthesises | — (Magentic manager) |

```
                ┌──────────────┐  simple / general / memory
  user task ──▶│  TriageAgent  │ ─────────────────────────▶ direct answer (1 call)
                └──────┬───────┘
                       │ needs fresh data or computation  → escalate
                       ▼
                ┌─────────────────────────┐
                │  Magentic Manager       │  plans → routes → replans on stall
                │  (OrchestratorManager)  │
                └──────────┬──────────────┘
        ┌──────────────┬───────┴───────┬──────────────────┐
        ▼              ▼               ▼                  ▼
  ResearchAgent   FinanceAgent   QuantAnalystAgent   DocumentAgent
  (web_search)  (yfinance tools) (code interpreter)  (read_document)
        └──────────────┴───────┬───────┴──────────────────┘
                           ▼
                 synthesised, sourced answer
```

## Project layout

```
app/
  config.py          typed settings from env (pydantic-settings)
  clients.py         FoundryChatClient factory (CLI cred dev / MSI prod)
  observability.py   OpenTelemetry -> Azure Monitor
  tools.py           @tool functions (web_search + finance + read_document), async (non-blocking)
  prompts.py         all agent prompts (descriptions + instructions) in one place
  agents.py          triage front door + three specialists + manager
  memory.py          persistent ContextProvider memory (facts + recent questions)
  orchestrator.py    triage fast-path + MagenticBuilder wiring + run/stream helpers
  main.py            CLI entry
  server.py          FastAPI (/chat, /chat/stream, /upload, /memory, /healthz, /readyz)
scripts/             smoke tests
tests/               offline tool unit tests
.env                 environment config (not committed)
requirements.txt     pinned dependencies
```

## Run locally

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure
cp .env.example .env   # fill in FOUNDRY_PROJECT_ENDPOINT
az login               # local credential

# 3a. API server
uvicorn app.server:app --reload

# 3b. One-shot CLI
python -m app.main "Compare NVDA and AMD: pull 1y daily prices and summarise news."

# 3c. Smoke tests (no Azure needed)
python scripts/smoke_test_tools.py

# 4. Unit tests
pytest tests/
```

## Configuration

All settings come from environment variables (or `.env`):

| Variable | Required | Default | Description |
|---|---|---|---|
| `FOUNDRY_PROJECT_ENDPOINT` | Yes | — | Foundry project URL |
| `FOUNDRY_MODEL` | Yes | `gpt-5.4-mini` | Model deployment name |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | No | — | Azure Monitor telemetry |
| `MAX_ROUND_COUNT` | No | `20` | Max orchestration rounds (manager↔agent iterations) before the run is terminated |
| `MAX_STALL_COUNT` | No | `5` | Unproductive/looping rounds tolerated before the orchestrator scraps the plan and replans |
| `MAX_RESET_COUNT` | No | `5` | Max replans (resets) before the run is aborted |
| `ENABLE_PLAN_REVIEW` | No | `false` | Human-in-the-loop plan approval |
| `MEMORY_ENABLED` | No | `true` | Enable persistent cross-request memory |
| `MEMORY_PATH` | No | `.agent_memory.json` | Where memory is persisted |
| `MEMORY_MAX_TASKS` | No | `10` | Recent questions kept for continuity |
| `UPLOAD_DIR` | No | `.uploads` | Where `POST /upload` saves documents |
| `UPLOAD_MAX_MB` | No | `25` | Max upload size (MB) |
| `DOC_TOKEN_BUDGET` | No | `16000` | Max tokens of document text sent to the LLM |

### Orchestration limits

These three bound the Magentic manager's control loop:

- **`MAX_ROUND_COUNT`** — the cap on **rounds**. One round = the manager builds a
  *progress ledger* (evaluates "is the task done? are we stuck? who goes next?")
  and delegates to **one** agent, who responds. Hitting this terminates the run
  (*"maximum round count reached"*).
- **`MAX_STALL_COUNT`** — the "are we getting anywhere?" guard. After each round
  the progress ledger flags whether progress is being made and whether the team
  is looping. An unproductive round increments a stall counter (a productive one
  decrements it); when it exceeds this threshold, the orchestrator scraps the
  current plan and **replans**. Higher = more patience; lower = replans sooner.
- **`MAX_RESET_COUNT`** — the cap on **replans (resets)**. The initial plan is made
  once; each reset (from a stall, *or* from a progress-ledger failure) replans and
  bumps the reset counter. When it reaches this limit, the workflow **aborts**
  (*"max reset count reached"*).

```
round → manager evaluates progress (progress ledger)
  ├─ task satisfied?           → finish, synthesize answer
  ├─ stalled/looping too much? → RESET + REPLAN   (counts toward MAX_RESET_COUNT)
  └─ otherwise                 → delegate to next agent, next round
                                  (counts toward MAX_ROUND_COUNT)

too many rounds → terminate ("max round count reached")
too many resets → terminate ("max reset count reached")
```

> This is exactly the failure mode of the original `400` bug: every progress
> ledger failed → reset each round → the reset counter climbed until
> *"max reset count reached"* aborted the run with no answer.

## Routing (triage fast path)

Every request first hits the `TriageAgent` — **one** model call that decides
between answering directly and escalating to the full team:

- **Answered directly** (no orchestration): greetings, small talk, capability
  questions, general-knowledge / conceptual questions ("what is a P/E ratio?",
  "how do ETFs work?"), and anything answerable from memory.
- **Escalated** to the Magentic workflow: anything needing up-to-date web
  information, live/historical market data, news, recent events, or real
  computation. The triage agent replies with a sentinel token and the
  orchestrator runs the specialists.

This keeps simple inputs fast (one call instead of the full plan→ledger→delegate
→synthesise loop), while complex requests still get the whole team. All prompt
text — including the triage routing rules — lives in [`app/prompts.py`](app/prompts.py),
so behavior is tuned in one place.

## Documents

The `DocumentAgent` reads and summarises **PDF, Word (.docx), text (.txt/.md),
and spreadsheets (.xlsx/.xls/.csv)** via the `read_document` tool. Two ways to
give it a file:

- **UI upload** — use the "Attach a document" uploader in the Streamlit sidebar.
  The file is sent to `POST /upload`, saved under `UPLOAD_DIR`, and its server
  path is attached to your next question. Ask follow-ups about the same file
  without re-uploading; "Remove attachment" clears it.
- **Path** — mention a local file path in your message (e.g. *"summarise
  C:\reports\q2.pdf"*); the agent reads it directly. Works from the CLI too.

```bash
# upload, then ask about it
curl -F "file=@report.pdf" localhost:8000/upload
```

**Large files:** extracted text is measured with a tokenizer and capped at
`DOC_TOKEN_BUDGET` tokens (default **16,000**) so it fits the model context — a
100-page upload sends the first 16k tokens, and the summary notes it was
truncated. (For *full* coverage of very large documents, a map-reduce pass
— summarise each chunk, then combine — would be the next step.) Scanned/image-only
PDFs yield no text (no OCR).

## Memory

The team has persistent memory via a `ContextProvider` (the Agent Framework
memory primitive — see the [docs](https://learn.microsoft.com/en-us/agent-framework/get-started/memory)).
Because the app builds a fresh workflow per request (so per-session state would
not survive), memory is backed by a JSON file (`MEMORY_PATH`) and therefore
persists across requests **and** server restarts.

* **What it remembers** — facts the user states explicitly ("my name is…",
  "I prefer…", "remember that…", "I am a…") and a rolling list of recent
  questions for continuity.
* **How it's used** — `MemoryContextProvider.before_run` injects the remembered
  context as instructions for every agent; `after_run` extracts new facts.
* **Inspect / clear** — `GET /memory` returns what's stored; `POST /memory/clear`
  (or `DELETE /memory`) forgets everything and returns the now-empty state.
  Clearing only empties the store — the same store keeps working, so the next
  request is remembered again with **no restart needed**. Set
  `MEMORY_ENABLED=false` to turn memory off entirely.

```bash
curl localhost:8000/memory                 # inspect
curl -X POST localhost:8000/memory/clear   # clear (DELETE /memory also works)
```

## FAQ

### Where is the conversation stored?

The **full conversation is not persisted** by the app. Each request is stateless
except for the memory file. There are three separate layers, and only one
survives across requests:

| What | Where it lives | Survives across requests? |
|---|---|---|
| **Magentic working conversation** (manager `chat_history`, agent transcripts, tool calls) | In RAM, inside the workflow built per request in `orchestrator._build_workflow()` | No — a fresh workflow is built every `/chat/stream` call, then discarded |
| **UI chat history** (the bubbles you see) | `st.session_state.messages` in the browser/Streamlit session (`ui.py`) | No — display only; never sent back to the server. Gone on refresh / "Clear Chat" |
| **Memory** (facts + recent questions) | A JSON file on disk (`MEMORY_PATH`, default `.agent_memory.json`) | Yes — across requests and restarts |

So the agents do **not** see prior turns' full transcripts — only the small memory
block that gets injected (extracted facts + the rolling list of recent questions).
That is why a later turn can recall your name even though it runs as a brand-new
workflow with no transcript of the earlier turn.

Within a single request, the Foundry **Responses API** does store the participant
agents' responses server-side (the `previous_response_id` chain), but that is
per-run plumbing, not an app-level conversation store, and the manager runs
`store=False`. **Memory ≠ transcript:** to persist the whole multi-turn transcript
you would add a `HistoryProvider` (e.g. `InMemoryHistoryProvider`, or a DB/Redis
provider) keyed by a conversation ID — that is a separate feature.

### Is the memory attached to the agent or the orchestrator?

**Both, in two layers:**

- The **behavior** — `MemoryContextProvider` (injects memory in `before_run`,
  extracts facts in `after_run`) — is attached to the **agents** via the
  framework's `context_providers=[...]` parameter on each `Agent(...)` in
  `agents.py`. All four agents (three specialists + manager) get it. This is the
  official Agent Framework memory mechanism; it fires around each agent's model call.
- The **data + lifecycle** — the file-backed `MemoryStore` plus capturing the
  user's question with `note_task` — is owned by the **orchestrator**
  (`MultiAgentSystem` in `orchestrator.py`). It creates one shared `MemoryStore`,
  builds the provider from it, hands the provider to the agent builders, and calls
  `memory.note_task(task)` at the start of each request.

```
MultiAgentSystem (orchestrator)
  ├── owns  MemoryStore  ──►  .agent_memory.json   (persistent data)
  ├── note_task(task)    per request                (records the question)
  └── builds MemoryContextProvider(store)
        └── attached to every Agent via context_providers=[...]
              ├── before_run → inject remembered facts/questions
              └── after_run  → extract & store new facts
```

The provider rides on the **agents** (how the framework injects context into model
calls), but the persistent state and per-request capture are coordinated by the
**orchestrator**. They share a single `MemoryStore` instance, which keeps memory
consistent across all agents and durable across requests.

### Is the final response from the manager or from an agent?

It depends on the path:

- **Simple / general questions (fast path)** — the answer comes straight from the
  **`TriageAgent`** in a single call (surfaced under the manager label in the stream).
- **Escalated questions (full team)** — the final answer is the **manager's
  synthesis**, not a specialist's raw output. The specialists (Research / Finance /
  Quant / Document) produce *intermediate* results; the Magentic manager combines
  them in its final-answer step into the single sourced answer you receive (the
  terminal `AgentResponse` the orchestrator yields).

So on an escalated task a specialist never has the "last word" — the manager always
writes the final response; on the fast path the triage agent does.

### Can I create an agent without an LLM?

The built-in `Agent` (`ChatAgent`) is **LLM-backed** — it wraps a chat client, so it
always needs a model. But you don't need an LLM for non-reasoning work:

- **Tools** are plain Python, no LLM. All of this app's real I/O — `web_search`, the
  yfinance calls, `read_document` — is deterministic code that the agents *call*.
- **Custom executors / participants** — `MagenticBuilder(participants=...)` accepts
  any `Executor` (or object implementing the agent-run protocol), not just
  `ChatAgent`s, so you can add a deterministic, no-LLM participant to the workflow.

Rule of thumb: use a **tool** (or executor) for deterministic logic, and an **LLM
agent** only when you need reasoning or language.

### What is the manager's role if it's also an agent?

The manager *is* an LLM agent (a `ChatAgent`, like the specialists), but Magentic
wraps it in a `StandardMagenticManager` and uses it as the **coordinator, not a
doer**:

- **Plans** — builds a task ledger (facts + step-by-step plan).
- **Routes** — each round builds a *progress ledger* ("is it done? are we stuck? who
  acts next?") and delegates to one specialist.
- **Detects stalls / replans** — see [Orchestration limits](#orchestration-limits).
- **Synthesises** — combines the specialists' outputs into the final sourced answer.

It deliberately does **not** answer factual or numeric questions itself — its
instructions route them. Same object type as a specialist, different job: the
specialists are the *hands* (tools, domain work); the manager is the *brain*
(plan, route, synthesise).

## Deployment

See `azure-container-apps.md` for Container Apps deployment guide.

MAX_ROUND_COUNT — 
Max total rounds in the inner loop. One round = the manager builds a progress ledger (evaluates "is the task done? are we stuck? who goes next?") and delegates to one agent, who responds. So yes — it's the cap on orchestrator↔agent iterations for a single task.

When round_index >= max_round_count, the run terminates with "Workflow terminated due to reaching maximum round count." (line 1230, 1236).

MAX_STALL_COUNT — 
After every round, the manager's progress ledger answers two flags: is progress being made? and is it in a loop? (lines 1102–1107):

Unproductive round (no progress or looping) → stall_count += 1
Productive round → stall_count -= 1 (it decays, doesn't reset to 0)
When stall_count > MAX_STALL_COUNT, the orchestrator decides the current plan isn't working and triggers a reset + replan (throws away the plan and makes a new one).

In short: how many unproductive/looping rounds it tolerates before scrapping the plan and replanning. Higher = more patience before giving up on a plan; lower = replans sooner.

MAX_RESET_COUNT — 
It's the max number of resets (replans), not total plans. The flow:

The manager makes the initial plan once.
Each reset (from a stall, or from a progress-ledger failure) does one replan and increments reset_count (line 385).
When reset_count >= MAX_RESET_COUNT, the workflow gives up entirely and terminates with "Max reset count reached" (lines 1231–1238).
So: max times the orchestrator may throw away its plan and start over before aborting. (Total plans ≈ 1 initial + up to MAX_RESET_COUNT replans.)



> Not investment advice. The financial outputs are for engineering demonstration.
