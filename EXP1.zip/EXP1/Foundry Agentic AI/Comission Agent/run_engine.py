"""
Deterministic CLI — no Foundry, no credentials, no network.

Validates the core offline using the canonical default_ruleset.json. This is
the same interpreter the agents call through their tools (the agents merely
supply a ruleset PARSED from natural language instead of the canonical one).

    python run_engine.py /abs/path/Test_Workbook.xlsx [/abs/path/Test_Doc.docx]
"""

from __future__ import annotations

import json
import sys

import commission_io as cio
from rule_interpreter import load_ruleset


def main(xlsx_path: str, doc_path: str | None = None):
    rs = load_ruleset()
    output_path = xlsx_path.replace(".xlsx", "_filled.xlsx")

    if doc_path:
        import rules_parsing as rp
        text = rp.read_ruleset_text(doc_path)
        print(f"Read {len(text)} chars of natural-language rules from the document.")
        check = rp.check_parsed_ruleset(rs)
        print(f"Canonical ruleset self-check: accuracy={check['parse_accuracy']}, "
              f"mismatches={check['mismatch_count']}\n")

    results = cio.calculate(xlsx_path, rs)
    print(f"{'OrderID':8}{'GM%':>8}{'Tier':>7}{'Band':>8}{'Rate%':>8}{'Commission':>13}")
    print("-" * 52)
    for r in results:
        print(f"{r['OrderID']:8}{r['GrossMargin']*100:7.2f}%{r['Tier']:>7}"
              f"{r['GMBand']:>8}{r['CommissionRate']*100:7.2f}%{r['CommissionAmount']:13.2f}")

    recon = cio.reconcile(xlsx_path, rs)
    print(f"\nReconciliation vs spec expected table: {recon['mismatch_count']} mismatch(es)")
    for m in recon["mismatches"]:
        print(f"  {m['OrderID']}: computed {m['computed']:.2f} vs spec {m['spec_expected']:.2f} "
              f"(rules: {', '.join(m['rules_applied'])})")

    out = cio.write_filled(xlsx_path, output_path, rs)
    print(f"\nWrote {out['rows_written']} rows to {out['output_path']}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python run_engine.py /abs/path/Test_Workbook.xlsx [/abs/path/Test_Doc.docx]")
        raise SystemExit(1)
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
