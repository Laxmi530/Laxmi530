"""
Pure data + reconciliation logic. No agent_framework, no network.

Now ruleset-driven: every function takes a structured ruleset dict, so the
SAME code runs whether the rules came from default_ruleset.json or were parsed
from natural language by the RuleParserAgent.
"""

from __future__ import annotations

from openpyxl import load_workbook

from rule_interpreter import compute_batch, load_ruleset

# Spec document "Expected Results" commission amounts, for reconciliation.
# ORD005 and ORD006 are known to disagree with the documented rules.
SPEC_EXPECTED = {
    "ORD001": 3000.00, "ORD002": 300.00, "ORD003": 5700.00, "ORD004": 240.00,
    "ORD005": 950.00, "ORD006": 4275.00, "ORD007": 1350.00, "ORD008": 2200.00,
    "ORD009": 1625.00, "ORD010": 0.00, "ORD011": 7600.00, "ORD012": 1800.00,
    "ORD013": 1050.00, "ORD014": 1950.00, "ORD015": 337.50,
}


def read_orders(path: str) -> list[dict]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    header = [str(h).strip() if h is not None else "" for h in rows[0]]
    records = []
    for row in rows[1:]:
        if row[0] is None:
            continue
        records.append(dict(zip(header, row)))
    wb.close()
    return records


def calculate(path: str, ruleset: dict | None = None) -> list[dict]:
    rs = ruleset or load_ruleset()
    return [r.to_dict() for r in compute_batch(read_orders(path), rs)]


def reconcile(path: str, ruleset: dict | None = None) -> dict:
    rs = ruleset or load_ruleset()
    mismatches = []
    for r in compute_batch(read_orders(path), rs):
        expected = SPEC_EXPECTED.get(r.order_id)
        computed = round(r.commission_amount, 2)
        if expected is not None and abs(expected - computed) > 0.01:
            mismatches.append({
                "OrderID": r.order_id, "computed": computed,
                "spec_expected": expected, "tier": r.tier,
                "rate": round(r.final_rate, 4), "rules_applied": r.rules_applied,
            })
    return {"mismatch_count": len(mismatches), "mismatches": mismatches}


def write_filled(input_path: str, output_path: str, ruleset: dict | None = None) -> dict:
    rs = ruleset or load_ruleset()
    wb = load_workbook(input_path)
    ws = wb.active
    header = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
    col = {name: i + 1 for i, name in enumerate(header)}
    results = {r.order_id: r for r in compute_batch(read_orders(input_path), rs)}

    written = 0
    for row in range(2, ws.max_row + 1):
        oid = ws.cell(row=row, column=col["OrderID"]).value
        if oid is None:
            continue
        r = results[str(oid)]
        ws.cell(row=row, column=col["GrossMargin"]).value = round(r.gross_margin, 4)
        ws.cell(row=row, column=col["Tier"]).value = r.tier
        ws.cell(row=row, column=col["CommissionRate"]).value = round(r.final_rate, 4)
        ws.cell(row=row, column=col["CommissionAmount"]).value = round(r.commission_amount, 2)
        written += 1

    wb.save(output_path)
    return {"output_path": output_path, "rows_written": written}
