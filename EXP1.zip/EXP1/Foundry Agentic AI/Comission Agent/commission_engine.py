"""
Deterministic commission engine.

This module is the trusted source of truth for commission math. It contains
NO LLM calls and NO randomness, so its output is fully reproducible and unit
testable. The agents call this engine through tools; they never do arithmetic
themselves.

Ruleset (from the spec document):
  Tier:   Large if OrderValue >= 50000 else Small
  GM:     (OrderValue - COGS) / OrderValue
  Bands:  Low < 20% ; Medium 20%-40% (inclusive) ; High > 40%
  R1:     GM < 10%               -> final rate = 0 (loss-leader)
  R2:     Recurring & months>=24 -> +0.5 percentage points
  R3:     Discount > 25%         -> -1.0 percentage point (floored at 0)
  R4:     Commission = OrderValue * final rate
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Base rate matrix: (OrderType, Tier) -> {GM band: rate}
RATE_MATRIX: dict[tuple[str, str], dict[str, float]] = {
    ("Order", "Large"): {"Low": 0.020, "Medium": 0.040, "High": 0.060},
    ("Order", "Small"): {"Low": 0.010, "Medium": 0.025, "High": 0.045},
    ("Recurring", "Large"): {"Low": 0.035, "Medium": 0.060, "High": 0.090},
    ("Recurring", "Small"): {"Low": 0.020, "Medium": 0.040, "High": 0.070},
}

RECURRING_BONUS = 0.005      # R2
DISCOUNT_PENALTY = 0.010     # R3
LOSS_LEADER_GM = 0.10        # R1 threshold
DISCOUNT_THRESHOLD = 0.25    # R3 threshold
LARGE_TIER_THRESHOLD = 50000 # Tier threshold


@dataclass
class CommissionResult:
    order_id: str
    order_type: str
    order_value: float
    gross_margin: float
    tier: str
    gm_band: str
    base_rate: float
    recurring_bonus: float
    discount_penalty: float
    final_rate: float
    commission_amount: float
    rules_applied: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "OrderID": self.order_id,
            "GrossMargin": round(self.gross_margin, 4),
            "Tier": self.tier,
            "GMBand": self.gm_band,
            "CommissionRate": round(self.final_rate, 4),
            "CommissionAmount": round(self.commission_amount, 2),
            "RulesApplied": self.rules_applied,
        }


def gross_margin(order_value: float, cogs: float) -> float:
    if order_value == 0:
        raise ValueError("OrderValue cannot be zero")
    return (order_value - cogs) / order_value


def tier_for(order_value: float) -> str:
    return "Large" if order_value >= LARGE_TIER_THRESHOLD else "Small"


def gm_band_for(gm: float) -> str:
    if gm < 0.20:
        return "Low"
    if gm <= 0.40:
        return "Medium"
    return "High"


def compute_commission(
    order_id: str,
    order_type: str,
    order_value: float,
    cogs: float,
    discount_pct: float,
    contract_months: int,
) -> CommissionResult:
    """Apply the full ruleset to a single order and return a structured result."""
    order_type = order_type.strip().capitalize()
    if order_type not in ("Order", "Recurring"):
        raise ValueError(f"Unknown order type: {order_type!r}")

    gm = gross_margin(order_value, cogs)
    tier = tier_for(order_value)
    band = gm_band_for(gm)
    rules: list[str] = []

    # R1 - loss-leader: GM strictly below 10% pays nothing.
    if gm < LOSS_LEADER_GM:
        rules.append("R1 (loss-leader: GM<10% -> 0)")
        return CommissionResult(
            order_id=order_id, order_type=order_type, order_value=order_value,
            gross_margin=gm, tier=tier, gm_band=band, base_rate=0.0,
            recurring_bonus=0.0, discount_penalty=0.0, final_rate=0.0,
            commission_amount=0.0, rules_applied=rules,
        )

    base_rate = RATE_MATRIX[(order_type, tier)][band]
    rules.append(f"matrix({order_type}/{tier}/{band}={base_rate:.3f})")

    bonus = 0.0
    if order_type == "Recurring" and contract_months >= 24:
        bonus = RECURRING_BONUS
        rules.append("R2 (recurring >=24mo: +0.5pp)")

    penalty = 0.0
    if discount_pct > DISCOUNT_THRESHOLD:
        penalty = DISCOUNT_PENALTY
        rules.append("R3 (discount>25%: -1pp)")

    final_rate = max(0.0, base_rate + bonus - penalty)
    commission = order_value * final_rate  # R4

    return CommissionResult(
        order_id=order_id, order_type=order_type, order_value=order_value,
        gross_margin=gm, tier=tier, gm_band=band, base_rate=base_rate,
        recurring_bonus=bonus, discount_penalty=penalty, final_rate=final_rate,
        commission_amount=commission, rules_applied=rules,
    )


def compute_batch(rows: list[dict]) -> list[CommissionResult]:
    """Compute commissions for a list of order dicts."""
    results = []
    for r in rows:
        results.append(
            compute_commission(
                order_id=str(r["OrderID"]),
                order_type=str(r["OrderType"]),
                order_value=float(r["OrderValue"]),
                cogs=float(r["COGS"]),
                discount_pct=float(r["DiscountPct"]),
                contract_months=int(r["ContractMonths"]),
            )
        )
    return results
