"""
Unit tests for the deterministic commission engine.

EXPECTED values here are derived strictly from the documented ruleset and the
Excel formula in the spec. They are the production source of truth.

NOTE: two rows in the spec's "Expected Results" table do not match its own
rules and are treated as errors in that table (see README "Known data issues"):
  - ORD005: spec shows 1.0% but its discount is 20% (not >25%), so no R3 penalty
            applies -> correct rate is 2.0%.
  - ORD006: spec shows tier Large but OrderValue 45000 < 50000 -> correct tier
            is Small -> correct rate 7.5%.
The asserts below use the rule-correct values.
"""

import pytest

from commission_engine import compute_commission

# OrderID -> (type, value, cogs, discount, months, expected_tier, expected_rate, expected_commission)
CASES = [
    ("ORD001", "Order",     75000, 45000, 0.10,  0, "Large", 0.040, 3000.00),
    ("ORD002", "Order",     12000,  9500, 0.05,  0, "Small", 0.025,  300.00),
    ("ORD003", "Recurring", 60000, 24000, 0.15, 36, "Large", 0.095, 5700.00),
    ("ORD004", "Recurring",  8000,  5500, 0.30, 12, "Small", 0.030,  240.00),
    ("ORD005", "Order",     95000, 80000, 0.20,  0, "Large", 0.020, 1900.00),
    ("ORD006", "Recurring", 45000, 18000, 0.10, 24, "Small", 0.075, 3375.00),
    ("ORD007", "Order",     30000, 15000, 0.08,  0, "Small", 0.045, 1350.00),
    ("ORD008", "Order",    110000, 99000, 0.05,  0, "Large", 0.020, 2200.00),
    ("ORD009", "Recurring", 25000, 10000, 0.28, 36, "Small", 0.065, 1625.00),
    ("ORD010", "Order",      5000,  4700, 0.02,  0, "Small", 0.000,    0.00),
    ("ORD011", "Recurring", 80000, 32000, 0.12, 48, "Large", 0.095, 7600.00),
    ("ORD012", "Order",     40000, 22000, 0.15,  0, "Small", 0.045, 1800.00),
    ("ORD013", "Recurring", 15000,  6000, 0.10, 18, "Small", 0.070, 1050.00),
    ("ORD014", "Order",     65000, 39000, 0.30,  0, "Large", 0.030, 1950.00),
    ("ORD015", "Recurring",  7500,  4500, 0.05, 24, "Small", 0.045,  337.50),
]


@pytest.mark.parametrize(
    "oid,otype,value,cogs,disc,months,exp_tier,exp_rate,exp_comm", CASES
)
def test_commission(oid, otype, value, cogs, disc, months, exp_tier, exp_rate, exp_comm):
    r = compute_commission(oid, otype, value, cogs, disc, months)
    assert r.tier == exp_tier, f"{oid} tier"
    assert round(r.final_rate, 4) == exp_rate, f"{oid} rate"
    assert round(r.commission_amount, 2) == exp_comm, f"{oid} commission"


def test_loss_leader_edge_exactly_10pct():
    # ORD008: GM is exactly 10% -> NOT a loss leader (rule is strictly < 10%).
    r = compute_commission("ORD008", "Order", 110000, 99000, 0.05, 0)
    assert r.final_rate == 0.020
    assert "R1" not in " ".join(r.rules_applied)


def test_discount_floor_never_negative():
    r = compute_commission("X", "Order", 60000, 50000, 0.99, 0)  # GM ~16.7% Low, big discount
    assert r.final_rate >= 0.0
