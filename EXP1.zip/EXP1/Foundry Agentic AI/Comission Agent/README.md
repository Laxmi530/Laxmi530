# Commission Processing — Agent Framework + Foundry (natural-language driven)

An agentic solution where the **input is natural language**: you point it at the
ruleset *document* (plain English) and the data workbook, and a **Magentic
orchestrator** coordinates four specialist agents to parse, compute, reconcile,
and explain. It exercises all five Agent Test Scenarios in the spec.

## Architecture

```
                  OrchestratorAgent (Magentic)  ->  plans / delegates / sums up
       ┌───────────────┬──────────────────┬──────────────────┐
 RuleParserAgent   CalculatorAgent   ReconciliationAgent  ExplanationAgent
 reads NL doc ->   applies parsed    reconcile vs          plain-English
 structured rules  ruleset to data   expected table        rule citations
 + self-check
       └───────────────┴──────────────────┘
                       v
           rule_interpreter.py  <- deterministic, config-driven, NO LLM math
           default_ruleset.json <- canonical rules (ground truth for the checker)
```

The LLM does the fuzzy part (natural language -> structured rules) and the prose
(explanations). The deterministic interpreter does every calculation. So if the
agent parses the rules correctly the math is exact and reproducible — and
reconciliation catches any parsing mistake.

## Files

| File | Purpose |
|------|---------|
| `rule_interpreter.py` | Deterministic interpreter. Applies *any* structured ruleset. |
| `default_ruleset.json` | Canonical ruleset = what a correct parse of the doc yields. |
| `rules_parsing.py` | Reads NL rules from the .docx; validates a parsed ruleset. |
| `commission_io.py` | Read workbook, calculate, reconcile, write — ruleset-driven. |
| `tools.py` | `@ai_function` wrappers exposing the above to the agents. |
| `agents_app.py` | Foundry client + 4 agents + Magentic orchestrator (NL-driven). |
| `run_engine.py` | Credential-free CLI to validate the core offline. |
| `test_rule_interpreter.py` | Unit tests (15 orders + edge case). |

## Local testing — step by step

### Step 0 — Validate the core offline (no credentials)

```
pip install openpyxl python-docx
python test_rule_interpreter.py                          # 15/15 + edge case
python run_engine.py /abs/Test_Workbook.xlsx /abs/Test_Doc.docx
```

`run_engine.py` reads the NL rules, runs the canonical self-check (accuracy 1.0),
computes all 15 orders, reconciles, and writes the filled workbook — proving the
deterministic layer before any LLM is involved.

### Step 1 — Install the full stack

```
pip install -r requirements.txt
```

### Step 2 — Authenticate + configure

```
az login
cp .env.example .env            # add FOUNDRY_PROJECT_ENDPOINT + FOUNDRY_MODEL
set -a && source .env && set +a
```

### Step 3 — Run with natural-language input

```
python agents_app.py /abs/Test_Doc.docx /abs/Test_Workbook.xlsx
```

The agents read the rules from the document (natural language) — nothing about
the rate matrix is hard-coded into the prompt.

## How each Agent Test Scenario is covered

| # | Scenario | How it is tested |
|---|----------|------------------|
| 1 | Parse rules from natural language | RuleParserAgent reads the .docx and emits a structured ruleset; `check_parsed_ruleset` scores it against the canonical ruleset (parse_accuracy must be 1.0). A wrong parse drops accuracy and lists the bad fields. |
| 2 | Apply conditional logic (R1/R2/R3) | Interpreter applies the *parsed* ruleset; unit tests assert all 15 rows. |
| 3 | Edge cases | ORD008 (GM exactly 10% -> not loss-leader -> 2.0%), ORD010 (6% -> R1 -> 0%), ORD004 (30% discount -> R3 -> 3.0%) are asserted and explained. |
| 4 | Reconciliation | `reconcile_with_spec` compares computed amounts to the doc's expected table cell-by-cell. |
| 5 | Explanation | ExplanationAgent justifies each commission from `rules_applied`, citing R1/R2/R3 and the matrix cell. |

### Things to try during testing

- Plain NL run: confirm parse_accuracy is 1.0.
- Parse robustness: reword the ruleset prose in the doc; confirm the parser still
  yields the same structured ruleset.
- Edge-case probe: after a run, ask "Explain ORD008, ORD010, and ORD004."
- Reconciliation: confirm the agent flags ORD005 and ORD006 (below).

## Known data issues (surfaced by reconciliation)

The doc's "Expected Results" table disagrees with its own rules on two rows:

- ORD005 — table shows 1.0%/$950, but discount is 20% (not > 25%), so R3 does not
  apply -> correct 2.0%/$1,900.
- ORD006 — table shows Large/$4,275, but OrderValue 45,000 < 50,000 -> Small ->
  7.5%/$3,375.

## Notes for production

- The interpreter is the trust boundary; review and FREEZE the parsed ruleset
  (save the validated JSON) before it drives real payouts.
- Extending the ruleset (multi-month aggregation, rep rollups, tiered
  accelerators) = add fields to `default_ruleset.json` + interpreter logic +
  tests; the agents need no change.

## Deploying to Foundry

After local tests pass, package the workflow as a Hosted agent and deploy with
`azd up`. The agent then appears under Build > Agents in the portal with a
playground and end-to-end traces. Deployment — not the endpoint in the code — is
what registers the agent in the portal.
