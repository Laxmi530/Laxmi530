"""
Multi-agent orchestration with Microsoft Agent Framework.

An orchestrator (the Magentic "manager") coordinates two specialist agents:
  - ResearcherAgent : gathers information, no math/code
  - CoderAgent      : writes and runs code for quantitative work

The manager plans the task, decides which agent acts next each round,
tracks progress, and synthesizes a single final answer.

Run:
    az login
    export FOUNDRY_PROJECT_ENDPOINT="https://<resource>.ai.azure.com/api/projects/<project>"
    export FOUNDRY_MODEL="gpt-5-mini"        # any deployed model in your project
    python magentic_orchestration.py
"""

import asyncio
import os

from agent_framework import Agent, AgentResponse, AgentResponseUpdate
from agent_framework.foundry import FoundryChatClient
from agent_framework.orchestrations import MagenticBuilder
from azure.identity import AzureCliCredential


def build_workflow():
    # 1. Connect to your Foundry project + model deployment.
    #    AzureCliCredential reuses the login from `az login`.
    client = FoundryChatClient(
        project_endpoint=os.environ["FOUNDRY_PROJECT_ENDPOINT"],
        model=os.environ["FOUNDRY_MODEL"],
        credential=AzureCliCredential(),
    )

    # 2. Specialist agent #1 — research only.
    researcher_agent = Agent(
        name="ResearcherAgent",
        description="Specialist in research and information gathering.",
        instructions=(
            "You are a researcher. Find relevant information. "
            "Do not perform calculations or write code."
        ),
        client=client,
    )

    # 3. Specialist agent #2 — code + execution.
    #    get_code_interpreter_tool() gives it a sandbox to run code in.
    coder_agent = Agent(
        name="CoderAgent",
        description="Writes and executes code to process and analyze data.",
        instructions=(
            "You solve quantitative questions by writing and running code. "
            "Show your analysis and computation clearly."
        ),
        client=client,
        tools=client.get_code_interpreter_tool(),
    )

    # 4. The orchestrator — the Magentic manager.
    #    It never does the work itself; it plans and delegates.
    manager_agent = Agent(
        name="OrchestratorAgent",
        description="Coordinates the research and coding agents.",
        instructions="You coordinate the team to complete complex tasks efficiently.",
        client=client,
    )

    # 5. Wire everyone into a Magentic workflow.
    workflow = MagenticBuilder(
        participants=[researcher_agent, coder_agent],
        intermediate_output_from=[researcher_agent, coder_agent],  # stream each agent's work
        manager_agent=manager_agent,
        max_round_count=10,   # hard cap on coordination rounds
        max_stall_count=3,    # consecutive no-progress rounds before the manager replans
        max_reset_count=2,    # max number of full plan resets
    ).build()

    return workflow


async def main():
    workflow = build_workflow()

    task = (
        "Compare the estimated training energy consumption of ResNet-50, "
        "BERT-base, and GPT-2, then estimate the relative CO2 emissions for each, "
        "and recommend the most energy-efficient model per task type. "
        "Provide a short table."
    )

    last_message_id = None
    final_response = None

    # stream=True lets you watch the orchestration unfold live.
    async for event in workflow.run(task, stream=True):
        # (a) Live token stream from whichever agent is currently speaking.
        if event.type == "output" and isinstance(event.data, AgentResponseUpdate):
            if event.data.message_id != last_message_id:
                if last_message_id is not None:
                    print("\n")
                print(f"- {event.executor_id}: ", end="", flush=True)
                last_message_id = event.data.message_id
            print(event.data, end="", flush=True)

        # (b) Orchestrator milestones: PLAN_CREATED / REPLANNED / PROGRESS_LEDGER_UPDATED.
        elif event.type == "magentic_orchestrator":
            print(f"\n[orchestrator] {event.data.event_type.name}")

        # (c) The manager's final synthesized answer (terminal output).
        elif event.type == "output" and isinstance(event.data, AgentResponse):
            final_response = event.data

    if final_response and final_response.messages:
        print("\n\n=== Final answer ===\n")
        print(final_response.messages[-1].text)


if __name__ == "__main__":
    asyncio.run(main())