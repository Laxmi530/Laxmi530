"""
Rule-parsing support (pure, no agent_framework).

- read_ruleset_text: pull the natural-language ruleset out of a .docx so the
  RuleParserAgent can read it as plain text (this is the natural-language input).
- check_parsed_ruleset: compare a parsed ruleset against the canonical one and
  report differences. This is how Test Scenario #1 ("parse rules from natural
  language") is scored objectively.
"""

from __future__ import annotations

import json

from docx import Document

from rule_interpreter import load_ruleset


def read_ruleset_text(path: str) -> str:
    """Extract paragraphs and tables from a .docx as a single text blob."""
    doc = Document(path)
    parts: list[str] = []
    for p in doc.paragraphs:
        if p.text.strip():
            parts.append(p.text)
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            parts.append(" | ".join(cells))
    return "\n".join(parts)


def _flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
        else:
            out[key] = v
    return out


def check_parsed_ruleset(parsed: dict) -> dict:
    """Diff a parsed ruleset against the canonical one. Empty diffs == perfect parse."""
    canonical = _flatten(load_ruleset())
    candidate = _flatten(parsed)
    diffs = []
    for key, want in canonical.items():
        got = candidate.get(key, "<missing>")
        if isinstance(want, float) and isinstance(got, (int, float)):
            ok = abs(float(got) - want) < 1e-9
        else:
            ok = got == want
        if not ok:
            diffs.append({"field": key, "expected": want, "parsed": got})
    extra = [k for k in candidate if k not in canonical]
    return {
        "fields_checked": len(canonical),
        "mismatch_count": len(diffs),
        "mismatches": diffs,
        "unexpected_fields": extra,
        "parse_accuracy": round(1 - len(diffs) / len(canonical), 3),
    }
