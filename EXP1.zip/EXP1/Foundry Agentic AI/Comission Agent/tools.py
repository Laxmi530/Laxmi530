"""
Function tools exposed to the agents (@ai_function wrappers).

Two groups:
  Rule parsing : read the NL document, validate a parsed ruleset.
  Calculation  : apply a parsed ruleset to the data, reconcile, write output.

All math is deterministic; the agents only decide WHEN to call these.
"""

from __future__ import annotations

import json
from typing import Annotated

from agent_framework import ai_function

import commission_io as cio
import rules_parsing as rp


@ai_function(
    name="read_ruleset_document",
    description=(
        "Read the natural-language commission ruleset from a .docx file and return "
        "it as plain text, including the rate-matrix table. Use this to obtain the "
        "rules before parsing them into structured form."
    ),
)
def read_ruleset_document(
    doc_path: Annotated[str, "Absolute path to the .docx ruleset document"],
) -> str:
    return rp.read_ruleset_text(doc_path)


@ai_function(
    name="check_parsed_ruleset",
    description=(
        "Validate a structured ruleset (as a JSON string) against the canonical "
        "ruleset. Returns parse accuracy and any mismatched fields. Use this to "
        "confirm the ruleset you extracted from natural language is correct."
    ),
)
def check_parsed_ruleset(
    ruleset_json: Annotated[str, "The parsed ruleset as a JSON object string"],
) -> str:
    return json.dumps(rp.check_parsed_ruleset(json.loads(ruleset_json)), indent=2)


@ai_function(
    name="calculate_commissions",
    description=(
        "Apply a structured ruleset (JSON string) to every order in the input Excel "
        "workbook and return a JSON array of per-order results (gross margin, tier, "
        "rate, amount, and rules applied). The ruleset must be the one parsed from "
        "the document."
    ),
)
def calculate_commissions(
    ruleset_json: Annotated[str, "The parsed ruleset as a JSON object string"],
    input_path: Annotated[str, "Absolute path to the input .xlsx workbook"],
) -> str:
    return json.dumps(cio.calculate(input_path, json.loads(ruleset_json)), indent=2)


@ai_function(
    name="reconcile_with_spec",
    description=(
        "Using a structured ruleset (JSON string), compute commissions for the input "
        "workbook and compare them against the specification's expected-results table. "
        "Returns every order whose computed amount differs from the expected amount."
    ),
)
def reconcile_with_spec(
    ruleset_json: Annotated[str, "The parsed ruleset as a JSON object string"],
    input_path: Annotated[str, "Absolute path to the input .xlsx workbook"],
) -> str:
    return json.dumps(cio.reconcile(input_path, json.loads(ruleset_json)), indent=2)


@ai_function(
    name="write_filled_workbook",
    description=(
        "Apply a structured ruleset (JSON string) and write a new workbook with the "
        "GrossMargin, Tier, CommissionRate, and CommissionAmount columns filled in. "
        "Returns the output path and number of rows written."
    ),
)
def write_filled_workbook(
    ruleset_json: Annotated[str, "The parsed ruleset as a JSON object string"],
    input_path: Annotated[str, "Absolute path to the input .xlsx workbook"],
    output_path: Annotated[str, "Absolute path for the filled output .xlsx workbook"],
) -> str:
    return json.dumps(cio.write_filled(input_path, output_path, json.loads(ruleset_json)))
