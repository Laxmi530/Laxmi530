"""
Commission processing solution — Microsoft Agent Framework + Foundry.

Natural-language driven: the orchestrator is given the path to the ruleset
DOCUMENT (plain English) and the data workbook, and the agents do the rest.

Agents
------
  RuleParserAgent     -> reads the NL ruleset, extracts a structured ruleset,
                         and self-checks it with check_parsed_ruleset   (Scenario 1)
  CalculatorAgent     -> applies the parsed ruleset to the data          (Scenario 2/3)
  ReconciliationAgent -> reconciles computed vs. spec expected           (Scenario 4)
  ExplanationAgent    -> justifies each commission with rule citations   (Scenario 5)
  OrchestratorAgent   -> Magentic manager: plans, delegates, synthesizes

The LLMs parse and explain; the deterministic interpreter behind the tools does
all arithmetic, so payouts are reproducible.

Run locally
-----------
    az login
    cp .env.example .env        # fill in values
    set -a && source .env && set +a
    python agents_app.py /abs/path/to/Test_Doc.docx /abs/path/to/Test_Workbook.xlsx
"""

from __future__ import annotations

import asyncio
import os
import sys

from agent_framework import Agent, AgentResponse, AgentResponseUpdate
from agent_framework.foundry import FoundryChatClient
from agent_framework.orchestrations import MagenticBuilder
from azure.identity import AzureCliCredential

from tools import (
    calculate_commissions,
    check_parsed_ruleset,
    read_ruleset_document,
    reconcile_with_spec,
    write_filled_workbook,
)

RULESET_SCHEMA_HINT = (
    'Emit the ruleset as JSON with exactly this shape: '
    '{"tier_threshold": <number>, '
    '"gm_band_thresholds": {"low_below": <fraction>, "medium_max": <fraction>}, '
    '"rate_matrix": {"Order": {"Large": {"Low":..,"Medium":..,"High":..}, "Small": {..}}, '
    '"Recurring": {"Large": {..}, "Small": {..}}}, '
    '"loss_leader_gm": <fraction>, '
    '"recurring_bonus": {"min_months": <int>, "amount": <fraction>}, '
    '"discount_penalty": {"threshold": <fraction>, "amount": <fraction>}}. '
    'Use fractions, not percents (4% -> 0.04).'
)


def build_workflow():
    client = FoundryChatClient(
        project_endpoint=os.environ["FOUNDRY_PROJECT_ENDPOINT"],
        model=os.environ["FOUNDRY_MODEL"],
        credential=AzureCliCredential(),
    )

    rule_parser_agent = Agent(
        name="RuleParserAgent",
        description="Extracts a structured ruleset from the natural-language document.",
        instructions=(
            "You read a commission ruleset written in natural language (including a "
            "rate-matrix table) and convert it into a structured JSON ruleset. "
            "First call read_ruleset_document on the provided document path. Then "
            "produce the JSON ruleset and call check_parsed_ruleset to verify it. If "
            "accuracy is below 1.0, fix the mismatched fields and check again. "
            "Output the final, validated ruleset JSON clearly. " + RULESET_SCHEMA_HINT
        ),
        client=client,
        tools=[read_ruleset_document, check_parsed_ruleset],
    )

    calculator_agent = Agent(
        name="CalculatorAgent",
        description="Applies the parsed ruleset to the data workbook.",
        instructions=(
            "You compute commissions. Take the validated ruleset JSON from the "
            "RuleParserAgent and call calculate_commissions and write_filled_workbook "
            "with it. Never do arithmetic yourself; report the tool output faithfully."
        ),
        client=client,
        tools=[calculate_commissions, write_filled_workbook],
    )

    reconciliation_agent = Agent(
        name="ReconciliationAgent",
        description="Reconciles computed commissions against the spec expected table.",
        instructions=(
            "You verify results. Call reconcile_with_spec with the validated ruleset "
            "JSON and the workbook path. For each mismatch, state which value follows "
            "the documented rules and whether the expected table contains a data error. "
            "Cite the specific rule."
        ),
        client=client,
        tools=[reconcile_with_spec],
    )

    explanation_agent = Agent(
        name="ExplanationAgent",
        description="Explains each commission in plain English with rule citations.",
        instructions=(
            "Using the computed results already in the conversation (with each order's "
            "rules_applied), write a short justification per order: tier, GM band, base "
            "rate, any R1/R2/R3 adjustment, final amount. Do not recompute numbers."
        ),
        client=client,
    )

    manager_agent = Agent(
        name="OrchestratorAgent",
        description="Coordinates parsing, calculation, reconciliation, and explanation.",
        instructions=(
            "Orchestrate end-to-end: first have RuleParserAgent extract and validate "
            "the ruleset from the document; pass that ruleset to CalculatorAgent to "
            "compute and write the filled workbook; have ReconciliationAgent check the "
            "results and flag discrepancies; have ExplanationAgent justify the outcomes. "
            "Synthesize a final report covering parse accuracy, results, discrepancies "
            "(with rule-based resolution), and explanations for the edge cases."
        ),
        client=client,
    )

    return MagenticBuilder(
        participants=[rule_parser_agent, calculator_agent, reconciliation_agent, explanation_agent],
        intermediate_output_from=[rule_parser_agent, calculator_agent, reconciliation_agent, explanation_agent],
        manager_agent=manager_agent,
        max_round_count=20,
        max_stall_count=3,
        max_reset_count=2,
    ).build()


async def main(doc_path: str, xlsx_path: str):
    workflow = build_workflow()
    output_path = xlsx_path.replace(".xlsx", "_filled.xlsx")

    # The INPUT is natural language: point the agents at the document and data.
    task = (
        f"The commission rules are described in natural language in the document at "
        f"'{doc_path}'. The sales orders are in the workbook at '{xlsx_path}'. "
        f"1) Parse the rules from the document into a structured ruleset and validate it. "
        f"2) Use that ruleset to compute every order's commission and write a filled "
        f"workbook to '{output_path}'. "
        f"3) Reconcile the computed amounts against the document's expected-results "
        f"table and flag any discrepancies, stating which value is correct per the rules. "
        f"4) Explain the edge cases (exactly-10%-GM, loss-leader, high-discount) with "
        f"rule citations. "
        f"Finish with a concise final report."
    )

    last_id = None
    final_response = None
    async for event in workflow.run(task, stream=True):
        if event.type == "output" and isinstance(event.data, AgentResponseUpdate):
            if event.data.message_id != last_id:
                if last_id is not None:
                    print("\n")
                print(f"- {event.executor_id}: ", end="", flush=True)
                last_id = event.data.message_id
            print(event.data, end="", flush=True)
        elif event.type == "magentic_orchestrator":
            print(f"\n[orchestrator] {event.data.event_type.name}")
        elif event.type == "output" and isinstance(event.data, AgentResponse):
            final_response = event.data

    if final_response and final_response.messages:
        print("\n\n=== Final report ===\n")
        print(final_response.messages[-1].text)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python agents_app.py /abs/path/Test_Doc.docx /abs/path/Test_Workbook.xlsx")
        raise SystemExit(1)
    asyncio.run(main(sys.argv[1], sys.argv[2]))
