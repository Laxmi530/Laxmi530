"""Unit tests for the deterministic interpreter, using the canonical ruleset.

Expected values are derived strictly from the documented rules. ORD005 and
ORD006 use the rule-correct values (the spec's expected table errs on these).
"""

from rule_interpreter import compute_commission, load_ruleset

RS = load_ruleset()

CASES = [
    ("ORD001", "Order",     75000, 45000, 0.10,  0, "Large", 0.040, 3000.00),
    ("ORD002", "Order",     12000,  9500, 0.05,  0, "Small", 0.025,  300.00),
    ("ORD003", "Recurring", 60000, 24000, 0.15, 36, "Large", 0.095, 5700.00),
    ("ORD004", "Recurring",  8000,  5500, 0.30, 12, "Small", 0.030,  240.00),
    ("ORD005", "Order",     95000, 80000, 0.20,  0, "Large", 0.020, 1900.00),
    ("ORD006", "Recurring", 45000, 18000, 0.10, 24, "Small", 0.075, 3375.00),
    ("ORD007", "Order",     30000, 15000, 0.08,  0, "Small", 0.045, 1350.00),
    ("ORD008", "Order",    110000, 99000, 0.05,  0, "Large", 0.020, 2200.00),
    ("ORD009", "Recurring", 25000, 10000, 0.28, 36, "Small", 0.065, 1625.00),
    ("ORD010", "Order",      5000,  4700, 0.02,  0, "Small", 0.000,    0.00),
    ("ORD011", "Recurring", 80000, 32000, 0.12, 48, "Large", 0.095, 7600.00),
    ("ORD012", "Order",     40000, 22000, 0.15,  0, "Small", 0.045, 1800.00),
    ("ORD013", "Recurring", 15000,  6000, 0.10, 18, "Small", 0.070, 1050.00),
    ("ORD014", "Order",     65000, 39000, 0.30,  0, "Large", 0.030, 1950.00),
    ("ORD015", "Recurring",  7500,  4500, 0.05, 24, "Small", 0.045,  337.50),
]


def _run():
    passed = 0
    for oid, ot, v, c, d, m, et, er, ec in CASES:
        order = {"OrderID": oid, "OrderType": ot, "OrderValue": v,
                 "COGS": c, "DiscountPct": d, "ContractMonths": m}
        r = compute_commission(order, RS)
        assert r.tier == et, (oid, "tier", r.tier, et)
        assert round(r.final_rate, 4) == er, (oid, "rate", r.final_rate, er)
        assert round(r.commission_amount, 2) == ec, (oid, "commission", r.commission_amount, ec)
        passed += 1
    # edge: exactly 10% GM is NOT a loss leader
    r8 = compute_commission(dict(zip(
        ["OrderID","OrderType","OrderValue","COGS","DiscountPct","ContractMonths"],
        ["ORD008","Order",110000,99000,0.05,0])), RS)
    assert r8.final_rate == 0.020 and "R1" not in " ".join(r8.rules_applied)
    print(f"ALL {passed}/15 interpreter assertions PASSED + edge case OK")


if __name__ == "__main__":
    _run()
