"""
Deterministic rule INTERPRETER.

Unlike a hard-coded engine, this applies whatever structured ruleset it is
given. The ruleset can be:
  - the canonical default_ruleset.json (known-good, for offline runs/tests), or
  - a ruleset the RuleParserAgent extracted from the natural-language document.

No LLM, no randomness: given a ruleset + an order, the output is reproducible.
This is the trust boundary. The agents parse and explain; this computes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_RULESET_PATH = Path(__file__).with_name("default_ruleset.json")


@dataclass
class CommissionResult:
    order_id: str
    order_type: str
    order_value: float
    gross_margin: float
    tier: str
    gm_band: str
    base_rate: float
    recurring_bonus: float
    discount_penalty: float
    final_rate: float
    commission_amount: float
    rules_applied: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "OrderID": self.order_id,
            "GrossMargin": round(self.gross_margin, 4),
            "Tier": self.tier,
            "GMBand": self.gm_band,
            "CommissionRate": round(self.final_rate, 4),
            "CommissionAmount": round(self.commission_amount, 2),
            "RulesApplied": self.rules_applied,
        }


def load_ruleset(path: str | Path = DEFAULT_RULESET_PATH) -> dict:
    with open(path) as f:
        return json.load(f)


def _gm_band(gm: float, rs: dict) -> str:
    t = rs["gm_band_thresholds"]
    if gm < t["low_below"]:
        return "Low"
    if gm <= t["medium_max"]:
        return "Medium"
    return "High"


def compute_commission(order: dict, rs: dict) -> CommissionResult:
    """Apply a structured ruleset `rs` to one order dict."""
    order_type = str(order["OrderType"]).strip().capitalize()
    order_value = float(order["OrderValue"])
    cogs = float(order["COGS"])
    discount = float(order["DiscountPct"])
    months = int(order["ContractMonths"])

    if order_value == 0:
        raise ValueError("OrderValue cannot be zero")
    gm = (order_value - cogs) / order_value
    tier = "Large" if order_value >= rs["tier_threshold"] else "Small"
    band = _gm_band(gm, rs)
    rules: list[str] = []

    # R1 loss-leader
    if gm < rs["loss_leader_gm"]:
        rules.append(f"R1 (GM<{rs['loss_leader_gm']:.0%} -> 0)")
        return CommissionResult(
            str(order["OrderID"]), order_type, order_value, gm, tier, band,
            0.0, 0.0, 0.0, 0.0, 0.0, rules,
        )

    base = rs["rate_matrix"][order_type][tier][band]
    rules.append(f"matrix({order_type}/{tier}/{band}={base})")

    bonus = 0.0
    rb = rs["recurring_bonus"]
    if order_type == "Recurring" and months >= rb["min_months"]:
        bonus = rb["amount"]
        rules.append(f"R2 (recurring>={rb['min_months']}mo:+{rb['amount']})")

    penalty = 0.0
    dp = rs["discount_penalty"]
    if discount > dp["threshold"]:
        penalty = dp["amount"]
        rules.append(f"R3 (discount>{dp['threshold']:.0%}:-{dp['amount']})")

    final_rate = max(0.0, base + bonus - penalty)
    commission = order_value * final_rate  # R4

    return CommissionResult(
        str(order["OrderID"]), order_type, order_value, gm, tier, band,
        base, bonus, penalty, final_rate, commission, rules,
    )


def compute_batch(orders: list[dict], rs: dict | None = None) -> list[CommissionResult]:
    rs = rs or load_ruleset()
    return [compute_commission(o, rs) for o in orders]
