from src.filtering import FilterCriteria, apply_filters, is_in_stock
from src.models import Product


def _p(
    name="P",
    rating=None,
    num_ratings=None,
    price=None,
    discount=None,
    availability=None,
    sponsored=None,
):
    return Product(
        name=name,
        marketplace="Amazon India",
        url=f"https://x.in/p/{name}",
        rating=rating,
        num_ratings=num_ratings,
        current_price=price,
        discount_percent=discount,
        availability=availability,
        is_sponsored=sponsored,
    )


def test_no_active_filters_returns_all():
    products = [_p(rating=3.0), _p(rating=4.5)]
    assert apply_filters(products, FilterCriteria()) == products


def test_min_rating_filters_and_excludes_unrated():
    products = [_p("a", rating=4.5), _p("b", rating=3.0), _p("c")]
    out = apply_filters(products, FilterCriteria(min_rating=4.0))
    assert [p.name for p in out] == ["a"]


def test_min_num_ratings():
    products = [_p("a", num_ratings=10), _p("b", num_ratings=5000)]
    out = apply_filters(products, FilterCriteria(min_num_ratings=1000))
    assert [p.name for p in out] == ["b"]


def test_price_range():
    products = [_p("a", price=100.0), _p("b", price=500.0), _p("c", price=2000.0)]
    out = apply_filters(products, FilterCriteria(min_price=200, max_price=1000))
    assert [p.name for p in out] == ["b"]


def test_min_discount():
    products = [_p("a", discount=10.0), _p("b", discount=55.0)]
    out = apply_filters(products, FilterCriteria(min_discount=50))
    assert [p.name for p in out] == ["b"]


def test_exclude_sponsored():
    products = [_p("a", sponsored=True), _p("b", sponsored=False)]
    out = apply_filters(products, FilterCriteria(exclude_sponsored=True))
    assert [p.name for p in out] == ["b"]


def test_in_stock_only():
    products = [
        _p("a", availability="In stock"),
        _p("b", availability="Currently unavailable"),
        _p("c", availability=None),
    ]
    out = apply_filters(products, FilterCriteria(in_stock_only=True))
    assert [p.name for p in out] == ["a"]


def test_is_in_stock_helper():
    assert is_in_stock(_p(availability="In stock")) is True
    assert is_in_stock(_p(availability="Out of stock")) is False
    assert is_in_stock(_p(availability=None)) is False
