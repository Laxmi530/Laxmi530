import pytest

from src import utils


@pytest.mark.parametrize(
    "url,expected",
    [
        # tracking params stripped
        ("https://www.amazon.in/dp/X?ref=a&tag=b", "https://www.amazon.in/dp/X"),
        # utm_* prefix stripped
        ("https://x.in/p?utm_source=g&utm_medium=cpc", "https://x.in/p"),
        # fragment + trailing slash removed
        ("https://x.in/p/1/#reviews", "https://x.in/p/1"),
        # meaningful param (pid) preserved
        (
            "https://www.flipkart.com/x/p/itm1?pid=ABC&ref=y",
            "https://www.flipkart.com/x/p/itm1?pid=ABC",
        ),
    ],
)
def test_normalize_url(url, expected):
    assert utils.normalize_url(url) == expected


def test_normalize_url_handles_none():
    assert utils.normalize_url(None) is None


@pytest.mark.parametrize(
    "url,ok",
    [
        ("https://www.amazon.in/dp/X", True),
        ("https://amazon.in/dp/X", True),
        ("https://www.flipkart.com/x/p/itm1", True),
        ("https://evil.example.com/steal", False),
        ("https://amazon.in.evil.com/x", False),  # suffix spoof rejected
        ("not a url", False),
    ],
)
def test_is_allowed_url(url, ok):
    assert utils.is_allowed_url(url) is ok


def test_amazon_asin_extraction():
    assert (
        utils.amazon_asin("https://www.amazon.in/dp/B0ABC12345?ref=x") == "B0ABC12345"
    )
    assert (
        utils.amazon_asin("https://www.amazon.in/gp/product/B0XYZ98765/")
        == "B0XYZ98765"
    )
    assert utils.amazon_asin("https://www.amazon.in/s?k=phone") is None


def test_flipkart_pid_extraction():
    assert (
        utils.flipkart_pid("https://www.flipkart.com/x/p/itm1?pid=MOBABC123&lid=1")
        == "MOBABC123"
    )
    assert utils.flipkart_pid("https://www.flipkart.com/x/p/itm1") is None
