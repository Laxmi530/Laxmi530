import sqlite3
from datetime import datetime

import pytest

from src.database import PriceHistoryDB
from src.models import Product


@pytest.fixture
def db(tmp_path):
    return PriceHistoryDB(tmp_path / "test.db")


def _p(price, when, pid="prod-1", is_sample=False):
    return Product(
        name="Widget",
        marketplace="Amazon India",
        url="https://x.com/p/1",
        product_id=pid,
        current_price=price,
        retrieved_at=when,
        is_sample=is_sample,
    )


def test_single_record_has_no_history(db):
    db.record_price(_p(100.0, datetime(2026, 1, 1)))
    stats = db.get_stats("prod-1")
    assert stats["record_count"] == 1
    assert stats["previous"] is None
    assert stats["pct_change"] is None


def test_aggregates_over_multiple_records(db):
    db.record_price(_p(100.0, datetime(2026, 1, 1)))
    db.record_price(_p(80.0, datetime(2026, 1, 2)))
    db.record_price(_p(120.0, datetime(2026, 1, 3)))
    stats = db.get_stats("prod-1")
    assert stats["record_count"] == 3
    assert stats["lowest"] == 80.0
    assert stats["highest"] == 120.0
    assert stats["average"] == 100.0
    assert stats["current"] == 120.0
    assert stats["previous"] == 80.0
    assert stats["pct_change"] == 50.0  # (120-80)/80


def test_sample_records_are_not_persisted(db):
    db.record_price(_p(100.0, datetime(2026, 1, 1), is_sample=True))
    assert db.total_records() == 0
    assert db.get_stats("prod-1") is None


def test_history_returns_ordered_dataframe(db):
    db.record_price(_p(120.0, datetime(2026, 1, 3)))
    db.record_price(_p(100.0, datetime(2026, 1, 1)))
    hist = db.get_history("prod-1")
    assert list(hist["current_price"]) == [100.0, 120.0]  # oldest first


def test_unknown_product_returns_none(db):
    assert db.get_stats("does-not-exist") is None


# --- de-duplication --------------------------------------------------------
def test_duplicate_within_window_is_skipped(db):
    t0 = datetime(2026, 1, 1, 10, 0, 0)
    t1 = datetime(2026, 1, 1, 10, 5, 0)  # 5 min later, same price
    assert db.record_price(_p(100.0, t0)) is True
    assert db.record_price(_p(100.0, t1)) is False
    assert db.total_records() == 1


def test_changed_price_is_always_stored(db):
    t0 = datetime(2026, 1, 1, 10, 0, 0)
    t1 = datetime(2026, 1, 1, 10, 5, 0)  # 5 min later, different price
    assert db.record_price(_p(100.0, t0)) is True
    assert db.record_price(_p(90.0, t1)) is True
    assert db.total_records() == 2


def test_same_price_outside_window_is_stored(db):
    t0 = datetime(2026, 1, 1, 10, 0, 0)
    t1 = datetime(2026, 1, 2, 10, 0, 0)  # next day, same price
    assert db.record_price(_p(100.0, t0)) is True
    assert db.record_price(_p(100.0, t1)) is True
    assert db.total_records() == 2


def test_record_many_returns_stored_count(db):
    t0 = datetime(2026, 1, 1, 10, 0, 0)
    t1 = datetime(2026, 1, 1, 10, 1, 0)
    products = [_p(100.0, t0), _p(100.0, t1)]  # 2nd is a dup within window
    assert db.record_many(products) == 1


# --- normalised schema -----------------------------------------------------
def test_schema_version_is_current(db):
    assert db.schema_version == 4


def test_product_upserted_once_across_observations(db):
    db.record_price(_p(100.0, datetime(2026, 1, 1)))
    db.record_price(_p(90.0, datetime(2026, 1, 2)))
    assert db.product_count() == 1
    assert db.total_observations() == 2


def test_observation_stores_rich_metadata(db):
    p = Product(
        name="Widget",
        marketplace="Amazon India",
        url="https://www.amazon.in/dp/B0AAA11111",
        product_id="prod-1",
        current_price=100.0,
        original_price=150.0,
        rating=4.5,
        num_ratings=1200,
        num_reviews=300,
        seller="Acme",
        availability="In stock",
        retrieved_at=datetime(2026, 1, 1),
    )
    db.record_price(p)
    hist = db.get_history("prod-1")
    row = hist.iloc[0]
    assert row["rating"] == 4.5
    assert row["num_ratings"] == 1200
    assert row["seller"] == "Acme"
    assert row["source"] == "live"


# --- search runs -----------------------------------------------------------
def test_run_lifecycle_and_tracked_searches(db):
    rid = db.start_run("Amazon India", "earbuds", "Live")
    db.finish_run(rid, "ok", result_count=5)
    # A failed run must not be surfaced as a tracked search.
    rid2 = db.start_run("Flipkart", "broken", "Live")
    db.finish_run(rid2, "failed", error="blocked")
    tracked = db.distinct_tracked_searches()
    assert ("Amazon India", "earbuds") in tracked
    assert ("Flipkart", "broken") not in tracked


def test_observation_links_to_run(db):
    rid = db.start_run("Amazon India", "earbuds", "Live")
    db.record_price(_p(100.0, datetime(2026, 1, 1)), run_id=rid)
    db.finish_run(rid, "ok", result_count=1)
    assert db.total_observations() == 1


# --- migration from legacy single-table schema ----------------------------
def test_migrates_legacy_price_records(tmp_path):
    path = tmp_path / "legacy.db"
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE price_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id TEXT, marketplace TEXT, product_name TEXT,
            current_price REAL, product_url TEXT, retrieved_at TEXT
        );
        """
    )
    conn.execute(
        "INSERT INTO price_records "
        "(product_id, marketplace, product_name, current_price, "
        " product_url, retrieved_at) VALUES (?, ?, ?, ?, ?, ?)",
        (
            "AMZ:OLD1",
            "Amazon India",
            "Old Widget",
            499.0,
            "https://www.amazon.in/dp/OLD1",
            "2026-01-01T00:00:00",
        ),
    )
    conn.commit()
    conn.close()

    db = PriceHistoryDB(path)  # opening triggers migration
    assert db.schema_version == 4
    assert db.product_count() == 1
    assert db.total_observations() == 1
    stats = db.get_stats("AMZ:OLD1")
    assert stats["current"] == 499.0
    # Legacy table is dropped after migration.
    with db._connect() as c:
        exists = c.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name='price_records'"
        ).fetchone()
    assert exists is None


# --- variant persistence & parser-quality metrics (schema v3) -------------
def test_variant_fields_persisted(db):
    p = Product(
        name="Phone",
        marketplace="Amazon India",
        url="https://www.amazon.in/dp/B0VAR11111",
        product_id="prod-var",
        current_price=59999.0,
        storage="256 GB",
        color="Black",
        variant_name="256 GB, Black",
        pack_size=1,
        retrieved_at=datetime(2026, 1, 1),
    )
    db.record_price(p)
    with db._connect() as c:
        row = c.execute(
            "SELECT storage, color, variant_name, pack_size "
            "FROM products WHERE id = ?",
            ("prod-var",),
        ).fetchone()
    assert row["storage"] == "256 GB"
    assert row["variant_name"] == "256 GB, Black"
    assert row["pack_size"] == 1


def test_parser_quality_rates(db):
    db.record_parse_metrics(
        marketplace="Amazon India",
        counts={"current_price": 9, "rating": 3},
        total=10,
    )
    pq = db.parser_quality()
    price_row = pq[pq["field"] == "current_price"].iloc[0]
    rating_row = pq[pq["field"] == "rating"].iloc[0]
    assert price_row["rate"] == 0.9
    assert rating_row["rate"] == 0.3


def test_parser_quality_empty(db):
    assert db.parser_quality().empty


# --- anomaly quality + stronger aggregates (schema v4) --------------------
def _pp(price, when, pid="prod-agg"):
    return Product(
        name="Widget",
        marketplace="Amazon India",
        url="https://www.amazon.in/dp/B0AGG00001",
        product_id=pid,
        current_price=price,
        availability="In stock",
        retrieved_at=when,
    )


def test_anomaly_excluded_from_aggregates(db):
    # Stable ~1000 history, then one absurd spike that must be flagged.
    base = datetime(2026, 1, 1)
    for i, price in enumerate([1000.0, 1000.0, 1000.0, 1000.0]):
        db.record_price(_pp(price, base.replace(day=i + 1)))
    db.record_price(_pp(99999.0, base.replace(day=6)))  # spike -> suspected

    stats = db.get_stats("prod-agg")
    assert stats["anomalies"] == 1
    assert stats["highest"] == 1000.0  # spike excluded from aggregates
    assert stats["average"] == 1000.0
    assert stats["current"] == 99999.0  # but current still reflects latest


def test_stronger_aggregates(db):
    base = datetime(2026, 1, 1)
    db.record_price(_pp(100.0, base.replace(day=1)))
    db.record_price(_pp(100.0, base.replace(day=2)))  # dup price (no change)
    db.record_price(_pp(120.0, base.replace(day=3)))  # a change
    stats = db.get_stats("prod-agg")
    assert stats["num_checks"] == 3
    assert stats["num_changes"] == 1  # only 100 -> 120
    assert stats["median"] == 100.0
    assert stats["in_stock_pct"] == 100.0


def test_out_of_stock_reduces_in_stock_pct(db):
    base = datetime(2026, 1, 1)
    db.record_price(_pp(100.0, base.replace(day=1)))
    p2 = _pp(100.0, base.replace(day=2))
    p2.availability = "Currently unavailable"
    db.record_price(p2)
    # dedup: same price within window would skip; use a day gap + price change
    p3 = _pp(150.0, base.replace(day=3))
    p3.availability = "Currently unavailable"
    db.record_price(p3)
    stats = db.get_stats("prod-agg")
    assert stats["in_stock_pct"] < 100.0
