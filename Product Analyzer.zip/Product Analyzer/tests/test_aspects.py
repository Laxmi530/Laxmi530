import pytest

from src import aspects, config
from src.scrapers import sample_data


# --- count parsing ---------------------------------------------------------
@pytest.mark.parametrize(
    "text,expected",
    [
        ("1.7K", 1700),
        ("1.4K", 1400),
        ("652", 652),
        ("1,234", 1234),
        ("2K+", 2000),
        ("10,647", 10647),
        ("1.2M", 1_200_000),
        (None, None),
        ("", None),
    ],
)
def test_parse_count(text, expected):
    assert aspects.parse_count(text) == expected


@pytest.mark.parametrize(
    "rating,expected",
    [(4.5, "positive"), (4.0, "positive"), (3.5, "mixed"), (2.1, "negative")],
)
def test_sentiment_from_rating(rating, expected):
    assert aspects.sentiment_from_rating(rating) == expected


# --- Amazon aspect parsing -------------------------------------------------
_AMAZON_ASPECTS_HTML = """
<div data-hook="cr-insights-widget">
  <a data-hook="cr-insights-aspect" data-aspect-sentiment="positive">
    <span class="aspect-name">Quality</span><span class="aspect-count">1.7K</span>
  </a>
  <a data-hook="cr-insights-aspect" data-aspect-sentiment="positive">
    <span class="aspect-name">Sound quality</span><span class="aspect-count">1.4K</span>
  </a>
  <a data-hook="cr-insights-aspect" data-aspect-sentiment="mixed">
    <span class="aspect-name">Reliability</span><span class="aspect-count">540</span>
  </a>
</div>
"""


def test_parse_amazon_aspects():
    result = aspects.parse_amazon_aspects(_AMAZON_ASPECTS_HTML)
    assert len(result) == 3
    quality = result[0]
    assert quality.name == "Quality"
    assert quality.count == 1700
    assert quality.sentiment == "positive"
    assert result[2].name == "Reliability"
    assert result[2].sentiment == "mixed"
    assert result[2].count == 540


def test_parse_amazon_aspects_text_fallback():
    html = '<a class="cr-insights-aspect">Battery life (652)</a>'
    result = aspects.parse_amazon_aspects(html)
    assert result[0].name == "Battery life"
    assert result[0].count == 652


# --- Flipkart aspect parsing ----------------------------------------------
_FLIPKART_ASPECTS_HTML = """
<div>
  <div class="aspect-rating">
    <span class="aspect-name">Sound Quality</span><span class="aspect-value">4</span>
  </div>
  <div class="aspect-rating">
    <span class="aspect-name">Value for Money</span><span class="aspect-value">3.9</span>
  </div>
  <div class="aspect-rating">
    <span class="aspect-name">Call Quality</span><span class="aspect-value">5</span>
  </div>
</div>
"""


def test_parse_flipkart_aspects():
    result = aspects.parse_flipkart_aspects(_FLIPKART_ASPECTS_HTML)
    assert len(result) == 3
    assert result[0].name == "Sound Quality"
    assert result[0].rating == 4.0
    assert result[0].sentiment == "positive"
    value = result[1]
    assert value.name == "Value for Money"
    assert value.rating == 3.9
    assert value.sentiment == "mixed"


# --- sample data -----------------------------------------------------------
def test_sample_amazon_aspects_have_counts():
    p = sample_data.generate(config.MARKETPLACE_AMAZON, "earbuds", 1)[0]
    assert p.aspects
    assert all(a.count is not None for a in p.aspects)
    assert any(a.name == "Battery life" for a in p.aspects)


def test_sample_flipkart_aspects_have_ratings():
    p = sample_data.generate(config.MARKETPLACE_FLIPKART, "shoes", 1)[0]
    assert p.aspects
    assert all(a.rating is not None for a in p.aspects)


def test_sample_myntra_aspects_have_ratings():
    p = sample_data.generate(config.MARKETPLACE_MYNTRA, "tshirt", 1)[0]
    assert p.aspects
    assert all(0 <= a.rating <= 5 for a in p.aspects)
