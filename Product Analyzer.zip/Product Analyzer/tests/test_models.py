from datetime import datetime

from src import config
from src.models import Product


def test_same_marketplace_and_url_give_same_id():
    p1 = Product(
        name="A", marketplace="Amazon India", url="https://www.amazon.in/dp/X?ref=a"
    )
    p2 = Product(
        name="B", marketplace="Amazon India", url="https://www.amazon.in/dp/X?tag=b"
    )
    # Tracking params are stripped before ID derivation -> stable id.
    assert p1.product_id == p2.product_id


def test_different_marketplace_gives_different_id():
    p1 = Product(name="A", marketplace="Amazon India", url="https://x.in/p/1")
    p2 = Product(name="A", marketplace="Flipkart", url="https://x.in/p/1")
    assert p1.product_id != p2.product_id


def test_native_id_produces_canonical_id():
    p = Product(
        name="A",
        marketplace="Amazon India",
        url="https://www.amazon.in/dp/B0ABC12345",
        native_id="B0ABC12345",
    )
    assert p.product_id == "AMZ:B0ABC12345"


def test_url_is_normalized_on_construction():
    p = Product(
        name="A",
        marketplace="Amazon India",
        url="https://www.amazon.in/dp/X/?ref=nav_logo#frag",
    )
    assert p.url == "https://www.amazon.in/dp/X"


def test_sample_flag_sets_source():
    p = Product(name="A", marketplace="Amazon India", url="u", is_sample=True)
    assert p.source == "sample"


def test_discount_derived_from_prices():
    p = Product(
        name="A",
        marketplace="Amazon India",
        url="u",
        current_price=800.0,
        original_price=1000.0,
    )
    assert p.discount_percent == 20.0


def test_discount_not_derived_when_no_original():
    p = Product(name="A", marketplace="Amazon India", url="u", current_price=800.0)
    assert p.discount_percent is None


def test_monthly_purchases_display_falls_back():
    p = Product(name="A", marketplace="Amazon India", url="u")
    assert p.monthly_purchases_display == config.NOT_AVAILABLE
    p.monthly_purchases = "1K+ bought in past month"
    assert p.monthly_purchases_display == "1K+ bought in past month"


def test_to_dict_serialises_timestamp():
    p = Product(
        name="A",
        marketplace="Amazon India",
        url="u",
        retrieved_at=datetime(2026, 1, 2, 3, 4, 5),
    )
    assert p.to_dict()["retrieved_at"] == "2026-01-02T03:04:05"
