import pytest

from src.database import LockUnavailable, PriceHistoryDB


@pytest.fixture
def db(tmp_path):
    return PriceHistoryDB(tmp_path / "locks.db")


def test_acquire_and_second_owner_blocked(db):
    assert db.acquire_lock("job", "owner-a", 3600) is True
    assert db.acquire_lock("job", "owner-b", 3600) is False


def test_release_allows_reacquire(db):
    db.acquire_lock("job", "owner-a", 3600)
    db.release_lock("job", "owner-a")
    assert db.acquire_lock("job", "owner-b", 3600) is True


def test_expired_lock_is_recovered(db):
    # TTL 0 -> expires immediately; the next acquire should recover it.
    db.acquire_lock("job", "owner-a", 0)
    assert db.acquire_lock("job", "owner-b", 3600) is True


def test_job_lock_context_manager(db):
    with db.job_lock("job", "owner-a", 3600):
        # While held, another owner cannot acquire it.
        assert db.acquire_lock("job", "owner-b", 3600) is False
    # Released on exit.
    assert db.acquire_lock("job", "owner-b", 3600) is True


def test_job_lock_raises_when_held(db):
    db.acquire_lock("job", "owner-a", 3600)
    with pytest.raises(LockUnavailable), db.job_lock("job", "owner-b", 3600):
        pass
