import pytest

from src import validation
from src.models import Product


def _p(
    name="Sony WF Wireless Earbuds",
    url="https://www.amazon.in/dp/B0AAA11111",
    is_sample=False,
    **kw,
):
    return Product(
        name=name, marketplace="Amazon India", url=url, is_sample=is_sample, **kw
    )


# --- relevance -------------------------------------------------------------
@pytest.mark.parametrize(
    "query,title,expected_min",
    [
        ("wireless earbuds", "Sony Wireless Earbuds Pro", 0.99),  # both tokens
        ("wireless earbuds", "Sony Earbuds", 0.49),  # one of two
        ("earbuds", "Laptop Stand Aluminium", 0.0),  # none
    ],
)
def test_relevance_score(query, title, expected_min):
    assert validation.relevance_score(query, title) >= expected_min


def test_relevance_empty_query_matches_everything():
    assert validation.relevance_score("", "anything") == 1.0


# --- validation ------------------------------------------------------------
def test_valid_product_has_no_issues():
    result = validation.validate_product(_p(), "wireless earbuds")
    assert result.is_sane
    assert result.relevance >= 0.99


def test_rating_out_of_range_flagged():
    result = validation.validate_product(_p(rating=7.0), "earbuds")
    assert not result.is_sane
    assert "rating out of range" in result.issues


def test_non_positive_price_flagged():
    result = validation.validate_product(_p(current_price=0.0), "earbuds")
    assert "non-positive price" in result.issues


def test_mrp_below_price_flagged():
    result = validation.validate_product(
        _p(current_price=1000.0, original_price=800.0), "earbuds"
    )
    assert "MRP below current price" in result.issues


def test_disallowed_url_flagged_for_live_product():
    result = validation.validate_product(
        _p(url="https://evil.example.com/x"), "earbuds"
    )
    assert "disallowed URL" in result.issues


def test_sample_product_url_not_penalised():
    result = validation.validate_product(
        _p(url="https://example.com/demo", is_sample=True), "earbuds"
    )
    assert result.is_sane


# --- cleaning --------------------------------------------------------------
def test_clean_results_drops_offtopic_and_dedupes():
    good = _p(name="Wireless Earbuds Pro", url="https://www.amazon.in/dp/B0AAA11111")
    dup = _p(
        name="Wireless Earbuds Pro (dup listing)",
        url="https://www.amazon.in/dp/B0AAA11111",
    )  # same canonical id
    offtopic = _p(name="Kitchen Knife Set", url="https://www.amazon.in/dp/B0BBB22222")

    kept, dropped = validation.clean_results([good, dup, offtopic], "wireless earbuds")
    kept_ids = [p.product_id for p in kept]
    assert good.product_id in kept_ids
    assert len(kept) == 1
    reasons = {reason for _p_, reason in dropped}
    assert "duplicate" in reasons
    assert any("off-topic" in r for r in reasons)


def test_clean_results_sets_relevance_score():
    p = _p(name="Wireless Earbuds")
    kept, _ = validation.clean_results([p], "wireless earbuds")
    assert kept[0].relevance_score is not None
