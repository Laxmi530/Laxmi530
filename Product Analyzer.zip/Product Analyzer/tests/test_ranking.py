from src.models import Product
from src.ranking import compute_scores, rank_products, weighted_rating


def _p(
    name, rating=None, num_ratings=None, num_reviews=None, price=None, discount=None
):
    return Product(
        name=name,
        marketplace="Amazon India",
        url=f"https://x.in/p/{name}",
        rating=rating,
        num_ratings=num_ratings,
        num_reviews=num_reviews,
        current_price=price,
        discount_percent=discount,
    )


# --- rating mode -----------------------------------------------------------
def test_rating_mode_orders_by_rating_desc():
    products = [_p("low", 3.0), _p("high", 4.8), _p("mid", 4.0)]
    ranked = rank_products(products, mode="rating")
    assert [p.name for p in ranked] == ["high", "mid", "low"]


def test_rating_mode_ties_broken_by_num_ratings():
    products = [_p("fewer", 4.5, 100), _p("more", 4.5, 5000)]
    ranked = rank_products(products, mode="rating")
    assert [p.name for p in ranked] == ["more", "fewer"]


def test_rating_mode_ties_broken_by_reviews():
    products = [_p("a", 4.5, 100, 10), _p("b", 4.5, 100, 90)]
    ranked = rank_products(products, mode="rating")
    assert [p.name for p in ranked] == ["b", "a"]


def test_unrated_products_sink_to_bottom():
    products = [_p("unrated"), _p("rated", 3.1)]
    ranked = rank_products(products, mode="rating")
    assert ranked[-1].name == "unrated"


# --- weighted mode ---------------------------------------------------------
def test_weighted_mode_penalises_low_sample_size():
    # In a realistic result set (mean well below 5), a 5.0 from 2 users should
    # NOT beat a 4.7 from 50,000. Filler products pull the Bayesian prior down.
    popular = _p("popular", 4.7, num_ratings=50_000)
    niche = _p("niche", 5.0, num_ratings=2)
    filler = [_p(f"f{i}", 3.8, num_ratings=500) for i in range(8)]
    ranked = rank_products([niche, popular, *filler], mode="weighted")
    assert ranked.index(popular) < ranked.index(niche)

    # By contrast, raw-rating mode would rank the niche 5.0 first.
    ranked_raw = rank_products([niche, popular, *filler], mode="rating")
    assert ranked_raw[0].name == "niche"


def test_weighted_rating_between_rating_and_mean():
    p = _p("x", 5.0, num_ratings=1)
    score = weighted_rating(p, mean=4.0, m=50)
    assert 4.0 < score < 5.0


def test_compute_scores_attaches_attribute():
    products = [_p("a", 4.0, 100), _p("b", 4.5, 200)]
    compute_scores(products)
    assert all(hasattr(p, "weighted_score") for p in products)


# --- other modes -----------------------------------------------------------
def test_price_low_mode():
    products = [_p("exp", price=999.0), _p("cheap", price=199.0), _p("noprice")]
    ranked = rank_products(products, mode="price_low")
    assert ranked[0].name == "cheap"
    assert ranked[-1].name == "noprice"  # missing price sorts last


def test_discount_mode():
    products = [_p("a", discount=10.0), _p("b", discount=60.0)]
    ranked = rank_products(products, mode="discount")
    assert ranked[0].name == "b"


def test_popular_mode():
    products = [_p("a", 4.0, 100), _p("b", 3.0, 9999)]
    ranked = rank_products(products, mode="popular")
    assert ranked[0].name == "b"


def test_relevance_mode_prefers_on_topic():
    on_topic = _p("match", 4.5, num_ratings=1000)
    on_topic.relevance_score = 1.0
    off_topic = _p("other", 4.9, num_ratings=1000)
    off_topic.relevance_score = 0.1
    ranked = rank_products([off_topic, on_topic], mode="relevance")
    assert ranked[0].name == "match"


def test_limit_truncates():
    products = [_p(str(i), rating=float(i)) for i in range(5)]
    assert len(rank_products(products, limit=3, mode="rating")) == 3
