import json
import logging

import pytest
import requests

from src import diagnostics
from src.database import PriceHistoryDB
from src.logging_config import JsonFormatter, configure_logging, get_logger


# --- classification --------------------------------------------------------
@pytest.mark.parametrize(
    "status,expected",
    [
        (200, "ok"),
        (403, "blocked"),
        (429, "blocked"),
        (503, "blocked"),
        (529, "blocked"),  # Flipkart "overloaded" bot-shedding status
        (500, "server_error"),
        (404, "not_found"),
        (418, "http_418"),
    ],
)
def test_classify_http_status(status, expected):
    assert diagnostics.classify_http(status, None) == expected


def test_classify_http_exceptions():
    assert diagnostics.classify_http(None, requests.Timeout()) == "timeout"
    assert diagnostics.classify_http(None, requests.ConnectionError()) == "network"


@pytest.mark.parametrize(
    "text,expected",
    [
        ("Amazon returned HTTP 503", "blocked"),
        ("request timed out", "timeout"),
        ("Amazon layout not recognised (blocked?)", "blocked"),
        ("No parsable products found", "empty_or_parse"),
        ("Refusing to fetch disallowed URL", "disallowed_url"),
        ("something odd", "other"),
    ],
)
def test_classify_run_error(text, expected):
    assert diagnostics.classify_run_error(text) == expected


# --- DB event recording + summary -----------------------------------------
@pytest.fixture
def db(tmp_path):
    return PriceHistoryDB(tmp_path / "diag.db")


def test_schema_migrated_to_current(db):
    assert db.schema_version == 4


def _event(db, **kw):
    base = dict(
        marketplace="Amazon India",
        query="x",
        url="https://a.in/s",
        status_code=200,
        ok=True,
        error_type="ok",
        retry_count=0,
        duration_ms=100,
    )
    base.update(kw)
    db.record_http_event(**base)


def test_diagnostics_summary_aggregates(db):
    _event(db, status_code=200, ok=True, error_type="ok", duration_ms=100)
    _event(db, status_code=503, ok=False, error_type="blocked", duration_ms=300)
    summary = db.diagnostics_summary()
    assert summary["total_requests"] == 2
    assert summary["http_success_rate"] == 0.5
    assert summary["blocked_rate"] == 0.5
    assert summary["avg_response_ms"] == 200


def test_diagnostics_search_rates(db):
    r1 = db.start_run("Amazon India", "earbuds", "Live")
    db.finish_run(r1, "ok", result_count=5)
    r2 = db.start_run("Amazon India", "nothing", "Live")
    db.finish_run(r2, "ok", result_count=0)  # empty
    r3 = db.start_run("Flipkart", "boom", "Live")
    db.finish_run(r3, "failed", error="blocked")
    summary = db.diagnostics_summary()
    assert summary["total_searches"] == 3
    assert summary["search_success_rate"] == round(2 / 3, 3)
    assert summary["empty_result_rate"] == 0.5  # 1 of 2 ok runs empty
    assert summary["last_successful_retrieval"] is not None


def test_distributions(db):
    _event(db, status_code=200, error_type="ok")
    _event(db, status_code=503, ok=False, error_type="blocked")
    _event(db, status_code=503, ok=False, error_type="blocked")
    status = db.http_status_distribution()
    assert set(status["value"]) == {200, 503}
    errors = db.error_type_distribution()
    blocked = errors[errors["value"] == "blocked"]["count"].iloc[0]
    assert int(blocked) == 2


def test_empty_diagnostics(db):
    summary = db.diagnostics_summary()
    assert summary["total_requests"] == 0
    assert summary["http_success_rate"] is None


# --- structured logging ----------------------------------------------------
def test_json_formatter_includes_extra_fields():
    formatter = JsonFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="http_fetch",
        args=(),
        exc_info=None,
    )
    record.marketplace = "Amazon India"
    record.status_code = 503
    record.duration_ms = 250
    payload = json.loads(formatter.format(record))
    assert payload["message"] == "http_fetch"
    assert payload["marketplace"] == "Amazon India"
    assert payload["status_code"] == 503
    assert payload["level"] == "INFO"


def test_configure_logging_is_idempotent():
    logger = configure_logging()
    count = len(logger.handlers)
    configure_logging()
    assert len(logger.handlers) == count  # no duplicate handlers


def test_get_logger_is_child_of_app_logger():
    assert get_logger("scraper").name == "product_analyzer.scraper"
