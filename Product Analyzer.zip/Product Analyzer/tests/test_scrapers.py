import pytest

from src import config, scrapers
from src.scrapers import sample_data
from src.scrapers.amazon import AmazonIndiaScraper
from src.scrapers.base import BaseScraper, ScraperError


# --- parsing helpers -------------------------------------------------------
@pytest.mark.parametrize(
    "text,expected",
    [
        ("₹1,299.00", 1299.0),
        ("Rs. 499", 499.0),
        ("", None),
        (None, None),
        ("no digits", None),
    ],
)
def test_parse_price(text, expected):
    assert BaseScraper.parse_price(text) == expected


@pytest.mark.parametrize(
    "text,expected",
    [
        ("4.3 out of 5 stars", 4.3),
        ("5.0", 5.0),
        ("7.0 out of 5", None),  # out of range
        (None, None),
    ],
)
def test_parse_rating(text, expected):
    assert BaseScraper.parse_rating(text) == expected


def test_parse_int_strips_commas():
    assert BaseScraper.parse_int("12,345 ratings") == 12345


@pytest.mark.parametrize(
    "text,expected",
    [
        ("2K+ bought in past month", "2K+ bought in past month"),
        ("1,000+ purchased in the past month", "1,000+ purchased in the past month"),
        ("Great product, top seller", None),
        (None, None),
    ],
)
def test_extract_monthly_purchases(text, expected):
    assert BaseScraper.extract_monthly_purchases(text) == expected


# --- Amazon HTML parsing ---------------------------------------------------
_AMAZON_HTML = """
<html><body>
<div data-component-type="s-search-result" data-asin="B0TEST123">
  <h2><a href="/dp/B0TEST123?ref=x"><span>Test Earbuds Pro</span></a></h2>
  <img class="s-image" src="https://img/test.jpg"/>
  <span class="a-price"><span class="a-offscreen">₹1,499</span></span>
  <span class="a-price a-text-price"><span class="a-offscreen">₹2,999</span></span>
  <span class="a-icon-alt">4.4 out of 5 stars</span>
  <span class="a-size-base s-underline-text">3,210</span>
  <div>2K+ bought in past month</div>
</div>
</body></html>
"""


def test_amazon_parse_search_extracts_fields():
    scraper = AmazonIndiaScraper()
    products = scraper.parse_search(_AMAZON_HTML, limit=10)
    assert len(products) == 1
    p = products[0]
    assert p.name == "Test Earbuds Pro"
    assert p.native_id == "B0TEST123"
    assert p.product_id == "AMZ:B0TEST123"  # marketplace + native id
    assert p.current_price == 1499.0
    assert p.original_price == 2999.0
    assert p.rating == 4.4
    assert p.num_ratings == 3210
    assert p.discount_percent == 50.0  # derived
    assert p.monthly_purchases == "2K+ bought in past month"
    assert "?" not in p.url
    assert p.is_sponsored is False


_AMAZON_SPONSORED_HTML = """
<html><body>
<div data-component-type="s-search-result" data-asin="B0SPON0001">
  <span class="puis-sponsored-label-text">Sponsored</span>
  <h2><a href="/dp/B0SPON0001"><span>Promoted Earbuds</span></a></h2>
  <span class="a-price"><span class="a-offscreen">₹999</span></span>
  <span class="a-icon-alt">4.1 out of 5 stars</span>
</div>
</body></html>
"""


def test_amazon_detects_sponsored():
    products = AmazonIndiaScraper().parse_search(_AMAZON_SPONSORED_HTML, limit=10)
    assert products[0].is_sponsored is True


def test_amazon_parse_search_raises_on_unrecognised_html():
    scraper = AmazonIndiaScraper()
    with pytest.raises(ScraperError):
        scraper.parse_search("<html><body>blocked</body></html>", limit=10)


_AMAZON_UNPARSEABLE_PRICE_HTML = """
<html><body>
<div data-component-type="s-search-result" data-asin="B0BADP0001">
  <h2><a href="/dp/B0BADP0001"><span>Weird Price Earbuds</span></a></h2>
  <span class="a-price"><span class="a-offscreen">Currently unavailable</span></span>
  <span class="a-icon-alt">4.2 out of 5 stars</span>
</div>
</body></html>
"""


def test_amazon_flags_parse_failed_provenance():
    from src.provenance import FieldStatus

    products = AmazonIndiaScraper().parse_search(
        _AMAZON_UNPARSEABLE_PRICE_HTML, limit=10
    )
    p = products[0]
    assert p.current_price is None
    # Value was present on the page but unparseable -> PARSE_FAILED (not
    # NOT_PRESENT), so the UI can tell them apart.
    assert p.field_status("current_price") == FieldStatus.PARSE_FAILED
    assert p.field_status("rating") == FieldStatus.SUCCESS


# --- sample data -----------------------------------------------------------
def test_sample_data_is_deterministic_and_labelled():
    a = sample_data.generate(config.MARKETPLACE_AMAZON, "earbuds", 10)
    b = sample_data.generate(config.MARKETPLACE_AMAZON, "earbuds", 10)
    assert len(a) == 10
    assert all(p.is_sample and p.source == config.SOURCE_SAMPLE for p in a)
    assert [p.name for p in a] == [p.name for p in b]  # deterministic
    assert all(0 <= p.rating <= 5 for p in a)


def test_sample_data_has_variant_fields():
    products = sample_data.generate(config.MARKETPLACE_AMAZON, "phone", 5)
    assert all(p.variant_name and p.storage and p.color for p in products)


def test_sample_data_works_for_myntra():
    products = sample_data.generate(config.MARKETPLACE_MYNTRA, "tshirt", 5)
    assert len(products) == 5
    assert all(p.marketplace == config.MARKETPLACE_MYNTRA for p in products)
    assert products[0].product_id.startswith("SAMPLE-MY")


# --- Myntra HTML parsing ---------------------------------------------------
_MYNTRA_HTML = """
<html><body><ul>
<li class="product-base">
  <a href="/roadster/roadster-men-tshirt/1364628/buy" title="Roadster Tshirt">
    <img src="https://img/m.jpg"/>
    <div class="product-brand">Roadster</div>
    <div class="product-product">Men Cotton T-shirt</div>
    <div class="product-ratingsContainer">4.2 | 1,234</div>
    <span class="product-ratingsCount">1,234</span>
    <div class="product-price">
      <span class="product-discountedPrice">Rs. 649</span>
      <span class="product-strike">Rs. 1299</span>
    </div>
  </a>
</li>
</ul></body></html>
"""


def test_myntra_parse_search_extracts_fields():
    from src.scrapers.myntra import MyntraScraper

    products = MyntraScraper().parse_search(_MYNTRA_HTML, limit=10)
    assert len(products) == 1
    p = products[0]
    assert p.marketplace == config.MARKETPLACE_MYNTRA
    assert "Roadster" in p.name and "T-shirt" in p.name
    assert p.brand == "Roadster"
    assert p.native_id == "1364628"
    assert p.product_id == "MYN:1364628"
    assert p.current_price == 649.0
    assert p.original_price == 1299.0
    assert p.rating == 4.2


def test_myntra_raises_on_js_shell():
    from src.scrapers.myntra import MyntraScraper

    with pytest.raises(ScraperError):
        MyntraScraper().parse_search("<html><body>app shell</body></html>", 10)


def test_registry_has_all_three_marketplaces():
    from src.scrapers.myntra import MyntraScraper

    assert isinstance(scrapers.get_scraper(config.MARKETPLACE_MYNTRA), MyntraScraper)
    assert config.MARKETPLACE_MYNTRA in config.MARKETPLACES


# --- HTTP retry / domain policy -------------------------------------------
class _FakeResp:
    def __init__(self, status_code, text="ok", headers=None):
        self.status_code = status_code
        self.text = text
        self.headers = headers or {}


def test_retries_transient_then_succeeds(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda *a, **k: None)
    scraper = AmazonIndiaScraper()
    calls = {"n": 0}

    def fake_get(url, params=None, timeout=None):
        calls["n"] += 1
        if calls["n"] == 1:
            return _FakeResp(503)
        return _FakeResp(200, "<html>ok</html>")

    monkeypatch.setattr(scraper.session, "get", fake_get)
    html = scraper._get(config.AMAZON_SEARCH_URL)
    assert "ok" in html and calls["n"] == 2


def test_does_not_retry_permanent_error(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda *a, **k: None)
    scraper = AmazonIndiaScraper()
    calls = {"n": 0}

    def fake_get(url, params=None, timeout=None):
        calls["n"] += 1
        return _FakeResp(403)  # blocked / forbidden — permanent

    monkeypatch.setattr(scraper.session, "get", fake_get)
    with pytest.raises(ScraperError):
        scraper._get(config.AMAZON_SEARCH_URL)
    assert calls["n"] == 1  # no retries on 403


def test_disallowed_domain_is_refused():
    scraper = AmazonIndiaScraper()
    with pytest.raises(ScraperError):
        scraper._get("https://evil.example.com/steal")


def test_browser_fallback_used_when_http_blocked(monkeypatch):
    # HTTP path fails; with the flag on, _get should fall back to the browser.
    monkeypatch.setattr(config, "ENABLE_BROWSER_FALLBACK", True)
    scraper = AmazonIndiaScraper()

    def blocked(url, params=None):
        raise ScraperError("blocked")

    monkeypatch.setattr(scraper, "_http_fetch", blocked)
    monkeypatch.setattr(
        scraper, "_browser_fetch", lambda url, params=None: "<html>rendered</html>"
    )
    assert scraper._get(config.AMAZON_SEARCH_URL) == "<html>rendered</html>"


def test_browser_fallback_off_by_default_reraises(monkeypatch):
    monkeypatch.setattr(config, "ENABLE_BROWSER_FALLBACK", False)
    scraper = AmazonIndiaScraper()

    def blocked(url, params=None):
        raise ScraperError("blocked")

    monkeypatch.setattr(scraper, "_http_fetch", blocked)
    with pytest.raises(ScraperError):
        scraper._get(config.AMAZON_SEARCH_URL)


class _Recorder:
    def __init__(self):
        self.events = []
        self.parse_metrics = []

    def record_http_event(self, **fields):
        self.events.append(fields)

    def record_parse_metrics(self, **fields):
        self.parse_metrics.append(fields)


def test_search_records_parse_metrics_for_live(monkeypatch):
    from src.models import Product

    live = [
        Product(
            name="Earbuds A",
            marketplace=config.MARKETPLACE_AMAZON,
            url="https://www.amazon.in/dp/B0AAA00001",
            native_id="B0AAA00001",
            current_price=999.0,
            rating=4.2,
        ),
        Product(
            name="Earbuds B",
            marketplace=config.MARKETPLACE_AMAZON,
            url="https://www.amazon.in/dp/B0AAA00002",
            native_id="B0AAA00002",
            current_price=None,  # missing price
            rating=None,
        ),
    ]
    monkeypatch.setattr(AmazonIndiaScraper, "search", lambda self, q, limit: live)
    rec = _Recorder()
    scrapers.search(
        config.MARKETPLACE_AMAZON,
        "earbuds",
        10,
        mode=config.DATA_MODE_LIVE,
        recorder=rec,
    )
    assert len(rec.parse_metrics) == 1
    counts = rec.parse_metrics[0]["counts"]
    assert counts["current_price"] == 1  # 1 of 2 had a price
    assert counts["native_id"] == 2


def test_recorder_captures_success_event(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda *a, **k: None)
    rec = _Recorder()
    scraper = AmazonIndiaScraper(recorder=rec)
    monkeypatch.setattr(
        scraper.session, "get", lambda *a, **k: _FakeResp(200, "<html>ok</html>")
    )
    scraper._get(config.AMAZON_SEARCH_URL)
    assert len(rec.events) == 1
    assert rec.events[0]["ok"] is True
    assert rec.events[0]["error_type"] == "ok"
    assert rec.events[0]["status_code"] == 200


def test_recorder_captures_blocked_event(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda *a, **k: None)
    rec = _Recorder()
    scraper = AmazonIndiaScraper(recorder=rec)
    monkeypatch.setattr(scraper.session, "get", lambda *a, **k: _FakeResp(403))
    with pytest.raises(ScraperError):
        scraper._get(config.AMAZON_SEARCH_URL)
    assert rec.events[-1]["ok"] is False
    assert rec.events[-1]["error_type"] == "blocked"


# --- explicit data-source modes -------------------------------------------
def test_demo_mode_returns_sample_without_scraping(monkeypatch):
    def must_not_run(self, query, limit):
        raise AssertionError("Demo mode must not hit the network")

    monkeypatch.setattr(AmazonIndiaScraper, "search", must_not_run)
    res = scrapers.search(
        config.MARKETPLACE_AMAZON, "phone", 10, mode=config.DATA_MODE_DEMO
    )
    assert len(res) == 10 and all(p.is_sample for p in res)


def test_live_mode_raises_without_fallback(monkeypatch):
    def boom(self, query, limit):
        raise ScraperError("blocked")

    monkeypatch.setattr(AmazonIndiaScraper, "search", boom)
    with pytest.raises(ScraperError):
        scrapers.search(
            config.MARKETPLACE_AMAZON, "phone", 10, mode=config.DATA_MODE_LIVE
        )


def test_live_fallback_mode_returns_sample(monkeypatch):
    def boom(self, query, limit):
        raise ScraperError("blocked")

    monkeypatch.setattr(AmazonIndiaScraper, "search", boom)
    res = scrapers.search(
        config.MARKETPLACE_AMAZON,
        "phone",
        10,
        mode=config.DATA_MODE_LIVE_FALLBACK,
    )
    assert all(p.is_sample for p in res)


# --- fallback behaviour ----------------------------------------------------
def test_search_falls_back_to_sample_when_live_fails(monkeypatch):
    def boom(self, query, limit):
        raise ScraperError("blocked")

    monkeypatch.setattr(AmazonIndiaScraper, "search", boom)
    monkeypatch.setattr(config, "ENABLE_SAMPLE_FALLBACK", True)

    results = scrapers.search(config.MARKETPLACE_AMAZON, "phone", 10)
    assert len(results) == 10
    assert all(p.is_sample for p in results)


def test_search_reraises_when_fallback_disabled(monkeypatch):
    def boom(self, query, limit):
        raise ScraperError("blocked")

    monkeypatch.setattr(AmazonIndiaScraper, "search", boom)
    monkeypatch.setattr(config, "ENABLE_SAMPLE_FALLBACK", False)

    with pytest.raises(ScraperError):
        scrapers.search(config.MARKETPLACE_AMAZON, "phone", 10)


def test_unknown_marketplace_raises():
    with pytest.raises(ScraperError):
        scrapers.get_scraper("eBay")
