from datetime import datetime, timedelta

from src import config, provenance
from src.models import Product
from src.provenance import FieldMeta, FieldSource, FieldStatus


def _p(**kw):
    return Product(name="X", marketplace="Amazon India", url="https://x.in/p/1", **kw)


# --- freshness -------------------------------------------------------------
def test_freshness_fresh_recent_stale():
    now = datetime(2026, 7, 23, 12, 0, 0)
    assert provenance.freshness(now - timedelta(minutes=10), now) == provenance.FRESH
    assert provenance.freshness(now - timedelta(hours=5), now) == provenance.RECENT
    assert provenance.freshness(now - timedelta(days=3), now) == provenance.STALE


def test_product_freshness_property():
    p = _p(retrieved_at=datetime.now() - timedelta(minutes=1))
    assert p.freshness == provenance.FRESH
    assert p.age_seconds >= 0


# --- derived field status --------------------------------------------------
def test_field_status_success_when_value_present():
    p = _p(current_price=100.0)
    assert p.field_status("current_price") == FieldStatus.SUCCESS
    assert p.field_source("current_price") == FieldSource.SEARCH_PAGE


def test_field_status_not_present_when_missing():
    p = _p(seller=None)
    assert p.field_status("seller") == FieldStatus.NOT_PRESENT
    assert p.field_source("seller") == FieldSource.NONE


def test_sample_product_fields_are_sample():
    p = _p(current_price=100.0, is_sample=True)
    assert p.field_status("current_price") == FieldStatus.SAMPLE
    assert p.field_source("current_price") == FieldSource.SAMPLE


def test_explicit_provenance_overrides_derived():
    p = _p(
        current_price=None,
        provenance={"current_price": FieldMeta(FieldStatus.PARSE_FAILED)},
    )
    assert p.field_status("current_price") == FieldStatus.PARSE_FAILED


# --- extraction counts -----------------------------------------------------
def test_extraction_counts():
    products = [
        _p(current_price=100.0, rating=4.0, seller="A"),
        _p(current_price=200.0, rating=None, seller=None),
    ]
    counts = provenance.extraction_counts(products)
    assert counts["current_price"] == 2
    assert counts["rating"] == 1
    assert counts["seller"] == 1
    # Every tracked field is represented.
    assert set(counts) == set(config.PARSE_TRACKED_FIELDS)
