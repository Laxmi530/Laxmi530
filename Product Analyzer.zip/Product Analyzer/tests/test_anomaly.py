from src import config
from src.anomaly import classify_price


def test_no_prior_prices_is_valid():
    status, reason = classify_price(1000.0, [])
    assert status == config.OBS_VALID
    assert reason is None


def test_missing_price_is_valid():
    status, _ = classify_price(None, [100.0, 100.0])
    assert status == config.OBS_VALID


def test_extreme_jump_flagged():
    # 100 -> 1000 is a 900% jump.
    status, reason = classify_price(1000.0, [100.0])
    assert status == config.OBS_SUSPECTED
    assert "changed" in reason


def test_small_change_valid():
    status, _ = classify_price(110.0, [100.0])
    assert status == config.OBS_VALID


def test_far_outside_range_flagged():
    # Previous value (60) is close to the new one (55) so the jump rule does
    # NOT fire, but 55 is far below the historical median (1000) -> range rule.
    status, reason = classify_price(55.0, [1000.0, 1000.0, 1000.0, 60.0])
    assert status == config.OBS_SUSPECTED
    assert "range" in reason


def test_range_check_needs_enough_history():
    # Only two prior prices: range rule does not apply, and 300 vs 200 is
    # a 50% change (below the jump threshold) -> valid.
    status, _ = classify_price(300.0, [200.0, 200.0])
    assert status == config.OBS_VALID
