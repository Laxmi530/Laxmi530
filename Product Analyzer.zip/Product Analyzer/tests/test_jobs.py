from datetime import datetime

import pytest

from src import config
from src.database import PriceHistoryDB
from src.jobs import collect_prices
from src.models import Product
from src.scrapers.base import ScraperError


@pytest.fixture
def db(tmp_path):
    return PriceHistoryDB(tmp_path / "jobs.db")


def _live_products(query, n=3):
    return [
        Product(
            name=f"{query} {i}",
            marketplace="Amazon India",
            url=f"https://www.amazon.in/dp/B0{query[:3].upper()}{i:04d}",
            native_id=f"B0{query[:3].upper()}{i:04d}",
            current_price=100.0 + i,
            rating=4.0 + i * 0.1,
            num_ratings=10 * i,
            retrieved_at=datetime(2026, 7, 23, 12, 0, 0),
        )
        for i in range(n)
    ]


def test_collect_stores_live_observations(db, monkeypatch):
    monkeypatch.setattr(
        collect_prices.scrapers,
        "search",
        lambda mp, q, limit, mode, recorder=None: _live_products(q, 3),
    )
    summary = collect_prices.collect(
        db,
        [("Amazon India", "earbuds")],
        limit=10,
        mode=config.DATA_MODE_LIVE,
    )
    assert summary.succeeded == 1
    assert summary.total_found == 3
    assert summary.total_stored == 3
    assert db.total_observations() == 3


def test_collect_continues_after_a_failure(db, monkeypatch):
    def flaky(mp, q, limit, mode, recorder=None):
        if q == "broken":
            raise ScraperError("blocked")
        return _live_products(q, 2)

    monkeypatch.setattr(collect_prices.scrapers, "search", flaky)
    summary = collect_prices.collect(
        db,
        [("Amazon India", "broken"), ("Amazon India", "good")],
        mode=config.DATA_MODE_LIVE,
    )
    assert summary.failed == 1
    assert summary.succeeded == 1
    assert summary.total_stored == 2


def test_demo_mode_stores_nothing(db, monkeypatch):
    # Demo mode yields sample data, which must never be persisted.
    summary = collect_prices.collect(
        db,
        [("Amazon India", "laptop")],
        limit=10,
        mode=config.DATA_MODE_DEMO,
    )
    assert summary.total_found == 10
    assert summary.total_stored == 0
    assert db.total_observations() == 0


def test_resolve_searches_uses_tracked(db):
    rid = db.start_run("Flipkart", "tv", "Live")
    db.finish_run(rid, "ok", result_count=1)
    searches = collect_prices._resolve_searches(
        db,
        config.MARKETPLACE_AMAZON,
        queries=[],
        use_tracked=False,
    )
    assert ("Flipkart", "tv") in searches


def test_resolve_searches_dedups(db):
    searches = collect_prices._resolve_searches(
        db,
        "Amazon India",
        queries=["x", "x"],
        use_tracked=False,
    )
    assert searches == [("Amazon India", "x")]


def test_main_reports_nothing_to_collect(db, tmp_path, capsys):
    code = collect_prices.main(["--db", str(tmp_path / "empty.db")])
    assert code == 1
    assert "Nothing to collect" in capsys.readouterr().out


def test_main_refuses_when_collector_lock_held(tmp_path, capsys):
    db_path = tmp_path / "locked.db"
    holder = PriceHistoryDB(db_path)
    assert holder.acquire_lock(config.COLLECTOR_LOCK, "other-owner", 3600)

    code = collect_prices.main(
        ["--db", str(db_path), "--query", "laptop", "--mode", "Demo"]
    )
    assert code == 3
    assert "already in progress" in capsys.readouterr().out
