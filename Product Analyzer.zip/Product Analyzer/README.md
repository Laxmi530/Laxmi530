# 🛒 Product Analyzer

Search **Amazon India**, **Flipkart**, or **Myntra** for a product or category
and display the **top-rated products** (Top 10 / Top 20), ranked by customer
rating, with SQLite-backed **price-history tracking** and interactive charts.

Built with Python 3.11+, Streamlit, Pandas, Plotly, SQLite, Requests +
BeautifulSoup, and Pytest (Playwright optional, for bot-walled / JS pages).

---

## Features

- **Sidebar search**: marketplace dropdown, product/category input, Top 10 /
  Top 20 selector, **Submit** and **Clear** buttons.
- **Loading spinner** while products are retrieved.
- **Card layout _or_ sortable table** view.
- Per-product details: name, marketplace, image, current price, MRP, discount
  %, rating, number of ratings, number of reviews, seller, availability,
  product URL, monthly purchases, and retrieval timestamp.
- **"What customers say" review aspects** — per-product review themes with
  Amazon-style mention counts + sentiment (*Quality 1.7K ↗*, *Reliability 540
  ~*) and Flipkart/Myntra-style per-aspect star ratings (*Sound Quality 4★*),
  shown when available.
- **Ranking**: primarily by customer rating, tie-broken by number of ratings,
  then number of reviews.
- **Price history (SQLite)**: current / lowest / highest / average / previous
  price, % change, and an interactive Plotly chart — per product via
  **View Price History**.
- Honest data handling — see below.

## Marketplace access (important)

Live scraping success varies **a lot** by marketplace, and this is about
bot-blocking, not parser quality:

| Marketplace | Plain HTTP | Notes |
| --- | --- | --- |
| **Amazon India** | usually works | returns server-rendered search HTML |
| **Flipkart** | **blocked** | returns HTTP 403 / 529 (bot wall) even with full browser headers |
| **Myntra** | **JS-only** | returns a React app shell with no product markup |

For Flipkart and Myntra, the realistic paths are the **browser-render
fallback** below or an official/licensed data API. Without them, choose *Demo*
or *Live with demo fallback* to see clearly-labelled sample data.

### Browser-render fallback (Playwright)

When a plain request is blocked (403/429/503/529) or returns a JS shell, the
app can retry the page through a real headless browser:

```bash
pip install playwright
python -m playwright install chromium
# then run with the fallback enabled:
PRODUCT_ANALYZER_BROWSER=1 streamlit run app.py
```

It's **off by default** (so tests/CI stay hermetic and no browser launches
unexpectedly) and degrades gracefully — if Playwright or the browser binary is
missing, the request just fails clearly and is recorded in diagnostics. Note
that determined bot walls can still block a headless browser from a datacenter
IP; a residential IP and an official API are the sturdier options.

## Honest data handling

- **Explicit data-source modes** (sidebar → *Data source*):
  - **Live** — scrapes the marketplace and **fails clearly** if blocked (no
    silent substitution).
  - **Demo** — always returns clearly-labelled sample data.
  - **Live with demo fallback** — scrapes, falling back to sample data on
    failure so the UI stays usable.
  Every product carries a **data-source badge** — :green[LIVE] or
  :orange[SAMPLE] — so the origin of each row is never ambiguous.
- **Per-field provenance** — each card has an *ⓘ Field sources* panel showing,
  for every field, where it came from and its status: **retrieved**,
  **not provided by marketplace**, **parse failed**, or **sample**. This
  distinguishes "Amazon doesn't publish this" from "our parser broke" from
  "this is demo data" — instead of showing a bare blank for all three.
- **Data freshness** — each result shows a ● fresh / ● recent / ● stale badge
  and its retrieval time (thresholds in [src/config.py](src/config.py)). A
  **failed live refresh never nulls out** previously valid results — the last
  known data is kept and flagged as possibly stale.
- **Monthly purchases**: extracted only from literal on-page text such as
  *"2K+ bought in past month"*. When absent, it shows **Not publicly
  available**. Numbers are never invented or estimated.
- **Price history** only reflects data collected by *this app* over time. A
  product seen once shows *"Price history will become available after this
  product has been checked multiple times."* No pre-app history is fabricated.
  Sample records are **never** written to the database.
- **Variant safety** — products carry variant attributes (`brand`,
  `variant_name`, `color`, `storage`, `pack_size`, …) and canonical IDs are
  variant-specific (ASIN/PID), so price history for a 128 GB phone is never
  mixed with the 256 GB variant.

## Ranking modes

Choose in the sidebar (*Rank by*) — applied at render time, so you can
re-rank without re-scraping:

- **Best weighted rating** (default) — a **Bayesian weighted rating**
  `(v/(v+m))·R + (m/(v+m))·C`, so a 5.0 from 2 buyers does not outrank a 4.7
  from 50,000. `m` is `BAYESIAN_MIN_RATINGS` in [src/config.py](src/config.py).
- **Best match** — title relevance × weighted rating (on-topic *and* good).
- **Highest rating** — raw rating, tie-broken by rating count then reviews.
- **Most popular** — by number of ratings.
- **Lowest price** / **Highest discount**.

## Result-quality validation & filters

Every result set is validated before display ([src/validation.py](src/validation.py)):

- **Relevance scoring** — share of query tokens present in the title; results
  below `MIN_RELEVANCE` are dropped as off-topic.
- **Data-sanity checks** — valid/allowed URL, rating in 0–5, price > 0, MRP not
  below current price, plausible discount.
- **De-duplication** — by canonical product id.
- **Sponsored identification** — ad listings are flagged (badged `AD`).

The header reports the funnel (`fetched → after validation → shown`) and what
was removed, so nothing disappears silently.

**Filters** (sidebar → *Filters*, applied live without re-scraping): minimum
rating, minimum number of ratings, price range, minimum discount, in-stock
only, and exclude-sponsored.

## Comparison

The **⚖️ Compare** tab lets you select 2–4 products and compare price, MRP,
discount, rating, rating/review counts, seller, availability, monthly
purchases and sponsored status side by side — with an overlaid price-history
chart for products that have multiple live observations.

## Review aspects ("What customers say")

Each card has a *🗣️ What customers say* panel of review-theme chips
([src/aspects.py](src/aspects.py)):

- **Amazon** — aspect name + mention count + sentiment arrow (🟢↗ positive /
  🟠~ mixed): *Quality 1.7K*, *Battery life 652*, *Reliability 540*.
- **Flipkart / Myntra** — aspect name + per-aspect star rating: *Sound Quality
  4★*, *Value for Money 3.9★*.

These blocks live on the **product detail page**, not the search-results page,
so live values need product-page access (the browser fallback or an API). In
**Demo mode** they are populated with clearly-labelled sample aspects for all
three marketplaces; the Amazon and Flipkart parsers are unit-tested against
fixtures so extraction works when real product-page HTML is available.

## Reliability & correctness details

- **Canonical product IDs** — `marketplace + native id` (Amazon **ASIN** /
  Flipkart **PID**). URLs are normalised (tracking/affiliate/session params
  stripped, fragment and trailing slash removed) before IDs are derived, so
  the same product maps to one stable ID regardless of URL noise.
- **De-duplicated price observations** — an unchanged price within
  `PRICE_DEDUP_INTERVAL` (default 1 hour) is **not** re-stored, so repeated
  Submits don't distort history; a **changed** price is always stored.
- **Smart retries** — only transient failures (429/500/502/503/504, timeouts)
  are retried, honouring `Retry-After`; permanent failures (400/401/403,
  CAPTCHA) fail fast.
- **Domain allowlist** — HTTP requests are restricted to approved marketplace
  domains (`ALLOWED_DOMAINS`) to avoid following arbitrary scraped URLs (SSRF
  hardening).

## Project layout

```
Product Analyzer/
├── app.py                  # Streamlit entry point
├── requirements.txt        # runtime deps
├── requirements-dev.txt    # + lint/type/security/test tooling
├── pyproject.toml          # ruff / black / mypy / bandit / pytest config
├── Dockerfile · docker-compose.yml · .dockerignore
├── .pre-commit-config.yaml
├── .github/workflows/ci.yml
├── src/
│   ├── config.py           # all tunables (env-overridable)
│   ├── models.py           # Product dataclass
│   ├── database.py         # SQLite (normalised, migrated)
│   ├── ranking.py          # ranking logic (weighted / relevance / price / …)
│   ├── validation.py       # relevance scoring, sanity checks, dedup
│   ├── filtering.py        # user-facing result filters
│   ├── aspects.py          # "Customers say" review-aspect parsing
│   ├── diagnostics.py      # HTTP/error classification for health metrics
│   ├── provenance.py       # per-field origin/status + data freshness
│   ├── anomaly.py          # price-anomaly detection (outlier flagging)
│   ├── logging_config.py   # structured JSON logging
│   ├── health.py           # health-check function + CLI
│   ├── formatting.py       # display helpers
│   ├── utils.py            # URL normalisation, ID + domain helpers
│   ├── scrapers/
│   │   ├── base.py         # HTTP + retries + browser-render fallback
│   │   ├── amazon.py       # Amazon India
│   │   ├── flipkart.py     # Flipkart
│   │   ├── myntra.py       # Myntra
│   │   └── sample_data.py  # labelled demo fallback
│   └── jobs/
│       └── collect_prices.py  # scheduled price-collection job
└── tests/                  # pytest suite
```

## Database schema

Normalised into three tables, versioned with SQLite's `PRAGMA user_version`
and applied through ordered migrations (see [src/database.py](src/database.py)).
Legacy single-table databases are migrated in place automatically on first
open.

- **`products`** — one row per canonical product (marketplace, native id,
  canonical URL, name, image, variant attributes, first/last seen).
- **`price_observations`** — the time series: price, MRP, discount, rating,
  rating/review counts, availability, seller, monthly-purchase text,
  sponsored flag, source (live/sample), retrieval status, **quality**
  (valid / suspected_outlier), `observed_at`, and the `run_id`.
- **`search_runs`** — one row per search (UI or job) with mode, status,
  result count, error and timing — useful for diagnosing selector breakage.
- **`scrape_events`** — one row per HTTP fetch (status code, ok, error type,
  retry count, response time) powering the diagnostics page.
- **`parse_metrics`** — per-field extraction counts (present / total) per
  scrape, powering the parser-quality panel.
- **`job_locks`** — named locks with owner + TTL, so the collector never
  overlaps itself and abandoned locks are auto-recovered.

Indexes cover `products(marketplace, native_id)`,
`price_observations(product_id, observed_at)`,
`search_runs(marketplace, started_at)`,
`scrape_events(marketplace, created_at)` and
`parse_metrics(marketplace, field)`.

The database opens in **WAL mode with a busy timeout**, so the Streamlit app
and the scheduled collector can touch the same file concurrently without
"database is locked" errors.

## Price-history integrity

- **Anomaly detection** — each observation is classified `valid` or
  `suspected_outlier` ([src/anomaly.py](src/anomaly.py)): a price that jumps
  more than `ANOMALY_JUMP_PCT` from the previous value, or lands far outside
  the historical median, is flagged and **excluded from lowest / highest /
  average / median** so one bad parse (an EMI figure, an MRP mistaken for the
  price) can't poison the history. The chart marks outliers in red.
- **Statistically honest aggregates** — the price-history view reports median
  alongside average, plus **number of checks vs. actual price changes**,
  in-stock %, days since last change, and the dates of the low/high. "20
  checks" is never conflated with "20 price changes".

## Concurrency & locking

- **WAL + busy timeout** prevent SQLite "database is locked" errors under
  concurrent access.
- The scheduled collector holds a global **`job_locks`** entry
  (`config.COLLECTOR_LOCK`) for its run; a second collector started while one
  is active **refuses to run and exits with code 3**. Locks carry a TTL, so an
  abandoned lock from a killed process is recovered automatically on the next
  run. `acquire_lock` / `release_lock` / the `job_lock` context manager are
  reusable for per-product locking too.

## Diagnostics & logging

- **🩺 Diagnostics page** (sidebar → *Page*) surfaces scraper health from
  `search_runs` and `scrape_events`: search success rate, empty-result rate,
  last successful retrieval, HTTP request success/blocked (CAPTCHA) rates,
  average response time, and charts of HTTP status codes and error types, plus
  tables of recent searches and requests. This makes selector breakage and
  bot-blocking easy to spot.
- **Parser-quality panel** — per-field extraction rates per marketplace
  (price, rating, image, seller, native id, monthly purchases). Rates below a
  configurable threshold are flagged as likely selector breakage (e.g.
  *"Amazon price extraction 31%"*) — catching parser degradation before users
  report it.
- **Structured JSON logging** ([src/logging_config.py](src/logging_config.py))
  emits one JSON object per line with fields such as `marketplace`,
  `request_url`, `status_code`, `retry_count`, `error_type` and
  `duration_ms`. Request headers, cookies and credentials are never logged.

## Scheduled price collection

Manual searches alone create sparse history. Run this standalone job (separate
from Streamlit) on a scheduler to accumulate observations over time:

```bash
# Re-collect every search previously run (live):
python -m src.jobs.collect_prices

# Specific queries on a marketplace:
python -m src.jobs.collect_prices --marketplace "Flipkart" \
    --query "wireless earbuds" --query "air fryer"

# Options: --mode {Live|Demo|Live with demo fallback}  --limit {10|20}  --db PATH
```

It records each search as a `search_run`, stores observations, **continues
when individual searches fail**, prints a summary, and returns a non-zero exit
code only if every search failed (scheduler-friendly). It holds a global lock
for the run, so **overlapping invocations refuse to start (exit code 3)**
rather than doing duplicate work. Suitable for cron, Windows Task Scheduler, or
GitHub Actions.

## Setup

```bash
# From the project root
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # macOS/Linux

pip install -r requirements.txt

# Optional: browser rendering for JS-heavy pages
python -m playwright install chromium
```

## Run

```bash
streamlit run app.py
```

Then open the URL Streamlit prints (usually http://localhost:8501).

## Configuration (environment)

Deployment settings come from the environment so config stays out of the code:

| Variable | Default | Purpose |
| --- | --- | --- |
| `PRODUCT_ANALYZER_DB` | `data/price_history.db` | SQLite path (point at a mounted volume in Docker) |
| `PRODUCT_ANALYZER_LOG_LEVEL` | `INFO` | Log level |
| `PRODUCT_ANALYZER_SAMPLE_FALLBACK` | `true` | Allow demo fallback when live is unspecified |
| `PRODUCT_ANALYZER_BROWSER` | `false` | Enable the Playwright browser-render fallback for bot-walled / JS pages |

A health check is available for probes and dashboards:

```bash
python -m src.health         # prints JSON: {"status": "ok", "schema_version": 2, ...}
```

## Docker

```bash
# Build & run with a persistent named volume for price history
docker compose up --build
# → http://localhost:8501
```

The image runs as a non-root user, stores the database on the `/data` volume,
and defines a `HEALTHCHECK` against Streamlit's `/_stcore/health` endpoint. See
[Dockerfile](Dockerfile) and [docker-compose.yml](docker-compose.yml).

## Development & quality gates

```bash
pip install -r requirements-dev.txt
pre-commit install         # run the gates automatically on each commit

ruff check .               # lint
black --check .            # format
mypy src                   # type check
bandit -c pyproject.toml -r src   # security
pytest                     # tests
```

All tool configuration lives in [pyproject.toml](pyproject.toml); hooks in
[.pre-commit-config.yaml](.pre-commit-config.yaml). The same gates run in CI on
Python 3.11 and 3.12 ([.github/workflows/ci.yml](.github/workflows/ci.yml)),
plus an advisory `pip-audit` dependency scan.

> Note: `black` on Python **3.12.5** aborts due to a CPython AST bug — use
> 3.11, 3.12.4, or ≥3.12.6 locally (the pinned `black==24.4.2` matches CI).

## Test

```bash
pytest
```

## Notes & possible improvements

- Selectors for Amazon/Flipkart are best-effort and isolated in
  `src/scrapers/` so they are easy to update when the sites change markup.
- A Playwright-based scraper can be added behind the same `BaseScraper`
  interface for pages that require JavaScript rendering.
- Respect each marketplace's Terms of Service and `robots.txt`; add rate
  limiting / proxies responsibly if you scale live scraping.
- A documented estimation method for monthly purchases could be added and, if
  so, its outputs must be explicitly labelled as estimates.

Candidate next steps (not yet implemented):

- **Offer normalization & effective price** — per-seller offers, coupons/bank
  offers, effective total cost (depends on a reliable live/API data source).
- **Time-weighted average price** (current aggregates weight each observation
  equally regardless of the gap between checks).
- **Price alerts & watchlists** — save a target price and notify on drops.
- **History retention/compaction** and **backup/restore** CLIs.
- **Configurable caching**, price-history date filters (7/30/90 days), CSV/PNG
  exports, and a full accessibility audit.

> The ceiling on much of the above is **reliable live data**. Amazon/Flipkart
> block automated requests, so a dependable monitoring product ultimately
> needs an official API or a licensed product-data provider rather than HTML
> scraping.
