"""Product Analyzer — Streamlit UI.

Search Amazon India or Flipkart for a product/category and display the
top-rated results as cards or a sortable table, with result-quality
validation, live filters, a comparison view, and SQLite-backed price history.

Ranking and filters are applied at render time over the validated result set,
so they can be changed without re-scraping. Only Submit re-runs a search.

Run with:  streamlit run app.py
"""

from __future__ import annotations

from datetime import datetime

import pandas as pd
import plotly.express as px
import streamlit as st

from src import config, filtering, provenance, ranking, scrapers, validation
from src import formatting as fmt
from src.database import PriceHistoryDB
from src.filtering import FilterCriteria
from src.logging_config import configure_logging
from src.models import Product

st.set_page_config(
    page_title="Product Analyzer",
    page_icon="🛒",
    layout="wide",
    initial_sidebar_state="expanded",
)

configure_logging()  # idempotent under Streamlit reruns


# --- resources -------------------------------------------------------------
@st.cache_resource
def get_db() -> PriceHistoryDB:
    return PriceHistoryDB()


DB = get_db()


def _default_rank_label() -> str:
    for label, key in config.RANK_MODES.items():
        if key == config.DEFAULT_RANK_MODE:
            return label
    return next(iter(config.RANK_MODES))


_SOURCE_BADGE = {
    config.SOURCE_LIVE: ":green[LIVE]",
    config.SOURCE_SAMPLE: ":orange[SAMPLE]",
}

_FRESHNESS_BADGE = {
    provenance.FRESH: ":green[● fresh]",
    provenance.RECENT: ":orange[● recent]",
    provenance.STALE: ":red[● stale]",
}

# Fields shown in the per-card provenance expander.
_PROVENANCE_FIELDS = (
    ("current_price", "Price"),
    ("original_price", "MRP"),
    ("rating", "Rating"),
    ("num_ratings", "Ratings"),
    ("seller", "Seller"),
    ("availability", "Availability"),
    ("monthly_purchases", "Bought last month"),
    ("image_url", "Image"),
)

_PAGE_SEARCH = "🔎 Search"
_PAGE_DIAGNOSTICS = "🩺 Diagnostics"

_FILTER_DEFAULTS = {
    "f_min_rating": 0.0,
    "f_min_ratings": 0,
    "f_price_min": 0.0,
    "f_price_max": 0.0,
    "f_min_discount": 0,
    "f_in_stock": False,
    "f_exclude_sponsored": False,
}


# --- session state ---------------------------------------------------------
def _init_state() -> None:
    st.session_state.setdefault("results", None)  # validated List[Product]
    st.session_state.setdefault("meta", {})
    st.session_state.setdefault("open_history", None)
    st.session_state.setdefault("refresh_error", None)
    st.session_state.setdefault("rank_label", _default_rank_label())
    st.session_state.setdefault("view_mode", "Cards")
    st.session_state.setdefault("page", _PAGE_SEARCH)
    for key, value in _FILTER_DEFAULTS.items():
        st.session_state.setdefault(key, value)


def _clear() -> None:
    """Reset all inputs, filters and displayed results."""
    st.session_state["results"] = None
    st.session_state["meta"] = {}
    st.session_state["open_history"] = None
    st.session_state["refresh_error"] = None
    st.session_state["marketplace"] = config.MARKETPLACES[0]
    st.session_state["query"] = ""
    st.session_state["result_size"] = config.DEFAULT_RESULT_SIZE
    st.session_state["view_mode"] = "Cards"
    st.session_state["data_mode"] = config.DATA_MODES[0]
    st.session_state["rank_label"] = _default_rank_label()
    st.session_state["compare_sel"] = []
    for key, value in _FILTER_DEFAULTS.items():
        st.session_state[key] = value


_init_state()


# --- sidebar ---------------------------------------------------------------
def render_sidebar() -> None:
    with st.sidebar:
        st.radio(
            "Page",
            options=[_PAGE_SEARCH, _PAGE_DIAGNOSTICS],
            key="page",
            label_visibility="collapsed",
        )
        st.divider()

        if st.session_state.get("page") == _PAGE_DIAGNOSTICS:
            st.caption("Scraper health from recorded searches and requests.")
            return

        st.header("🔎 Search")
        with st.form("search_form", clear_on_submit=False):
            st.selectbox("Marketplace", options=config.MARKETPLACES, key="marketplace")
            st.text_input(
                "Product name or category",
                key="query",
                placeholder="e.g. wireless earbuds",
            )
            st.selectbox(
                "Number of results",
                options=config.RESULT_SIZES,
                format_func=lambda n: f"Top {n}",
                key="result_size",
            )
            st.selectbox(
                "Data source",
                options=config.DATA_MODES,
                key="data_mode",
                help="Live scrapes the marketplace and fails clearly if "
                "blocked. Demo always shows labelled sample data.",
            )
            submitted = st.form_submit_button(
                "Submit", type="primary", use_container_width=True
            )

        st.button("Clear", on_click=_clear, use_container_width=True)

        # Post-processing controls — change without re-scraping.
        st.selectbox(
            "Rank by",
            options=list(config.RANK_MODES.keys()),
            key="rank_label",
            help="Weighted rating balances the score against how many people "
            "rated the product; Best match also weights title relevance.",
        )
        _render_filter_controls()

        st.divider()
        st.caption(
            f"Tracked products: **{DB.product_count():,}** · "
            f"price observations: **{DB.total_observations():,}**\n\n"
            "Every product shows a **data-source badge** (LIVE / SAMPLE). "
            "Flipkart & Myntra usually block live scraping; choose *Demo* / "
            "*Live with demo fallback*, or enable the browser fallback."
        )

    if submitted:
        _run_search()


def _render_filter_controls() -> None:
    with st.expander("⚙️ Filters", expanded=False):
        st.slider("Minimum rating", 0.0, 5.0, key="f_min_rating", step=0.5)
        st.number_input(
            "Minimum number of ratings", min_value=0, step=100, key="f_min_ratings"
        )
        cols = st.columns(2)
        cols[0].number_input(
            "Min price (₹, 0 = any)", min_value=0.0, step=100.0, key="f_price_min"
        )
        cols[1].number_input(
            "Max price (₹, 0 = any)", min_value=0.0, step=100.0, key="f_price_max"
        )
        st.slider("Minimum discount %", 0, 90, key="f_min_discount", step=5)
        st.checkbox("In stock only", key="f_in_stock")
        st.checkbox("Exclude sponsored", key="f_exclude_sponsored")


def _criteria_from_state() -> FilterCriteria:
    return FilterCriteria(
        min_rating=float(st.session_state.get("f_min_rating", 0.0)),
        min_num_ratings=int(st.session_state.get("f_min_ratings", 0)),
        min_price=(st.session_state.get("f_price_min") or None),
        max_price=(st.session_state.get("f_price_max") or None),
        min_discount=float(st.session_state.get("f_min_discount", 0)),
        in_stock_only=bool(st.session_state.get("f_in_stock", False)),
        exclude_sponsored=bool(st.session_state.get("f_exclude_sponsored", False)),
    )


# --- search ----------------------------------------------------------------
def _summarise_dropped(dropped: list) -> dict:
    counts: dict = {}
    for _product, reason in dropped:
        counts[reason] = counts.get(reason, 0) + 1
    return counts


def _run_search() -> None:
    query = (st.session_state.get("query") or "").strip()
    marketplace = st.session_state["marketplace"]
    limit = st.session_state["result_size"]
    data_mode = st.session_state.get("data_mode", config.DATA_MODES[0])

    if not query:
        st.session_state["results"] = None
        st.session_state["meta"] = {"error": "Please enter a product or category."}
        return

    with st.spinner(f"Retrieving top {limit} '{query}' from {marketplace}…"):
        run_id = DB.start_run(marketplace, query, data_mode)
        try:
            products = scrapers.search(
                marketplace, query, limit, mode=data_mode, recorder=DB
            )
        except scrapers.ScraperError as exc:
            DB.finish_run(run_id, "failed", result_count=0, error=str(exc))
            # Do NOT null out previously valid results on a failed refresh —
            # keep showing the last known data (flagged as possibly stale).
            if st.session_state.get("results"):
                st.session_state["refresh_error"] = (
                    f"Live refresh from {marketplace} failed: {exc}. "
                    "Showing the last retrieved results, which may be stale."
                )
            else:
                st.session_state["results"] = None
                st.session_state["meta"] = {
                    "error": (
                        f"Live retrieval from {marketplace} failed: {exc}. "
                        "Try again later, or switch **Data source** to *Demo* / "
                        "*Live with demo fallback*."
                    )
                }
            return

        # Validate: score relevance, drop invalid/off-topic/duplicate results.
        kept, dropped = validation.clean_results(products, query)
        stored = DB.record_many(kept, run_id=run_id)
        DB.finish_run(run_id, "ok", result_count=len(kept))

    st.session_state["results"] = kept
    st.session_state["open_history"] = None
    st.session_state["compare_sel"] = []
    st.session_state["refresh_error"] = None
    st.session_state["meta"] = {
        "query": query,
        "marketplace": marketplace,
        "limit": limit,
        "data_mode": data_mode,
        "stored": stored,
        "retrieved": len(products),
        "dropped": _summarise_dropped(dropped),
        "retrieved_at": datetime.now(),
        "is_sample": bool(kept and kept[0].is_sample),
    }


# --- product rendering -----------------------------------------------------
def _price_block(p: Product) -> str:
    parts = [f"**{fmt.rupees(p.current_price)}**"]
    if p.original_price and p.current_price and p.original_price > p.current_price:
        parts.append(f"~~{fmt.rupees(p.original_price)}~~")
    if p.discount_percent:
        parts.append(f":green[{p.discount_percent:.0f}% off]")
    return "  ".join(parts)


def _badges(p: Product) -> str:
    badges = [_SOURCE_BADGE.get(p.source, "")]
    if p.is_sponsored:
        badges.append(":violet[AD]")
    return " ".join(b for b in badges if b)


def render_card(rank: int, p: Product) -> None:
    with st.container(border=True):
        cols = st.columns([1, 3, 2])

        with cols[0]:
            if p.image_url:
                st.image(p.image_url, use_container_width=True)
            else:
                st.markdown("🖼️ _No image_")

        with cols[1]:
            st.markdown(f"**#{rank}. {p.name}** {_badges(p)}")
            if p.variant_name:
                st.caption(f"Variant: {p.variant_name}")
            score = getattr(p, "weighted_score", None)
            score_txt = f" · weighted {score}" if score else ""
            rel = p.relevance_score
            rel_txt = f" · relevance {rel:.0%}" if rel is not None else ""
            st.caption(
                f"{p.marketplace} · Seller: {fmt.text(p.seller)}"
                f"{score_txt}{rel_txt}"
            )
            st.markdown(_price_block(p))
            st.markdown(
                f"⭐ {fmt.rating(p.rating)} "
                f"({fmt.count(p.num_ratings)} ratings, "
                f"{fmt.count(p.num_reviews)} reviews)"
            )
            st.markdown(f"🛍️ Bought last month: {p.monthly_purchases_display}")

        with cols[2]:
            st.markdown(f"📦 {fmt.text(p.availability)}")
            freshness_badge = _FRESHNESS_BADGE.get(p.freshness, "")
            st.caption(
                f"{freshness_badge} · retrieved "
                f"{p.retrieved_at.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            if p.url:
                st.link_button("Open product ↗", p.url, use_container_width=True)
            if st.button(
                "📈 View Price History",
                key=f"hist_{p.product_id}",
                use_container_width=True,
            ):
                st.session_state["open_history"] = (
                    None
                    if st.session_state["open_history"] == p.product_id
                    else p.product_id
                )

        if p.aspects:
            with st.expander(f"🗣️ What customers say ({len(p.aspects)})"):
                render_aspects(p)

        with st.expander("ⓘ Field sources"):
            render_provenance(p)

        if st.session_state["open_history"] == p.product_id:
            render_price_history(p)


_ASPECT_SENTIMENT = {
    "positive": "🟢↗",
    "mixed": "🟠~",
    "negative": "🔴↘",
    "neutral": "•",
}


def render_aspects(p: Product) -> None:
    """Render 'Customers say' review aspects as coloured chips.

    Amazon-style aspects show a mention count; Flipkart/Myntra-style aspects
    show a per-aspect star rating.
    """
    chips = []
    for aspect in p.aspects:
        icon = _ASPECT_SENTIMENT.get(aspect.sentiment, "•")
        if aspect.rating is not None:
            detail = f"{aspect.rating:.1f}★"
        elif aspect.count is not None:
            detail = fmt.compact_count(aspect.count)
        else:
            detail = ""
        colour = {"positive": "green", "mixed": "orange", "negative": "red"}.get(
            aspect.sentiment, "gray"
        )
        chips.append(f":{colour}[{icon} {aspect.name} {detail}]".rstrip())
    st.markdown(" · ".join(chips))
    st.caption("Aspect sentiment summarised from customer reviews.")


_STATUS_LABEL = {
    provenance.FieldStatus.SUCCESS: "✓ retrieved",
    provenance.FieldStatus.NOT_PRESENT: "— not provided by marketplace",
    provenance.FieldStatus.PARSE_FAILED: "⚠ parse failed",
    provenance.FieldStatus.SAMPLE: "sample data",
    provenance.FieldStatus.CACHED: "cached",
    provenance.FieldStatus.STALE: "stale",
    provenance.FieldStatus.BLOCKED: "blocked",
}


def render_provenance(p: Product) -> None:
    """Per-field origin/status table — distinguishes 'not provided' from
    'parse failed' from 'sample', so missing data is never ambiguous."""
    rows = []
    for field_name, label in _PROVENANCE_FIELDS:
        status = p.field_status(field_name)
        value = getattr(p, field_name, None)
        rows.append(
            {
                "Field": label,
                "Value": fmt.text(str(value) if value is not None else None),
                "Source": p.field_source(field_name).value,
                "Status": _STATUS_LABEL.get(status, status.value),
            }
        )
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


def render_price_history(p: Product) -> None:
    st.markdown("---")
    if p.is_sample:
        st.info(
            "This is sample data — price history is only tracked for " "live records."
        )
        return

    stats = DB.get_stats(p.product_id)
    if not stats or stats["record_count"] < 2:
        st.info(
            "Price history will become available after this product has "
            "been checked multiple times."
        )
        return

    m = st.columns(5)
    m[0].metric("Current", fmt.rupees(stats["current"]))
    m[1].metric("Lowest", fmt.rupees(stats["lowest"]))
    m[2].metric("Highest", fmt.rupees(stats["highest"]))
    m[3].metric("Average", fmt.rupees(stats["average"]))
    delta = (
        None if stats["pct_change"] is None else fmt.signed_percent(stats["pct_change"])
    )
    m[4].metric(
        "Previous", fmt.rupees(stats["previous"]), delta=delta, delta_color="inverse"
    )

    n = st.columns(5)
    n[0].metric("Median", fmt.rupees(stats["median"]))
    n[1].metric("Checks", f"{stats['num_checks']}")
    n[2].metric("Price changes", f"{stats['num_changes']}")
    n[3].metric("In stock", f"{stats['in_stock_pct']:.0f}%")
    n[4].metric("Days since change", f"{stats['days_since_change']}")

    lo = stats["lowest_date"].strftime("%Y-%m-%d")
    hi = stats["highest_date"].strftime("%Y-%m-%d")
    st.caption(
        f"Lowest on {lo} · highest on {hi} · aggregates use "
        f"{stats['record_count']} valid observation(s)."
    )
    if stats["anomalies"]:
        st.warning(
            f"⚠️ {stats['anomalies']} observation(s) flagged as suspected "
            "outliers and excluded from the aggregates above."
        )

    history = DB.get_history(p.product_id).dropna(subset=["current_price"])
    history = history.assign(Quality=history["quality"].fillna(config.OBS_VALID))
    fig = px.scatter(
        history,
        x="observed_at",
        y="current_price",
        color="Quality",
        color_discrete_map={
            config.OBS_VALID: "#2563eb",
            config.OBS_SUSPECTED: "#dc2626",
        },
        labels={"observed_at": "Date", "current_price": "Price (₹)"},
        title="Recorded price over time (suspected outliers in red)",
    )
    # Connect the valid points with a line for readability.
    valid_line = history[history["Quality"] == config.OBS_VALID]
    fig.add_scatter(
        x=valid_line["observed_at"],
        y=valid_line["current_price"],
        mode="lines",
        line=dict(color="#2563eb"),
        name="valid",
        showlegend=False,
    )
    fig.update_layout(height=340, margin=dict(l=10, r=10, t=40, b=10))
    st.plotly_chart(fig, use_container_width=True)


def _to_dataframe(products: list[Product]) -> pd.DataFrame:
    rows = []
    for i, p in enumerate(products, start=1):
        rows.append(
            {
                "Rank": i,
                "Product": p.name,
                "Marketplace": p.marketplace,
                "Rating": p.rating,
                "Ratings": p.num_ratings,
                "Reviews": p.num_reviews,
                "Price (₹)": p.current_price,
                "MRP (₹)": p.original_price,
                "Discount %": p.discount_percent,
                "Seller": p.seller,
                "Availability": p.availability,
                "Bought last month": p.monthly_purchases_display,
                "Weighted": getattr(p, "weighted_score", None),
                "Relevance": p.relevance_score,
                "Sponsored": bool(p.is_sponsored),
                "Source": p.source.upper(),
                "URL": p.url,
            }
        )
    return pd.DataFrame(rows)


def render_table(products: list[Product]) -> None:
    df = _to_dataframe(products)
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "URL": st.column_config.LinkColumn("URL", display_text="Open ↗"),
            "Rating": st.column_config.NumberColumn(format="%.1f ⭐"),
            "Relevance": st.column_config.NumberColumn(format="%.0f%%"),
            "Sponsored": st.column_config.CheckboxColumn("Ad?"),
        },
    )
    st.caption(
        "Tip: click a column header to sort. The **Source** column "
        "shows LIVE vs SAMPLE."
    )


# --- comparison ------------------------------------------------------------
def render_compare(products: list[Product]) -> None:
    if len(products) < 2:
        st.info("Need at least two products in the results to compare.")
        return

    labels = {f"#{i} · {p.name[:60]}": p for i, p in enumerate(products, start=1)}
    picked_labels = st.multiselect(
        "Select 2–4 products to compare",
        options=list(labels),
        max_selections=4,
        key="compare_sel",
    )
    picked = [labels[lbl] for lbl in picked_labels]
    if len(picked) < 2:
        st.info("Pick at least two products above.")
        return

    data = {}
    for i, p in enumerate(picked, start=1):
        data[f"#{i} {p.name[:22]}"] = {
            "Marketplace": p.marketplace,
            "Price": fmt.rupees(p.current_price),
            "MRP": fmt.rupees(p.original_price),
            "Discount": fmt.percent(p.discount_percent),
            "Rating": fmt.rating(p.rating),
            "Ratings": fmt.count(p.num_ratings),
            "Reviews": fmt.count(p.num_reviews),
            "Seller": fmt.text(p.seller),
            "Availability": fmt.text(p.availability),
            "Bought last month": p.monthly_purchases_display,
            "Sponsored": "Yes" if p.is_sponsored else "No",
            "Source": p.source.upper(),
        }
    st.dataframe(pd.DataFrame(data), use_container_width=True)

    _render_compare_history(picked)


def _render_compare_history(picked: list[Product]) -> None:
    frames = []
    for i, p in enumerate(picked, start=1):
        if p.is_sample:
            continue
        hist = DB.get_history(p.product_id).dropna(subset=["current_price"])
        if len(hist) >= 2:
            hist = hist.copy()
            hist["Product"] = f"#{i} {p.name[:22]}"
            frames.append(hist)

    if not frames:
        st.caption(
            "No multi-point live price history yet for the selected " "products."
        )
        return

    combined = pd.concat(frames, ignore_index=True)
    fig = px.line(
        combined,
        x="observed_at",
        y="current_price",
        color="Product",
        markers=True,
        labels={"observed_at": "Date", "current_price": "Price (₹)"},
        title="Price history comparison",
    )
    fig.update_layout(height=360, margin=dict(l=10, r=10, t=40, b=10))
    st.plotly_chart(fig, use_container_width=True)


# --- main ------------------------------------------------------------------
def render_results() -> None:
    meta = st.session_state["meta"]
    results = st.session_state["results"]

    if meta.get("error"):
        st.warning(meta["error"])
        return
    if results is None:
        st.info(
            "👈 Choose a marketplace, enter a product or category, and "
            "press **Submit** to see the top-rated products."
        )
        return
    if not results:
        st.warning("No products passed validation for that search.")
        return

    refresh_error = st.session_state.get("refresh_error")
    if refresh_error:
        st.warning(f"⚠️ {refresh_error}")

    rank_label = st.session_state.get("rank_label", _default_rank_label())
    rank_mode = config.RANK_MODES[rank_label]
    ranked = ranking.rank_products(results, mode=rank_mode)

    criteria = _criteria_from_state()
    shown = filtering.apply_filters(ranked, criteria)

    st.subheader(f"Top {meta['limit']} '{meta['query']}' on {meta['marketplace']}")
    ts = meta["retrieved_at"].strftime("%Y-%m-%d %H:%M:%S")
    dropped_total = sum(meta.get("dropped", {}).values())
    caption = (
        f"Retrieved {ts} · ranked by **{rank_label}** · "
        f"{meta.get('retrieved', len(results))} fetched → "
        f"{len(results)} after validation → {len(shown)} shown · "
        f"{meta.get('stored', 0)} new observation(s) stored."
    )
    st.caption(caption)
    if dropped_total:
        detail = ", ".join(f"{n} {reason}" for reason, n in meta["dropped"].items())
        st.caption(f"Validation removed {dropped_total}: {detail}.")

    if meta.get("is_sample"):
        st.warning(
            "⚠️ Live data could not be retrieved (the marketplace likely "
            "blocked the request). Showing **clearly-labelled sample data** "
            "for demonstration. Sample records are not stored in price history."
        )

    tab_results, tab_compare = st.tabs(["📋 Results", "⚖️ Compare"])

    with tab_results:
        if not shown:
            st.warning(
                "No products match the current filters. Adjust them in " "the sidebar."
            )
        else:
            st.radio(
                "View",
                options=["Cards", "Table"],
                key="view_mode",
                horizontal=True,
                label_visibility="collapsed",
            )
            if st.session_state.get("view_mode") == "Table":
                render_table(shown)
            else:
                for i, product in enumerate(shown, start=1):
                    render_card(i, product)

    with tab_compare:
        render_compare(shown)


def _pct(value) -> str:
    return "—" if value is None else f"{value * 100:.0f}%"


def render_diagnostics() -> None:
    st.subheader("🩺 Scraper health")
    st.caption(
        "Derived from recorded searches (`search_runs`) and HTTP "
        "requests (`scrape_events`). Live scrapes populate this; demo "
        "runs make no requests."
    )

    d = DB.diagnostics_summary()
    if d["total_searches"] == 0 and d["total_requests"] == 0:
        st.info(
            "No activity recorded yet. Run some **Live** searches (or the "
            "collection job) to populate diagnostics."
        )
        return

    row1 = st.columns(4)
    row1[0].metric("Searches", f"{d['total_searches']:,}")
    row1[1].metric("Search success", _pct(d["search_success_rate"]))
    row1[2].metric("Empty-result rate", _pct(d["empty_result_rate"]))
    row1[3].metric("HTTP requests", f"{d['total_requests']:,}")

    row2 = st.columns(4)
    row2[0].metric("Request success", _pct(d["http_success_rate"]))
    row2[1].metric("Blocked / CAPTCHA", _pct(d["blocked_rate"]))
    avg_ms = d["avg_response_ms"]
    row2[2].metric("Avg response", "—" if avg_ms is None else f"{avg_ms} ms")
    row2[3].metric("Last successful", d["last_successful_retrieval"] or "—")

    charts = st.columns(2)
    status_df = DB.http_status_distribution()
    with charts[0]:
        st.markdown("**HTTP status codes**")
        if status_df.empty:
            st.caption("No HTTP requests recorded.")
        else:
            status_df["value"] = status_df["value"].astype(str)
            fig = px.bar(
                status_df,
                x="value",
                y="count",
                labels={"value": "Status", "count": "Requests"},
            )
            fig.update_layout(height=280, margin=dict(l=10, r=10, t=10, b=10))
            st.plotly_chart(fig, use_container_width=True)

    error_df = DB.error_type_distribution()
    with charts[1]:
        st.markdown("**Error types**")
        if error_df.empty:
            st.caption("No HTTP requests recorded.")
        else:
            fig = px.bar(
                error_df,
                x="value",
                y="count",
                labels={"value": "Type", "count": "Requests"},
            )
            fig.update_layout(height=280, margin=dict(l=10, r=10, t=10, b=10))
            st.plotly_chart(fig, use_container_width=True)

    _render_parser_quality()

    st.markdown("**Recent searches**")
    runs = DB.recent_runs(50)
    if runs.empty:
        st.caption("No searches recorded yet.")
    else:
        st.dataframe(runs, use_container_width=True, hide_index=True)

    with st.expander("Recent HTTP requests"):
        events = DB.recent_events(200)
        if events.empty:
            st.caption("No HTTP requests recorded yet.")
        else:
            st.dataframe(events, use_container_width=True, hide_index=True)


def _render_parser_quality() -> None:
    """Per-field extraction rates — flags likely selector breakage."""
    st.markdown("**Parser quality** (field extraction rate, live scrapes only)")
    pq = DB.parser_quality()
    if pq.empty:
        st.caption(
            "No live parse metrics yet — recorded when a live scrape returns "
            "results."
        )
        return

    threshold = config.PARSER_QUALITY_MIN_RATE
    pq = pq.assign(
        rate_pct=(pq["rate"] * 100).round(0),
        flag=pq["rate"].apply(
            lambda r: "⚠ low" if r is not None and r < threshold else "ok"
        ),
    )
    low = pq[pq["flag"] == "⚠ low"]
    if not low.empty:
        worst = ", ".join(
            f"{row.marketplace} {row.field} {row.rate_pct:.0f}%"
            for row in low.itertuples()
        )
        st.warning(
            f"⚠️ Low extraction rate (< {threshold:.0%}) — possible selector "
            f"breakage: {worst}"
        )
    st.dataframe(
        pq[["marketplace", "field", "present", "total", "rate_pct", "flag"]],
        use_container_width=True,
        hide_index=True,
        column_config={
            "rate_pct": st.column_config.NumberColumn("rate", format="%.0f%%")
        },
    )


def main() -> None:
    st.title("🛒 Product Analyzer")
    st.caption(
        "Top-rated products from Amazon India, Flipkart & Myntra — validated, "
        "filterable, comparable, with SQLite price-history tracking."
    )
    render_sidebar()
    if st.session_state.get("page") == _PAGE_DIAGNOSTICS:
        render_diagnostics()
    else:
        render_results()


if __name__ == "__main__":
    main()
