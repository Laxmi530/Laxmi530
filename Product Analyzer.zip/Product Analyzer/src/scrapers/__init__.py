"""Marketplace scrapers."""

from __future__ import annotations

from collections.abc import Callable

from .. import config, provenance
from ..models import Product
from . import sample_data
from .amazon import AmazonIndiaScraper
from .base import BaseScraper, ScraperError
from .flipkart import FlipkartScraper
from .myntra import MyntraScraper

_REGISTRY: dict[str, Callable[..., BaseScraper]] = {
    config.MARKETPLACE_AMAZON: AmazonIndiaScraper,
    config.MARKETPLACE_FLIPKART: FlipkartScraper,
    config.MARKETPLACE_MYNTRA: MyntraScraper,
}


def get_scraper(marketplace: str, recorder=None) -> BaseScraper:
    """Return an instance of the scraper for the given marketplace.

    ``recorder`` (optional) receives per-request diagnostics events.
    """
    try:
        return _REGISTRY[marketplace](recorder=recorder)
    except KeyError:
        raise ScraperError(f"Unknown marketplace: {marketplace!r}") from None


def _resolve_mode(mode: str | None) -> str:
    """Back-compat default: honour ENABLE_SAMPLE_FALLBACK when unspecified."""
    if mode:
        return mode
    return (
        config.DATA_MODE_LIVE_FALLBACK
        if config.ENABLE_SAMPLE_FALLBACK
        else config.DATA_MODE_LIVE
    )


def search(
    marketplace: str,
    query: str,
    limit: int,
    mode: str | None = None,
    recorder=None,
) -> list[Product]:
    """Search a marketplace for a product/category.

    ``mode`` controls the data source explicitly:

    - ``Demo``                    : always return labelled sample data.
    - ``Live``                    : scrape only; raise ``ScraperError`` on
      failure (no silent fallback).
    - ``Live with demo fallback`` : scrape, falling back to sample data on
      failure so the UI stays usable.

    ``recorder`` (optional) receives per-request diagnostics events.
    """
    mode = _resolve_mode(mode)

    if mode == config.DATA_MODE_DEMO:
        return sample_data.generate(marketplace, query, limit)

    scraper = get_scraper(marketplace, recorder=recorder)
    try:
        products = scraper.search(query, limit)
        if products:
            _record_parse_metrics(recorder, marketplace, products)
            return products
        raise ScraperError("No products parsed from live response.")
    except ScraperError:
        if mode == config.DATA_MODE_LIVE_FALLBACK:
            return sample_data.generate(marketplace, query, limit)
        raise  # Live mode: surface the failure clearly.


def _record_parse_metrics(recorder, marketplace: str, products) -> None:
    """Record per-field extraction rates for live results, if supported."""
    if recorder is None or not products or products[0].is_sample:
        return
    record = getattr(recorder, "record_parse_metrics", None)
    if record is None:
        return
    counts = provenance.extraction_counts(products)
    record(marketplace=marketplace, counts=counts, total=len(products))


__all__ = [
    "AmazonIndiaScraper",
    "FlipkartScraper",
    "MyntraScraper",
    "BaseScraper",
    "ScraperError",
    "get_scraper",
    "search",
    "sample_data",
]
