"""Base scraper: shared HTTP handling and parsing helpers."""

from __future__ import annotations

import re
import time
from abc import ABC, abstractmethod
from urllib.parse import urlencode

import requests

from .. import config, diagnostics, utils
from ..logging_config import get_logger
from ..models import Product

log = get_logger("scraper")


class ScraperError(Exception):
    """Raised when a live scrape cannot produce usable results."""


class BaseScraper(ABC):
    """Common functionality for marketplace scrapers.

    An optional ``recorder`` (any object exposing ``record_http_event(...)``,
    e.g. :class:`~src.database.PriceHistoryDB`) receives one event per HTTP
    fetch for health monitoring. ``query`` is set by :meth:`search` so events
    and logs can be attributed to a search.
    """

    marketplace: str = "Unknown"

    def __init__(
        self,
        session: requests.Session | None = None,
        recorder=None,
    ) -> None:
        self.session = session or requests.Session()
        self.session.headers.update(config.DEFAULT_HEADERS)
        self.recorder = recorder
        self.query: str | None = None

    # --- HTTP -------------------------------------------------------------
    def _get(self, url: str, params: dict | None = None) -> str:
        """GET a URL and return HTML text.

        Tries a plain HTTP request first. If that fails and
        ``config.ENABLE_BROWSER_FALLBACK`` is set, retries the page through a
        real browser (Playwright) — the only realistic way past bot walls such
        as Flipkart's 403/529 or JS-rendered pages. Requests are restricted to
        approved marketplace domains.
        """
        if not utils.is_allowed_url(url):
            raise ScraperError(f"Refusing to fetch disallowed URL: {url!r}")

        try:
            return self._http_fetch(url, params)
        except ScraperError:
            if config.ENABLE_BROWSER_FALLBACK:
                return self._browser_fetch(url, params)
            raise

    def _http_fetch(self, url: str, params: dict | None = None) -> str:
        """Plain requests-based fetch with retries.

        Only transient failures (``config.RETRYABLE_STATUS`` and network
        timeouts) are retried; permanent failures (400/401/403, CAPTCHA)
        fail fast. A server ``Retry-After`` header is honoured (capped). Emits
        one diagnostics event (final outcome) and a structured log line.
        """
        start = time.perf_counter()
        last_exc: Exception | None = None
        last_status: int | None = None
        error_type = "unknown"

        for attempt in range(config.REQUEST_RETRIES + 1):
            try:
                resp = self.session.get(
                    url, params=params, timeout=config.REQUEST_TIMEOUT
                )
                last_status = resp.status_code
                if resp.status_code == 200 and resp.text:
                    self._emit_event(url, 200, True, "ok", attempt, start)
                    return resp.text

                status = resp.status_code
                error_type = diagnostics.classify_http(status, None)
                err = ScraperError(f"{self.marketplace} returned HTTP {status}")
                if status not in config.RETRYABLE_STATUS:
                    self._emit_event(url, status, False, error_type, attempt, start)
                    raise err
                last_exc = err
                delay = self._retry_delay(resp, attempt)
            except requests.RequestException as exc:  # network-level failure
                last_exc = exc
                last_status = None
                error_type = diagnostics.classify_http(None, exc)
                delay = config.REQUEST_BACKOFF * (attempt + 1)

            if attempt < config.REQUEST_RETRIES:
                time.sleep(delay)

        self._emit_event(
            url, last_status, False, error_type, config.REQUEST_RETRIES, start
        )
        raise ScraperError(
            f"Failed to fetch {url!r} from {self.marketplace}: {last_exc}"
        )

    def _browser_fetch(self, url: str, params: dict | None = None) -> str:
        """Render a page in a headless browser and return its HTML.

        Degrades gracefully: raises ``ScraperError`` (recorded as a diagnostics
        event) if Playwright or a browser binary is not installed.
        """
        start = time.perf_counter()
        full_url = url
        if params:
            full_url = f"{url}?{urlencode(params)}"

        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            self._emit_event(full_url, None, False, "browser_unavailable", 0, start)
            raise ScraperError(
                "Browser fallback is enabled but Playwright is not installed "
                "(pip install playwright && python -m playwright install chromium)."
            ) from exc

        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=True)
                page = browser.new_page(
                    user_agent=config.DEFAULT_HEADERS["User-Agent"],
                    locale="en-IN",
                )
                page.goto(
                    full_url,
                    timeout=config.BROWSER_TIMEOUT_MS,
                    wait_until="domcontentloaded",
                )
                html = page.content()
                browser.close()
        except Exception as exc:  # browser missing / navigation / timeout
            self._emit_event(full_url, None, False, "browser_failed", 0, start)
            raise ScraperError(
                f"Browser fetch failed for {self.marketplace}: {exc}"
            ) from exc

        self._emit_event(full_url, 200, True, "ok_browser", 0, start)
        return html

    def _emit_event(
        self,
        url: str,
        status_code: int | None,
        ok: bool,
        error_type: str,
        retry_count: int,
        start: float,
    ) -> None:
        """Record and log the outcome of an HTTP fetch (no sensitive data)."""
        duration_ms = int((time.perf_counter() - start) * 1000)
        fields = dict(
            marketplace=self.marketplace,
            query=self.query,
            url=url,
            status_code=status_code,
            ok=ok,
            error_type=error_type,
            retry_count=retry_count,
            duration_ms=duration_ms,
        )
        if self.recorder is not None:
            try:
                self.recorder.record_http_event(**fields)
            except Exception:  # diagnostics must never break a scrape
                log.warning("failed to record scrape event", extra=fields)
        (log.info if ok else log.warning)("http_fetch", extra=fields)

    @staticmethod
    def _retry_delay(resp: requests.Response, attempt: int) -> float:
        """Honour Retry-After (capped) else exponential-ish backoff."""
        retry_after = resp.headers.get("Retry-After")
        if retry_after and retry_after.isdigit():
            return min(int(retry_after), config.MAX_RETRY_AFTER)
        return config.REQUEST_BACKOFF * (attempt + 1)

    # --- parsing helpers (static, easy to unit-test) ----------------------
    @staticmethod
    def parse_price(text: str | None) -> float | None:
        """Extract a rupee amount from noisy text like '₹1,299.00'."""
        if not text:
            return None
        cleaned = text.replace(",", "")
        match = re.search(r"(\d+(?:\.\d+)?)", cleaned)
        return float(match.group(1)) if match else None

    @staticmethod
    def parse_int(text: str | None) -> int | None:
        """Extract an integer count from text like '12,345 ratings'."""
        if not text:
            return None
        cleaned = text.replace(",", "")
        match = re.search(r"(\d+)", cleaned)
        return int(match.group(1)) if match else None

    @staticmethod
    def parse_rating(text: str | None) -> float | None:
        """Extract a 0-5 rating from text like '4.3 out of 5 stars'."""
        if not text:
            return None
        match = re.search(r"(\d(?:\.\d)?)", text)
        if not match:
            return None
        value = float(match.group(1))
        return value if 0 <= value <= 5 else None

    @staticmethod
    def extract_monthly_purchases(text: str | None) -> str | None:
        """Return raw 'X bought in past month' text if present, else None.

        Never fabricates or estimates — only returns what the page literally
        states.
        """
        if not text:
            return None
        match = re.search(
            r"([\d.,kK+]+\s*(?:bought|purchased)[^.<\n]*month)",
            text,
            flags=re.IGNORECASE,
        )
        return match.group(1).strip() if match else None

    # --- contract ---------------------------------------------------------
    @abstractmethod
    def search(self, query: str, limit: int) -> list[Product]:
        """Return up to ``limit`` products matching ``query``."""
        raise NotImplementedError
