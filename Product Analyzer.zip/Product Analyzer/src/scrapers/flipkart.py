"""Flipkart search-results scraper.

Flipkart renders results server-side but obfuscates its CSS class names
(they change frequently), so parsing relies on structural/heuristic cues.
When the layout is unrecognised the caller falls back to sample data.
"""

from __future__ import annotations

from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .. import config, utils
from ..models import Product
from .base import BaseScraper, ScraperError

_BASE = "https://www.flipkart.com"


class FlipkartScraper(BaseScraper):
    marketplace = config.MARKETPLACE_FLIPKART

    def search(self, query: str, limit: int) -> list[Product]:
        if not query or not query.strip():
            raise ScraperError("Empty query.")
        self.query = query.strip()
        html = self._get(config.FLIPKART_SEARCH_URL, params={"q": query.strip()})
        return self.parse_search(html, limit)

    def parse_search(self, html: str, limit: int) -> list[Product]:
        soup = BeautifulSoup(html, "lxml")

        # Anchor on product links; Flipkart product URLs contain '/p/'.
        anchors = [a for a in soup.select("a[href*='/p/']") if a.get_text(strip=True)]
        if not anchors:
            raise ScraperError("Flipkart layout not recognised (blocked?).")

        products: list[Product] = []
        seen: set[str] = set()
        for anchor in anchors:
            product = self._parse_anchor(anchor, soup)
            if not product or product.url in seen:
                continue
            seen.add(product.url)
            products.append(product)
            if len(products) >= limit:
                break
        if not products:
            raise ScraperError("No parsable Flipkart products found.")
        return products

    def _parse_anchor(self, anchor, soup) -> Product | None:
        href = anchor.get("href", "")
        if "/p/" not in href:
            return None
        url = urljoin(_BASE, href)
        pid = utils.flipkart_pid(url)

        # The clickable card is usually a nearby ancestor block.
        container = (
            anchor.find_parent(
                lambda tag: tag.name == "div" and tag.get_text(strip=True)
            )
            or anchor
        )

        name = anchor.get("title") or anchor.get_text(strip=True)
        if not name:
            return None

        img_el = container.select_one("img")
        image_url = img_el.get("src") if img_el else None

        text = container.get_text(" ")
        current_price = self._first_rupee(text)
        rating = self.parse_rating(self._rating_text(container))
        monthly = self.extract_monthly_purchases(text)
        is_sponsored = self._detect_sponsored(container)

        return Product(
            name=name[:200],
            marketplace=self.marketplace,
            url=url,
            native_id=pid,
            image_url=image_url,
            current_price=current_price,
            rating=rating,
            monthly_purchases=monthly,
            is_sponsored=is_sponsored,
            availability="In stock" if current_price else None,
        )

    @staticmethod
    def _detect_sponsored(container) -> bool:
        """Flipkart marks ad tiles with a small 'Ad' / 'Sponsored' badge."""
        for el in container.select("div, span"):
            label = el.get_text(strip=True)
            if label in ("Ad", "Sponsored", "Ad Sponsored"):
                return True
        return False

    @staticmethod
    def _first_rupee(text: str) -> float | None:
        import re

        match = re.search(r"₹\s*([\d,]+)", text)
        if not match:
            return None
        return float(match.group(1).replace(",", ""))

    @staticmethod
    def _rating_text(container) -> str | None:
        # Flipkart rating badges typically hold a bare number like "4.3".
        for div in container.select("div"):
            txt = div.get_text(strip=True)
            if txt and len(txt) <= 3:
                try:
                    val = float(txt)
                    if 0 <= val <= 5:
                        return txt
                except ValueError:
                    continue
        return None
