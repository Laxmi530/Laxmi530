"""Clearly-labelled sample data.

Used only as a fallback when live scraping is blocked (very common for
Amazon/Flipkart). Every record has ``is_sample=True`` so the UI can badge it
as demo data, and sample records are never written to the price-history
database. The numbers here are illustrative placeholders, not real listings.
"""

from __future__ import annotations

import hashlib

from .. import aspects as asp
from .. import config
from ..models import Product, ReviewAspect

# A small pool of realistic-looking attributes to vary the demo output.
_ADJECTIVES = ["Pro", "Max", "Lite", "Ultra", "Plus", "Neo", "Prime", "Air"]
_BRANDS = ["Aurora", "NexGen", "Volt", "Zephyr", "Cobalt", "Lumen", "Apex", "Nova"]
_STORAGES = ["64 GB", "128 GB", "256 GB", "512 GB"]
_COLORS = ["Black", "Blue", "Silver", "Graphite"]

# Amazon-style aspects: (name, base mention count, sentiment).
_AMAZON_ASPECTS = [
    ("Quality", 1700, asp.POSITIVE),
    ("Sound quality", 1400, asp.POSITIVE),
    ("Battery life", 652, asp.POSITIVE),
    ("Value for money", 648, asp.POSITIVE),
    ("Fit", 237, asp.POSITIVE),
    ("Comfort", 234, asp.POSITIVE),
    ("Reliability", 540, asp.MIXED),
    ("Connectivity", 463, asp.MIXED),
]
# Flipkart/Myntra-style aspects: (name, base rating).
_RATED_ASPECTS = [
    ("Sound Quality", 4.0),
    ("Bass", 4.0),
    ("Design & Build", 4.1),
    ("Battery Backup", 4.0),
    ("Value for Money", 3.9),
    ("Call Quality", 5.0),
]


def _sample_aspects(marketplace: str, seed: int) -> list[ReviewAspect]:
    """Deterministic, clearly-illustrative review aspects for a demo product."""
    if marketplace == config.MARKETPLACE_AMAZON:
        out = []
        for i, (name, base, sentiment) in enumerate(_AMAZON_ASPECTS):
            # Vary the count a little per product so cards aren't identical.
            count = int(base * (0.8 + ((seed >> (i + 1)) % 40) / 100.0))
            out.append(ReviewAspect(name=name, sentiment=sentiment, count=count))
        return out
    rated = []
    for j, (aspect_name, base_rating) in enumerate(_RATED_ASPECTS):
        rating = round(
            min(5.0, max(3.0, base_rating + ((seed >> (j + 1)) % 3 - 1) * 0.1)), 1
        )
        rated.append(
            ReviewAspect(
                name=aspect_name,
                sentiment=asp.sentiment_from_rating(rating),
                rating=rating,
            )
        )
    return rated


def _seed(text: str) -> int:
    # Non-cryptographic: SHA1 only seeds deterministic demo data.
    digest = hashlib.sha1(text.encode("utf-8"), usedforsecurity=False)
    return int(digest.hexdigest(), 16)


def generate(marketplace: str, query: str, limit: int) -> list[Product]:
    """Produce ``limit`` deterministic sample products for a query."""
    base = _seed(f"{marketplace}|{query.lower()}")
    slug = query.strip().replace(" ", "-").lower() or "product"
    products: list[Product] = []

    for i in range(limit):
        r = _seed(f"{base}|{i}")
        brand = _BRANDS[(r >> 3) % len(_BRANDS)]
        adj = _ADJECTIVES[(r >> 7) % len(_ADJECTIVES)]

        rating = round(3.5 + ((r >> 11) % 16) / 10.0, 1)  # 3.5 – 5.0
        rating = min(rating, 5.0)
        num_ratings = 50 + (r >> 5) % 25000
        num_reviews = int(num_ratings * (0.05 + ((r >> 9) % 20) / 100.0))

        original = 999 + (r % 40) * 500
        discount_pct = (r >> 13) % 45
        current = round(original * (1 - discount_pct / 100.0), 0)

        # Roughly half the demo records show a purchase badge; the rest do
        # not (mirroring reality, where the field is often absent).
        monthly: str | None = None
        if (r >> 4) % 2 == 0:
            buckets = ["500+", "1K+", "2K+", "5K+", "10K+"]
            monthly = f"{buckets[(r >> 6) % len(buckets)]} bought in past month"

        # Mark roughly one in four demo items as sponsored so the
        # "exclude sponsored" filter is visibly functional in demo mode.
        is_sponsored = (r >> 2) % 4 == 0

        # Illustrative variant attributes (kept distinct so histories aren't
        # mixed across variants).
        storage = _STORAGES[(r >> 8) % len(_STORAGES)]
        color = _COLORS[(r >> 10) % len(_COLORS)]

        products.append(
            Product(
                name=f"{brand} {query.title()} {adj} (Model {1000 + i})",
                marketplace=marketplace,
                url=f"https://example.com/{marketplace.split()[0].lower()}"
                f"/{slug}/p/{brand.lower()}-{adj.lower()}-{1000 + i}",
                product_id=f"SAMPLE-{marketplace[:2].upper()}-{slug}-{i}",
                image_url="https://placehold.co/300x300?text=" f"{brand}+{adj}",
                current_price=float(current),
                original_price=float(original),
                rating=rating,
                num_ratings=num_ratings,
                num_reviews=num_reviews,
                seller=f"{brand} Retail",
                availability="In stock",
                brand=brand,
                variant_name=f"{storage}, {color}",
                color=color,
                storage=storage,
                pack_size=1,
                monthly_purchases=monthly,
                is_sponsored=is_sponsored,
                aspects=_sample_aspects(marketplace, r),
                is_sample=True,
            )
        )
    return products
