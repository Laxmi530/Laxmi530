"""Myntra search-results scraper.

Myntra is a React app: its search results are rendered client-side, so a plain
HTTP request usually returns an app shell with no product markup (and Myntra
also challenges automated traffic). Reliable extraction therefore needs the
browser-render fallback (``PRODUCT_ANALYZER_BROWSER=1`` + Playwright); this
parser targets the rendered ``li.product-base`` cards.
"""

from __future__ import annotations

from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .. import config, utils
from ..models import Product
from .base import BaseScraper, ScraperError

_BASE = "https://www.myntra.com"


class MyntraScraper(BaseScraper):
    marketplace = config.MARKETPLACE_MYNTRA

    def search(self, query: str, limit: int) -> list[Product]:
        if not query or not query.strip():
            raise ScraperError("Empty query.")
        self.query = query.strip()
        slug = self.query.lower().replace(" ", "-")
        html = self._get(
            f"{config.MYNTRA_SEARCH_URL}/{slug}", params={"rawQuery": self.query}
        )
        return self.parse_search(html, limit)

    def parse_search(self, html: str, limit: int) -> list[Product]:
        soup = BeautifulSoup(html, "lxml")
        cards = soup.select("li.product-base")
        if not cards:
            raise ScraperError(
                "Myntra layout not recognised (JS-only shell or blocked). "
                "Enable the browser fallback (PRODUCT_ANALYZER_BROWSER=1)."
            )

        products: list[Product] = []
        for card in cards:
            product = self._parse_card(card)
            if product:
                products.append(product)
            if len(products) >= limit:
                break
        if not products:
            raise ScraperError("No parsable Myntra products found.")
        return products

    def _parse_card(self, card) -> Product | None:
        link = card.select_one("a[href]")
        if not link:
            return None
        url = urljoin(_BASE, link.get("href", "")).split("?")[0]

        brand = self._text(card, ".product-brand")
        title = self._text(card, ".product-product")
        name = " ".join(part for part in (brand, title) if part) or link.get("title")
        if not name:
            return None

        img = card.select_one("img")
        image_url = img.get("src") if img else None

        current_price = self.parse_price(
            self._text(card, ".product-discountedPrice, .product-price")
        )
        original_price = self.parse_price(self._text(card, ".product-strike"))
        rating = self.parse_rating(self._text(card, ".product-ratingsContainer"))
        num_ratings = self.parse_int(self._text(card, ".product-ratingsCount"))

        return Product(
            name=name[:200],
            marketplace=self.marketplace,
            url=url,
            native_id=utils.myntra_pid(url),
            image_url=image_url,
            brand=brand,
            current_price=current_price,
            original_price=original_price,
            rating=rating,
            num_ratings=num_ratings,
            availability="In stock" if current_price else None,
        )

    @staticmethod
    def _text(card, selector: str) -> str | None:
        el = card.select_one(selector)
        return el.get_text(strip=True) if el else None
