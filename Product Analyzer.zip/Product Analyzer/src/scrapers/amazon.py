"""Amazon India search-results scraper.

Parses the ``/s`` search page. Amazon frequently serves CAPTCHA / 503
interstitials to automated clients; when that happens the caller falls back
to sample data. Selectors are best-effort and may need updating as Amazon
changes its markup — kept isolated here for that reason.
"""

from __future__ import annotations

import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .. import config, utils
from ..models import Product
from ..provenance import FieldMeta, FieldStatus
from .base import BaseScraper, ScraperError

_BASE = "https://www.amazon.in"


class AmazonIndiaScraper(BaseScraper):
    marketplace = config.MARKETPLACE_AMAZON

    def search(self, query: str, limit: int) -> list[Product]:
        if not query or not query.strip():
            raise ScraperError("Empty query.")
        self.query = query.strip()
        html = self._get(config.AMAZON_SEARCH_URL, params={"k": query.strip()})
        return self.parse_search(html, limit)

    def parse_search(self, html: str, limit: int) -> list[Product]:
        soup = BeautifulSoup(html, "lxml")
        cards = soup.select("div[data-component-type='s-search-result']")
        if not cards:
            raise ScraperError("Amazon layout not recognised (blocked?).")

        products: list[Product] = []
        for card in cards:
            product = self._parse_card(card)
            if product:
                products.append(product)
            if len(products) >= limit:
                break
        if not products:
            raise ScraperError("No parsable Amazon products found.")
        return products

    def _parse_card(self, card) -> Product | None:
        title_el = card.select_one("h2 a span, h2 span")
        link_el = card.select_one("h2 a, a.a-link-normal.s-no-outline")
        if not title_el or not link_el:
            return None

        name = title_el.get_text(strip=True)
        href = link_el.get("href", "")
        url = urljoin(_BASE, href) if href else _BASE

        asin = card.get("data-asin") or utils.amazon_asin(url) or None

        image_el = card.select_one("img.s-image")
        image_url = image_el.get("src") if image_el else None

        provenance: dict[str, FieldMeta] = {}

        price_text = self._text(card, "span.a-price span.a-offscreen")
        current_price = self.parse_price(price_text)
        if price_text and current_price is None:
            provenance["current_price"] = FieldMeta(FieldStatus.PARSE_FAILED)

        original_price = self.parse_price(
            self._text(card, "span.a-price.a-text-price span.a-offscreen")
        )

        rating_text = self._text(card, "span.a-icon-alt")
        rating = self.parse_rating(rating_text)
        if rating_text and rating is None:
            provenance["rating"] = FieldMeta(FieldStatus.PARSE_FAILED)

        num_ratings = self.parse_int(
            self._attr(
                card,
                "a[href*='#customerReviews'] span, "
                "span.a-size-base.s-underline-text",
            )
        )

        card_text = card.get_text(" ")
        monthly = self.extract_monthly_purchases(card_text)
        is_sponsored = self._detect_sponsored(card, card_text)

        return Product(
            name=name,
            marketplace=self.marketplace,
            url=url,
            native_id=asin,
            image_url=image_url,
            current_price=current_price,
            original_price=original_price,
            rating=rating,
            num_ratings=num_ratings,
            monthly_purchases=monthly,
            is_sponsored=is_sponsored,
            availability="In stock" if current_price else None,
            provenance=provenance,
        )

    @staticmethod
    def _detect_sponsored(card, card_text: str) -> bool:
        """Amazon labels ad cards with a 'Sponsored' badge."""
        if card.select_one(
            "span.puis-sponsored-label-text, .s-sponsored-label-text, "
            "a.puis-label-popover"
        ):
            return True
        return bool(re.search(r"\bsponsored\b", card_text, re.IGNORECASE))

    @staticmethod
    def _text(card, selector: str) -> str | None:
        el = card.select_one(selector)
        return el.get_text(strip=True) if el else None

    @staticmethod
    def _attr(card, selector: str) -> str | None:
        el = card.select_one(selector)
        return el.get_text(strip=True) if el else None
