"""Per-field provenance and data-freshness helpers.

Each displayed value can carry a :class:`FieldMeta` (where it came from and
whether extraction succeeded), so the UI can distinguish "the marketplace does
not provide this" from "the parser failed" from "this is sample/cached/stale
data". Product-level source (live/sample) remains on the product itself.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from . import config


class FieldSource(StrEnum):
    SEARCH_PAGE = "search_page"
    PRODUCT_PAGE = "product_page"
    DERIVED = "derived"
    SAMPLE = "sample"
    NONE = "none"


class FieldStatus(StrEnum):
    SUCCESS = "success"
    NOT_PRESENT = "not_present"  # marketplace does not provide it
    PARSE_FAILED = "parse_failed"  # value was present but could not be parsed
    BLOCKED = "blocked"
    CACHED = "cached"
    SAMPLE = "sample"
    STALE = "stale"


@dataclass(frozen=True)
class FieldMeta:
    status: FieldStatus
    source: FieldSource = FieldSource.SEARCH_PAGE


# Freshness labels.
FRESH = "fresh"
RECENT = "recent"
STALE = "stale"


def freshness(retrieved_at: datetime, now: datetime | None = None) -> str:
    """Classify a value's age as ``fresh`` / ``recent`` / ``stale``."""
    now = now or datetime.now()
    age = (now - retrieved_at).total_seconds()
    if age < config.FRESH_SECONDS:
        return FRESH
    if age < config.RECENT_SECONDS:
        return RECENT
    return STALE


def extraction_counts(products: Iterable) -> dict[str, int]:
    """Count, per tracked field, how many products have a non-None value."""
    counts = dict.fromkeys(config.PARSE_TRACKED_FIELDS, 0)
    for product in products:
        for field in config.PARSE_TRACKED_FIELDS:
            if getattr(product, field, None) is not None:
                counts[field] += 1
    return counts
