"""Review-aspect ("Customers say") extraction.

Marketplaces summarise reviews by theme:

- **Amazon** — aspect chips with a mention count and a sentiment arrow
  (e.g. *Quality (1.7K) ↗*, *Reliability (540) ~*).
- **Flipkart / Myntra** — per-aspect star ratings (e.g. *Sound Quality 4★*).

These blocks live on the **product detail page**, not the search-results page,
so live extraction requires fetching the product page (or the browser
fallback). Selectors are best-effort and isolated here, like the scrapers.
"""

from __future__ import annotations

import re

from bs4 import BeautifulSoup

from .models import ReviewAspect

POSITIVE = "positive"
MIXED = "mixed"
NEGATIVE = "negative"
NEUTRAL = "neutral"


def parse_count(text: str | None) -> int | None:
    """Parse a mention count like ``1.7K`` / ``1,234`` / ``2K+`` / ``540``."""
    if not text:
        return None
    cleaned = text.strip().replace(",", "").replace("+", "")
    match = re.search(r"(\d+(?:\.\d+)?)\s*([kKmM]?)", cleaned)
    if not match:
        return None
    value = float(match.group(1))
    suffix = match.group(2).lower()
    if suffix == "k":
        value *= 1_000
    elif suffix == "m":
        value *= 1_000_000
    return int(round(value))


def sentiment_from_rating(rating: float) -> str:
    if rating >= 4.0:
        return POSITIVE
    if rating >= 3.0:
        return MIXED
    return NEGATIVE


def _sentiment_from_hint(hint: str) -> str:
    hint = (hint or "").lower()
    if "positive" in hint or "↗" in hint:
        return POSITIVE
    if "negative" in hint or "↘" in hint:
        return NEGATIVE
    if "mixed" in hint or "neutral" in hint or "~" in hint:
        return MIXED
    return NEUTRAL


def parse_amazon_aspects(html: str | BeautifulSoup) -> list[ReviewAspect]:
    """Extract Amazon 'Customers say' aspect chips (name + count + sentiment)."""
    soup = html if isinstance(html, BeautifulSoup) else BeautifulSoup(html, "lxml")
    aspects: list[ReviewAspect] = []
    for el in soup.select("[data-hook='cr-insights-aspect'], a.cr-insights-aspect"):
        name_el = el.select_one(".aspect-name")
        name = name_el.get_text(strip=True) if name_el else None
        count_el = el.select_one(".aspect-count")
        count_text = count_el.get_text(strip=True) if count_el else None

        if not name:
            # Text fallback: "Quality (1.7K)" / "Quality 1.7K".
            text = el.get_text(" ", strip=True)
            m = re.match(r"(.+?)\s*\(?([\d.,kKmM+]+)\)?$", text)
            if m:
                name, count_text = m.group(1).strip(), m.group(2)

        if not name:
            continue

        sentiment = _sentiment_from_hint(
            el.get("data-aspect-sentiment", "")
            or " ".join(el.get("class", []))
            or el.get_text(" ")
        )
        aspects.append(
            ReviewAspect(name=name, sentiment=sentiment, count=parse_count(count_text))
        )
    return aspects


def parse_flipkart_aspects(html: str | BeautifulSoup) -> list[ReviewAspect]:
    """Extract Flipkart/Myntra per-aspect star ratings (name + rating)."""
    soup = html if isinstance(html, BeautifulSoup) else BeautifulSoup(html, "lxml")
    aspects: list[ReviewAspect] = []
    for el in soup.select(".aspect-rating"):
        name_el = el.select_one(".aspect-name")
        rating_el = el.select_one(".aspect-value")
        name = name_el.get_text(strip=True) if name_el else None
        rating_text = rating_el.get_text(strip=True) if rating_el else None

        if not name:
            text = el.get_text(" ", strip=True)
            m = re.match(r"(.+?)\s*([0-5](?:\.\d)?)\s*★?$", text)
            if m:
                name, rating_text = m.group(1).strip(), m.group(2)

        if not name or not rating_text:
            continue
        try:
            rating = float(re.sub(r"[^\d.]", "", rating_text))
        except ValueError:
            continue
        aspects.append(
            ReviewAspect(
                name=name, sentiment=sentiment_from_rating(rating), rating=rating
            )
        )
    return aspects
