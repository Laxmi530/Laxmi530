"""SQLite-backed price-history tracking (normalised schema).

Three tables:

- ``products``           — one row per canonical product (static details).
- ``price_observations`` — one row per observation (the time series).
- ``search_runs``        — one row per search (UI or scheduled job), with
                           status/result-count for diagnostics.

Schema changes are applied through ordered, versioned migrations tracked with
SQLite's ``PRAGMA user_version`` — no ad-hoc "create if not exists" at call
sites. Legacy single-table (``price_records``) databases are migrated in
place.

No historical data is invented: aggregates are computed only from observations
that have actually accumulated over time.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable, Iterator
from contextlib import contextmanager, suppress
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

from . import config
from .anomaly import classify_price
from .filtering import is_in_stock_text
from .models import Product


class LockUnavailable(Exception):
    """Raised when a job lock is already held by another owner."""


# --------------------------------------------------------------------------
# Migrations
# --------------------------------------------------------------------------
_SCHEMA_V1 = """
CREATE TABLE IF NOT EXISTS products (
    id            TEXT PRIMARY KEY,          -- canonical product id
    marketplace   TEXT NOT NULL,
    native_id     TEXT,                      -- ASIN / PID when known
    canonical_url TEXT,
    name          TEXT NOT NULL,
    image_url     TEXT,
    first_seen    TEXT NOT NULL,
    last_seen     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_market_native
    ON products (marketplace, native_id);

CREATE TABLE IF NOT EXISTS search_runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    marketplace  TEXT NOT NULL,
    query        TEXT NOT NULL,
    mode         TEXT,
    status       TEXT,                       -- 'ok' | 'failed'
    result_count INTEGER,
    error        TEXT,
    started_at   TEXT NOT NULL,
    completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_market_time
    ON search_runs (marketplace, started_at);

CREATE TABLE IF NOT EXISTS price_observations (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id        TEXT NOT NULL REFERENCES products(id),
    run_id            INTEGER REFERENCES search_runs(id),
    current_price     REAL,
    original_price    REAL,
    discount_percent  REAL,
    rating            REAL,
    num_ratings       INTEGER,
    num_reviews       INTEGER,
    availability      TEXT,
    seller            TEXT,
    monthly_purchases TEXT,
    is_sponsored      INTEGER,               -- 0 | 1 | NULL
    source            TEXT,                  -- 'live' | 'sample'
    retrieval_status  TEXT,                  -- 'ok' | 'failed'
    observed_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_obs_product_time
    ON price_observations (product_id, observed_at);
CREATE INDEX IF NOT EXISTS idx_obs_time
    ON price_observations (observed_at);
"""


def _migrate_v1(conn: sqlite3.Connection) -> None:
    """Create the normalised schema and fold in any legacy price_records."""
    conn.executescript(_SCHEMA_V1)

    legacy = conn.execute(
        "SELECT name FROM sqlite_master " "WHERE type='table' AND name='price_records'"
    ).fetchone()
    if not legacy:
        return

    for row in conn.execute("SELECT * FROM price_records").fetchall():
        ts = row["retrieved_at"]
        conn.execute(
            """
            INSERT INTO products
                (id, marketplace, native_id, canonical_url,
                 name, image_url, first_seen, last_seen)
            VALUES (?, ?, NULL, ?, ?, NULL, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                last_seen = MAX(products.last_seen, excluded.last_seen)
            """,
            (
                row["product_id"],
                row["marketplace"],
                row["product_url"],
                row["product_name"],
                ts,
                ts,
            ),
        )
        conn.execute(
            """
            INSERT INTO price_observations
                (product_id, run_id, current_price, source,
                 retrieval_status, observed_at)
            VALUES (?, NULL, ?, 'live', 'ok', ?)
            """,
            (row["product_id"], row["current_price"], ts),
        )
    conn.execute("DROP TABLE price_records")


_SCHEMA_V2 = """
CREATE TABLE IF NOT EXISTS scrape_events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    marketplace  TEXT NOT NULL,
    query        TEXT,
    url          TEXT,
    status_code  INTEGER,
    ok           INTEGER,           -- 1 | 0
    error_type   TEXT,              -- ok | blocked | timeout | server_error | ...
    retry_count  INTEGER,
    duration_ms  INTEGER,
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_market_time
    ON scrape_events (marketplace, created_at);
CREATE INDEX IF NOT EXISTS idx_events_error
    ON scrape_events (error_type);
"""


def _migrate_v2(conn: sqlite3.Connection) -> None:
    """Add per-request scrape diagnostics."""
    conn.executescript(_SCHEMA_V2)


# Static ALTERs (fixed identifiers — no interpolation, so no injection risk).
_V3_ALTERS = (
    "ALTER TABLE products ADD COLUMN brand TEXT",
    "ALTER TABLE products ADD COLUMN model_number TEXT",
    "ALTER TABLE products ADD COLUMN variant_name TEXT",
    "ALTER TABLE products ADD COLUMN color TEXT",
    "ALTER TABLE products ADD COLUMN size TEXT",
    "ALTER TABLE products ADD COLUMN storage TEXT",
    "ALTER TABLE products ADD COLUMN pack_size INTEGER",
    "ALTER TABLE products ADD COLUMN parent_product_id TEXT",
)

_SCHEMA_V3 = """
CREATE TABLE IF NOT EXISTS parse_metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id      INTEGER REFERENCES search_runs(id),
    marketplace TEXT NOT NULL,
    field       TEXT NOT NULL,
    present     INTEGER NOT NULL,
    total       INTEGER NOT NULL,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_parse_metrics_market_field
    ON parse_metrics (marketplace, field);
"""


def _migrate_v3(conn: sqlite3.Connection) -> None:
    """Add product-variant columns and per-field parser-quality metrics."""
    for statement in _V3_ALTERS:
        with suppress(sqlite3.OperationalError):  # column already exists
            conn.execute(statement)
    conn.executescript(_SCHEMA_V3)


_V4_ALTERS = ("ALTER TABLE price_observations ADD COLUMN quality TEXT",)

_SCHEMA_V4 = """
CREATE TABLE IF NOT EXISTS job_locks (
    lock_name   TEXT PRIMARY KEY,
    owner_id    TEXT NOT NULL,
    acquired_at TEXT NOT NULL,
    expires_at  TEXT NOT NULL
);
"""


def _migrate_v4(conn: sqlite3.Connection) -> None:
    """Add observation quality (anomaly status) and a job-lock table."""
    for statement in _V4_ALTERS:
        with suppress(sqlite3.OperationalError):  # column already exists
            conn.execute(statement)
    conn.executescript(_SCHEMA_V4)


# Ordered list; index+1 is the version each migration brings the DB to.
_MIGRATIONS = [_migrate_v1, _migrate_v2, _migrate_v3, _migrate_v4]

# Prebuilt, fully-static distribution queries (no string interpolation, so no
# SQL-injection surface — column/table names are fixed here).
_DISTRIBUTION_QUERIES = {
    "status_code": (
        "SELECT status_code AS value, COUNT(*) AS count FROM scrape_events "
        "WHERE status_code IS NOT NULL GROUP BY status_code ORDER BY count DESC"
    ),
    "error_type": (
        "SELECT error_type AS value, COUNT(*) AS count FROM scrape_events "
        "WHERE error_type IS NOT NULL GROUP BY error_type ORDER BY count DESC"
    ),
}


class PriceHistoryDB:
    """Wrapper around a normalised SQLite price-history database."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        self.db_path = Path(db_path) if db_path else config.DATABASE_PATH
        if str(self.db_path) != ":memory:":
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._migrate()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        # WAL + busy_timeout let the Streamlit app and the scheduled collector
        # touch the same file concurrently without "database is locked" errors.
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 5000")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _migrate(self) -> None:
        with self._connect() as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            for target, migration in enumerate(_MIGRATIONS, start=1):
                if version < target:
                    migration(conn)
                    conn.execute(f"PRAGMA user_version = {target}")

    @property
    def schema_version(self) -> int:
        with self._connect() as conn:
            return int(conn.execute("PRAGMA user_version").fetchone()[0])

    # --- products ---------------------------------------------------------
    def _upsert_product(self, conn: sqlite3.Connection, product: Product) -> None:
        ts = product.retrieved_at.isoformat(timespec="seconds")
        conn.execute(
            """
            INSERT INTO products
                (id, marketplace, native_id, canonical_url, name, image_url,
                 brand, model_number, variant_name, color, size, storage,
                 pack_size, parent_product_id, first_seen, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name          = excluded.name,
                image_url     = COALESCE(excluded.image_url, products.image_url),
                native_id     = COALESCE(excluded.native_id, products.native_id),
                canonical_url = excluded.canonical_url,
                variant_name  = COALESCE(excluded.variant_name, products.variant_name),
                last_seen     = MAX(products.last_seen, excluded.last_seen)
            """,
            (
                product.product_id,
                product.marketplace,
                product.native_id,
                product.url,
                product.name,
                product.image_url,
                product.brand,
                product.model_number,
                product.variant_name,
                product.color,
                product.size,
                product.storage,
                product.pack_size,
                product.parent_product_id,
                ts,
                ts,
            ),
        )

    # --- runs -------------------------------------------------------------
    def start_run(self, marketplace: str, query: str, mode: str) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO search_runs
                    (marketplace, query, mode, status, started_at)
                VALUES (?, ?, ?, 'running', ?)
                """,
                (
                    marketplace,
                    query,
                    mode,
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            # lastrowid is always set after a successful AUTOINCREMENT insert.
            return int(cur.lastrowid or 0)

    def finish_run(
        self,
        run_id: int,
        status: str,
        result_count: int | None = None,
        error: str | None = None,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE search_runs
                SET status = ?, result_count = ?, error = ?, completed_at = ?
                WHERE id = ?
                """,
                (
                    status,
                    result_count,
                    error,
                    datetime.now().isoformat(timespec="seconds"),
                    run_id,
                ),
            )

    def distinct_tracked_searches(self) -> list[tuple[str, str]]:
        """Distinct (marketplace, query) pairs from successful past runs."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT DISTINCT marketplace, query
                FROM search_runs
                WHERE status = 'ok'
                ORDER BY marketplace, query
                """
            ).fetchall()
        return [(r["marketplace"], r["query"]) for r in rows]

    # --- observations -----------------------------------------------------
    def _last_observation(
        self, product_id: str
    ) -> tuple[float | None, datetime] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT current_price, observed_at
                FROM price_observations
                WHERE product_id = ?
                ORDER BY observed_at DESC
                LIMIT 1
                """,
                (product_id,),
            ).fetchone()
        if row is None:
            return None
        return row["current_price"], datetime.fromisoformat(row["observed_at"])

    def record_observation(
        self,
        product: Product,
        run_id: int | None = None,
        status: str = "ok",
    ) -> bool:
        """Store one observation (and upsert its product).

        Returns ``True`` if written, ``False`` if skipped. Sample records are
        never persisted. A duplicate observation (unchanged price within
        ``config.PRICE_DEDUP_INTERVAL`` seconds) is skipped; a changed price is
        always stored.
        """
        if product.is_sample:
            return False

        # product_id is always populated in Product.__post_init__.
        pid = product.product_id or ""
        last = self._last_observation(pid)
        if last is not None:
            last_price, last_ts = last
            unchanged = last_price == product.current_price
            within_window = (
                abs((product.retrieved_at - last_ts).total_seconds())
                < config.PRICE_DEDUP_INTERVAL
            )
            if unchanged and within_window:
                return False

        # Anomaly check against prior *valid* prices for this product.
        quality, _reason = classify_price(
            product.current_price, self._valid_prices(pid)
        )

        sponsored = None if product.is_sponsored is None else int(product.is_sponsored)
        with self._connect() as conn:
            self._upsert_product(conn, product)
            conn.execute(
                """
                INSERT INTO price_observations
                    (product_id, run_id, current_price, original_price,
                     discount_percent, rating, num_ratings, num_reviews,
                     availability, seller, monthly_purchases, is_sponsored,
                     source, retrieval_status, quality, observed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    product.product_id,
                    run_id,
                    product.current_price,
                    product.original_price,
                    product.discount_percent,
                    product.rating,
                    product.num_ratings,
                    product.num_reviews,
                    product.availability,
                    product.seller,
                    product.monthly_purchases,
                    sponsored,
                    product.source,
                    status,
                    quality,
                    product.retrieved_at.isoformat(timespec="seconds"),
                ),
            )
        return True

    def _valid_prices(self, product_id: str) -> list[float]:
        """Prior non-anomalous priced observations, oldest first."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT current_price
                FROM price_observations
                WHERE product_id = ? AND current_price IS NOT NULL
                  AND (quality IS NULL OR quality = ?)
                ORDER BY observed_at ASC
                """,
                (product_id, config.OBS_VALID),
            ).fetchall()
        return [float(r["current_price"]) for r in rows]

    def record_price(
        self,
        product: Product,
        run_id: int | None = None,
        status: str = "ok",
    ) -> bool:
        """Backwards-compatible alias for :meth:`record_observation`."""
        return self.record_observation(product, run_id, status)

    def record_many(
        self, products: Iterable[Product], run_id: int | None = None
    ) -> int:
        """Record several observations; returns the number actually stored."""
        return sum(1 for p in products if self.record_observation(p, run_id))

    # --- reads ------------------------------------------------------------
    def get_history(self, product_id: str) -> pd.DataFrame:
        """All observations for a product, oldest first."""
        with self._connect() as conn:
            df = pd.read_sql_query(
                """
                SELECT observed_at, current_price, original_price,
                       discount_percent, rating, num_ratings, num_reviews,
                       availability, seller, monthly_purchases, source, quality
                FROM price_observations
                WHERE product_id = ?
                ORDER BY observed_at ASC
                """,
                conn,
                params=(product_id,),
            )
        if not df.empty:
            df["observed_at"] = pd.to_datetime(df["observed_at"])
        return df

    @staticmethod
    def _num_price_changes(prices: pd.Series) -> int:
        """Count how many times the price actually differed from the prior."""
        return int((prices != prices.shift()).sum() - 1) if len(prices) > 1 else 0

    def get_stats(self, product_id: str) -> dict | None:
        """Aggregate price statistics, or ``None`` if no priced records.

        Aggregates (lowest/highest/average/median) use only ``valid``
        observations — ``suspected_outlier`` rows are excluded so a single bad
        parse can't distort them — while ``current``/``previous`` reflect the
        latest actual observations.
        """
        df = self.get_history(product_id)
        priced = df.dropna(subset=["current_price"])
        if priced.empty:
            return None

        quality = priced["quality"]
        valid = priced[quality.isna() | (quality == config.OBS_VALID)]
        agg = valid if not valid.empty else priced
        agg_prices = agg["current_price"]

        prices = priced["current_price"]
        current = float(prices.iloc[-1])
        previous = float(prices.iloc[-2]) if len(prices) >= 2 else None
        pct_change = None
        if previous is not None and previous > 0:
            pct_change = round((current - previous) / previous * 100, 2)

        in_stock = priced["availability"].apply(is_in_stock_text)
        last_seen = priced["observed_at"].iloc[-1]

        # Date of the most recent actual price change.
        changed = prices != prices.shift()
        change_idx = [i for i, c in enumerate(changed) if c]
        last_change_at = priced["observed_at"].iloc[change_idx[-1]]
        days_since_change = int((last_seen - last_change_at).days)

        return {
            "record_count": int(len(valid)),
            "num_checks": int(len(priced)),
            "num_changes": self._num_price_changes(prices),
            "anomalies": int(len(priced) - len(valid)),
            "current": current,
            "previous": previous,
            "lowest": float(agg_prices.min()),
            "highest": float(agg_prices.max()),
            "average": round(float(agg_prices.mean()), 2),
            "median": round(float(agg_prices.median()), 2),
            "pct_change": pct_change,
            "in_stock_pct": round(float(in_stock.mean()) * 100, 1),
            "days_since_change": days_since_change,
            "lowest_date": agg.loc[agg_prices.idxmin(), "observed_at"],
            "highest_date": agg.loc[agg_prices.idxmax(), "observed_at"],
            "first_seen": priced["observed_at"].iloc[0],
            "last_seen": last_seen,
        }

    # --- diagnostics (scrape health) -------------------------------------
    def record_http_event(
        self,
        *,
        marketplace: str,
        url: str | None,
        status_code: int | None,
        ok: bool,
        error_type: str,
        retry_count: int,
        duration_ms: int,
        query: str | None = None,
    ) -> None:
        """Record one HTTP attempt's outcome for health monitoring."""
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO scrape_events
                    (marketplace, query, url, status_code, ok, error_type,
                     retry_count, duration_ms, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    marketplace,
                    query,
                    url,
                    status_code,
                    int(ok),
                    error_type,
                    retry_count,
                    duration_ms,
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )

    def diagnostics_summary(self) -> dict:
        """Aggregate scrape health from search_runs and scrape_events."""
        with self._connect() as conn:
            runs = pd.read_sql_query("SELECT * FROM search_runs", conn)
            events = pd.read_sql_query("SELECT * FROM scrape_events", conn)

        summary: dict = {
            "total_searches": int(len(runs)),
            "total_requests": int(len(events)),
            "search_success_rate": None,
            "empty_result_rate": None,
            "last_successful_retrieval": None,
            "http_success_rate": None,
            "blocked_rate": None,
            "avg_response_ms": None,
        }

        if not runs.empty:
            ok_runs = runs[runs["status"] == "ok"]
            summary["search_success_rate"] = round(len(ok_runs) / len(runs), 3)
            if not ok_runs.empty:
                counts = ok_runs["result_count"].fillna(0)
                summary["empty_result_rate"] = round((counts == 0).mean(), 3)
                fruitful = ok_runs[counts > 0]["completed_at"].dropna()
                if not fruitful.empty:
                    summary["last_successful_retrieval"] = fruitful.max()

        if not events.empty:
            summary["http_success_rate"] = round(events["ok"].mean(), 3)
            summary["blocked_rate"] = round(
                (events["error_type"] == "blocked").mean(), 3
            )
            durations = events["duration_ms"].dropna()
            if not durations.empty:
                summary["avg_response_ms"] = int(durations.mean())

        return summary

    def recent_runs(self, limit: int = 50) -> pd.DataFrame:
        with self._connect() as conn:
            return pd.read_sql_query(
                """
                SELECT started_at, marketplace, query, mode, status,
                       result_count, error, completed_at
                FROM search_runs ORDER BY id DESC LIMIT ?
                """,
                conn,
                params=(limit,),
            )

    def recent_events(self, limit: int = 200) -> pd.DataFrame:
        with self._connect() as conn:
            return pd.read_sql_query(
                """
                SELECT created_at, marketplace, query, status_code, ok,
                       error_type, retry_count, duration_ms, url
                FROM scrape_events ORDER BY id DESC LIMIT ?
                """,
                conn,
                params=(limit,),
            )

    def _distribution(self, column: str) -> pd.DataFrame:
        with self._connect() as conn:
            return pd.read_sql_query(_DISTRIBUTION_QUERIES[column], conn)

    def http_status_distribution(self) -> pd.DataFrame:
        return self._distribution("status_code")

    def error_type_distribution(self) -> pd.DataFrame:
        return self._distribution("error_type")

    # --- parser-quality metrics ------------------------------------------
    def record_parse_metrics(
        self,
        *,
        marketplace: str,
        counts: dict[str, int],
        total: int,
        run_id: int | None = None,
    ) -> None:
        """Store per-field extraction counts (present / total) for a scrape."""
        now = datetime.now().isoformat(timespec="seconds")
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO parse_metrics
                    (run_id, marketplace, field, present, total, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                [
                    (run_id, marketplace, field, present, total, now)
                    for field, present in counts.items()
                ],
            )

    def parser_quality(self) -> pd.DataFrame:
        """Per-(marketplace, field) extraction rate across all recorded scrapes.

        Columns: marketplace, field, present, total, rate (0-1).
        """
        with self._connect() as conn:
            df = pd.read_sql_query(
                """
                SELECT marketplace, field,
                       SUM(present) AS present, SUM(total) AS total
                FROM parse_metrics
                GROUP BY marketplace, field
                ORDER BY marketplace, field
                """,
                conn,
            )
        if not df.empty:
            df["rate"] = (df["present"] / df["total"]).where(df["total"] > 0)
        return df

    # --- job locking ------------------------------------------------------
    def acquire_lock(self, name: str, owner: str, ttl_seconds: int) -> bool:
        """Try to take a named lock. Recovers locks whose TTL has expired.

        Returns ``True`` if acquired, ``False`` if another owner holds it.
        """
        now = datetime.now()
        expires = now + timedelta(seconds=ttl_seconds)
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM job_locks WHERE expires_at <= ?",
                (now.isoformat(timespec="seconds"),),
            )
            try:
                conn.execute(
                    """
                    INSERT INTO job_locks (lock_name, owner_id, acquired_at,
                                           expires_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        name,
                        owner,
                        now.isoformat(timespec="seconds"),
                        expires.isoformat(timespec="seconds"),
                    ),
                )
            except sqlite3.IntegrityError:
                return False  # held by someone else and not yet expired
        return True

    def release_lock(self, name: str, owner: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM job_locks WHERE lock_name = ? AND owner_id = ?",
                (name, owner),
            )

    @contextmanager
    def job_lock(self, name: str, owner: str, ttl_seconds: int) -> Iterator[None]:
        """Hold a named lock for the duration of the block.

        Raises :class:`LockUnavailable` if another owner already holds it.
        """
        if not self.acquire_lock(name, owner, ttl_seconds):
            raise LockUnavailable(name)
        try:
            yield
        finally:
            self.release_lock(name, owner)

    # --- counts -----------------------------------------------------------
    def total_observations(self) -> int:
        with self._connect() as conn:
            return int(
                conn.execute("SELECT COUNT(*) FROM price_observations").fetchone()[0]
            )

    def product_count(self) -> int:
        with self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM products").fetchone()[0])

    # Backwards-compatible alias.
    def total_records(self) -> int:
        return self.total_observations()
