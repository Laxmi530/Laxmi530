"""Product Analyzer — retrieve and rank top-rated products from Indian marketplaces."""

__version__ = "1.0.0"
