"""Ranking of products.

Modes (see ``config.RANK_MODES``):

- ``weighted`` : Bayesian weighted rating (default). Balances the rating
  against how many people rated it, so a 5.0 from 2 users does not beat a
  4.7 from 50,000. Tie-broken by rating count then reviews.
- ``rating``   : raw customer rating, tie-broken by rating count then reviews.
- ``popular``  : most ratings first.
- ``price_low``: lowest current price first.
- ``discount`` : highest discount percentage first.

Products missing the sort field sink to the bottom rather than being dropped.
"""

from __future__ import annotations

from . import config
from .models import Product


def _mean_rating(products: list[Product]) -> float:
    rated = [p.rating for p in products if p.rating is not None]
    return sum(rated) / len(rated) if rated else 0.0


def weighted_rating(
    product: Product, mean: float, m: int = config.BAYESIAN_MIN_RATINGS
) -> float:
    """Bayesian weighted rating:  (v/(v+m))*R + (m/(v+m))*C.

    ``R`` = product rating, ``v`` = number of ratings, ``C`` = mean rating
    across the result set, ``m`` = minimum-ratings threshold. Products with no
    rating score 0.
    """
    if product.rating is None:
        return 0.0
    v = product.num_ratings or 0
    r = product.rating
    if v + m == 0:
        return r
    return (v / (v + m)) * r + (m / (v + m)) * mean


def compute_scores(
    products: list[Product], m: int = config.BAYESIAN_MIN_RATINGS
) -> None:
    """Attach a ``weighted_score`` attribute to each product (for display)."""
    mean = _mean_rating(products)
    for p in products:
        p.weighted_score = round(weighted_rating(p, mean, m), 3)


def rank_products(
    products: list[Product],
    limit: int | None = None,
    mode: str = config.DEFAULT_RANK_MODE,
) -> list[Product]:
    """Return products sorted best-first for ``mode``, optionally truncated."""
    compute_scores(products)
    mean = _mean_rating(products)

    def sort_key(p: Product) -> tuple:
        if mode == "rating":
            return (
                -(p.rating if p.rating is not None else -1.0),
                -(p.num_ratings or 0),
                -(p.num_reviews or 0),
            )
        if mode == "popular":
            return (-(p.num_ratings or 0), -(p.rating or 0))
        if mode == "price_low":
            # Missing prices sort last (treated as +inf).
            price = p.current_price if p.current_price is not None else float("inf")
            return (price,)
        if mode == "discount":
            return (-(p.discount_percent or 0),)
        if mode == "relevance":
            # Combine title relevance with the weighted rating so the best
            # on-topic AND well-rated products rise to the top.
            relevance = getattr(p, "relevance_score", None) or 0
            return (
                -(relevance * weighted_rating(p, mean)),
                -(p.num_ratings or 0),
            )
        # "weighted" (default)
        return (
            -weighted_rating(p, mean),
            -(p.num_ratings or 0),
            -(p.num_reviews or 0),
        )

    ranked = sorted(products, key=sort_key)
    return ranked[:limit] if limit is not None else ranked
