"""User-facing result filters (applied after validation, before display)."""

from __future__ import annotations

from dataclasses import dataclass

from .models import Product

_OUT_OF_STOCK_MARKERS = (
    "out of stock",
    "unavailable",
    "sold out",
    "currently unavailable",
)


def is_in_stock_text(availability: str | None) -> bool:
    """Best-effort in-stock check from an availability string.

    Unknown/empty availability is treated as *not* confirmed in stock, so an
    "in stock only" filter (and the in-stock-% statistic) stays conservative.
    """
    text = (availability or "").lower().strip()
    if not text:
        return False
    return not any(marker in text for marker in _OUT_OF_STOCK_MARKERS)


def is_in_stock(product: Product) -> bool:
    return is_in_stock_text(product.availability)


@dataclass
class FilterCriteria:
    min_rating: float = 0.0
    min_num_ratings: int = 0
    min_price: float | None = None
    max_price: float | None = None
    min_discount: float = 0.0
    in_stock_only: bool = False
    exclude_sponsored: bool = False

    @property
    def is_active(self) -> bool:
        """True if any filter would actually narrow the results."""
        return (
            self.min_rating > 0
            or self.min_num_ratings > 0
            or self.min_price is not None
            or self.max_price is not None
            or self.min_discount > 0
            or self.in_stock_only
            or self.exclude_sponsored
        )


def _passes(product: Product, c: FilterCriteria) -> bool:
    if c.min_rating > 0 and (product.rating is None or product.rating < c.min_rating):
        return False
    if c.min_num_ratings > 0 and (product.num_ratings or 0) < c.min_num_ratings:
        return False
    if c.min_price is not None and (
        product.current_price is None or product.current_price < c.min_price
    ):
        return False
    if c.max_price is not None and (
        product.current_price is None or product.current_price > c.max_price
    ):
        return False
    if c.min_discount > 0 and (product.discount_percent or 0) < c.min_discount:
        return False
    if c.in_stock_only and not is_in_stock(product):
        return False
    return not (c.exclude_sponsored and product.is_sponsored)


def apply_filters(products: list[Product], c: FilterCriteria) -> list[Product]:
    """Return only the products satisfying every active criterion."""
    if not c.is_active:
        return list(products)
    return [p for p in products if _passes(p, c)]
