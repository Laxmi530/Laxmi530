"""Application health check.

Used by the diagnostics UI, tests, and as a container liveness probe
(``python -m src.health``). Streamlit also serves its own HTTP probe at
``/_stcore/health``; this checks the parts that matter to *this* app —
principally that the database opens and is migrated.
"""

from __future__ import annotations

import json
import sys

from . import __version__
from .database import PriceHistoryDB


def check_health(db: PriceHistoryDB | None = None) -> dict:
    """Return a health report dict. ``status`` is 'ok' or 'error'."""
    try:
        db = db or PriceHistoryDB()
        return {
            "status": "ok",
            "version": __version__,
            "schema_version": db.schema_version,
            "products": db.product_count(),
            "observations": db.total_observations(),
        }
    except Exception as exc:  # pragma: no cover - defensive
        return {"status": "error", "version": __version__, "error": str(exc)}


def main() -> int:
    report = check_health()
    print(json.dumps(report))
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
