"""Result-quality validation, relevance scoring and de-duplication.

Scrapers can surface off-topic listings, accessories, malformed prices or
duplicate cards. This module scores each result's relevance to the query,
checks it for data sanity, and removes duplicates — returning both the kept
products and a reason for every dropped one (for UI transparency).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from . import config, utils
from .models import Product

_TOKEN_RE = re.compile(r"[a-z0-9]+")
_STOPWORDS = {
    "the",
    "a",
    "an",
    "for",
    "with",
    "and",
    "or",
    "of",
    "in",
    "to",
    "on",
    "best",
    "top",
    "new",
}


def _tokens(text: str) -> list[str]:
    return [
        t
        for t in _TOKEN_RE.findall((text or "").lower())
        if t not in _STOPWORDS and len(t) > 1
    ]


def relevance_score(query: str, title: str) -> float:
    """Share of query tokens present in the title (0-1).

    An empty query is treated as "everything matches" (1.0).
    """
    q = set(_tokens(query))
    if not q:
        return 1.0
    t = set(_tokens(title))
    if not t:
        return 0.0
    return round(len(q & t) / len(q), 3)


@dataclass
class ValidationResult:
    relevance: float
    issues: list[str] = field(default_factory=list)

    @property
    def is_sane(self) -> bool:
        """True if no data-sanity problems (ignores relevance)."""
        return not self.issues

    def is_valid(self, min_relevance: float) -> bool:
        return self.is_sane and self.relevance >= min_relevance


def validate_product(product: Product, query: str) -> ValidationResult:
    """Score relevance and collect any data-sanity issues for a product."""
    issues: list[str] = []

    if not product.url:
        issues.append("missing URL")
    elif not product.is_sample and not utils.is_allowed_url(product.url):
        issues.append("disallowed URL")

    if product.rating is not None and not (0 <= product.rating <= 5):
        issues.append("rating out of range")

    if product.current_price is not None and product.current_price <= 0:
        issues.append("non-positive price")

    if (
        product.original_price is not None
        and product.current_price is not None
        and product.original_price < product.current_price
    ):
        issues.append("MRP below current price")

    if product.discount_percent is not None and not (
        0 <= product.discount_percent <= config.MAX_REASONABLE_DISCOUNT
    ):
        issues.append("implausible discount")

    return ValidationResult(
        relevance=relevance_score(query, product.name), issues=issues
    )


def clean_results(
    products: list[Product],
    query: str,
    min_relevance: float = config.MIN_RELEVANCE,
) -> tuple[list[Product], list[tuple[Product, str]]]:
    """Validate, de-duplicate and score a result set.

    Returns ``(kept, dropped)`` where ``dropped`` pairs each removed product
    with a short reason. Every kept product has ``relevance_score`` set.
    Sponsored products are *identified* (``is_sponsored``) but not dropped here
    — excluding them is a user filter (see :mod:`src.filtering`).
    """
    kept: list[Product] = []
    dropped: list[tuple[Product, str]] = []
    seen: set = set()

    for product in products:
        result = validate_product(product, query)
        product.relevance_score = result.relevance

        if not result.is_sane:
            dropped.append((product, "; ".join(result.issues)))
            continue
        if result.relevance < min_relevance:
            dropped.append((product, "off-topic (low relevance)"))
            continue
        if product.product_id in seen:
            dropped.append((product, "duplicate"))
            continue

        seen.add(product.product_id)
        kept.append(product)

    return kept, dropped
