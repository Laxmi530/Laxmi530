"""Structured JSON logging.

Emits one JSON object per log line with a stable set of fields plus any
``extra=`` keys passed at the call site. Never logs request headers, cookies
or credentials — callers pass only non-sensitive fields such as marketplace,
query, request_url, status_code, retry_count, error_type and duration_ms.
"""

from __future__ import annotations

import json
import logging

from . import config

APP_LOGGER = "product_analyzer"

# Default attributes present on every LogRecord; anything else is treated as a
# structured "extra" field and included in the JSON output.
_STANDARD_ATTRS = {
    "args",
    "asctime",
    "created",
    "exc_info",
    "exc_text",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "module",
    "msecs",
    "message",
    "msg",
    "name",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "thread",
    "threadName",
    "taskName",
}


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "time": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key not in _STANDARD_ATTRS and not key.startswith("_"):
                payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(
    level: int | str | None = None, json_format: bool = True
) -> logging.Logger:
    """Configure the application logger. Idempotent (safe under Streamlit reruns).

    ``level`` defaults to ``config.LOG_LEVEL`` (overridable via the
    ``PRODUCT_ANALYZER_LOG_LEVEL`` environment variable).
    """
    if level is None:
        level = config.LOG_LEVEL
    logger = logging.getLogger(APP_LOGGER)
    logger.setLevel(level)
    logger.propagate = False
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            JsonFormatter()
            if json_format
            else logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        )
        logger.addHandler(handler)
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a child of the application logger."""
    return logging.getLogger(f"{APP_LOGGER}.{name}" if name else APP_LOGGER)
