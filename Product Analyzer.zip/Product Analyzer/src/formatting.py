"""Small display-formatting helpers shared by the UI."""

from __future__ import annotations

from . import config


def rupees(value: float | None) -> str:
    if value is None:
        return config.NOT_AVAILABLE
    return f"₹{value:,.0f}"


def percent(value: float | None) -> str:
    if value is None:
        return config.NOT_AVAILABLE
    return f"{value:.1f}%"


def signed_percent(value: float | None) -> str:
    if value is None:
        return config.NOT_AVAILABLE
    sign = "+" if value > 0 else ""
    return f"{sign}{value:.2f}%"


def count(value: int | None) -> str:
    if value is None:
        return config.NOT_AVAILABLE
    return f"{value:,}"


def compact_count(value: int | None) -> str:
    """Abbreviate large counts: 1700 -> '1.7K', 648 -> '648'."""
    if value is None:
        return config.NOT_AVAILABLE
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f}M".replace(".0M", "M")
    if value >= 1_000:
        return f"{value / 1_000:.1f}K".replace(".0K", "K")
    return str(value)


def rating(value: float | None) -> str:
    if value is None:
        return config.NOT_AVAILABLE
    return f"{value:.1f} / 5"


def text(value: str | None) -> str:
    return value if value else config.NOT_AVAILABLE
