"""Price-anomaly detection.

A parser can return a syntactically valid but wrong price (an EMI figure, an
MRP mistaken for the sale price, a digit dropped). Such values are flagged as
``suspected_outlier`` so they can be excluded from min/max/average/median
until validated — one bad parse should not poison a product's history.
"""

from __future__ import annotations

import statistics
from collections.abc import Sequence

from . import config


def classify_price(
    new_price: float | None, prior_prices: Sequence[float]
) -> tuple[str, str | None]:
    """Return ``(status, reason)`` for a new price given prior valid prices.

    ``status`` is ``config.OBS_VALID`` or ``config.OBS_SUSPECTED``. Missing
    prices are treated as valid (there is nothing to compare).
    """
    if new_price is None:
        return config.OBS_VALID, None

    if prior_prices:
        previous = prior_prices[-1]
        if previous and previous > 0:
            change_pct = abs(new_price - previous) / previous * 100
            if change_pct > config.ANOMALY_JUMP_PCT:
                return (
                    config.OBS_SUSPECTED,
                    f"price changed {change_pct:.0f}% vs previous",
                )

    if len(prior_prices) >= config.ANOMALY_MIN_HISTORY:
        median = statistics.median(prior_prices)
        factor = config.ANOMALY_RANGE_FACTOR
        if median > 0 and (new_price > median * factor or new_price < median / factor):
            return (
                config.OBS_SUSPECTED,
                f"price far outside historical range (median ₹{median:,.0f})",
            )

    return config.OBS_VALID, None
