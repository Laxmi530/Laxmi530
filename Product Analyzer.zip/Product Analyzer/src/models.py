"""Data model for a single product listing."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from datetime import datetime

from . import config, provenance, utils
from .provenance import FieldSource, FieldStatus


@dataclass
class ReviewAspect:
    """A review theme customers mention (e.g. "Battery life").

    Marketplaces expose different signals: Amazon gives a mention ``count`` and
    a sentiment; Flipkart/Myntra give a per-aspect ``rating``. Whichever is
    present is kept; the other stays ``None``.
    """

    name: str
    sentiment: str = "neutral"  # positive | mixed | negative | neutral
    count: int | None = None  # mentions (Amazon)
    rating: float | None = None  # 0-5 per-aspect rating (Flipkart/Myntra)


@dataclass
class Product:
    """A normalised product record.

    Every scraper produces ``Product`` instances so ranking, storage and the
    UI can treat all marketplaces uniformly. Fields that could not be
    retrieved are left as ``None`` and rendered as
    ``config.NOT_AVAILABLE`` in the UI.
    """

    name: str
    marketplace: str
    url: str
    product_id: str | None = None
    # Marketplace-native identifier (Amazon ASIN / Flipkart PID) when known.
    native_id: str | None = None
    image_url: str | None = None

    current_price: float | None = None
    original_price: float | None = None  # MRP
    discount_percent: float | None = None

    rating: float | None = None  # 0-5
    num_ratings: int | None = None
    num_reviews: int | None = None

    seller: str | None = None
    availability: str | None = None

    # Variant attributes. Kept distinct so price history is never mixed across
    # different variants (e.g. 128 GB vs 256 GB) sharing a listing.
    brand: str | None = None
    model_number: str | None = None
    variant_name: str | None = None
    color: str | None = None
    size: str | None = None
    storage: str | None = None
    pack_size: int | None = None
    parent_product_id: str | None = None

    # True/False when known, None when undetermined. Sponsored-result
    # detection is future work (#4); the column is stored either way.
    is_sponsored: bool | None = None

    # Raw text such as "2K+ bought in past month" if the page shows it,
    # otherwise None. Never fabricated or estimated.
    monthly_purchases: str | None = None

    # Set to True only for demo/sample records so the UI can label them.
    is_sample: bool = False
    # Data-source tag for the UI badge (config.SOURCE_LIVE / SOURCE_SAMPLE).
    source: str = config.SOURCE_LIVE
    # Query-title relevance (0-1), set by the validation step. None until then.
    relevance_score: float | None = None
    # Bayesian weighted rating, set by the ranking step. None until then.
    weighted_score: float | None = None

    # Per-field origin/status. Scrapers populate entries that need to override
    # the derived default (e.g. PARSE_FAILED); everything else is derived.
    provenance: dict[str, provenance.FieldMeta] = field(default_factory=dict)

    # "Customers say" review themes (Amazon aspect chips / Flipkart aspect
    # ratings), when available. Empty when the marketplace/page doesn't expose
    # them (they live on the product page, not the search results page).
    aspects: list[ReviewAspect] = field(default_factory=list)

    retrieved_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self) -> None:
        # Canonicalise the URL first so IDs are stable across tracking params.
        self.url = utils.normalize_url(self.url) or self.url
        if self.is_sample and self.source == config.SOURCE_LIVE:
            self.source = config.SOURCE_SAMPLE
        if not self.product_id:
            self.product_id = self._derive_id()
        self._fill_discount()

    def _derive_id(self) -> str:
        """Canonical ID: ``<marketplace-code>:<native id or url hash>``.

        Prefers a marketplace-native identifier (ASIN/PID) so the same product
        maps to one ID regardless of URL noise; falls back to a hash of the
        normalised URL, then name+marketplace.
        """
        code = config.MARKETPLACE_CODES.get(
            self.marketplace, (self.marketplace[:3] or "UNK").upper()
        )
        if self.native_id:
            return f"{code}:{self.native_id}"
        basis = (self.url or f"{self.name}|{self.marketplace}").strip().lower()
        # Non-cryptographic: SHA1 is only used to derive a short stable id.
        digest = hashlib.sha1(basis.encode("utf-8"), usedforsecurity=False).hexdigest()[
            :16
        ]
        return f"{code}:{digest}"

    def _fill_discount(self) -> None:
        """Derive discount % from prices when the site did not provide it."""
        if (
            self.discount_percent is None
            and self.current_price
            and self.original_price
            and self.original_price > self.current_price > 0
        ):
            self.discount_percent = round(
                (self.original_price - self.current_price) / self.original_price * 100,
                1,
            )

    # --- convenience ------------------------------------------------------
    @property
    def monthly_purchases_display(self) -> str:
        return self.monthly_purchases or config.NOT_AVAILABLE

    # --- provenance / freshness ------------------------------------------
    def field_status(self, name: str) -> FieldStatus:
        """Origin/status of a field: explicit provenance, else derived.

        Derivation: sample products → SAMPLE; a populated value → SUCCESS;
        a missing value → NOT_PRESENT. Scrapers set PARSE_FAILED explicitly
        when a value was present on the page but could not be parsed.
        """
        meta = self.provenance.get(name)
        if meta is not None:
            return meta.status
        if self.is_sample:
            return FieldStatus.SAMPLE
        return (
            FieldStatus.SUCCESS
            if getattr(self, name, None) is not None
            else FieldStatus.NOT_PRESENT
        )

    def field_source(self, name: str) -> FieldSource:
        meta = self.provenance.get(name)
        if meta is not None:
            return meta.source
        if self.is_sample:
            return FieldSource.SAMPLE
        return (
            FieldSource.SEARCH_PAGE
            if getattr(self, name, None) is not None
            else FieldSource.NONE
        )

    @property
    def age_seconds(self) -> float:
        return (datetime.now() - self.retrieved_at).total_seconds()

    @property
    def freshness(self) -> str:
        return provenance.freshness(self.retrieved_at)

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("provenance", None)  # not JSON-friendly and internal to the UI
        d["retrieved_at"] = self.retrieved_at.isoformat(timespec="seconds")
        return d
