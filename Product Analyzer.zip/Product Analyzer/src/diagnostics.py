"""Helpers for classifying scrape outcomes (used by health diagnostics)."""

from __future__ import annotations

import requests

# HTTP statuses that indicate the marketplace is blocking/throttling the
# client (bot walls, CAPTCHA interstitials, rate limits) rather than a plain
# server fault.
# 529 = "site is overloaded" (used by Flipkart to shed automated traffic).
BLOCKED_STATUS = frozenset({403, 429, 503, 529})
SERVER_ERROR_STATUS = frozenset({500, 502, 504})


def classify_http(status_code: int | None, exc: Exception | None) -> str:
    """Classify a single HTTP attempt into a coarse error type."""
    if exc is not None:
        if isinstance(exc, requests.Timeout):
            return "timeout"
        return "network"
    if status_code == 200:
        return "ok"
    if status_code in BLOCKED_STATUS:
        return "blocked"
    if status_code == 404:
        return "not_found"
    if status_code in SERVER_ERROR_STATUS:
        return "server_error"
    return f"http_{status_code}" if status_code else "unknown"


def classify_run_error(error: str | None) -> str:
    """Bucket a failed search-run error message for diagnostics display."""
    if not error:
        return "other"
    text = error.lower()
    if (
        "http 403" in text
        or "http 429" in text
        or "http 503" in text
        or "blocked" in text
        or "captcha" in text
    ):
        return "blocked"
    if "timed out" in text or "timeout" in text:
        return "timeout"
    if "layout not recognised" in text or "not recognized" in text:
        return "selector_failure"
    if "no products" in text or "no parsable" in text or "empty" in text:
        return "empty_or_parse"
    if "disallowed url" in text:
        return "disallowed_url"
    return "other"
