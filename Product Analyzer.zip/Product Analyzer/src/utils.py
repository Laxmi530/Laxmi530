"""URL normalisation, domain validation and identity helpers."""

from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from . import config

# Query-string keys that carry no product identity (tracking / affiliate /
# session / search-context noise). Stripped before an ID is derived so the
# same product always yields the same canonical URL and ID.
_TRACKING_PARAMS = {
    "ref",
    "ref_",
    "tag",
    "linkcode",
    "ascsubtag",
    "_encoding",
    "psc",
    "smid",
    "th",
    "spm",
    "otracker",
    "otracker1",
    "fm",
    "iid",
    "ppt",
    "ppn",
    "ssid",
    "srno",
    "lid",
    "marketplace",
    "content-id",
    "qid",
    "sr",
    "keywords",
    "sprefix",
    "crid",
    "gclid",
    "fbclid",
}
_TRACKING_PREFIXES = ("pf_rd_", "pd_rd_", "utm_", "_pop")


def _is_tracking(key: str) -> bool:
    key = key.lower()
    return key in _TRACKING_PARAMS or key.startswith(_TRACKING_PREFIXES)


def normalize_url(url: str | None) -> str | None:
    """Return a canonical form of ``url``.

    Drops tracking/affiliate/session parameters, removes the fragment and any
    trailing slash. Meaningful params (e.g. Flipkart's ``pid``) are preserved.
    """
    if not url:
        return url
    parts = urlsplit(url.strip())
    kept = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=False)
        if not _is_tracking(k)
    ]
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((parts.scheme, parts.netloc, path, urlencode(kept), ""))


def domain_of(url: str | None) -> str | None:
    if not url:
        return None
    return (urlsplit(url).hostname or "").lower() or None


def is_allowed_url(url: str | None, allowed=config.ALLOWED_DOMAINS) -> bool:
    """True if ``url`` targets one of the approved marketplace domains."""
    host = domain_of(url)
    if not host:
        return False
    return any(host == d or host.endswith("." + d) for d in allowed)


def amazon_asin(url: str | None) -> str | None:
    """Extract an Amazon ASIN from a product URL, if present."""
    if not url:
        return None
    match = re.search(r"/(?:dp|gp/product|d)/([A-Z0-9]{10})(?:[/?]|$)", url)
    return match.group(1) if match else None


def flipkart_pid(url: str | None) -> str | None:
    """Extract a Flipkart PID (from the ``pid`` query param) from a URL."""
    if not url:
        return None
    for key, value in parse_qsl(urlsplit(url).query):
        if key.lower() == "pid" and value:
            return value
    return None


def myntra_pid(url: str | None) -> str | None:
    """Extract a Myntra product id from a URL like ``/.../<id>/buy``."""
    if not url:
        return None
    match = re.search(r"/(\d+)/buy", url) or re.search(r"/(\d{5,})(?:[/?]|$)", url)
    return match.group(1) if match else None
