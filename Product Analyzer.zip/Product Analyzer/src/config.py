"""Central configuration for Product Analyzer.

All tunables live here so the scrapers, database and UI stay in sync. Values
prefixed ``PRODUCT_ANALYZER_`` in the environment override the defaults, which
keeps deployment (Docker / CI / prod) configuration out of the code.
"""

from __future__ import annotations

import os
from pathlib import Path


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


# --- Paths -----------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
# Override with PRODUCT_ANALYZER_DB (e.g. a mounted volume in Docker).
DATABASE_PATH = Path(
    os.environ.get("PRODUCT_ANALYZER_DB", str(DATA_DIR / "price_history.db"))
)

# Logging level name (DEBUG/INFO/WARNING/…) — override with LOG_LEVEL.
LOG_LEVEL = os.environ.get("PRODUCT_ANALYZER_LOG_LEVEL", "INFO")

# --- Marketplaces ----------------------------------------------------------
MARKETPLACE_AMAZON = "Amazon India"
MARKETPLACE_FLIPKART = "Flipkart"
MARKETPLACE_MYNTRA = "Myntra"
MARKETPLACES = (MARKETPLACE_AMAZON, MARKETPLACE_FLIPKART, MARKETPLACE_MYNTRA)

# Short, stable codes used to build canonical product IDs
# (marketplace + native id), so IDs never collide across marketplaces.
MARKETPLACE_CODES = {
    MARKETPLACE_AMAZON: "AMZ",
    MARKETPLACE_FLIPKART: "FPK",
    MARKETPLACE_MYNTRA: "MYN",
}

# Search base URLs (India storefronts).
AMAZON_SEARCH_URL = "https://www.amazon.in/s"
FLIPKART_SEARCH_URL = "https://www.flipkart.com/search"
MYNTRA_SEARCH_URL = "https://www.myntra.com"  # query is appended as a path

# Domains the app is allowed to make HTTP requests to. Guards against
# following arbitrary/malicious URLs scraped from a page (SSRF hardening).
ALLOWED_DOMAINS = ("amazon.in", "flipkart.com", "myntra.com")

# --- Result sizes ----------------------------------------------------------
RESULT_SIZES = (10, 20)
DEFAULT_RESULT_SIZE = 10

# --- HTTP behaviour --------------------------------------------------------
REQUEST_TIMEOUT = 15  # seconds
REQUEST_RETRIES = 2
REQUEST_BACKOFF = 1.5  # seconds, multiplied per retry
POLITE_DELAY = 1.0  # seconds between paginated requests

# Only these HTTP statuses are retried (transient). Statuses like 400/401/403
# or a CAPTCHA page are permanent for our purposes and fail fast.
RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})
MAX_RETRY_AFTER = 30  # cap on honouring a server's Retry-After header

# --- Ranking ---------------------------------------------------------------
# Ranking modes exposed in the UI: label -> internal key.
RANK_MODES = {
    "Best weighted rating": "weighted",
    "Best match (relevance × rating)": "relevance",
    "Highest rating": "rating",
    "Most popular (rating count)": "popular",
    "Lowest price": "price_low",
    "Highest discount": "discount",
}
DEFAULT_RANK_MODE = "weighted"
# Minimum rating-count threshold (m) for the Bayesian weighted rating.
BAYESIAN_MIN_RATINGS = 50

# --- Result-quality validation --------------------------------------------
# Minimum share of query tokens that must appear in a product title for it to
# be considered relevant (0-1). Titles below this are dropped as off-topic.
MIN_RELEVANCE = 0.3
# Discounts above this percentage are treated as implausible (bad parse).
MAX_REASONABLE_DISCOUNT = 95.0

# --- Data freshness --------------------------------------------------------
# Age thresholds (seconds) used to label how fresh a displayed value is.
FRESH_SECONDS = 3600  # < 1 hour  -> "fresh"
RECENT_SECONDS = 86400  # < 24 hours -> "recent"; older -> "stale"

# --- Parser-quality monitoring ---------------------------------------------
# Fields whose extraction rate is tracked per marketplace for diagnostics.
PARSE_TRACKED_FIELDS = (
    "current_price",
    "rating",
    "image_url",
    "seller",
    "native_id",
    "monthly_purchases",
)
# Extraction rate below this (per field) is flagged as likely selector breakage.
PARSER_QUALITY_MIN_RATE = 0.5

# --- Data source modes -----------------------------------------------------
DATA_MODE_LIVE = "Live"
DATA_MODE_DEMO = "Demo"
DATA_MODE_LIVE_FALLBACK = "Live with demo fallback"
DATA_MODES = (DATA_MODE_LIVE_FALLBACK, DATA_MODE_LIVE, DATA_MODE_DEMO)

# Data-source tags shown as a badge on every product.
SOURCE_LIVE = "live"
SOURCE_SAMPLE = "sample"

# --- Price-history de-duplication ------------------------------------------
# Do not store a new observation if the price is unchanged and the last
# observation was within this many seconds. A changed price is always stored.
PRICE_DEDUP_INTERVAL = 3600  # 1 hour

# --- Price-anomaly detection -----------------------------------------------
# An observation is flagged (and excluded from aggregates) when its price
# jumps more than this % from the previous value, or lands this many times
# above/below the historical median (needs at least ANOMALY_MIN_HISTORY prior
# valid prices for the range check).
ANOMALY_JUMP_PCT = 80.0
ANOMALY_RANGE_FACTOR = 5.0
ANOMALY_MIN_HISTORY = 3

# Observation quality states.
OBS_VALID = "valid"
OBS_SUSPECTED = "suspected_outlier"
OBS_EXCLUDED = "excluded"
OBS_REVIEW = "requires_review"

# --- Job / collection locking ----------------------------------------------
# Name of the global lock the scheduled collector holds so two runs never
# overlap, and how long it lives before being treated as abandoned.
COLLECTOR_LOCK = "price-collector"
LOCK_TTL_SECONDS = 3600

# A realistic desktop browser header set. Marketplaces still frequently
# challenge automated traffic; the app degrades gracefully when that happens.
DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-IN,en-GB;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    # Client hints + fetch metadata — some sites (e.g. Flipkart) 403 without
    # a plausible set. Best-effort; does not defeat determined bot walls.
    "sec-ch-ua": '"Chromium";v="125", "Not.A/Brand";v="24", "Google Chrome";v="125"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
}

# Text shown everywhere a value could not be scraped.
NOT_AVAILABLE = "Not publicly available"

# When live scraping is blocked (very common for Amazon/Flipkart), the app can
# fall back to a clearly-labelled sample dataset so the UI remains usable in
# demos and offline development. Never presented as real, live data.
ENABLE_SAMPLE_FALLBACK = _env_bool("PRODUCT_ANALYZER_SAMPLE_FALLBACK", True)

# --- Browser-render fallback -----------------------------------------------
# Some marketplaces (Flipkart, Myntra) block plain HTTP requests (403/429/529)
# and/or render results with JavaScript. When enabled AND Playwright + a
# browser are installed, a blocked/JS page is retried through a real browser.
# Off by default so tests/CI stay hermetic and no browser launches unexpectedly.
#   Enable with:  PRODUCT_ANALYZER_BROWSER=1
#   Install once: python -m playwright install chromium
ENABLE_BROWSER_FALLBACK = _env_bool("PRODUCT_ANALYZER_BROWSER", False)
# Statuses that trigger the browser fallback (bot walls / challenges).
BROWSER_FALLBACK_STATUS = frozenset({403, 429, 503, 529})
BROWSER_TIMEOUT_MS = 30000
