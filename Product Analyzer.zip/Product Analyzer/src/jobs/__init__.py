"""Standalone batch jobs (run outside the Streamlit process)."""
