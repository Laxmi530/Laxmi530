"""Scheduled price-collection job.

Manual searches alone produce sparse price history. This job re-runs a set of
searches and records the current prices, so history accumulates over time.
It is intentionally separate from the Streamlit app and is suitable for cron,
Windows Task Scheduler, GitHub Actions, etc.

Which searches?
  - Any ``--query`` values passed on the command line (paired with
    ``--marketplace``), and/or
  - the distinct (marketplace, query) pairs from previous successful runs
    (``--tracked``, the default when no queries are given).

Individual search failures never abort the run; each is logged and the job
continues. A summary is printed (and returned) at the end.

Examples
--------
    # Re-collect everything searched before, live:
    python -m src.jobs.collect_prices

    # Collect specific queries on Flipkart:
    python -m src.jobs.collect_prices --marketplace "Flipkart" \
        --query "wireless earbuds" --query "air fryer"

    # Dry demo run (labelled sample data is NOT persisted):
    python -m src.jobs.collect_prices --mode Demo --query "laptop"
"""

from __future__ import annotations

import argparse
import sys
import uuid
from collections.abc import Sequence
from dataclasses import dataclass, field

from .. import config, scrapers, validation
from ..database import LockUnavailable, PriceHistoryDB
from ..logging_config import configure_logging, get_logger

log = get_logger("collect_prices")


@dataclass
class SearchOutcome:
    marketplace: str
    query: str
    status: str  # 'ok' | 'failed'
    found: int = 0
    stored: int = 0
    error: str | None = None


@dataclass
class RunSummary:
    outcomes: list[SearchOutcome] = field(default_factory=list)

    @property
    def searches(self) -> int:
        return len(self.outcomes)

    @property
    def succeeded(self) -> int:
        return sum(1 for o in self.outcomes if o.status == "ok")

    @property
    def failed(self) -> int:
        return sum(1 for o in self.outcomes if o.status == "failed")

    @property
    def total_found(self) -> int:
        return sum(o.found for o in self.outcomes)

    @property
    def total_stored(self) -> int:
        return sum(o.stored for o in self.outcomes)


def _resolve_searches(
    db: PriceHistoryDB,
    marketplace: str,
    queries: Sequence[str],
    use_tracked: bool,
) -> list[tuple[str, str]]:
    searches: list[tuple[str, str]] = [(marketplace, q) for q in queries]
    if use_tracked or not searches:
        searches.extend(db.distinct_tracked_searches())
    # De-duplicate, preserve order.
    seen: set = set()
    unique: list[tuple[str, str]] = []
    for pair in searches:
        if pair not in seen:
            seen.add(pair)
            unique.append(pair)
    return unique


def collect(
    db: PriceHistoryDB,
    searches: Sequence[tuple[str, str]],
    limit: int = config.DEFAULT_RESULT_SIZE,
    mode: str = config.DATA_MODE_LIVE,
) -> RunSummary:
    """Run each (marketplace, query) search and record observations."""
    summary = RunSummary()
    for marketplace, query in searches:
        run_id = db.start_run(marketplace, query, mode)
        try:
            products = scrapers.search(
                marketplace, query, limit, mode=mode, recorder=db
            )
            kept, _dropped = validation.clean_results(products, query)
            stored = db.record_many(kept, run_id=run_id)
            db.finish_run(run_id, "ok", result_count=len(kept))
            summary.outcomes.append(
                SearchOutcome(marketplace, query, "ok", found=len(kept), stored=stored)
            )
            log.info(
                "collected %s '%s': found=%d stored=%d",
                marketplace,
                query,
                len(kept),
                stored,
            )
        except Exception as exc:  # never abort the whole run
            db.finish_run(run_id, "failed", result_count=0, error=str(exc))
            summary.outcomes.append(
                SearchOutcome(marketplace, query, "failed", error=str(exc))
            )
            log.warning("failed %s '%s': %s", marketplace, query, exc)
    return summary


def _format_summary(summary: RunSummary) -> str:
    lines = [
        "",
        "Price collection summary",
        "========================",
        f"searches : {summary.searches} "
        f"(ok={summary.succeeded}, failed={summary.failed})",
        f"found    : {summary.total_found} products",
        f"stored   : {summary.total_stored} new observations "
        "(duplicates / sample data skipped)",
        "",
    ]
    for o in summary.outcomes:
        if o.status == "ok":
            lines.append(
                f"  [ok]   {o.marketplace:<12} {o.query!r}: "
                f"found={o.found} stored={o.stored}"
            )
        else:
            lines.append(f"  [FAIL] {o.marketplace:<12} {o.query!r}: {o.error}")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m src.jobs.collect_prices",
        description="Collect current prices for tracked / specified searches.",
    )
    p.add_argument(
        "--marketplace",
        default=config.MARKETPLACE_AMAZON,
        choices=list(config.MARKETPLACES),
        help="Marketplace for --query values (default: Amazon India).",
    )
    p.add_argument(
        "--query",
        action="append",
        default=[],
        metavar="TEXT",
        help="A search to collect (repeatable).",
    )
    p.add_argument(
        "--tracked",
        action="store_true",
        help="Also include distinct searches from past successful "
        "runs (implied when no --query is given).",
    )
    p.add_argument(
        "--limit",
        type=int,
        default=config.DEFAULT_RESULT_SIZE,
        choices=list(config.RESULT_SIZES),
        help="Results per search.",
    )
    p.add_argument(
        "--mode",
        default=config.DATA_MODE_LIVE,
        choices=list(config.DATA_MODES),
        help="Data source (default: Live).",
    )
    p.add_argument(
        "--db", default=None, help="Path to the SQLite database (default: configured)."
    )
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    configure_logging()

    db = PriceHistoryDB(args.db)
    searches = _resolve_searches(db, args.marketplace, args.query, args.tracked)

    if not searches:
        print(
            "Nothing to collect: no --query given and no tracked searches "
            "found. Run some searches in the app first, or pass --query."
        )
        return 1

    # A global lock prevents two collector runs from overlapping; an
    # abandoned lock (expired TTL) is recovered automatically.
    owner = uuid.uuid4().hex
    try:
        with db.job_lock(config.COLLECTOR_LOCK, owner, config.LOCK_TTL_SECONDS):
            summary = collect(db, searches, limit=args.limit, mode=args.mode)
    except LockUnavailable:
        print(
            "Another price-collection run is already in progress "
            f"(lock '{config.COLLECTOR_LOCK}' held). Exiting without running."
        )
        log.warning("collector lock unavailable; skipping run")
        return 3

    print(_format_summary(summary))
    # Exit non-zero only if every search failed (useful for schedulers).
    return 0 if summary.succeeded > 0 else 2


if __name__ == "__main__":
    sys.exit(main())
