"""
Market breadth from the NSE bhavcopy (Thomsett, *Stock Market Math*, Ch. 8-9).

Breadth asks how many stocks are taking part in a move: advances against
declines, and new 52-week highs against new lows. It needs every listed name
on every day, including the ones that later delisted, which is what the
survivorship-free bhavcopy cache is (``bhavcopy.load_cache``); an index level
cannot supply it.

Two point-in-time details:

* An advance is ``close > prevclose``. NSE's ``prevclose`` is adjusted for a
  corporate action on its ex-date, so a split or bonus does not print as a
  crash.
* 52-week extremes are taken on the chain of ``close / prevclose``, not on the
  raw close, for the same reason: on the raw close every split is a false
  52-week low.

numpy / pandas only.
"""

import numpy as np
import pandas as pd

#: Liquidity floor for an issue to count on a day (Rs 1 crore of turnover).
MIN_TURNOVER = 1e7
#: Sessions in a 52-week window.
YEAR = 250
#: A daily move larger than this is treated as a data error, not a price.
MAX_ABS_LOG_RETURN = np.log(1.25)


def _ema(x, span):
    return x.ewm(span=span, adjust=False).mean()


def daily_breadth(raw, min_turnover=MIN_TURNOVER, year=YEAR):
    """
    Daily breadth series from a long bhavcopy panel.

    Parameters
    ----------
    raw : pd.DataFrame
        ``bhavcopy.load_cache`` output: ``datetime, symbol, close, prevclose,
        turnover`` at least, every listed name.
    min_turnover : float
        An issue counts on a day only with at least this turnover.
    year : int
        Window, in the issue's own sessions, for a new high or low.

    Returns
    -------
    pd.DataFrame indexed by date
        ``advances, declines, issues, highs, lows, net_ratio, mkt_ret`` and the
        smoothed measures ``ad10`` (10-day mean of the net advance ratio),
        ``mcclellan`` (EMA19 - EMA39 of it), ``hilo10`` (10-day mean of (highs -
        lows) / issues) and ``hl_index`` (10-day mean of highs / (highs + lows)).
        ``mkt_ret`` is the equal-weighted mean log return of the counted issues.
    """
    df = raw[["datetime", "symbol", "close", "prevclose", "turnover"]].copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values(["symbol", "datetime"])
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.log(df["close"].to_numpy(float) / df["prevclose"].to_numpy(float))
    r[~np.isfinite(r) | (np.abs(r) > MAX_ABS_LOG_RETURN)] = np.nan
    df["ret"] = r
    df["chain"] = df.groupby("symbol")["ret"].transform(lambda s: s.fillna(0.0).cumsum())
    g = df.groupby("symbol")["chain"]
    prior_max = g.transform(lambda s: s.shift(1).rolling(year, min_periods=year).max())
    prior_min = g.transform(lambda s: s.shift(1).rolling(year, min_periods=year).min())
    df["high52"] = (df["chain"] > prior_max) & df["ret"].notna()
    df["low52"] = (df["chain"] < prior_min) & df["ret"].notna()

    live = df[(df["turnover"] >= min_turnover) & df["ret"].notna()]
    day = live.groupby("datetime").agg(
        advances=("ret", lambda s: int((s > 0).sum())),
        declines=("ret", lambda s: int((s < 0).sum())),
        issues=("ret", "size"),
        highs=("high52", "sum"),
        lows=("low52", "sum"),
        mkt_ret=("ret", "mean"),
    )
    moved = (day["advances"] + day["declines"]).replace(0, np.nan)
    day["net_ratio"] = ((day["advances"] - day["declines"]) / moved).fillna(0.0)
    day["ad10"] = day["net_ratio"].rolling(10).mean()
    day["mcclellan"] = _ema(day["net_ratio"], 19) - _ema(day["net_ratio"], 39)
    day["hilo10"] = ((day["highs"] - day["lows"]) / day["issues"]).rolling(10).mean()
    extremes = (day["highs"] + day["lows"]).replace(0, np.nan)
    day["hl_index"] = (day["highs"] / extremes).fillna(0.5).rolling(10).mean()
    return day


# ---------------------------------------------------------------------------
# Live market context for the app
# ---------------------------------------------------------------------------

#: ``ad10`` quintile edges and the market's next-21-session realised volatility
#: (annualised) in each quintile, frozen from run_market_breadth.py on
#: 2018-01 .. 2024-06, before the reserved period. Never refitted on live data.
AD10_EDGES = (-0.1211, -0.0329, 0.0380, 0.1097)
NEXT_MONTH_VOL = (0.246, 0.199, 0.190, 0.173, 0.174)
_LABELS = ("weakest", "weak", "middling", "strong", "strongest")


def ad10_quintile(value):
    """1 (weakest breadth) .. 5 (strongest), on the frozen 2018-2024 edges."""
    return 1 + int(np.searchsorted(np.asarray(AD10_EDGES), float(value), side="right"))


def live_breadth(today=None, sessions=10, lookback_days=25, fetch_fn=None):
    """
    The 10-session advance/decline ratio up to the latest published session.

    Reads the last ``sessions`` NSE bhavcopies (``bhavcopy.fetch_day``, which
    now caches only real files, so a day NSE has not published yet is simply
    retried). Advisory: returns None on any failure or with too few sessions.

    Returns
    -------
    dict or None
        ``ad10``, ``quintile``, ``label``, ``next_month_vol`` (the frozen
        historical average for that quintile), ``as_of``, ``sessions`` and a
        ``message``.
    """
    try:
        if fetch_fn is None:
            import bhavcopy as bc
            fetch_fn = bc.fetch_day
        end = pd.Timestamp(today or pd.Timestamp.now()).normalize()
        ratios, dates = [], []
        for d in pd.bdate_range(end - pd.Timedelta(days=lookback_days), end)[::-1]:
            day = fetch_fn(d)
            if day is None or not len(day):
                continue
            ok = day["turnover"] >= MIN_TURNOVER
            with np.errstate(divide="ignore", invalid="ignore"):
                r = np.log(day.loc[ok, "close"].astype(float) / day.loc[ok, "prevclose"].astype(float))
            r = r[np.isfinite(r) & (np.abs(r) <= MAX_ABS_LOG_RETURN)]
            adv, dec = int((r > 0).sum()), int((r < 0).sum())
            if adv + dec == 0:
                continue
            ratios.append((adv - dec) / (adv + dec))
            dates.append(d)
            if len(ratios) == sessions:
                break
        if len(ratios) < sessions:
            return None
        ad10 = float(np.mean(ratios))
        q = ad10_quintile(ad10)
        vol = NEXT_MONTH_VOL[q - 1]
        others = [v for i, v in enumerate(NEXT_MONTH_VOL) if i != q - 1]
        msg = (f"Market breadth (10-session advance/decline, NSE, to {dates[0].date()}): "
               f"{ad10:+.2f}, the {_LABELS[q - 1]} fifth of 2018-2024. In that fifth the "
               f"market's volatility over the next month averaged {vol * 100:.0f}% a year "
               f"(other fifths {min(others) * 100:.0f}-{max(others) * 100:.0f}%).")
        return {"ad10": ad10, "quintile": q, "label": _LABELS[q - 1],
                "next_month_vol": vol, "as_of": str(dates[0].date()),
                "sessions": len(ratios), "message": msg}
    except Exception:
        return None
