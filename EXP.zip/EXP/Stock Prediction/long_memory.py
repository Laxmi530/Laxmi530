"""
Long-memory estimators: rescaled range (Hurst), Lo's modified R/S, and DFA.

Mariani & Florescu, *Quantitative Finance*, Ch. 12.5 and 13.4, estimate a
Hurst exponent H by rescaled-range (R/S) analysis and a scaling exponent
alpha by detrended fluctuation analysis (DFA), read either above 0.5 as
"persistence" that "enables prediction", and propose that "the further these
parameters are from 0.5, the stronger the evidence of a crash event waiting
to happen". This module implements the book's two procedures as written and
the corrections the literature added, so the claims can be measured rather
than read off a slope:

- ``rs_hurst(x, corrected=False)`` -- the book's R/S slope (p. 332-334). In
  finite samples it is biased ABOVE 0.5 for independent data, because the
  expected R/S of short sub-series grows faster than n**0.5 (Anis & Lloyd
  1976). ``corrected=True`` regresses on the excess over the Anis-Lloyd-
  Peters expectation, so independent data reads 0.5.
- ``lo_modified_rs(x)`` -- Lo's (1991) modified R/S statistic V. Classical
  R/S also rises with SHORT-range dependence (an AR(1), say), which is not
  long memory; Lo's statistic replaces the standard deviation with a
  Newey-West one, so only long-range dependence moves it. Under no long
  memory V lies in [0.809, 1.862] with 95% probability.
- ``dfa(x, abs_input=False)`` -- detrended fluctuation analysis, order 1.
  The book integrates the ABSOLUTE log returns (p. 334); ``abs_input=True``
  reproduces that, which measures memory in VOLATILITY. Standard DFA (the
  default) integrates the demeaned series itself. alpha = 0.5 means no
  correlation, 0.5-1 long-range correlation, 1.5 a random walk's levels.

Pure numpy. Every estimator returns a dict with the slope and the points it
was fitted on, so a caller can see the log-log line rather than trust it.
"""

import math

import numpy as np

_EPS = 1e-12


def _scales(n_obs, min_n=8, max_frac=0.25, n_points=12):
    """Log-spaced sub-series lengths between ``min_n`` and ``max_frac * N``."""
    hi = max(int(n_obs * max_frac), min_n + 1)
    s = np.unique(np.round(np.logspace(np.log10(min_n), np.log10(hi), n_points)).astype(int))
    return s[s >= min_n]


def expected_rs(n):
    """
    Anis-Lloyd expected R/S of n independent Gaussian draws, with Peters'
    (1994) small-sample factor (n - 0.5) / n.

    This is the curve independent data follows; its log-log slope is above
    0.5 at small n, which is why the uncorrected estimator is biased upward.
    """
    n = int(n)
    if n < 3:
        return float("nan")
    # Gamma ratio in logs: exact at every n, where Peters' formula switches to
    # an asymptotic form above n = 340 to avoid overflow (and jumps there).
    lead = math.exp(math.lgamma((n - 1) / 2.0) - math.lgamma(n / 2.0)) / math.sqrt(math.pi)
    tail = sum(math.sqrt((n - i) / i) for i in range(1, n))
    return float((n - 0.5) / n * lead * tail)


def _rs_at(x, n):
    """Mean R/S over the non-overlapping sub-series of length n (book steps 2-7)."""
    m = len(x) // n
    if m < 1:
        return float("nan")
    blocks = x[: m * n].reshape(m, n)
    dev = blocks - blocks.mean(axis=1, keepdims=True)
    c = np.cumsum(dev, axis=1)
    r = c.max(axis=1) - c.min(axis=1)
    s = blocks.std(axis=1)                       # 1/n, as in the book
    ok = s > _EPS
    return float(np.mean(r[ok] / s[ok])) if ok.any() else float("nan")


def rs_hurst(x, scales=None, corrected=False):
    """
    Hurst exponent by rescaled-range analysis.

    Parameters
    ----------
    x : array-like
        The series to test, e.g. log returns (the book's M(t)).
    scales : array-like of int, optional
        Sub-series lengths n. Default: 12 log-spaced values from 8 to N/4.
    corrected : bool, optional
        False reproduces the book (slope of log(R/S) on log n). True is the
        Anis-Lloyd-Peters correction: H = 0.5 + slope of
        log(R/S) - log(E[R/S]) on log n, so independent data reads 0.5.

    Returns
    -------
    dict
        {'H', 'scales', 'rs', 'expected_rs', 'n_obs'}.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    sc = np.asarray(scales if scales is not None else _scales(len(x)), dtype=int)
    rs = np.array([_rs_at(x, int(n)) for n in sc])
    ers = np.array([expected_rs(int(n)) for n in sc])
    ok = np.isfinite(rs) & (rs > 0) & np.isfinite(ers)
    out = {"H": float("nan"), "scales": sc, "rs": rs, "expected_rs": ers, "n_obs": int(len(x))}
    if ok.sum() < 3:
        return out
    lx = np.log(sc[ok])
    ly = np.log(rs[ok]) - (np.log(ers[ok]) if corrected else 0.0)
    slope = float(np.polyfit(lx, ly, 1)[0])
    out["H"] = 0.5 + slope if corrected else slope
    return out


def lo_modified_rs(x, q=None):
    """
    Lo's (1991) modified rescaled-range statistic for LONG memory.

    V = (max - min of the cumulative demeaned sum) / (sqrt(N) * sigma_q),
    where sigma_q is the Newey-West long-run standard deviation with q lags.
    Short-range dependence inflates the classical R/S; sigma_q absorbs it,
    so V moves only with long-range dependence. Under the null of no long
    memory, V lies in [0.809, 1.862] with probability 0.95.

    Parameters
    ----------
    x : array-like
    q : int, optional
        Lags; default Andrews' (1991) data-dependent rule for an AR(1).

    Returns
    -------
    dict
        {'V', 'q', 'reject_5pct', 'direction'}; direction is 'persistent'
        above the band, 'anti-persistent' below it, else 'no long memory'.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    n = len(x)
    out = {"V": float("nan"), "q": 0, "reject_5pct": False, "direction": "n/a"}
    if n < 50:
        return out
    d = x - x.mean()
    if q is None:
        rho = float(np.corrcoef(d[1:], d[:-1])[0, 1]) if np.std(d) > _EPS else 0.0
        rho = min(abs(rho), 0.99)               # the rule uses |rho|
        q = int(((1.5 * n) ** (1 / 3)) * ((2 * rho / (1 - rho * rho)) ** (2 / 3))) if rho > 0 else 0
    q = int(max(0, min(q, n // 4)))
    var = float(d @ d) / n
    for j in range(1, q + 1):
        w = 1.0 - j / (q + 1.0)
        var += 2.0 * w * float(d[j:] @ d[:-j]) / n
    if var <= _EPS:
        return out
    c = np.cumsum(d)
    v = float((c.max() - c.min()) / (math.sqrt(n) * math.sqrt(var)))
    rej = not (0.809 <= v <= 1.862)
    out.update(V=v, q=q, reject_5pct=bool(rej),
               direction=("persistent" if v > 1.862 else "anti-persistent" if v < 0.809
                          else "no long memory"))
    return out


def dfa(x, scales=None, abs_input=False, both_ends=True):
    """
    Detrended fluctuation analysis (order 1).

    Parameters
    ----------
    x : array-like
        Increments, e.g. log returns.
    scales : array-like of int, optional
        Box sizes; default 12 log-spaced values from 8 to N/4.
    abs_input : bool, optional
        True integrates |x| without demeaning, as the book does (p. 334):
        that measures long memory in volatility. False (default) integrates
        the demeaned series, the standard definition.
    both_ends : bool, optional
        Also box the series from its end, so no data is left over (the
        book's 2N/n boxes). Default True.

    Returns
    -------
    dict
        {'alpha', 'scales', 'F', 'n_obs'}.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    y = np.cumsum(np.abs(x)) if abs_input else np.cumsum(x - x.mean())
    n_obs = len(y)
    sc = np.asarray(scales if scales is not None else _scales(n_obs), dtype=int)
    F = []
    for n in sc:
        m = n_obs // n
        if m < 2:
            F.append(np.nan)
            continue
        segs = [y[: m * n].reshape(m, n)]
        if both_ends:
            segs.append(y[n_obs - m * n:].reshape(m, n))
        t = np.arange(n, dtype=np.float64)
        A = np.column_stack([t, np.ones(n)])
        sq = []
        for blocks in segs:
            coef, *_ = np.linalg.lstsq(A, blocks.T, rcond=None)
            resid = blocks.T - A @ coef
            sq.append(np.mean(resid ** 2, axis=0))
        F.append(float(np.sqrt(np.mean(np.concatenate(sq)))))
    F = np.array(F)
    ok = np.isfinite(F) & (F > 0)
    out = {"alpha": float("nan"), "scales": sc, "F": F, "n_obs": int(n_obs)}
    if ok.sum() >= 3:
        out["alpha"] = float(np.polyfit(np.log(sc[ok]), np.log(F[ok]), 1)[0])
    return out


def fgn(n, H, seed=0):
    """
    Fractional Gaussian noise with Hurst exponent H, by circulant embedding
    (Davies & Harte 1987). Exact in distribution; used to validate the
    estimators on series whose H is known.
    """
    rng = np.random.default_rng(seed)
    k = np.arange(n + 1, dtype=np.float64)
    gamma = 0.5 * (np.abs(k + 1) ** (2 * H) - 2 * np.abs(k) ** (2 * H) + np.abs(k - 1) ** (2 * H))
    row = np.concatenate([gamma, gamma[-2:0:-1]])
    lam = np.fft.fft(row).real
    lam = np.maximum(lam, 0.0)
    m = len(row)
    z = rng.standard_normal(m) + 1j * rng.standard_normal(m)
    w = np.fft.fft(np.sqrt(lam / m) * z)
    return w.real[:n]
