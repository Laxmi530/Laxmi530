"""
Insider trades on NSE (SEBI insider-trading disclosures), for Hough's "Follow
the Leaders" screen (*Your Next Great Stock*, Ch. 19).

The data
--------
SEBI's Prohibition of Insider Trading Regulations (2015) make promoters,
directors, key managerial personnel and designated employees disclose a trade
within two trading days, and the company passes it to the exchange within two
more. NSE publishes each disclosure with the time it went out
(``disclosed``), the trade dates, the person's category, the mode (open-market
purchase or sale, ESOP allotment, pledge, gift, inter-se transfer ...), the
shares, the value, and the holding before and after. The publication time is
what makes this **point-in-time**: unlike yfinance's statements (README
section 32), a disclosure can be dated to the moment the market could see it.

The book's screen (Ch. 19)
--------------------------
Insider purchases over $100,000, at least two buys, under 5% of the shares,
in a company worth under $10 billion followed by six or fewer analysts. Of
Hough's refinements: executives' purchases beat board members' and big
shareholders', several buyers beat one, and selling is far less informative
than buying (insiders sell to pay for things). Only **open-market purchases**
count, the US Form 4 code "P": an ESOP allotment, a gift or a transfer between
promoters is not a decision to buy at the market price.

Mapped to SEBI's categories: key managerial personnel are the executives,
directors the board, promoters and the promoter group the large holders.
Designated employees, relatives and "other" are not insiders in the book's
sense and are left out of the signal.

README section 67 tests the screen on NSE (``tests/validation/run_insider_buying.py``);
:data:`MEASURED` holds its result for the app.
"""

import datetime as _dt
import gzip
import json
import os
import time

import numpy as np
import pandas as pd

HOME = "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading"
API = "https://www.nseindia.com/api/corporates-pit?index=equities&from_date={a}&to_date={b}"
API_SYMBOL = API + "&symbol={symbol}"
# From May 2026 NSE lists new disclosures here (the old endpoint became its
# "archive" and stops on 2 May 2026), one row per filing with only the company
# and time; the trades themselves are in each filing's XBRL file.
API_NEW = "https://www.nseindia.com/api/corporates-pit-gg?index=equities&from_date={a}&to_date={b}"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".insider_cache")

#: SEBI person category -> the book's insider kind (others are not counted).
GROUPS = {"Key Managerial Personnel": "executive", "KMP": "executive",
          "Director": "board", "Promoter and Director": "board",
          "Promoters": "promoter", "Promoter": "promoter", "Promoter Group": "promoter"}
OPEN_MARKET_BUY, OPEN_MARKET_SELL = "Market Purchase", "Market Sale"

# The book's Ch. 19 recipe. $100,000 at the project's one rate, so it cannot drift.
from stock_checklist import USD_INR    # noqa: E402
MIN_VALUE = 100_000 * USD_INR          # ₹88 lakh in total
MIN_BUYS = 2
MAX_PCT = 5.0                          # under 5% of the shares
WINDOW_DAYS = 90                       # Hough: "within the past three months"
NEW_FEED_FROM = pd.Timestamp("2026-04-01")   # the new filing index (see API_NEW)

# Filled from run_insider_buying.py (2018-01 .. 2024-06, before the reserved period).
MEASURED = {"leaders": (
    "Measured on NSE, 2019-24: after the book's screen fired (252 times in 100 liquid stocks), "
    "the stock beat stocks with the same 12-month and 1-month returns by +1.71% over the next "
    "quarter (t 1.4): about the book's six points a year, but not distinguishable from luck on "
    "this sample. Indian insider buying is mostly promoters adding to their stake (only 4 events "
    "had an executive among the buyers). Insiders' open-market sales were followed by -0.6% "
    "(t -0.7).")}


# ---------------------------------------------------------------------------
# Fetch and normalise
# ---------------------------------------------------------------------------

def _num(x):
    try:
        return float(str(x).replace(",", "").strip())
    except (TypeError, ValueError):
        return float("nan")


def _date(x, fmt):
    try:
        return pd.Timestamp(_dt.datetime.strptime(str(x).strip(), fmt))
    except (TypeError, ValueError):
        return pd.NaT


def normalise(rows):
    """NSE's raw disclosure rows -> one tidy frame, duplicates across exchanges removed."""
    cols = ["symbol", "company", "person", "category", "kind", "mode", "txn", "shares", "value",
            "before_pct", "after_pct", "trade_from", "trade_to", "intimated", "disclosed", "exchange"]
    if not rows:
        return pd.DataFrame(columns=cols)
    out = pd.DataFrame({
        "symbol": [str(r.get("symbol") or "").upper() for r in rows],
        "company": [r.get("company") for r in rows],
        "person": [str(r.get("acqName") or "").strip() for r in rows],
        "category": [r.get("personCategory") for r in rows],
        "mode": [r.get("acqMode") for r in rows],
        "txn": [r.get("tdpTransactionType") for r in rows],
        "sec_type": [r.get("secType") for r in rows],
        "shares": [_num(r.get("secAcq")) for r in rows],
        "value": [_num(r.get("secVal")) for r in rows],
        "before_pct": [_num(r.get("befAcqSharesPer")) for r in rows],
        "after_pct": [_num(r.get("afterAcqSharesPer")) for r in rows],
        "trade_from": [_date(r.get("acqfromDt"), "%d-%b-%Y") for r in rows],
        "trade_to": [_date(r.get("acqtoDt"), "%d-%b-%Y") for r in rows],
        "intimated": [_date(r.get("intimDt"), "%d-%b-%Y") for r in rows],
        "disclosed": [_date(r.get("date"), "%d-%b-%Y %H:%M") for r in rows],
        "exchange": [r.get("exchange") for r in rows],
    })
    out["kind"] = out["category"].map(GROUPS).fillna("other")
    out = out[out["sec_type"].fillna("Equity Shares") == "Equity Shares"]
    # The same trade can be disclosed on both exchanges; keep the earliest.
    key = ["symbol", "person", "mode", "txn", "shares", "trade_from", "trade_to"]
    out = out.sort_values("disclosed").drop_duplicates(key, keep="first")
    return out[cols].reset_index(drop=True)


def _session(session=None):
    import requests
    s = session or requests.Session()
    if not s.cookies:
        s.get(HOME, headers={"User-Agent": _UA}, timeout=20)
    return s


def _iso_to_nse(x):
    try:
        return pd.Timestamp(str(x).strip()[:10]).strftime("%d-%b-%Y")
    except (TypeError, ValueError):
        return None


def parse_filing(xml_text, meta=None):
    """
    One new-format (XBRL) insider filing -> raw rows in the legacy endpoint's
    shape, one per disclosure in the file, so :func:`normalise` reads both.
    """
    import xml.etree.ElementTree as ET
    meta = meta or {}
    root = ET.fromstring(xml_text.encode("utf-8") if isinstance(xml_text, str) else xml_text)
    main, parts = {}, {}
    for el in root:
        tag = el.tag.split("}")[-1]
        ctx = el.get("contextRef")
        if ctx is None:
            continue
        (main if ctx == "MainI" else parts.setdefault(ctx, {}))[tag] = (el.text or "").strip()
    when = str(meta.get("broadcastDateTime") or "")[:17] or None      # 'dd-Mon-yyyy HH:MM'
    rows = []
    for ctx in sorted(parts):
        d = parts[ctx]
        rows.append({
            "symbol": main.get("Symbol") or meta.get("symbol"),
            "company": main.get("NameOfTheCompany") or meta.get("companyName"),
            "acqName": d.get("NameOfThePerson"), "personCategory": d.get("CategoryOfPerson"),
            "acqMode": d.get("ModeOfAcquisitionOrDisposal"),
            "tdpTransactionType": d.get("SecuritiesAcquiredOrDisposedTransactionType"),
            "secType": "Equity Shares" if d.get("TypeOfInstrument") == "Equity" else d.get("TypeOfInstrument"),
            "secAcq": d.get("SecuritiesAcquiredOrDisposedNumberOfSecurity"),
            "secVal": d.get("SecuritiesAcquiredOrDisposedValueOfSecurity"),
            # XBRL percentages are fractions (0.0123); the old feed's are percent.
            "befAcqSharesPer": _pct100(d.get("SecuritiesHeldPriorToAcquisitionOrDisposalPercentageOfShareholding")),
            "afterAcqSharesPer": _pct100(d.get("SecuritiesHeldPostAcquistionOrDisposalPercentageOfShareholding")),
            "acqfromDt": _iso_to_nse(d.get("DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyFromDate")),
            "acqtoDt": _iso_to_nse(d.get("DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyToDate")),
            "intimDt": _iso_to_nse(d.get("DateOfIntimationToCompany")),
            "date": when, "exchange": d.get("ExchangeOnWhichTheTradeWasExecuted"),
        })
    return rows


def _pct100(x):
    """XBRL percentages are pure fractions (0.0623 = 6.23%), always."""
    return _num(x) * 100.0


def fetch(start, end, symbol=None, session=None, pause=0.2):
    """
    Disclosures published between two dates (inclusive), optionally for one
    symbol, from both of NSE's endpoints: the archive (to 2 May 2026) and the
    new filing index, whose XBRL files are read one by one.
    """
    s = _session(session)
    h = {"User-Agent": _UA, "Referer": HOME}
    a, b = pd.Timestamp(start).strftime("%d-%m-%Y"), pd.Timestamp(end).strftime("%d-%m-%Y")
    url = API_SYMBOL.format(a=a, b=b, symbol=symbol) if symbol else API.format(a=a, b=b)
    r = s.get(url, headers=h, timeout=120)
    r.raise_for_status()
    rows = list(r.json().get("data") or [])
    if pd.Timestamp(end) >= NEW_FEED_FROM:
        url = API_NEW.format(a=a, b=b) + (f"&symbol={symbol}" if symbol else "")
        r = s.get(url, headers=h, timeout=120)
        r.raise_for_status()
        for meta in r.json().get("data") or []:
            try:
                x = s.get(meta["xmlFileName"], headers=h, timeout=60)
                x.raise_for_status()
                rows.extend(parse_filing(x.content, meta))
            except Exception:
                continue                       # one unreadable filing is not the whole view
            time.sleep(pause)
    return normalise(rows)


def history(start, end, cache_dir=CACHE_DIR, fetch_fn=None, pause=1.0, verbose=True,
            allow_holdout=False, purpose=None):
    """
    Every disclosure published from ``start`` to ``end``, month by month,
    caching completed months in ``cache_dir``. Refuses the reserved period
    (README section 21) unless deliberately opened, like ``bhavcopy.build_panel``.
    """
    import bhavcopy
    bhavcopy._guard_holdout(end, allow_holdout=allow_holdout, purpose=purpose)
    os.makedirs(cache_dir, exist_ok=True)
    session = None
    frames = []
    months = pd.period_range(pd.Timestamp(start), pd.Timestamp(end), freq="M")
    this_month = pd.Timestamp.now().to_period("M")
    for m in months:
        path = os.path.join(cache_dir, f"pit_{m.strftime('%Y%m')}.json.gz")
        rows = None
        if os.path.exists(path):
            with gzip.open(path, "rt", encoding="utf-8") as f:
                rows = json.load(f)
        else:
            a, b = m.start_time, m.end_time.normalize()
            if fetch_fn is not None:
                rows = fetch_fn(a, b)
            else:
                session = _session(session)
                r = session.get(API.format(a=a.strftime("%d-%m-%Y"), b=b.strftime("%d-%m-%Y")),
                                headers={"User-Agent": _UA, "Referer": HOME}, timeout=180)
                r.raise_for_status()
                rows = r.json().get("data") or []
                time.sleep(pause)
            if m < this_month:                       # a finished month never changes
                with gzip.open(path, "wt", encoding="utf-8") as f:
                    json.dump(rows, f)
            if verbose:
                print(f"  {m}: {len(rows):,} disclosures")
        frames.append(normalise(rows))
    df = pd.concat(frames, ignore_index=True) if frames else normalise([])
    df = df[(df["disclosed"] >= pd.Timestamp(start)) & (df["disclosed"] < pd.Timestamp(end) + pd.Timedelta(days=1))]
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# The book's signal
# ---------------------------------------------------------------------------

def insider_trades(df, kinds=("executive", "board", "promoter")):
    """Open-market buys and sells by the book's insiders."""
    m = df["kind"].isin(kinds) & df["mode"].isin([OPEN_MARKET_BUY, OPEN_MARKET_SELL])
    t = df[m].copy()
    t["side"] = np.where(t["mode"] == OPEN_MARKET_BUY, "buy", "sell")
    # Some filings put the trade under the other mode label; the transaction type decides.
    t.loc[(t["side"] == "buy") & (t["txn"] == "Sell"), "side"] = "sell"
    t.loc[(t["side"] == "sell") & (t["txn"] == "Buy"), "side"] = "buy"
    t["pct"] = (t["after_pct"] - t["before_pct"]).abs()
    return t


def leaders(trades, asof, window_days=WINDOW_DAYS, side="buy"):
    """
    The Ch. 19 screen on the trades disclosed in the ``window_days`` up to and
    including ``asof``: count, distinct buyers, value, kinds, share of the
    company, and whether the book's recipe is met.
    """
    asof = pd.Timestamp(asof)
    # Strictly what had been published by ``asof``: a later filing is look-ahead.
    w = trades[(trades["side"] == side) & (trades["disclosed"] <= asof)
               & (trades["disclosed"] > asof - pd.Timedelta(days=window_days))]
    value = float(w["value"].sum()) if len(w) else 0.0
    pct = float(w["pct"].fillna(0.0).sum()) if len(w) else 0.0
    kinds = sorted(set(w["kind"]))
    return {"n": int(len(w)), "buyers": int(w["person"].nunique()) if len(w) else 0,
            "value": value, "pct": pct, "kinds": kinds,
            "executive": "executive" in kinds,
            "meets": bool(len(w) >= MIN_BUYS and value >= MIN_VALUE and pct < MAX_PCT)}


def signal_events(trades, window_days=WINDOW_DAYS, cooldown_days=WINDOW_DAYS, side="buy"):
    """
    The first disclosure at which each stock meets the recipe, then again only
    after ``cooldown_days`` without an event, so overlapping windows are not
    counted twice. Returns one row per event with the window's description.
    """
    out = []
    t = trades[trades["side"] == side].sort_values("disclosed")
    for sym, g in t.groupby("symbol"):
        last = None
        for when in g["disclosed"].drop_duplicates():
            if last is not None and when - last < pd.Timedelta(days=cooldown_days):
                continue
            s = leaders(g, when, window_days, side=side)
            if s["meets"]:
                out.append({"symbol": sym, "disclosed": when, **s})
                last = when
    return pd.DataFrame(out)


def live_view(symbol, today=None, fetch_fn=None, window_days=WINDOW_DAYS):
    """
    The last ``window_days`` of one stock's insider trades, for the app: the
    buy and sell screens and the trades themselves. None on any failure.
    """
    try:
        now = pd.Timestamp(today) if today is not None else pd.Timestamp.now()
        if now == now.normalize():                     # a date: the whole of that day
            now = now + pd.Timedelta(hours=23, minutes=59)
        start = now.normalize() - pd.Timedelta(days=window_days)
        df = (fetch_fn or fetch)(start, now, symbol=symbol)
        tr = insider_trades(df)
        return {"buy": leaders(tr, now, window_days, "buy"),
                "sell": leaders(tr, now, window_days, "sell"),
                "trades": tr.sort_values("disclosed", ascending=False),
                "all_modes": df, "from": str(start.date()), "to": str(now.date())}
    except Exception:
        return None
