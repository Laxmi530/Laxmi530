"""
Tests for ``ARIMAX_model`` - that the regressors reach the model, and enter
lagged.

The defect these pin: pmdarima 2.x takes regressors as ``X`` and silently
swallows the old ``exogenous=`` keyword, so the shipped "ARIMAX" fitted no
regressors at all and was plain ARIMA. Passing them as written would not have
been right either: momentum, volatility, RSI and range at bar t contain r_t,
so a same-bar regression explains r_t with itself (README §59).
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import warnings

import numpy as np
import pandas as pd
import pytest

pm = pytest.importorskip("pmdarima")
import ARIMAX_model as am                       # noqa: E402

warnings.filterwarnings("ignore")


def _frame(n=400, seed=0):
    idx = pd.bdate_range("2021-01-04", periods=n)
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "log_return": rng.normal(0, 0.01, n),
        "log_volume_ratio": rng.normal(0, 1, n),
        "range_hl": rng.uniform(0.01, 0.03, n),
        "volatility": rng.uniform(0.005, 0.02, n),
        "rsi": rng.uniform(30, 70, n),
        "momentum_5": rng.normal(0, 0.02, n),
        "dayofweek": idx.dayofweek, "month": idx.month,
    }, index=idx)
    return df


def test_bar_statistics_enter_lagged_and_calendar_does_not():
    df = _frame()
    cols = am._get_exog_cols("daily")
    y, X = am._lagged_design(df, cols)
    assert len(y) == len(df) - 1 and X.shape == (len(df) - 1, len(cols))
    j = cols.index("momentum_5")
    assert np.allclose(X[:, j], df["momentum_5"].values[:-1])      # t-1
    k = cols.index("dayofweek")
    assert np.allclose(X[:, k], df["dayofweek"].values[1:])        # the target bar's own
    assert np.allclose(y.values, df["log_return"].values[1:])


def test_the_regressors_actually_reach_the_fitted_model():
    """Regression test: with exogenous= the fit had no x-coefficients at all."""
    df = _frame(seed=1)
    # Make the return depend on yesterday's momentum, so a fit that sees X
    # must put weight on it.
    df["log_return"] = 0.5 * df["momentum_5"].shift(1).fillna(0) + df["log_return"] * 0.2
    cols = am._get_exog_cols("daily")
    model, _ = am.train_arimax_garch(df, cols)
    names = [str(k) for k in model.params().index]
    xs = [k for k in names if k.startswith("x")]
    assert len(xs) == len(cols), names
    coef = float(model.params()[f"x{cols.index('momentum_5') + 1}"])
    assert coef == pytest.approx(0.5, abs=0.05)


def test_step_one_regresses_on_the_last_observed_bar():
    df = _frame(seed=2)
    cols = am._get_exog_cols("daily")
    dates = pd.bdate_range(df.index[-1] + pd.offsets.BDay(1), periods=3)
    fx = am._build_future_exog(df, dates, cols, "daily")
    last = df.iloc[-1]
    for c in ("log_volume_ratio", "range_hl", "volatility", "rsi", "momentum_5"):
        assert fx[0, cols.index(c)] == pytest.approx(float(last[c]))
    # Later steps decay toward neutral: momentum shrinks by 0.9 a step.
    j = cols.index("momentum_5")
    assert fx[1, j] == pytest.approx(0.9 * float(last["momentum_5"]))


def test_the_meta_ensemble_keeps_the_statistical_member_it_was_validated_with():
    """
    Every published meta-ensemble figure was measured when its "ARIMAX" member
    silently fitted no regressors, i.e. was ARIMA. With the regressors now
    fitted that member would be a different (measurably worse) model, so the
    ensemble names the one it was validated with.
    """
    import meta_ensemble as me
    stat = [c for c in me._CONSTITUENTS if c[1] in ("ARIMA_GARCH", "ARIMAX_model")]
    assert stat == [("ARIMA+GARCH", "ARIMAX_model", "run_arimax_prediction",
                     {"use_exog": False})]


def test_no_exog_mode_is_the_old_silently_ignored_fit():
    """use_exog=False must equal what auto_arima(..., exogenous=X) did: no X."""
    df = _frame(seed=3)
    kw = dict(start_p=0, start_q=0, max_p=5, max_q=5, max_order=10, d=0,
              seasonal=False, information_criterion="bic", stepwise=True,
              suppress_warnings=True, error_action="ignore", trace=False)
    old = pm.auto_arima(df["log_return"], **kw)
    new, _ = am._train_no_exog(df)
    assert old.order == new.order
    assert np.allclose(old.params(), new.params())
