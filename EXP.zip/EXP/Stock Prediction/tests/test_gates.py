"""
Gate / abstention / no-edge tests — the product's *trust* layer.

A reviewer's point: trust depends on the gates, not only the models. These tests
pin the serving contract directly (no Streamlit), spanning the two pure modules
that implement it: backtest.confidence_bucket (the skill->label rule),
data_quality (the input gate), and gating (the serving layer on top).

Run standalone or under pytest.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np

import backtest as bt
import data_quality as dq
import gating
from test_data_quality import _clean_daily, NOW   # reuse synthetic builders


# ── confidence_bucket: weak evidence can never be "High" ────────────────────
def test_weak_dm_cannot_be_high():
    # Large RMSE improvement but a weak (insignificant) DM p-value.
    b = bt.confidence_bucket(improvement=0.20, dm_pvalue=0.40, coverage=0.95)
    assert b != 'High', b


def test_significant_edge_is_high():
    b = bt.confidence_bucket(improvement=0.10, dm_pvalue=0.01, coverage=0.95)
    assert b == 'High', b


def test_no_improvement_is_no_edge():
    assert bt.confidence_bucket(improvement=-0.01, dm_pvalue=0.01, coverage=0.95) == 'No edge'
    assert bt.confidence_bucket(improvement=0.0, dm_pvalue=np.nan, coverage=np.nan) == 'No edge'


def test_bad_coverage_blocks_high():
    # Strong, significant improvement but a broken 60% interval -> not High.
    b = bt.confidence_bucket(improvement=0.20, dm_pvalue=0.01, coverage=0.60)
    assert b != 'High', b


# ── gated_direction: "No edge" withholds the call ───────────────────────────
def test_no_edge_withholds_direction():
    s, d = gating.gated_direction(change=12.3, bucket='No edge')
    assert s == 'No edge' and d == gating.WITHHELD_DIRECTION


def test_edge_shows_direction():
    assert gating.gated_direction(5.0, 'High') == ('Bullish', '▲')
    assert gating.gated_direction(-5.0, 'High') == ('Bearish', '▼')
    # No assessment (bucket None) is not the same as "No edge": call is shown.
    assert gating.gated_direction(5.0, None)[0] == 'Bullish'


# ── conviction: wide interval => |conviction| < 1 (inside the band) ─────────
def test_wide_interval_caps_conviction_below_one():
    # Move of +10 against a very wide band (half-width 100) -> tiny conviction.
    c = gating.conviction(change=10.0, lower=900.0, upper=1100.0)
    assert abs(c) < 1.0, c


def test_tight_interval_high_conviction():
    # Same move against a tight band (half-width 5) -> conviction > 1.
    c = gating.conviction(change=10.0, lower=995.0, upper=1005.0)
    assert c > 1.0, c


def test_no_interval_conviction_nan():
    assert np.isnan(gating.conviction(10.0, None, None))


# ── data-quality gate -> serving mode ───────────────────────────────────────
def test_stale_data_becomes_abstain():
    df = _clean_daily(end="2026-05-01")          # ~8 weeks stale vs NOW
    r = dq.assess_data_quality(df, "1d", horizon=5, now=NOW)
    assert r.mode == 'abstain'


def test_insufficient_history_abstains():
    r = dq.assess_data_quality(_clean_daily(n=30), "1d", horizon=5, now=NOW)
    assert r.mode == 'abstain'


def test_clean_data_serves_normally():
    r = dq.assess_data_quality(_clean_daily(), "1d", horizon=5, now=NOW)
    assert r.mode == 'normal'


# ── apply_data_quality_gate: degraded data withholds ALL directions ─────────
def test_degraded_forces_no_edge_for_all():
    conf = {'XGBoost (ML)': {'bucket': 'High', 'dm_p': 0.01},
            'ARIMA-GARCH': {'bucket': 'Medium'}}
    gated = gating.apply_data_quality_gate(conf, list(conf), degraded=True)
    assert all(v['bucket'] == 'No edge' for v in gated.values())
    # Even models that were never assessed get withheld.
    gated2 = gating.apply_data_quality_gate({}, ['LSTM (DL)'], degraded=True)
    assert gated2['LSTM (DL)']['bucket'] == 'No edge'


def test_good_data_leaves_buckets_untouched():
    conf = {'XGBoost (ML)': {'bucket': 'High'}}
    gated = gating.apply_data_quality_gate(conf, list(conf), degraded=False)
    assert gated['XGBoost (ML)']['bucket'] == 'High'
    # Input not mutated.
    assert conf['XGBoost (ML)']['bucket'] == 'High'


# ── no implied "best model": reason codes reflect evidence, not rank ────────
def test_reason_code_states_no_edge():
    assert 'no edge' in gating.confidence_reason({'bucket': 'No edge', 'dm_p': 0.42})
    assert 'data quality' in gating.confidence_reason(
        {'bucket': 'No edge', 'note': 'withheld: data quality'})


# ── a p-value is not P(no edge) (Kanungo Ch. 4; Sellke, Bayarri & Berger) ──
def test_min_bayes_factor_known_values():
    import math
    import backtest
    # -e p ln p: 0.4072 at p = 0.05, 0.1252 at p = 0.01; no evidence above 1/e.
    assert abs(backtest.min_bayes_factor(0.05) - 0.40716) < 1e-4
    assert abs(backtest.min_bayes_factor(0.01) - 0.12518) < 1e-4
    assert backtest.min_bayes_factor(0.5) == 1.0
    assert backtest.min_bayes_factor(1.0 / math.e) == 1.0
    for bad in (float('nan'), 0.0, -0.1, 1.5):
        assert math.isnan(backtest.min_bayes_factor(bad))
    # Monotone: a smaller p is never weaker evidence.
    ps = [0.001, 0.01, 0.05, 0.1, 0.2, 0.3]
    bfs = [backtest.min_bayes_factor(p) for p in ps]
    assert bfs == sorted(bfs)


def test_null_probability_floor_at_the_bucket_thresholds():
    import backtest
    # Even prior odds. 'High' needs DM p < 0.10 and 'Medium' p < 0.20, and
    # neither threshold means what it sounds like.
    assert abs(backtest.null_probability_floor(0.05) - 0.2893) < 1e-3
    assert abs(backtest.null_probability_floor(0.10) - 0.3849) < 1e-3
    assert abs(backtest.null_probability_floor(0.20) - 0.4668) < 1e-3
    # A sceptical prior can only raise the floor.
    assert backtest.null_probability_floor(0.05, prior_null=0.8) > \
        backtest.null_probability_floor(0.05)
    # The floor is always above the naive misreading P(H0) = p.
    for p in (0.001, 0.01, 0.05, 0.1, 0.2):
        assert backtest.null_probability_floor(p) > p


def test_reason_code_prints_the_floor_where_an_edge_is_claimed():
    hi = gating.confidence_reason({'bucket': 'High', 'dm_p': 0.05, 'coverage': 0.94})
    assert hi == "beats random walk (DM p=0.05, cov 94%; P(no edge) ≥ 29%)", hi
    med = gating.confidence_reason({'bucket': 'Medium', 'dm_p': 0.14})
    assert med == "weak edge (DM p=0.14; P(no edge) ≥ 43%)", med
    # Where no edge is claimed there is nothing to deflate, and no p prints none.
    assert 'P(no edge)' not in gating.confidence_reason({'bucket': 'No edge', 'dm_p': 0.42})
    assert 'P(no edge)' not in gating.confidence_reason({'bucket': 'Medium'})


# ── the withholding reason survives the UI's entry shape ────────────────────
# UI._model_confidence always writes 'note': '' (and 'assessment failed: ...'
# on error). setdefault never replaced either, so a row withheld for its data
# read "no edge vs random walk (DM p=0.03)" -- blaming a model that rated High.
def _ui_entry(bucket='High', note=''):
    return {'bucket': bucket, 'improvement': 0.08, 'dm_p': 0.03,
            'coverage': 0.94, 'note': note}


def test_data_quality_reason_shown_for_ui_entries():
    conf = {'XGBoost': _ui_entry(), 'LSTM': _ui_entry('N/A', 'assessment failed: boom')}
    gated = gating.apply_data_quality_gate(conf, list(conf), degraded=True)
    for m in conf:
        assert gating.confidence_reason(gated[m]) == "withheld — data quality", gated[m]


def test_novelty_reason_shown_for_ui_entries():
    nov = {'available': True, 'verdict': 'unprecedented', 'percentile': 0.999}
    gated = gating.apply_novelty_gate({'XGBoost': _ui_entry()}, ['XGBoost'], nov)
    assert gating.confidence_reason(gated['XGBoost']) == "withheld — unseen market regime"
    # The first gate to withhold keeps its reason.
    both = gating.apply_novelty_gate(
        gating.apply_data_quality_gate({'XGBoost': _ui_entry()}, ['XGBoost'], True),
        ['XGBoost'], nov)
    assert gating.confidence_reason(both['XGBoost']) == "withheld — data quality"


def test_unusual_regime_keeps_assessment_note_and_verdict():
    nov = {'available': True, 'verdict': 'unusual', 'percentile': 0.97}
    gated = gating.apply_novelty_gate(
        {'XGBoost': _ui_entry(), 'LSTM': _ui_entry('N/A', 'assessment failed: boom')},
        ['XGBoost', 'LSTM'], nov)
    assert gated['XGBoost']['bucket'] == 'High'
    assert gating.confidence_reason(gated['XGBoost']).endswith("· unusual regime")
    assert gated['LSTM']['note'] == 'assessment failed: boom'


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All gate tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
