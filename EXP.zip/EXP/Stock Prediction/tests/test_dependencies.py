"""
Tests for ``dependencies`` and ``run_app`` - finding and installing missing
packages. Network-free: pip is never actually run (the real install was
checked once in a fresh virtualenv; README "Getting started").
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import pytest

import dependencies as deps
import run_app


def _reqs(tmp_path, text):
    p = tmp_path / "requirements.txt"
    p.write_text(text, encoding="utf-8")
    return deps.read_requirements(str(p))


def test_requirements_are_parsed_like_pip_reads_them(tmp_path):
    r = _reqs(tmp_path, "# a comment\n\npandas==3.0.3   # trailing\n-r other.txt\n"
                        "chronos-forecasting==2.2.2\nrequests[socks]>=2\n")
    assert r == [("pandas", "pandas==3.0.3", "3.0.3"),
                 ("chronos-forecasting", "chronos-forecasting==2.2.2", "2.2.2"),
                 ("requests", "requests[socks]>=2", None)]
    # The project's own file parses, and the app needs nothing it does not list.
    own = {n for n, _, _ in deps.read_requirements()}
    assert {"streamlit", "prophet", "tensorflow", "chronos-forecasting"} <= own


def test_missing_and_mismatched_are_told_apart(tmp_path):
    have = deps.installed_version("pytest")
    r = _reqs(tmp_path, f"pytest=={have}\ndefinitely-not-a-real-package-xyz==1.0\npip==0.0.1\n")
    missing, mismatched = deps.check(r)
    assert [m[0] for m in missing] == ["definitely-not-a-real-package-xyz"]
    assert [m[0] for m in mismatched] == ["pip"]          # reported, never changed
    assert deps.missing(r) == ["definitely-not-a-real-package-xyz"]


def test_prophet_is_installed_without_its_contradicting_deps_then_its_own_deps():
    steps = deps.plan([("xgboost", "xgboost==3.2.0", "3.2.0"),
                       ("prophet", "prophet==1.2.2", "1.2.2")], deps.read_requirements())
    assert steps[0] == ["install", "-c", "{constraints}", "xgboost==3.2.0"]
    assert steps[1] == ["install", "--no-deps", "prophet==1.2.2"]
    assert steps[2] == ("DEPS_OF", "prophet")


def test_install_pins_everything_and_stops_on_a_pip_error(tmp_path, monkeypatch):
    r = _reqs(tmp_path, "numpy==2.4.6\npandas==3.0.3\nfakepkg-one==1.0\nprophet==1.2.2\n")
    seen = []

    def runner(cmd):
        seen.append(cmd)
        if "-c" in cmd:
            with open(cmd[cmd.index("-c") + 1], encoding="utf-8") as f:
                seen.append(f.read())
        return 0
    monkeypatch.setattr(deps, "_declared_deps", lambda name, skip: ["cmdstanpy>=1.0.4"])
    missing_specs = [("fakepkg-one", "fakepkg-one==1.0", "1.0"), ("prophet", "prophet==1.2.2", "1.2.2")]
    deps.install(missing_specs, reqs=r, runner=runner, log=lambda *_: None)
    cmds = [c for c in seen if isinstance(c, list)]
    texts = [c for c in seen if isinstance(c, str)]
    assert cmds[0][-1] == "fakepkg-one==1.0" and "--no-deps" in cmds[1]
    assert cmds[2][-1] == "cmdstanpy>=1.0.4"
    # The constraints hold every pin except prophet's own (its caps are the conflict).
    assert "numpy==2.4.6" in texts[0] and "pandas==3.0.3" in texts[0] and "prophet" not in texts[0]

    calls = []
    assert deps.install(missing_specs, reqs=r, runner=lambda c: calls.append(c) or 1,
                        log=lambda *_: None) is False
    assert len(calls) == 1                                  # stopped at the first failure


def test_the_launcher_reports_without_installing_on_check(monkeypatch, capsys):
    monkeypatch.setattr(deps, "check", lambda reqs=None: ([("x", "x==1", "1", None)], []))
    monkeypatch.setattr(deps, "install", lambda *a, **k: pytest.fail("must not install on --check"))
    assert run_app.main(["--check"]) == 1
    assert "1 required package(s) are not installed" in capsys.readouterr().out
    # Declining at the prompt installs nothing.
    monkeypatch.setattr("builtins.input", lambda *_: "n")
    assert run_app.main([]) == 1


def test_the_install_page_lists_what_is_missing():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_string(
        "import streamlit as st\nimport dependencies\n"
        "dependencies.render_install_page(st, ['prophet', 'tensorflow'])\n"
        "st.write('never reached')\n", default_timeout=60).run()   # the 3 s default is flaky under load
    assert not at.exception
    assert at.title[0].value == "Some required packages are not installed"
    assert "prophet\ntensorflow" in at.code[0].value
    assert at.button[0].label == "Install missing packages"
    assert not any("never reached" in m.value for m in at.markdown)
