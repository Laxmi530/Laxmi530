"""
Does the Hybrid ARIMA+LSTM's new split-conformal 95% band hold 95% of
outcomes? (README section 69.) NSE data before the reserved period only.

Written down before running
---------------------------
* Data: the survivorship-free bhavcopy panel, 2018-01-01 .. 2024-06-30. Six
  names drawn with a fixed seed from the 40 most liquid that trade on every
  session; for each, 8 forecast origins evenly spaced from 2021-07-01 to the
  last date with 5 sessions after it.
* Each forecast sees only the prices up to its origin (the model keeps the
  last 750), exactly as in the app; it is scored against the next 5 prices.
* THE TEST: pooled coverage over all 240 forecast-steps. The band passes if
  it is at least 90%; the target, 95%, should sit inside its 95% Wilson
  interval. Coverage by step and the mean width are reported alongside.

Steps share an origin, so the 240 are not independent; the Wilson interval
is computed on the 48 origins' mean coverage as well, which is the honest
sample size.

Run::

    python tests/validation/run_hybrid_coverage.py
"""

import concurrent.futures as cf
import contextlib
import io
import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, _ROOT)

START, END = "2018-01-01", "2024-06-30"
ORIGINS_FROM = pd.Timestamp("2021-07-01")
N_NAMES, N_ORIGINS, HORIZON, SEED = 6, 8, 5, 20261020
OUT = os.path.join(_HERE, "hybrid_coverage.csv")


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def one(task):
    """One forecast: history up to the origin, scored on the next HORIZON prices."""
    sym, hist, future = task
    sys.path.insert(0, _ROOT)
    os.environ["STOCKAPP_QUIET"] = "1"
    import Hybrid_model as hm
    with contextlib.redirect_stdout(io.StringIO()):
        out = hm.run_hybrid_prediction(hist, "1d", HORIZON)
    rows = []
    for h in range(HORIZON):
        lo, hi, p = (float(out[c].iloc[h]) for c in ("lower_bound", "upper_bound", "predicted_price"))
        a = float(future[h])
        rows.append({"symbol": sym, "origin": str(hist["datetime"].iloc[-1].date()), "step": h + 1,
                     "actual": a, "forecast": p, "lower": lo, "upper": hi,
                     "covered": bool(lo <= a <= hi), "width_pct": (hi - lo) / p * 100})
    return rows


def main():
    import bhavcopy as bc
    print("=" * 78)
    print("HYBRID ARIMA+LSTM: COVERAGE OF THE NEW 95% BAND ON NSE, 2021-07 .. 2024-06")
    print("=" * 78)
    panel, _ = bc.build_panel(START, END, n=40, verbose=False, purpose="Hybrid band coverage")
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close", aggfunc="last").sort_index()
    full = [s for s in px.columns if px[s].notna().all()]
    rng = np.random.default_rng(SEED)
    names = sorted(rng.choice(full, size=N_NAMES, replace=False).tolist())
    dates = px.index
    lo_i = dates.searchsorted(ORIGINS_FROM)
    hi_i = len(dates) - HORIZON - 1
    origin_idx = np.linspace(lo_i, hi_i, N_ORIGINS).round().astype(int)
    tasks = []
    for s in names:
        series = px[s]
        for i in origin_idx:
            hist = pd.DataFrame({"datetime": dates[:i + 1], "adj_close": series.values[:i + 1],
                                 "close": series.values[:i + 1]})
            tasks.append((s, hist, series.values[i + 1:i + 1 + HORIZON]))
    print(f"  {len(names)} names ({', '.join(names)}), {len(origin_idx)} origins each, {HORIZON} steps")
    rows = []
    with cf.ProcessPoolExecutor(max_workers=3) as ex:
        for r in ex.map(one, tasks):
            rows.extend(r)
    d = pd.DataFrame(rows)
    d.to_csv(OUT, index=False)

    k, n = int(d["covered"].sum()), len(d)
    lo, hi = wilson(k, n)
    per_origin = d.groupby(["symbol", "origin"])["covered"].mean()
    m = len(per_origin)
    olo, ohi = wilson(per_origin.mean() * m, m)
    print(f"\n  pooled coverage: {k}/{n} = {k / n:.1%}  (Wilson 95% {lo:.1%} .. {hi:.1%}; "
          f"on the {m} origins {olo:.1%} .. {ohi:.1%})")
    print(f"  {'step':>6}{'coverage':>10}{'mean width':>12}")
    for h, g in d.groupby("step"):
        print(f"  {h:>6}{g['covered'].mean():>10.1%}{g['width_pct'].mean():>11.1f}%")
    by_name = d.groupby("symbol")["covered"].mean()
    print("  by name: " + ", ".join(f"{s} {v:.0%}" for s, v in by_name.items()))
    verdict = ("PASSES" if k / n >= 0.90 else "FAILS") + (", 95% inside the interval" if lo <= 0.95 <= hi
                                                          else ", 95% outside the interval")
    print(f"\n  THE TEST (pooled coverage >= 90%): {verdict}")
    print(f"  wrote {OUT}")
    return 0 if k / n >= 0.90 else 1


if __name__ == "__main__":
    sys.exit(main())
