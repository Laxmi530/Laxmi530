"""
Synthetic returns on NSE: what the Kolmogorov-Smirnov test sees, and what it misses.

Hilpisch, *Reinforcement Learning for Finance*, Ch. 5, validates GAN-generated
returns with a KS test (25 of 25 pass) and concludes they have "all the
qualities of the original data set". ``synthetic_check.compare_paths``
reports KS next to the stylized facts KS cannot see. This driver runs it on
real NSE return paths against five generators:

    shuffle         the real returns in random order: the real marginal,
                    no time structure. The cleanest test of KS's blind spot.
    Gaussian        independent normal draws with the real mean and sd.
    GAN             the project's optional generator
                    (``var_models._gan_samples``), as the chapter's: it maps
                    independent noise to returns, one day at a time.
    block bootstrap the project's default (``var_models``' stationary
                    bootstrap, mean block 5), as a path.
    GARCH(1,1)-t    fitted to each name with ``arch`` and simulated: a model
                    generator with clustering built in.

Each synthetic path has the real path's length. 2018-01-01 .. 2024-06-30,
before the reserved period.

Run::

    python tests/validation/run_synthetic_check.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import synthetic_check as sc       # noqa: E402

START, END = "2018-01-01", "2024-06-30"
SYMBOLS = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC")
SEEDS = 5
OUT = os.path.join(_HERE, "synthetic_check.csv")


def gan_path_draws(r, seed):
    """One path from the project's GAN: n draws of independent noise, mapped."""
    import importlib.util
    if importlib.util.find_spec("tensorflow") is None:      # the GAN needs it
        return None
    import var_models as vm
    # _gan_samples returns horizon SUMS; ask for len(r) one-day "sums".
    s = vm._gan_samples(r, horizon=1, n_sims=len(r), seed=seed, epochs=400)
    return None if s is None else np.asarray(s, dtype=np.float64)


def garch_paths(r, seeds):
    """
    Fit GARCH(1,1)-t once, then simulate one seeded path per seed.

    Built from parts so the Student-t draws are SEEDED: arch_model(dist="t")
    simulates from an unseeded generator, and a first version of this driver
    printed a different GARCH row on every run.
    """
    from arch.univariate import ConstantMean, GARCH, StudentsT
    params = ConstantMean(100 * r, volatility=GARCH(p=1, q=1),
                          distribution=StudentsT()).fit(disp="off").params
    out = []
    for s in seeds:
        am = ConstantMean(100 * r, volatility=GARCH(p=1, q=1),
                          distribution=StudentsT(seed=np.random.default_rng(1000 + s)))
        out.append(am.simulate(params, nobs=len(r), burn=500)["data"].to_numpy() / 100.0)
    return out


def main():
    print("=" * 78)
    print("SYNTHETIC RETURNS: KS vs THE STYLIZED FACTS  (Hilpisch, RL for Finance, Ch. 5)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=40, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close",
                           aggfunc="last").sort_index()
    rows = []
    for k, sym in enumerate(SYMBOLS):
        if sym not in px:
            continue
        r = np.log(px[sym].dropna()).diff().dropna().to_numpy()
        # One path per name is too noisy to rank generators: a first version
        # did that, and three runs gave GARCH clustering of 0.40, 0.47 and 0.35.
        # So every cheap generator gets SEEDS paths per name and the name's
        # value is their median. The GAN needs a training run per path, so it
        # keeps one.
        seeds = [100 * k + s for s in range(SEEDS)]
        gens = {"shuffle": [np.random.default_rng(s).permutation(r) for s in seeds],
                "Gaussian": [np.random.default_rng(s).normal(r.mean(), r.std(), len(r)) for s in seeds],
                "GAN (project's)": [gan_path_draws(r, k)],
                "block bootstrap (project's)": [sc.stationary_bootstrap_path(r, len(r), 5, s) for s in seeds],
                "GARCH(1,1)-t": garch_paths(r, seeds)}
        for g, paths in gens.items():
            paths = [p for p in paths if p is not None]
            if not paths:
                print(f"  {sym}: {g} unavailable")
                continue
            cs = [sc.compare_paths(r, p) for p in paths]
            med = lambda key: float(np.median([c[key] for c in cs]))
            rows.append({"symbol": sym, "generator": g, "n_paths": len(cs),
                         "ks_p": med("ks_p"), "passes_ks": float(np.mean([c["passes_ks"] for c in cs])),
                         "clustering_ratio": med("clustering_ratio"), "tail_ratio": med("tail_ratio"),
                         "leverage_real": med("leverage_real"), "leverage_synth": med("leverage_synth"),
                         "agg_kurtosis_ratio": med("agg_kurtosis_ratio"),
                         "fully_matches": float(np.mean([c["verdict"] == "matches every checked fact" for c in cs]))})
    d = pd.DataFrame(rows)
    d.to_csv(OUT, index=False)
    print(f"\n  {d.symbol.nunique()} names, {SEEDS} paths per name (GAN: 1); medians (ratio = synthetic / real; 1 = matches)\n")
    print(f"  {'generator':<29}{'passes KS':>10}{'clustering':>12}{'1% tail':>9}"
          f"{'leverage r/s':>15}{'20-day kurt':>13}   fully matches")
    for g, x in d.groupby("generator", sort=False):
        print(f"  {g:<29}{x.passes_ks.mean():10.0%}{x.clustering_ratio.median():12.2f}"
              f"{x.tail_ratio.median():9.2f}{x.leverage_real.median():+8.3f}/{x.leverage_synth.median():+.3f}"
              f"{x.agg_kurtosis_ratio.median():13.2f}   "
              f"{x.fully_matches.mean():.0%}")
    print("\n  'passes KS' is the chapter's test. Every other column is a property it")
    print("  cannot see; 'fully matches' needs all of them within tolerance.")

    # How much of the clustering a block bootstrap keeps depends on its block
    # length. var_models uses a mean block of 5; volatility memory on NSE is
    # long (DFA ~0.71, Section 56). Medians over names and 5 seeds each.
    print("\n  block bootstrap: what the mean block length keeps (medians, 5 seeds per name)")
    print(f"  {'mean block':>12}{'clustering':>12}{'20-day kurt':>13}")
    blk = []
    for bm in (5, 10, 20, 40, 80):
        cl, ak = [], []
        for k, sym in enumerate(SYMBOLS):
            if sym not in px:
                continue
            r = np.log(px[sym].dropna()).diff().dropna().to_numpy()
            for s in range(5):
                c = sc.compare_paths(r, sc.stationary_bootstrap_path(r, len(r), bm, 100 * k + s))
                cl.append(c["clustering_ratio"])
                ak.append(c["agg_kurtosis_ratio"])
        blk.append({"block_mean": bm, "clustering": float(np.median(cl)), "agg_kurt": float(np.median(ak))})
        print(f"  {bm:12d}{np.median(cl):12.2f}{np.median(ak):13.2f}")
    pd.DataFrame(blk).to_csv(OUT.replace(".csv", "_blocks.csv"), index=False)
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
