"""
The O'Neil-disciple signals on NSE: pocket pivots, major gap-ups, and Dr. K's
market direction model (Morales & Kacher, *Trade Like an O'Neil Disciple*,
Ch. 5 and 7).

The book reports a backtest of +33.1% a year (1974-2009) for its market model
and calls pocket pivots "a highly exploitable phenomenon". It also says its
follow-through threshold was re-chosen several times "based on perceived
volatility" and that the model has undisclosed "fail-safes". Both are exactly
how a backtest is overfitted, so every rule below is fixed before looking, at
the book's own published values.

Data: the survivorship-free bhavcopy panel (200 liquid names) and NIFTY 50 OHLC
(yfinance, ending 2024-06-30); 2018-01-01 .. 2024-06-30, before the reserved
period. Volume is rupee TURNOVER throughout: share volume jumps on a split,
turnover does not, and the market's volume is NSE's total equity turnover
(NIFTY's own volume field is zero on 25 days of this window).

A. Pocket pivots (Ch. 5). Core: an up close on turnover at least the largest
   down-day turnover of the prior 10 sessions, closing above the 50-day
   average. Proper: core, plus the day's low within 1% of the 10-day average
   ("right at or just below"; the 1% is ours) and no "wedging" (price rising
   over the prior 10 sessions on falling turnover). Control: up closes above
   the 50-day average WITHOUT the volume signature, so the comparison isolates
   what the book's volume rule adds.
B. Major gap-ups (Ch. 5): the open at least 0.75 x the 40-day ATR above the
   prior close, on turnover at least 1.5 x its 50-day average. "Leading stock"
   proxy (the book's fundamentals are unavailable, README section 32): above
   the 50-day average and within 15% of the 52-week high. Held 21 sessions
   from the close, with and without the book's sell rule (exit if the gap
   day's low is broken; filled at the lower of that day's open and the low).
C. Market direction model (Ch. 7) on NIFTY. Distribution day: down at least
   0.1% on higher volume, or "churning" (up less than 0.1%, closing in the
   bottom quarter of the range, on higher volume). Sell: 5 or more in 20
   sessions. Follow-through: from the first up close after a new low, sessions
   4-7 of the rally attempt, up at least the threshold on higher volume;
   thresholds 1.0% (O'Neil's original) and 1.5% (the book's 2010 value). Long
   NIFTY in an uptrend, cash in a correction, 10 bp per switch.

Excess returns are over the equal-weighted panel. Event t-statistics average
events by calendar month first, so a crowded day cannot pass for many
independent observations. The market model is tested against 1,000 circular
shifts of its own state series (same time in the market, same run lengths).

Run::

    python tests/validation/run_oneil.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                                         # noqa: E402
import oneil                                                  # noqa: E402
from run_market_breadth import newey_west_ols                 # noqa: E402

START, END = "2018-01-01", "2024-06-30"
HORIZONS = (5, 21, 63)
COST = 0.0022                    # delivery round trip (README section 55)
SWITCH_COST = 0.0010             # index futures, per switch, incl. spread
OUT = os.path.join(_HERE, "oneil.csv")


def monthly_t(dates, values, lag=1):
    """Mean and Newey-West t of the per-month means of event values."""
    s = pd.Series(np.asarray(values, float), index=pd.to_datetime(dates)).dropna()
    if len(s) < 10:
        return float("nan"), float("nan"), 0
    m = s.groupby(s.index.to_period("M")).mean()
    if len(m) < 6:
        return float(m.mean()), float("nan"), len(s)
    b, t = newey_west_ols(m.values, np.zeros((len(m), 0)), lag)
    return float(b[0]), float(t[0]), len(s)


def event_table(label, ev, market_fwd):
    print(f"\n  {label}")
    print(f"  {'group':<34}{'events':>8}" + "".join(f"{f'{h}d excess':>12}{'t':>7}" for h in HORIZONS)
          + f"{'21d hit':>9}")
    rows = []
    for name, sub in ev.items():
        line = f"  {name:<34}{len(sub):>8,d}"
        rec = {"study": label, "group": name, "n": len(sub)}
        for h in HORIZONS:
            x = sub[f"fwd_{h}"] - sub["date"].map(market_fwd[h])
            m, t, _ = monthly_t(sub["date"], x, lag=max(1, h // 21))
            rec[f"ex_{h}"], rec[f"t_{h}"] = m, t
            line += f"{m * 100:11.2f}%{t:7.2f}"
        hit = float(np.mean((sub["fwd_21"] - sub["date"].map(market_fwd[21])) > 0)) if len(sub) else float("nan")
        rec["hit_21"] = hit
        print(line + f"{hit:9.1%}")
        rows.append(rec)
    return rows


def main():
    print("=" * 78)
    print("O'NEIL-DISCIPLE SIGNALS ON NSE  (Morales & Kacher, Ch. 5 and 7)")
    print("=" * 78)
    panel, _ = bc.build_panel(START, END, n=200, verbose=False)
    frames = {s: oneil.stock_signals(g) for s, g in panel.groupby("symbol") if len(g) >= 300}
    allr = pd.concat({s: f["ret"] for s, f in frames.items()}, axis=1)
    mkt = allr.mean(axis=1)
    market_fwd = {h: mkt[::-1].rolling(h).sum()[::-1].shift(-1) for h in HORIZONS}
    print(f"  {len(frames)} names, {len(mkt):,} sessions")

    ev = pd.concat([f.assign(symbol=s, date=f.index) for s, f in frames.items()], ignore_index=True)
    ev = ev[ev["date"] >= pd.Timestamp(START) + pd.Timedelta(days=90)]
    rows = event_table("A. POCKET PIVOTS", {
        "core pocket pivot": ev[ev.pp_core], "proper pocket pivot": ev[ev.pp_proper],
        "control: up, above 50-day, no signature": ev[ev.pp_control],
        "all sessions": ev}, market_fwd)

    # Difference: what the volume signature adds, same month.
    for h in (21,):
        a = ev[ev.pp_core].assign(x=lambda d: d[f"fwd_{h}"] - d["date"].map(market_fwd[h]))
        c = ev[ev.pp_control].assign(x=lambda d: d[f"fwd_{h}"] - d["date"].map(market_fwd[h]))
        ma = a.groupby(a.date.dt.to_period("M")).x.mean()
        mc = c.groupby(c.date.dt.to_period("M")).x.mean()
        d = (ma - mc).dropna()
        b, t = newey_west_ols(d.values, np.zeros((len(d), 0)), 1)
        print(f"\n  core pocket pivot minus control, {h}d, by month: {b[0] * 100:+.2f}%  t {t[0]:+.2f} "
              f"({len(d)} months); net of a {COST * 100:.2f}% round trip the pivot's own mean is "
              f"{(a.x.mean() - COST) * 100:+.2f}%")

    rows += event_table("B. MAJOR GAP-UPS (held 21 sessions from the close)", {
        "major gap-up, all": ev[ev.gap_major], "major gap-up, leading-stock proxy": ev[ev.gap_leader]},
        market_fwd)
    g = ev[ev.gap_leader & ev.stop_ret_21.notna()].copy()
    mcum = mkt.fillna(0.0).cumsum()
    pos = mcum.index.get_indexer(g["date"])
    end = np.clip(pos + g["stop_days"].astype(int).to_numpy(), 0, len(mcum) - 1)
    g["ex_stop"] = g["stop_ret_21"].to_numpy() - (mcum.to_numpy()[end] - mcum.to_numpy()[pos])
    m, t, n = monthly_t(g["date"], g["ex_stop"])
    print(f"  with the book's sell rule (exit below the gap day's low): 21d excess {m * 100:+.2f}%  t {t:+.2f}; "
          f"stopped out {g['stopped'].mean():.0%}")
    rows.append({"study": "B", "group": "gap leader with stop", "n": n, "ex_21": m, "t_21": t})

    # ------------------------------------------------- D: the sell guide
    # A sell rule is worth following if what it sells then does WORSE than the
    # market, and worse than the same event without the rule's extra condition.
    rows += event_table("D. MOVING-AVERAGE SELL GUIDE: a close crossing below the 50-day", {
        "on heavy volume (>= 1.5x the 50-day avg)": ev[ev.ma50_break_heavy],
        "control: on ordinary volume": ev[ev.ma50_break_light]}, market_fwd)
    for h in (5, 21, 63):
        a = ev[ev.ma50_break_heavy].assign(x=lambda d: d[f"fwd_{h}"] - d["date"].map(market_fwd[h]))
        c = ev[ev.ma50_break_light].assign(x=lambda d: d[f"fwd_{h}"] - d["date"].map(market_fwd[h]))
        dm = (a.groupby(a.date.dt.to_period("M")).x.mean() - c.groupby(c.date.dt.to_period("M")).x.mean()).dropna()
        b, tt = newey_west_ols(dm.values, np.zeros((len(dm), 0)), max(1, h // 21))
        print(f"  heavy minus ordinary volume, {h}d, by month: {b[0] * 100:+.2f}%  t {tt[0]:+.2f} ({len(dm)} months)")
        rows.append({"study": "D", "group": f"heavy minus light {h}d", "n": len(dm), f"ex_{h}": b[0], f"t_{h}": tt[0]})

    # ------------------------------------------------------ C: market model
    print("\nC. DR. K'S MARKET DIRECTION MODEL ON NIFTY")
    nifty = oneil.load_nifty(START, END)
    turnover = bc.load_cache(pd.Timestamp(START) - pd.Timedelta(days=60), END).groupby("datetime")["turnover"].sum()
    idx = nifty.join(turnover.rename("volume"), how="inner")
    r = np.log(idx["close"]).diff()
    for thr in (0.010, 0.015):
        st = oneil.market_direction(idx, ftd_threshold=thr)
        live = st.index >= pd.Timestamp(START)
        st, rr = st[live], r[live]
        pos = (st["state"] == "uptrend").astype(float).shift(1).fillna(1.0)
        switches = pos.diff().abs().fillna(0.0)
        strat = pos * rr - switches * SWITCH_COST / 2.0
        def stats(x):
            ann = x.mean() * 252
            vol = x.std() * math.sqrt(252)
            eq = np.exp(x.cumsum())
            return ann, vol, ann / vol if vol else float("nan"), float((eq / eq.cummax() - 1).min())
        a_s, v_s, sh_s, dd_s = stats(strat)
        a_b, v_b, sh_b, dd_b = stats(rr)
        rng = np.random.default_rng(0)
        state = pos.values
        sh_null = []
        for _ in range(1000):
            k = rng.integers(20, len(state) - 20)
            p2 = np.roll(state, k)
            sw2 = np.abs(np.diff(p2, prepend=p2[0]))
            x2 = p2 * rr.values - sw2 * SWITCH_COST / 2.0
            sh_null.append(np.nanmean(x2) / np.nanstd(x2) * math.sqrt(252))
        p_val = float(np.mean(np.array(sh_null) >= sh_s))
        n_dd = int(st["dist_day"].sum())
        n_sell, n_ftd = int((st["signal"] == "sell").sum()), int((st["signal"] == "ftd").sum())
        print(f"\n  follow-through threshold {thr * 100:.1f}%: {n_dd} distribution days, {n_sell} sell "
              f"signals, {n_ftd} follow-throughs; in the market {pos.mean():.0%} of sessions, "
              f"{int(switches.sum())} switches")
        print(f"    model long/cash : return {a_s * 100:5.1f}%/yr  vol {v_s * 100:4.1f}%  Sharpe {sh_s:.2f}  max DD {dd_s * 100:6.1f}%")
        print(f"    buy and hold    : return {a_b * 100:5.1f}%/yr  vol {v_b * 100:4.1f}%  Sharpe {sh_b:.2f}  max DD {dd_b * 100:6.1f}%")
        print(f"    circular-shift placebo: Sharpe at least as good in {p_val:.1%} of 1,000 shifts")
        fwd21 = rr[::-1].rolling(21).sum()[::-1].shift(-1)
        fv21 = np.sqrt((rr ** 2)[::-1].rolling(21).mean()[::-1].shift(-1) * 252)
        for s_name in ("uptrend", "correction"):
            msk = st["state"] == s_name
            print(f"    in '{s_name}': next-21 NIFTY return {fwd21[msk].mean() * 100:+.2f}%, "
                  f"next-21 realised vol {fv21[msk].mean() * 100:.1f}% ({int(msk.sum())} sessions)")
        rows.append({"study": "C", "group": f"market model {thr:.3f}", "n": n_sell,
                     "sharpe": sh_s, "sharpe_bh": sh_b, "p_placebo": p_val, "maxdd": dd_s,
                     "maxdd_bh": dd_b, "in_market": float(pos.mean())})
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
