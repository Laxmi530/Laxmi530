"""
Does the DFA volatility-memory exponent improve HAR-RV's variance forecast?

Section 56 left one question open. The book's DFA exponent on |returns| (a
measure of how slowly volatility shocks decay) survived, barely, as a
predictor of next month's drawdown beyond other risk measures. The app's
downside numbers come from HAR-RV, which already models volatility
persistence at day/week/month scales. So the question that decides whether
the exponent belongs in the product is narrow: given HAR-RV's own forecast
of the next 21 sessions' variance, does alpha add anything?

Pre-specified
-------------
- 100 most liquid names, survivorship-free, 2018-01-01 .. 2024-06-30
  (before the reserved period); an origin every 21 sessions once 500
  sessions of history exist.
- At each origin, per name: HAR-RV fitted exactly as the app does
  (``HAR_RV_model.fit_har`` on log r^2 over the trailing 1,000 sessions,
  ``forecast_har_variance`` summed over 21 steps) -> V_har; alpha = DFA of
  |returns| over the trailing 250 sessions; realised V = sum of r^2 over
  the next 21 sessions.
- Two recalibrations of log V on the data of EARLIER origins only (all
  names pooled, expanding window): baseline log V ~ 1 + log V_har;
  augmented log V ~ 1 + log V_har + alpha. Both carry an intercept and a
  slope on the HAR forecast, so any gain cannot come from fixing HAR's level.
- Loss: QLIKE, V/V_hat - log(V/V_hat) - 1, the robust loss for variance
  forecasts (Patton 2011). Diebold-Mariano on the per-origin mean loss
  difference. Bar: augmented better with t > 2.

Run::

    python tests/validation/run_har_dfa.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import HAR_RV_model as har         # noqa: E402
import long_memory as lm           # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 100
H, STEP, WARM, FITWIN, DFAWIN = 21, 21, 500, 1000, 250
LAGS = (1, 5, 22)
EPS = 1e-12
OUT = os.path.join(_HERE, "har_dfa.csv")


def qlike(v, vhat):
    q = v / vhat
    return q - np.log(q) - 1.0


def main():
    print("=" * 78)
    print("DOES DFA alpha IMPROVE HAR-RV's 21-DAY VARIANCE FORECAST?  (README §56)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close",
                           aggfunc="last").sort_index()
    R = np.log(px / px.shift(1))

    recs = []
    for k, i in enumerate(range(WARM, len(px) - H, STEP)):
        for sym in px.columns:
            past = R[sym].iloc[max(0, i - FITWIN) + 1:i + 1].dropna().to_numpy()
            fut = R[sym].iloc[i + 1:i + 1 + H].to_numpy()
            if len(past) < WARM - 10 or np.isnan(fut).any():
                continue
            log_rv = np.log(past ** 2 + EPS)
            coef, _ = har.fit_har(log_rv, LAGS)
            v_har = float(har.forecast_har_variance(log_rv, coef, LAGS, H).sum())
            alpha = lm.dfa(past[-DFAWIN:], abs_input=True)["alpha"]
            v = float(np.sum(fut ** 2))
            if v <= 0 or v_har <= 0 or not np.isfinite(alpha):
                continue
            recs.append({"origin": k, "date": px.index[i], "symbol": sym,
                         "log_v": np.log(v), "log_vhar": np.log(v_har), "alpha": alpha, "v": v})
    d = pd.DataFrame(recs)
    print(f"\n  {d.origin.nunique()} origins, {d.symbol.nunique()} names, {len(d):,} forecasts")

    # Expanding-window, out-of-sample recalibration on earlier origins only.
    rows = []
    for k in sorted(d.origin.unique()):
        train, test = d[d.origin < k], d[d.origin == k]
        if train.origin.nunique() < 12 or test.empty:
            continue
        out = {"origin": k, "n": len(test)}
        for name, cols in (("base", ["log_vhar"]), ("aug", ["log_vhar", "alpha"])):
            A = np.column_stack([np.ones(len(train))] + [train[c] for c in cols])
            b, *_ = np.linalg.lstsq(A, train["log_v"].to_numpy(), rcond=None)
            resid = train["log_v"].to_numpy() - A @ b
            # Back to a variance level with the data's own log-to-level offset.
            c = float(np.log(np.mean(np.exp(resid))))
            At = np.column_stack([np.ones(len(test))] + [test[c2] for c2 in cols])
            vhat = np.exp(At @ b + c)
            out[f"qlike_{name}"] = float(np.mean(qlike(test["v"].to_numpy(), vhat)))
            if name == "aug":
                out["alpha_coef"] = float(b[-1])
        out["qlike_har_raw"] = float(np.mean(qlike(test["v"].to_numpy(), np.exp(test["log_vhar"]))))
        rows.append(out)
    r = pd.DataFrame(rows)
    r.to_csv(OUT, index=False)
    diff = r["qlike_base"] - r["qlike_aug"]                    # > 0: alpha helps
    fm = sm.fama_macbeth_ic(diff, lags=1)
    print(f"  {len(r)} out-of-sample origins (expanding window, at least 12 to train)")
    print(f"\n  mean QLIKE   HAR as forecast {r.qlike_har_raw.mean():.4f}   "
          f"recalibrated HAR {r.qlike_base.mean():.4f}   + DFA alpha {r.qlike_aug.mean():.4f}")
    print(f"  improvement from alpha: {diff.mean():+.5f} per forecast "
          f"({100 * diff.mean() / r.qlike_base.mean():+.2f}%), DM t {fm['t_stat']:+.2f}; "
          f"better on {(diff > 0).mean():.0%} of origins")
    print(f"  alpha's coefficient across fits: median {r.alpha_coef.median():+.3f} "
          f"(range {r.alpha_coef.min():+.3f} .. {r.alpha_coef.max():+.3f})")
    verdict = "ADDS to HAR-RV" if fm["t_stat"] > 2 and diff.mean() > 0 else "does not add to HAR-RV"
    print(f"\n  verdict (bar: t > 2): DFA alpha {verdict}")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
