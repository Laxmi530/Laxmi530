"""
Does the regime-novelty gate measure the regime, or the price level?

``autoencoder_regime.feature_windows`` built its windows from all nine columns
of ``compute_price_features``, and column 0 is the raw adjusted close. The AE
is standardised on the earliest 70% of windows, so for any stock that has
trended, the most recent windows carry a price far outside the fit range and
reconstruct badly for that reason alone. README §25 called the inputs
"scale-free"; eight of the nine columns are, the price is not.

This driver fits the AE on NSE names with and without the price column and
reports, over the held-out score block (the most recent 10% of windows, never
seen in fitting or in the reference), the share flagged 'unusual' (> 95th
percentile of the reference errors) and 'unprecedented' (> 99.5th). With no
regime change, about 5% and 0.5% are expected; what the price column adds is
the excess. 2019-01-01 .. 2024-06-30, before the reserved period.

Run::

    python tests/validation/run_novelty_price_level.py
"""

import os
import sys
import warnings

import pandas as pd

warnings.filterwarnings("ignore")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import autoencoder_regime as ar             # noqa: E402
import bhavcopy as bc                       # noqa: E402

SYMBOLS = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC", "TITAN", "BAJFINANCE", "SBIN")
OUT = os.path.join(_HERE, "novelty_price_level.csv")


def main():
    print("=" * 78)
    print("REGIME NOVELTY: with vs without the raw price column  (README §25)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel("2019-01-01", "2024-06-30", n=60, verbose=False)
    rows = []
    print(f"\n  {'symbol':<11}{'price x':>8}  {'with price: unusual / unpreced.':>32}"
          f"  {'without: unusual / unpreced.':>30}")
    for sym in SYMBOLS:
        d = panel[panel.symbol == sym].sort_values("datetime")
        if d.empty:
            continue
        d = d[["datetime", "adj_close"]].reset_index(drop=True)
        growth = float(d.adj_close.iloc[-1] / d.adj_close.iloc[0])
        res = {"symbol": sym, "price_growth": growth}
        for label, cols in (("with", ar.ALL_COLUMNS), ("without", ar.SCALE_FREE_COLUMNS)):
            b = ar.fit_regime_autoencoder(d, window=20, columns=cols)
            s = ar.novelty_series(b)
            res[f"{label}_unusual"] = float((s.percentile > 0.95).mean())
            res[f"{label}_unprecedented"] = float((s.percentile > 0.995).mean())
        rows.append(res)
        print(f"  {sym:<11}{growth:8.2f}  {res['with_unusual']:>20.0%} / "
              f"{res['with_unprecedented']:<9.0%}  {res['without_unusual']:>18.0%} / "
              f"{res['without_unprecedented']:.0%}", flush=True)
    t = pd.DataFrame(rows)
    t.to_csv(OUT, index=False)
    print(f"\n  medians: with price {t.with_unusual.median():.0%} / {t.with_unprecedented.median():.0%}"
          f"   without {t.without_unusual.median():.0%} / {t.without_unprecedented.median():.0%}"
          "   (no-change expectation ~5% / ~0.5%)")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
