"""
Does Monte Carlo noise matter for the app's cone, and would variance
reduction help?

Hilpisch, *Python for Finance*, Ch. 12, "Variance Reduction", shows two
standard tricks on the MEAN of a simulated sample: antithetic variates (use
z and -z) and moment matching (rescale the draws to mean 0, sd 1 exactly).
The app reads QUANTILES off its simulated paths, the 2.5th and 97.5th
percentiles of ``model_utils.simulate_price_paths`` at N_SIMS = 5,000, so the
useful question is different: how much does the band edge move between
seeds, relative to the band itself, and would either trick shrink that?

Measured on standard-normal draws (the band edge in units of the
half-width, 1.96 sigma) and on Student-t(4) draws rescaled to unit variance,
which is closer to a daily equity return. 2,000 repetitions per cell.

Run::

    python tests/validation/run_mc_variance_reduction.py
"""

import sys

import numpy as np

N_SIMS = (1000, 5000, 20000)
REPS = 2000
Q = 0.025


def draws(rng, n, dist, method):
    """n standardised draws by plain MC, antithetic variates or moment matching."""
    def base(k):
        if dist == "normal":
            return rng.standard_normal(k)
        x = rng.standard_t(4, k)
        return x / np.sqrt(2.0)                      # t(4) has variance 2
    if method == "plain":
        return base(n)
    if method == "antithetic":
        z = base(n // 2)
        return np.concatenate([z, -z])
    z = base(n)                                      # moment matching
    return (z - z.mean()) / z.std()


def main():
    print("=" * 78)
    print("MONTE CARLO NOISE IN THE CONE'S EDGE  (Hilpisch, Python for Finance, Ch. 12)")
    print("=" * 78)
    print(f"\n  sd of the {Q:.1%} quantile across {REPS} seeds, as a % of the band "
          "half-width\n")
    print(f"  {'distribution':<14}{'paths':>7}{'plain':>9}{'antithetic':>12}"
          f"{'moment-matched':>16}")
    rng = np.random.default_rng(0)
    for dist in ("normal", "t(4)"):
        for n in N_SIMS:
            out = {}
            for method in ("plain", "antithetic", "moment"):
                q = np.array([np.quantile(draws(rng, n, dist, method), Q)
                              for _ in range(REPS)])
                # Half-width of the 95% band for this distribution.
                ref = np.quantile(draws(np.random.default_rng(1), 2_000_000, dist,
                                        "plain"), [Q, 1 - Q])
                out[method] = 100 * q.std() / ((ref[1] - ref[0]) / 2)
            print(f"  {dist:<14}{n:7d}{out['plain']:8.2f}%{out['antithetic']:11.2f}%"
                  f"{out['moment']:15.2f}%")
    print("\n  At the app's 5,000 paths the edge moves by about 2% of the half-width")
    print("  between seeds, and the seed is fixed (42), so a given forecast is")
    print("  reproducible. Compare with the coverage error the calibration")
    print("  harness measures, which is a property of the model, not of sampling.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
