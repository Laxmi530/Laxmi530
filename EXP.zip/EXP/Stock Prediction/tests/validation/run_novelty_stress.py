"""
The regime-novelty gate in a real crash: does it flag March 2020, stay quiet
in calm years, and know anything a plain volatility reading does not?

README §25 built the gate (``autoencoder_regime.regime_novelty``: a denoising
autoencoder's reconstruction error on the latest 20-session window, as a
percentile of a held-out reference block; above the 99.5th the app withholds
every directional call) and left its test open: on calm data it should almost
never fire, and its value can only show on a regime break. §59 measured the
calm side on eight names: 13% of recent windows "unusual" and 5%
"unprecedented", against 5% and 0.5% by design.

Pre-registered, on the 20 most liquid names of the survivorship-free bhavcopy
panel (screened on 2017-01..2017-07), sessions 2017-07-03 .. 2024-12-31:

* At each quarter end from 2019-06-30 to 2024-09-30 the AE is fitted as the
  app fits it, on all of that name's history to date, and every session of
  the next quarter is scored with that fit (the features are backward-
  looking, so a window scored from the full series equals one scored from a
  series cut at that session; checked below). The app refits per request, so
  this is the app with a fit up to three months old.
* Flag rates, "unusual" (> 95th percentile of the reference errors) and
  "unprecedented" (> 99.5th), by period: 2019-07..2020-01, the crash
  (2020-02-15 .. 2020-05-31), 2020-06..2021-12, 2022, 2023-2024.
* Timing: the weekly share of names flagged through Jan-May 2020, against the
  equal-weight panel's drawdown.
* Control: the same percentile rule applied to a plain statistic, the sd of
  the window's last 20 returns, against the same reference block. If the
  control does what the AE does, the AE adds nothing.
* Information: the static 95% band's miss rate at h = 5 (the rule in
  ``run_aci_bands.py``) on flagged vs unflagged sessions, for each detector
  and for each combination of the two.
* Keep the gate as it is if the calm-period "unprecedented" rate is at most
  1.5% and at least half of the names are flagged at some point in the crash
  window; otherwise it needs a fix, and any fix is tuned on 2019-07 .. 2021-12
  and checked on 2022-2024.

Run::

    python tests/validation/run_novelty_stress.py
"""

import os
import sys
import time
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import autoencoder_regime as ar             # noqa: E402
import bhavcopy as bc                       # noqa: E402
import run_aci_bands as acib                # noqa: E402

START, END = "2017-07-03", "2024-12-31"
N = 20
FIT_DATES = pd.date_range("2019-06-30", "2024-09-30", freq="QE")
PERIODS = [
    ("2019-07..2020-01", "2019-07-01", "2020-02-14"),
    ("crash 2020", "2020-02-15", "2020-05-31"),
    ("2020-06..2021", "2020-06-01", "2021-12-31"),
    ("2022", "2022-01-01", "2022-12-31"),
    ("2023-2024", "2023-01-01", "2024-12-31"),
]
CALM = ("2019-07..2020-01", "2020-06..2021", "2022", "2023-2024")
H = 5
OUT_SCORES = os.path.join(_HERE, "novelty_stress_scores.csv")
OUT = os.path.join(_HERE, "novelty_stress.csv")


def ref_stamps(df_fit, bundle):
    """End dates of the reference-block windows, rebuilt as fit_regime_autoencoder splits them."""
    X, stamps, _ = ar.feature_windows(df_fit, window=bundle["window"], columns=bundle["columns"])
    n = len(X)
    n_fit = int(n * ar._FIT_FRAC)
    n_ref = max(20, int(n * ar._REF_FRAC))
    n_fit = min(n_fit, n - n_ref - 5)
    s = stamps[n_fit:n_fit + n_ref]
    assert len(s) == len(bundle["ref_errors"]), (len(s), len(bundle["ref_errors"]))
    return pd.to_datetime(s)


def score_name(sym, d):
    """Daily AE and control percentiles for one name, refitting each quarter."""
    d = d[["datetime", "adj_close"]].sort_values("datetime").reset_index(drop=True)
    X_all, st_all, _ = ar.feature_windows(d)
    st_all = pd.to_datetime(st_all)
    logp = np.log(d["adj_close"].to_numpy(float))
    r = pd.Series(np.r_[np.nan, np.diff(logp)], index=pd.to_datetime(d["datetime"]))
    vol20 = r.rolling(20).std()
    rows, checked = [], False
    for q in FIT_DATES:
        nxt = q + pd.offsets.QuarterEnd(1)
        df_fit = d[d.datetime <= q]
        b = ar.fit_regime_autoencoder(df_fit)
        if b is None:
            continue
        sel = (st_all > q) & (st_all <= nxt)
        if not sel.any():
            continue
        Z = (X_all[sel] - b["mu"]) / b["sd"]
        err = ar.reconstruction_error(b["autoencoder"], Z)
        ref = np.sort(np.asarray(b["ref_errors"], float))
        pct = np.searchsorted(ref, err, side="right") / len(ref)       # mean(ref <= err)
        rs = ref_stamps(df_fit, b)
        ref_v = np.sort(vol20.reindex(rs).dropna().to_numpy())
        cur_v = vol20.reindex(st_all[sel]).to_numpy()
        vpct = np.searchsorted(ref_v, cur_v, side="right") / len(ref_v)
        if not checked:                      # the full-series score equals the app's cut-series score
            t = st_all[sel][0]
            app = ar.regime_novelty(d[d.datetime <= t], bundle=b)
            assert abs(app["error"] - err[0]) <= 1e-4 * max(1.0, err[0]), (app["error"], err[0])
            checked = True
        rows.append(pd.DataFrame({"symbol": sym, "origin": st_all[sel], "fit_date": q,
                                  "fit_rows": len(df_fit), "ae_pct": pct, "vol_pct": vpct,
                                  "ae_err": err, "vol20": cur_v}))
    return pd.concat(rows, ignore_index=True) if rows else None


def rates(df, col):
    return float((df[col] > ar._UNUSUAL_PCT).mean()), float((df[col] > ar._UNPRECEDENTED_PCT).mean())


def main():
    print("=" * 78)
    print("REGIME NOVELTY IN A REAL CRASH  (README section 25, the open test)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, rep = bc.build_panel(START, END, n=N, lookback_days=acib.LOOKBACK_DAYS,
                                min_days=acib.MIN_DAYS, verbose=False)
    print(f"  {rep['n_symbols']} names; AE refitted at {len(FIT_DATES)} quarter ends "
          f"{FIT_DATES[0].date()} .. {FIT_DATES[-1].date()}")

    parts, t0 = [], time.time()
    for i, (s, g) in enumerate(panel.groupby("symbol")):
        if g["datetime"].min() > pd.Timestamp("2018-01-31"):
            print(f"  {s}: listed after 2018-01, skipped (too little history for the 2019 fits)")
            continue
        w = score_name(s, g)
        if w is not None:
            parts.append(w)
            pd.concat(parts, ignore_index=True).to_csv(OUT_SCORES, index=False)
        print(f"  [{i + 1}/{panel.symbol.nunique()}] {s}: {0 if w is None else len(w)} sessions scored "
              f"({(time.time() - t0) / 60:.0f} min)", flush=True)
    S = pd.concat(parts, ignore_index=True)

    # Static band misses at h = 5 for the same names and sessions.
    miss = []
    for s, g in panel.groupby("symbol"):
        g = g.sort_values("datetime")
        p = g["adj_close"].to_numpy(float)
        w = acib.name_windows(g["datetime"].to_numpy(), np.log(p), H, None)
        if w is not None:
            miss.append(pd.DataFrame({"symbol": s, "origin": pd.to_datetime(w.origin),
                                      "miss": (w.score > w.static).to_numpy()}))
    S = S.merge(pd.concat(miss), on=["symbol", "origin"], how="left")

    rows = []
    print(f"\n1. FLAG RATES  (by design ~5% unusual, ~0.5% unprecedented when nothing has changed)")
    print(f"  {'period':<19}{'sessions':>9}   {'AE unusual':>10}{'unpreced.':>10}   "
          f"{'vol unusual':>11}{'unpreced.':>10}   {'band miss h=5':>13}")
    for lab, a, b in PERIODS:
        part = S[(S.origin >= a) & (S.origin <= b)]
        au, ap = rates(part, "ae_pct")
        vu, vp = rates(part, "vol_pct")
        mr = float(part["miss"].mean())
        rows.append({"section": "rates", "period": lab, "n": len(part), "ae_unusual": au,
                     "ae_unprecedented": ap, "vol_unusual": vu, "vol_unprecedented": vp, "band_miss": mr})
        print(f"  {lab:<19}{len(part):>9,d}   {au:>10.1%}{ap:>10.1%}   {vu:>11.1%}{vp:>10.1%}   {mr:>13.1%}")
    calm = S[np.any([(S.origin >= a) & (S.origin <= b) for lab, a, b in PERIODS if lab in CALM], axis=0)]
    au, ap = rates(calm, "ae_pct")
    print(f"  {'all calm periods':<19}{len(calm):>9,d}   {au:>10.1%}{ap:>10.1%}")

    print("\n2. THE CRASH, WEEK BY WEEK  (share of names flagged; panel = equal-weight drawdown from 2020-01-14)")
    ew = (panel.pivot_table(index="datetime", columns="symbol", values="adj_close")
          .pct_change().mean(axis=1).fillna(0).add(1).cumprod())
    ew = ew / ew.loc[:"2020-01-14"].iloc[-1] - 1
    crash = S[(S.origin >= "2020-01-01") & (S.origin <= "2020-05-31")].copy()
    crash["week"] = crash.origin.dt.to_period("W-FRI")
    print(f"  {'week to':<12}{'panel':>8}   {'AE unusual':>10}{'unpreced.':>10}   {'vol unusual':>11}{'unpreced.':>10}")
    for wk, part in crash.groupby("week"):
        last = part.origin.max()
        dd = float(ew.loc[:last].iloc[-1])
        f = part.groupby("symbol")[["ae_pct", "vol_pct"]].max()
        vals = [(f.ae_pct > ar._UNUSUAL_PCT).mean(), (f.ae_pct > ar._UNPRECEDENTED_PCT).mean(),
                (f.vol_pct > ar._UNUSUAL_PCT).mean(), (f.vol_pct > ar._UNPRECEDENTED_PCT).mean()]
        rows.append({"section": "crash_week", "period": str(last.date()), "panel_drawdown": dd,
                     "ae_unusual": vals[0], "ae_unprecedented": vals[1],
                     "vol_unusual": vals[2], "vol_unprecedented": vals[3]})
        print(f"  {str(last.date()):<12}{dd:>8.1%}   {vals[0]:>10.0%}{vals[1]:>10.0%}   {vals[2]:>11.0%}{vals[3]:>10.0%}")
    win = S[(S.origin >= "2020-02-15") & (S.origin <= "2020-05-31")]
    any_ae = float((win.groupby("symbol").ae_pct.max() > ar._UNPRECEDENTED_PCT).mean())
    any_v = float((win.groupby("symbol").vol_pct.max() > ar._UNPRECEDENTED_PCT).mean())
    print(f"  names flagged 'unprecedented' at least once in the crash window: AE {any_ae:.0%}, vol {any_v:.0%}")

    print(f"\n3. DOES A FLAG MEAN THE BAND WILL MISS?  static 95% band, h = {H}, all sessions")
    S["ae_flag"] = S.ae_pct > ar._UNUSUAL_PCT
    S["vol_flag"] = S.vol_pct > ar._UNUSUAL_PCT
    print(f"  {'AE flag':<9}{'vol flag':<10}{'sessions':>10}{'miss rate':>11}")
    for (af, vf), part in S.dropna(subset=["miss"]).groupby(["ae_flag", "vol_flag"]):
        rows.append({"section": "info", "period": f"ae={af} vol={vf}", "n": len(part),
                     "band_miss": float(part.miss.mean())})
        print(f"  {str(af):<9}{str(vf):<10}{len(part):>10,d}{part.miss.mean():>11.1%}")
    print(f"  sessions by fit-history length (calm periods): " + ", ".join(
        f"{lo}-{hi} rows: AE unprecedented {rates(calm[(calm.fit_rows >= lo) & (calm.fit_rows < hi)], 'ae_pct')[1]:.1%}"
        for lo, hi in ((0, 750), (750, 1250), (1250, 9999))
        if ((calm.fit_rows >= lo) & (calm.fit_rows < hi)).any()))

    ok_calm = ap <= 0.015
    ok_crash = any_ae >= 0.5
    print("\nDECISION (pre-registered):")
    print(f"  calm 'unprecedented' rate {ap:.1%} <= 1.5%: {'PASS' if ok_calm else 'FAIL'}")
    print(f"  names flagged in the crash {any_ae:.0%} >= 50%: {'PASS' if ok_crash else 'FAIL'}")
    print(f"  => {'KEEP THE GATE AS IT IS' if ok_calm and ok_crash else 'THE GATE NEEDS A FIX'}")
    rows.append({"section": "decision", "period": "calm", "ae_unusual": au, "ae_unprecedented": ap,
                 "crash_names_ae": any_ae, "crash_names_vol": any_v})
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}\n  wrote {OUT_SCORES}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
