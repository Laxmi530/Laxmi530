"""
HAR-RV's shipped adaptive cone (ACI, gamma 0.05) against its static cone, at
scale.

``run_aci_bands.py`` found that ACI with gamma 0.05 under-covers when the
calibration windows overlap (h-session windows from consecutive origins: one
shock is h misses in a row, and the level over-reacts): 92.1% at h = 5 and
90.3% at h = 10. HAR-RV runs that ACI by default (README §12), on standardised
residuals from up to 80 origins strided across the last 30% of history. With
the app's full histories (decades for most large caps) the stride is about 27
sessions and nothing overlaps, and the earlier A/B (§12: 3 names, 18 origins)
was a tie. With a few years of history the stride is a few sessions and the
windows overlap. This tests that case at scale; the long-history case cannot
be run offline, because the bhavcopy cache starts in 2017.

Pre-registered, on the 60 most liquid names of the survivorship-free panel
(screened on 2017-01..2017-07), history from 2017-07-03, before the reserved
period:

* Origins every 10th session from 2019-01-01 to 2024-12-31. At each,
  ``run_har_rv_prediction(history to the origin, 'daily', 10)`` with
  ``adaptive=True`` (shipped) and ``adaptive=False``; covered when the price h
  sessions later lies inside the band, h = 1, 5, 10.
* Metrics as in ``run_aci_bands.py``: coverage, width, and CC (mean over the
  five volatility-shift quintiles of ``|coverage - 0.95|``, edges fixed on
  2019-2021), on 2019-2021 and 2022-2024, with a block bootstrap over calendar
  months (2,000 draws).
* Keep ACI as the default unless, on 2022-2024 at h = 5, static is better:
  overall ``|coverage - 0.95|`` smaller by more than 0.5 points, or CC lower
  with the interval excluding zero. If so, the fix is the one the overlap
  argument implies, not a tuned one: ACI only when the calibration origins are
  at least ``horizon`` sessions apart, static otherwise.

Run::

    python tests/validation/run_har_aci_scale.py
"""

import concurrent.futures as cf
import contextlib
import io
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                       # noqa: E402
import run_aci_bands as acib                # noqa: E402

START, END = "2017-07-03", "2024-12-31"
N = 60
STEP = 10
H_MAX = 10
HS = (1, 5, 10)
FIRST, SELECT_END, CONFIRM_FROM = (pd.Timestamp("2019-01-01"), pd.Timestamp("2021-12-31"),
                                   pd.Timestamp("2022-01-01"))
OUT = os.path.join(_HERE, "har_aci_scale.csv")
OUT_ROWS = os.path.join(_HERE, "har_aci_scale_rows.csv")
WORKERS = 6


def one_name(args):
    sym, d = args
    from HAR_RV_model import run_har_rv_prediction
    d = d.sort_values("datetime").reset_index(drop=True)
    p = d["adj_close"].to_numpy(float)
    logp = np.log(p)
    r1 = np.diff(logp)
    dates = pd.to_datetime(d["datetime"])
    idx = np.where((dates >= FIRST).to_numpy())[0]
    idx = idx[(idx < len(d) - H_MAX) & (idx >= acib.M + H_MAX + 20)][::STEP]
    rows = []
    for t in idx:
        hist = d.iloc[:t + 1][["datetime", "open", "high", "low", "close", "adj_close"]]
        out = {}
        for arm, adaptive in (("aci", True), ("static", False)):
            with contextlib.redirect_stdout(io.StringIO()):
                fc = run_har_rv_prediction(hist, "daily", H_MAX, adaptive=adaptive)
            out[arm] = fc
        rv = r1[t - 20:t]
        for h in HS:
            span = acib.M + h - 1
            lv = r1[t - span:t]
            rec = {"symbol": sym, "origin": dates[t], "h": h,
                   "shift": float(np.std(rv, ddof=1) / np.std(lv, ddof=1)),
                   "actual": p[t + h], "last": p[t]}
            for arm, fc in out.items():
                lo, up = float(fc["lower_bound"].iloc[h - 1]), float(fc["upper_bound"].iloc[h - 1])
                rec[f"{arm}_cov"] = bool(lo <= p[t + h] <= up)
                rec[f"{arm}_width"] = (up - lo) / p[t] * 100
            rows.append(rec)
    return rows


def cc(cov, q):
    per = [cov[q == i].mean() for i in range(5) if (q == i).any()]
    return float(np.mean(np.abs(np.array(per) - 0.95)))


def boot(part, q, rng, n_boot=2000):
    month = part["origin"].dt.to_period("M").astype(str).to_numpy()
    months, inv = np.unique(month, return_inverse=True)
    Sa = np.zeros((len(months), 5)); Ss = np.zeros((len(months), 5)); C = np.zeros((len(months), 5))
    np.add.at(Sa, (inv, q), part["aci_cov"].to_numpy(float))
    np.add.at(Ss, (inv, q), part["static_cov"].to_numpy(float))
    np.add.at(C, (inv, q), 1.0)
    d = np.empty(n_boot)
    for b in range(n_boot):
        w = np.bincount(rng.integers(0, len(months), len(months)), minlength=len(months))
        c = w @ C
        d[b] = np.abs((w @ Ss) / c - 0.95).mean() - np.abs((w @ Sa) / c - 0.95).mean()
    return float(np.quantile(d, 0.025)), float(np.quantile(d, 0.975))   # static - aci


def main():
    print("=" * 78)
    print("HAR-RV: SHIPPED ACI CONE vs STATIC, AT SCALE  (README sections 12 and 71)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, rep = bc.build_panel(START, END, n=N, lookback_days=acib.LOOKBACK_DAYS,
                                min_days=acib.MIN_DAYS, verbose=False)
    jobs = [(s, g) for s, g in panel.groupby("symbol") if len(g) > 600]
    print(f"  {len(jobs)} names; origins every {STEP} sessions from {FIRST.date()}", flush=True)
    rows = []
    with cf.ProcessPoolExecutor(WORKERS) as ex:
        for k, res in enumerate(ex.map(one_name, jobs), 1):
            rows.extend(res)
            if k % 10 == 0:
                print(f"  {k}/{len(jobs)} names done", flush=True)
    R = pd.DataFrame(rows)
    R.to_csv(OUT_ROWS, index=False)

    rng = np.random.default_rng(20261021)
    out = []
    print(f"\n  {'h':>3} {'period':<9}{'n':>7}   {'cover ACI':>9}{'static':>8}   {'width ACI':>9}{'static':>8}"
          f"   {'CC ACI':>7}{'static':>8}   {'q5 ACI':>7}{'static':>8}   static-ACI CC interval")
    for h in HS:
        part_h = R[R.h == h]
        edges = np.quantile(part_h[part_h.origin <= SELECT_END]["shift"], [0.2, 0.4, 0.6, 0.8])
        for lab, part in (("2019-21", part_h[part_h.origin <= SELECT_END]),
                          ("2022-24", part_h[part_h.origin >= CONFIRM_FROM])):
            q = np.digitize(part["shift"], edges)
            ca, cs = part["aci_cov"].to_numpy(float), part["static_cov"].to_numpy(float)
            lo, hi = boot(part, q, rng)
            rec = {"h": h, "period": lab, "n": len(part),
                   "cov_aci": ca.mean(), "cov_static": cs.mean(),
                   "width_aci": part["aci_width"].mean(), "width_static": part["static_width"].mean(),
                   "cc_aci": cc(ca, q), "cc_static": cc(cs, q),
                   "q5_aci": ca[q == 4].mean(), "q5_static": cs[q == 4].mean(),
                   "cc_static_minus_aci_lo": lo, "cc_static_minus_aci_hi": hi}
            out.append(rec)
            print(f"  {h:>3} {lab:<9}{len(part):>7,d}   {rec['cov_aci']:>9.1%}{rec['cov_static']:>8.1%}"
                  f"   {rec['width_aci']:>8.2f}%{rec['width_static']:>7.2f}%   {rec['cc_aci']:>7.3f}{rec['cc_static']:>8.3f}"
                  f"   {rec['q5_aci']:>7.1%}{rec['q5_static']:>8.1%}   [{lo:+.4f}, {hi:+.4f}]")
    T = pd.DataFrame(out)
    T.to_csv(OUT, index=False)

    c = T[(T.h == 5) & (T.period == "2022-24")].iloc[0]
    worse_cov = abs(c.cov_aci - 0.95) > abs(c.cov_static - 0.95) + 0.005
    worse_cc = c.cc_static_minus_aci_hi < 0
    print("\nDECISION (2022-24, h = 5, pre-registered):")
    print(f"  overall coverage ACI {c.cov_aci:.1%} vs static {c.cov_static:.1%}: "
          f"{'static better by > 0.5 pt' if worse_cov else 'no'}")
    print(f"  CC ACI {c.cc_aci:.3f} vs static {c.cc_static:.3f}, static - ACI interval "
          f"[{c.cc_static_minus_aci_lo:+.4f}, {c.cc_static_minus_aci_hi:+.4f}]: "
          f"{'static better' if worse_cc else 'no'}")
    print(f"  => {'SWITCH: ACI only when origins are >= horizon apart' if (worse_cov or worse_cc) else 'KEEP ACI AS THE DEFAULT'}")
    print(f"\n  wrote {OUT}\n  wrote {OUT_ROWS}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
