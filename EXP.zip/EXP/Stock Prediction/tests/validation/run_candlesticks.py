"""
Do the book's five candlestick patterns predict anything on NSE?

Kanwar & Gupta, *Python for Trading on Technical*, section 5, compute five
TA-Lib patterns (Marubozu, Morning Star, Evening Star, Hammer, Inverted
Hammer) and plot where they fire on INFY 2018-20. They never test whether a
signal is followed by the move it names. This is that test, as an event
study on the survivorship-free 400-name panel.

Pre-specified
-------------
- The book's own functions, through TA-Lib (``pip install TA-Lib``; this is
  a validation-only dependency, not an app one), on corporate-action-
  adjusted OHLC (``event_backtest.adjust_ohlc``), so a split never forms a
  pattern.
- Direction is the pattern's own: TA-Lib returns +100 for a bullish signal
  and -100 for a bearish one (Marubozu can be either; Morning Star, Hammer
  and Inverted Hammer are bullish; Evening Star is bearish). Each event's
  forward return is multiplied by that sign, so a positive mean means the
  pattern was right.
- Outcome: the next 5 sessions' simple return in EXCESS of the equal-weighted
  universe over the same days (the 1-session version is reported alongside).
  Signal at the close of t, so the return starts at t.
- Statistic: the per-date mean of signed excess returns, with a Newey-West
  t-statistic at 5 lags (5-day windows overlap). Five patterns are tested,
  so the bar is Bonferroni |t| > 2.58 (alpha = 0.01 two-sided).
- 2018-01-01 .. 2024-06-30, before the reserved period.

Run::

    python tests/validation/run_candlesticks.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import event_backtest as eb        # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 400
PATTERNS = {"Marubozu": "CDLMARUBOZU", "Morning Star": "CDLMORNINGSTAR",
            "Evening Star": "CDLEVENINGSTAR", "Hammer": "CDLHAMMER",
            "Inverted Hammer": "CDLINVERTEDHAMMER"}
T_BAR = 2.58
OUT = os.path.join(_HERE, "candlesticks.csv")


def main():
    print("=" * 78)
    print("CANDLESTICK PATTERNS, EVENT STUDY  (Kanwar & Gupta, section 5)")
    print("=" * 78)
    try:
        import talib
    except ImportError:
        print("\nTA-Lib is not installed. It is the book's library and a validation-only")
        print("dependency here:  pip install TA-Lib")
        return 1
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    panel = eb.adjust_ohlc(panel)

    def wide(col):
        return panel.pivot_table(index="datetime", columns="symbol", values=col,
                                 aggfunc="last").sort_index()
    O, H, L, C = wide("open"), wide("high"), wide("low"), wide("close")
    fwd = {h: C.shift(-h) / C - 1.0 for h in (1, 5)}
    excess = {h: f.sub(f.mean(axis=1), axis=0) for h, f in fwd.items()}

    sig = {p: pd.DataFrame(0.0, index=C.index, columns=C.columns) for p in PATTERNS}
    for sym in C.columns:
        ok = C[sym].notna() & O[sym].notna() & H[sym].notna() & L[sym].notna()
        if ok.sum() < 50:
            continue
        idx = C.index[ok]
        args = [x.loc[idx, sym].to_numpy(dtype=float) for x in (O, H, L, C)]
        for p, fn in PATTERNS.items():
            kw = {"penetration": 0} if "STAR" in fn else {}
            sig[p].loc[idx, sym] = getattr(talib, fn)(*args, **kw)

    print(f"\n  {C.shape[1]} names, {len(C)} sessions; signed excess return after the pattern")
    print(f"  (positive = the pattern was right); Bonferroni bar |t| > {T_BAR}\n")
    print(f"  {'pattern':<17}{'events':>8}{'bullish':>9}{'5-day mean':>12}{'t':>7}"
          f"{'1-day mean':>12}{'t':>7}   verdict")
    rows = []
    for p in PATTERNS:
        s = np.sign(sig[p])
        n_ev = int((s != 0).sum().sum())
        bull = float((s > 0).sum().sum() / max(n_ev, 1))
        res = {}
        for h in (5, 1):
            signed = (s * excess[h]).where(s != 0)
            per_day = signed.mean(axis=1).dropna()
            fm = sm.fama_macbeth_ic(per_day, lags=h)
            res[h] = (float(per_day.mean()), fm["t_stat"])
        ok = abs(res[5][1]) > T_BAR
        verdict = ("RIGHT" if res[5][0] > 0 else "WRONG-WAY") if ok else "no effect"
        rows.append({"pattern": p, "events": n_ev, "bullish_share": bull,
                     "mean_5d": res[5][0], "t_5d": res[5][1],
                     "mean_1d": res[1][0], "t_1d": res[1][1], "verdict": verdict})
        print(f"  {p:<17}{n_ev:8d}{bull:9.0%}{res[5][0]:+12.3%}{res[5][1]:+7.2f}"
              f"{res[1][0]:+12.3%}{res[1][1]:+7.2f}   {verdict}")
    # ---------------------------------------------- 2. can it be traded?
    # Added after seeing section 1, so these are diagnostics, not tests. A
    # pattern that closes at the bar's high or low is exactly what an NSE
    # price-band (circuit) lock looks like, and a locked close cannot be
    # traded at: there is no counterparty. Three checks, each removing one way
    # the close-to-close number could be unreachable.
    prev = C.shift(1)
    move = (C / prev - 1.0).abs()
    bands = (0.02, 0.05, 0.10, 0.20)
    at_band = sum(((move - b).abs() < 0.0015) for b in bands).astype(bool)
    at_extreme = (C >= H * 0.9995) | (C <= L * 1.0005)
    locked = at_band & at_extreme
    tv = wide("turnover").rolling(60, min_periods=20).median()
    liquid = tv.ge(tv.median(axis=1), axis=0)
    fo = C.shift(-5) / O.shift(-1) - 1.0                  # enter at t+1 open
    ex_open = fo.sub(fo.mean(axis=1), axis=0)
    print("\n  2. CAN IT BE TRADED?  (diagnostics added after section 1)")
    print(f"  {'pattern':<17}{'locked share':>13}{'next-open entry':>17}{'t':>7}"
          f"{'no locked bars':>16}{'t':>7}{'liquid half':>13}{'t':>7}")
    for r in rows:
        if r["verdict"] == "no effect":
            continue
        s = np.sign(sig[r["pattern"]])
        ev = s != 0
        out = {"locked_share": float((locked & ev).sum().sum() / max(ev.sum().sum(), 1))}
        for name, ret, mask in (("open", ex_open, ev), ("unlocked", excess[5], ev & ~locked),
                                ("liquid", excess[5], ev & liquid)):
            per_day = (s * ret).where(mask).mean(axis=1).dropna()
            fm = sm.fama_macbeth_ic(per_day, lags=5)
            out[name] = (float(per_day.mean()), fm["t_stat"])
        r.update({"locked_share": out["locked_share"],
                  "mean_next_open": out["open"][0], "t_next_open": out["open"][1],
                  "mean_unlocked": out["unlocked"][0], "t_unlocked": out["unlocked"][1],
                  "mean_liquid": out["liquid"][0], "t_liquid": out["liquid"][1]})
        print(f"  {r['pattern']:<17}{out['locked_share']:13.0%}{out['open'][0]:+17.3%}"
              f"{out['open'][1]:+7.2f}{out['unlocked'][0]:+16.3%}{out['unlocked'][1]:+7.2f}"
              f"{out['liquid'][0]:+13.3%}{out['liquid'][1]:+7.2f}")

    d = sm.india_round_trip_bps("delivery")["total"]
    f = sm.india_round_trip_bps("futures")["total"]
    print(f"\n  For scale: one round trip costs {d:.1f} bp in cash delivery, {f:.1f} bp in futures.")
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
