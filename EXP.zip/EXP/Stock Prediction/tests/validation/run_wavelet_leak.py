"""
Wavelet "forecasting": how much of it is the future leaking in?

Mariani & Florescu, *Quantitative Finance*, Ch. 5, teach the discrete
wavelet transform (Haar, Daubechies) and cite wavelet forecasting as "a
viable alternative to existing methods such as ARIMA" (p. 117). The usual
recipe denoises a price series with a wavelet transform and forecasts from
the smooth. A transform of the WHOLE series makes every denoised value a
function of neighbours on both sides, so the smooth at day t already knows
day t+1.

One deliberately simple rule, run two ways on the same data:

- non-causal: denoise the whole log-price series once, then predict
  tomorrow's direction from the sign of the smooth's slope at t;
- causal: at each t, denoise only the trailing 256 log prices and read the
  slope at the last point, which is all a live forecaster could do.

Haar DWT, 4 levels, cycle-spun (translation-invariant), soft universal threshold (Donoho & Johnstone:
lambda = sigma * sqrt(2 ln n), sigma = MAD(finest details) / 0.6745). 20
liquid NSE names, 2018-01-01 .. 2024-06-30, before the reserved period.
Scored by directional hit rate, and its t against 50% (binomial).

Run::

    python tests/validation/run_wavelet_leak.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 20
LEVELS, CAUSAL_WIN = 4, 256
OUT = os.path.join(_HERE, "wavelet_leak.csv")


def haar_denoise(x, levels=LEVELS):
    """Haar DWT, soft universal threshold on the details, inverse DWT."""
    x = np.asarray(x, dtype=np.float64)
    n0 = len(x)
    size = 1 << int(np.ceil(np.log2(max(n0, 2))))
    a = np.concatenate([x, x[::-1][: size - n0]]) if size > n0 else x.copy()  # symmetric pad
    details = []
    for _ in range(levels):
        if len(a) < 2:
            break
        even, odd = a[0::2], a[1::2]
        details.append((even - odd) / np.sqrt(2.0))
        a = (even + odd) / np.sqrt(2.0)
    sigma = np.median(np.abs(details[0])) / 0.6745 if details else 0.0
    lam = sigma * np.sqrt(2.0 * np.log(size))
    for k, d in enumerate(details):
        details[k] = np.sign(d) * np.maximum(np.abs(d) - lam, 0.0)
    for d in reversed(details):
        out = np.empty(2 * len(a))
        out[0::2] = (a + d) / np.sqrt(2.0)
        out[1::2] = (a - d) / np.sqrt(2.0)
        a = out
    return a[:n0]


def spin_denoise(x, levels=LEVELS):
    """
    Translation-invariant Haar denoising (cycle spinning; Coifman & Donoho
    1995): average the denoised series over all 2**levels circular shifts.

    Plain thresholded Haar reconstructs a staircase that is flat inside each
    16-day block, so its slope is exactly zero on most days. A first version
    of this driver scored those zeros as misses and reported hit rates of 2%
    and 14% -- an artefact of the test, not a result. Cycle spinning removes
    the staircase. Each shift still sees only the data it is given, so the
    causal version stays causal.
    """
    x = np.asarray(x, dtype=np.float64)
    k = 1 << levels
    acc = np.zeros_like(x)
    for s in range(k):
        acc += np.roll(haar_denoise(np.roll(x, -s), levels), s)
    return acc / k


def main():
    print("=" * 78)
    print("WAVELET FORECASTING: NON-CAUSAL vs CAUSAL  (Mariani & Florescu, Ch. 5)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close",
                           aggfunc="last").sort_index()
    rows = []
    for sym in px.columns:
        lp = np.log(px[sym].dropna().to_numpy())
        if len(lp) < CAUSAL_WIN + 200:
            continue
        nxt = np.sign(np.diff(lp))                       # nxt[t] = sign(lp[t+1] - lp[t])
        full = spin_denoise(lp)
        # Non-causal: the smooth's slope from t-1 to t, used to call t -> t+1.
        nc = np.sign(full[1:-1] - full[:-2])
        a, b = nc[CAUSAL_WIN:], nxt[1:][CAUSAL_WIN:]
        m = (a != 0) & (b != 0)                          # score only real calls
        hit_nc = np.mean(a[m] == b[m])
        cz = []
        for t in range(CAUSAL_WIN, len(lp) - 1):
            s = spin_denoise(lp[t - CAUSAL_WIN + 1:t + 1])
            cz.append(np.sign(s[-1] - s[-2]))
        cz = np.array(cz)
        b = nxt[CAUSAL_WIN:len(lp) - 1]
        m = (cz != 0) & (b != 0)
        hit_c = np.mean(cz[m] == b[m])
        n = int(m.sum())
        rows.append({"symbol": sym, "n": n, "hit_noncausal": float(hit_nc),
                     "hit_causal": float(hit_c)})
    r = pd.DataFrame(rows)
    r.to_csv(OUT, index=False)
    n_total = int(r.n.sum())
    for k, label in (("hit_noncausal", "non-causal (whole-series transform)"),
                     ("hit_causal", "causal (trailing 256 days only)")):
        p = float((r[k] * r.n).sum() / n_total)
        t = (p - 0.5) / np.sqrt(0.25 / n_total)
        print(f"  {label:<38} hit rate {p:6.1%}   t vs 50% {t:+7.2f}   "
              f"(names {r[k].min():.0%} .. {r[k].max():.0%})")
    print(f"\n  {len(r)} names, {n_total:,} forecasts. The same rule, the same data; the only")
    print("  difference is whether the denoised value at t was allowed to see t+1.")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
