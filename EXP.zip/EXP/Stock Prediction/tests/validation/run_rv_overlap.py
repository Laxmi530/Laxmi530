"""
How much of a volatility forecast's score is the target overlapping its input?

Karasan, *Machine Learning for Financial Risk Management with Python*, Ch. 4,
scores SVR-GARCH on 5-day rolling realised volatility one day ahead. That
target shares 4 of its 5 days with the same-day realised volatility the model
takes as a feature, so a model that merely copies its input scores well.

This driver measures that on NSE large caps with no model at all: "tomorrow =
today" against the overlapping target, the same forecast against the next
DISJOINT 5 days, and a constant (the training-period mean) as the floor.
Window ends 2024-06-30, before the reserved final test period.

Run::

    python tests/validation/run_rv_overlap.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 50
SYMBOLS = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC")
WIN, TEST = 5, 252


def scores(close):
    """RMSE (decimal vol) of persistence on overlapping and disjoint targets."""
    ret = 100 * close.pct_change().dropna()
    rv = ret.rolling(WIN).std().dropna()
    nxt = rv.shift(-1)                          # tomorrow's 5-day RV: overlaps
    dis = ret.rolling(WIN).std().shift(-WIN)    # the next 5 days: disjoint
    a = pd.concat([rv, nxt, dis], axis=1, keys=["now", "nxt", "dis"],
                  sort=True).dropna().iloc[-TEST:] / 100
    const = rv.loc[:a.index[0]].iloc[:-1].mean() / 100
    rmse = lambda y, f: float(np.sqrt(np.mean((y - f) ** 2)))
    return {"mean_rv": float(a["now"].mean()),
            "persist_overlap": rmse(a["nxt"], a["now"]),
            "persist_disjoint": rmse(a["dis"], a["now"]),
            "constant_disjoint": rmse(a["dis"], const)}


def main():
    print("=" * 78)
    print("OVERLAPPING VOLATILITY TARGETS  (Karasan, ML for Financial Risk Mgmt, Ch. 4)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=N, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    print(f"\n  last {TEST} days of {START}..{END}; RMSE in decimal volatility\n")
    print(f"  {'symbol':<10}{'mean RV':>9}{'persist, overlap':>18}"
          f"{'persist, disjoint':>19}{'constant, disjoint':>20}")
    for sym in SYMBOLS:
        if sym not in px:
            continue
        s = scores(px[sym].dropna())
        print(f"  {sym:<10}{s['mean_rv']:9.4f}{s['persist_overlap']:18.5f}"
              f"{s['persist_disjoint']:19.5f}{s['constant_disjoint']:20.5f}")
    print("\n  On the overlapping target persistence looks like skill; on a")
    print("  disjoint target it loses to a constant.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
