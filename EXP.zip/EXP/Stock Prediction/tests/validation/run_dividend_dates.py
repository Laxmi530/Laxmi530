"""
Dividend dates and the book's micro factors on NSE (Mladjenovic, *Stock
Investing For Dummies*, 7th ed., Ch. 6 and Ch. 15).

1. **The ex-date drop.** Ch. 6: a buyer on the ex-dividend date gets "a
   slightly lower price to reflect the amount of the dividend". The drop
   ratio (cum close x (1 + market return) - ex close) / dividend is 1 if the
   price falls by exactly the dividend (Elton & Gruber 1970). Measured on every
   cash dividend in the panel, by dividend yield.
2. **Does it matter to a forecast?** The app forecasts the adjusted
   (total-return) price, but the quoted price drops by the dividend on the
   ex-date. The share of dividends large enough to be seen against a 5-day
   95% cone.
3. **Ch. 15's micro factors, the ones price and corporate-action data can
   build point-in-time:** dividend yield (trailing-12-month cash dividends per
   share / price, split-adjusted to the date), low volatility (60-day realised
   vol), beta (to the equal-weighted panel, 250 days) and liquidity (median
   turnover, 60 days). Fama-MacBeth rank IC against the next 21 sessions'
   excess return, sampled every 21 sessions so windows do not overlap, with a
   Bonferroni bar over the four factors. Dividend yield is also measured
   within volatility quintiles, because payers are quieter stocks.

Survivorship-free bhavcopy panel, 2018-01-01 .. 2024-06-30, before the
reserved period.

Run::

    python tests/validation/run_dividend_dates.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import strategy_metrics as sm               # noqa: E402

START, END, N, H = "2018-01-01", "2024-06-30", 400, 21
OUT = os.path.join(_HERE, "dividend_dates.csv")


def _ttm_dividend(acts_sym, dates):
    """Trailing-12-month cash dividend per share at each date, on that date's share basis."""
    a = acts_sym.sort_values("ex_date")
    out = np.zeros(len(dates))
    ex = a["ex_date"].to_numpy()
    div = a["dividend"].to_numpy(float)
    fac = a["factor"].to_numpy(float)
    for k, d in enumerate(dates):
        win = (ex <= d) & (ex > d - np.timedelta64(365, "D"))
        if not win.any():
            continue
        tot = 0.0
        for j in np.nonzero(win & (div > 0))[0]:
            # A split or bonus after the dividend but on/before d puts the old
            # per-share dividend on fewer shares: divide by those factors.
            later = (ex > ex[j]) & (ex <= d) & (fac != 1.0)
            tot += div[j] / float(np.prod(fac[later])) if later.any() else div[j]
        out[k] = tot
    return out


def main():
    print("=" * 78)
    print("DIVIDEND DATES AND MICRO FACTORS ON NSE  (Mladjenovic, Ch. 6 and Ch. 15)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    acts = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END,
                                chunk_months=360)
    panel, _ = bc.build_panel(START, END, n=N, actions=acts, verbose=False)
    panel = panel.sort_values(["symbol", "datetime"])
    close = panel.pivot_table(index="datetime", columns="symbol", values="close")
    adj = panel.pivot_table(index="datetime", columns="symbol", values="adj_close")
    turn = panel.pivot_table(index="datetime", columns="symbol", values="turnover")
    ret = np.log(adj).diff()
    mkt = ret.mean(axis=1)
    dates = close.index
    print(f"\n  {close.shape[1]} names, {len(dates)} sessions, {len(acts):,} corporate actions")

    # ------------------------------------------------------ 1. the ex-date drop
    ev = []
    # Two dividends going ex on the same day (a final and a special: L&T 2023,
    # Nestle 2021, RCF 2022) are one price drop, so they are one event with the
    # summed amount. Measured separately, each was set against the whole drop
    # (L&T's Rs 6 read as a 57% drop ratio, its Rs 24 as 14%) and the row order
    # between them was arbitrary.
    cash = acts[(acts.dividend > 0) & (acts.factor == 1.0)]
    cash = cash.groupby(["symbol", "ex_date"], as_index=False)["dividend"].sum()
    for _, a in cash.iterrows():
        s = a["symbol"]
        if s not in close.columns:
            continue
        i = int(np.searchsorted(dates, a["ex_date"]))
        if i <= 0 or i >= len(dates) or dates[i] != a["ex_date"]:
            continue
        cum, exc = close[s].iloc[i - 1], close[s].iloc[i]
        if not (np.isfinite(cum) and np.isfinite(exc) and cum > 0):
            continue
        d = float(a["dividend"])
        expected = cum * math.exp(mkt.iloc[i]) if np.isfinite(mkt.iloc[i]) else cum
        ev.append({"symbol": s, "ex_date": a["ex_date"], "dividend": d, "yield": d / cum,
                   "drop_ratio": (expected - exc) / d,
                   "vol_d": float(ret[s].iloc[max(0, i - 60):i].std())})
    e = pd.DataFrame(ev)
    print("\n1. THE EX-DATE DROP  (1.0 = the price falls by exactly the dividend)")
    print(f"  {len(e):,} cash dividends on their ex-date")
    print(f"  {'dividend yield':<16}{'events':>8}{'median ratio':>14}{'yield-weighted':>16}")
    for lo, hi, lab in ((0, .005, "< 0.5%"), (.005, .01, "0.5-1%"), (.01, .02, "1-2%"),
                        (.02, .05, "2-5%"), (.05, 1, ">= 5%")):
        g = e[(e["yield"] >= lo) & (e["yield"] < hi)]
        if len(g) < 5:
            continue
        w = np.average(g.drop_ratio, weights=g["yield"])
        print(f"  {lab:<16}{len(g):8d}{g.drop_ratio.median():14.2f}{w:16.2f}")
    big = e[e["yield"] >= 0.01]
    print(f"  yield >= 1%: median drop ratio {big.drop_ratio.median():.2f}, "
          f"yield-weighted {np.average(big.drop_ratio, weights=big['yield']):.2f}")

    # ------------------------------------------- 2. against a 5-day cone
    e["cone_5d"] = 1.96 * e["vol_d"] * math.sqrt(5)
    e["share_of_cone"] = e["yield"] / e["cone_5d"]
    print("\n2. AGAINST A 5-DAY 95% CONE  (half-width 1.96 x 60-day vol x sqrt 5)")
    print(f"  dividends worth >= 10% of the cone's half-width : {np.mean(e.share_of_cone >= .10):.0%}")
    print(f"  dividends worth >= 25%                          : {np.mean(e.share_of_cone >= .25):.0%}")
    print(f"  largest: {e.nlargest(3, 'share_of_cone')[['symbol', 'ex_date', 'yield']].to_dict('records')}")

    # ---------------------------------------------- 3. the micro factors
    print("\n3. CH. 15 MICRO FACTORS: Fama-MacBeth rank IC vs the next 21 sessions' excess return")
    ttm = pd.DataFrame(index=dates, columns=close.columns, dtype=float)
    by_sym = {s: g for s, g in acts.groupby("symbol")}
    for s in close.columns:
        ttm[s] = (_ttm_dividend(by_sym[s], dates.to_numpy()) if s in by_sym
                  else np.zeros(len(dates)))
    factors = {
        "dividend yield": ttm / close,
        "low volatility": -ret.rolling(60).std(),
        # Rolling cov(stock, market) column by column; DataFrame.rolling.cov with
        # a Series does not align and returned NaN everywhere.
        "beta (low)": -((ret.mul(mkt, axis=0).rolling(250).mean()
                         - ret.rolling(250).mean().mul(mkt.rolling(250).mean(), axis=0))
                        .div(mkt.rolling(250).var(ddof=0), axis=0)),
        "liquidity": np.log(turn.rolling(60).median()),
    }
    fwd = np.log(adj.shift(-H) / adj)
    fwd = fwd.sub(fwd.mean(axis=1), axis=0)                 # excess of the panel
    sample = dates[260:-H:H]                                # non-overlapping, after warm-up
    res = {}
    for name, f in factors.items():
        ic = {}
        for d in sample:
            x, y = f.loc[d], fwd.loc[d]
            ok = x.notna() & y.notna()
            if name == "dividend yield":
                ok &= close.loc[d].notna()
            if ok.sum() >= 30:
                ic[d] = float(x[ok].rank().corr(y[ok].rank()))
        fm = sm.fama_macbeth_ic(pd.Series(ic), lags=0)
        res[name] = fm
    bar = 2.50                                              # Bonferroni over 4 at 5%
    print(f"  {'factor':<16}{'mean IC':>9}{'t':>8}{'hit':>7}{'months':>8}   (Bonferroni |t| > {bar})")
    for name, fm in res.items():
        print(f"  {name:<16}{fm['mean_ic']:+9.4f}{fm['t_stat']:+8.2f}{fm['hit_rate']:7.2f}"
              f"{fm['n_dates']:8d}   {'SIGNIFICANT' if abs(fm['t_stat']) > bar else '-'}")

    # Dividend yield within volatility quintiles: payers are quieter stocks.
    ic = {}
    vol = ret.rolling(60).std()
    for d in sample:
        x, y, v = factors["dividend yield"].loc[d], fwd.loc[d], vol.loc[d]
        ok = x.notna() & y.notna() & v.notna()
        if ok.sum() < 50:
            continue
        q = pd.qcut(v[ok].rank(method="first"), 5, labels=False)
        xr = x[ok].groupby(q).rank(pct=True)
        ic[d] = float(xr.corr(y[ok].rank()))
    nv = sm.fama_macbeth_ic(pd.Series(ic), lags=0)
    print(f"  dividend yield, ranked WITHIN volatility quintiles: IC {nv['mean_ic']:+.4f}, "
          f"t {nv['t_stat']:+.2f}")
    # Attack the one factor that cleared the bar.
    def _fm(f, dts, mask=None, binary=False):
        ic = {}
        for d in dts:
            x, y = f.loc[d], fwd.loc[d]
            ok = x.notna() & y.notna()
            if mask is not None:
                ok &= mask.loc[d]
            if ok.sum() >= 30 and x[ok].nunique() > 1:
                ic[d] = float(x[ok].rank().corr(y[ok].rank()))
        return sm.fama_macbeth_ic(pd.Series(ic), lags=0)
    dy = factors["dividend yield"]
    half = sample[len(sample) // 2]
    for lab, dts in (("first half", [d for d in sample if d < half]),
                     ("second half", [d for d in sample if d >= half])):
        fm = _fm(dy, dts)
        print(f"  dividend yield, {lab} ({pd.Timestamp(dts[0]).date()} ..): IC {fm['mean_ic']:+.4f}, "
              f"t {fm['t_stat']:+.2f}, {fm['n_dates']} months")
    fm = _fm((ttm > 0).astype(float), sample)
    print(f"  payer vs non-payer only (1/0)             : IC {fm['mean_ic']:+.4f}, t {fm['t_stat']:+.2f}")
    fm = _fm(dy, sample, mask=(ttm > 0))
    print(f"  yield ranked among PAYERS only            : IC {fm['mean_ic']:+.4f}, t {fm['t_stat']:+.2f}")
    payers = (ttm > 0).loc[sample].mean(axis=1).median()
    print(f"  share of names paying a dividend in the trailing year: {payers:.0%}")

    e.to_csv(OUT, index=False)
    pd.DataFrame(res).T.to_csv(OUT.replace(".csv", "_factors.csv"))
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
