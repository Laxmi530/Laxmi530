"""
Market breadth on NSE: does it forecast the market's return or its volatility?
(Thomsett, *Stock Market Math*, Ch. 8 "Breadth of the Market", "New Highs and
New Lows"; Ch. 9 "Breadth of Trading".)

Breadth is the one market-level input this project never tried. Every model
reads one stock's prices plus, optionally, an index level; none sees how many
stocks are rising. Breadth needs the WHOLE market, including the names that
later delisted, which is exactly what the survivorship-free bhavcopy cache holds.

Pre-registered, before looking:

* Universe each day: every EQ-series line with turnover >= Rs 1 crore.
* Measures (4): ``ad10`` (10-day mean of (advances - declines) / (advances +
  declines)); ``mcclellan`` (EMA19 - EMA39 of that daily ratio, the
  ratio-adjusted McClellan oscillator); ``hilo10`` (10-day mean of (new
  52-week highs - new 52-week lows) / issues); ``hl_index`` (10-day mean of
  highs / (highs + lows), the "record high percent").
  Advances use close against NSE's prevclose, which the exchange adjusts for
  corporate actions; 52-week extremes use the chain of close / prevclose, so a
  split never prints a false new low.
* Targets (3): the next 5- and 21-session equal-weighted market log return, and
  the next 21-session log realised volatility INCREMENTAL to a HAR baseline
  (log RV over the last 1, 5 and 22 sessions).
* Inference: OLS slope on daily-sampled overlapping data with Newey-West
  errors (lag = horizon). Bonferroni over 4 x 3 = 12 tests: |t| > 2.87.
* Out of sample: fit 2018-01 .. 2021-12, score 2022-01 .. 2024-06; R^2 against
  the in-sample mean (returns) or the HAR baseline (volatility).

Data 2017-01-01 .. 2024-06-30 (2017 is warm-up), before the reserved period.

Run::

    python tests/validation/run_market_breadth.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import breadth                              # noqa: E402

START, END = "2017-01-01", "2024-06-30"
FIT_END, TEST_START = pd.Timestamp("2021-12-31"), pd.Timestamp("2022-01-01")
MEASURES = ("ad10", "mcclellan", "hilo10", "hl_index")
T_BAR = 2.87
OUT = os.path.join(_HERE, "market_breadth.csv")


def newey_west_ols(y, X, lag):
    """OLS coefficients and Newey-West t-statistics (Bartlett kernel)."""
    X = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ beta
    XtX_inv = np.linalg.inv(X.T @ X)
    S = (X * e[:, None]).T @ (X * e[:, None])
    for k in range(1, lag + 1):
        w = 1.0 - k / (lag + 1.0)
        G = (X[k:] * e[k:, None]).T @ (X[:-k] * e[:-k, None])
        S += w * (G + G.T)
    V = XtX_inv @ S @ XtX_inv
    return beta, beta / np.sqrt(np.diag(V))


def driscoll_kraay(y, X, dates, lag):
    """Pooled OLS with Driscoll-Kraay t-statistics: moments summed by date, then Newey-West."""
    X = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ beta
    h = pd.DataFrame(X * e[:, None]).groupby(pd.Index(dates)).sum().sort_index().values
    S = h.T @ h
    for k in range(1, lag + 1):
        w = 1.0 - k / (lag + 1.0)
        G = h[k:].T @ h[:-k]
        S += w * (G + G.T)
    XtX_inv = np.linalg.inv(X.T @ X)
    V = XtX_inv @ S @ XtX_inv
    return beta, beta / np.sqrt(np.diag(V))


def _india_vix(index):
    """India VIX closes up to the end of the study window only (never the reserved period)."""
    try:
        import yfinance as yf
        v = yf.download("^INDIAVIX", start="2016-12-01", end="2024-07-01",
                        progress=False, auto_adjust=False)
        c = v["Close"]
        c = c.iloc[:, 0] if isinstance(c, pd.DataFrame) else c
        c.index = pd.to_datetime(c.index).tz_localize(None)
        c = c[c.index <= pd.Timestamp(END)]
        return c.reindex(index).ffill()
    except Exception as exc:
        print(f"  (India VIX unavailable: {exc})")
        return None


def oos_r2(y_tr, X_tr, y_te, X_te, X_tr_base=None, X_te_base=None):
    """Out-of-sample R^2 of the model against a baseline (mean, or a nested OLS)."""
    def fit_pred(Xa, ya, Xb):
        A = np.column_stack([np.ones(len(ya))] + ([Xa] if Xa is not None else []))
        b, *_ = np.linalg.lstsq(A, ya, rcond=None)
        B = np.column_stack([np.ones(len(Xb) if Xb is not None else len(y_te))]
                            + ([Xb] if Xb is not None else []))
        return B @ b
    p_model = fit_pred(X_tr, y_tr, X_te)
    p_base = fit_pred(X_tr_base, y_tr, X_te_base)
    return 1.0 - np.sum((y_te - p_model) ** 2) / np.sum((y_te - p_base) ** 2)


def main():
    print("=" * 78)
    print("MARKET BREADTH ON NSE  (Thomsett, Stock Market Math, Ch. 8-9)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    print("\n  loading the full market (every listed name, delisted ones included) ...")
    raw = bc.load_cache(START, END)
    b = breadth.daily_breadth(raw)
    print(f"  {len(b):,} sessions; median {b['issues'].median():.0f} liquid issues a day, "
          f"{b['highs'].median():.0f} new highs and {b['lows'].median():.0f} new lows")

    d = b.copy()
    r = d["mkt_ret"]
    for h in (5, 21):
        d[f"fwd_ret_{h}"] = r[::-1].rolling(h).sum()[::-1].shift(-1)
    rv = r ** 2
    d["fwd_lrv_21"] = np.log(rv[::-1].rolling(21).mean()[::-1].shift(-1))
    d["lrv_1"] = np.log(rv.clip(lower=1e-10))
    d["lrv_5"] = np.log(rv.rolling(5).mean())
    d["lrv_22"] = np.log(rv.rolling(22).mean())
    d = d[d.index >= pd.Timestamp("2018-01-01")].dropna()
    print(f"  scored sessions 2018-01 .. 2024-06: {len(d):,}")

    print(f"\n  Correlation of the measures:\n{d[list(MEASURES)].corr().round(2).to_string()}")

    rows = []
    har = ["lrv_1", "lrv_5", "lrv_22"]
    tr, te = d[d.index <= FIT_END], d[d.index >= TEST_START]
    print(f"\n  {'measure':<11}{'target':<16}{'slope':>10}{'NW t':>8}{'OOS R2':>9}   verdict")
    for m in MEASURES:
        z = (d[m] - tr[m].mean()) / tr[m].std()          # standardised on the fit window
        for tgt, h in (("fwd_ret_5", 5), ("fwd_ret_21", 21), ("fwd_lrv_21", 21)):
            if tgt.startswith("fwd_ret"):
                beta, t = newey_west_ols(d[tgt].values, z.values[:, None], h)
                r2 = oos_r2(tr[tgt].values, z[tr.index].values[:, None],
                            te[tgt].values, z[te.index].values[:, None])
            else:
                X = np.column_stack([d[har].values, z.values])
                beta, t = newey_west_ols(d[tgt].values, X, h)
                beta, t = beta[[0, -1]], t[[0, -1]]
                r2 = oos_r2(tr[tgt].values, np.column_stack([tr[har].values, z[tr.index].values]),
                            te[tgt].values, np.column_stack([te[har].values, z[te.index].values]),
                            tr[har].values, te[har].values)
            sig = abs(t[1]) > T_BAR
            rows.append({"measure": m, "target": tgt, "slope": beta[1], "t": t[1],
                         "oos_r2": r2, "significant": sig})
            print(f"  {m:<11}{tgt:<16}{beta[1]:10.5f}{t[1]:8.2f}{r2:9.4f}   "
                  f"{'clears the bar' if sig else '-'}")

    res = pd.DataFrame(rows)
    # Halves, for anything that cleared the bar.
    for _, row in res[res.significant].iterrows():
        m, tgt = row.measure, row.target
        h = 5 if tgt == "fwd_ret_5" else 21
        print(f"\n  {m} -> {tgt}: by half")
        for lab, part in (("2018-2020", d[d.index < "2021-01-01"]), ("2021-2024", d[d.index >= "2021-01-01"])):
            z = ((part[m] - tr[m].mean()) / tr[m].std()).values[:, None]
            X = np.column_stack([part[har].values, z]) if tgt == "fwd_lrv_21" else z
            beta, t = newey_west_ols(part[tgt].values, X, h)
            print(f"    {lab}: slope {beta[-1]:+.5f}  t {t[-1]:+.2f}")

    # Plain description: forward returns by breadth quintile.
    print("\n  Next-21-session market return by ad10 quintile (descriptive, overlapping):")
    q = pd.qcut(d["ad10"], 5, labels=False) + 1
    print("  " + "  ".join(f"Q{k}: {d.loc[q == k, 'fwd_ret_21'].mean() * 100:+.2f}%" for k in range(1, 6)))
    print("  Next-21-session realised vol (annualised) by ad10 quintile:")
    vol21 = np.sqrt(np.exp(d["fwd_lrv_21"]) * 252)
    print("  " + "  ".join(f"Q{k}: {vol21[q == k].mean() * 100:.1f}%" for k in range(1, 6)))

    # ---------------------------------------------- 2: is it something simpler?
    # Weak breadth follows a falling market, and falling markets get more
    # volatile (the leverage effect); India VIX is the market's own forecast
    # of the next month's volatility. Does breadth add to either?
    print("\n2. CONTROLS FOR THE VOLATILITY RESULT (target: next-21-session log RV)")
    d["ret_10"] = r.rolling(10).sum().reindex(d.index)
    d["neg_10"] = np.minimum(d["ret_10"], 0.0)
    vix = _india_vix(d.index)
    if vix is not None:
        d["lvix"] = np.log((vix / 100.0) ** 2 / 252.0)
    d2 = d.dropna(subset=[c for c in ("ret_10", "lvix") if c in d])
    tr2, te2 = d2[d2.index <= FIT_END], d2[d2.index >= TEST_START]
    ctrl_sets = [("HAR + past 10-day return (leverage)", har + ["ret_10", "neg_10"])]
    if vix is not None:
        ctrl_sets.append(("HAR + leverage + India VIX", har + ["ret_10", "neg_10", "lvix"]))
    for m in ("ad10", "mcclellan"):
        z = (d2[m] - tr2[m].mean()) / tr2[m].std()
        for lab, ctrl in ctrl_sets:
            X = np.column_stack([d2[ctrl].values, z.values])
            beta, t = newey_west_ols(d2["fwd_lrv_21"].values, X, 21)
            r2 = oos_r2(tr2["fwd_lrv_21"].values,
                        np.column_stack([tr2[ctrl].values, z[tr2.index].values]),
                        te2["fwd_lrv_21"].values,
                        np.column_stack([te2[ctrl].values, z[te2.index].values]),
                        tr2[ctrl].values, te2[ctrl].values)
            print(f"  {m:<10} over {lab:<38} slope {beta[-1]:+.3f}  NW t {t[-1]:+.2f}  "
                  f"OOS R2 gain {r2:+.4f}")

    # ------------------------------------------------ 3: single stocks
    print("\n3. SINGLE STOCKS: does market breadth improve each stock's own HAR forecast?")
    panel, _ = bc.build_panel("2018-01-01", END, n=200, verbose=False)
    st_rows = []
    for s, g in panel.groupby("symbol"):
        g = g.sort_values("datetime")
        if len(g) < 750:
            continue
        sr = np.log(g["adj_close"]).diff()
        sr.index = pd.to_datetime(g["datetime"].values)
        srv = sr ** 2
        f = pd.DataFrame({
            "y": np.log(srv[::-1].rolling(21).mean()[::-1].shift(-1)),
            "s1": np.log(srv.clip(lower=1e-10)), "s5": np.log(srv.rolling(5).mean()),
            "s22": np.log(srv.rolling(22).mean())})
        f = f.join(d[["ad10", "mcclellan", "lrv_22"] + (["lvix"] if "lvix" in d else [])], how="inner")
        f["symbol"] = s
        st_rows.append(f.replace([np.inf, -np.inf], np.nan).dropna())
    P = pd.concat(st_rows)
    print(f"  {P.symbol.nunique()} names, {len(P):,} name-days")
    base = ["s1", "s5", "s22", "lrv_22"]
    for m in ("ad10", "mcclellan"):
        mu, sd = P.loc[P.index <= FIT_END, m].mean(), P.loc[P.index <= FIT_END, m].std()
        P["z"] = (P[m] - mu) / sd
        trP, teP = P[P.index <= FIT_END], P[P.index >= TEST_START]
        for lab, cols in (("stock HAR + market RV", base),
                          ("stock HAR + market RV + VIX", base + ["lvix"]) if "lvix" in P else (None, None)):
            if lab is None:
                continue
            beta, t = driscoll_kraay(P["y"].values, P[cols + ["z"]].values, P.index.values, 21)
            r2 = oos_r2(trP["y"].values, trP[cols + ["z"]].values, teP["y"].values,
                        teP[cols + ["z"]].values, trP[cols].values, teP[cols].values)
            print(f"  {m:<10} over {lab:<30} slope {beta[-1]:+.3f}  Driscoll-Kraay t {t[-1]:+.2f}  "
                  f"OOS R2 gain {r2:+.4f}")

    b.to_csv(OUT)
    res.to_csv(OUT.replace(".csv", "_tests.csv"), index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
