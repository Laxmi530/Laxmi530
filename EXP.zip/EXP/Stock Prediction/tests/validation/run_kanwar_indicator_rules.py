"""
The three indicator trading rules inside Kanwar & Gupta's indicator chapters.

Besides the SMA x RSI setup (``run_kanwar_setup.py``), the book's indicator
chapters each end with a small trading rule, shown on INFY 2018-20:

    MACD (p. 92-95)        long while MACD(12, 26, 9) > its signal line,
                           flat otherwise. Book: "26 trades, return from each
                           trade approximately -5% to 20%".
    Balance of Power (p. 96-97)  buy when BOP crosses above zero, sell when it
                           crosses below. The book computes and plots BOP
                           smoothed by a 9-day SMA, so the cross is taken on
                           that line (raw BOP changes sign almost daily).
    Stochastic (p. 98-100) buy when slowk crosses above slowd with slowd < 20,
                           sell when it crosses below with slowd > 80
                           (slow Stochastic 5, 3, 3); long from a buy to the
                           next sell.

Step 0 reproduces the book's own number, MACD's 26 trades on INFY over
2018-2020, as a check that the rule implemented is the rule in the book.
Then each rule, unchanged (no parameters are searched, so no PBO), runs on
the 50 most liquid NSE names, survivorship-free, 2018-01-01 .. 2024-06-30,
long-only as in the book, at cash-delivery cost
(``strategy_metrics.india_round_trip_bps``). A timing rule that is out of the
market part of the time will trail buy & hold in a rising market for that
reason alone, so the comparison that matters is the TIMING return: the
rule's return minus buy & hold scaled by the rule's time in the market.

Run::

    python tests/validation/run_kanwar_indicator_rules.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import event_backtest as eb        # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 50
WARMUP = 60
OUT = os.path.join(_HERE, "kanwar_indicator_rules.csv")


def positions(d, ta):
    """Long/flat positions for the three rules on one name's OHLC."""
    o, h, lo, c = (d[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    idx = d.index
    macd, sig, _ = ta.MACD(c, fastperiod=12, slowperiod=26, signalperiod=9)
    p_macd = pd.Series(np.where(np.isnan(macd) | np.isnan(sig), 0.0,
                                (macd > sig).astype(float)), index=idx)

    bop = pd.Series(ta.SMA(ta.BOP(o, h, lo, c), 9), index=idx)
    p_bop = pd.Series(np.nan, index=idx)
    p_bop[(bop > 0) & (bop.shift(1) <= 0)] = 1.0
    p_bop[(bop < 0) & (bop.shift(1) >= 0)] = 0.0
    p_bop = p_bop.ffill().fillna(0.0)

    k, dd = ta.STOCH(h, lo, c, fastk_period=5, slowk_period=3, slowk_matype=0,
                     slowd_period=3, slowd_matype=0)
    k, dd = pd.Series(k, index=idx), pd.Series(dd, index=idx)
    buy = (k > dd) & (k.shift(1) < dd.shift(1)) & (dd < 20)
    sell = (k < dd) & (k.shift(1) > dd.shift(1)) & (dd > 80)
    p_sto = pd.Series(np.nan, index=idx)
    p_sto[buy] = 1.0
    p_sto[sell] = 0.0
    p_sto = p_sto.ffill().fillna(0.0)
    return {"MACD": p_macd, "BOP": p_bop, "Stochastic": p_sto}


COVID = ("2020-02-01", "2020-06-30")


def _timing_ex(net, bh, pos):
    """Timing return with the February-June 2020 crash and rebound removed."""
    keep = ~((net.index >= COVID[0]) & (net.index <= COVID[1]))
    tim = float(pos[keep].mean())
    return float((net[keep].mean() - tim * bh[keep].mean()) * 252)


def main():
    print("=" * 78)
    print("KANWAR & GUPTA: THE MACD, BALANCE-OF-POWER AND STOCHASTIC RULES")
    print("=" * 78)
    try:
        import talib as ta
    except ImportError:
        print("\nTA-Lib is not installed (validation-only dependency): pip install TA-Lib")
        return 1
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    panel = eb.adjust_ohlc(panel)

    # ---------------------------------------------- 0. reproduce the book
    d = (panel[panel.symbol == "INFY"].set_index("datetime").sort_index()
         .loc["2018-01-01":"2020-12-31"])
    p = positions(d, ta)["MACD"]
    trades = int(round((p.diff().fillna(0) != 0).sum() / 2))
    print(f"\n0. REPRODUCING THE BOOK: MACD rule on INFY 2018-2020 -> {trades} trades "
          f"(book: 26)")

    # ---------------------------------------------- 1. the rules, everywhere
    cost = lambda dt: sm.india_round_trip_bps("delivery", as_of=dt)["total"] / 1e4 / 2.0
    rows = []
    for sym, g in panel.groupby("symbol"):
        d = g.set_index("datetime").sort_index()
        if len(d) < WARMUP + 500:
            continue
        nxt = d["close"].pct_change().shift(-1)        # adjusted close
        c_t = np.array([cost(t) for t in d.index])
        bh = nxt.iloc[WARMUP:-1]
        for rule, pos in positions(d, ta).items():
            turn = pos.diff().abs().fillna(pos)
            net = (pos * nxt - c_t * turn).iloc[WARMUP:-1]
            tim = float(pos.iloc[WARMUP:-1].mean())
            rows.append({"symbol": sym, "rule": rule, "time_in_market": tim,
                         "trades_per_year": float(turn.iloc[WARMUP:-1].sum() / 2 / (len(net) / 252)),
                         "net_total": float((1 + net).prod() - 1),
                         "bh_total": float((1 + bh).prod() - 1),
                         "net_sharpe": float(net.mean() / net.std(ddof=1) * np.sqrt(252)),
                         "bh_sharpe": float(bh.mean() / bh.std(ddof=1) * np.sqrt(252)),
                         # Return from timing alone: the rule against buy &
                         # hold held for the same fraction of days.
                         "timing_ann": float((net.mean() - tim * bh.mean()) * 252),
                         # A trend-exit rule can earn its timing from one
                         # episode; the COVID crash is the obvious one here.
                         "timing_ann_ex_covid": _timing_ex(net, bh, pos.iloc[WARMUP:-1])})
    r = pd.DataFrame(rows)
    r.to_csv(OUT, index=False)
    print(f"\n1. EACH RULE ON {r.symbol.nunique()} LIQUID NSE NAMES, 2018-2024, long-only, "
          "cash-delivery costs")
    print(f"\n  {'rule':<12}{'in market':>10}{'trades/yr':>10}{'net total':>11}{'buy&hold':>10}"
          f"{'net SR':>8}{'B&H SR':>8}{'beats B&H':>11}{'timing/yr':>11}{'t':>7}")
    for rule, g in r.groupby("rule", sort=False):
        t = g.timing_ann.mean() / (g.timing_ann.std(ddof=1) / np.sqrt(len(g)))
        print(f"  {rule:<12}{g.time_in_market.median():10.0%}{g.trades_per_year.median():10.1f}"
              f"{g.net_total.median():+11.0%}{g.bh_total.median():+10.0%}"
              f"{g.net_sharpe.median():+8.2f}{g.bh_sharpe.median():+8.2f}"
              f"{(g.net_sharpe > g.bh_sharpe).mean():11.0%}{g.timing_ann.median():+11.1%}{t:+7.2f}")
    print("\n  timing with Feb-Jun 2020 removed:")
    for rule, g in r.groupby("rule", sort=False):
        t = g.timing_ann_ex_covid.mean() / (g.timing_ann_ex_covid.std(ddof=1) / np.sqrt(len(g)))
        print(f"  {rule:<12} median {g.timing_ann_ex_covid.median():+.1%} a year, t {t:+.2f}")
    print("\n  'timing/yr' = the rule's annualised net return minus buy & hold held for the")
    print("  same share of days; positive means the rule picked its days well. Names are")
    print("  correlated, so the cross-name t overstates the evidence for whatever sign it has.")
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
