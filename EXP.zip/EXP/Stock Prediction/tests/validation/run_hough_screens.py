"""
Two claims from Hough, *Your Next Great Stock* (2008), tested on NSE before the
reserved period.

A. The falling-knife deal breaker (Ch. 24). "If the stock has fallen over the
   past year, was it still moving lower each day over the past week? If so,
   consider discarding it or at least setting it aside ... the odds are better
   that a falling stock will head lower after you buy it. Better to wait until
   it has stabilized or even risen a bit and pay the higher price."

   Written down before running. This project's one robust cross-sectional
   finding is short-term REVERSAL (README sections 38, 39, 49): last week's
   losers beat last week's winners over the following weeks. If that holds
   among 12-month losers too, the book's rule has the sign backwards: the
   stock still falling is the better buy, and waiting costs money.

   A1. Among stock-days with a negative 252-session return, "still falling"
       (5-session return below zero) against "stabilised" (zero or above).
       Excess return over the equal-weighted panel at 5, 21 and 63 sessions;
       the test is the 21-session difference, month by month.
   A2. The book's alternative, priced directly. For a still-falling stock,
       buying now and buying at the first session its 5-session return turns
       non-negative (capped at 63 sessions) end at the same place, so the whole
       difference is the stock's excess move during the wait. Negative: the
       stock fell further and waiting saved money (the book). Positive:
       waiting paid up.

   Two tests, so the bar is Bonferroni alpha/2 (|t| > 2.24).

   Added after the first run, and labelled as such: A2's move mixes the
   week's signal with the drift every 12-month loser has (momentum: they lag
   whatever the last week did). Subtracting what the average 12-month loser
   did over the same sessions leaves the part the "still falling" signal adds.

B. Data mining (Ch. 6). Hough built his "XYZ strategy" (S&P 500 names starting
   with X, Y or Z) in twenty minutes to show how a back test can lie. The same
   on NSE: group stocks by the first letter of their symbol, pick the three
   best letters on 2018-01 .. 2021-03, and hold them on 2021-04 .. 2024-06.
   The in-sample excess is what pure selection buys; 1,000 random relabellings
   (same group sizes) give its distribution. Expected: the out-of-sample
   excess is about zero, and the in-sample winner is unremarkable against the
   relabelled ones. (The Tata / non-Tata split of 'T' was added after the
   first run, to test a lurking-variable reading of the one letter that held.)

Data: the survivorship-free bhavcopy panel, 400 liquid names screened on the
year before 2018, 2018-01-01 .. 2024-06-30. Event t-statistics average events
by calendar month first (Newey-West, lag h/21), so a crowded day cannot pass
for many independent observations.

Run::

    python tests/validation/run_hough_screens.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                                         # noqa: E402
from run_market_breadth import newey_west_ols                 # noqa: E402
from run_oneil import monthly_t                               # noqa: E402

START, END = "2018-01-01", "2024-06-30"
SPLIT = "2021-04-01"
HORIZONS = (5, 21, 63)
YEAR, WEEK, MAX_WAIT = 252, 5, 63
N_NAMES, MIN_LETTER, TOP_K, N_PERM = 400, 5, 3, 1000
BAR = 2.24                                    # Bonferroni alpha/2, two-sided
OUT = os.path.join(_HERE, "hough_screens.csv")


def month_diff_t(a_dates, a_vals, b_dates, b_vals, lag):
    """Mean and Newey-West t of the per-month difference of two event groups."""
    ma = pd.Series(a_vals, index=pd.to_datetime(a_dates)).dropna()
    mb = pd.Series(b_vals, index=pd.to_datetime(b_dates)).dropna()
    d = (ma.groupby(ma.index.to_period("M")).mean()
         - mb.groupby(mb.index.to_period("M")).mean()).dropna()
    b, t = newey_west_ols(d.values, np.zeros((len(d), 0)), lag)
    return float(b[0]), float(t[0]), len(d)


def wait_moves(lc, mkt_cum, r5, base_cum=None):
    """
    For each still-falling day: the stock's excess log move from today to the
    first session (within MAX_WAIT) whose 5-session return is non-negative,
    the number of sessions waited, and (with ``base_cum``) the same move net
    of a benchmark's over the same sessions.
    """
    n = len(lc)
    out = np.full(n, np.nan)
    waited = np.full(n, np.nan)
    net = np.full(n, np.nan)
    ok = r5 >= 0
    nxt = np.full(n, -1)
    last = -1
    for i in range(n - 1, -1, -1):          # next index (strictly after i) with ok
        nxt[i] = last
        if ok[i]:
            last = i
    for t in range(n):
        if not (r5[t] < 0) or not np.isfinite(lc[t]):
            continue
        w = nxt[t]
        if w < 0 or w - t > MAX_WAIT:
            w = t + MAX_WAIT
        if w >= n or not np.isfinite(lc[w]):
            continue
        out[t] = (lc[w] - lc[t]) - (mkt_cum[w] - mkt_cum[t])
        waited[t] = w - t
        if base_cum is not None and np.isfinite(base_cum[w]) and np.isfinite(base_cum[t]):
            net[t] = out[t] - (base_cum[w] - base_cum[t])
    return out, waited, net


def study_a(closes, mkt, rows):
    print("\nA. THE FALLING-KNIFE DEAL BREAKER (Ch. 24)")
    mkt_cum = mkt.fillna(0.0).cumsum()
    market_fwd = {h: mkt[::-1].rolling(h).sum()[::-1].shift(-1) for h in HORIZONS}
    # The average 12-month loser's excess return each session, membership taken
    # the session before (the post-hoc benchmark for A2).
    lr = pd.concat({s: np.log(c).diff() for s, c in closes.items()}, axis=1)
    lag_r252 = pd.concat({s: (np.log(c) - np.log(c).shift(YEAR)).shift(1) for s, c in closes.items()}, axis=1)
    loser_ex = lr.sub(mkt, axis=0).where(lag_r252 < 0).mean(axis=1).fillna(0.0)
    loser_cum = loser_ex.cumsum()
    parts = []
    for sym, c in closes.items():
        lc = np.log(c)
        f = pd.DataFrame({"date": c.index, "r252": (lc - lc.shift(YEAR)).values,
                          "r5": (lc - lc.shift(WEEK)).values})
        for h in HORIZONS:
            f[f"x_{h}"] = (lc.shift(-h) - lc).values - c.index.map(market_fwd[h]).values
        mc = mkt_cum.reindex(c.index).values
        f["wait"], f["waited"], f["wait_net"] = wait_moves(lc.values, mc, f["r5"].values,
                                                           loser_cum.reindex(c.index).values)
        parts.append(f.dropna(subset=["r252", "r5"]))
    ev = pd.concat(parts, ignore_index=True)
    ev = ev[ev["date"] >= pd.Timestamp(START) + pd.Timedelta(days=380)]
    groups = {
        "12m loser, still falling (r5 < 0)": ev[(ev.r252 < 0) & (ev.r5 < 0)],
        "12m loser, stabilised (r5 >= 0)": ev[(ev.r252 < 0) & (ev.r5 >= 0)],
        "12m winner, falling this week": ev[(ev.r252 >= 0) & (ev.r5 < 0)],
        "12m winner, up this week": ev[(ev.r252 >= 0) & (ev.r5 >= 0)],
    }
    print(f"  {'group':<38}{'stock-days':>11}" + "".join(f"{f'{h}d excess':>12}{'t':>7}" for h in HORIZONS))
    for name, g in groups.items():
        line, rec = f"  {name:<38}{len(g):>11,d}", {"study": "A1", "group": name, "n": len(g)}
        for h in HORIZONS:
            m, t, _ = monthly_t(g["date"], g[f"x_{h}"], lag=max(1, h // 21))
            rec[f"mean_{h}"], rec[f"t_{h}"] = m, t
            line += f"{m * 100:11.2f}%{t:7.2f}"
        print(line)
        rows.append(rec)

    fall, stab = groups["12m loser, still falling (r5 < 0)"], groups["12m loser, stabilised (r5 >= 0)"]
    print("\n  Still falling minus stabilised, 12-month losers (month by month):")
    for h in HORIZONS:
        m, t, k = month_diff_t(fall["date"], fall[f"x_{h}"].values, stab["date"], stab[f"x_{h}"].values,
                               lag=max(1, h // 21))
        tag = "  <- A1, the test" if h == 21 else ""
        print(f"    {h:>2}d: {m * 100:+.2f}%  t {t:+.2f}  ({k} months){tag}")
        rows.append({"study": "A1 diff", "group": f"still falling - stabilised, {h}d", "n": k,
                     f"mean_{h}": m, f"t_{h}": t})
    first = fall[fall.date < pd.Timestamp(SPLIT)]
    second = fall[fall.date >= pd.Timestamp(SPLIT)]
    for lab, sub in (("first half", first), ("second half", second)):
        s_sub = stab[(stab.date < pd.Timestamp(SPLIT)) if lab == "first half" else (stab.date >= pd.Timestamp(SPLIT))]
        m, t, k = month_diff_t(sub["date"], sub["x_21"].values, s_sub["date"], s_sub["x_21"].values, lag=1)
        print(f"    21d, {lab}: {m * 100:+.2f}%  t {t:+.2f}  ({k} months)")
        rows.append({"study": "A1 diff", "group": f"21d, {lab}", "n": k, "mean_21": m, "t_21": t})

    w = fall.dropna(subset=["wait"])
    m, t, k = monthly_t(w["date"], w["wait"], lag=3)
    print(f"\n  A2. Waiting for a still-falling 12-month loser to stabilise: the stock's excess move "
          f"during the wait\n    {m * 100:+.2f}%  t {t:+.2f}  ({k:,} stock-days)"
          f"   {'negative: waiting saved money (the book)' if m < 0 else 'positive: waiting paid up'}")
    rows.append({"study": "A2", "group": "excess move while waiting to stabilise", "n": k,
                 "mean_21": m, "t_21": t})
    print(f"    sessions waited: median {w['waited'].median():.0f}, mean {w['waited'].mean():.1f}; "
          f"never stabilised within {MAX_WAIT}: {(w['waited'] >= MAX_WAIT).mean():.1%}")
    m2, t2, k2 = monthly_t(w["date"], w["wait_net"], lag=3)
    print("  A2, post hoc: the same move net of the average 12-month loser over the same sessions")
    print(f"    {m2 * 100:+.2f}%  t {t2:+.2f}   (what the 'still falling' signal adds beyond momentum)")
    rows.append({"study": "A2 post hoc", "group": "wait move net of the average 12m loser", "n": k2,
                 "mean_21": m2, "t_21": t2})


def letter_returns(closes, mkt, labels, start, end):
    """Mean daily excess (and t) of an equal-weighted portfolio per label."""
    rets = pd.concat({s: np.log(c).diff() for s, c in closes.items()}, axis=1)
    rets = rets[(rets.index >= start) & (rets.index < end)]
    ex = rets.sub(mkt.reindex(rets.index), axis=0)
    out = {}
    for lab in sorted(set(labels.values())):
        cols = [s for s, l in labels.items() if l == lab and s in ex.columns]
        port = ex[cols].mean(axis=1).dropna()
        if len(port) < 100:
            continue
        b, t = newey_west_ols(port.values, np.zeros((len(port), 0)), 5)
        out[lab] = (float(b[0]) * 252, float(t[0]))
    return out


def study_b(closes, mkt, rows):
    print("\nB. DATA MINING: THE XYZ STRATEGY ON NSE (Ch. 6)")
    split = pd.Timestamp(SPLIT)
    letters = {s: s[0] if s[0].isalpha() else "#" for s in closes}
    counts = pd.Series(letters).value_counts()
    keep = set(counts[counts >= MIN_LETTER].index)
    labels = {s: l for s, l in letters.items() if l in keep}
    print(f"  {len(keep)} first letters with at least {MIN_LETTER} names ({sum(counts[list(keep)])} names)")
    ins = letter_returns(closes, mkt, labels, pd.Timestamp(START), split)
    oos = letter_returns(closes, mkt, labels, split, pd.Timestamp(END) + pd.Timedelta(days=1))
    best = sorted(ins, key=lambda k: ins[k][0], reverse=True)[:TOP_K]
    sig_in = sum(1 for v in ins.values() if abs(v[1]) > 1.96)
    common = [k for k in ins if k in oos]
    rho = pd.Series([ins[k][0] for k in common]).corr(pd.Series([oos[k][0] for k in common]), method="spearman")
    pick_in = np.mean([ins[k][0] for k in best])
    pick_out = np.mean([oos[k][0] for k in best if k in oos])
    print(f"  in sample ({START[:7]} .. 2021-03), the best {TOP_K} letters: "
          + ", ".join(f"{k} {ins[k][0] * 100:+.1f}%/yr (t {ins[k][1]:+.2f})" for k in best))
    print(f"  held out of sample (2021-04 .. {END[:7]}): "
          + ", ".join(f"{k} {oos[k][0] * 100:+.1f}%/yr (t {oos[k][1]:+.2f})" for k in best if k in oos))
    print(f"  basket of {TOP_K}: {pick_in * 100:+.1f}%/yr in sample, {pick_out * 100:+.1f}%/yr out of sample")
    print(f"  letters 'significant' in sample (|t| > 1.96): {sig_in} of {len(ins)}")
    print(f"  rank correlation of letter returns, in sample vs out: {rho:+.2f}")

    rng = np.random.default_rng(20080101)
    syms = list(labels)
    labs = np.array([labels[s] for s in syms])
    rets = pd.concat({s: np.log(closes[s]).diff() for s in syms}, axis=1)
    ins_ex = rets[(rets.index >= pd.Timestamp(START)) & (rets.index < split)].sub(mkt, axis=0)
    oos_ex = rets[rets.index >= split].sub(mkt, axis=0)
    null_in, null_out = [], []
    for _ in range(N_PERM):
        perm = rng.permutation(labs)
        g_in = {l: ins_ex.loc[:, perm == l].mean(axis=1).mean() * 252 for l in keep}
        g_out = {l: oos_ex.loc[:, perm == l].mean(axis=1).mean() * 252 for l in keep}
        top = sorted(g_in, key=g_in.get, reverse=True)[:TOP_K]
        null_in.append(np.mean([g_in[l] for l in top]))
        null_out.append(np.mean([g_out[l] for l in top]))
    null_in, null_out = np.array(null_in), np.array(null_out)
    p_in = float(np.mean(null_in >= pick_in))
    print(f"  1,000 random relabellings (same group sizes): the best {TOP_K} 'letters' earn "
          f"{np.median(null_in) * 100:+.1f}%/yr in sample (median; 95th pct {np.percentile(null_in, 95) * 100:+.1f}%), "
          f"then {np.median(null_out) * 100:+.1f}%/yr out of sample")
    p_out = float(np.mean(null_out >= pick_out))
    print(f"  the real letters' in-sample basket sits at the {100 * (1 - p_in):.0f}th percentile of that null, "
          f"its out-of-sample return at the {100 * (1 - p_out):.0f}th")
    t_names = sorted(s for s in labels if labels[s] == "T")
    tata = [s for s in t_names if s.startswith("TATA") or s in ("TCS", "TITAN", "TRENT", "TINPLATE")]
    print(f"  'T' holds {len(t_names)} names, {len(tata)} of them Tata group: {', '.join(tata)}")
    split_lab = {s: ("Tata" if s in tata else "T, not Tata") for s in t_names}
    for lab, (ann, t) in letter_returns(closes, mkt, split_lab, split, pd.Timestamp(END) + pd.Timedelta(days=1)).items():
        print(f"    out of sample, {lab}: {ann * 100:+.1f}%/yr (t {t:+.2f})")
        rows.append({"study": "B lurking", "group": lab, "out_of_sample": ann, "t_oos": t})
    rows.append({"study": "B", "group": f"best {TOP_K} letters: " + "".join(best), "n": len(ins),
                 "in_sample": pick_in, "out_of_sample": pick_out, "rank_corr": rho,
                 "null_in_median": float(np.median(null_in)), "null_in_p95": float(np.percentile(null_in, 95)),
                 "null_out_median": float(np.median(null_out)), "p_in": p_in, "p_out": p_out, "sig_in": sig_in})


def main():
    print("=" * 78)
    print("HOUGH, YOUR NEXT GREAT STOCK: TWO CLAIMS ON NSE")
    print("=" * 78)
    panel, _ = bc.build_panel(START, END, n=N_NAMES, verbose=False, purpose="Hough Ch. 6 and 24")
    closes = {}
    for s, g in panel.groupby("symbol"):
        c = pd.Series(pd.to_numeric(g["adj_close"], errors="coerce").values,
                      index=pd.to_datetime(g["datetime"].values)).sort_index()
        c = c[c > 0]
        if len(c) >= 300:
            closes[s] = c
    allr = pd.concat({s: np.log(c).diff() for s, c in closes.items()}, axis=1)
    mkt = allr.mean(axis=1)
    print(f"  {len(closes)} names, {len(mkt):,} sessions, {START} .. {END}")
    rows = []
    study_a(closes, mkt, rows)
    study_b(closes, mkt, rows)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  written {OUT}")


if __name__ == "__main__":
    main()
