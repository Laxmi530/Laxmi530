"""
Hilpisch's three technical strategies, optimised his way, then tested.

Hilpisch, *Python for Algorithmic Trading*, Ch. 4, backtests three classic
rules and optimises each by brute force for in-sample gross performance:

    SMA crossover    long when SMA1 > SMA2, short otherwise; he searches
                     SMA1 in range(30, 50, 2) x SMA2 in range(200, 300, 2),
                     500 pairs, and reports the best
    momentum         position = sign of the mean of the last m log returns
    mean reversion   short when price is `threshold` above its SMA, long when
                     below, flat when the gap changes sign

His own "Data Snooping and Overfitting" section (pp. 111-113) says the results
are chosen to make a point, cites Bailey et al. (2015) on backtest
overfitting, and leaves the validation to the reader. This driver is that
validation, on NSE, with three questions:

1. What does the book's method report? (Best in-sample config, full period.)
2. What is the Probability of Backtest Overfitting of picking that way?
   (``strategy_metrics.probability_of_backtest_overfitting``, CSCV, S = 16.)
3. What happens if you optimise on the first half and trade the second?

Pre-specified
-------------
- Universe: the 50 most liquid NSE names, survivorship-free, screened on 2017
  liquidity; 2018-01-01 .. 2024-06-30, which stops before the reserved final
  test period. Trading starts after the longest SMA (300 sessions) is
  available, for every rule, so all configurations share one window.
- The book's grids for SMA. Momentum m in {1, 2, 3, 4, 5, 10, 20, 60, 120,
  250}. Mean reversion: SMA in {20, 25, 30, 43, 50}, threshold in {2.5, 5,
  7.5, 10}% of the SMA. The book's threshold is in price units (3.5 on GDX,
  7.5 on GLD), which does not transfer across stocks, so it is expressed
  relative to the SMA here.
- Long-short exactly as the book, and long-only (short -> flat), because
  overnight single-stock shorting is not available in Indian cash equities.
- Positions act on the NEXT day's return. Returns are simple (an equal
  weighted book earns simple returns; see Section 50); costs are 10 bp one
  way per unit of position change, so a long-to-short flip pays 20 bp.

Run::

    python tests/validation/run_technical_rules.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 50
WARMUP = 300
COST = 10.0 / 1e4
MIN_DAYS = 600
SMA1S, SMA2S = list(range(30, 50, 2)), list(range(200, 300, 2))
MOMS = [1, 2, 3, 4, 5, 10, 20, 60, 120, 250]
MR_SMAS, MR_THS = [20, 25, 30, 43, 50], [0.025, 0.05, 0.075, 0.10]
DEFAULTS = {"sma": "42/252", "mom": "3"}            # the book's first examples
OUT = os.path.join(_HERE, "technical_rules.csv")


def positions(close):
    """{family: (labels, T x K position matrix)} for one price series."""
    c = close.to_numpy(dtype=float)
    lr = np.log(close).diff().to_numpy()
    s = {w: close.rolling(w).mean().to_numpy()
         for w in set(SMA1S + SMA2S + MR_SMAS + [42, 252])}

    sma_lab, sma_pos = [], []
    for a in SMA1S:
        for b in SMA2S:
            sma_lab.append(f"{a}/{b}")
            sma_pos.append(np.where(s[a] > s[b], 1.0, -1.0))
    sma_lab.append("42/252")
    sma_pos.append(np.where(s[42] > s[252], 1.0, -1.0))

    mom_lab, mom_pos = [], []
    for m in MOMS:
        mom_lab.append(str(m))
        mom_pos.append(np.sign(pd.Series(lr).rolling(m).mean().to_numpy()))

    mr_lab, mr_pos = [], []
    for w in MR_SMAS:
        d = c / s[w] - 1.0
        for th in MR_THS:
            p = np.where(d > th, -1.0, np.nan)
            p = np.where(d < -th, 1.0, p)
            p = np.where(d * np.roll(d, 1) < 0, 0.0, p)
            p[0] = np.nan
            mr_lab.append(f"{w}/{th:.3f}")
            mr_pos.append(pd.Series(p).ffill().fillna(0.0).to_numpy())

    return {"sma": (sma_lab, np.column_stack(sma_pos)),
            "mom": (mom_lab, np.column_stack(mom_pos)),
            "mr": (mr_lab, np.column_stack(mr_pos))}


def strat_returns(pos, simple_next, logret_next):
    """Net simple, and gross log, returns of acting on ``pos`` the next day."""
    pos = np.where(np.isfinite(pos), pos, 0.0)
    turn = np.abs(np.diff(np.vstack([np.zeros((1, pos.shape[1])), pos]), axis=0))
    net = pos * simple_next[:, None] - COST * turn
    gross_log = pos * logret_next[:, None]
    return net, gross_log


def sharpe(x):
    sd = np.std(x, axis=0, ddof=1)
    return np.where(sd > 0, np.mean(x, axis=0) / np.where(sd > 0, sd, 1) * np.sqrt(252), np.nan)


def main():
    print("=" * 78)
    print("TECHNICAL RULES, OPTIMISED AND TESTED  (Hilpisch, Python for Algo Trading, Ch. 4)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()

    rows, pooled = [], {}
    used = 0
    for sym in px.columns:
        close = px[sym].dropna()
        if len(close) - WARMUP < MIN_DAYS:
            continue
        used += 1
        simple = close.pct_change().to_numpy()
        logret = np.log(close).diff().to_numpy()
        # Position decided at the close of t earns the return of t+1.
        nxt_s, nxt_l = np.roll(simple, -1)[WARMUP:-1], np.roll(logret, -1)[WARMUP:-1]
        idx = close.index[WARMUP + 1:]
        bh = nxt_s
        half = len(bh) // 2
        for fam, (labels, P) in positions(close).items():
            P = P[WARMUP:-1]
            for mode in ("long-short", "long-only"):
                Pm = P if mode == "long-short" else np.maximum(P, 0.0)
                net, gross_log = strat_returns(Pm, nxt_s, nxt_l)
                grid = slice(0, len(labels) - 1) if fam == "sma" else slice(None)
                g_net, g_log = net[:, grid], gross_log[:, grid]
                key = (fam, mode)
                pooled.setdefault(key, []).append(pd.DataFrame(g_net, index=idx))

                # 1. The book's method: best full-period GROSS performance.
                best = int(np.argmax(g_log.sum(axis=0)))
                is_gross = float(np.expm1(g_log[:, best].sum()))
                is_net = float(np.prod(1 + g_net[:, best]) - 1)
                bh_tot = float(np.prod(1 + bh) - 1)
                # 2. PBO of selecting by Sharpe across the grid.
                pbo = sm.probability_of_backtest_overfitting(g_net, n_blocks=16)
                # 3. Optimise on the first half (net Sharpe), trade the second.
                sr1 = sharpe(g_net[:half])
                sr2 = sharpe(g_net[half:])
                if not np.isfinite(sr1).any():          # a rule that never traded
                    sr1 = np.zeros_like(sr1)
                pick = int(np.nanargmax(np.where(np.isfinite(sr1), sr1, -np.inf)))
                rec = {"symbol": sym, "family": fam, "mode": mode,
                       "n_configs": g_net.shape[1],
                       "is_best": labels[best], "is_gross": is_gross,
                       "is_net": is_net, "bh_total": bh_tot,
                       "pbo": pbo["pbo"], "prob_oos_loss": pbo["prob_oos_loss"],
                       "split_pick": labels[pick], "split_is_sr": float(sr1[pick]),
                       "split_oos_sr": float(sr2[pick]),
                       "split_oos_median_sr": float(np.nanmedian(sr2)),
                       "bh_oos_sr": float(sharpe(bh[half:, None])[0])}
                if fam in DEFAULTS:
                    j = labels.index(DEFAULTS[fam])
                    rec["default_sr"] = float(sharpe(net[:, [j]])[0])
                    rec["bh_sr"] = float(sharpe(bh[:, None])[0])
                rows.append(rec)

    df = pd.DataFrame(rows)
    df.to_csv(OUT, index=False)
    print(f"\n  {used} names with at least {MIN_DAYS} trading days after a "
          f"{WARMUP}-session warm-up; 10 bp one way")

    print("\n" + "=" * 78)
    print("1. THE BOOK'S METHOD: best in-sample gross performance, full period")
    print("=" * 78)
    print(f"  {'rule':<6}{'mode':<12}{'configs':>8}{'best gross':>12}{'same, net':>11}"
          f"{'buy&hold':>10}{'best beats B&H':>16}")
    for (fam, mode), g in df.groupby(["family", "mode"], sort=False):
        print(f"  {fam:<6}{mode:<12}{int(g.n_configs.iloc[0]):8d}{g.is_gross.median():+12.0%}"
              f"{g.is_net.median():+11.0%}{g.bh_total.median():+10.0%}"
              f"{(g.is_net > g.bh_total).mean():16.0%}")
    print("  (medians across names; 'best beats B&H' is net of costs)")

    print("\n" + "=" * 78)
    print("2. PROBABILITY OF BACKTEST OVERFITTING (CSCV, 16 blocks, 12,870 splits)")
    print("=" * 78)
    print(f"  {'rule':<6}{'mode':<12}{'median PBO':>11}{'names > 0.5':>13}"
          f"{'pooled PBO':>12}{'pooled P(OOS loss)':>20}")
    summary = []
    for (fam, mode), g in df.groupby(["family", "mode"], sort=False):
        R = pd.concat(pooled[(fam, mode)], axis=0).groupby(level=0).mean().sort_index()
        pp = sm.probability_of_backtest_overfitting(R.to_numpy(), n_blocks=16)
        summary.append({"family": fam, "mode": mode, "median_pbo": g.pbo.median(),
                        "share_pbo_above_half": (g.pbo > 0.5).mean(),
                        "pooled_pbo": pp["pbo"], "pooled_prob_oos_loss": pp["prob_oos_loss"]})
        print(f"  {fam:<6}{mode:<12}{g.pbo.median():11.2f}{(g.pbo > 0.5).mean():13.0%}"
              f"{pp['pbo']:12.2f}{pp['prob_oos_loss']:20.0%}")
    print("  (pooled = each configuration applied to every name, equal weight)")

    print("\n" + "=" * 78)
    print("3. OPTIMISE ON THE FIRST HALF, TRADE THE SECOND  (annualised net Sharpe)")
    print("=" * 78)
    print(f"  {'rule':<6}{'mode':<12}{'pick, IS':>9}{'pick, OOS':>11}{'grid median OOS':>17}"
          f"{'buy&hold OOS':>14}{'pick > B&H':>12}")
    for (fam, mode), g in df.groupby(["family", "mode"], sort=False):
        print(f"  {fam:<6}{mode:<12}{g.split_is_sr.median():+9.2f}{g.split_oos_sr.median():+11.2f}"
              f"{g.split_oos_median_sr.median():+17.2f}{g.bh_oos_sr.median():+14.2f}"
              f"{(g.split_oos_sr > g.bh_oos_sr).mean():12.0%}")

    print("\n" + "=" * 78)
    print("4. THE BOOK'S DEFAULTS, NO SELECTION (SMA 42/252, momentum 3), full period")
    print("=" * 78)
    d = df.dropna(subset=["default_sr"])
    for (fam, mode), g in d.groupby(["family", "mode"], sort=False):
        diff = g.default_sr - g.bh_sr
        print(f"  {fam:<6}{mode:<12} net Sharpe median {g.default_sr.median():+.2f} vs buy&hold "
              f"{g.bh_sr.median():+.2f}; beats B&H on {(diff > 0).mean():.0%} of names")
    pd.DataFrame(summary).to_csv(OUT.replace(".csv", "_pbo.csv"), index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
