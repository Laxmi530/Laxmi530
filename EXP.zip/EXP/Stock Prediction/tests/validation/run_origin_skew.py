"""
How much did the forecast-origin ATR/range skew move the tree models' forecasts?

``direct_forecast.compute_origin_row`` built the origin row with
``_features_from_buffers`` from prices and volumes only, so ``atr_norm`` and
``range_pct`` at the origin were close-to-close proxies while every training
row (``create_features``) used high/low true range. On NSE daily bars the
served ``atr_norm`` was ~46% below the trained one (README §55). The fix
passes the bars; this driver measures what the skew had been worth.

For each name and each of 20 origins spread over 2020-2024 (before the
reserved period), it trains the 5-day direct XGBoost model exactly as
``ML_model.run_ML_prediction`` does, then predicts from the old origin row
(no OHLC passed) and the fixed one, and reports the change in the predicted
5-day return against the size of the predictions themselves.

Run::

    python tests/validation/run_origin_skew.py
"""

import os
import sys
import warnings

import numpy as np

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import ML_model as M                        # noqa: E402
from direct_forecast import (               # noqa: E402
    compute_origin_row, horizon_feature_cols, make_horizon_targets, training_frame)

SYMBOLS = ("RELIANCE", "TCS", "INFY")
H, ORIGINS = 5, 20


def main():
    print("=" * 78)
    print("FORECAST-ORIGIN SKEW: atr_norm / range_pct  (README §55)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel("2018-01-01", "2024-06-30", n=20, verbose=False)
    print(f"\n  {'symbol':<10}{'mean |pred|':>12}{'mean |change|':>15}{'change / |pred|':>17}"
          f"{'sign flips':>12}{'atr old/new':>13}")
    for sym in SYMBOLS:
        d = panel[panel.symbol == sym].sort_values("datetime").reset_index(drop=True)
        d = d[["datetime", "open", "high", "low", "close", "adj_close", "volume"]]
        ends = np.linspace(700, len(d) - 1, ORIGINS).astype(int)
        preds, changes, flips, ratios = [], [], 0, []
        for e in ends:
            df = d.iloc[max(0, e - 999):e + 1].reset_index(drop=True)
            feat = M.create_features(df, "daily")
            cols = horizon_feature_cols(feat)
            tgt = make_horizon_targets(feat, H)
            model, _ = M.train_generic_model(
                training_frame(feat, cols, tgt[H], f"target_h{H}"), f"target_h{H}", "xgboost")
            new_X, _, _ = compute_origin_row(df, cols, "daily")
            old_X, _, _ = compute_origin_row(df.drop(columns=["high", "low", "close"]), cols, "daily")
            p_new, p_old = float(model.predict(new_X)[0]), float(model.predict(old_X)[0])
            preds.append(abs(p_new))
            changes.append(abs(p_new - p_old))
            flips += int(np.sign(p_new) != np.sign(p_old))
            ratios.append(float(old_X["atr_norm"].iloc[0] / new_X["atr_norm"].iloc[0]))
        mp, mc = float(np.mean(preds)), float(np.mean(changes))
        print(f"  {sym:<10}{mp:12.4%}{mc:15.4%}{mc / mp:17.0%}{flips:9d}/{ORIGINS}"
              f"{np.mean(ratios):13.2f}")
    print("\n  'change' is |fixed - old| in the predicted 5-day log return.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
