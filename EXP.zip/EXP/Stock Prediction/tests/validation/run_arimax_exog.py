"""
ARIMAX regressors: what the model was, what it was meant to be, and the fix.

``ARIMAX_model`` passed its regressors to pmdarima as ``exogenous=``. pmdarima
2.x renamed that keyword ``X`` and silently swallows the old one, so the shipped
"ARIMAX" fitted no regressors: it was plain ARIMA on the same returns. Passing
them as written would not have been right either, because momentum, volatility,
RSI and range at bar t all contain r_t itself. This driver walk-forwards three
variants on the same origins:

    no regressors     what shipped (pmdarima ignored ``exogenous=``)
    same-bar          the regressors as originally written, now actually used:
                      r_t on bar-t statistics (contemporaneous)
    lagged (the fix)  r_t on bar t-1 statistics; calendar of bar t

and reports, per variant, RMSE against the random walk, the Diebold-Mariano
p-value, 95% band coverage and the band's mean half-width. 2019-2024-06 NSE
bhavcopy (before the reserved period), 5-day horizon.

Run::

    python tests/validation/run_arimax_exog.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import ARIMAX_model as am                  # noqa: E402
import backtest as bt                      # noqa: E402
import bhavcopy as bc                      # noqa: E402

START, END = "2018-01-01", "2024-06-30"
SYMBOLS = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC")
H, ORIGINS, MIN_TRAIN = 5, 24, 800
OUT = os.path.join(_HERE, "arimax_exog.csv")


def _same_bar_design(df, exog_cols):
    """The original (contemporaneous) design: r_t on bar-t statistics."""
    return df["log_return"], df[exog_cols].to_numpy(dtype=np.float64)


def _variant(name):
    """Return a predict_fn running ARIMAX under one regression design."""
    def fn(df, interval, horizon):
        if name == "no regressors":
            # Identical to the old fit, whose exogenous= keyword was ignored
            # (tests/test_arimax.py pins the equivalence).
            return am.run_arimax_prediction(df, interval, horizon, use_exog=False)
        saved = am._lagged_design
        if name == "same-bar":
            am._lagged_design = _same_bar_design
        try:
            return am.run_arimax_prediction(df, interval, horizon)
        finally:
            am._lagged_design = saved
    return fn


def main():
    print("=" * 78)
    print("ARIMAX REGRESSORS: none (shipped) vs same-bar vs lagged (fix)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=20, verbose=False)
    rows = []
    import io
    import contextlib
    for sym in SYMBOLS:
        d = panel[panel.symbol == sym].sort_values("datetime").reset_index(drop=True)
        d = d[["datetime", "open", "high", "low", "close", "adj_close", "volume"]]
        for name in ("no regressors", "same-bar", "lagged (fix)"):
            with contextlib.redirect_stdout(io.StringIO()):
                res = bt.walk_forward_backtest(
                    d, _variant(name), "1d", H, n_splits=ORIGINS, min_train=MIN_TRAIN,
                    verbose=False, strategy=False)
            s = res["summary"]
            per = res["per_split"]
            rows.append({"symbol": sym, "variant": name, "n": len(res["origins"]),
                         "rmse": float(s.loc["rmse", "model"]),
                         "rmse_naive": float(s.loc["rmse", "naive"]),
                         "dm_p": float(res["dm"]["p_value"]),
                         "dm_stat": float(res["dm"]["stat"]),
                         "coverage": float(per["coverage"].mean())})
            r = rows[-1]
            print(f"  {sym:<9}{name:<15} n={r['n']:2d}  RMSE/naive {r['rmse'] / r['rmse_naive']:.3f}"
                  f"  DM p {r['dm_p']:.3f}  coverage {r['coverage']:.1%}", flush=True)
    t = pd.DataFrame(rows)
    t.to_csv(OUT, index=False)
    t["ratio"] = t.rmse / t.rmse_naive
    print("\n  pooled over names:")
    for name, g in t.groupby("variant", sort=False):
        print(f"    {name:<15} median RMSE/naive {g.ratio.median():.3f}   "
              f"mean coverage {g.coverage.mean():.1%}   "
              f"names with DM p<0.10: {(g.dm_p < 0.10).sum()} "
              f"({', '.join(g.symbol[(g.dm_p < 0.10)].tolist()) or '-'})")
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
