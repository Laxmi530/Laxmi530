"""
Scheduled market-wide events on NSE: do they break the cone the way results
days do?  (Benklifa, *Think Like an Option Trader*, Ch. 5, "known unknowns".)

README section 64 measured results days: a 95% band that ignores them covered
82-93% of the windows holding one. Three other events have public dates and
unknown outcomes, and they hit every stock at once:

* **Union Budget** speeches: 2018-02-01, 2019-02-01 (interim), 2019-07-05,
  2020-02-01 (a Saturday special session; the bhavcopy cache walks weekdays,
  so its move lands in the 2020-02-03 return, which is then that event's
  session), 2021-02-01, 2022-02-01, 2023-02-01, 2024-02-01 (interim).
* **RBI monetary policy** decisions, scheduled meetings only. The 2019-20,
  2021-22 and 2023-24 dates were checked against RBI's published schedules;
  2022-02-10 is the rescheduled date (a holiday moved it a day). The
  unscheduled moves (2020-03-27, 2020-05-22, 2022-05-04) are excluded: nobody
  could know them in advance, so no forecast could widen for them.
* **Monthly F&O expiry**: the last Thursday of each month, or the session
  before it when that Thursday is a holiday (the stock-derivative rule in force
  throughout 2018-2024).

Same pre-registration as run_results_days.py: event sessions day0 (first
session on or after the date) and day1; z = return / one-step EWMA sigma;
E[z^2] fitted on 2018-2021 and checked on 2022 to mid-2024; then the coverage
of a 95% band with and without each event in the window, plain and widened.
An event is worth adding to the app only if its plain coverage falls clearly
short of 95% and the widening restores it out of sample.

Run::

    python tests/validation/run_market_events.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                       # noqa: E402
from run_results_days import name_frame, windows, FIT_END, TEST_START, START, END  # noqa: E402

BUDGET = ["2018-02-01", "2019-02-01", "2019-07-05", "2020-02-01", "2021-02-01",
          "2022-02-01", "2023-02-01", "2024-02-01"]
RBI = ["2018-02-07", "2018-04-05", "2018-06-06", "2018-08-01", "2018-10-05", "2018-12-05",
       "2019-02-07", "2019-04-04", "2019-06-06", "2019-08-07", "2019-10-04", "2019-12-05",
       "2020-02-06", "2020-08-06", "2020-10-09", "2020-12-04",
       "2021-02-05", "2021-04-07", "2021-06-04", "2021-08-06", "2021-10-08", "2021-12-08",
       "2022-02-10", "2022-04-08", "2022-06-08", "2022-08-05", "2022-09-30", "2022-12-07",
       "2023-02-08", "2023-04-06", "2023-06-08", "2023-08-10", "2023-10-06", "2023-12-08",
       "2024-02-08", "2024-04-05", "2024-06-07"]
HORIZONS = (1, 5)
OUT = os.path.join(_HERE, "market_events.csv")


def expiry_days(sessions):
    """Last Thursday of each month, or the last session before it if it was shut."""
    s = pd.DatetimeIndex(sorted(sessions))
    out = []
    for (y, m), _ in pd.Series(s, index=s).groupby([s.year, s.month]):
        last_day = pd.Timestamp(year=y, month=m, day=1) + pd.offsets.MonthEnd(0)
        thu = last_day - pd.Timedelta(days=(last_day.dayofweek - 3) % 7)
        prior = s[s <= thu]
        if len(prior):
            out.append(prior[-1])
    return out


def main():
    print("=" * 78)
    print("SCHEDULED MARKET EVENTS ON NSE  (Benklifa Ch. 5: known unknowns)")
    print("=" * 78)
    panel, _ = bc.build_panel(START, END, n=200, verbose=False)
    sessions = pd.to_datetime(panel["datetime"]).unique()
    events = {"budget": pd.to_datetime(BUDGET), "rbi": pd.to_datetime(RBI),
              "expiry": pd.DatetimeIndex(expiry_days(sessions))}
    print(f"  {panel.symbol.nunique()} names; events: " +
          ", ".join(f"{k} {len(v)}" for k, v in events.items()))

    rows = []
    for kind, dates in events.items():
        frames = [name_frame(g, dates) for _, g in panel.groupby("symbol") if len(g) >= 500]
        allz = pd.concat(frames)
        allz["z2"] = (allz.r / allz.sigma) ** 2
        print(f"\n  {kind.upper()}: E[z^2] (ordinary day ~ 1)")
        k = {}
        for lab, part in (("2018-2021", allz[allz.index <= FIT_END]),
                          ("2022-2024", allz[allz.index >= TEST_START])):
            e0, e1 = part[part.day0].z2.mean(), part[part.day1].z2.mean()
            o = part[~part.day0 & ~part.day1].z2.mean()
            lo, hi = (pd.Timestamp(START), FIT_END) if lab == "2018-2021" else (TEST_START, pd.Timestamp(END))
            n_ev = int(((dates >= lo) & (dates <= hi)).sum())     # calendar events, not per-name sessions
            print(f"    {lab}: day0 {e0:5.2f}   day1 {e1:5.2f}   other {o:5.2f}   ({n_ev} events)")
            if lab == "2018-2021":
                k = {"k0": e0 / o, "k1": e1 / o}
        print(f"    fitted: k_day0 {k['k0']:.2f}, k_day1 {k['k1']:.2f}")
        for h in HORIZONS:
            W = pd.concat([windows(f, h, k["k0"], k["k1"]) for f in frames])
            tr, te = W[W.origin <= FIT_END], W[W.origin >= TEST_START]
            q = np.quantile(np.abs(tr.u), 0.95)
            qa = np.quantile(np.abs(tr.u_adj), 0.95)
            ev, ne = te[te.event], te[~te.event]
            rec = {"event": kind, "h": h, "k0": k["k0"], "k1": k["k1"], "n_event": len(ev),
                   "cov_event_plain": float(np.mean(np.abs(ev.u) <= q)),
                   "cov_event_widened": float(np.mean(np.abs(ev.u_adj) <= qa)),
                   "cov_none_plain": float(np.mean(np.abs(ne.u) <= q))}
            rows.append(rec)
            print(f"    h={h}: windows with the event {len(ev):,}: plain {rec['cov_event_plain']:.1%}, "
                  f"widened {rec['cov_event_widened']:.1%}; without: plain {rec['cov_none_plain']:.1%}")
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
