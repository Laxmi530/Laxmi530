"""
Long memory on NSE, and the book's crash-warning claim.

Mariani & Florescu, *Quantitative Finance*, Ch. 12.5 / 13.4, estimate a
Hurst exponent by rescaled range (R/S) and a DFA exponent on integrated
ABSOLUTE log returns, read values above 0.5 as persistence that "enables
prediction", and state (p. 357): "We estimate the Hurst parameter (H) as
well as the Detrended Fluctuation parameter (alpha) and we compare with 0.5.
The further these parameters are from 0.5, the stronger the evidence of a
crash event waiting to happen." Their tables report H 0.56-0.70 and alpha
0.57-0.83 on tick data around crash weeks.

Two questions, answered with ``long_memory``:

1. What do these estimators read on NSE returns, and what do they read on a
   SHUFFLED copy of the same returns (same distribution, every kind of
   memory destroyed)? The shuffled value is the real "0.5" to compare with.
2. Does distance from 0.5 warn of crashes? Pre-specified: every 21 sessions,
   for each name with a full trailing 250-session window, compute the
   book's |H - 0.5| (classical R/S) and |alpha - 0.5| (DFA on |returns|);
   the outcome is the worst drawdown over the next 21 sessions. Rank IC by
   date, Fama-MacBeth t (non-overlapping months), and the same after
   controlling for trailing 60-day volatility, which the |returns| DFA
   partly measures. Two signals, so the bar is Bonferroni |t| > 2.24.

200 names, survivorship-free, 2018-01-01 .. 2024-06-30, before the reserved
period.

Run::

    python tests/validation/run_long_memory.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import long_memory as lm           # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 200
WINDOW, STEP, AHEAD, VOLWIN = 250, 21, 21, 60
T_BAR = 2.24
OUT = os.path.join(_HERE, "long_memory.csv")


def rank_slope(y, X):
    z = pd.concat([y.rename("y"), X], axis=1).dropna().rank(pct=True)
    if len(z) < 30:
        return np.nan
    A = np.column_stack([np.ones(len(z)), z.drop(columns="y").to_numpy()])
    b, *_ = np.linalg.lstsq(A, z["y"].to_numpy(), rcond=None)
    return float(b[1])


def main():
    print("=" * 78)
    print("LONG MEMORY ON NSE, AND THE CRASH-WARNING CLAIM  (Mariani & Florescu, Ch. 12-13)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close",
                           aggfunc="last").sort_index()
    R = np.log(px / px.shift(1))

    # ------------------------------------------------ 1. full-sample readings
    rng = np.random.default_rng(0)
    rows = []
    for sym in R.columns:
        r = R[sym].dropna().to_numpy()
        if len(r) < 1000:
            continue
        sh = rng.permutation(r)
        lo = lm.lo_modified_rs(r)
        rows.append({"symbol": sym,
                     "book_H": lm.rs_hurst(r)["H"], "book_H_shuffled": lm.rs_hurst(sh)["H"],
                     "corrected_H": lm.rs_hurst(r, corrected=True)["H"],
                     "lo_V": lo["V"], "lo_reject": lo["reject_5pct"],
                     "dfa_returns": lm.dfa(r)["alpha"],
                     "book_dfa_abs": lm.dfa(r, abs_input=True)["alpha"],
                     "book_dfa_abs_shuffled": lm.dfa(sh, abs_input=True)["alpha"],
                     "dfa_abs_demeaned": lm.dfa(np.abs(r))["alpha"]})
    f = pd.DataFrame(rows)
    print(f"\n1. FULL-SAMPLE READINGS on {len(f)} names (median across names)")
    print(f"   {'':34}{'returns':>10}{'same, shuffled':>17}")
    print(f"   {'book R/S Hurst':34}{f.book_H.median():10.3f}{f.book_H_shuffled.median():17.3f}")
    print(f"   {'Anis-Lloyd-Peters corrected H':34}{f.corrected_H.median():10.3f}")
    print(f"   {'standard DFA of returns':34}{f.dfa_returns.median():10.3f}")
    print(f"   {'book DFA of |returns|':34}{f.book_dfa_abs.median():10.3f}{f.book_dfa_abs_shuffled.median():17.3f}")
    print(f"   {'standard DFA of |returns|':34}{f.dfa_abs_demeaned.median():10.3f}")
    print(f"   Lo's modified R/S rejects 'no long memory' in returns for "
          f"{f.lo_reject.mean():.0%} of names (5% expected by chance); "
          f"median V {f.lo_V.median():.2f} (band 0.809-1.862)")
    f.to_csv(OUT, index=False)

    # ------------------------------------------------ 2. the crash claim
    dd_fwd = pd.DataFrame(index=px.index, columns=px.columns, dtype=float)
    vals = px.to_numpy()
    for i in range(len(px) - AHEAD):
        seg = vals[i:i + AHEAD + 1]
        peak = np.fmax.accumulate(seg, axis=0)
        dd_fwd.iloc[i] = np.nanmin(seg / peak - 1.0, axis=0)
    vol = R.rolling(VOLWIN).std()
    ic = {"H": [], "alpha": [], "vol": []}
    part = {"H": [], "alpha": []}
    dates = range(WINDOW, len(px) - AHEAD, STEP)
    for i in dates:
        win = R.iloc[i - WINDOW + 1:i + 1]
        ok = win.notna().sum() >= WINDOW - 5
        if ok.sum() < 30:
            continue
        sigH, sigA = {}, {}
        for sym in win.columns[ok]:
            x = win[sym].dropna().to_numpy()
            sigH[sym] = abs(lm.rs_hurst(x)["H"] - 0.5)
            sigA[sym] = abs(lm.dfa(x, abs_input=True)["alpha"] - 0.5)
        sH, sA = pd.Series(sigH), pd.Series(sigA)
        crash = -dd_fwd.iloc[i].reindex(sH.index)          # bigger = worse drawdown
        v = vol.iloc[i].reindex(sH.index)
        for k, s in (("H", sH), ("alpha", sA), ("vol", v)):
            z = pd.concat([s, crash], axis=1).dropna()
            ic[k].append(z.iloc[:, 0].corr(z.iloc[:, 1], method="spearman"))
        part["H"].append(rank_slope(crash, pd.concat([sH.rename("s"), v.rename("v")], axis=1)))
        part["alpha"].append(rank_slope(crash, pd.concat([sA.rename("s"), v.rename("v")], axis=1)))

    print(f"\n2. DOES DISTANCE FROM 0.5 WARN OF A CRASH?  {len(ic['H'])} monthly cross-sections")
    print("   (outcome: worst drawdown over the next 21 sessions; positive = the claim's sign)")
    res = []
    for k, label in (("H", "|H - 0.5|, book R/S"), ("alpha", "|alpha - 0.5|, book DFA |r|"),
                     ("vol", "trailing 60-day volatility (reference)")):
        fm = sm.fama_macbeth_ic(pd.Series(ic[k]).dropna(), lags=1)
        line = f"   {label:<40} rank IC {fm['mean_ic']:+.4f}  t {fm['t_stat']:+.2f}"
        rec = {"signal": label, "ic": fm["mean_ic"], "t": fm["t_stat"]}
        if k in part:
            fp = sm.fama_macbeth_ic(pd.Series(part[k]).dropna(), lags=1)
            line += f"   | beyond volatility: {fp['mean_ic']:+.4f}  t {fp['t_stat']:+.2f}"
            line += "   PASS" if abs(fp["t_stat"]) > T_BAR and fp["mean_ic"] > 0 else "   fail"
            rec.update(partial=fp["mean_ic"], partial_t=fp["t_stat"])
        res.append(rec)
        print(line)
    print(f"   bar: positive and |t| > {T_BAR} beyond volatility (Bonferroni, two signals)")

    # ------------------------------------------------ 3. post-hoc controls
    # Added after section 2 passed, so diagnostics, not tests. A 250-day
    # exponent can be another risk measure in disguise: longer-window
    # volatility, the volatility of volatility, the past year's trend or its
    # worst drawdown. If the signal survives all of them, it carries
    # something they do not.
    v250 = R.rolling(WINDOW).std()
    vov = R.rolling(20).std().rolling(WINDOW).std()
    ret250 = px / px.shift(WINDOW) - 1.0
    dd250 = px / px.rolling(WINDOW).max() - 1.0
    full = {"H": [], "alpha": []}
    for i in dates:
        win = R.iloc[i - WINDOW + 1:i + 1]
        ok = win.notna().sum() >= WINDOW - 5
        if ok.sum() < 30:
            continue
        names = win.columns[ok]
        sH = pd.Series({s: abs(lm.rs_hurst(win[s].dropna().to_numpy())["H"] - 0.5) for s in names})
        sA = pd.Series({s: abs(lm.dfa(win[s].dropna().to_numpy(), abs_input=True)["alpha"] - 0.5)
                        for s in names})
        crash = -dd_fwd.iloc[i].reindex(names)
        ctrl = pd.concat([vol.iloc[i].rename("v60"), v250.iloc[i].rename("v250"),
                          vov.iloc[i].rename("vov"), ret250.iloc[i].rename("r250"),
                          dd250.iloc[i].rename("dd250")], axis=1).reindex(names)
        for k, s in (("H", sH), ("alpha", sA)):
            full[k].append(rank_slope(crash, pd.concat([s.rename("s"), ctrl], axis=1)))
    print("\n3. POST-HOC: beyond 60- AND 250-day volatility, vol-of-vol, the past year's return")
    print("   and its drawdown (diagnostics added after section 2)")
    for k, label in (("H", "|H - 0.5|, book R/S"), ("alpha", "|alpha - 0.5|, book DFA |r|")):
        fp = sm.fama_macbeth_ic(pd.Series(full[k]).dropna(), lags=1)
        print(f"   {label:<40} coef {fp['mean_ic']:+.4f}  t {fp['t_stat']:+.2f}")
        for rec in res:
            if rec["signal"] == label:
                rec.update(all_controls=fp["mean_ic"], all_controls_t=fp["t_stat"])
    pd.DataFrame(res).to_csv(OUT.replace(".csv", "_crash.csv"), index=False)
    print(f"\n   wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
