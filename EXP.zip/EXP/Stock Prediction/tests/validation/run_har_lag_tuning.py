"""
Does tuning HAR-RV's lags help? Re-measured with an untouched holdout.

README "Does tuning HAR-RV's lags help?" ran ``tuning.nested_search`` over five
HAR lag sets. Its holdout call handed ``qlike_objective_har`` the whole history,
and the objective spread its five origins over the back half of whatever it was
given, so two of the five "holdout" origins sat inside the 70% the search was
tuned on. ``nested_search`` now passes ``score_from=cut``. This driver runs the
search per name and prints both holdout scores: the old (contaminated) one and
the fixed one, on the same data.

NSE bhavcopy, the last 1,000 sessions before 2024-07-01 (before the reserved
period); 700 inner rows, 300 untouched.

Run::

    python tests/validation/run_har_lag_tuning.py
"""

import os
import sys
import warnings

import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import tuning as tn                         # noqa: E402

SYMBOLS = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC")
ROWS = 1000
OUT = os.path.join(_HERE, "har_lag_tuning.csv")


def main():
    print("=" * 78)
    print("HAR-RV LAG TUNING, NESTED  (README §27)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel("2019-06-01", "2024-06-30", n=20, verbose=False)
    space = {"lags": tn.suggest_spaces()["har_rv"]["lags"]}
    rows = []
    print(f"\n  {'symbol':<10}{'winner':<13}{'default':>10}{'tuned':>10}{'delta':>10}"
          f"{'old tuned':>11}{'old delta':>11}")
    for sym in SYMBOLS:
        d = panel[panel.symbol == sym].sort_values("datetime").tail(ROWS)
        d = d[["datetime", "adj_close"]].reset_index(drop=True)
        res = tn.nested_search(d, space, tn.qlike_objective_har, method="grid",
                               holdout_frac=0.30, verbose=False)
        # The old holdout: the same configs scored over the back half of the
        # whole frame, i.e. without score_from.
        old_t = tn.qlike_objective_har(d, res["best_config"])
        old_b = tn.qlike_objective_har(d, res["default_config"])
        rows.append({"symbol": sym, "winner": str(res["best_config"]["lags"]),
                     "holdout_default": res["holdout_score_default"],
                     "holdout_tuned": res["holdout_score_tuned"],
                     "delta": res["improvement"],
                     "old_default": old_b, "old_tuned": old_t, "old_delta": old_t - old_b})
        r = rows[-1]
        print(f"  {sym:<10}{r['winner']:<13}{r['holdout_default']:10.5f}{r['holdout_tuned']:10.5f}"
              f"{r['delta']:+10.5f}{r['old_tuned']:11.5f}{r['old_delta']:+11.5f}")
    t = pd.DataFrame(rows)
    t.to_csv(OUT, index=False)
    print(f"\n  generalises (delta > 0): {(t.delta > 0).sum()} of {len(t)}; "
          f"under the old holdout: {(t.old_delta > 0).sum()} of {len(t)}")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
