"""
Is a stock's crash risk persistent, beyond what its volatility already says?

Karasan, *Machine Learning for Financial Risk Management with Python*, Ch. 9,
measures stock-price crash risk with the literature's three standard measures
(Chen, Hong & Stein 2001; Kim, Li & Zhang 2011), all computed on a year of
weekly FIRM-SPECIFIC returns:

    NCSKEW  negative skewness: higher = a fatter left tail
    DUVOL   log ratio of down-week to up-week variance
    CRASH   1 if any week falls 3.09 sd below the year's mean

The book then explains crashes with governance and accounting variables this
project does not have. The question that needs only prices, and that decides
whether crash risk belongs in this product's risk panel, is narrower: does
this year's crash risk predict next year's, once next year's VOLATILITY,
which the app already forecasts, is accounted for? Skewness from 50 weekly
returns is a noisy estimate, and a noisy estimate of something persistent can
still be useful. A noisy estimate of nothing is not.

Pre-specified
-------------
- Universe: 400 names, survivorship-free, screened on 2017 liquidity.
- Weekly log returns (Wednesday close). The market is the equal-weighted
  universe return. Firm-specific return = ln(1 + residual) from
  r_i = a + sum_{k=-2..2} b_k m_{t+k}, fitted per stock-year. Lead weeks
  falling in the next year are dropped, so year t's measures use nothing from
  t+1.
- Calendar years 2018..2023, at least 40 weeks: five year-to-year pairs.
  2024 is excluded, because its second half is inside the reserved final test
  period.
- Controls (year t): SIGMA (sd of firm-specific returns), RET (their sum),
  SIZE (log median daily traded value).
- Test: a cross-sectional regression on ranks, per pair, of rank(Y_{t+1}) on
  rank(NCSKEW_t) and the controls, averaged Fama-MacBeth style. With five
  cross-sections the 5% critical t is 2.78 (4 df). Crash risk counts as
  persistent beyond volatility only if the NCSKEW_t coefficient has the same
  sign in all five pairs AND |t| > 2.78.

Run::

    python tests/validation/run_crash_risk.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402

START, END, N = "2018-01-01", "2023-12-31", 400
YEARS = range(2018, 2024)
MIN_WEEKS, CRASH_Z, T_CRIT = 40, 3.09, 2.78
OUT = os.path.join(_HERE, "crash_risk.csv")


def ncskew(w):
    """Negative coefficient of skewness (Chen, Hong & Stein 2001)."""
    w = np.asarray(w, dtype=float)
    w = w - w.mean()
    n = len(w)
    den = (n - 1) * (n - 2) * (w @ w) ** 1.5
    return float(-(n * (n - 1) ** 1.5 * (w ** 3).sum()) / den) if den > 0 else np.nan


def duvol(w):
    """Log of down-week to up-week variance, each scaled by its own count."""
    w = np.asarray(w, dtype=float)
    d, u = w[w < w.mean()], w[w >= w.mean()]
    if len(d) < 2 or len(u) < 2:
        return np.nan
    return float(np.log(((len(u) - 1) * (d - w.mean()) @ (d - w.mean()))
                        / ((len(d) - 1) * (u - w.mean()) @ (u - w.mean()))))


def crash(w):
    """1 if any week is more than CRASH_Z sd below the year's mean."""
    w = np.asarray(w, dtype=float)
    return float((w < w.mean() - CRASH_Z * w.std(ddof=1)).any())


def firm_specific(r, m, year):
    """ln(1 + residual) of the expanded market model, within ``year`` only."""
    X = pd.concat({f"m{k}": m.shift(-k) for k in (-2, -1, 0, 1, 2)}, axis=1)
    df = pd.concat([r.rename("r"), X], axis=1)
    df = df[(df.index.year == year)]
    # Leads that land in the next year would leak it into this year's measure.
    df = df[(df.index + pd.Timedelta(weeks=2)).year == year].dropna()
    if len(df) < MIN_WEEKS:
        return None
    A = np.column_stack([np.ones(len(df)), df.drop(columns="r").to_numpy()])
    beta, *_ = np.linalg.lstsq(A, df["r"].to_numpy(), rcond=None)
    e = df["r"].to_numpy() - A @ beta
    return np.log1p(e)


def rank_regression(d, y, xs):
    """OLS of rank(y) on ranks of xs; returns coefficients and t-stats."""
    z = d[[y] + xs].rank(pct=True).dropna()
    A = np.column_stack([np.ones(len(z))] + [z[x] for x in xs])
    b, *_ = np.linalg.lstsq(A, z[y].to_numpy(), rcond=None)
    e = z[y].to_numpy() - A @ b
    s2 = e @ e / (len(z) - A.shape[1])
    se = np.sqrt(np.diag(s2 * np.linalg.inv(A.T @ A)))
    return dict(zip(xs, b[1:])), dict(zip(xs, (b / se)[1:])), len(z)


def main():
    print("=" * 78)
    print("CRASH RISK PERSISTENCE  (Karasan, ML for Financial Risk Mgmt, Ch. 9)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    tv = (panel.assign(tv=panel["close"] * panel["volume"])
          .pivot_table(index="datetime", columns="symbol", values="tv", aggfunc="last"))
    wk = np.log(px.resample("W-WED").last()).diff()
    mkt = wk.mean(axis=1)

    rows = []
    for sym in wk.columns:
        for y in YEARS:
            w = firm_specific(wk[sym], mkt, y)
            if w is None:
                continue
            t = tv.loc[tv.index.year == y, sym].dropna()
            rows.append({"symbol": sym, "year": y, "ncskew": ncskew(w),
                         "duvol": duvol(w), "crash": crash(w),
                         "sigma": float(w.std(ddof=1)), "ret": float(w.sum()),
                         "size": float(np.log(t[t > 0].median())) if (t > 0).any() else np.nan})
    m = pd.DataFrame(rows)
    print(f"\n  {len(m)} stock-years, {m.symbol.nunique()} names, years "
          f"{min(YEARS)}..{max(YEARS)}")
    print(f"  CRASH rate {m.crash.mean():.1%} of stock-years; mean NCSKEW "
          f"{m.ncskew.mean():+.3f}, mean DUVOL {m.duvol.mean():+.3f}")

    nxt = m.copy()
    nxt["year"] -= 1
    pairs = m.merge(nxt, on=["symbol", "year"], suffixes=("", "_next"))

    # ---------------------------------------- 1. raw year-to-year persistence
    print("\n" + "=" * 78)
    print("1. RAW PERSISTENCE: Spearman(measure in t, same measure in t+1)")
    print("=" * 78)
    print(f"  {'pair':<11}{'n':>5}{'NCSKEW':>9}{'DUVOL':>9}{'SIGMA':>9}")
    raw = []
    for y, g in pairs.groupby("year"):
        r = {v: g[v].corr(g[f"{v}_next"], method="spearman")
             for v in ("ncskew", "duvol", "sigma")}
        raw.append(r)
        print(f"  {y}->{y + 1:<6}{len(g):5d}{r['ncskew']:+9.3f}{r['duvol']:+9.3f}"
              f"{r['sigma']:+9.3f}")
    raw = pd.DataFrame(raw)
    print(f"  {'mean':<11}{'':5}{raw.ncskew.mean():+9.3f}{raw.duvol.mean():+9.3f}"
          f"{raw.sigma.mean():+9.3f}")

    # ---------------------------------------- 2. beyond volatility
    print("\n" + "=" * 78)
    print("2. BEYOND VOLATILITY: rank regression, NCSKEW_t coefficient per pair")
    print("=" * 78)
    controls = ["sigma", "ret", "size"]
    out = []
    print(f"  {'outcome':<12}{'controls':<20}" + "".join(f"{f'{y % 100}->{(y + 1) % 100}':>9}" for y in YEARS[:-1])
          + f"{'FM mean':>9}{'FM t':>7}{'verdict':>10}")
    specs = [("ncskew_next", []), ("ncskew_next", controls),
             ("duvol_next", controls), ("crash_next", controls),
             ("sigma_next", controls)]
    for yv, cs in specs:
        coefs = []
        for y, g in pairs.groupby("year"):
            b, t, n = rank_regression(g, yv, ["ncskew"] + cs)
            coefs.append(b["ncskew"])
        c = np.array(coefs)
        fm_t = c.mean() / (c.std(ddof=1) / np.sqrt(len(c)))
        same = (np.sign(c) == np.sign(c.mean())).all()
        ok = same and abs(fm_t) > T_CRIT
        label = "+".join(cs) if cs else "none"
        print(f"  {yv.replace('_next', ''):<12}{label:<20}"
              + "".join(f"{x:+9.3f}" for x in c)
              + f"{c.mean():+9.3f}{fm_t:+7.2f}{'PASS' if ok else 'fail':>10}")
        out.append({"outcome": yv, "controls": label, "fm_mean": c.mean(),
                    "fm_t": fm_t, "same_sign": bool(same), "passes": bool(ok),
                    **{f"coef_{y}": x for y, x in zip(YEARS, c)}})

    # ---------------------------------------- 3. what a user would see
    print("\n" + "=" * 78)
    print("3. CRASH INCIDENCE NEXT YEAR, by quintile of NCSKEW this year")
    print("=" * 78)
    pairs["q"] = pairs.groupby("year")["ncskew"].transform(
        lambda s: pd.qcut(s.rank(method="first"), 5, labels=False) + 1)
    tab = pairs.groupby("q").agg(n=("crash_next", "size"),
                                 crash_next=("crash_next", "mean"),
                                 sigma_next=("sigma_next", "mean"))
    for q, r in tab.iterrows():
        q = int(q)
        tag = " (least crash-prone)" if q == 1 else " (most crash-prone)" if q == 5 else ""
        print(f"  Q{q}{tag:<22}{int(r.n):5d} stock-years   crash next year "
              f"{r.crash_next:6.1%}   sigma next {r.sigma_next:.4f}")

    pd.DataFrame(out).to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
