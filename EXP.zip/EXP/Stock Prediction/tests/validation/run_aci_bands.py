"""
Adaptive conformal (ACI) for the per-step conformal bands: does it hold 95%
when the market changes, where a fixed quantile does not?

Eleven of the app's models (the six neural nets, XGBoost, LightGBM, Stacking,
Hybrid, Kalman) set their 95% band from a block of recent calibration errors
and take a fixed quantile of it: ``ceil((m+1)*0.95)/m`` of about 190 errors
for daily data (20% of the 1,000-row cap). A fixed quantile of the last nine
months is right on average and wrong exactly when volatility has just changed.
HAR-RV and Vol-LSTM already adapt (``aci_quantile``, Gibbs & Candes 2021).

The bands are quantiles of ``|log(actual / forecast)|``, and README §11 and
§70 found the point forecasts sit on the random walk, so the calibration
errors are measured here with the naive forecast: the score of the window
from session j is ``|log(P[j+h] / P[j])|``. That makes the test cheap enough
for 200 names and every session, and it isolates the one thing that changes,
the quantile rule. (A model whose forecast moves off the random walk has
somewhat different errors; the rule is the same.)

Pre-registered, on the survivorship-free bhavcopy panel (200 names, screened
on 2017-01..2017-07), sessions 2018-07-01 .. 2024-12-31, before the reserved
period:

* At each origin t and horizon h in (1, 5, 10): the stream is the scores of
  the M = 190 most recent windows fully realised by t (j + h <= t), oldest
  first. Arms: STATIC, the conformal quantile above (as in
  ``direct_forecast.conformal_halfwidth``); ACI with gamma in (0.005, 0.01,
  0.05), 0.05 being HAR-RV's. Covered when ``|log(P[t+h]/P[t])|`` <= the
  half-width.
* Volatility shift at t: the sd of the last 20 one-session returns over the
  sd of the returns spanned by the stream. Quintile breakpoints are fixed on
  the selection period.
* Primary metric, CC: the mean over the five shift quintiles of
  ``|coverage - 0.95|``; a band right on average and wrong in both tails of
  the shift has a large CC.
* gamma is chosen on 2018-07 .. 2021-12 (which holds the 2020 crash) by CC at
  h = 5, then scored once on 2022-01 .. 2024-12.
* Ship in the eleven models only if, on 2022-2024 at h = 5, (1) CC improves
  with a 95% block-bootstrap interval (calendar months resampled, 2,000
  draws) that excludes zero, (2) overall ``|coverage - 0.95|`` is no worse
  than static's by more than 0.5 points, and (3) the mean width is no more
  than 15% wider.
* Reported, not used for the decision: coverage by year, in the 2020 crash
  (origins 2020-02-15 .. 2020-05-31), the worst calendar month, months below
  85%, and windows holding a results day (calendar to 2024-06).

Run::

    python tests/validation/run_aci_bands.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
from model_utils import aci_quantile        # noqa: E402

START, END = "2017-07-03", "2024-12-31"
LOOKBACK_DAYS, MIN_DAYS = 180, 100          # the cache starts 2017-01
N = 200
M = 190
HORIZONS = (1, 5, 10)
GAMMAS = (0.005, 0.01, 0.05)
TEST_FROM = pd.Timestamp("2018-07-01")
SELECT_END = pd.Timestamp("2021-12-31")
CONFIRM_FROM = pd.Timestamp("2022-01-01")
CRASH = (pd.Timestamp("2020-02-15"), pd.Timestamp("2020-05-31"))
CAL_END = pd.Timestamp("2024-06-30")        # results calendar coverage
STATIC_Q = min(1.0, np.ceil((M + 1) * 0.95) / M)
N_BOOT = 2000
CAL_FILE = os.path.join(_HERE, "results_calendar_2018_2024.csv")
OUT = os.path.join(_HERE, "aci_bands.csv")
OUT_DETAIL = os.path.join(_HERE, "aci_bands_detail.csv")


def name_windows(dates, logp, h, events):
    """One row per origin: realised |R_h|, every arm's half-width, shift, event flag."""
    n = len(logp)
    R = logp[h:] - logp[:-h]                 # R[j] = window from session j
    a = np.abs(R)
    r1 = np.diff(logp)                       # r1[k] = return into session k+1
    t0 = max(h + M - 1, 20)
    ts = np.arange(t0, n - h)
    if len(ts) == 0:
        return None
    streams = sliding_window_view(a, M)[ts - h - M + 1]     # windows j = t-h-M+1 .. t-h
    out = {"origin": dates[ts], "score": a[ts]}
    out["static"] = np.quantile(streams, STATIC_Q, axis=1)
    for g in GAMMAS:
        out[f"aci_{g}"] = aci_quantile(streams, gamma=g)
    # Recent sd over the stream's sd: returns into sessions t-19..t vs those it spans.
    rv = sliding_window_view(r1, 20)[ts - 20]
    span = M + h - 1
    lv = sliding_window_view(r1, span)[ts - span]
    out["shift"] = rv.std(axis=1, ddof=1) / lv.std(axis=1, ddof=1)
    if events is not None:
        ev = np.zeros(n)
        k = np.searchsorted(dates, events)
        for kk in (k, k + 1):                # day0 and day1
            kk = kk[kk < n]
            ev[kk] = 1.0
        ce = np.r_[0.0, np.cumsum(ev)]
        out["event"] = (ce[ts + h + 1] - ce[ts + 1]) > 0
    else:
        out["event"] = np.zeros(len(ts), bool)
    return pd.DataFrame(out)


def arms():
    return ["static"] + [f"aci_{g}" for g in GAMMAS]


def cc(df, arm, edges):
    q = np.digitize(df["shift"], edges)
    cov = df["score"] <= df[arm]
    per = [cov[q == i].mean() for i in range(5) if (q == i).any()]
    return float(np.mean(np.abs(np.array(per) - 0.95)))


def summary(df, arm, edges):
    cov = df["score"] <= df[arm]
    month = df["origin"].dt.to_period("M")
    by_m = cov.groupby(month).mean()
    q = np.digitize(df["shift"], edges)
    return {
        "coverage": float(cov.mean()),
        "width_pct": float(np.mean(np.sinh(df[arm]) * 200)),
        "cc": cc(df, arm, edges),
        **{f"cov_q{i + 1}": float(cov[q == i].mean()) for i in range(5)},
        "worst_month": float(by_m.min()),
        "months_below_85": int((by_m < 0.85).sum()),
        "n_months": int(len(by_m)),
    }


def boot_cc_diff(df, arm, edges, rng):
    """Block bootstrap over calendar months of CC(arm) - CC(static)."""
    month = df["origin"].dt.to_period("M").astype(str).to_numpy()
    q = np.digitize(df["shift"], edges)
    cov_a = (df["score"] <= df[arm]).to_numpy(float)
    cov_s = (df["score"] <= df["static"]).to_numpy(float)
    months, inv = np.unique(month, return_inverse=True)
    # Per (month, quintile) sums so each draw is a cheap weighted sum.
    S_a = np.zeros((len(months), 5)); S_s = np.zeros((len(months), 5)); C = np.zeros((len(months), 5))
    np.add.at(S_a, (inv, q), cov_a)
    np.add.at(S_s, (inv, q), cov_s)
    np.add.at(C, (inv, q), 1.0)
    diffs = np.empty(N_BOOT)
    for b in range(N_BOOT):
        w = np.bincount(rng.integers(0, len(months), len(months)), minlength=len(months))
        c = w @ C
        ca = np.abs((w @ S_a) / c - 0.95).mean()
        cs = np.abs((w @ S_s) / c - 0.95).mean()
        diffs[b] = ca - cs
    return float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))


def main():
    print("=" * 78)
    print("ADAPTIVE CONFORMAL FOR THE PER-STEP BANDS  (Gibbs & Candes 2021; README section 71)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, rep = bc.build_panel(START, END, n=N, lookback_days=LOOKBACK_DAYS,
                                min_days=MIN_DAYS, verbose=False)
    cal = pd.read_csv(CAL_FILE, parse_dates=["date"]) if os.path.exists(CAL_FILE) else None
    by_sym = {s: np.sort(g.date.values) for s, g in cal.groupby("symbol")} if cal is not None else {}
    print(f"  {rep['n_symbols']} names, {rep['n_dates']} sessions {START} .. {END}; "
          f"M = {M} calibration windows, static quantile level {STATIC_Q:.4f}")

    rng = np.random.default_rng(20261021)
    rows, chosen = [], None
    detail = []
    for h in sorted(HORIZONS, key=lambda x: x != 5):     # h = 5 first: gamma is chosen there
        parts = []
        for s, g in panel.groupby("symbol"):
            g = g.sort_values("datetime")
            p = g["adj_close"].to_numpy(float)
            ok = np.isfinite(p) & (p > 0)
            if ok.sum() < M + h + 60:
                continue
            d = g["datetime"].to_numpy()[ok]
            w = name_windows(d, np.log(p[ok]), h, by_sym.get(s))
            if w is not None:
                w["symbol"] = s
                parts.append(w)
        W = pd.concat(parts, ignore_index=True)
        W = W[W.origin >= TEST_FROM]
        W = W[np.isfinite(W["shift"])]
        sel, conf = W[W.origin <= SELECT_END], W[W.origin >= CONFIRM_FROM]
        edges = np.quantile(sel["shift"], [0.2, 0.4, 0.6, 0.8])
        print(f"\nh = {h}: {len(W):,} origin-windows over {W.symbol.nunique()} names; "
              f"shift quintile edges {np.round(edges, 2)}")
        if h == 5:
            chosen = min((f"aci_{g}" for g in GAMMAS), key=lambda a: cc(sel, a, edges))
            print(f"  gamma chosen on 2018-07..2021-12 by CC: {chosen}")
        crash = W[(W.origin >= CRASH[0]) & (W.origin <= CRASH[1])]
        ev = W[(W.origin <= CAL_END) & W.event]
        hdr = (f"  {'period':<11}{'arm':<11}{'cover':>7}{'width':>8}{'CC':>7}"
               + "".join(f"{'q' + str(i + 1):>7}" for i in range(5))
               + f"{'worst mo':>9}{'<85%':>6}")
        print(hdr)
        for label, part in (("2018-21", sel), ("2022-24", conf), ("crash 2020", crash)):
            for arm in arms():
                rec = summary(part, arm, edges)
                rec.update({"h": h, "period": label, "arm": arm, "n": len(part)})
                rows.append(rec)
                print(f"  {label:<11}{arm:<11}{rec['coverage']:7.1%}{rec['width_pct']:7.2f}%"
                      f"{rec['cc']:7.3f}" + "".join(f"{rec[f'cov_q{i + 1}']:7.1%}" for i in range(5))
                      + f"{rec['worst_month']:9.1%}{rec['months_below_85']:>4d}/{rec['n_months']}")
        if len(ev):
            line = "  results-day windows (to 2024-06): " + ", ".join(
                f"{a} {np.mean(ev['score'] <= ev[a]):.1%}" for a in arms())
            print(line + f"  (n = {len(ev):,})")
            for a in arms():
                rows.append({"h": h, "period": "results days", "arm": a, "n": len(ev),
                             "coverage": float(np.mean(ev["score"] <= ev[a])),
                             "width_pct": float(np.mean(np.sinh(ev[a]) * 200))})
        yr = W.assign(year=W.origin.dt.year)
        for a in arms():
            for y, part in yr.groupby("year"):
                detail.append({"h": h, "arm": a, "year": int(y), "n": len(part),
                               "coverage": float(np.mean(part["score"] <= part[a])),
                               "width_pct": float(np.mean(np.sinh(part[a]) * 200))})
        print("  coverage by year: " + "  ".join(
            f"{y}: " + "/".join(f"{np.mean(part['score'] <= part[a]):.1%}" for a in ("static", chosen))
            for y, part in yr.groupby("year")) + f"   (static/{chosen})")
        if chosen is not None:
            lo, hi = boot_cc_diff(conf, chosen, edges, rng)
            rows.append({"h": h, "period": "2022-24", "arm": f"{chosen} - static (CC)",
                         "cc_diff_lo": lo, "cc_diff_hi": hi})
            print(f"  2022-24 CC({chosen}) - CC(static): 95% interval [{lo:+.4f}, {hi:+.4f}]")

    res = pd.DataFrame(rows)
    res.to_csv(OUT, index=False)
    pd.DataFrame(detail).to_csv(OUT_DETAIL, index=False)

    # ------------------------------------------------------------- decision
    c5 = res[(res.h == 5) & (res.period == "2022-24")]
    st_ = c5[c5.arm == "static"].iloc[0]
    ac = c5[c5.arm == chosen].iloc[0]
    ci = c5[c5.arm == f"{chosen} - static (CC)"].iloc[0]
    t1 = ci.cc_diff_hi < 0
    t2 = abs(ac.coverage - 0.95) <= abs(st_.coverage - 0.95) + 0.005
    t3 = ac.width_pct <= st_.width_pct * 1.15
    print("\nDECISION (2022-24, h = 5, pre-registered):")
    print(f"  (1) CC {st_.cc:.3f} -> {ac.cc:.3f}, interval [{ci.cc_diff_lo:+.4f}, {ci.cc_diff_hi:+.4f}]"
          f" excludes 0 with improvement: {'PASS' if t1 else 'FAIL'}")
    print(f"  (2) overall coverage {st_.coverage:.1%} -> {ac.coverage:.1%}: {'PASS' if t2 else 'FAIL'}")
    print(f"  (3) width {st_.width_pct:.2f}% -> {ac.width_pct:.2f}%: {'PASS' if t3 else 'FAIL'}")
    print(f"  => {'SHIP ' + chosen if (t1 and t2 and t3) else 'DO NOT SHIP'}")
    print(f"\n  wrote {OUT}\n  wrote {OUT_DETAIL}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
