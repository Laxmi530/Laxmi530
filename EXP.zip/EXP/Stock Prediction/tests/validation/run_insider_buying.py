"""
Hough's "Follow the Leaders" screen (*Your Next Great Stock*, Ch. 19) on NSE,
from SEBI insider-trading disclosures, before the reserved period.

The claim. Insiders "beat the broad stock market by six percentage points a
year" (a long-term US study the book cites), and the screen narrows that to
open-market purchases over $100,000, at least two of them, under 5% of the
shares. The book's refinements: executives' buys beat board members' and big
holders'; several buyers beat one; selling says far less than buying.

Written down before running
---------------------------
Signal: ``insiders.signal_events`` - the first disclosure at which a stock's
open-market PURCHASES by key managerial personnel, directors or promoters,
disclosed in the trailing 90 days, number at least 2, total at least Rs 88 lakh
($100,000 at Rs 88) and change holdings by under 5%; then no new event for that
stock for 90 days. Entry at the close of the first session AFTER the
disclosure's calendar date, so every trade was public before it is used.

Test (one, two-sided, |t| > 1.96): the 63-session return in excess of a
characteristic-matched benchmark - the average stock in the same quintile of
252-session return AND of 21-session return on the entry day. Matching matters
here because insiders often buy after a fall, and this project has measured
both momentum (12-month losers lag) and short-term reversal (last month's
losers bounce); an unmatched excess would credit insiders with either.
Event t-statistics average events by calendar month first (Newey-West, lag 3).
The book predicts a positive excess of about 1.5% a quarter.

Everything else printed (unmatched excess, 21 and 126 sessions, executives
involved or not, one buyer or several, large purchases, the two halves, and
open-market SALES by the same insiders) is exploratory: reported, not claimed.

Data: the bhavcopy panel (400 liquid names screened on 2017, 2018-01 ..
2024-06) and NSE's disclosures from 2018-01; events from 2019-01, once a
252-session return exists for the match.

Run::

    python tests/validation/run_insider_buying.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                                         # noqa: E402
import insiders                                               # noqa: E402
from run_market_breadth import newey_west_ols                 # noqa: E402
from run_oneil import monthly_t                               # noqa: E402

START, END = "2018-01-01", "2024-06-30"
EVENTS_FROM = pd.Timestamp("2019-01-01")
SPLIT = pd.Timestamp("2021-10-01")
HORIZONS = (21, 63, 126)
TEST_H = 63
COST = 0.0022                    # delivery round trip (README section 55)
OUT = os.path.join(_HERE, "insider_buying.csv")


def matched_excess(lp, h):
    """Excess over the panel, and over the same (252-day, 21-day) quintile cell."""
    fwd = lp.shift(-h) - lp
    ex = fwd.sub(fwd.mean(axis=1), axis=0)
    q252 = np.ceil((lp - lp.shift(252)).rank(axis=1, pct=True) * 5)
    q21 = np.ceil((lp - lp.shift(21)).rank(axis=1, pct=True) * 5)
    cell = q252 * 10 + q21
    long = pd.DataFrame({"ex": ex.stack(), "cell": cell.stack()}).dropna()
    bench = long.groupby([long.index.get_level_values(0), "cell"])["ex"].transform("mean")
    matched = (long["ex"] - bench).unstack()
    return ex, matched.reindex(index=lp.index, columns=lp.columns)


def describe(label, ev, rows):
    line = f"  {label:<44}{len(ev):>8,d}"
    rec = {"group": label, "events": len(ev), "symbols": ev["symbol"].nunique() if len(ev) else 0}
    for h in HORIZONS:
        for kind in ("raw", "matched"):
            m, t, _ = monthly_t(ev["entry"], ev[f"{kind}_{h}"], lag=max(1, h // 21))
            rec[f"{kind}_{h}"], rec[f"t_{kind}_{h}"] = m, t
        m = rec[f'matched_{h}']
        # monthly_t needs 10 events; below that say so rather than print "nan%".
        line += (f"{m * 100:10.2f}%{rec[f't_matched_{h}']:6.2f}" if m == m else f"{'too few':>11}{'':6}")
    hit = float(np.mean(ev[f"matched_{TEST_H}"] > 0)) if len(ev) else float("nan")
    rec["hit_63"] = hit
    raw = rec[f'raw_{TEST_H}']
    print(line + (f"{raw * 100:10.2f}%" if raw == raw else f"{'too few':>11}") + f"{hit:8.1%}")
    rows.append(rec)
    return rec


def main():
    print("=" * 78)
    print("FOLLOW THE LEADERS ON NSE  (Hough Ch. 19, SEBI insider-trading disclosures)")
    print("=" * 78)
    panel, _ = bc.build_panel(START, END, n=400, verbose=False, purpose="Hough Ch. 19")
    lp = panel.pivot_table(index="datetime", columns="symbol", values="adj_close", aggfunc="last")
    lp = np.log(lp.where(lp > 0)).sort_index()
    sessions = lp.index
    print(f"  {lp.shape[1]} names, {len(sessions):,} sessions")
    disc = insiders.history(START, END, verbose=False)
    trades = insiders.insider_trades(disc)
    trades = trades[trades["symbol"].isin(lp.columns)]
    print(f"  {len(disc):,} disclosures; open-market trades by executives, directors and promoters "
          f"in the panel: {int((trades.side == 'buy').sum()):,} buys, {int((trades.side == 'sell').sum()):,} sells")

    cols = {}
    for h in HORIZONS:
        cols[h] = matched_excess(lp, h)

    def attach(ev):
        if not len(ev):
            return ev
        pos = sessions.searchsorted(ev["disclosed"].dt.normalize() + pd.Timedelta(days=1))
        ok = pos < len(sessions)
        ev = ev[ok].copy()
        ev["entry"] = sessions[pos[ok]]
        for h in HORIZONS:
            ex, mt = cols[h]
            ev[f"raw_{h}"] = [ex.at[d, s] if s in ex.columns else np.nan for d, s in zip(ev.entry, ev.symbol)]
            ev[f"matched_{h}"] = [mt.at[d, s] if s in mt.columns else np.nan for d, s in zip(ev.entry, ev.symbol)]
        return ev[(ev["entry"] >= EVENTS_FROM) & ev[f"matched_{TEST_H}"].notna()]

    buys = attach(insiders.signal_events(trades, side="buy"))
    sells = attach(insiders.signal_events(trades, side="sell"))
    rows = []
    print(f"\n  matched = excess over stocks in the same 252-day and 21-day return quintiles")
    print(f"  {'group':<44}{'events':>8}" + "".join(f"{f'{h}d matched':>11}{'t':>6}" for h in HORIZONS)
          + f"{'63d raw':>11}{'63d hit':>8}")
    main_rec = describe("THE BOOK'S SCREEN (open-market buys)", buys, rows)
    describe("  an executive (KMP) among the buyers", buys[buys["executive"]], rows)
    describe("  no executive", buys[~buys["executive"]], rows)
    describe("  promoters only", buys[buys["kinds"].apply(lambda k: k == ["promoter"])], rows)
    describe("  two or more distinct buyers", buys[buys["buyers"] >= 2], rows)
    describe("  one buyer, repeated", buys[buys["buyers"] == 1], rows)
    describe("  Rs 10 crore or more", buys[buys["value"] >= 1e8], rows)
    describe(f"  first half (to {SPLIT.date()})", buys[buys["entry"] < SPLIT], rows)
    describe("  second half", buys[buys["entry"] >= SPLIT], rows)
    describe("OPEN-MARKET SALES, same recipe", sells, rows)

    m, t = main_rec[f"matched_{TEST_H}"], main_rec[f"t_matched_{TEST_H}"]
    verdict = ("supports the book" if (t > 1.96 and m > 0) else
               "goes against the book" if (t < -1.96) else "is not distinguishable from zero")
    print(f"\n  THE TEST: {TEST_H}-session matched excess {m * 100:+.2f}% (t {t:+.2f}) "
          f"over {main_rec['events']:,} events in {main_rec['symbols']} stocks: it {verdict}.")
    print(f"  net of a {COST * 100:.2f}% round trip: {(m - COST) * 100:+.2f}%; "
          f"the book's six points a year is about +1.5% a quarter")
    lag = buys[[f"raw_{TEST_H}", f"matched_{TEST_H}"]].mean()
    print(f"  mean raw vs matched (stock-level, unweighted): {lag.iloc[0] * 100:+.2f}% vs {lag.iloc[1] * 100:+.2f}%")
    pre = []
    for d, s in zip(buys.entry, buys.symbol):
        i = sessions.get_loc(d)
        pre.append(lp[s].iloc[i] - lp[s].iloc[i - 63] if i >= 63 else np.nan)
    pre = pd.Series(pre).dropna()
    print(f"  the 63 sessions BEFORE entry: median stock return {pre.median() * 100:+.1f}% "
          f"(share negative {np.mean(pre < 0):.0%}) - insiders tend to buy after a fall")
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  written {OUT}")


if __name__ == "__main__":
    main()
