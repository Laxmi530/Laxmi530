"""
Does Section 49's residual reversal clear costs if it is traded through
single-stock futures?

Kanwar & Gupta, *Python for Trading on Technical*, "Cost of Trade", itemise
the Indian charges and make the point this project had not tested: cash
delivery carries STT on both sides (Rs 10,000 per crore each way), so it is
roughly ten times as expensive as the same position through futures. Every
cost verdict here so far (Sections 39, 49, 53) compared against cash delivery.
Section 49's residual reversal (k = 5) breaks even at ~12.9 bp a round trip:
below delivery's ~22 bp, but well above futures' ~2.6 bp of statutory
charges. Futures also solve the other constraint Section 39 named: a short
leg is only possible overnight through a stock future.

So the pre-registered signal is re-run, unchanged, on the names that could
actually be traded that way:

- The factors are estimated on the full panel exactly as in Section 49 (they
  describe the market; tradeability is irrelevant to estimating them), and
  the book ranks and trades only names with stock futures THAT MONTH, from
  the exchange's own F&O bhavcopy (``bhavcopy.fno_members``). Today's list
  would be a look-ahead: it holds names that grew into the segment and drops
  those that left it.
- k = 5 as registered, with the raw signal for reference; nothing else is
  tried. Decile book, 5-day hold, averaged over all 5 starting days.
- Returns are spot simple returns. A futures leg earns the spot return less
  the cost of carry; in a dollar-neutral book the carry nets to first order.
  Opening each position in a contract that does not expire inside the hold
  avoids roll trades.

Costs per round trip (``strategy_metrics.india_round_trip_bps``): futures
statutory ~2.6 bp, plus a spread allowance of 2 or 5 bp; cash delivery
~22.2 bp. 2018-01-01 .. 2024-06-30, before the reserved period.

Run::

    python tests/validation/run_futures_reversal.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                  # noqa: E402
import strategy_metrics as sm          # noqa: E402
import run_residual_reversal as rr     # noqa: E402

START, END, N = rr.START, rr.END, rr.N
HOLD, WINDOW, DECILE = rr.HOLD, rr.WINDOW, rr.DECILE
SIGNALS = ("raw", "pca5")
OUT = os.path.join(_HERE, "futures_reversal.csv")


def main():
    print("=" * 78)
    print("RESIDUAL REVERSAL THROUGH STOCK FUTURES  (Kanwar & Gupta, 'Cost of Trade')")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    R = np.log(px / px.shift(1))
    fwd_s = px.shift(-HOLD) / px - 1.0

    members = bc.fno_members(START, END)
    months = sorted(members)
    sizes = [len(members[m] & set(px.columns)) for m in months]
    print(f"\n  F&O snapshots: {len(months)} months; universe names with stock futures: "
          f"median {int(np.median(sizes))} (range {min(sizes)} .. {max(sizes)}) of {px.shape[1]}")

    daily = []
    for i in range(WINDOW, len(px) - HOLD):
        fo = members.get(pd.Period(px.index[i], "M"))
        if not fo:
            continue
        s = rr.signals_at(R, i)
        if s is None:
            continue
        names = [c for c in s["raw"].index if c in fo]
        f = fwd_s.iloc[i].reindex(names)
        keep = f.notna()
        if keep.sum() < DECILE * 4:
            continue
        f = f[keep]
        daily.append((i, {n: s[n].reindex(f.index) for n in SIGNALS}, f))
    print(f"  {len(daily)} signal days with at least {DECILE * 4} tradeable names "
          f"(median {int(np.median([len(d[2]) for d in daily]))} per day)")

    # Each rebalance pays the futures rate in force on its date (STT was 0.01%
    # until April 2023, 0.0125% to September 2024); "today" is the April 2026
    # schedule a live book would pay.
    at = lambda i, add=0.0: sm.india_round_trip_bps("futures", as_of=px.index[i])["total"] + add
    costs = {
        "futures, rate at the time": lambda i: at(i),
        "  + 2 bp spread": lambda i: at(i, 2.0),
        "futures today (Apr 2026)": lambda i: sm.india_round_trip_bps("futures")["total"],
        "  + 2 bp spread ": lambda i: sm.india_round_trip_bps("futures")["total"] + 2.0,
        "cash delivery": lambda i: sm.india_round_trip_bps("delivery", as_of=px.index[i])["total"],
    }
    mid = daily[len(daily) // 2][0]
    print("\n  round-trip costs (mid-sample): "
          + ", ".join(f"{k.strip()} {fn(mid):.1f} bp" for k, fn in costs.items()))

    rows = []
    for n in SIGNALS:
        ics = [float(np.corrcoef(sig[n].rank(), f.rank())[0, 1]) for _, sig, f in daily]
        fm = sm.fama_macbeth_ic(pd.Series(ics), lags=HOLD)
        per_g, per_tr, per_net = [], [], {k: [] for k in costs}
        for p in range(HOLD):
            prev, g, tr, ix = None, [], [], []
            for i, sig, f in daily:
                if i % HOLD != p:
                    continue
                gross, w = rr.book(sig[n], f)
                g.append(gross)
                ix.append(i)
                w = w.reindex(px.columns, fill_value=0.0)
                tr.append(2.0 if prev is None else float((w - prev).abs().sum()))
                prev = w
            g, tr = np.array(g), np.array(tr)
            per_g.append(g.mean())
            per_tr.append(tr.mean())
            for k, fn in costs.items():
                c = np.array([fn(i) for i in ix])
                net = g - tr * (c / 1e4) / 2.0          # round-trip cost per unit traded / 2
                per_net[k].append(net.mean() / (net.std(ddof=1) / np.sqrt(len(net))))
        g, tr = float(np.mean(per_g)), float(np.mean(per_tr))
        be = 1e4 * 2.0 * g / tr
        row = {"signal": n, "mean_ic": fm["mean_ic"], "ic_t": fm["t_stat"],
               "gross_per_rebalance": g, "gross_phase_min": min(per_g),
               "gross_phase_max": max(per_g), "turnover": tr, "breakeven_bp": be}
        for k in costs:
            row[f"net_t_median[{k}]"] = float(np.median(per_net[k]))
            row[f"net_t_min[{k}]"] = float(np.min(per_net[k]))
        rows.append(row)

    out = pd.DataFrame(rows)
    out.to_csv(OUT, index=False)
    print("\n" + "=" * 78)
    print("F&O NAMES ONLY, point-in-time  (book averaged over all 5 starting days)")
    print("=" * 78)
    for _, x in out.iterrows():
        print(f"\n  {x.signal}: rank IC {x.mean_ic:+.4f} (t {x.ic_t:+.2f}); gross/rebalance "
              f"{x.gross_per_rebalance:+.3%} ({x.gross_phase_min:+.2%} .. {x.gross_phase_max:+.2%}); "
              f"turnover {x.turnover:.2f}; breakeven {x.breakeven_bp:.1f} bp")
        for k in costs:
            print(f"    net t at {k:<27}: median {x[f'net_t_median[{k}]']:+.2f}, "
                  f"worst starting day {x[f'net_t_min[{k}]']:+.2f}")
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
