"""
The 52-week-high strategy, in both directions, net of costs.

Yan, *Python for Finance*, Ch. 8, p. 196, states the rule as CONTRARIAN: go
long when today's price is close to its 52-week low and short when it is
close to its 52-week high. George & Hwang (2004, *Journal of Finance*) found
the OPPOSITE in US equities: stocks near their 52-week high outperform, and
the effect is distinct from (and largely subsumes) price momentum, because
investors anchor on the high and under-react to news that pushes a price
toward it. Both are written down here before running, so the sign of the
result decides between them rather than being chosen after it.

Why it is worth testing here
----------------------------
Section 38's one positive cross-sectional signal (5-day reversal) died on
cost in Section 39: it turns over 3.5x per rebalance against a ~20 bp round
trip. The 52-week high is SLOW. Proximity to a year-long maximum changes
little from one month to the next, so a monthly book may turn over far less,
and its long side (stocks near their highs) can be bought without shorting,
which matters where only 38% of a liquid universe is shortable.

Pre-specified
-------------
- Universe: 400 names, survivorship-free (Section 38), 2018-01-01 ..
  2024-06-30, before the reserved final test period. Signals start once 252
  sessions of history exist.
- Signal: PTH = price / max(price over the last 252 sessions) (George &
  Hwang). Yan's range position (price - low) / (high - low) is reported
  alongside.
- Horizon: 21 sessions; simple forward returns.
- IC: daily Spearman, Fama-MacBeth with Newey-West at 21 lags (the forward
  windows overlap).
- Beyond momentum: daily rank regression of the forward return on PTH, the
  12-1 month return (George & Hwang's control) and the last 21-day return.
- Books: decile long-short (top PTH minus bottom), and long-only (top decile
  minus the equal-weighted universe). Rebalanced every 21 sessions and
  averaged over all 21 starting days (Section 49). Breakeven is round trip,
  2 x gross / turnover, as in Section 39.

Run::

    python tests/validation/run_52week_high.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 400
LOOK, HOLD, DECILE, MIN_NAMES = 252, 21, 10, 100
OUT = os.path.join(_HERE, "week52_high.csv")


def rank_coef(y, X):
    """Cross-sectional OLS of rank(y) on ranks of X; slope on the first column."""
    z = pd.concat([y.rename("y"), X], axis=1).dropna().rank(pct=True)
    if len(z) < MIN_NAMES:
        return np.nan
    A = np.column_stack([np.ones(len(z)), z.drop(columns="y").to_numpy()])
    b, *_ = np.linalg.lstsq(A, z["y"].to_numpy(), rcond=None)
    return float(b[1])


def weights(sig, top_only):
    if top_only == "short":
        # The short side alone, as an excess: universe minus the bottom decile.
        w = pd.Series(1.0 / len(sig), index=sig.index)
        bot = sig[sig <= sig.quantile(1.0 / DECILE)].index
        w[bot] -= 1.0 / len(bot)
        return w
    return _weights(sig, top_only)


def _weights(sig, top_only):
    """
    Decile weights: long-short, or long-only top decile vs the universe.

    Buckets are value thresholds with ties INCLUDED. In a rising market more
    than a tenth of names can sit exactly at their 52-week high (PTH = 1);
    averaged ranks then put every one of them below a rank cut-off and the top
    decile comes out empty.
    """
    w = pd.Series(0.0, index=sig.index)
    top = sig[sig >= sig.quantile(1.0 - 1.0 / DECILE)].index
    w[top] = 1.0 / len(top)
    if top_only:
        return w - 1.0 / len(sig)                  # excess over equal weight
    bot = sig[sig <= sig.quantile(1.0 / DECILE)].index
    w[bot] = -1.0 / len(bot)
    return w


def main():
    print("=" * 78)
    print("52-WEEK HIGH  (Yan, Python for Finance, Ch. 8; George & Hwang 2004)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()

    hi = px.rolling(LOOK, min_periods=LOOK).max()
    lo = px.rolling(LOOK, min_periods=LOOK).min()
    pth = px / hi
    rng = (px - lo) / (hi - lo)
    mom = px.shift(HOLD) / px.shift(LOOK) - 1.0          # 12-1 month
    r21 = px / px.shift(HOLD) - 1.0
    fwd = px.shift(-HOLD) / px - 1.0

    days = [i for i in range(LOOK, len(px) - HOLD)
            if pth.iloc[i].notna().sum() >= MIN_NAMES]
    print(f"\n  {len(days)} signal days, {px.index[days[0]]:%Y-%m-%d} .. "
          f"{px.index[days[-1]]:%Y-%m-%d}; median names per day "
          f"{int(np.median([pth.iloc[i].notna().sum() for i in days]))}")

    ic = {"pth": [], "range": [], "mom": []}
    partial = []
    for i in days:
        f = fwd.iloc[i]
        for k, s in (("pth", pth), ("range", rng), ("mom", mom)):
            x = pd.concat([s.iloc[i], f], axis=1).dropna()
            ic[k].append(x.iloc[:, 0].corr(x.iloc[:, 1], method="spearman")
                         if len(x) >= MIN_NAMES else np.nan)
        X = pd.concat([pth.iloc[i].rename("pth"), mom.iloc[i].rename("mom"),
                       r21.iloc[i].rename("r21")], axis=1)
        partial.append(rank_coef(f, X))

    print("\n" + "=" * 78)
    print("1. RANK IC vs the next 21 sessions  (Fama-MacBeth, Newey-West 21 lags)")
    print("=" * 78)
    rows = []
    for k, label in (("pth", "price / 52-week high (George & Hwang)"),
                     ("range", "position in 52-week range (Yan)"),
                     ("mom", "12-1 month momentum (control)")):
        fm = sm.fama_macbeth_ic(pd.Series(ic[k]).dropna(), lags=HOLD)
        rows.append({"test": f"ic_{k}", "mean": fm["mean_ic"], "t": fm["t_stat"]})
        print(f"  {label:<40} IC {fm['mean_ic']:+.4f}   t {fm['t_stat']:+.2f}"
              f"   positive on {fm['hit_rate']:.0%} of days")
    fm = sm.fama_macbeth_ic(pd.Series(partial).dropna(), lags=HOLD)
    rows.append({"test": "pth_beyond_mom_and_r21", "mean": fm["mean_ic"], "t": fm["t_stat"]})
    print(f"  {'PTH, controlling for 12-1 and 21-day returns':<40} coef {fm['mean_ic']:+.4f}"
          f"   t {fm['t_stat']:+.2f}")
    print("  A positive sign supports George & Hwang; a negative one, Yan's contrarian rule.")

    print("\n" + "=" * 78)
    print("2. THE BOOKS, rebalanced every 21 sessions, averaged over 21 starting days")
    print("=" * 78)
    for name, top_only in (("long-short decile", False),
                           ("long side: top decile vs universe", True),
                           ("short side: universe vs bottom decile", "short")):
        per_g, per_t, per_n, per_tstat = [], [], [], []
        for p in range(HOLD):
            prev, g, tr = None, [], []
            for i in days[p::HOLD]:
                s = pth.iloc[i]
                f = fwd.iloc[i]
                ok = s.notna() & f.notna()
                if ok.sum() < MIN_NAMES:
                    continue
                w = weights(s[ok], top_only)
                g.append(float((w * f[ok]).sum()))
                w = w.reindex(px.columns, fill_value=0.0)
                tr.append(2.0 if prev is None else float((w - prev).abs().sum()))
                prev = w
            per_g.append(np.mean(g))
            per_t.append(np.mean(tr))
            per_n.append(len(g))
            # Within one starting day the rebalances do not overlap, so a plain
            # t-statistic on the per-rebalance series is valid.
            per_tstat.append(float(np.mean(g) / (np.std(g, ddof=1) / np.sqrt(len(g)))))
        g, t = float(np.mean(per_g)), float(np.mean(per_t))
        be = 1e4 * 2.0 * g / t if t > 0 else np.nan
        rows.append({"test": f"book_{name}", "mean": g, "turnover": t, "breakeven_bp": be,
                     "phase_min": min(per_g), "phase_max": max(per_g),
                     "t_median": float(np.median(per_tstat)),
                     "t_min": min(per_tstat), "t_max": max(per_tstat)})
        print(f"  {name:<38} gross/month {g:+.3%}  (starting days {min(per_g):+.2%} .. "
              f"{max(per_g):+.2%})")
        print(f"  {'':<38} t per starting day: median {np.median(per_tstat):+.2f} "
              f"(range {min(per_tstat):+.2f} .. {max(per_tstat):+.2f})")
        print(f"  {'':<38} turnover {t:.2f}   breakeven {be:.0f} bp round trip   "
              f"({int(np.mean(per_n))} rebalances per starting day)")
    print("  Against ~20 bp of STT alone per round trip (Section 39).")

    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
