"""
What did removing ``bb_position`` do to the tree models' forecasts?

``bb_position`` was ``(p - MA20) / (2 sigma20)`` and ``price_zscore`` is
``(p - MA20) / sigma20``: one is exactly half the other (README §55). A tree
splits on a rescaled copy at the rescaled threshold, so the copy adds no
information. But it is not inert either: XGBoost and LightGBM sample 80% of
the columns per tree (``colsample_bytree=0.8``), so a duplicate doubles that
signal's share of the draws, and any change to the column set reshuffles the
random draws for every other column too.

So the comparison needs a control. For each origin this trains the 5-day
direct model three ways and predicts the same origin:

    A  current features (no bb_position), seed 42      -- as shipped now
    B  current features + bb_position, seed 42         -- as shipped before
    C  current features, seed 7                        -- re-seeding only

|A - B| is the removal's effect; |A - C| is what re-seeding alone does. If the
first is no larger than the second, the removal is indistinguishable from
noise. Accuracy against the realised 5-day return is reported for A and B.
XGBoost and LightGBM, 3 names x 20 origins, 2020-2024, before the reserved
period.

Run::

    python tests/validation/run_bb_position_removal.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import ML_model as M                        # noqa: E402
from direct_forecast import (               # noqa: E402
    compute_origin_row, horizon_feature_cols, make_horizon_targets, training_frame)

SYMBOLS = ("RELIANCE", "TCS", "INFY")
H, ORIGINS = 5, 20
_BUILD = M.get_model_and_params


def _seeded(seed):
    def build(model_type):
        model, engine = _BUILD(model_type)
        model.set_params(random_state=seed)
        return model, engine
    return build


def _fit_predict(feat, cols, X, seed, engine):
    tgt = make_horizon_targets(feat, H)
    M.get_model_and_params = _seeded(seed)
    try:
        model, _ = M.train_generic_model(
            training_frame(feat, cols, tgt[H], f"target_h{H}"), f"target_h{H}", engine)
    finally:
        M.get_model_and_params = _BUILD
    return float(model.predict(X[cols])[0])


def main():
    print("=" * 78)
    print("REMOVING bb_position: effect on forecasts, against a re-seeding control")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel("2018-01-01", "2024-06-30", n=20, verbose=False)
    rows = []
    for engine in ("xgboost", "lightgbm"):
        for sym in SYMBOLS:
            d = panel[panel.symbol == sym].sort_values("datetime").reset_index(drop=True)
            d = d[["datetime", "open", "high", "low", "close", "adj_close", "volume"]]
            ends = np.linspace(700, len(d) - 1 - H, ORIGINS).astype(int)
            for e in ends:
                df = d.iloc[max(0, e - 999):e + 1].reset_index(drop=True)
                feat = M.create_features(df, "daily")
                cols = horizon_feature_cols(feat)
                X, _, _ = compute_origin_row(df, cols, "daily")
                feat_b = feat.copy()
                feat_b["bb_position"] = feat_b["price_zscore"] / 2.0
                cols_b = cols + ["bb_position"]
                X_b = X.copy()
                X_b["bb_position"] = X_b["price_zscore"] / 2.0
                y = float(np.log(d["adj_close"].iloc[e + H] / d["adj_close"].iloc[e]))
                rows.append({"engine": engine, "symbol": sym, "y": y,
                             "A": _fit_predict(feat, cols, X, 42, engine),
                             "B": _fit_predict(feat_b, cols_b, X_b, 42, engine),
                             "C": _fit_predict(feat, cols, X, 7, engine)})
    r = pd.DataFrame(rows)
    r.to_csv(os.path.join(_HERE, "bb_position_removal.csv"), index=False)

    print(f"\n  {'engine':<10}{'mean |pred|':>12}{'|A-B| removal':>15}{'|A-C| re-seed':>15}"
          f"{'RMSE A':>9}{'RMSE B':>9}{'hit A':>7}{'hit B':>7}{'sign A!=B':>11}")
    for engine, g in r.groupby("engine"):
        rm = lambda p: float(np.sqrt(np.mean((g[p] - g.y) ** 2)))
        hit = lambda p: float(np.mean(np.sign(g[p]) == np.sign(g.y)))
        print(f"  {engine:<10}{g.A.abs().mean():12.3%}{(g.A - g.B).abs().mean():15.3%}"
              f"{(g.A - g.C).abs().mean():15.3%}{rm('A'):9.3%}{rm('B'):9.3%}"
              f"{hit('A'):7.0%}{hit('B'):7.0%}{int((np.sign(g.A) != np.sign(g.B)).sum()):6d}/{len(g)}")
    print("\n  If |A-B| is no larger than |A-C|, removing the duplicate moved forecasts")
    print("  no more than changing the random seed does.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
