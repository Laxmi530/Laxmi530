"""
How large is the Jensen gap in expected shortfall?

Expected shortfall is the average return in the worst alpha tail. Every
estimator in ``var_models`` and the app's ``risk_metrics.empirical_risk``
used to compute it as ``expm1(mean(log tail))``, which is the GEOMETRIC mean
of the tail's gross returns. By Jensen's inequality (Sadr, *Mathematical
Techniques in Finance*, A.2.4, and the arithmetic-versus-geometric exercise
in Ch. 3) that is always below the arithmetic mean ``mean(expm1(log tail))``,
which is the average loss the label promises and the scale the ES backtest
scores realised returns on. VaR is unaffected: a quantile commutes with exp.

This driver measures the gap on NSE names at the horizons the app serves.
Window ends 2024-06-30, before the reserved final test period.

Run::

    python tests/validation/run_es_jensen.py
"""

import os
import sys
import warnings

import numpy as np

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 60
SYMBOLS = ("RELIANCE", "TCS", "TATASTEEL", "YESBANK")
HORIZONS = (1, 5, 20, 60)
ALPHA = 0.05


def main():
    print("=" * 78)
    print("JENSEN GAP IN EXPECTED SHORTFALL  (Sadr, Mathematical Techniques, A.2.4)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=N, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    print(f"\n  {'symbol':<11}{'h':>4}{'old (geometric)':>17}{'new (arithmetic)':>18}"
          f"{'gap':>10}{'gap / ES':>10}")
    for sym in SYMBOLS:
        if sym not in px:
            continue
        r = np.log(px[sym].dropna()).diff().dropna().to_numpy()
        for h in HORIZONS:
            agg = np.convolve(r, np.ones(h), mode="valid")
            tail = agg[agg <= np.quantile(agg, ALPHA)]
            geo, ari = np.expm1(tail.mean()), np.expm1(tail).mean()
            print(f"  {sym:<11}{h:4d}{geo:+17.2%}{ari:+18.2%}{ari - geo:+10.2%}"
                  f"{(ari - geo) / abs(geo):10.1%}")
    print("\n  The old figure is always the more negative: it overstated the")
    print("  average tail loss, by an amount that grows with tail dispersion.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
