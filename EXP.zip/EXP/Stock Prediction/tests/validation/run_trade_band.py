"""
Does a no-trade band rescue the residual reversal from its costs?

Section 49's residual reversal is the strongest signal this project has (rank
IC t about -8) and it still loses to cost: its decile book breaks even below a
cash-delivery round trip (22.2 bp, ``strategy_metrics.india_round_trip_bps``).
Section 39 tried the obvious fix, holding longer, and turnover barely moved,
because the signal has no persistence.

Holding longer is not the only way to trade less. "Finance-Grounded
Optimization for Algorithmic Trading" (arXiv 2509.04541) adds a turnover
penalty to the training loss. The portfolio-side version of the same idea needs
no new model: a NO-TRADE BAND. Enter a name when it reaches the extreme decile,
but leave only when it drops out of a wider band. A position whose signal is
still good is kept instead of being sold and bought back, and what is lost is
the edge of names drifting toward the middle.

Pre-specified, so nothing is tuned after the fact:

* signals: Section 49's raw and k = 5 PCA-residual trailing 5-day returns
  (``run_residual_reversal.signals_at``), long losers, short winners;
* entry at the extreme decile; exit bands {0.10, 0.15, 0.20, 0.30, 0.40}
  of the cross-sectional rank (0.10 is no band);
* rebalance every 1 or every 5 sessions; the 5-session book is averaged over
  its five starting days, as in Section 49;
* equal weight within each leg; turnover sum |w_t - w_{t-1}|, the first
  book counted as 2.0; breakeven = 2 x gross / turnover, as in Section 39;
* window 2018-01-01 .. 2024-06-30, before the reserved period
  (bhavcopy.HOLDOUT_START).

Rule, fixed before the run: the band rescues the signal only if some
configuration breaks even above a cash-delivery round trip in BOTH log and
simple returns AND its per-rebalance return net of that cost has t > 2. Ten
configurations per signal are tried, so a narrow pass would still need the
reserved period before it meant anything.

Step 0 checks that the 5-session, no-band k = 5 book reproduces Section 49's
stored breakeven, so the band is measured against the same book.

Run::

    python tests/validation/run_trade_band.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc              # noqa: E402
import strategy_metrics as sm      # noqa: E402
from run_residual_reversal import DECILE, WINDOW, signals_at   # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 400
SIGNALS = ("raw", "pca5")
EXITS = (0.10, 0.15, 0.20, 0.30, 0.40)
STEPS = (1, 5)
OUT = os.path.join(_HERE, "trade_band.csv")


def banded_book(sigs, fwd, cols, step, phase, exit_q):
    """
    Per-rebalance gross return and turnover of a banded decile long-short book.

    ``sigs`` is a list of (row, signal Series); ``fwd`` the ``step``-session
    forward returns. A name enters a leg at the extreme decile and stays while
    its rank is within ``exit_q`` of that end; a name with no forward return
    (it stops trading) leaves.
    """
    enter = 1.0 / DECILE
    longs, shorts, prev = set(), set(), None
    gross, traded = [], []
    for i, sig in sigs:
        if i % step != phase or i >= len(fwd) - step:
            continue
        f = fwd.iloc[i].reindex(sig.index)
        keep = f.notna()
        if keep.sum() < DECILE * 4:
            continue
        f = f[keep]
        r = sig[keep].rank(pct=True)
        longs = {n for n in longs if n in r.index and r[n] <= exit_q} | set(r.index[r <= enter])
        shorts = ({n for n in shorts if n in r.index and r[n] >= 1.0 - exit_q}
                  | set(r.index[r >= 1.0 - enter]))
        lo, sh = sorted(longs), sorted(shorts)
        gross.append(float(f[lo].mean() - f[sh].mean()))
        w = pd.Series(0.0, index=cols)
        w[lo] = 1.0 / len(lo)
        w[sh] = -1.0 / len(sh)
        traded.append(2.0 if prev is None else float((w - prev).abs().sum()))
        prev = w
    return np.array(gross), np.array(traded)


def main():
    print("=" * 78)
    print("NO-TRADE BAND ON THE RESIDUAL REVERSAL  (after arXiv 2509.04541)")
    print("=" * 78)
    cost = sm.india_round_trip_bps("delivery")["total"]
    print(f"window {START}..{END} | n={N} | exits {EXITS} | rebalance every {STEPS} "
          f"| cash-delivery round trip {cost:.2f} bp")
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    R = np.log(px / px.shift(1))
    fwd = {(s, kind): (np.log(px.shift(-s) / px) if kind == "log" else px.shift(-s) / px - 1.0)
           for s in STEPS for kind in ("log", "simple")}

    sigs = {n: [] for n in SIGNALS}
    for i in range(WINDOW, len(px) - 1):
        s = signals_at(R, i)
        if s is not None:
            for n in SIGNALS:
                sigs[n].append((i, s[n]))
    print(f"\n  {len(sigs['raw'])} signal days, {px.index[sigs['raw'][0][0]]:%Y-%m-%d} .. "
          f"{px.index[sigs['raw'][-1][0]]:%Y-%m-%d}")

    rows = []
    for n in SIGNALS:
        for step in STEPS:
            for q in EXITS:
                per = {"log": [], "simple": []}
                tr_all, net_t = [], []
                for p in range(step):
                    g_log, tr = banded_book(sigs[n], fwd[(step, "log")], px.columns, step, p, q)
                    g_sim, _ = banded_book(sigs[n], fwd[(step, "simple")], px.columns, step, p, q)
                    per["log"].append(g_log.mean())
                    per["simple"].append(g_sim.mean())
                    tr_all.append(tr.mean())
                    net = g_sim - cost / 2e4 * tr          # cost per unit traded = half a round trip
                    net_t.append(net.mean() / (net.std(ddof=1) / np.sqrt(len(net))))
                g, gs, tr = np.mean(per["log"]), np.mean(per["simple"]), np.mean(tr_all)
                rows.append({"signal": n, "step": step, "exit": q,
                             "gross_log": g, "gross_simple": gs, "turnover": tr,
                             "breakeven_bp": 1e4 * 2.0 * g / tr,
                             "breakeven_simple_bp": 1e4 * 2.0 * gs / tr,
                             "net_simple": gs - cost / 2e4 * tr,
                             "net_t_median": float(np.median(net_t)),
                             "net_t_min": float(np.min(net_t))})
    out = pd.DataFrame(rows)

    # ------------------------------------------------ 0. reconcile with S49
    print("\n" + "=" * 78)
    print("0. RECONCILIATION: 5-session, no-band k=5 book against Section 49")
    print("=" * 78)
    ref = os.path.join(_HERE, "residual_reversal.csv")
    mine = out[(out.signal == "pca5") & (out.step == 5) & (out.exit == 0.10)].iloc[0]
    ok = None
    if os.path.exists(ref):
        r49 = pd.read_csv(ref).set_index("signal").loc["pca5"]
        ok = abs(mine.breakeven_bp - r49.breakeven_bp) < 0.05
        print(f"  Section 49 stored: breakeven {r49.breakeven_bp:.2f} bp, turnover {r49.turnover:.3f}")
        print(f"  this driver      : breakeven {mine.breakeven_bp:.2f} bp, turnover {mine.turnover:.3f}"
              f"  -> {'ok' if ok else 'MISMATCH'}")
    else:
        print("  residual_reversal.csv missing; run run_residual_reversal.py first")

    print("\n" + "=" * 78)
    print("1. THE GRID  (per rebalance; t of the simple-return book net of "
          f"{cost:.1f} bp, median and worst over starting days)")
    print("=" * 78)
    print(f"  {'signal':<7}{'every':>6}{'exit':>6}{'gross':>10}{'turnover':>10}"
          f"{'b/e log':>9}{'simple':>8}{'net':>10}{'net t':>8}{'worst':>7}")
    for _, x in out.iterrows():
        print(f"  {x.signal:<7}{x.step:>6d}{x.exit:>6.2f}{x.gross_log:+10.4%}{x.turnover:10.3f}"
              f"{x.breakeven_bp:7.1f}bp{x.breakeven_simple_bp:6.1f}bp{x.net_simple:+10.4%}"
              f"{x.net_t_median:+8.2f}{x.net_t_min:+7.2f}")
    out.to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")

    best = out.loc[out[["breakeven_bp", "breakeven_simple_bp"]].min(axis=1).idxmax()]
    passed = out[(out.breakeven_bp > cost) & (out.breakeven_simple_bp > cost) & (out.net_t_median > 2)]
    print("\n" + "=" * 78)
    print("VERDICT (pre-registered rule)")
    print("=" * 78)
    if ok is False:
        print("  Reconciliation FAILED: the no-band book is not Section 49's. Not read.")
        return 1
    print(f"  best: {best.signal}, every {best.step}, exit {best.exit:.2f}: breakeven "
          f"{best.breakeven_bp:.1f} bp log / {best.breakeven_simple_bp:.1f} bp simple, "
          f"turnover {best.turnover:.2f}, net t {best.net_t_median:+.2f}")
    if passed.empty:
        print(f"  No configuration clears {cost:.1f} bp with net t > 2. The band does not "
              "rescue the signal.")
    else:
        print(f"  {len(passed)} configuration(s) clear the rule. Ten were tried per signal; "
              "only the reserved period could confirm one.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
