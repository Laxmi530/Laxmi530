"""
Is Section 38's reversal idiosyncratic, or a factor bouncing back?

Tatsat, Puri & Lookabaugh, *Machine Learning and Data Science Blueprints for
Finance*, Ch. 7, uses PCA to build "eigen portfolios". The same decomposition
has a more useful job here: separating a stock's move into the part shared
with common statistical factors and the part that is its own.

Section 38's signal is the RAW trailing 5-day return. Some of that is the
stock moving with its sector or style and then reverting with it. The
short-term residual-reversal literature reports that ranking on the return
left after removing common factors gives a stronger and steadier signal. Two
questions follow, and the second is the one that matters:

1. Is the reversal mostly idiosyncratic? Compare the IC of the raw signal
   with residual signals after removing the top k principal components.
2. Does a cleaner signal change Section 39's verdict? Reversal died on cost:
   a 6.1 bp round-trip breakeven against ~20 bp of real friction. A higher IC
   only helps if it is not bought with more turnover.

Pre-specified, so the search cannot be tuned after the fact: k in {1, 3, 5},
a 252-day trailing window for the PCA, 5-day signal and hold, decile
long-short, equal weight. Window ends 2024-06-30, before the reserved final
test period (bhavcopy.HOLDOUT_START).

Step 0 reconciles the raw signal against Section 39's stored book, because a
driver that rebuilds another section's result should prove it rebuilt it.

Run::

    python tests/validation/run_residual_reversal.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc              # noqa: E402
import strategy_metrics as sm      # noqa: E402

START, END, N = "2018-01-01", "2024-06-30", 400
HOLD, WINDOW, DECILE = 5, 252, 10
KS = (1, 3, 5)
OUT = os.path.join(_HERE, "residual_reversal.csv")


def signals_at(R, i):
    """Raw and PCA-residual trailing 5-day returns at row ``i`` of daily returns."""
    win = R.iloc[i - WINDOW + 1:i + 1]
    ok = win.notna().all(axis=0)
    win = win.loc[:, ok]
    if win.shape[1] < DECILE * 4:
        return None
    X = win.to_numpy(dtype=float)
    Xc = X - X.mean(axis=0)
    # Eigenvectors of the cross-asset covariance: the statistical factors.
    cov = (Xc.T @ Xc) / (len(Xc) - 1)
    vals, vecs = np.linalg.eigh(cov)
    order = np.argsort(vals)[::-1]
    vecs, vals = vecs[:, order], vals[order]
    last5 = X[-HOLD:]
    out = {"raw": pd.Series(last5.sum(axis=0), index=win.columns)}
    for k in KS:
        V = vecs[:, :k]
        resid = last5 - (last5 @ V) @ V.T          # remove the top-k factors
        out[f"pca{k}"] = pd.Series(resid.sum(axis=0), index=win.columns)
    out["_var_share"] = {k: float(vals[:k].sum() / vals.sum()) for k in KS}
    return out


def book(sig, fwd):
    """Decile long-short (long losers): gross log return and weight vector."""
    r = sig.rank(pct=True)
    longs = r[r <= 1.0 / DECILE].index
    shorts = r[r >= 1.0 - 1.0 / DECILE].index
    w = pd.Series(0.0, index=sig.index)
    w[longs] = 1.0 / len(longs)
    w[shorts] = -1.0 / len(shorts)
    return float(fwd[longs].mean() - fwd[shorts].mean()), w


def main():
    print("=" * 78)
    print("RESIDUAL REVERSAL  (Tatsat et al., ML & Data Science Blueprints, Ch. 7)")
    print("=" * 78)
    print(f"window {START}..{END} | n={N} | PCA window {WINDOW}d | "
          f"hold {HOLD}d | k in {KS} (pre-specified)")
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1

    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    px = panel.pivot_table(index="datetime", columns="symbol",
                           values="adj_close", aggfunc="last").sort_index()
    R = np.log(px / px.shift(1))
    fwd_all = np.log(px.shift(-HOLD) / px)
    # An equal-weighted leg EARNS the mean of simple returns, and costs are paid
    # on simple notional. The mean of log returns sits below it by a Jensen gap
    # that is larger for the more volatile leg (recent losers), so a log book
    # understates a reversal book's gross. Section 39 and the first version of
    # this driver reported log; both are kept so the gap is visible.
    fwd_simple_all = px.shift(-HOLD) / px - 1.0

    # Signals EVERY day. A 5-day book rebalanced every 5 sessions has five
    # equally valid phases, and the choice is not innocent: Section 39's book
    # ranges from -0.11% to +0.11% gross per rebalance across them, and the
    # published +0.105% is the best of the five. So the IC uses every day
    # (Newey-West at the horizon, since forward windows overlap) and the book
    # is averaged over all five phases rather than reported for one.
    names = ["raw"] + [f"pca{k}" for k in KS]
    daily = []                                    # (i, keep-index, signals, fwd)
    shares = []
    for i in range(WINDOW, len(px) - HOLD):
        s = signals_at(R, i)
        if s is None:
            continue
        f = fwd_all.iloc[i].reindex(s["raw"].index)
        keep = f.notna()
        if keep.sum() < DECILE * 4:
            continue
        f = f[keep] - f[keep].mean()               # cross-sectional excess
        fs = fwd_simple_all.iloc[i].reindex(f.index)
        daily.append((i, {n: s[n][keep] for n in names}, f, fs))
        shares.append(s["_var_share"])

    print(f"\n  {len(daily)} signal days, {px.index[daily[0][0]]:%Y-%m-%d} .. "
          f"{px.index[daily[-1][0]]:%Y-%m-%d}")
    vs = pd.DataFrame(shares).mean()
    print("  variance explained by the top k factors (mean): "
          + ", ".join(f"k={k}: {vs[k]:.0%}" for k in KS))

    ics = {n: [] for n in names}
    rho = {n: [] for n in names if n != "raw"}
    for _, sig, f, _fs in daily:
        for n in names:
            ics[n].append(float(np.corrcoef(sig[n].rank(), f.rank())[0, 1]))
            if n != "raw":
                rho[n].append(float(np.corrcoef(sig["raw"].rank(),
                                                sig[n].rank())[0, 1]))

    # The book, per phase: phase p rebalances on the days with i % HOLD == p.
    gross = {n: {p: [] for p in range(HOLD)} for n in names}
    gross_s = {n: {p: [] for p in range(HOLD)} for n in names}
    traded = {n: {p: [] for p in range(HOLD)} for n in names}
    phase0_dates = []
    for p in range(HOLD):
        prev = {n: None for n in names}
        for i, sig, f, fs in daily:
            if i % HOLD != p:
                continue
            if p == 0:
                phase0_dates.append(px.index[i])
            for n in names:
                g, w = book(sig[n], f)
                gross[n][p].append(g)
                gross_s[n][p].append(book(sig[n], fs)[0])
                w = w.reindex(px.columns, fill_value=0.0)
                traded[n][p].append(2.0 if prev[n] is None
                                    else float((w - prev[n]).abs().sum()))
                prev[n] = w

    # ---------------------------------------------- 0. reconcile with S39
    ref = os.path.join(_HERE, "reversal_costs_h5.csv")
    if os.path.exists(ref):
        r39 = pd.read_csv(ref, parse_dates=["date"]).set_index("date")["gross"]
        mine = pd.Series(gross["raw"][0], index=phase0_dates)
        common = mine.index.intersection(r39.index)
        print("\n" + "=" * 78)
        print("0. RECONCILIATION: the raw signal against Section 39's stored book")
        print("=" * 78)
        print(f"  {len(common)} shared rebalance dates (this build starts in 2019: "
              f"it needs {WINDOW} days for the PCA window)")
        if len(common) > 10:
            print(f"  Section 39 on those dates: mean {r39[common].mean():+.4%}")
            print(f"  this build on those dates: mean {mine[common].mean():+.4%}")
            print(f"  correlation: {np.corrcoef(mine[common], r39[common])[0, 1]:.3f}"
                  "  (residual gap: this build also requires a full PCA window)")

    # ---------------------------------------------- 1 + 2. the comparison
    print("\n" + "=" * 78)
    print("1-2. RAW vs PCA-RESIDUAL REVERSAL  (book averaged over all 5 phases)")
    print("=" * 78)
    print(f"  {'signal':<8}{'rank IC':>10}{'t':>8}{'hit':>7}{'rho raw':>9}"
          f"{'gross/reb':>11}{'phase range':>21}{'turnover':>10}{'breakeven':>11}")
    rows = []
    for n in names:
        fm = sm.fama_macbeth_ic(pd.Series(ics[n]), lags=HOLD)
        per = [np.mean(gross[n][p]) for p in range(HOLD)]
        g = float(np.mean(per))
        tr = float(np.mean([np.mean(traded[n][p]) for p in range(HOLD)]))
        be_bp = 1e4 * 2.0 * g / tr                 # round trip, as in S39
        per_s = [np.mean(gross_s[n][p]) for p in range(HOLD)]
        g_s = float(np.mean(per_s))
        r = np.mean(rho[n]) if n in rho else 1.0
        rows.append({"signal": n, "mean_ic": fm["mean_ic"], "t_stat": fm["t_stat"],
                     "hit_rate": fm["hit_rate"], "rho_with_raw": r,
                     "gross_per_rebalance": g, "gross_phase_min": min(per),
                     "gross_phase_max": max(per), "turnover": tr,
                     "breakeven_bp": be_bp, "gross_simple": g_s,
                     "gross_simple_phase_min": min(per_s),
                     "gross_simple_phase_max": max(per_s),
                     "breakeven_simple_bp": 1e4 * 2.0 * g_s / tr,
                     "n_days": len(ics[n])})
        print(f"  {n:<8}{fm['mean_ic']:+10.4f}{fm['t_stat']:+8.2f}"
              f"{fm['hit_rate']:7.2f}{r:9.2f}{g:+11.4%}"
              f"   {min(per):+.3%}..{max(per):+.3%}{tr:10.2f}{be_bp:9.1f}bp")
    out = pd.DataFrame(rows)

    print("\n  The same books in SIMPLE returns (what an equal-weighted leg earns,")
    print("  and the scale costs are paid on). Log understates the reversal book,")
    print("  because its long leg (recent losers) is the more volatile:")
    print(f"  {'signal':<8}{'gross log':>11}{'gross simple':>14}{'phase range (simple)':>24}"
          f"{'breakeven log':>15}{'simple':>9}")
    for _, x in out.iterrows():
        print(f"  {x.signal:<8}{x.gross_per_rebalance:+11.4%}{x.gross_simple:+14.4%}"
              f"   {x.gross_simple_phase_min:+.3%}..{x.gross_simple_phase_max:+.3%}"
              f"{x.breakeven_bp:13.1f}bp{x.breakeven_simple_bp:7.1f}bp")
    out.to_csv(OUT, index=False)
    print(f"\n  wrote {OUT}")

    raw = out[out.signal == "raw"].iloc[0]
    best = out[out.signal != "raw"].sort_values("t_stat").iloc[0]
    print("\n" + "=" * 78)
    print("VERDICT")
    print("=" * 78)
    print(f"  raw IC {raw.mean_ic:+.4f} (t {raw.t_stat:+.2f}); strongest residual "
          f"{best.signal} IC {best.mean_ic:+.4f} (t {best.t_stat:+.2f}).")
    print(f"  breakeven {raw.breakeven_bp:.1f} bp raw vs {best.breakeven_bp:.1f} bp "
          f"for {best.signal} in log returns; {raw.breakeven_simple_bp:.1f} vs "
          f"{best.breakeven_simple_bp:.1f} bp in simple,")
    print("  against ~20 bp of real round-trip friction.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
