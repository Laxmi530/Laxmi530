"""
Stop-loss orders on NSE: the book's fixed percentages, beta, and how to
predict a stop-out (Mladjenovic, *Stock Investing For Dummies*, 7th ed., Ch. 17).

Four questions, on the survivorship-free bhavcopy panel, 2018-01-01 ..
2024-06-30 (before the reserved period), adjusted OHLC:

1. **The book's fixed stops** (5, 8, 10, 15, 20, 25% below the close): how
   often is each hit within one month (21 sessions) and one quarter (63), and
   how much does that depend on the stock's volatility?
2. **Beta or volatility?** The book places a stop with "the beta", which it
   calls a measure of volatility. Beta is correlation x relative volatility.
   Which of the two ranks names by how often their stops are hit?
3. **Predicting a stop-out.** Out of sample (estimate to 2022-06, score
   2022-07 onward, non-overlapping windows), how well calibrated are three
   estimates: the end-point probability the risk panel showed, the reflection
   principle (2x end-point), and the stock's own volatility-standardised
   excursion history (``stops.stop_hit_probability``)?
4. **The fill.** When a stop is hit, how far below it does the sale happen?
   The book's own example: a stop at $18 that sells at $17.

Run::

    python tests/validation/run_stop_loss.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import stops                                # noqa: E402
from var_models import ewma_next_sigma      # noqa: E402

START, END = "2018-01-01", "2024-06-30"
# Two opposite out-of-sample periods: a calm rising market, and a crash.
PERIODS = (("calm 2022-07 .. 2024-06", pd.Timestamp("2022-07-01"), pd.Timestamp("2024-06-30")),
           ("crash 2020-01 .. 2021-12", pd.Timestamp("2020-01-01"), pd.Timestamp("2021-12-31")))
N = 200
BOOK_STOPS = (0.05, 0.08, 0.10, 0.15, 0.20, 0.25)
OUT = os.path.join(_HERE, "stop_loss.csv")


def _bars(g):
    g = g.sort_values("datetime").reset_index(drop=True)
    low, adj = stops.adjusted_lows(g)
    close = pd.to_numeric(g["close"], errors="coerce").to_numpy(float)
    ratio = np.where(close > 0, adj / close, np.nan)
    opn = pd.to_numeric(g["open"], errors="coerce").to_numpy(float) * ratio
    return g["datetime"].to_numpy(), adj, low, opn


def _hits(adj, low, h, stop, step):
    """Hit indicator, and the fill relative to the stop, over non-overlapping windows."""
    out, fills = [], []
    lvl = math.log(1.0 - stop)
    for t in range(0, len(adj) - h - 1, step):
        lo = np.log(low[t + 1:t + h + 1] / adj[t])
        hit = np.nonzero(lo <= lvl)[0]
        out.append(bool(len(hit)))
    return np.array(out), fills


def _ece(p, y, bins=10):
    p, y = np.asarray(p, float), np.asarray(y, float)
    idx = np.clip((p * bins).astype(int), 0, bins - 1)
    return float(sum(np.mean(idx == b) * abs(p[idx == b].mean() - y[idx == b].mean())
                     for b in range(bins) if np.any(idx == b)))


def main():
    print("=" * 78)
    print("STOP-LOSS ORDERS ON NSE  (Mladjenovic, Stock Investing For Dummies, Ch. 17)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=N, verbose=False)
    names = [s for s, g in panel.groupby("symbol") if len(g) >= 1000]
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close").sort_index()
    mkt = np.log(px).diff().mean(axis=1)               # equal-weighted panel market
    print(f"\n  {len(names)} names with >= 1,000 sessions; market = equal-weighted panel")

    # ---------------------------------------------------- 1 + 2: hit rates
    rows = []
    for s in names:
        g = panel[panel.symbol == s]
        dts, adj, low, opn = _bars(g)
        r = pd.Series(np.diff(np.log(adj)), index=pd.to_datetime(dts[1:]))
        rec = {"symbol": s, "vol": float(r.std() * math.sqrt(252)),
               "beta": stops.beta(r.values, mkt.reindex(r.index).values)}
        for h in (21, 63):
            for st in BOOK_STOPS:
                y, _ = _hits(adj, low, h, st, h)
                rec[f"hit_{h}_{int(st * 100)}"] = float(y.mean()) if len(y) else np.nan
        rows.append(rec)
    t = pd.DataFrame(rows).dropna(subset=["vol", "beta"])
    t["vol_q"] = pd.qcut(t.vol, 5, labels=False) + 1

    print("\n1. THE BOOK'S FIXED STOPS: share of windows in which the stop is hit")
    for h in (21, 63):
        print(f"\n  within {h} sessions      " + "".join(f"{int(s * 100):>6d}%" for s in BOOK_STOPS))
        print("  all names            " + "".join(f"{t[f'hit_{h}_{int(s * 100)}'].median():7.0%}"
                                                  for s in BOOK_STOPS))
        for q, gq in t.groupby("vol_q"):
            print(f"  vol quintile {q} ({gq.vol.median():4.0%}) " +
                  "".join(f"{gq[f'hit_{h}_{int(s * 100)}'].median():7.0%}" for s in BOOK_STOPS))

    print("\n2. BETA OR VOLATILITY?")
    sp = lambda a, b: float(pd.Series(a).rank().corr(pd.Series(b).rank()))   # noqa: E731
    print(f"  Spearman(beta, volatility) across names         : {sp(t.beta, t.vol):+.2f}")
    for h, st in ((21, 0.10), (63, 0.10), (21, 0.05)):
        col = f"hit_{h}_{int(st * 100)}"
        print(f"  {int(st * 100)}% stop, {h} sessions: rank corr with hit rate:"
              f"  volatility {sp(t.vol, t[col]):+.2f}   beta {sp(t.beta, t[col]):+.2f}")
    lo_b = t[t.beta < t.beta.quantile(0.2)]
    print(f"  lowest-beta fifth: median beta {lo_b.beta.median():.2f}, median vol "
          f"{lo_b.vol.median():.0%} (all names {t.vol.median():.0%}); 10%/21d hit rate "
          f"{lo_b['hit_21_10'].median():.0%} vs {t['hit_21_10'].median():.0%}")

    # ------------------------------------------------ 3: calibration OOS
    print("\n3. PREDICTING A STOP-OUT, OUT OF SAMPLE (history before the period, scored in it)")
    cals = []
    for label, p0, p1 in PERIODS:
        cal = []
        for s in names:
            g = panel[panel.symbol == s].sort_values("datetime").reset_index(drop=True)
            dts, adj, low, _ = _bars(g)
            dts = pd.to_datetime(dts)
            cut, stop_at = int(np.searchsorted(dts, p0)), int(np.searchsorted(dts, p1, "right"))
            if cut < stops.MIN_WINDOWS + 70 or stop_at - cut < 120:
                continue
            r = np.diff(np.log(adj))
            for h in (5, 21):
                u, _ = stops.standardised_excursions(g.iloc[:cut], h)   # history before it
                for t0 in range(cut, stop_at - h - 1, h):
                    sig = ewma_next_sigma(r[:t0])
                    lo = np.log(low[t0 + 1:t0 + h + 1] / adj[t0])
                    for st in (0.05, 0.08, 0.10, 0.15):
                        res = stops.stop_hit_probability(None, st, h, sigma_now=sig, excursions=u)
                        cal.append({"period": label, "h": h, "stop": st,
                                    "y": float(np.any(lo <= math.log(1 - st))),
                                    "endpoint": res["endpoint"], "reflection": res["reflection"],
                                    "empirical": res["probability"]})
        c = pd.DataFrame(cal).dropna()
        cals.append(c)
        print(f"\n  {label}: {len(c):,} name-window-stop predictions")
        print(f"  {'':<12}{'observed':>10}{'endpoint':>10}{'reflection':>12}{'empirical':>11}"
              f"   Brier: {'endpoint':>9}{'reflection':>11}{'empirical':>10}")
        for (h, st), gg in c.groupby(["h", "stop"]):
            br = {k: float(np.mean((gg[k] - gg.y) ** 2)) for k in ("endpoint", "reflection", "empirical")}
            print(f"  {h:>2}d {int(st * 100):>3d}%    {gg.y.mean():10.1%}{gg.endpoint.mean():10.1%}"
                  f"{gg.reflection.mean():12.1%}{gg.empirical.mean():11.1%}          "
                  f"{br['endpoint']:9.4f}{br['reflection']:11.4f}{br['empirical']:10.4f}")
        ece = {k: _ece(c[k], c.y) for k in ("endpoint", "reflection", "empirical")}
        print("  ECE (pooled):  " + "   ".join(f"{k} {v:.3f}" for k, v in ece.items()))
    c = pd.concat(cals, ignore_index=True)

    # ------------------------------------------------------- 4: the fill
    print("\n4. THE FILL: how far below a 10% stop the sale happens (gap through at the open)")
    gaps = []
    for s in names:
        g = panel[panel.symbol == s]
        dts, adj, low, opn = _bars(g)
        for t0 in range(0, len(adj) - 22, 21):
            stop_px = adj[t0] * 0.90
            for k in range(t0 + 1, t0 + 22):
                if low[k] <= stop_px:
                    fill = min(opn[k], stop_px) if np.isfinite(opn[k]) else stop_px
                    gaps.append(fill / stop_px - 1.0)
                    break
    gaps = np.array(gaps)
    print(f"  stops hit: {len(gaps):,}; filled below the stop (gapped through): "
          f"{np.mean(gaps < -1e-9):.0%}; mean shortfall {gaps.mean():+.2%}; "
          f"worst 5% {np.quantile(gaps, 0.05):+.2%}")

    t.to_csv(OUT, index=False)
    c.to_csv(OUT.replace(".csv", "_calibration.csv"), index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
