"""
What did the book's trading agent learn? A constant rule on the same simulator.

Hilpisch, *Reinforcement Learning for Finance*, Ch. 6, trains a deep
Q-learning TradingAgent and reports (pp. 108-110) "a significantly positive
average performance ... Not once does the trained agent lose money": mean
gross performance 1.582, accuracy ~0.55.

The agent is trained AND tested on simulated prices, not market data. The
simulator (``Trading._simulate_data``) is a mean-reverting process,

    x_t = x_{t-1} + kappa (theta - x_{t-1}) dt + x_{t-1} sigma sqrt(dt) z_t,

with the test parametrization x0 = 100, kappa = 2, theta = 50, sigma = 0.1
over 504 steps (two years): a price BUILT to fall from 100 toward 50, with
noise far smaller than the built-in decline. Whatever the agent learns, a
constant rule can read the same drift straight off the parameters.

This driver replicates the simulator exactly (Euler-Maruyama, dt =
days/365/periods, the book's directional accuracy and multiplicative gross
performance with leverage 1, tested from bar 8 as in its lags=8 setup) and
scores, over 1,000 simulated episodes each:

    always short          one constant action
    random                a coin flip each bar (the book's untrained baseline)
    short above theta     short when x > theta, long below (uses theta)

on the book's parametrization, and on a control with kappa = 0 (no drift),
where nothing should earn anything. No TensorFlow is needed: no agent is
trained, because the point is what a rule that learns nothing achieves.

Run::

    python tests/validation/run_rl_simulation_check.py
"""

import math
import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
EPISODES, PERIODS, LAGS = 1000, 504, 8
OUT = os.path.join(_HERE, "rl_simulation_check.csv")


def simulate(rng, x0=100.0, kappa=2.0, theta=50.0, sigma=0.1,
             start="2024-1-1", end="2026-1-1", periods=PERIODS):
    """The book's Trading._simulate_data (Euler-Maruyama), with its dt."""
    index = pd.date_range(start=start, end=end, periods=periods)
    dt = (index[-1] - index[0]).days / 365 / periods
    x = [x0]
    for _ in range(1, periods):
        x_ = x[-1] + kappa * (theta - x[-1]) * dt + x[-1] * sigma * math.sqrt(dt) * rng.standard_normal()
        x.append(max(x_, 0.0))
    return np.array(x)


def score(x, actions, theta):
    """Directional accuracy and gross performance (long = 1, short = 0)."""
    r = np.diff(np.log(x))[LAGS - 1:]                 # returns from bar LAGS on
    d = (r > 0).astype(int)
    a = actions[: len(r)]
    acc = float(np.mean(a == d))
    pl = np.where(a == 1, r, -r)                       # leverage 1
    return acc, float(np.exp(pl.sum()))


def run(kappa, label):
    rng = np.random.default_rng(100)
    res = {"always short": [], "random": [], "short above theta": []}
    theta = 50.0
    for _ in range(EPISODES):
        x = simulate(rng, kappa=kappa, theta=theta)
        n = len(x) - LAGS
        res["always short"].append(score(x, np.zeros(n, dtype=int), theta))
        res["random"].append(score(x, rng.integers(0, 2, n), theta))
        above = (x[LAGS - 1:-1] > theta).astype(int)    # decided on the bar before
        res["short above theta"].append(score(x, 1 - above, theta))
    rows = []
    for rule, v in res.items():
        acc = np.array([a for a, _ in v])
        perf = np.array([p for _, p in v])
        rows.append({"simulator": label, "rule": rule, "accuracy": acc.mean(),
                     "mean_performance": perf.mean(), "share_losing": float(np.mean(perf < 1.0))})
    return rows


def main():
    print("=" * 78)
    print("WHAT DID THE TRADING AGENT LEARN?  (Hilpisch, RL for Finance, Ch. 6)")
    print("=" * 78)
    print(f"\n  {EPISODES} simulated episodes of {PERIODS} steps each; the book's agent: accuracy ~0.549,")
    print("  mean gross performance 1.582, 'not once does the trained agent lose money'\n")
    rows = run(2.0, "book: kappa=2, theta=50, x0=100") + run(0.0, "control: kappa=0 (no drift)")
    d = pd.DataFrame(rows)
    d.to_csv(OUT, index=False)
    for sim, g in d.groupby("simulator", sort=False):
        print(f"  {sim}")
        for _, x in g.iterrows():
            print(f"    {x.rule:<20} accuracy {x.accuracy:.3f}   mean performance {x.mean_performance:.3f}"
                  f"   episodes losing money {x.share_losing:.1%}")
    print("\n  A rule that learns nothing reproduces the agent's result on the book's")
    print("  simulator, and nothing earns anything once the built-in drift is removed.")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
