"""
Does feature_drift fire on nothing? False alarms and power, plain vs block null.

``feature_drift.drift_table`` judges drift by a permutation test. A plain
permutation treats observations as exchangeable, which rolling-window features
are not, so on a STATIONARY persistent series it calls the two windows
different. This driver measures, over many simulated histories:

    false alarms   no drift at all: i.i.d. t(4) returns, and a GARCH(1,1)
                   path (stationary, persistent volatility)
    power          a genuine regime change: volatility doubles for the
                   current window

for the project's rolling features (raw return, vol_10, vol_50, ma_ratio_50),
under the old plain null (block = 1) and the block null now used.
750-bar reference vs 250-bar current, as in README §35.

Run::

    python tests/validation/run_drift_false_alarm.py
"""

import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import feature_drift as fd                  # noqa: E402

TRIALS, N_PERM = 60, 100
REF, CUR, BURN = 750, 250, 100


def _garch(n, rng, omega=1e-6, a=0.08, b=0.90):
    r, h = np.empty(n), omega / (1 - a - b)
    for t in range(n):
        r[t] = np.sqrt(h) * rng.standard_t(6) / np.sqrt(1.5)
        h = omega + a * r[t] ** 2 + b * h
    return r


def _features(r):
    s = pd.Series(r)
    px = pd.Series(np.exp(np.cumsum(r)))
    return pd.DataFrame({"return": s, "vol_10": s.rolling(10).std(),
                         "vol_50": s.rolling(50).std(),
                         "ma_ratio_50": px / px.rolling(50).mean()}
                        ).iloc[BURN:].reset_index(drop=True)


def _flag_rate(make, block_mode):
    hits = {}
    for t in range(TRIALS):
        f = _features(make(np.random.default_rng(t)))
        ref, cur = f.iloc[:REF], f.iloc[REF:REF + CUR]
        for col in f.columns:
            a, b = ref[col].dropna().values, cur[col].dropna().values
            blk = 1 if block_mode == "plain" else fd.block_length(a, len(b) // 3)
            v = fd.psi(a, b)
            p_psi = float(np.mean(fd.psi_null(a, b, n_perm=N_PERM, seed=t, block=blk) >= v))
            w = fd.wasserstein(a, b)
            p_w = float(np.mean(fd.wasserstein_null(a, b, n_perm=N_PERM, seed=t, block=blk) >= w))
            hits.setdefault(col, []).append(p_psi < 0.025 or p_w < 0.025)
    return {k: float(np.mean(v)) for k, v in hits.items()}


def main():
    print("=" * 78)
    print("FEATURE-DRIFT FALSE ALARMS AND POWER: plain vs block permutation null")
    print("=" * 78)
    n = BURN + REF + CUR
    cases = {
        "iid t(4), no drift": lambda g: g.standard_t(4, n) * 0.01 / np.sqrt(2),
        "GARCH(1,1), no drift": lambda g: _garch(n, g),
        "vol doubles (real drift)": lambda g: (g.standard_t(4, n) * 0.01 / np.sqrt(2)
                                               * np.r_[np.ones(BURN + REF), np.full(CUR, 2.0)]),
    }
    rows = []
    for case, make in cases.items():
        for mode in ("plain", "block"):
            rates = _flag_rate(make, mode)
            rows.append({"case": case, "null": mode, **rates})
            print(f"  {case:<26}{mode:<7}" + "".join(f"{k} {v:.2f}   " for k, v in rates.items()),
                  flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(_HERE, "drift_false_alarm.csv"), index=False)
    print("\n  Rows are the share of trials flagged DRIFT (alpha/2 per test, as in")
    print("  drift_table). Under no drift the target is <= 0.05; under a real")
    print("  shift, higher is better.")
    _real_data()
    return 0


def _real_data():
    """README §35's split on real data: RELIANCE, 750-bar reference vs 250 current."""
    import bhavcopy as bc
    import ML_model
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        return
    panel, _ = bc.build_panel("2019-01-01", "2024-06-30", n=20, verbose=False)
    print("\n  Real data (README §35's split): RELIANCE features, last 1,000 sessions"
          " to 2024-06-30")
    for sym in ("RELIANCE", "TCS", "INFY"):
        d = panel[panel.symbol == sym].sort_values("datetime")
        d = d[["datetime", "open", "high", "low", "close", "adj_close", "volume"]]
        feat = ML_model.create_features(d.reset_index(drop=True), "daily").dropna()
        cols = [c for c in feat.select_dtypes(include=[np.number]).columns
                if c not in {"open", "high", "low", "close", "adj_close", "volume",
                             "target_log_return"}]
        cur, ref = feat.iloc[-CUR:], feat.iloc[-(CUR + REF):-CUR]
        flagged = {}
        for mode in ("plain", "block"):
            n = 0
            names = []
            for c in cols:
                a, b = ref[c].dropna().values, cur[c].dropna().values
                if len(a) < fd.MIN_SAMPLES or len(b) < fd.MIN_SAMPLES:
                    continue
                blk = 1 if mode == "plain" else fd.block_length(a, len(b) // 3)
                p1 = float(np.mean(fd.psi_null(a, b, n_perm=300, block=blk) >= fd.psi(a, b)))
                p2 = float(np.mean(fd.wasserstein_null(a, b, n_perm=300, block=blk)
                                   >= fd.wasserstein(a, b)))
                if p1 < 0.025 or p2 < 0.025:
                    n += 1
                    names.append(c)
            flagged[mode] = (n, names)
        print(f"    {sym:<9} {len(cols)} features: plain null flags {flagged['plain'][0]:2d}, "
              f"block null flags {flagged['block'][0]:2d} "
              f"({', '.join(flagged['block'][1][:6]) or '-'})")


if __name__ == "__main__":
    sys.exit(main())
