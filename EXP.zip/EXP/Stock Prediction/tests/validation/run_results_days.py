"""
Results days on NSE: how much riskier is a forecast window that contains one,
and does a measured widening restore the cone's coverage?

Benklifa, *Think Like an Option Trader*, Ch. 5, separates risk into "known
unknowns" and "unknown unknowns". A results announcement is the purest known
unknown: its DATE is public (SEBI's listing rules require at least two working
days' notice, and most companies give one to three weeks), its OUTCOME is not.
An option trader sees it in the price: implied volatility jumps for the expiry
that spans it. A forecast cone calibrated on all days treats it as a normal day.

Pre-registered, on the survivorship-free bhavcopy panel, 2018-01-01 ..
2024-06-30 (before the reserved period):

* Event days: the first session on or after each results board meeting
  (``day0``) and the session after it (``day1``), because many companies report
  after the close.
* Scale: each name's one-step EWMA sigma forecast (lambda 0.94), so a day's
  surprise is z = r / sigma.
* (1) Variance ratio E[z^2] on day0, day1 and all other days, by half.
* (2) Coverage of a 95% band |R_h| <= q * sigma * sqrt(h), q calibrated on
  2018-2021 over every window, scored 2022-01 .. 2024-06 separately for
  windows that contain an event day and windows that do not; h = 1, 5, 10.
* (3) The widening: sigma_h^2 = sigma^2 * (h + sum over event days in the
  window of (k_d - 1)), with k_day0, k_day1 estimated on 2018-2021 only;
  recalibrate q on 2018-2021 and score again.

Caveat: the calendar gives meeting dates, not announcement dates, so a window
is treated as knowing its event from the origin. For h <= 10 sessions that is
true for almost every meeting, given the usual notice.

Run::

    python tests/validation/run_results_days.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import corporate_events as ce               # noqa: E402
from var_models import ewma_volatility      # noqa: E402

START, END = "2018-01-01", "2024-06-30"
FIT_END = pd.Timestamp("2021-12-31")
TEST_START = pd.Timestamp("2022-01-01")
HORIZONS = (1, 5, 10)
CAL_CACHE = os.path.join(_HERE, "results_calendar_2018_2024.csv")
OUT = os.path.join(_HERE, "results_days.csv")


def calendar():
    if os.path.exists(CAL_CACHE):
        c = pd.read_csv(CAL_CACHE, parse_dates=["date"])
    else:
        print("  fetching NSE's event calendar 2017-12 .. 2024-06 (one-off, cached) ...")
        c = ce.results_calendar("2017-12-01", END)
        c.to_csv(CAL_CACHE, index=False)
    return c


def name_frame(g, events):
    """Per-session returns, EWMA sigma and day0/day1 flags for one name."""
    g = g.sort_values("datetime")
    d = pd.DataFrame({"adj": g["adj_close"].to_numpy(float)},
                     index=pd.to_datetime(g["datetime"].to_numpy()))
    d["r"] = np.log(d["adj"]).diff()
    r = d["r"].to_numpy()
    sig = np.full(len(r), np.nan)
    sig[1:] = ewma_volatility(np.nan_to_num(r[1:]), lam=0.94, warmup=20)   # sig[t] forecasts r[t]
    d["sigma"] = sig
    d["day0"] = False
    d["day1"] = False
    idx = d.index
    for ev in events:
        k = idx.searchsorted(ev)
        if k < len(idx):
            d.iloc[k, d.columns.get_loc("day0")] = True
            if k + 1 < len(idx):
                d.iloc[k + 1, d.columns.get_loc("day1")] = True
    return d.dropna(subset=["r", "sigma"])


def windows(d, h, k0=1.0, k1=1.0):
    """h-session windows from each origin: standardised return and event content."""
    r = d["r"].to_numpy()
    sig = d["sigma"].to_numpy()
    e0 = d["day0"].to_numpy().astype(float)
    e1 = d["day1"].to_numpy().astype(float)
    cs = np.r_[0.0, np.cumsum(r)]
    c0 = np.r_[0.0, np.cumsum(e0)]
    c1 = np.r_[0.0, np.cumsum(e1)]
    n = len(r)
    rows = []
    for t in range(0, n - h):
        # origin = close of session t; window = sessions t+1 .. t+h
        R = cs[t + h + 1] - cs[t + 1]
        n0 = c0[t + h + 1] - c0[t + 1]
        n1 = c1[t + h + 1] - c1[t + 1]
        s = sig[t + 1]                      # the forecast made at the close of t
        rows.append((d.index[t], R, s, n0, n1))
    w = pd.DataFrame(rows, columns=["origin", "R", "sigma", "n0", "n1"])
    w["event"] = (w.n0 + w.n1) > 0
    w["u"] = w.R / (w.sigma * np.sqrt(h))
    w["u_adj"] = w.R / (w.sigma * np.sqrt(h + w.n0 * (k0 - 1) + w.n1 * (k1 - 1)))
    return w


def main():
    print("=" * 78)
    print("RESULTS DAYS ON NSE  (Benklifa, Think Like an Option Trader, Ch. 5)")
    print("=" * 78)
    cal = calendar()
    print(f"  {len(cal):,} results meetings, {cal.symbol.nunique():,} symbols")
    panel, _ = bc.build_panel(START, END, n=200, verbose=False)
    by_sym = {s: g.date.values for s, g in cal.groupby("symbol")}
    frames = {}
    for s, g in panel.groupby("symbol"):
        if len(g) < 500 or s not in by_sym:
            continue
        frames[s] = name_frame(g, pd.to_datetime(by_sym[s]))
    print(f"  {len(frames)} names with results dates and >= 500 sessions")

    # ---------------------------------------------------- 1: variance ratio
    allz = pd.concat([f.assign(symbol=s) for s, f in frames.items()])
    allz["z2"] = (allz.r / allz.sigma) ** 2
    print("\n1. HOW BIG IS A RESULTS DAY?  E[z^2], z = return / EWMA sigma (normal day ~ 1)")
    print(f"  {'':<12}{'day0':>8}{'day1':>8}{'other':>8}{'n day0':>9}")
    k = {}
    for lab, part in (("2018-2021", allz[allz.index <= FIT_END]),
                      ("2022-2024", allz[allz.index >= TEST_START]),
                      ("all", allz)):
        e0 = part[part.day0].z2.mean()
        e1 = part[part.day1].z2.mean()
        o = part[~part.day0 & ~part.day1].z2.mean()
        print(f"  {lab:<12}{e0:8.2f}{e1:8.2f}{o:8.2f}{int(part.day0.sum()):9,d}")
        if lab == "2018-2021":
            k = {"k0": e0 / o, "k1": e1 / o}
    p95 = allz[allz.day0 | allz.day1].assign(az=lambda x: np.sqrt(x.z2))
    print(f"  share of event days with |z| > 3: {np.mean(p95.az > 3):.1%} "
          f"(other days {np.mean(np.sqrt(allz[~allz.day0 & ~allz.day1].z2) > 3):.1%})")
    print(f"  fitted on 2018-2021: k_day0 = {k['k0']:.2f}, k_day1 = {k['k1']:.2f}")

    # ---------------------------------------------------- 2-3: coverage
    print("\n2-3. 95% BAND COVERAGE, scored 2022-01 .. 2024-06 (q calibrated on 2018-2021)")
    print(f"  {'h':>3}  {'windows w/ event':>17}{'plain':>8}{'widened':>9}   "
          f"{'no event':>9}{'plain':>8}{'widened':>9}   {'width x':>8}")
    rows = []
    for h in HORIZONS:
        W = pd.concat([windows(f, h, k["k0"], k["k1"]) for f in frames.values()])
        tr, te = W[W.origin <= FIT_END], W[W.origin >= TEST_START]
        q = np.quantile(np.abs(tr.u), 0.95)
        qa = np.quantile(np.abs(tr.u_adj), 0.95)
        ev, ne = te[te.event], te[~te.event]
        cov = lambda x, col, qq: float(np.mean(np.abs(x[col]) <= qq))   # noqa: E731
        width = float(np.median(np.sqrt((h + ev.n0 * (k["k0"] - 1) + ev.n1 * (k["k1"] - 1)) / h)) * qa / q)
        rec = {"h": h, "n_event": len(ev), "cov_event_plain": cov(ev, "u", q),
               "cov_event_widened": cov(ev, "u_adj", qa), "n_none": len(ne),
               "cov_none_plain": cov(ne, "u", q), "cov_none_widened": cov(ne, "u_adj", qa),
               "event_width_ratio": width, "q": q, "q_adj": qa}
        rows.append(rec)
        print(f"  {h:>3}  {len(ev):>17,d}{rec['cov_event_plain']:8.1%}{rec['cov_event_widened']:9.1%}   "
              f"{len(ne):>9,d}{rec['cov_none_plain']:8.1%}{rec['cov_none_widened']:9.1%}   {width:8.2f}")
    # ---------------------------------------------------- 4: just after one
    # The mirror case: a volatility forecast made in the sessions just AFTER a
    # results day has the event's move in it, and the event will not repeat.
    print("\n4. JUST AFTER A RESULTS DAY: windows starting within 5 sessions of one (none inside)")
    print(f"  {'h':>3}  {'windows':>9}{'coverage':>10}{'E[u^2]':>9}   other windows: {'coverage':>9}{'E[u^2]':>8}")
    for h in HORIZONS:
        W = []
        for f in frames.values():
            w = windows(f, h, k["k0"], k["k1"])
            ev = (f["day0"] | f["day1"]).to_numpy().astype(float)
            recent = pd.Series(ev).rolling(5, min_periods=1).sum().to_numpy()[:len(w)]
            w["after"] = (recent > 0) & ~w["event"].to_numpy()
            W.append(w)
        W = pd.concat(W)
        tr, te = W[W.origin <= FIT_END], W[W.origin >= TEST_START]
        qa = np.quantile(np.abs(tr.u_adj), 0.95)
        a, o = te[te.after], te[~te.after & ~te.event]
        print(f"  {h:>3}  {len(a):>9,d}{np.mean(np.abs(a.u_adj) <= qa):10.1%}{np.mean(a.u_adj ** 2):9.2f}"
              f"   {'':>15}{np.mean(np.abs(o.u_adj) <= qa):9.1%}{np.mean(o.u_adj ** 2):8.2f}")

    pd.DataFrame(rows).to_csv(OUT, index=False)
    pd.Series(k).to_csv(OUT.replace(".csv", "_k.csv"))
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
