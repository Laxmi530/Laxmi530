"""
Out-of-sample confirmation of Section 49's residual reversal on July-December
2024: after every published panel study (they stop at 2024-06-30) and before
the reserved period (2025-01-01). README section 67 found this half-year gives
the signal about 63% power while costing the reserved period nothing.

Written down before running
---------------------------
* Signal: Section 49's, unchanged and imported from its driver - the trailing
  5-day return left after removing the top k = 5 principal components of a
  252-day window of daily returns; 5-day signal and hold.
* Universe: 400 names by liquidity screened on the year before 2023-07-01
  (``build_panel``'s pre-window screen), prices from 2023-07-01 so the first
  PCA window is full by July 2024. Signal days from 2024-07-01 to the last day
  with a 5-day forward return inside 2024.
* THE TEST: the k = 5 rank IC, Fama-MacBeth with Newey-West at 5 lags, must be
  negative with t < -1.96. Section 49 measured IC -0.0325 (t -7.75) over
  2019-2024H1.
* Reported, not tested: raw and k = 1, 3; the decile book's gross per
  rebalance over all five phases; turnover and breakeven against the 22.2 bp
  delivery round trip (Section 55).

The cache also holds 2025-2026 days. ``build_panel`` refuses to read them
(``bhavcopy.HOLDOUT_START``) and nothing here asks it to.

Run::

    python tests/validation/run_reversal_confirmation.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))
sys.path.insert(0, _HERE)

import bhavcopy as bc                                          # noqa: E402
import strategy_metrics as sm                                  # noqa: E402
from run_residual_reversal import HOLD, KS, WINDOW, DECILE, book, signals_at   # noqa: E402

LOAD_FROM, TEST_FROM, END, N = "2023-07-01", "2024-07-01", "2024-12-31", 400
# Section 49 as re-run after the renamed-company fix (section 74).
PUBLISHED = {"raw": (-0.0266, -4.16), "pca1": (-0.0315, -5.97), "pca3": (-0.0306, -6.80),
             "pca5": (-0.0335, -8.08)}
DELIVERY_BP = 22.2
OUT = os.path.join(_HERE, "reversal_confirmation.csv")


def main():
    print("=" * 78)
    print("RESIDUAL REVERSAL, OUT OF SAMPLE: JULY-DECEMBER 2024  (Section 49's signal, unchanged)")
    print("=" * 78)
    actions = bc.corporate_actions(pd.Timestamp(LOAD_FROM) - pd.Timedelta(days=400), END)
    panel, rep = bc.build_panel(LOAD_FROM, END, n=N, actions=actions, verbose=False,
                                purpose="Section 49 confirmation, 2024H2")
    px = panel.pivot_table(index="datetime", columns="symbol", values="adj_close",
                           aggfunc="last").sort_index()
    assert px.index.max() < bc.HOLDOUT_START
    R = np.log(px / px.shift(1))
    fwd_all = np.log(px.shift(-HOLD) / px)
    names = ["raw"] + [f"pca{k}" for k in KS]
    first = px.index.searchsorted(pd.Timestamp(TEST_FROM))
    daily = []
    for i in range(max(first, WINDOW), len(px) - HOLD):
        s = signals_at(R, i)
        if s is None:
            continue
        f = fwd_all.iloc[i].reindex(s["raw"].index)
        keep = f.notna()
        if keep.sum() < DECILE * 4:
            continue
        f = f[keep] - f[keep].mean()
        daily.append((i, {n: s[n][keep] for n in names}, f))
    print(f"  {px.shape[1]} names; {len(daily)} signal days, {px.index[daily[0][0]]:%Y-%m-%d} .. "
          f"{px.index[daily[-1][0]]:%Y-%m-%d} (forward returns end {px.index[daily[-1][0] + HOLD]:%Y-%m-%d})")

    rows = []
    print(f"\n  {'signal':<8}{'rank IC':>10}{'t':>8}{'hit':>7}{'published IC (t)':>20}"
          f"{'gross/reb':>11}{'turnover':>10}{'breakeven':>11}")
    for n in names:
        ics = [float(np.corrcoef(sig[n].rank(), f.rank())[0, 1]) for _, sig, f in daily]
        fm = sm.fama_macbeth_ic(pd.Series(ics), lags=HOLD)
        per, turn = [], []
        for p in range(HOLD):
            prev, g, tr = None, [], []
            for i, sig, f in daily:
                if i % HOLD != p:
                    continue
                gi, w = book(sig[n], f)
                w = w.reindex(px.columns, fill_value=0.0)
                g.append(gi)
                tr.append(2.0 if prev is None else float((w - prev).abs().sum()))
                prev = w
            per.append(np.mean(g))
            turn.append(np.mean(tr))
        gross, to = float(np.mean(per)), float(np.mean(turn))
        be = 1e4 * 2.0 * gross / to
        pic, pt = PUBLISHED[n]
        rows.append({"signal": n, "mean_ic": fm["mean_ic"], "t_stat": fm["t_stat"], "hit_rate": fm["hit_rate"],
                     "published_ic": pic, "published_t": pt, "gross_per_rebalance": gross,
                     "gross_phase_min": min(per), "gross_phase_max": max(per), "turnover": to,
                     "breakeven_bp": be, "n_days": len(ics)})
        print(f"  {n:<8}{fm['mean_ic']:+10.4f}{fm['t_stat']:+8.2f}{fm['hit_rate']:7.2f}"
              f"{f'{pic:+.4f} ({pt:+.2f})':>20}{gross:+11.4%}{to:10.2f}{be:9.1f}bp")
    out = pd.DataFrame(rows)
    out.to_csv(OUT, index=False)

    k5 = out[out.signal == "pca5"].iloc[0]
    passed = k5.mean_ic < 0 and k5.t_stat < -1.96
    print("\n" + "=" * 78)
    print(f"THE TEST (k = 5): IC {k5.mean_ic:+.4f}, t {k5.t_stat:+.2f} over {int(k5.n_days)} days -> "
          + ("CONFIRMED out of sample" if passed else "NOT confirmed"))
    print(f"  size against the published IC: {k5.mean_ic / PUBLISHED['pca5'][0]:.0%}")
    print(f"  gross {k5.gross_per_rebalance:+.3%} per 5-day rebalance "
          f"({k5.gross_phase_min:+.3%} .. {k5.gross_phase_max:+.3%} across phases); breakeven "
          f"{k5.breakeven_bp:.1f} bp against {DELIVERY_BP} bp for a delivery round trip")
    print(f"  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
