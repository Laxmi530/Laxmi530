"""
Kanwar & Gupta, *Python for Trading on Technical*: the indicators it adds, and
its one trading setup, tested.

1. Indicators. The book computes CCI, Stochastic %K, Stochastic RSI, Balance
   of Power, the Chaikin A/D oscillator and On-Balance Volume with TA-Lib.
   The model features (``ML_model.create_features``) already carry SMA
   ratios, EMA/MACD, RSI, ATR, a price z-score and volume ratios. Adding a
   feature is a trial against a model zoo with no edge (Section 43), so the
   bar is: does it carry information the existing set does not? Measured as
   the largest |Spearman| with any existing feature, pooled over names.

2. The setup (pp. 128-130): long when close > SMA(a) AND RSI(b) > 50, flat
   otherwise; a in range(20, 220, 20), b in {14, 21}: 20 configurations on
   the book's eight NSE names, with the best read off in-sample. Tested here
   with the Probability of Backtest Overfitting (Section 52), a first-half /
   second-half split against buy & hold, and itemised costs (Section 55):
   the setup is long-only, so it trades cash delivery (~22.2 bp a round
   trip), not the ~1 bp the book charges.

2018-01-01 .. 2024-06-30, survivorship-free (HDFC is present until its 2023
merger), before the reserved period.

Run::

    python tests/validation/run_kanwar_setup.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                  # noqa: E402
import ML_model as M                   # noqa: E402
import strategy_metrics as sm          # noqa: E402

START, END = "2018-01-01", "2024-06-30"
BOOK_NAMES = ("RELIANCE", "HDFC", "SBIN", "LT", "TATAMOTORS", "ICICIBANK", "NESTLEIND", "INFY")
INDICATOR_NAMES = ("RELIANCE", "TCS", "INFY", "HDFCBANK", "ITC", "SBIN", "LT", "MARUTI")
SMAS, RSIS = list(range(20, 220, 20)), [14, 21]
WARMUP = 220
OUT = os.path.join(_HERE, "kanwar_setup.csv")


def wilder_rsi(close, n):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1.0 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1.0 / n, adjust=False).mean()
    return 100.0 - 100.0 / (1.0 + up / dn.replace(0, np.nan))


def book_indicators(d):
    """
    The indicators the book adds, with the book's own TA-Lib calls and periods
    (pp. 87-108): CCI(14); slow Stochastic (5, 3, 3); Stochastic RSI (14, 5,
    3); Balance of Power smoothed by a 9-day SMA; Chaikin A/D oscillator
    (6, 20); OBV. A first version of this driver used hand-written versions
    with other periods (CCI 20, fast %K 14, ADOSC 3/10) and was corrected.
    """
    import talib as ta
    h, lo, c, o, v = (d[k].to_numpy(dtype=float) for k in ("high", "low", "close", "open", "volume"))
    out = pd.DataFrame(index=d.index)
    out["cci_14"] = ta.CCI(h, lo, c, timeperiod=14)
    out["stoch_slowk"], _ = ta.STOCH(h, lo, c, fastk_period=5, slowk_period=3, slowk_matype=0,
                                     slowd_period=3, slowd_matype=0)
    out["stochrsi_fastk"], _ = ta.STOCHRSI(c, timeperiod=14, fastk_period=5, fastd_period=3,
                                           fastd_matype=0)
    out["bop_ma9"] = ta.SMA(ta.BOP(o, h, lo, c), 9)
    # ADOSC and OBV are in volume units; Spearman within a name is scale-free.
    out["adosc_6_20"] = ta.ADOSC(h, lo, c, v, fastperiod=6, slowperiod=20)
    # OBV is a running level whose value depends on the start date, so as a
    # feature only its change is defined; the book reads the level by eye.
    out["obv_change_20"] = pd.Series(ta.OBV(c, v), index=d.index).diff(20)
    return out


def main():
    print("=" * 78)
    print("KANWAR & GUPTA: INDICATORS AND THE SMA x RSI SETUP")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    # Checked up front, like the other Kanwar drivers, rather than failing with
    # a traceback after the panel has been built.
    try:
        import talib  # noqa: F401
    except ImportError:
        print("\nTA-Lib is not installed (validation-only dependency): pip install TA-Lib")
        return 1
    actions = bc.corporate_actions(pd.Timestamp(START) - pd.Timedelta(days=400), END)
    panel, _ = bc.build_panel(START, END, n=120, actions=actions, verbose=False)

    # ------------------------------------------------------------ 1. indicators
    print("\n1. DOES EACH INDICATOR CARRY INFORMATION THE FEATURES DO NOT?")
    print("   largest |Spearman| with any existing feature, median over names\n")
    best = {}
    for sym in INDICATOR_NAMES:
        d = panel[panel.symbol == sym].sort_values("datetime").reset_index(drop=True)
        if len(d) < 400:
            continue
        d = d[["datetime", "open", "high", "low", "close", "adj_close", "volume"]]
        feats = M.create_features(d, "daily")
        ind = book_indicators(d.set_index("datetime")).reindex(feats.index)
        base = feats.drop(columns=[c for c in ("open", "high", "low", "close", "adj_close",
                                               "volume", "target_log_return", "month",
                                               "dayofweek") if c in feats.columns])
        corr = pd.concat([ind, base], axis=1).corr(method="spearman").loc[ind.columns, base.columns]
        for k in ind.columns:
            j = corr.loc[k].abs().idxmax()
            best.setdefault(k, []).append((abs(corr.loc[k, j]), j))
    rows = []
    for k, v in best.items():
        vals = [x[0] for x in v]
        nearest = pd.Series([x[1] for x in v]).mode().iloc[0]
        rows.append({"indicator": k, "max_abs_spearman": float(np.median(vals)), "nearest": nearest})
        print(f"   {k:<16} {np.median(vals):.2f}   nearest existing feature: {nearest}")

    # --------------------------------------------------------------- 2. setup
    print("\n2. THE SETUP: long if close > SMA(a) and RSI(b) > 50  (20 configurations)")
    cost = sm.india_round_trip_bps("delivery")["total"] / 1e4 / 2.0   # per unit traded
    pooled, split, bh_all = [], [], []
    used = []
    for sym in BOOK_NAMES:
        d = panel[panel.symbol == sym].sort_values("datetime").set_index("datetime")
        if len(d) < WARMUP + 300:
            print(f"   {sym}: not enough history in the panel")
            continue
        used.append(sym)
        adj = d["adj_close"]
        nxt = adj.pct_change().shift(-1)
        cols, labels = [], []
        for a in SMAS:
            for b in RSIS:
                pos = ((adj > adj.rolling(a).mean()) & (wilder_rsi(adj, b) > 50)).astype(float)
                net = pos * nxt - cost * pos.diff().abs().fillna(pos)
                cols.append(net)
                labels.append(f"SMA{a}/RSI{b}")
        R = pd.concat(cols, axis=1).iloc[WARMUP:-1]
        R.columns = labels
        bh = nxt.iloc[WARMUP:-1]
        pooled.append(R)
        bh_all.append(bh)
        half = len(R) // 2
        sr = lambda x: x.mean() / x.std(ddof=1) * np.sqrt(252)
        pick = sr(R.iloc[:half]).idxmax()
        split.append({"symbol": sym, "pick": pick,
                      "pick_is": float(sr(R.iloc[:half])[pick]),
                      "pick_oos": float(sr(R.iloc[half:])[pick]),
                      "bh_oos": float(sr(bh.iloc[half:])),
                      "best_full_total": float((1 + R).prod().max() - 1),
                      "bh_full_total": float((1 + bh).prod() - 1)})
    P = pd.concat(pooled, axis=0).groupby(level=0).mean().sort_index()
    pbo = sm.probability_of_backtest_overfitting(P.to_numpy(), n_blocks=16)
    s = pd.DataFrame(split)
    print(f"   names: {', '.join(used)}; costs: cash delivery {2e4 * cost:.1f} bp round trip")
    print(f"   book's method (best of 20, full period, net): median {s.best_full_total.median():+.0%}"
          f" vs buy & hold {s.bh_full_total.median():+.0%}")
    print(f"   pooled PBO {pbo['pbo']:.2f}; P(in-sample winner loses out of sample) "
          f"{pbo['prob_oos_loss']:.0%}")
    print(f"   optimise on the first half, trade the second: pick's net Sharpe median "
          f"{s.pick_oos.median():+.2f} (in-sample {s.pick_is.median():+.2f}) vs buy & hold "
          f"{s.bh_oos.median():+.2f}; beats it on {(s.pick_oos > s.bh_oos).mean():.0%} of names")
    print(f"   picks: {', '.join(s.pick)}")

    # The rules as the TEXT states them (p. 123): above the 200-day SMA, enter
    # when RSI(21) > 70, exit when it falls below 50. The book's code instead
    # uses RSI > 50 both ways, which is what the grid above tests. One rule,
    # no selection, so no PBO; full period and second half against buy & hold.
    stated = []
    for sym in used:
        d = panel[panel.symbol == sym].sort_values("datetime").set_index("datetime")
        adj = d["adj_close"]
        nxt = adj.pct_change().shift(-1)
        above = adj > adj.rolling(200).mean()
        rsi = wilder_rsi(adj, 21)
        pos = pd.Series(np.nan, index=adj.index)
        pos[above & (rsi > 70)] = 1.0
        pos[(rsi < 50) | ~above] = 0.0
        pos = pos.ffill().fillna(0.0)
        net = (pos * nxt - cost * pos.diff().abs().fillna(pos)).iloc[WARMUP:-1]
        bh = nxt.iloc[WARMUP:-1]
        half = len(net) // 2
        sr = lambda x: x.mean() / x.std(ddof=1) * np.sqrt(252)
        stated.append({"symbol": sym, "total": float((1 + net).prod() - 1),
                       "bh_total": float((1 + bh).prod() - 1),
                       "oos_sr": float(sr(net.iloc[half:])), "bh_oos_sr": float(sr(bh.iloc[half:])),
                       "time_in_market": float(pos.iloc[WARMUP:-1].mean())})
    st = pd.DataFrame(stated)
    print("\n   the rule as the text states it (enter RSI > 70, exit RSI < 50, above SMA200):")
    print(f"   full period net median {st.total.median():+.0%} vs buy & hold {st.bh_total.median():+.0%}; "
          f"in the market {st.time_in_market.median():.0%} of days")
    print(f"   second half net Sharpe median {st.oos_sr.median():+.2f} vs buy & hold "
          f"{st.bh_oos_sr.median():+.2f}; beats it on {(st.oos_sr > st.bh_oos_sr).mean():.0%} of names")
    st.to_csv(OUT.replace(".csv", "_stated_rule.csv"), index=False)

    pd.DataFrame(rows).to_csv(OUT, index=False)
    s.to_csv(OUT.replace(".csv", "_split.csv"), index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
