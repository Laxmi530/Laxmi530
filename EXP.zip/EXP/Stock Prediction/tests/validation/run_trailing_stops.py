"""
Trailing stops and upside targets on NSE (Mladjenovic, *Stock Investing For
Dummies*, 7th ed., Ch. 17).

The book's preferred protection is the trailing stop: a stop that "trails the
stock price upward", at William O'Neill's 8% or 20-25% for volatile stocks. Its
limit orders raise the mirror question: a sell order above the price fills if
the price TOUCHES it. Section 60 measured the fixed stop; this measures both
of these, on the survivorship-free bhavcopy panel, 2018-01-01 .. 2024-06-30
(before the reserved period), adjusted OHLC.

1. **How often is a trailing stop hit**, against a fixed stop at the same
   distance, within 21 and 63 sessions, by volatility quintile?
2. **Which estimate is calibrated**, out of sample in a calm market (2022-07 ..
   2024-06) and a crash (2020-01 .. 2021-12), with sigma from the EWMA forecast
   at each window's start:
     - trailing: the fixed-stop reflection estimate (what the panel shows,
       a lower bound) vs the Levy drawdown formula (stops.trailing_probability);
     - upside touch: the end-point P(gain) vs the reflection estimate upward
       (stops.touch_up_probability).

The trailing reference is the highest adjusted HIGH from entry up to the bar
BEFORE the one being tested, so a low is never compared with a high printed
later on the same bar.

Run::

    python tests/validation/run_trailing_stops.py
"""

import math
import os
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))

import bhavcopy as bc                       # noqa: E402
import stops                                # noqa: E402
from var_models import ewma_next_sigma      # noqa: E402

START, END = "2018-01-01", "2024-06-30"
PERIODS = (("calm 2022-07 .. 2024-06", pd.Timestamp("2022-07-01"), pd.Timestamp("2024-06-30")),
           ("crash 2020-01 .. 2021-12", pd.Timestamp("2020-01-01"), pd.Timestamp("2021-12-31")))
N = 200
BOOK_STOPS = (0.05, 0.08, 0.10, 0.15, 0.20, 0.25)
TARGETS = (0.05, 0.08, 0.10, 0.15)
OUT = os.path.join(_HERE, "trailing_stops.csv")


def _bars(g):
    g = g.sort_values("datetime").reset_index(drop=True)
    low, adj = stops.adjusted_lows(g)
    close = pd.to_numeric(g["close"], errors="coerce").to_numpy(float)
    ratio = np.where(close > 0, adj / close, np.nan)
    high = pd.to_numeric(g["high"], errors="coerce").to_numpy(float) * ratio
    return pd.to_datetime(g["datetime"].to_numpy()), adj, low, high


def _paths(adj, low, high, t, h):
    """Log lows, log highs, and the trailing drawdown of each low, for bars t+1..t+h."""
    lo = np.log(low[t + 1:t + h + 1] / adj[t])
    hi = np.log(high[t + 1:t + h + 1] / adj[t])
    ref = np.maximum.accumulate(np.r_[0.0, hi[:-1]])      # peak through the bar before
    return lo, hi, lo - ref


def _ece(p, y, bins=10):
    p, y = np.asarray(p, float), np.asarray(y, float)
    idx = np.clip((p * bins).astype(int), 0, bins - 1)
    return float(sum(np.mean(idx == b) * abs(p[idx == b].mean() - y[idx == b].mean())
                     for b in range(bins) if np.any(idx == b)))


def main():
    print("=" * 78)
    print("TRAILING STOPS AND TARGETS ON NSE  (Mladjenovic, Ch. 17)")
    print("=" * 78)
    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print("\nNo bhavcopy cache. Run tests/validation/fetch_bhav_cache.py")
        return 1
    panel, _ = bc.build_panel(START, END, n=N, verbose=False)
    names = [s for s, g in panel.groupby("symbol") if len(g) >= 1000]
    print(f"\n  {len(names)} names with >= 1,000 sessions")

    # --------------------------------------------- 1: trailing vs fixed rates
    rows = []
    for s in names:
        dts, adj, low, high = _bars(panel[panel.symbol == s])
        r = np.diff(np.log(adj))
        rec = {"symbol": s, "vol": float(np.nanstd(r) * math.sqrt(252))}
        for h in (21, 63):
            fixed = {st: [] for st in BOOK_STOPS}
            trail = {st: [] for st in BOOK_STOPS}
            for t in range(0, len(adj) - h - 1, h):
                lo, _, dd = _paths(adj, low, high, t, h)
                for st in BOOK_STOPS:
                    lvl = math.log(1 - st)
                    fixed[st].append(bool(np.any(lo <= lvl)))
                    trail[st].append(bool(np.any(dd <= lvl)))
            for st in BOOK_STOPS:
                rec[f"fixed_{h}_{int(st * 100)}"] = float(np.mean(fixed[st]))
                rec[f"trail_{h}_{int(st * 100)}"] = float(np.mean(trail[st]))
        rows.append(rec)
    t = pd.DataFrame(rows).dropna(subset=["vol"])
    t["vol_q"] = pd.qcut(t.vol, 5, labels=False) + 1

    print("\n1. HOW OFTEN A STOP IS HIT: trailing (and fixed at the same distance)")
    for h in (21, 63):
        print(f"\n  within {h} sessions      " + "".join(f"{int(s * 100):>12d}%" for s in BOOK_STOPS))
        def line(df):
            return "".join(f"{df[f'trail_{h}_{int(s * 100)}'].median():7.0%}"
                           f" ({df[f'fixed_{h}_{int(s * 100)}'].median():3.0%})" for s in BOOK_STOPS)
        print("  all names            " + line(t))
        for q, gq in t.groupby("vol_q"):
            print(f"  vol quintile {q} ({gq.vol.median():4.0%}) " + line(gq))

    # ------------------------------------------------ 2: calibration OOS
    print("\n2. CALIBRATION OUT OF SAMPLE (sigma = EWMA forecast at each window's start)")
    cals = []
    for label, p0, p1 in PERIODS:
        cal = []
        for s in names:
            dts, adj, low, high = _bars(panel[panel.symbol == s])
            cut, stop_at = int(np.searchsorted(dts, p0)), int(np.searchsorted(dts, p1, "right"))
            if cut < 250 or stop_at - cut < 120:
                continue
            r = np.diff(np.log(adj))
            for h in (5, 21):
                for t0 in range(cut, stop_at - h - 1, h):
                    sig = ewma_next_sigma(r[:t0])
                    if not np.isfinite(sig) or sig <= 0:
                        continue
                    sh = sig * math.sqrt(h)
                    lo, hi, dd = _paths(adj, low, high, t0, h)
                    for st in (0.05, 0.08, 0.10, 0.15):
                        lvl = math.log(1 - st)
                        cal.append({"period": label, "kind": "trailing", "h": h, "x": st,
                                    "y": float(np.any(dd <= lvl)),
                                    "naive": stops.reflection_probability(st, sh),
                                    "model": stops.trailing_probability(st, sh)})
                    for tg in TARGETS:
                        cal.append({"period": label, "kind": "target", "h": h, "x": tg,
                                    "y": float(np.any(hi >= math.log(1 + tg))),
                                    "naive": 1.0 - stops._norm_cdf(math.log(1 + tg) / sh),
                                    "model": stops.touch_up_probability(tg, sh)})
        c = pd.DataFrame(cal).dropna()
        cals.append(c)
        print(f"\n  {label}: {len(c):,} predictions")
        for kind, naive_name, model_name in (("trailing", "fixed-stop 2x", "Levy drawdown"),
                                             ("target", "end-point", "reflection 2x")):
            ck = c[c.kind == kind]
            print(f"\n  {kind.upper():<10}{'observed':>10}{naive_name:>15}{model_name:>15}"
                  f"    Brier {naive_name:>14}{model_name:>15}")
            for (h, x), gg in ck.groupby(["h", "x"]):
                bn = float(np.mean((gg.naive - gg.y) ** 2))
                bm = float(np.mean((gg.model - gg.y) ** 2))
                print(f"  {h:>2}d {int(x * 100):>3d}%    {gg.y.mean():10.1%}{gg.naive.mean():15.1%}"
                      f"{gg.model.mean():15.1%}          {bn:14.4f}{bm:15.4f}")
            print(f"  ECE pooled: {naive_name} {_ece(ck.naive, ck.y):.3f}   "
                  f"{model_name} {_ece(ck.model, ck.y):.3f}")
    c = pd.concat(cals, ignore_index=True)

    t.to_csv(OUT, index=False)
    c.to_csv(OUT.replace(".csv", "_calibration.csv"), index=False)
    print(f"\n  wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
