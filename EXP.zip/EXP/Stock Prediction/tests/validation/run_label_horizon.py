"""
The Label Horizon Paradox on the NSE panel: does a shorter training label beat
the target it is meant to predict?

The claim
---------
Song, Liu & Chen (ICML 2026, arXiv 2602.03395) argue that the best supervision
signal for a horizon-T forecast is often a return over an *intermediate* horizon
h < T: a shorter label carries less accumulated noise, and the gain outweighs the
signal it gives up. Their evidence is cross-sectional (CSI 300/500/1000, one test
year, five seeds, no significance test). The project's only real signal (§38) is
cross-sectional too, and the experiment is cheap here: retrain §38's classifier
on h-day labels and score every arm against the same 5-day target.

Design (fixed before the first run)
-----------------------------------
* §38's panel exactly: bhavcopy, n=400, 2018-01-01 .. 2024-06-30 (before
  ``bhavcopy.HOLDOUT_START``), its features, its combined name-and-date split
  with a 5-day embargo, its calibrated LightGBM classifier.
* Target T = 5. Training labels h = 1..5. Every arm is scored on the SAME
  validation rows, labelled at T = 5, so arms differ in the training label only.
* The 8 seeds of ``universe_seeds_n400_201801_202406.csv``. The split and the
  model seed are shared by every arm within a seed, so split noise (IC 0.029 to
  0.044 across these seeds) cancels in the paired difference.
* The horizon is chosen WITHOUT looking at the validation block: an inner
  name-and-date split of each seed's training block picks h* by rank IC. Picking
  the best of five on the validation block would be a best-of-five trial.

Pre-registered decision
-----------------------
0. Harness check: the h = 5 arm must reproduce the published per-seed IC to 4
   decimals. If it does not, nothing below is read.
1. Adopt label-horizon selection only if the paired gain IC(h*) - IC(5) is
   positive in at least 6 of 8 seeds AND its median Newey-West t (paired daily
   IC difference, 4 lags) is at least 2.
2. The full h = 1..5 grid on the validation block is descriptive only: it is a
   best-of-five and decides nothing.
3. Two benchmarks, reported whatever happens: the raw 5-day reversal feature on
   the same rows (§38: a single raw feature beats the model), and the IC a
   tradeable book would need. §39's raw sort broke even at 6.1 bp with |IC| 0.052;
   at that turnover gross return scales roughly with IC, so clearing ~22 bp of
   statutory cost needs IC near 0.052 x 22 / 6.1 = 0.19.
4. A shorter label could buy IC with turnover. The rank autocorrelation of each
   arm's score five sessions apart is reported as a turnover proxy.

Run::

    python tests/validation/run_label_horizon.py
    python tests/validation/run_label_horizon.py --quick     # n=100, 2 seeds

Requires the day cache: ``python tests/validation/fetch_bhav_cache.py`` first.
"""

import os
import sys
import time
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

import bhavcopy as bc                       # noqa: E402
import cross_sectional_panel as csp         # noqa: E402
import cross_sectional_model as csm         # noqa: E402
import strategy_metrics as sm               # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))


def _arg(flag, default, cast=str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


QUICK = "--quick" in sys.argv
START = _arg("--start", "2018-01-01")
END = _arg("--end", "2024-06-30")
N = int(_arg("--n", "100" if QUICK else "400"))
TARGET = 5
HORIZONS = (1, 2, 3, 4, 5)
SEEDS = [100 + k * 7 for k in range(2 if QUICK else 8)]
EMBARGO = pd.Timedelta(days=TARGET * 2)      # split_panel's calendar cushion
PUBLISHED = os.path.join(_HERE, "universe_seeds_n400_201801_202406.csv")


def _score(bundle, df):
    P = csm.predict_proba(bundle, df)
    return P[:, 2] - P[:, 0]                 # P(buy) - P(short), as evaluate()


def _ic_series(df, score):
    return sm.ic_by_date(df["datetime"].values, score,
                         df["fwd_excess"].values.astype(float))


def _fm(ic, lags=TARGET - 1):
    return sm.fama_macbeth_ic(ic, lags=lags)


def _score_autocorr(df, score, lag=TARGET):
    """Mean cross-sectional rank correlation of a score with itself `lag`
    sessions later: high means the book's membership persists (low turnover)."""
    s = pd.DataFrame({"d": df["datetime"].values, "t": df["ticker"].values,
                      "s": score}).pivot_table(index="d", columns="t", values="s")
    r = s.rank(axis=1, pct=True)
    a, b = r.iloc[:-lag].to_numpy(), r.iloc[lag:].to_numpy()
    out = []
    for x, y in zip(a, b, strict=True):
        m = np.isfinite(x) & np.isfinite(y)
        if m.sum() >= 5:
            out.append(np.corrcoef(x[m], y[m])[0, 1])
    return float(np.mean(out)) if out else float("nan")


def _block(lab, tickers, end):
    return lab[lab["ticker"].isin(tickers) & (lab["datetime"] < end)]


def main():
    print("=" * 78)
    print("LABEL HORIZON  --  train on h-day labels, score on the 5-day target")
    print("=" * 78)
    print(f"window {START} .. {END} | n={N} | target {TARGET}d | "
          f"h in {HORIZONS} | seeds {SEEDS}")

    if not os.path.isdir(bc.CACHE_DIR) or not os.listdir(bc.CACHE_DIR):
        print(f"\nNo bhavcopy cache at {bc.CACHE_DIR!r}. Run "
              "tests/validation/fetch_bhav_cache.py")
        return 1

    print("\nfetching corporate actions ...")
    actions = bc.corporate_actions(
        pd.Timestamp(START) - pd.Timedelta(days=400), END)
    print("building panel (once) ...")
    panel, brep = bc.build_panel(START, END, n=N, actions=actions, verbose=False)
    cs, rep = csp.build_panel(tickers=brep["universe"],
                              fetch_fn=bc.bhav_fetcher(panel), verbose=False)
    feat = csp.add_ticker_features(cs)
    feat = csp.add_cross_sectional_ranks(feat)
    labs = {h: csp.add_labels(feat, horizon=h) for h in HORIZONS}
    cols = csp.feature_columns(labs[TARGET])
    print(f"  {rep['n_tickers']} usable names | {len(labs[TARGET]):,} rows at "
          f"T={TARGET} | {len(cols)} features")

    published = (pd.read_csv(PUBLISHED).set_index("seed")["rank_ic"]
                 if N == 400 and START == "2018-01-01" and END == "2024-06-30"
                 and os.path.exists(PUBLISHED) else None)

    rows, harness_ok = [], True
    for seed in SEEDS:
        t0 = time.time()
        s = csp.split_panel(labs[TARGET], mode="combined", seed=seed,
                            embargo=TARGET)
        tr_names, cut = s["train_tickers"], pd.Timestamp(s["split_date"])
        val = s["val"]

        # --- inner selection: never touches `val` ---------------------------
        block5 = _block(labs[TARGET], tr_names, cut - EMBARGO)
        inner = csp.split_panel(block5, mode="combined", seed=seed,
                                embargo=TARGET)
        icut = pd.Timestamp(inner["split_date"])
        inner_ic = {}
        for h in HORIZONS:
            itr = _block(labs[h], inner["train_tickers"], icut - EMBARGO)
            b = csm.fit_calibrated(itr, cols, seed=seed, verbose=False)
            inner_ic[h] = _fm(_ic_series(inner["val"], _score(b, inner["val"])))["mean_ic"]
        h_star = max(inner_ic, key=inner_ic.get)

        # --- outer arms, all scored on the same 5-day validation rows -------
        arm = {}
        for h in HORIZONS:
            tr = _block(labs[h], tr_names, cut - EMBARGO)
            if h == TARGET:
                assert len(tr) == s["n_train"], "h=5 arm must train on §38's rows"
            b = csm.fit_calibrated(tr, cols, seed=seed, verbose=False)
            sc = _score(b, val)
            ic = _ic_series(val, sc)
            arm[h] = {"ic": ic, "fm": _fm(ic), "ac": _score_autocorr(val, sc)}

        raw = _fm(_ic_series(val, -val["log_return_5"].values.astype(float)))
        d = (arm[h_star]["ic"] - arm[TARGET]["ic"]).dropna()
        dfm = _fm(d)

        if published is not None and seed in published.index:
            want, got = float(published[seed]), round(arm[TARGET]["fm"]["mean_ic"], 4)
            ok = abs(want - got) < 5e-5
            harness_ok &= ok
            check = f"h=5 IC {got:+.4f} vs published {want:+.4f} {'ok' if ok else 'MISMATCH'}"
        else:
            check = "no published figure to check against"

        row = {"seed": seed, "val_names": len(s["val_tickers"]),
               "h_star": h_star, "gain": dfm["mean_ic"], "gain_t": dfm["t_stat"],
               "raw_rev5_ic": raw["mean_ic"], "raw_rev5_t": raw["t_stat"]}
        for h in HORIZONS:
            row[f"inner_ic_h{h}"] = inner_ic[h]
            row[f"ic_h{h}"] = arm[h]["fm"]["mean_ic"]
            row[f"t_h{h}"] = arm[h]["fm"]["t_stat"]
            row[f"autocorr_h{h}"] = arm[h]["ac"]
        rows.append(row)
        grid = "  ".join(f"h{h} {arm[h]['fm']['mean_ic']:+.4f}" for h in HORIZONS)
        print(f"\n  seed {seed}: inner picks h*={h_star} | {check}")
        print(f"    val IC  {grid}")
        print(f"    gain h*-h5 {dfm['mean_ic']:+.4f} (t {dfm['t_stat']:+.2f}) | "
              f"raw reversal {raw['mean_ic']:+.4f} | {time.time() - t0:.0f}s")

    tab = pd.DataFrame(rows)
    tag = f"n{N}_{str(START)[:7].replace('-', '')}_{str(END)[:7].replace('-', '')}"
    csv = os.path.join(_HERE, f"label_horizon_{tag}.csv")
    tab.to_csv(csv, index=False)

    print("\n" + "=" * 78 + "\nSUMMARY ACROSS SEEDS\n" + "=" * 78)
    print(f"  harness (h=5 reproduces section 38's seeds): "
          f"{'ok' if harness_ok and published is not None else 'NOT CHECKED' if published is None else 'FAILED'}")
    print(f"  h* chosen by the inner split        : "
          f"{tab['h_star'].value_counts().sort_index().to_dict()}")
    print(f"  paired gain IC(h*) - IC(5)          : mean {tab['gain'].mean():+.4f} | "
          f"positive in {int((tab['gain'] > 0).sum())}/{len(tab)} | "
          f"median t {tab['gain_t'].median():+.2f}")
    print("  validation grid (descriptive, best-of-5):")
    for h in HORIZONS:
        print(f"    h={h}: IC {tab[f'ic_h{h}'].mean():+.4f} (sd {tab[f'ic_h{h}'].std(ddof=1):.4f}) | "
              f"score autocorr @5 {tab[f'autocorr_h{h}'].mean():.3f}")
    print(f"  raw 5-day reversal on the same rows : IC {tab['raw_rev5_ic'].mean():+.4f} "
          f"(sign flipped so positive = reversal works)")
    print("  IC a tradeable book would need      : ~0.19 (section 39 scaling)")

    print("\nVERDICT (pre-registered rule)\n" + "-" * 78)
    if published is not None and not harness_ok:
        print("  Harness check FAILED: the h=5 arm does not reproduce section 38. Not read.")
        print("  Either this driver differs from run_universe_seeds.py, or the stored file")
        print("  is stale (NSE revises its corporate-action feed; section 38). Re-run that")
        print("  driver to tell which. See section 73.")
        rc = 1
    elif (tab["gain"] > 0).sum() >= 6 and tab["gain_t"].median() >= 2:
        print("  ADOPT: label-horizon selection improves the 5-day ranking robustly.")
        rc = 0
    else:
        print("  NOT ADOPTED: the gain does not meet the rule (>=6/8 positive and")
        print("  median paired t >= 2). The 5-day label stays.")
        rc = 0
    print(f"\nsaved: {csv}")
    return rc


if __name__ == "__main__":
    sys.exit(main())
