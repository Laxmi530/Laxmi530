"""
Tests for ``charts`` (the forecast charts) and ``model_utils.widen_to_monotone``
(README section 70). Offline: frames built by hand.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import pytest

import charts
from model_utils import widen_to_monotone


def _history(n=30, last="2026-10-16", hourly=False):
    if hourly:
        days = pd.bdate_range(end=last, periods=5)
        idx = pd.DatetimeIndex([d + pd.Timedelta(hours=9, minutes=15) + pd.Timedelta(hours=k)
                                for d in days for k in range(7)])[-n:]
    else:
        idx = pd.bdate_range(end=last, periods=n)
    close = np.linspace(100, 110, len(idx))
    return pd.DataFrame({"datetime": idx, "open": close - 1, "high": close + 2, "low": close - 2,
                         "close": close, "adj_close": close * 0.9, "volume": 1e5})


def _prediction(start="2026-10-19", n=5, widths=(1, 2, 3, 4, 5)):
    dates = pd.bdate_range(start=start, periods=n)
    p = np.full(n, 100.0)
    w = np.asarray(widths, dtype=float)[:n]
    return pd.DataFrame({"datetime": dates, "predicted_price": p, "lower_bound": p - w, "upper_bound": p + w})


def _trace(fig, name):
    return next(t for t in fig.data if t.name == name)


def test_the_cone_fans_out_from_the_last_close():
    hist, pred = _history(), _prediction()
    fig = charts.forecast_chart(hist, pred, "TCS", "1 Day")
    band = _trace(fig, "95% range")
    last = hist["adj_close"].iloc[-1]
    assert band.y[0] == pytest.approx(last)                        # zero width at the last close
    assert pd.Timestamp(band.x[0]) == hist["datetime"].iloc[-1]
    assert list(band.y[1:]) == list(pred["lower_bound"])
    upper = next(t for t in fig.data if t.showlegend is False and t.hoverinfo == "skip")
    assert upper.y[0] == pytest.approx(last) and list(upper.y[1:]) == list(pred["upper_bound"])
    fc = _trace(fig, "Forecast (median)")
    assert fc.y[0] == pytest.approx(last) and len(fc.y) == 6
    assert any(s.line.dash == "dash" and s.yref == "paper" for s in fig.layout.shapes)   # last-close line


def test_weekends_and_holidays_leave_the_axis():
    hist = _history(last="2026-10-16")                             # a Friday
    pred = _prediction(start="2026-10-19")
    pred = pred[pred["datetime"] != pd.Timestamp("2026-10-20")]     # a holiday in the forecast
    fig = charts.forecast_chart(hist, pred, "TCS", "1 Day")
    gaps = fig.layout.xaxis.rangebreaks[0].values
    assert "2026-10-17" in gaps and "2026-10-18" in gaps and "2026-10-20" in gaps
    assert "2026-10-16" not in gaps and "2026-10-19" not in gaps
    hourly = charts.forecast_chart(_history(n=20, hourly=True), _prediction(n=3), "TCS", "1 Hour")
    assert any(rb.pattern == "hour" for rb in hourly.layout.xaxis.rangebreaks)


def test_candles_sit_on_the_forecasts_adjusted_basis():
    hist = _history()
    fig = charts.forecast_chart(hist, _prediction(), "TCS", "1 Day", style="candles")
    c = next(t for t in fig.data if t.type == "candlestick")
    assert np.allclose(c.close, hist["adj_close"])                 # close * (adj / close)
    assert np.allclose(c.high, (hist["close"] + 2) * 0.9)
    # Without OHLC the chart falls back to the line.
    line_only = charts.forecast_chart(hist[["datetime", "adj_close"]], _prediction(), "TCS", "1 Day",
                                      style="candles")
    assert not any(t.type == "candlestick" for t in line_only.data)


def test_missing_columns_raise():
    with pytest.raises(ValueError):
        charts.forecast_chart(pd.DataFrame({"x": [1]}), _prediction(), "TCS", "1 Day")


def test_the_comparison_chart_shows_every_model_and_their_median():
    hist = _history()
    a = _prediction()
    b = _prediction()
    b["predicted_price"] = 104.0
    c = _prediction()[["datetime", "predicted_price"]]              # a model with no band
    c["predicted_price"] = 101.0
    res = {"A": {"history": hist, "prediction": a}, "B": {"history": hist, "prediction": b},
           "C": {"history": hist, "prediction": c}}
    fig = charts.comparison_chart(res, "TCS", "1 Day")
    names = [t.name for t in fig.data]
    assert {"Each model (3, hover for names)", "B", "C", "Median of the models",
            "Median 95% range (2 models)"} <= set(names)
    model_lines = [t for t in fig.data if t.legendgroup == "models"]
    assert len(model_lines) == 3 and sum(bool(t.showlegend) for t in model_lines) == 1   # one legend entry
    med = _trace(fig, "Median of the models")
    assert med.y[1] == pytest.approx(101.0)                         # median of 100, 104, 101
    assert charts.comparison_chart({}, "TCS", "1 Day") is None


def test_a_band_never_narrows_with_the_horizon():
    df = _prediction(widths=(2, 3, 1.5, 4, 3.5))
    df.attrs["kept"] = True
    out = widen_to_monotone(df)
    up = np.log(out["upper_bound"] / out["predicted_price"])
    lo = np.log(out["predicted_price"] / out["lower_bound"])
    assert (np.diff(up) >= -1e-12).all() and (np.diff(lo) >= -1e-12).all()
    assert out["upper_bound"].iloc[2] == pytest.approx(103.0)        # held at the step-2 width
    assert out["upper_bound"].iloc[3] == pytest.approx(104.0)        # a wider step is untouched
    assert out.attrs["kept"] is True
    already = _prediction()
    assert widen_to_monotone(already.copy()).equals(already)
    no_band = _prediction()[["datetime", "predicted_price"]]
    assert widen_to_monotone(no_band.copy()).equals(no_band)
