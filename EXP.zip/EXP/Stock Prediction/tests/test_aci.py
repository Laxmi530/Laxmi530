"""
Tests for ``model_utils.aci_quantile`` (adaptive conformal, README section 71).
Offline: synthetic score streams.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np

from model_utils import aci_quantile
from HAR_RV_model import _aci_multipliers


def test_matches_har_rv_loop():
    """The batched version is HAR-RV's cone procedure, to rounding."""
    rng = np.random.default_rng(0)
    for g in (0.005, 0.01, 0.05):
        z = rng.standard_t(3, size=150)
        ref = _aci_multipliers({1: z}, 1, gamma=g)[0]
        assert abs(aci_quantile(np.abs(z), gamma=g) - ref) <= 1e-12 * abs(ref)


def test_batched_rows_equal_one_at_a_time():
    rng = np.random.default_rng(1)
    S = np.abs(rng.standard_normal((40, 120)))
    out = aci_quantile(S, gamma=0.01)
    assert out.shape == (40,)
    assert np.allclose(out, [aci_quantile(S[i], gamma=0.01) for i in range(40)], rtol=0, atol=1e-12)


def test_recent_misses_widen_and_recent_calm_tightens():
    """Same pool, different order: misses at the end of the stream give the wider band."""
    rng = np.random.default_rng(2)
    calm = np.abs(rng.standard_normal(150))
    big = np.abs(rng.standard_normal(40)) * 3
    late_shock = aci_quantile(np.r_[calm, big])
    early_shock = aci_quantile(np.r_[big, calm])
    static = np.quantile(np.r_[calm, big], 0.95)
    assert late_shock > static > early_shock


def test_level_stays_inside_the_clip():
    pool = np.arange(1.0, 101.0)
    s = np.sort(pool)
    lo_q = np.quantile(s, 1 - 0.30)          # alpha_hi bound
    hi_q = np.quantile(s, 1 - 0.005)         # alpha_lo bound
    for stream in (pool, pool[::-1], np.ones(100)):
        v = aci_quantile(stream)
        assert np.quantile(stream, 1 - 0.30) - 1e-12 <= v <= np.quantile(stream, 1 - 0.005) + 1e-12
    assert lo_q < hi_q


def test_non_finite_dropped_and_empty_is_nan():
    assert np.isnan(aci_quantile([]))
    assert np.isnan(aci_quantile([np.nan, np.inf]))
    a = np.abs(np.random.default_rng(3).standard_normal(60))
    assert aci_quantile(np.r_[a, np.nan]) == aci_quantile(a)
