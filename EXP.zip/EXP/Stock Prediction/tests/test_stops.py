"""
Tests for ``stops`` and the stop-loss reads in ``risk_metrics``.

The load-bearing property: a stop triggers on the path, so the end-point
probability understates it, and for a driftless random walk the reflection
principle makes the touch probability twice the end-point one.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import math

import numpy as np
import pandas as pd
import pytest

import risk_metrics as rm
import stops


def _bars(n=1500, sigma=0.015, steps=40, seed=0):
    """Daily bars from a driftless intraday path, so lows are real path minima."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal((n, steps)) * sigma / np.sqrt(steps)
    path = np.cumsum(z, axis=1)
    level = np.exp(np.r_[0.0, np.cumsum(path[:, -1])])[:-1]
    close = level * np.exp(path[:, -1])
    low = level * np.exp(np.minimum(path.min(axis=1), 0.0))
    return pd.DataFrame({"datetime": pd.bdate_range("2015-01-01", periods=n),
                         "open": level, "high": level * np.exp(np.maximum(path.max(axis=1), 0)),
                         "low": low, "close": close, "adj_close": close})


def test_reflection_is_twice_the_endpoint_and_capped():
    p_end = stops.endpoint_probability(0.10, 0.08)
    assert stops.reflection_probability(0.10, 0.08) == pytest.approx(2 * p_end)
    assert 0.95 < stops.reflection_probability(0.10, 5.0) <= 1.0   # -> 1 as sigma grows
    assert rm.stop_hit_probability(0.7) == 1.0
    assert rm.stop_hit_probability(0.1) == pytest.approx(0.2)


def test_reflection_matches_the_hit_rate_of_a_driftless_path():
    """On a driftless path with genuine intraday lows the touch rate is ~2x end-point."""
    df = _bars(n=6000, seed=1)
    low, adj = stops.adjusted_lows(df)
    h, stop = 10, 0.05
    hits, ends = [], []
    for t in range(0, len(adj) - h - 1, h):
        lo = np.log(low[t + 1:t + h + 1] / adj[t])
        hits.append(np.any(lo <= math.log(1 - stop)))
        ends.append(math.log(adj[t + h] / adj[t]) <= math.log(1 - stop))
    observed, p_end = float(np.mean(hits)), float(np.mean(ends))
    assert observed > 1.5 * p_end                      # the end-point understates
    assert stops.reflection_probability(stop, 0.015 * math.sqrt(h)) == pytest.approx(observed, abs=0.05)


def test_adjusted_lows_survive_a_split():
    df = _bars(n=400, seed=2)
    split = df.copy()
    split.loc[200:, ["open", "high", "low", "close"]] /= 5.0     # raw prices only
    a, _ = stops.adjusted_lows(df)
    b, _ = stops.adjusted_lows(split)
    assert np.allclose(a, b)


def test_stop_for_probability_inverts_stop_hit_probability():
    df = _bars(n=2000, seed=3)
    u, _ = stops.standardised_excursions(df, 10)
    s = stops.stop_for_probability(df, 0.2, 10, sigma_now=0.015, excursions=u)
    p = stops.stop_hit_probability(df, s, 10, sigma_now=0.015, excursions=u)["probability"]
    assert 0 < s < 0.5 and p == pytest.approx(0.2, abs=0.01)


def test_empirical_risk_sizes_the_one_in_five_stop_by_reflection():
    r = np.random.default_rng(4).standard_t(4, 20000) * 0.02
    e = rm.empirical_risk(100.0, r, 5.0)
    assert e["p_stop_hit"] == pytest.approx(min(1.0, 2 * e["p_loss"]))
    # The 1-in-5 stop is the level the price ENDS below 10% of the time.
    assert np.mean(r <= math.log(1 - e["stop_1in5_pct"])) == pytest.approx(0.10, abs=0.005)
    g = rm.risk_from_interval(100.0, 90.0, 111.0, 100.0, 5.0)
    assert g["p_stop_hit"] == pytest.approx(2 * g["p_loss"])
    assert 0 < g["stop_1in5_pct"] < 0.2


def test_beta_recovers_a_known_coefficient():
    rng = np.random.default_rng(5)
    m = rng.normal(0, 0.01, 2000)
    s = 1.4 * m + rng.normal(0, 0.01, 2000)
    assert stops.beta(s, m) == pytest.approx(1.4, abs=0.05)
    assert np.isnan(stops.beta(s[:5], m[:5]))


def test_trailing_stop_formula_matches_its_limits_and_a_simulation():
    from statistics import NormalDist
    # A deep stop: |W| leaving (-a, a) is ~ either side, so twice the fixed stop.
    deep = stops.trailing_probability(0.30, 0.10)
    assert deep == pytest.approx(2 * stops.reflection_probability(0.30, 0.10), rel=1e-3)
    # Always at least the fixed stop, and near-certain when the stop is tight.
    for x in (0.02, 0.05, 0.10, 0.20):
        assert stops.trailing_probability(x, 0.10) >= stops.reflection_probability(x, 0.10)
    assert stops.trailing_probability(0.005, 0.10) > 0.999
    # A fine-step driftless walk converges on it (discrete steps sit just below).
    rng = np.random.default_rng(7)
    w = np.cumsum(rng.normal(0, 0.10 / np.sqrt(2000), (3000, 2000)), axis=1)
    w = np.c_[np.zeros(3000), w]
    dd = (np.maximum.accumulate(w, axis=1) - w).max(axis=1)
    mc = float(np.mean(dd >= -math.log(0.9)))
    assert mc == pytest.approx(stops.trailing_probability(0.10, 0.10), abs=0.03)
    # The panel's version reads the same number off P(end below the stop).
    p_end = NormalDist().cdf(math.log(0.9) / 0.10)
    assert rm.trailing_stop_probability(p_end) == pytest.approx(
        stops.trailing_probability(0.10, 0.10))
    assert rm.trailing_stop_probability(0.6) == 1.0


def test_target_touch_is_the_reflection_principle_upward():
    assert stops.touch_up_probability(0.10, 0.10) == pytest.approx(
        2 * (1 - NormalDistCdf(math.log(1.1) / 0.10)))
    e = rm.empirical_risk(100.0, np.random.default_rng(8).normal(0, 0.03, 5000), 3.0)
    assert e["p_target_touch"] == pytest.approx(min(1.0, 2 * e["p_gain"]))
    assert e["p_trail_hit"] >= e["p_stop_hit"]
    g = rm.risk_from_interval(100.0, 90.0, 111.0, 100.0, 5.0)
    assert g["p_target_touch"] == pytest.approx(2 * g["p_gain"])


def NormalDistCdf(x):
    from statistics import NormalDist
    return NormalDist().cdf(x)


def test_breakeven_move_is_costs_plus_inflation_grossed_up_for_tax():
    be = rm.breakeven_move(5)
    assert be["cost"] == pytest.approx(0.0022, abs=0.0001)        # ~22 bp delivery round trip
    assert be["inflation_part"] == pytest.approx(0.04 * 5 / 252 / (1 - 0.208))
    assert be["move"] == pytest.approx(be["cost"] + be["inflation_part"])
    # Thomsett's annual break-even, inflation / (1 - tax), at a year and zero cost.
    assert rm.breakeven_move(252, cost_bps=0.0, inflation=0.03, tax=0.34)["move"] == \
        pytest.approx(0.03 / 0.66)
