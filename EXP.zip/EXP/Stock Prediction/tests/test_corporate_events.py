"""
Tests for ``corporate_events`` - the ex-dividend notice (Mladjenovic Ch. 6).

Network-free: the nselib-shaped corporate-action fetch is injected.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import pandas as pd
import pytest

import corporate_events as ce


def _feed(rows):
    def fetch(a, b):
        return pd.DataFrame(rows, columns=["symbol", "exDate", "subject", "faceVal"])
    return fetch


DATES = pd.bdate_range("2026-10-19", periods=5)


def test_a_dividend_inside_the_horizon_is_announced_with_its_expected_drop():
    feed = _feed([["MRPL", "21-Oct-2026", "Interim Dividend - Rs 3 Per Share", 10],
                  ["MRPL", "30-Dec-2026", "Interim Dividend - Rs 9 Per Share", 10],
                  ["INFY", "21-Oct-2026", "Interim Dividend - Rs 21 Per Share", 5]])
    n = ce.dividend_notice("MRPL.NS", 150.0, DATES, fetch_fn=feed)
    assert n is not None and len(n["events"]) == 1          # December is outside
    ev = n["events"][0]
    assert ev["ex_date"] == "2026-10-21" and ev["dividend"] == 3.0
    assert ev["yield"] == pytest.approx(0.02)
    assert ev["expected_drop"] == pytest.approx(ce.DROP_RATIO * 3.0)
    assert "QUOTED price" in n["message"] and "not a forecast miss" in n["message"]


def test_no_dividend_in_the_window_and_non_nse_tickers_give_none():
    feed = _feed([["MRPL", "30-Dec-2026", "Interim Dividend - Rs 9 Per Share", 10]])
    assert ce.dividend_notice("MRPL.NS", 150.0, DATES, fetch_fn=feed) is None
    assert ce.dividend_notice("500570.BO", 150.0, DATES, fetch_fn=feed) is None
    assert ce.nse_symbol("infy.ns") == "INFY" and ce.nse_symbol("AAPL") is None


def test_a_failing_feed_never_raises():
    def boom(a, b):
        raise RuntimeError("NSE down")
    assert ce.dividend_notice("MRPL.NS", 150.0, DATES, fetch_fn=boom) is None
