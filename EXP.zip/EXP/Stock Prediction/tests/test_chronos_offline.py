"""
Chronos-2 data preparation must not touch the network.

``prepare_timeseries_data`` labelled its single series with
``get_data.get_ticker(company_name)``, which downloads the full NSE and BSE
listings on every call - at every walk-forward origin of the confidence gate -
so a network blip failed a forecast for the sake of a label (README §59).
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import get_data


def test_chronos_series_id_needs_no_network(monkeypatch):
    def boom(*a, **k):
        raise AssertionError("prepare_timeseries_data reached the network")
    monkeypatch.setattr(get_data, "get_ticker", boom)
    monkeypatch.setattr(get_data, "get_bse_nse_data", boom)
    import chronos_model as cm
    n = 60
    df = pd.DataFrame({"datetime": pd.bdate_range("2024-01-01", periods=n),
                       "adj_close": np.linspace(100, 110, n),
                       "volume": np.full(n, 1e5)})
    out = cm.prepare_timeseries_data(df, "Infosys Limited", interval="1d")
    assert set(out["id"]) == {"Infosys Limited"}



def test_quantile_columns_named_as_strings_become_the_band():
    """chronos-forecasting 2.2.2 names quantile columns '0.025' (strings); the
    cleaner matched only float names, so Chronos lost its 95% band silently."""
    import pandas as pd
    import chronos_model as cm
    for lo, mid, hi in (("0.025", "0.5", "0.975"), (0.025, 0.5, 0.975)):
        raw = pd.DataFrame({"id": ["s"] * 2, "timestamp": pd.date_range("2026-10-19", periods=2),
                            "target_name": ["target"] * 2, "predictions": [100.0, 101.0],
                            lo: [95.0, 94.0], mid: [100.0, 101.0], hi: [105.0, 108.0]})
        out = cm.clean_prediction_output(raw)
        assert {"lower_bound", "upper_bound"} <= set(out.columns), lo
        assert out["volatility"].iloc[1] == round((108.0 - 94.0) / (2 * 1.96), 2)
        assert mid not in out.columns
