"""
Tests for ``hough`` - the stock screens of Hough, *Your Next Great Stock*.

Network-free: yfinance-shaped statement frames and a daily price frame are
built by hand.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import math

import numpy as np
import pandas as pd
import pytest

import hough
import stock_checklist as sc

YEARS = [pd.Timestamp(f"{y}-03-31") for y in (2026, 2025, 2024, 2023)]   # newest first
TODAY = "2026-10-18"


def _frame(rows):
    return pd.DataFrame({k: v for k, v in rows.items()}, index=YEARS).T


INCOME = {"Total Revenue": [150, 130, 115, 100], "Gross Profit": [60, 50, 43, 37],
          "Net Income": [30, 24, 20, 17], "Pretax Income": [40, 32, 27, 23],
          "Tax Provision": [10, 8, 7, 6], "Operating Income": [42, 34, 28, 24],
          "Interest Expense": [1, 1, 1, 1], "Diluted EPS": [3.0, 2.4, 2.0, 1.7],
          "Total Unusual Items": [0, 0, -1, 0]}
BALANCE = {"Total Assets": [160, 150, 140, 130], "Long Term Debt": [10, 12, 14, 16],
           "Total Debt": [12, 14, 16, 18], "Current Debt": [2, 2, 2, 2],
           "Current Assets": [90, 80, 70, 60], "Current Liabilities": [40, 40, 38, 35],
           "Stockholders Equity": [100, 90, 80, 70], "Ordinary Shares Number": [10, 10, 10, 10],
           "Cash And Cash Equivalents": [20, 18, 16, 14]}
CASH = {"Operating Cash Flow": [36, 28, 22, 19], "Investing Cash Flow": [-10, -9, -8, -7],
        "Financing Cash Flow": [-20, -15, -12, -10], "Free Cash Flow": [33, 25, 19, 16],
        "Cash Dividends Paid": [-8, -7, -6, -5], "Repurchase Of Capital Stock": [-2, 0, 0, 0],
        "Net Common Stock Issuance": [-2, 0, 0, 0]}
INFO = {"trailingPE": 12.0, "marketCap": 300.0, "priceToBook": 2.0,
        "priceToSalesTrailing12Months": 2.0, "sector": "Industrials",
        "financialCurrency": "INR", "currency": "INR",
        "heldPercentInsiders": 0.5, "heldPercentInstitutions": 0.2}


def _inputs(income=None, balance=None, cash=None, info=None, dividends=None):
    def merged(base, over):
        d = dict(base)
        d.update(over or {})
        return d
    return {"income": _frame(merged(INCOME, income)), "balance": _frame(merged(BALANCE, balance)),
            "cashflow": _frame(merged(CASH, cash)), "info": merged(INFO, info),
            "dividends": dividends if dividends is not None else pd.Series(dtype=float)}


def _hist(close, volume=500_000):
    close = np.asarray(close, float)
    days = pd.bdate_range(end="2026-10-16", periods=len(close))
    return pd.DataFrame({"datetime": days, "close": close, "adj close": close,
                         "volume": np.full(len(close), float(volume))})


def _labels(rows):
    return {c["label"]: c for _, c in rows}


def _screen(res, name):
    return next(s for s in res["screens"] if s["name"] == name)


def test_an_improving_company_scores_nine_and_one_change_costs_a_point():
    res = hough.build_screens(_inputs(), today=TODAY)
    fs = res["fscore"]
    assert (fs["score"], fs["scored"]) == (9, 9), [(c["label"], c["value"]) for c in fs["checks"]]
    # Issuing shares in the latest year costs exactly the "no net issuance" point.
    res = hough.build_screens(_inputs(cash={"Net Common Stock Issuance": [5, 0, 0, 0]}), today=TODAY)
    lost = [c["label"] for c in res["fscore"]["checks"] if c["verdict"] != sc.GOOD]
    assert res["fscore"]["score"] == 8 and lost == ["No net share issuance"]
    # A debt-free company scores the leverage point (Hough's compromise).
    res = hough.build_screens(_inputs(balance={"Long Term Debt": [0, 0, 0, 0]}), today=TODAY)
    assert _labels([(None, c) for c in res["fscore"]["checks"]])["Debt/assets falling"]["verdict"] == sc.GOOD


def test_roic_debt_accruals_and_payout_follow_the_books_formulas():
    res = hough.build_screens(_inputs(), today=TODAY)
    m = res["metrics"]
    # Tax 10/40 = 25%, at the floor; NOPAT 42 x 0.75; capital = assets - (current
    # liabilities - current debt), averaged: (160 - 38 + 150 - 38) / 2 = 117.
    assert m["roic"] == pytest.approx(42 * 0.75 / 117)
    assert m["accrual"] == pytest.approx(33 - 30)
    assert m["net_payout_yield"] == pytest.approx((8 + 2) / 300)
    s = _labels(res["survivor"])
    assert s["Debt against a year's income"]["verdict"] == sc.GOOD          # 12 / 31 = 0.39 years
    assert "0.39 years" in s["Debt against a year's income"]["value"]
    assert s["Return on invested capital"]["verdict"] == sc.GOOD
    assert s["Accruals"]["verdict"] == sc.GOOD
    # A low tax rate is floored at 25%: the ROIC does not rise when the tax bill falls.
    low_tax = hough.build_screens(_inputs(income={"Tax Provision": [1, 8, 7, 6]}), today=TODAY)
    assert low_tax["metrics"]["roic"] == pytest.approx(m["roic"])
    heavy = hough.build_screens(_inputs(balance={"Total Debt": [40, 14, 16, 18]}), today=TODAY)
    assert _labels(heavy["survivor"])["Debt against a year's income"]["verdict"] == sc.WATCH


def test_lynch_peg_uses_past_eps_growth_plus_the_yield():
    res = hough.build_screens(_inputs(), today=TODAY)
    g = (3.0 / 1.7) ** (1 / 3) - 1
    assert res["metrics"]["eps_growth"] == pytest.approx(g)
    assert res["metrics"]["lynch_peg"] == pytest.approx(12.0 / (g * 100))
    lynch = _screen(res, "Lynch-style")
    assert [c["ok"] for c in lynch["criteria"][:2]] == [True, True]          # 0.57, and 20.9% growth
    # A dividend raises the denominator.
    div = pd.Series([6.0], index=pd.to_datetime(["2026-07-01"]))
    hist = _hist(np.full(300, 100.0))
    with_div = hough.build_screens(_inputs(dividends=div), hist=hist, today=TODAY)
    assert with_div["metrics"]["lynch_peg"] == pytest.approx(12.0 / (g * 100 + 6.0))


def test_a_bonus_issue_does_not_pass_for_dilution():
    # Shares double in the latest year; the vendor's EPS halves with them.
    res = hough.build_screens(_inputs(balance={"Ordinary Shares Number": [20, 10, 10, 10]},
                                      income={"Diluted EPS": [1.5, 2.4, 2.0, 1.7]}), today=TODAY)
    assert math.isnan(res["metrics"]["eps_growth"])
    assert "per-share growth across it is not comparable" in res["metrics"]["eps_why"]
    s = _labels(res["survivor"])
    assert s["EPS keeping up with earnings"]["verdict"] == sc.NA
    assert s["P/E against growth (PEG)"]["verdict"] == sc.NA
    assert _screen(res, "Lynch-style")["criteria"][0]["ok"] is None
    # A steady share count derives EPS from net income per share.
    steady = hough.build_screens(_inputs(), today=TODAY)
    assert steady["metrics"]["eps_growth"] == pytest.approx((30 / 17) ** (1 / 3) - 1)


def test_usd_statements_are_converted_before_meeting_the_rupee_market_value():
    assert sc.statement_fx({"financialCurrency": "USD", "currency": "INR"}) == sc.USD_INR
    assert sc.statement_fx({"financialCurrency": "INR", "currency": "INR"}) == 1.0
    assert math.isnan(sc.statement_fx({"financialCurrency": "EUR", "currency": "INR"}))
    fx = sc.USD_INR
    usd = {"financialCurrency": "USD", "marketCap": 300.0 * fx,
           "priceToSalesTrailing12Months": 228.0}           # Yahoo's figure for a USD filer
    res = hough.build_screens(_inputs(info=usd), today=TODAY)
    assert res["metrics"]["net_payout_yield"] == pytest.approx((8 + 2) / 300)
    assert res["metrics"]["ps"] == pytest.approx(300 / 150)
    assert res["metrics"]["roic"] == pytest.approx(42 * 0.75 / 117)       # a ratio: unchanged
    # The company check's price/sales and price/tangible book are fixed the same way.
    chk = sc.build_checklist({"income": _frame(INCOME), "balance": _frame(BALANCE),
                              "cashflow": _frame(CASH), "info": dict(INFO, **usd),
                              "dividends": pd.Series(dtype=float)}, last_price=36.0 * fx, today=TODAY)
    vals = {c["label"]: c["value"] for _, cs in chk["ratios"] for c in cs}
    assert vals["Price to sales"] == "2.00"
    assert vals["Tangible book value"].startswith("price 3.00×")


def test_lenders_are_not_scored_on_industrial_rules():
    res = hough.build_screens(_inputs(info={"sector": "Financial Services"}), today=TODAY)
    assert res["fscore"]["score"] is None and "lenders" in res["fscore"]["why"]
    s = _labels(res["survivor"])
    for label in ("Debt against a year's income", "Cash flow against profit", "Return on invested capital",
                  "Accruals"):
        assert s[label]["verdict"] == sc.NA, label
    assert _screen(res, "Accrual to Be Kind")["criteria"][0]["ok"] is None
    assert _screen(res, "Buffett-style")["criteria"][2]["ok"] is None


def test_price_facts_flag_the_books_chart_deal_breakers():
    # A year-long fall still going on this week.
    falling = _hist(np.linspace(200, 120, 300))
    s = _labels(hough.build_screens(_inputs(), hist=falling, today=TODAY)["survivor"])
    assert s["Still falling after a down year"]["verdict"] == sc.WATCH
    assert "down on 5 of 5" in s["Still falling after a down year"]["value"]
    # Recovering this week after the same fall: not flagged.
    turning = _hist(np.r_[np.linspace(200, 120, 295), [121, 122, 123, 124, 125]])
    s = _labels(hough.build_screens(_inputs(), hist=turning, today=TODAY)["survivor"])
    assert s["Still falling after a down year"]["verdict"] == sc.GOOD
    # A two-session plunge of 12%.
    p = np.full(300, 100.0)
    p[200:] = [94.0, 88.0] + [88.0] * 98
    s = _labels(hough.build_screens(_inputs(), hist=_hist(p), today=TODAY)["survivor"])
    assert s["Sudden plunge in the past year"]["verdict"] == sc.WATCH
    # A buyout chart: a 20% jump, then flat.
    b = np.full(300, 100.0)
    b[-20:] = 120.0 + np.tile([0.5, -0.5], 10)
    res = hough.build_screens(_inputs(), hist=_hist(b), today=TODAY)
    assert res["price"]["buyout"]["sessions"] == 19
    assert _labels(res["survivor"])["Buyout pattern"]["verdict"] == sc.WATCH
    # Thin trading: under the book's $1 million a day.
    thin = hough.build_screens(_inputs(), hist=_hist(np.full(300, 100.0), volume=1000), today=TODAY)
    assert _labels(thin["survivor"])["Value traded each day"]["verdict"] == sc.WATCH


def test_screen_results_and_what_cannot_be_run():
    big = {"marketCap": 5e12, "priceToSalesTrailing12Months": 1.0}
    rising = _hist(np.linspace(100, 200, 300), volume=2_000_000)
    inputs = _inputs(info=big, income={"Total Revenue": [1.5e12, 1.3e12, 1.15e12, 1.0e12]})
    market = {"r63": 0.01, "r126": 0.02, "date": "2026-10-16"}
    res = hough.build_screens(inputs, hist=rising, market=market, today=TODAY)
    assert _screen(res, "Buy High, Sell Higher")["status"] == hough.PASS
    assert _screen(res, "Sales on Sale")["status"] == hough.PASS
    for name in ("Surprise, Surprise", "Bold Is Beautiful", "Rising Expectations", "Follow the Leaders",
                 "New Dogs", "Tomorrow's Breakthrough"):
        assert _screen(res, name)["status"] == hough.CANT, name
    # Without a market index the price-change legs are not measurable, not failed.
    res = hough.build_screens(inputs, hist=rising, market=None, today=TODAY)
    assert _screen(res, "Sales on Sale")["status"] == hough.PARTLY
    # 25% under the high fails the momentum screens.
    off_high = _hist(np.r_[np.linspace(100, 200, 250), np.full(50, 150.0)], volume=2_000_000)
    res = hough.build_screens(inputs, hist=off_high, market=market, today=TODAY)
    assert _screen(res, "Buy High, Sell Higher")["status"] == hough.FAIL
    # R&D, when a company reports it, runs the Ch. 15 screen.
    rd = hough.build_screens(_inputs(income={"Research And Development": [12, 10, 9, 8]}), today=TODAY)
    crit = {c["label"]: c["ok"] for c in _screen(rd, "Tomorrow's Breakthrough")["criteria"]}
    assert crit["R&D at least 5% of sales"] and crit["R&D up on the year before"]
    assert crit["Market value under 20× R&D"] is False                     # 300 / 12 = 25×
