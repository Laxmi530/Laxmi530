"""
Tests for ``option_market`` (Benklifa, Think Like an Option Trader) and the
results-day widening in ``risk_metrics`` / ``corporate_events``.

Network-free: option chains are synthesised from Black-76 prices.
"""

import math
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import pytest

import corporate_events as ce
import option_market as om
import risk_metrics as rm

ASOF = pd.Timestamp("2026-10-16 15:30")


def _chain(spot, expiry, iv, r=om.RISK_FREE, strikes=None):
    """A synthetic chain priced at one flat volatility."""
    T = (pd.Timestamp(expiry) + pd.Timedelta(hours=15.5) - ASOF).total_seconds() / (365 * 86400)
    df = math.exp(-r * T)
    F = spot / df
    strikes = strikes if strikes is not None else np.arange(spot * 0.8, spot * 1.2 + 1, spot * 0.02)
    return pd.DataFrame({"strike": strikes,
                         "call": [om.black_price(F, k, T, iv, df, "call") for k in strikes],
                         "put": [om.black_price(F, k, T, iv, df, "put") for k in strikes],
                         "call_oi": 1.0, "put_oi": 1.0})


def test_black_and_the_straddle_inversion():
    F, K, T, df = 100.0, 100.0, 0.1, 0.99
    c, p = om.black_price(F, K, T, 0.3, df, "call"), om.black_price(F, K, T, 0.3, df, "put")
    assert c - p == pytest.approx(df * (F - K), abs=1e-9)          # put-call parity
    assert om.straddle_vol(c + p, F, K, T, df) == pytest.approx(0.3, abs=1e-5)
    # The rule of thumb: an ATM straddle is ~0.8 standard deviations of the move.
    assert (c + p) / df / (F * 0.3 * math.sqrt(T)) == pytest.approx(math.sqrt(2 / math.pi), rel=0.01)


def test_market_view_recovers_the_volatility_and_finds_the_protective_put():
    data = {"spot": 1000.0, "asof": ASOF,
            "chains": {pd.Timestamp("2026-10-27"): _chain(1000.0, "2026-10-27", 0.30),
                       pd.Timestamp("2026-11-23"): _chain(1000.0, "2026-11-23", 0.30)}}
    v = om.market_view(data, horizon_days=5, threshold=0.04, model_sigma_h=0.03)
    assert v["iv"] == pytest.approx(0.30, abs=0.002)
    assert v["used"]["expiry"] == "2026-10-27" and not v["event"]
    assert v["sigma_h"] == pytest.approx(0.30 * math.sqrt(5 * 365 / 252 / 365), rel=0.01)
    assert v["put"]["strike"] <= 960.0 and v["put"]["max_loss_pct"] > 0.04
    # A horizon past the first expiry uses the second.
    assert om.market_view(data, horizon_days=15, threshold=0.04)["used"]["expiry"] == "2026-11-23"


def test_an_event_before_the_first_expiry_is_priced_out_of_the_term_structure():
    T1 = (pd.Timestamp("2026-10-27 15:30") - ASOF).total_seconds() / (365 * 86400)
    T2 = (pd.Timestamp("2026-11-23 15:30") - ASOF).total_seconds() / (365 * 86400)
    base, v_event = 0.25, 0.04 ** 2              # a 4% one-day event on top of 25% vol
    iv1 = math.sqrt(base ** 2 + v_event / T1)
    iv2 = math.sqrt(base ** 2 + v_event / T2)
    first = {"expiry": "2026-10-27", "T_years": T1, "iv": iv1}
    second = {"expiry": "2026-11-23", "T_years": T2, "iv": iv2}
    em = om.implied_event_move(first, second, "2026-10-23")
    day = base ** 2 / 252
    assert em["move"] == pytest.approx(math.sqrt(v_event + day), rel=1e-6)
    assert em["ratio"] == pytest.approx((v_event + day) / day, rel=1e-6)
    assert om.implied_event_move(first, second, "2026-11-10") is None   # after the first expiry


def test_parse_and_failures():
    payload = {"records": {"underlyingValue": 2465, "timestamp": "16-Oct-2026 15:40:00", "data": [
        {"strikePrice": 2460, "CE": {"buyPrice1": 40, "sellPrice1": 42, "lastPrice": 41, "openInterest": 5},
         "PE": {"buyPrice1": 0, "sellPrice1": 0, "lastPrice": 44, "openInterest": 7}}]}}
    spot, ts, df = om.parse_chain(payload)
    assert spot == 2465 and ts == pd.Timestamp("2026-10-16 15:40")
    assert df.call.iloc[0] == 41.0 and df.put.iloc[0] == 44.0         # mid, then last price
    assert om.option_view("500570.BO", 5, 0.02) is None               # not an NSE ticker

    def boom(sym):
        raise RuntimeError("NSE down")
    assert om.option_view("TCS.NS", 5, 0.02, fetch_fn=boom) is None


def test_results_sessions_and_the_widening():
    sessions = pd.bdate_range("2026-10-16", periods=6)                # last bar + 5 forecast days
    # Reported after the close on the last bar: only day1 is ahead.
    assert rm.results_sessions(sessions, ["2026-10-16"])[:2] == (0, 1)
    # Inside the horizon: both sessions.
    n0, n1, first = rm.results_sessions(sessions, ["2026-10-21"])
    assert (n0, n1) == (1, 1) and first == pd.Timestamp("2026-10-21")
    # Before the history ends, or after the horizon: nothing.
    assert rm.results_sessions(sessions, ["2026-10-14", "2026-11-30"])[:2] == (0, 0)
    w = rm.results_widening(5, 1, 1)
    assert w == pytest.approx(0.96 * math.sqrt((5 + 1.86 + 2.74) / 5))
    assert rm.results_widening(5, 0, 0) == 1.0
    r = np.array([-0.02, 0.0, 0.01, 0.03])
    assert np.allclose(rm.widen_log_returns(r, 2.0), 0.005 + 2.0 * (r - 0.005))
    lo, hi = rm.widen_interval(100.0, 90.0, 110.0, 2.0)
    assert lo == pytest.approx(81.0) and hi == pytest.approx(121.0)


def test_results_calendar_keeps_results_meetings_only():
    def feed(a, b):
        return pd.DataFrame({"symbol": ["infy", "tcs", "abc"],
                             "purpose": ["Financial Results/Dividend", "Other business matters", "Fund Raising"],
                             "bm_desc": ["", "To consider the financial results", "Raise capital"],
                             "date": ["23-Oct-2026", "09-Oct-2026", "20-Oct-2026"]})
    cal = ce.results_calendar("2026-10-01", "2026-10-31", fetch_fn=feed)
    assert set(cal.symbol) == {"INFY", "TCS"}
    assert ce.upcoming_results("INFY.NS", "2026-10-01", "2026-10-31", fetch_fn=feed) == \
        [pd.Timestamp("2026-10-23")]
    assert ce.upcoming_results("AAPL", "2026-10-01", "2026-10-31", fetch_fn=feed) == []


def test_the_collector_records_each_expiry_once(tmp_path):
    """NSE keeps no option history; option_market.collect_snapshots builds one.
    A second run on the same snapshot must add nothing."""
    data = {"spot": 1000.0, "asof": ASOF,
            "chains": {pd.Timestamp("2026-10-27"): _chain(1000.0, "2026-10-27", 0.30),
                       pd.Timestamp("2026-11-23"): _chain(1000.0, "2026-11-23", 0.28)}}
    rows = om.snapshot_rows("ABC", data, "2026-10-16 18:00:00")
    assert [r["expiry"] for r in rows] == ["2026-10-27", "2026-11-23"]
    assert rows[0]["atm_iv"] == pytest.approx(0.30, abs=0.002) and rows[0]["put_oi"] > 0

    out = str(tmp_path / "chains.csv")
    fetch = lambda s: data if s == "ABC" else None          # noqa: E731
    n, fails = om.collect_snapshots(["ABC", "NOPE"], out, pause=0, fetch_fn=fetch, verbose=False)
    assert n == 2 and fails == [("NOPE", "no chain")]
    assert om.collect_snapshots(["ABC"], out, pause=0, fetch_fn=fetch, verbose=False)[0] == 0
    assert len(pd.read_csv(out)) == 2


def test_symbols_with_an_ampersand_are_url_encoded():
    """M&M and GVT&D failed in the first collection: an unescaped & ends the
    query parameter, so NSE was asked for the chain of 'M'."""
    urls = []

    class _Resp:
        def __init__(self, payload):
            self._p = payload

        def json(self):
            return self._p

    class _Session:
        cookies = {"warm": "1"}

        def get(self, url, **k):
            urls.append(url)
            if "contract-info" in url:
                return _Resp({"expiryDates": ["27-Oct-2026"]})
            return _Resp({"records": {"underlyingValue": 100, "timestamp": "16-Oct-2026 15:40:00",
                                      "data": [{"strikePrice": 100, "CE": {"lastPrice": 3},
                                                "PE": {"lastPrice": 3}}]}})
    om.fetch_chains("M&M", n_expiries=1, session=_Session())
    assert all("symbol=M%26M" in u for u in urls) and len(urls) == 2
