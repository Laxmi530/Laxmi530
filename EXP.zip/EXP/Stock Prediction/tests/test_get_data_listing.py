"""
Tests for ``get_data``'s company listing: one exchange's outage must not empty it.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))


def test_a_bse_outage_falls_back_to_the_nse_listing(monkeypatch):
    """BSE's API answered 403 to every request on 2026-10-18; that used to empty
    the company list and make the app unusable."""
    import pandas as pd
    import get_data
    nse = pd.DataFrame({"NAME OF COMPANY": ["Tata Consultancy Services Limited"],
                        "SYMBOL": ["TCS"]})
    monkeypatch.setattr(get_data.pd, "read_csv", lambda url: nse.copy())

    class _Resp:
        def raise_for_status(self):
            raise RuntimeError("403 Forbidden")
    monkeypatch.setattr(get_data.requests, "get", lambda *a, **k: _Resp())
    out = get_data.get_bse_nse_data()
    assert out["SYMBOL"].tolist() == ["TCS"]


def test_the_yfinance_ticker_carries_the_exchange_suffix(monkeypatch):
    """A bare 'INFY' is the NYSE ADR on yfinance; 'Infosys Limited' fetched it
    in USD. The listing's exchange now pins the suffix."""
    import pandas as pd
    import get_data
    listing = pd.DataFrame({"NAME OF COMPANY": ["Infosys Limited", "Some BSE Co"],
                            "SYMBOL": ["INFY", "SBCO"], "EXCHANGE": ["NS", "BO"]})
    monkeypatch.setattr(get_data, "get_bse_nse_data", lambda: listing)
    assert get_data.get_yf_ticker("Infosys Limited") == "INFY.NS"
    assert get_data.get_yf_ticker("Some BSE Co") == "SBCO.BO"
    assert get_data.get_yf_ticker("Nobody") is None
    assert get_data.get_ticker("Infosys Limited") == "INFY"     # the nselib path still wants it bare


def test_inr_conversion_keeps_the_ticker_and_uses_each_dates_rate(monkeypatch):
    """The FX merge dropped attrs on pandas 3, so a converted stock lost the
    ticker the UI reads for its NSE notices. Each bar takes its own day's rate."""
    import pandas as pd
    import get_data
    days = pd.to_datetime(["2026-06-01", "2026-06-02", "2026-06-03"])
    fx = pd.DataFrame({"Close": [80.0, 81.0, 82.0]}, index=pd.DatetimeIndex(days, name="Date"))

    class _Ticker:
        def __init__(self, sym):
            assert sym == "USDINR=X"
        def history(self, **k):
            return fx
    monkeypatch.setattr(get_data.yf, "Ticker", _Ticker)
    df = pd.DataFrame({"datetime": days, "close": [10.0, 10.0, 10.0],
                       "adj_close": [10.0, 10.0, 10.0]})
    df.attrs["ticker"] = "ACME"
    out = get_data._convert_to_inr(df, "USD")
    assert out.attrs["ticker"] == "ACME"
    assert out.attrs["fx_conversion"]["method"] == "historical"
    assert out["close"].tolist() == [800.0, 810.0, 820.0]
