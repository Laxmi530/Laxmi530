"""
Regression tests: the intraday NSE-session features must be **identical**
whether computed offline (vectorised ``create_features``, used in training) or
online (``_features_from_buffers``, used at serve time), and they must be
**leak-free** (a future bar can never change the current bar's features).

This is the project's highest silent-bug risk: train/serve feature skew would
not raise an error, it would just quietly degrade live forecasts. These tests
lock the contract in place so a future edit to either path is caught.

Run standalone:
    python test_intraday_parity.py
or under pytest:
    pytest test_intraday_parity.py -q

Contract under test (documented in ML_model._add_intraday_features_vec):
NSE sessions are 7 contiguous hourly bars (09:15..15:15). The synthetic data
here is built to honour that, which is exactly the assumption the scalar mirror
relies on.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import ML_model
from model_utils import NSE_BARS_PER_SESSION

# The six intraday features that must match across the two code paths.
INTRADAY_COLS = [
    "bar_in_session",
    "is_first_bar",
    "is_last_bar",
    "ret_since_open",
    "overnight_gap",
    "same_hour_prev_day_ret",
]

_BAR_HOURS = [9, 10, 11, 12, 13, 14, 15]  # 09:15..15:15, 7 bars/session


def _make_hourly_df(n_sessions=40, seed=7):
    """Build a clean synthetic hourly frame: n_sessions x 7 contiguous bars."""
    assert len(_BAR_HOURS) == NSE_BARS_PER_SESSION
    rng = np.random.default_rng(seed)

    # Consecutive weekday sessions (skip Sat/Sun) so index.normalize() groups
    # one calendar day per session, matching the vectorised grouping.
    days, d = [], pd.Timestamp("2024-01-01")  # a Monday
    while len(days) < n_sessions:
        if d.dayofweek < 5:
            days.append(d)
        d += pd.Timedelta(days=1)

    stamps = [
        day + pd.Timedelta(hours=h, minutes=15)
        for day in days
        for h in _BAR_HOURS
    ]

    # A gentle random-walk price path (strictly positive).
    steps = rng.normal(0, 0.004, size=len(stamps))
    price = 1000.0 * np.exp(np.cumsum(steps))

    df = pd.DataFrame({
        "datetime": stamps,
        "open": price * (1 + rng.normal(0, 0.0005, len(stamps))),
        "high": price * (1 + np.abs(rng.normal(0, 0.001, len(stamps)))),
        "low": price * (1 - np.abs(rng.normal(0, 0.001, len(stamps)))),
        "close": price,
        "adj_close": price,
        "volume": rng.integers(1_000, 10_000, len(stamps)).astype(float),
    })
    return df


def _vec_features(df):
    """Run the offline/training feature builder and keep the intraday columns."""
    feat = ML_model.create_features(df, "hourly")
    return feat


def test_offline_online_parity():
    """Each intraday feature from the buffer path must equal the vectorised one."""
    assert ML_model.USE_INTRADAY_FEATURES, "intraday features are disabled"
    df = _make_hourly_df()
    feat = _vec_features(df)
    assert all(c in feat.columns for c in INTRADAY_COLS), "intraday cols missing offline"

    prices = df["adj_close"].to_numpy(float)
    volumes = df["volume"].to_numpy(float)
    stamps = pd.to_datetime(df["datetime"]).to_numpy()

    # Map each surviving feature row back to its position in the raw series.
    # Key on pd.Timestamp, NOT on raw numpy datetime64: `to_numpy()` yields
    # datetime64[ns] while `np.datetime64(Timestamp)` yields microsecond
    # resolution under numpy 1.x, so the two hash differently and every lookup
    # misses with a bare KeyError. pd.Timestamp normalises both sides and is
    # stable across the numpy 1.x / 2.x and pandas 2.x / 3.x boundaries.
    pos_by_time = {pd.Timestamp(t): i for i, t in enumerate(stamps)}

    checked = 0
    mismatches = []
    # Walk the rows that survived create_features' dropna(), skipping the very
    # early ones (warm-up) and sampling across the rest.
    for ts in feat.index[5::3]:
        i = pos_by_time[pd.Timestamp(ts)]
        if i < NSE_BARS_PER_SESSION + 2:
            continue  # need a full prior session for overnight_gap
        online = ML_model._features_from_buffers(
            prices[: i + 1], volumes[: i + 1], pd.Timestamp(ts), "hourly"
        )
        for col in INTRADAY_COLS:
            a = float(feat.loc[ts, col])
            b = float(online[col])
            if not np.isclose(a, b, rtol=1e-9, atol=1e-9):
                mismatches.append((str(ts), col, a, b))
        checked += 1

    assert checked >= 10, f"too few rows checked ({checked})"
    assert not mismatches, f"offline/online mismatch: {mismatches[:5]}"
    return checked


def test_leak_free_future_perturbation():
    """Changing a strictly-future bar must not alter the origin's features."""
    df = _make_hourly_df()
    prices = df["adj_close"].to_numpy(float)
    volumes = df["volume"].to_numpy(float)
    stamps = pd.to_datetime(df["datetime"])

    origin = 120  # a bar deep enough to have full history
    base = ML_model._features_from_buffers(
        prices[: origin + 1], volumes[: origin + 1], stamps.iloc[origin], "hourly"
    )

    # Perturb a FUTURE bar (after the origin) and recompute the SAME origin row.
    perturbed = prices.copy()
    perturbed[origin + 3] *= 1.25
    after = ML_model._features_from_buffers(
        perturbed[: origin + 1], volumes[: origin + 1], stamps.iloc[origin], "hourly"
    )

    diffs = {
        c: (base[c], after[c])
        for c in INTRADAY_COLS
        if not np.isclose(base[c], after[c], rtol=1e-12, atol=1e-12)
    }
    assert not diffs, f"future bar leaked into origin features: {diffs}"
    return True


def test_bar_positions_and_flags():
    """bar_in_session cycles 0..6 with correct first/last flags across sessions."""
    df = _make_hourly_df()
    feat = _vec_features(df)
    bars = feat["bar_in_session"].to_numpy()
    assert set(np.unique(bars)).issubset(set(range(NSE_BARS_PER_SESSION)))
    # first/last flags must agree with the bar index definition
    assert np.array_equal(feat["is_first_bar"].to_numpy(), (bars == 0).astype(int))
    assert np.array_equal(
        feat["is_last_bar"].to_numpy(),
        (bars == NSE_BARS_PER_SESSION - 1).astype(int),
    )
    return True


def test_toggle_off_drops_columns():
    """With the flag off, none of the intraday columns should be produced."""
    original = ML_model.USE_INTRADAY_FEATURES
    try:
        ML_model.USE_INTRADAY_FEATURES = False
        feat = ML_model.create_features(_make_hourly_df(), "hourly")
        present = [c for c in INTRADAY_COLS if c in feat.columns]
        assert not present, f"intraday cols leaked while disabled: {present}"
    finally:
        ML_model.USE_INTRADAY_FEATURES = original
    return True



# ── Every feature, not just the intraday ones (README §55) ─────────────────
# The tests above pin six intraday columns. ATR and range_pct were outside
# them, and the forecast origin served them as close-to-close proxies while
# training used true range: atr_norm ~46% low on NSE bars. This pins all of
# them. EWM-based features carry a finite-buffer warm-up, so they get a
# tolerance sized to an 80-bar seed; everything else must match exactly.
_NON_FEATURES = {"open", "high", "low", "close", "adj_close", "volume",
                 "target_log_return"}
_EWM_TOL = {"rsi_14": 0.5, "macd_norm": 1e-3, "macd_hist_norm": 1e-3,
            "atr_norm": 1e-5}


def _make_daily_ohlc(n=400, seed=3):
    rng = np.random.default_rng(seed)
    price = 1000.0 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    spread = np.abs(rng.normal(0, 0.008, n))
    return pd.DataFrame({
        "datetime": pd.bdate_range("2021-01-01", periods=n),
        "open": price * (1 + rng.normal(0, 0.003, n)),
        "high": price * (1 + spread),
        "low": price * (1 - spread),
        "close": price,
        "adj_close": price,
        "volume": rng.integers(1_000, 10_000, n).astype(float),
    })


def test_every_feature_matches_between_training_and_serving():
    df = _make_daily_ohlc()
    feat = ML_model.create_features(df, "daily")
    cols = [c for c in feat.columns if c not in _NON_FEATURES]
    pos = {pd.Timestamp(t): i for i, t in enumerate(df["datetime"])}
    buf = ML_model._BUFFER_SIZE
    arr = {c: df[c].to_numpy(float) for c in ("adj_close", "volume", "high", "low", "close")}
    bad = []
    for ts in feat.index[-120::7]:
        i = pos[pd.Timestamp(ts)]
        sl = slice(max(0, i + 1 - buf), i + 1)
        on = ML_model._features_from_buffers(
            arr["adj_close"][sl], arr["volume"][sl], pd.Timestamp(ts), "daily",
            highs=arr["high"][sl], lows=arr["low"][sl], closes=arr["close"][sl])
        missing = set(cols) - set(on)
        assert not missing, f"features computed in training but not at serve time: {missing}"
        for c in cols:
            a, b = float(feat.loc[ts, c]), float(on[c])
            tol = _EWM_TOL.get(c, 1e-9)
            if not np.isclose(a, b, rtol=0.0, atol=tol):
                bad.append((c, a, b))
    assert not bad, f"train/serve mismatch: {bad[:6]}"


def test_without_bars_the_origin_row_would_be_skewed():
    # The regression this file now guards: the proxies are a different scale.
    df = _make_daily_ohlc()
    p, v = df["adj_close"].to_numpy(float), df["volume"].to_numpy(float)
    dt = df["datetime"].iloc[-1]
    proxy = ML_model._features_from_buffers(p[-80:], v[-80:], dt, "daily")
    true = ML_model._features_from_buffers(
        p[-80:], v[-80:], dt, "daily", highs=df["high"].to_numpy(float)[-80:],
        lows=df["low"].to_numpy(float)[-80:], closes=df["close"].to_numpy(float)[-80:])
    assert abs(proxy["atr_norm"] / true["atr_norm"] - 1.0) > 0.2


def test_a_missing_high_or_low_on_the_origin_bar_falls_back_not_nan():
    # Passing the bars must never put a NaN into the forecast row: a missing
    # high/low on the last bar falls back to the close-to-close proxy.
    df = _make_daily_ohlc()
    p, v = df["adj_close"].to_numpy(float), df["volume"].to_numpy(float)
    h, lo, c = (df[k].to_numpy(float).copy() for k in ("high", "low", "close"))
    h[-1] = np.nan
    f = ML_model._features_from_buffers(p[-80:], v[-80:], df["datetime"].iloc[-1], "daily",
                                        highs=h[-80:], lows=lo[-80:], closes=c[-80:])
    assert all(np.isfinite(val) for val in f.values()), \
        {k: val for k, val in f.items() if not np.isfinite(val)}
    proxy = ML_model._features_from_buffers(p[-80:], v[-80:], df["datetime"].iloc[-1], "daily")
    assert f["range_pct"] == proxy["range_pct"]


def test_compute_origin_row_uses_the_bars():
    from direct_forecast import compute_origin_row
    df = _make_daily_ohlc()
    feat = ML_model.create_features(df, "daily")
    cols = [c for c in feat.columns if c not in _NON_FEATURES]
    X, _, _ = compute_origin_row(df, cols, "daily")
    h, lo = df["high"].iloc[-1], df["low"].iloc[-1]
    assert np.isclose(X["range_pct"].iloc[0], (h - lo) / df["adj_close"].iloc[-1])
    assert "bb_position" not in cols        # removed: exactly price_zscore / 2


def test_a_market_context_column_reaches_the_origin_row():
    # With market context on, a context feature is not derivable from the price
    # buffers and is overlaid from the frame. The row used to be int64 where it
    # was filled, and pandas 3 refused the float overlay (README section 68).
    from direct_forecast import compute_origin_row
    df = _make_daily_ohlc()
    df["mkt_ret_1"] = np.linspace(-0.02, 0.02, len(df))
    feat = ML_model.create_features(df, "daily")
    cols = [c for c in feat.columns if c not in _NON_FEATURES] + ["mkt_ret_1"]
    X, _, _ = compute_origin_row(df, list(dict.fromkeys(cols)), "daily")
    assert np.isclose(X["mkt_ret_1"].iloc[0], 0.02)
    assert all(str(t) == "float64" for t in X.dtypes)

def _main():
    tests = [
        ("offline==online parity", test_offline_online_parity),
        ("leak-free (future perturbation)", test_leak_free_future_perturbation),
        ("bar positions & flags", test_bar_positions_and_flags),
        ("toggle off drops columns", test_toggle_off_drops_columns),
    ]
    failures = 0
    for name, fn in tests:
        try:
            result = fn()
            extra = f" ({result} rows checked)" if isinstance(result, int) and not isinstance(result, bool) else ""
            print(f"PASS  {name}{extra}")
        except AssertionError as exc:
            failures += 1
            print(f"FAIL  {name}: {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"ERROR {name}: {type(exc).__name__}: {exc}")
    print("-" * 50)
    print("All intraday-parity tests passed." if not failures
          else f"{failures} test(s) failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())
