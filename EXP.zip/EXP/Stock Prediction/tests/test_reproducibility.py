"""
Tests for reproducibility.set_all_seeds / run_manifest.

Confirms seeding is deterministic across RNGs and the manifest captures the
auditable fields. Network-free; manifest timestamp is injected for determinism.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import random

import numpy as np
import pandas as pd

import reproducibility as rp


def test_set_all_seeds_is_deterministic():
    rp.set_all_seeds(123)
    a_np, a_py = np.random.rand(5), [random.random() for _ in range(5)]
    rp.set_all_seeds(123)
    b_np, b_py = np.random.rand(5), [random.random() for _ in range(5)]
    assert np.allclose(a_np, b_np)
    assert a_py == b_py


def test_different_seed_differs():
    rp.set_all_seeds(1)
    a = np.random.rand(5)
    rp.set_all_seeds(2)
    b = np.random.rand(5)
    assert not np.allclose(a, b)


def test_set_all_seeds_returns_seed():
    assert rp.set_all_seeds(7) == 7


def test_manifest_fields_and_injectable_time():
    now = pd.Timestamp("2026-06-29T12:00:00Z")
    m = rp.run_manifest(ticker="RELIANCE.NS", interval="1d", horizon=5,
                        seed=42, fetched_at="2026-06-28", now=now,
                        training_rows=750)
    for key in ("seed", "python", "platform", "packages", "ticker",
                "interval", "horizon", "fetched_at", "run_at_utc"):
        assert key in m, key
    assert m["seed"] == 42
    assert m["ticker"] == "RELIANCE.NS"
    assert m["training_rows"] == 750            # extra field passed through
    assert m["run_at_utc"].startswith("2026-06-29T12:00:00")
    # Versions present for at least the core libs that are definitely installed.
    assert "numpy" in m["packages"] and "pandas" in m["packages"]


def _main():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for fn in fns:
        try:
            fn(); print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failures += 1; print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failures += 1; print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print("-" * 50)
    print("All reproducibility tests passed." if not failures else f"{failures} failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    sys.exit(_main())


# ---------------------------------------------------------------------------
# Pin drift -- recording versions is not the same as checking them
# ---------------------------------------------------------------------------

def _pins_file(tmp_path, body):
    p = tmp_path / "requirements.txt"
    p.write_text(body, encoding="utf-8")
    return str(p)


def test_read_pins_takes_exact_pins_and_skips_the_rest(tmp_path):
    """Ranges cannot 'drift' in the sense check_pins cares about, and comments
    and blank lines must not become phantom packages."""
    path = _pins_file(tmp_path, """
# a comment
numpy==2.4.6

pandas==3.0.3
requests>=2.0          # a range, not a pin
broken-line-without-version
""")
    pins = rp.read_pins(path)
    assert pins == {"numpy": "2.4.6", "pandas": "3.0.3"}


def test_check_pins_reports_drift_against_the_real_environment():
    """numpy is pinned and installed, so it must be checked and not drift --
    this also proves the parser found the real requirements.txt."""
    r = rp.check_pins()
    assert r["checked"] > 5
    assert "numpy" not in r["drift"], r["drift"].get("numpy")


def test_check_pins_flags_a_version_that_does_not_match(tmp_path):
    path = _pins_file(tmp_path, "numpy==0.0.1\n")
    r = rp.check_pins(path)
    assert "numpy" in r["drift"]
    assert r["drift"]["numpy"]["pinned"] == "0.0.1"
    assert r["clean"] is False


def test_check_pins_separates_missing_from_drifted(tmp_path):
    """A package pinned but absent is a different failure from one installed at
    the wrong version, and conflating them hides which fix is needed."""
    path = _pins_file(tmp_path, "numpy==0.0.1\nnot-a-real-package-xyz==1.0\n")
    r = rp.check_pins(path)
    assert "numpy" in r["drift"]
    assert "not-a-real-package-xyz" in r["missing"]


def test_check_pins_handles_the_import_name_vs_distribution_name_gap(tmp_path):
    """'scikit-learn' on PyPI imports as 'sklearn'; looking up the import name
    would report every install as missing."""
    path = _pins_file(tmp_path, "scikit-learn==0.0.1\n")
    r = rp.check_pins(path)
    assert "scikit-learn" in r["drift"], "should be found and flagged, not 'missing'"
    assert not r["missing"]


def test_manifest_records_whether_the_run_was_on_pin():
    """The gap this closes: the manifest used to record versions and never
    compare them, so a run on a drifted stack looked identical to one on the
    pinned stack. Now it says so in its own audit record."""
    m = rp.run_manifest(ticker="TEST", interval="1d", horizon=5,
                        now=pd.Timestamp("2024-01-01", tz="UTC"))
    assert "pin_drift" in m
    assert m["pin_drift"] is None or isinstance(m["pin_drift"], dict)


def test_format_pin_report_is_explicit_in_both_directions():
    clean = rp.format_pin_report({"drift": {}, "missing": [], "checked": 17,
                                  "clean": True})
    assert "matches all 17" in clean
    dirty = rp.format_pin_report({
        "drift": {"numpy": {"pinned": "2.4.6", "installed": "1.26.4"}},
        "missing": [], "checked": 17, "clean": False})
    assert "DRIFT" in dirty and "1.26.4" in dirty and "2.4.6" in dirty


# ==========================================
# Data fingerprint -- which numbers, not just which ticker
# ==========================================
# Adjusted prices are restated on every dividend and split. Measured with
# bhavcopy.adjust_prices(as_of=...): every 2022 session of ten NSE large caps
# carries a different adjusted close depending on whether the history was
# fetched in Jan 2023 or Jun 2024, by up to 6.7%. A manifest of seed, ticker
# and package versions cannot see that; these pin the record that can.

def _frame(n=60, seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2022-01-03", periods=n)
    p = 1000.0 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    return pd.DataFrame({"datetime": idx, "open": p, "high": p * 1.01,
                         "low": p * 0.99, "close": p, "adj_close": p * 0.97,
                         "volume": rng.integers(1e5, 1e6, n).astype(float)})


def test_identical_data_gives_an_identical_fingerprint():
    a, b = _frame(), _frame()
    assert rp.data_fingerprint(a) == rp.data_fingerprint(b)


def test_row_and_column_order_do_not_matter():
    a = _frame()
    shuffled = a.sample(frac=1.0, random_state=3)[list(reversed(a.columns))]
    assert rp.data_fingerprint(a)["sha256"] == rp.data_fingerprint(shuffled)["sha256"]


def test_representation_noise_below_the_rounding_does_not_move_it():
    a = _frame()
    b = a.copy()
    b["adj_close"] = b["adj_close"] + 1e-9
    assert rp.data_fingerprint(a)["sha256"] == rp.data_fingerprint(b)["sha256"]


def test_a_retroactive_restatement_of_one_old_price_is_caught():
    """The failure this exists for: an old session silently re-adjusted."""
    a = _frame()
    b = a.copy()
    b.loc[5, "adj_close"] *= 1.0035      # RELIANCE's measured restatement
    fa, fb = rp.data_fingerprint(a), rp.data_fingerprint(b)
    assert fa["sha256"] != fb["sha256"]
    assert fa["rows"] == fb["rows"] and fa["last"] == fb["last"], \
        "row count and end date are unchanged -- only the hash can tell"


def test_engineered_feature_columns_are_ignored():
    a = _frame()
    b = a.assign(rsi_14=50.0, log_return=0.0)
    assert rp.data_fingerprint(a)["sha256"] == rp.data_fingerprint(b)["sha256"]


def test_a_datetime_index_works_as_well_as_a_column():
    a = _frame()
    b = a.set_index("datetime")
    assert rp.data_fingerprint(a)["sha256"] == rp.data_fingerprint(b)["sha256"]


def test_negative_zero_and_nan_are_canonical():
    a = _frame()
    a.loc[2, "volume"] = 0.0
    a.loc[3, "volume"] = np.nan
    b = a.copy()
    b.loc[2, "volume"] = -0.0
    assert rp.data_fingerprint(a)["sha256"] == rp.data_fingerprint(b)["sha256"]


def test_none_and_empty_frames_do_not_raise():
    assert rp.data_fingerprint(None)["rows"] == 0
    assert rp.data_fingerprint(_frame().iloc[:0])["rows"] == 0


def test_manifest_records_the_data_block_only_when_given_data():
    now = pd.Timestamp("2026-01-01", tz="UTC")
    with_data = rp.run_manifest(ticker="X", now=now, data=_frame())
    without = rp.run_manifest(ticker="X", now=now)
    assert with_data["data"]["sha256"] and with_data["data"]["rows"] == 60
    assert "data" not in without


def test_diff_manifests_names_the_data_first_and_ignores_the_timestamp():
    a_df, b_df = _frame(), _frame()
    b_df.loc[5, "adj_close"] *= 1.0035
    a = rp.run_manifest(ticker="X", now="2026-01-01T00:00:00Z", data=a_df)
    b = rp.run_manifest(ticker="X", now="2026-06-01T00:00:00Z", data=b_df)
    diff = rp.diff_manifests(a, b)
    assert diff and diff[0][0] == "data", diff
    assert all(k != "run_at_utc" for k, _, _ in diff)
    assert rp.diff_manifests(a, a) == []


def test_garch_cone_is_reproducible_across_runs():
    """
    Regression test: arch simulates from the fitted distribution's own
    generator, which np.random.seed does not reach, so two identical
    ARIMA/ARIMAX+GARCH runs produced different bands.
    """
    import warnings
    from arch import arch_model
    import model_utils as mu
    warnings.filterwarnings("ignore")
    r = np.random.default_rng(0).standard_t(5, 800) * 0.01
    for dist in ("normal", "t", "skewt"):
        res = arch_model(r, mean="Zero", vol="Garch", p=1, q=1, dist=dist,
                         rescale=False).fit(disp="off", show_warning=False)
        a = mu.simulate_price_paths(np.zeros(5), res, 100.0, 5)
        np.random.rand(10)                      # disturb the global state
        b = mu.simulate_price_paths(np.zeros(5), res, 100.0, 5)
        for k in ("predicted_price", "lower_bound", "upper_bound"):
            assert np.array_equal(a[k], b[k]), (dist, k)
