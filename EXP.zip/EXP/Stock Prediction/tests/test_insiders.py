"""
Tests for ``insiders`` - SEBI insider-trading disclosures and Hough's
"Follow the Leaders" screen (Ch. 19). Network-free: NSE-shaped rows by hand.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import gzip
import json

import pandas as pd
import pytest

import bhavcopy
import insiders


def _row(symbol="ABC", person="A Kumar", cat="Key Managerial Personnel", mode="Market Purchase",
         txn="Buy", shares=1000, value=5_000_000, before="1.00", after="1.10",
         trade="02-Jan-2023", disclosed="04-Jan-2023 18:00", exchange="NSE"):
    return {"symbol": symbol, "company": symbol + " Ltd", "acqName": person, "personCategory": cat,
            "acqMode": mode, "tdpTransactionType": txn, "secType": "Equity Shares",
            "secAcq": str(shares), "secVal": str(value), "befAcqSharesPer": before,
            "afterAcqSharesPer": after, "acqfromDt": trade, "acqtoDt": trade,
            "intimDt": trade, "date": disclosed, "exchange": exchange}


def test_rows_are_normalised_and_cross_exchange_duplicates_dropped():
    rows = [_row(), _row(exchange="BSE", disclosed="05-Jan-2023 10:00"),     # the same trade again
            _row(person="B Shah", cat="Employees/Designated Employees"),
            _row(person="C Rao", cat="Promoter Group", mode="ESOP")]
    df = insiders.normalise(rows)
    assert len(df) == 3
    first = df[df.person == "A Kumar"].iloc[0]
    assert first["exchange"] == "NSE" and first["disclosed"] == pd.Timestamp("2023-01-04 18:00")
    assert first["kind"] == "executive" and first["value"] == 5_000_000
    assert set(df["kind"]) == {"executive", "other", "promoter"}
    assert insiders.normalise([]).empty


def test_only_open_market_trades_by_the_books_insiders_count():
    df = insiders.normalise([
        _row(), _row(person="D", cat="Director", mode="Market Sale", txn="Sell"),
        _row(person="E", cat="Employees/Designated Employees"),            # not an insider here
        _row(person="F", cat="Promoters", mode="ESOP"),                     # not an open-market buy
        _row(person="G", cat="Promoters", mode="Inter-se-Transfer"),
    ])
    t = insiders.insider_trades(df)
    assert sorted(zip(t.person, t.side)) == [("A Kumar", "buy"), ("D", "sell")]
    assert t.loc[t.person == "A Kumar", "pct"].iloc[0] == pytest.approx(0.10)


def test_the_recipe_needs_two_buys_enough_value_and_a_small_stake():
    one = insiders.insider_trades(insiders.normalise([_row(value=20_000_000)]))
    s = insiders.leaders(one, "2023-01-10")
    assert (s["n"], s["meets"]) == (1, False)                        # one buy is not enough
    two = insiders.insider_trades(insiders.normalise([
        _row(value=5_000_000), _row(person="B", cat="Director", value=4_000_000,
                                    trade="03-Jan-2023", disclosed="05-Jan-2023 12:00")]))
    s = insiders.leaders(two, "2023-01-10")
    assert s["meets"] and s["buyers"] == 2 and s["executive"] and s["value"] == 9_000_000
    small = insiders.insider_trades(insiders.normalise([
        _row(value=3_000_000), _row(person="B", value=3_000_000, trade="03-Jan-2023")]))
    assert not insiders.leaders(small, "2023-01-10")["meets"]       # ₹60 lakh < ₹88 lakh
    big = insiders.insider_trades(insiders.normalise([
        _row(before="10", after="14"), _row(person="B", before="20", after="22", trade="03-Jan-2023")]))
    assert not insiders.leaders(big, "2023-01-10")["meets"]         # 6% of the company
    # The window: 90 days back, and nothing disclosed after the as-of moment.
    assert insiders.leaders(two, "2023-05-01")["n"] == 0
    assert insiders.leaders(two, "2023-01-05 11:00")["n"] == 1


def test_events_fire_once_per_window_and_never_use_a_later_filing():
    rows = [_row(value=5_000_000, trade="02-Jan-2023", disclosed="04-Jan-2023 18:00"),
            _row(person="B", value=5_000_000, trade="09-Jan-2023", disclosed="11-Jan-2023 18:00"),
            _row(person="C", value=5_000_000, trade="16-Jan-2023", disclosed="18-Jan-2023 18:00"),
            # 120 days later: a new window, a new event
            _row(person="A Kumar", value=5_000_000, trade="10-May-2023", disclosed="12-May-2023 18:00"),
            _row(person="B", value=5_000_000, trade="11-May-2023", disclosed="13-May-2023 18:00")]
    ev = insiders.signal_events(insiders.insider_trades(insiders.normalise(rows)))
    assert list(ev["disclosed"]) == [pd.Timestamp("2023-01-11 18:00"), pd.Timestamp("2023-05-13 18:00")]
    assert list(ev["n"]) == [2, 2]                                  # the 18 Jan filing was not yet public


def test_history_caches_finished_months_and_refuses_the_reserved_period(tmp_path):
    calls = []

    def fake(a, b):
        calls.append(a)
        return [_row(disclosed=f"{a:%d-%b-%Y} 18:00")]
    df = insiders.history("2023-01-01", "2023-02-28", cache_dir=str(tmp_path), fetch_fn=fake, verbose=False)
    assert len(df) == 2 and len(calls) == 2
    with gzip.open(tmp_path / "pit_202301.json.gz", "rt", encoding="utf-8") as f:
        assert len(json.load(f)) == 1
    insiders.history("2023-01-01", "2023-02-28", cache_dir=str(tmp_path), fetch_fn=fake, verbose=False)
    assert len(calls) == 2                                          # served from the cache
    with pytest.raises(bhavcopy.HoldoutError):
        insiders.history("2024-12-01", "2025-01-31", cache_dir=str(tmp_path), fetch_fn=fake, verbose=False)


def test_live_view_and_the_hough_screen():
    import hough
    from test_hough import _inputs, TODAY
    rows = [_row(value=5_000_000, trade="01-Oct-2026", disclosed="02-Oct-2026 18:00"),
            _row(person="B", cat="Director", value=5_000_000, trade="05-Oct-2026", disclosed="06-Oct-2026 18:00"),
            _row(person="C", cat="Promoters", mode="Market Sale", txn="Sell", value=2_000_000,
                 trade="07-Oct-2026", disclosed="08-Oct-2026 18:00")]
    view = insiders.live_view("ABC", today=TODAY, fetch_fn=lambda a, b, symbol=None: insiders.normalise(rows))
    assert view["buy"]["meets"] and view["sell"]["n"] == 1 and view["to"] == TODAY
    res = hough.build_screens(_inputs(info={"numberOfAnalystOpinions": 4}), today=TODAY, insider=view)
    s = next(x for x in res["screens"] if x["name"] == "Follow the Leaders")
    assert s["status"] == hough.PASS, [(c["label"], c["ok"], c["value"]) for c in s["criteria"]]
    # Without the disclosures the screen cannot be run, rather than failing.
    res = hough.build_screens(_inputs(), today=TODAY, insider=None)
    assert next(x for x in res["screens"] if x["name"] == "Follow the Leaders")["status"] == hough.CANT
    assert insiders.live_view("ABC", fetch_fn=lambda *a, **k: 1 / 0) is None


XBRL = """<?xml version="1.0" encoding="UTF-8"?>
<xbrli:xbrl xmlns:in-bse-co="http://www.bseindia.com/xbrl/co/2017-09-15/in-bse-co"
            xmlns:xbrli="http://www.xbrl.org/2003/instance">
<in-bse-co:Symbol contextRef="MainI">WSI</in-bse-co:Symbol>
<in-bse-co:NameOfTheCompany contextRef="MainI">W S Industries</in-bse-co:NameOfTheCompany>
<in-bse-co:TypeOfInstrument contextRef="Disclosure1">Equity</in-bse-co:TypeOfInstrument>
<in-bse-co:CategoryOfPerson contextRef="Disclosure1">Promoter and Director</in-bse-co:CategoryOfPerson>
<in-bse-co:NameOfThePerson contextRef="Disclosure1">S Aravindan</in-bse-co:NameOfThePerson>
<in-bse-co:SecuritiesHeldPriorToAcquisitionOrDisposalPercentageOfShareholding contextRef="Disclosure1" decimals="INF">0.0623</in-bse-co:SecuritiesHeldPriorToAcquisitionOrDisposalPercentageOfShareholding>
<in-bse-co:SecuritiesAcquiredOrDisposedNumberOfSecurity contextRef="Disclosure1">9000</in-bse-co:SecuritiesAcquiredOrDisposedNumberOfSecurity>
<in-bse-co:SecuritiesAcquiredOrDisposedValueOfSecurity contextRef="Disclosure1">488611</in-bse-co:SecuritiesAcquiredOrDisposedValueOfSecurity>
<in-bse-co:SecuritiesAcquiredOrDisposedTransactionType contextRef="Disclosure1">Buy</in-bse-co:SecuritiesAcquiredOrDisposedTransactionType>
<in-bse-co:SecuritiesHeldPostAcquistionOrDisposalPercentageOfShareholding contextRef="Disclosure1" decimals="INF">0.0625</in-bse-co:SecuritiesHeldPostAcquistionOrDisposalPercentageOfShareholding>
<in-bse-co:DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyFromDate contextRef="Disclosure1">2026-10-07</in-bse-co:DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyFromDate>
<in-bse-co:DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyToDate contextRef="Disclosure1">2026-10-07</in-bse-co:DateOfAllotmentAdviceOrAcquisitionOfSharesOrSaleOfSharesSpecifyToDate>
<in-bse-co:ModeOfAcquisitionOrDisposal contextRef="Disclosure1">Market Purchase</in-bse-co:ModeOfAcquisitionOrDisposal>
<in-bse-co:TypeOfInstrument contextRef="Disclosure2">Equity</in-bse-co:TypeOfInstrument>
<in-bse-co:CategoryOfPerson contextRef="Disclosure2">Designated Person</in-bse-co:CategoryOfPerson>
<in-bse-co:NameOfThePerson contextRef="Disclosure2">R Iyer</in-bse-co:NameOfThePerson>
<in-bse-co:ModeOfAcquisitionOrDisposal contextRef="Disclosure2">ESOP</in-bse-co:ModeOfAcquisitionOrDisposal>
<in-bse-co:SecuritiesAcquiredOrDisposedTransactionType contextRef="Disclosure2">Buy</in-bse-co:SecuritiesAcquiredOrDisposedTransactionType>
</xbrli:xbrl>"""


def test_new_format_filings_parse_into_the_same_rows():
    rows = insiders.parse_filing(XBRL, {"broadcastDateTime": "09-Oct-2026 10:27:35", "symbol": "WSI"})
    df = insiders.normalise(rows)
    assert len(df) == 2
    p = df[df.person == "S Aravindan"].iloc[0]
    assert p["kind"] == "board" and p["mode"] == "Market Purchase" and p["value"] == 488611
    assert (p["before_pct"], p["after_pct"]) == pytest.approx((6.23, 6.25))          # fractions -> percent
    assert p["disclosed"] == pd.Timestamp("2026-10-09 10:27") and p["trade_from"] == pd.Timestamp("2026-10-07")
    t = insiders.insider_trades(df)
    assert list(t.person) == ["S Aravindan"]                         # the ESOP and the employee are not counted


class _Resp:
    def __init__(self, payload=None, content=b""):
        self._p, self.content = payload, content

    def json(self):
        return self._p

    def raise_for_status(self):
        pass


class _Session:
    cookies = {"nsit": "x"}

    def __init__(self):
        self.urls = []

    def get(self, url, headers=None, timeout=None):
        self.urls.append(url)
        if "corporates-pit-gg" in url:
            return _Resp({"data": [{"symbol": "WSI", "broadcastDateTime": "09-Oct-2026 10:27:35",
                                    "xmlFileName": "https://nsearchives.nseindia.com/x.xml"}]})
        if url.endswith(".xml"):
            return _Resp(content=XBRL.encode("utf-8"))
        return _Resp({"data": [_row(symbol="WSI", person="Old Buyer", disclosed="20-Apr-2026 18:00",
                                    trade="17-Apr-2026")]})


def test_fetch_reads_the_archive_and_the_new_filing_index():
    s = _Session()
    df = insiders.fetch("2026-04-01", "2026-10-19", symbol="WSI", session=s, pause=0)
    assert sorted(df.person) == ["Old Buyer", "R Iyer", "S Aravindan"]
    assert any("corporates-pit-gg" in u and "symbol=WSI" in u for u in s.urls)
    # A window that ends before the new index existed asks only the archive.
    s = _Session()
    insiders.fetch("2024-01-01", "2024-03-31", symbol="WSI", session=s, pause=0)
    assert not any("corporates-pit-gg" in u for u in s.urls)
