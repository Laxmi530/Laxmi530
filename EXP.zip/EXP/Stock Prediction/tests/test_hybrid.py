"""
Tests for ``Hybrid_model`` - the ARIMA + LSTM hybrid and its split-conformal
95% band (README section 69). Offline: synthetic prices; the path arithmetic
is tested with a stand-in network so it runs in milliseconds.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import contextlib
import io

import numpy as np
import pandas as pd
import pytest

import Hybrid_model as hm


class _ConstantNet:
    """A stand-in LSTM that always predicts the same scaled residual."""

    def __init__(self, value):
        self.value, self.calls = value, 0

    def predict(self, x, verbose=0, batch_size=None):
        self.calls += 1
        return np.full((len(x), 1), self.value, dtype=np.float32)


class _Identity:
    def transform(self, x):
        return np.asarray(x, dtype=float)

    def inverse_transform(self, x):
        return np.asarray(x, dtype=float)


def test_the_path_compounds_arima_plus_the_residual_correction():
    lb = hm._LOOK_BACK
    preds = np.array([[0.01, 0.0, -0.01]])
    paths = hm._hybrid_paths(preds, [np.zeros(lb)], [100.0], _ConstantNet(0.002), _Identity())
    expected = 100.0 * np.exp(np.cumsum(preds[0] + 0.002))
    assert np.allclose(paths[0], expected)


def test_a_batch_of_origins_gives_the_same_paths_as_one_at_a_time():
    rng = np.random.default_rng(0)
    lb = hm._LOOK_BACK
    preds = rng.normal(0, 0.01, (4, 5))
    hists = [rng.normal(0, 0.01, lb + 7) for _ in range(4)]
    prices = np.array([100.0, 250.0, 80.0, 1200.0])
    net = _ConstantNet(-0.001)
    batch = hm._hybrid_paths(preds, hists, prices, net, _Identity())
    assert net.calls == 5                                # one network call per step, not per origin
    for i in range(4):
        one = hm._hybrid_paths(preds[i:i + 1], [hists[i]], prices[i:i + 1], _ConstantNet(-0.001), _Identity())
        assert np.allclose(batch[i], one[0])


def _prices(n=420, seed=5):
    rng = np.random.default_rng(seed)
    px = 1000 * np.exp(np.cumsum(rng.normal(0.0003, 0.015, n)))
    return pd.DataFrame({"datetime": pd.bdate_range("2023-01-02", periods=n), "adj_close": px, "close": px})


def test_the_hybrid_forecast_now_carries_a_widening_95_percent_band():
    with contextlib.redirect_stdout(io.StringIO()):
        out = hm.run_hybrid_prediction(_prices(), "1d", 5)
    assert {"lower_bound", "upper_bound", "volatility"} <= set(out.columns)
    assert (out["lower_bound"] < out["predicted_price"]).all()
    assert (out["predicted_price"] < out["upper_bound"]).all()
    width = np.log(out["upper_bound"] / out["lower_bound"])
    assert width.iloc[-1] > width.iloc[0]               # wider five steps out than one


def test_too_little_data_still_forecasts_without_a_band():
    with contextlib.redirect_stdout(io.StringIO()):
        out = hm.run_hybrid_prediction(_prices(n=35), "1d", 3)      # under _LOOK_BACK + 10 returns: ARIMA only
    assert len(out) == 3 and "lower_bound" not in out
