"""
Tests for ``RegimeSwitching_model`` - the Markov switching fit must not depend
on NumPy's global random state (README section 68). Offline: synthetic
two-regime returns.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import contextlib
import io

import numpy as np
import pandas as pd

import RegimeSwitching_model as rs


def _two_regime_returns(n=400, seed=3):
    rng = np.random.default_rng(seed)
    state, out = 0, []
    for _ in range(n):
        if rng.random() < 0.03:
            state = 1 - state
        out.append(rng.normal(0.0008, 0.008) if state == 0 else rng.normal(-0.001, 0.025))
    return pd.Series(out)


def _fit(r):
    with contextlib.redirect_stdout(io.StringIO()):
        return rs._fit_markov_switching(r)


def test_the_fit_is_the_same_whatever_ran_before_it():
    r = _two_regime_returns()
    fits = []
    for seed in (0, 8, 99):
        np.random.seed(seed)                       # what other models left behind
        res = _fit(r)
        fits.append((res.model.order, round(float(res.llf), 6)))
    assert len(set(fits)) == 1, fits


def test_the_callers_random_state_is_left_alone():
    r = _two_regime_returns()
    np.random.seed(11)
    expected = np.random.random(3)
    np.random.seed(11)
    _fit(r)
    assert np.allclose(np.random.random(3), expected)
