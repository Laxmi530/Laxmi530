"""
Tests for :mod:`long_memory` -- R/S, Lo's modified R/S, and DFA.

Each test runs the estimators on a series whose answer is known: independent
noise (no memory), fractional Gaussian noise with a chosen H, an AR(1)
(short memory only) and random-walk levels. The ones that matter most pin
the two ways the textbook procedure misleads (README §56): the classical R/S
reads above 0.5 on independent data, and it reads "long memory" on an AR(1)
that has none.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pytest

import long_memory as lm


def _iid(n, s):
    return np.random.default_rng(s).standard_normal(n)


def _ar1(s, phi=0.6, n=2000):
    rng = np.random.default_rng(s)
    e = rng.standard_normal(n)
    x = np.zeros(n)
    for t in range(1, n):
        x[t] = phi * x[t - 1] + e[t]
    return x


def test_expected_rs_is_increasing_and_smooth():
    v = [lm.expected_rs(n) for n in range(8, 800)]
    assert all(b > a for a, b in zip(v, v[1:]))
    # Asymptotically E[R/S] ~ sqrt(n * pi / 2).
    assert abs(lm.expected_rs(5000) / np.sqrt(5000 * np.pi / 2) - 1) < 0.02


def test_book_rs_reads_above_one_half_on_independent_noise():
    # The bias the corrected estimator exists for: no memory at all, yet the
    # textbook slope reads ~0.57 at the sample sizes the book uses.
    book = np.mean([lm.rs_hurst(_iid(1000, s))["H"] for s in range(20)])
    fixed = np.mean([lm.rs_hurst(_iid(1000, s), corrected=True)["H"] for s in range(20)])
    assert 0.54 < book < 0.60, book
    assert abs(fixed - 0.5) < 0.04, fixed


def test_dfa_recovers_known_hurst_exponents():
    for H in (0.3, 0.5, 0.7):
        a = np.mean([lm.dfa(lm.fgn(2000, H, s))["alpha"] for s in range(10)])
        assert abs(a - H) < 0.05, (H, a)
    walk = np.mean([lm.dfa(np.cumsum(_iid(2000, s)))["alpha"] for s in range(5)])
    assert abs(walk - 1.5) < 0.06, walk


def test_book_dfa_on_absolute_values_is_one_half_for_independent_noise():
    # |x| of iid noise has no memory, so the book's variant reads ~0.5 there;
    # on real returns it reads high because volatility clusters.
    a = np.mean([lm.dfa(_iid(2000, s), abs_input=True)["alpha"] for s in range(10)])
    assert abs(a - 0.5) < 0.04, a


def test_short_memory_fools_rs_but_not_lo():
    # An AR(1) has no long memory. The textbook R/S calls it persistent.
    book = np.mean([lm.rs_hurst(_ar1(s))["H"] for s in range(10)])
    assert book > 0.62, book
    rej = np.mean([lm.lo_modified_rs(_ar1(s))["reject_5pct"] for s in range(60)])
    assert rej < 0.15, rej


def test_lo_test_size_and_power():
    size = np.mean([lm.lo_modified_rs(_iid(2000, s))["reject_5pct"] for s in range(200)])
    assert size < 0.10, size
    power = np.mean([lm.lo_modified_rs(lm.fgn(2000, 0.8, s))["reject_5pct"] for s in range(60)])
    assert power > 0.5, power
    v = lm.lo_modified_rs(lm.fgn(2000, 0.85, 3))
    assert v["direction"] == "persistent" and v["V"] > 1.862


def test_estimators_degrade_gracefully():
    assert np.isnan(lm.rs_hurst(np.ones(500))["H"])          # zero variance
    assert np.isnan(lm.lo_modified_rs(_iid(20, 0))["V"])
    assert np.isnan(lm.dfa(_iid(10, 0))["alpha"])
    out = lm.rs_hurst(_iid(1000, 0))
    assert len(out["scales"]) == len(out["rs"]) == len(out["expected_rs"])


def test_fgn_has_the_requested_autocorrelation():
    # Lag-1 autocorrelation of fGn is 2**(2H-1) - 1.
    x = lm.fgn(20000, 0.75, 1)
    r1 = np.corrcoef(x[1:], x[:-1])[0, 1]
    assert r1 == pytest.approx(2 ** 0.5 - 1, abs=0.03)
