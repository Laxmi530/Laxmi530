"""
Tests for ``oneil`` - the O'Neil-disciple signals coded to the book's rules
(Morales & Kacher, Ch. 5 and 7). Network-free: hand-built price series.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import pytest

import oneil


def _stock(closes, vols, opens=None, lows=None, highs=None):
    n = len(closes)
    c = np.asarray(closes, float)
    return pd.DataFrame({
        "datetime": pd.bdate_range("2020-01-01", periods=n),
        "open": opens if opens is not None else c, "high": highs if highs is not None else c * 1.005,
        "low": lows if lows is not None else c * 0.995, "close": c, "adj_close": c,
        "turnover": np.asarray(vols, float)})


def _base(n=80):
    """A steady uptrend (above the 50-day) with quiet alternating days."""
    c, x = [], 100.0
    for i in range(n):                 # up 0.6%, down 0.3%: real down days, net uptrend
        x *= 1.006 if i % 2 == 0 else 0.997
        c.append(x)
    v = [100.0] * n
    return c, v


def test_the_volume_signature_separates_a_pocket_pivot_from_its_control():
    c, v = _base()
    c += [c[-1] * 1.01]
    v += [150.0]                       # above every down-day volume in the prior 10
    d = oneil.stock_signals(_stock(c, v))
    assert bool(d["pp_core"].iloc[-1]) and not bool(d["pp_control"].iloc[-1])
    c2, v2 = _base()
    c2 += [c2[-1] * 1.01]
    v2 += [90.0]                       # an up day above the 50-day, but below the down volume
    d2 = oneil.stock_signals(_stock(c2, v2))
    assert not bool(d2["pp_core"].iloc[-1]) and bool(d2["pp_control"].iloc[-1])


def test_an_extended_pivot_is_not_proper():
    c, v = _base()
    c += [c[-1] * 1.06]
    v += [150.0]
    lows = np.r_[np.asarray(c[:-1]) * 0.995, c[-1] * 0.99]   # the day's low 4%+ above the 10-day
    d = oneil.stock_signals(_stock(c, v, lows=lows))
    assert bool(d["pp_core"].iloc[-1]) and not bool(d["pp_proper"].iloc[-1])
    assert d["extension"].iloc[-1] > oneil.PP_EXTENSION


def test_a_major_gap_up_and_the_gap_day_low_stop():
    c, v = _base(120)
    n = len(c)
    opens = list(c)
    lows = [x * 0.995 for x in c]
    gap_open = c[-1] * 1.05
    c += [gap_open * 1.01] + [gap_open * 1.01] * 5 + [gap_open * 0.97] + [gap_open] * 20
    opens += [gap_open] + [gap_open * 1.01] * 5 + [gap_open * 0.985] + [gap_open] * 20
    lows += [gap_open * 0.995] + [gap_open * 1.0] * 5 + [gap_open * 0.96] + [gap_open * 0.995] * 20
    v += [300.0] + [100.0] * 26
    d = oneil.stock_signals(_stock(c, v, opens=np.array(opens), lows=np.array(lows),
                                   highs=np.array(c) * 1.01))
    t = n
    assert bool(d["gap_major"].iloc[t])
    assert bool(d["stopped"].iloc[t]) and d["stop_days"].iloc[t] == 6
    # Filled at the lower of that day's open and the gap day's low.
    assert d["stop_ret_21"].iloc[t] == pytest.approx(
        np.log(min(gap_open * 0.985, gap_open * 0.995) / c[t]))


def _index(rets, vols, pos=None):
    close = 100 * np.cumprod(1 + np.asarray(rets, float))
    pos = np.full(len(close), 0.5) if pos is None else np.asarray(pos, float)
    high, low = close * 1.01, close * 0.99
    close_in_range = low + pos * (high - low)
    return pd.DataFrame({"open": close, "high": high, "low": low, "close": close_in_range,
                         "volume": np.asarray(vols, float)},
                        index=pd.bdate_range("2021-01-01", periods=len(close)))


def test_distribution_days_follow_the_books_rules():
    rets = [0.0, -0.002, 0.0005, -0.0005, 0.0]
    vols = [100, 120, 130, 140, 90]
    pos = [0.5, 0.5, 0.1, 0.9, 0.5]
    idx = _index(rets, vols, pos)
    d = oneil.distribution_days(idx).tolist()
    # down >= 0.1% on more volume: yes; churning in the bottom quarter: yes;
    # down only 0.05% and closing high: no; lower volume: no.
    assert d[1] and d[2] and not d[3] and not d[4]


def test_five_distribution_days_sell_and_a_follow_through_buys_back():
    rets = [0.003] * 25
    vols = [100 + i for i in range(25)]
    for k in (5, 8, 11, 14, 17):                 # five distribution days inside 20 sessions
        rets[k], vols[k] = -0.005, vols[k - 1] + 50
    rets += [-0.01, -0.01, 0.004, 0.003, 0.002, 0.02]    # new lows, rally day 1-3, then day 4 +2%
    vols += [100, 100, 100, 100, 100, 200]
    st = oneil.market_direction(_index(np.r_[0.0, rets[1:]], vols, np.r_[[0.5] * len(vols)]),
                                ftd_threshold=0.015)
    assert (st["signal"] == "sell").sum() == 1
    assert st["signal"].iloc[-1] == "ftd" and st["state"].iloc[-1] == "uptrend"


def test_the_app_checklist_and_the_live_distribution_count():
    c, v = _base(300)
    c += [c[-1] * 1.01]
    v += [400.0]
    opens = np.r_[np.asarray(c[:-1]), c[-2]]          # opens at the prior close: no gap
    h = _stock(c, v, opens=opens).rename(columns={"turnover": "volume"})
    h["volume"] = h["volume"] / h["close"]          # shares, as the app's history carries
    chk = oneil.checklist(h)
    assert chk["pp_core"] and chk["above50"] and chk["gap"] is None and chk["heavy_break"] is None
    assert oneil.checklist(h.iloc[:100]) is None     # too little daily history

    days = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=30)
    nifty = pd.DataFrame({"open": 100.0, "high": 101.0, "low": 99.0,
                          "close": 100 * np.cumprod(np.r_[1.0, np.where(np.arange(29) % 3 == 0, 0.995, 1.002)])},
                         index=days)
    vols = {d.normalize(): 100.0 + 10 * (i % 3 == 1) for i, d in enumerate(days)}
    out = oneil.live_distribution_count(
        nifty_fn=lambda a, b: nifty,
        fetch_fn=lambda d: pd.DataFrame({"turnover": [vols[pd.Timestamp(d).normalize()]]}))
    assert out["sessions"] == 20 and out["count"] == len(out["dates"])
    assert out["sell"] == (out["count"] >= oneil.DIST_SELL)
    assert oneil.live_distribution_count(nifty_fn=lambda a, b: (_ for _ in ()).throw(RuntimeError())) is None


def test_a_heavy_volume_break_of_the_50_day_and_its_control():
    c, v = _base(120)
    heavy = c + [c[-1] * 0.90]                     # one close through the 50-day...
    d = oneil.stock_signals(_stock(heavy, v + [300.0]))
    assert bool(d["ma50_break_heavy"].iloc[-1]) and not bool(d["ma50_break_light"].iloc[-1])
    d = oneil.stock_signals(_stock(heavy, v + [110.0]))   # ...on ordinary volume
    assert bool(d["ma50_break_light"].iloc[-1]) and not bool(d["ma50_break_heavy"].iloc[-1])
    again = heavy + [heavy[-1] * 0.99]             # already below: not a new crossing
    d = oneil.stock_signals(_stock(again, v + [300.0, 300.0]))
    assert not bool(d["ma50_break_heavy"].iloc[-1]) and not bool(d["ma50_break_light"].iloc[-1])
