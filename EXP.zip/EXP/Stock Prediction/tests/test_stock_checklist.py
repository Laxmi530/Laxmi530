"""
Tests for ``stock_checklist`` - Mladjenovic's company check (Ch. 21, App. B).

Network-free: yfinance-shaped statement frames are built by hand.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import pandas as pd
import pytest

import stock_checklist as sc

YEARS = [pd.Timestamp(f"{y}-03-31") for y in (2026, 2025, 2024, 2023)]   # newest first


def _frame(rows):
    return pd.DataFrame({k: v for k, v in rows.items()}, index=YEARS).T


def _inputs(income=None, balance=None, info=None, dividends=None,
            symbol="ABC", fno=("ABC",), paid=(-8, -7, -6, -5), cap="NIFTY 50", years=20.0):
    inc = _frame(income or {"Total Revenue": [130, 120, 110, 100],
                            "Net Income": [26, 22, 20, 18],
                            "Diluted EPS": [13.0, 11.0, 10.0, 9.0]})
    bal = _frame(balance or {"Total Liabilities Net Minority Interest": [60, 58, 55, 50],
                             "Stockholders Equity": [100, 90, 80, 70],
                             "Total Assets": [160, 148, 135, 120],
                             "Current Assets": [90, 80, 70, 60],
                             "Current Liabilities": [40, 38, 35, 30],
                             "Inventory": [10, 10, 9, 8],
                             "Accounts Receivable": [20, 19, 18, 17]})
    if dividends is None:
        dividends = pd.Series([4.0, 5.0, 6.0], index=pd.to_datetime(
            ["2024-07-01", "2025-07-01", "2026-07-01"]))
    cash = _frame({"Cash Dividends Paid": list(paid)})
    caps = None if cap is None else {k: ({symbol} if k == cap else set())
                                     for k in ("NIFTY 50", "NIFTY NEXT 50", "NIFTY MIDCAP 150",
                                               "NIFTY SMALLCAP 250")}
    return {"income": inc, "balance": bal, "cashflow": cash, "cap_lists": caps,
            "years_listed": years,
            "info": info if info is not None else {"trailingPE": 12.0, "priceToBook": 2.0,
                                                    "priceToSalesTrailing12Months": 1.5,
                                                    "sector": "Industrials"},
            "dividends": dividends, "symbol": symbol,
            "fno_symbols": set(fno) if fno is not None else None}


TODAY = "2026-10-18"


def _by_label(checks):
    return {c["label"]: c for c in checks}


def test_a_healthy_company_meets_all_six_measurable_hallmarks():
    c = sc.build_checklist(_inputs(), last_price=150.0, today=TODAY)
    h = _by_label(c["hallmarks"])
    assert c["met"] == c["measured"] == 6
    assert "up in 3 of the last 3 years" in h["Rising sales"]["value"]
    assert "0.60× net equity" in h["Low liabilities"]["value"]
    assert h["Growing dividends"]["verdict"] == sc.GOOD
    assert c["minimum"] == {"profitability": (3, 3), "solvency": (2, 2)}
    assert c["fiscal_year_end"] == "2026-03-31" and len(c["judgement"]) == 4


def test_book_thresholds_set_the_verdicts():
    rich = _inputs(info={"trailingPE": 45.0, "priceToSalesTrailing12Months": 6.0})
    c = sc.build_checklist(rich, last_price=150.0, today=TODAY)
    assert _by_label(c["hallmarks"])["Bargain price"]["verdict"] == sc.BAD    # P/E > 40
    ratios = {x["label"]: x for _, cs in c["ratios"] for x in cs}
    assert ratios["Price to sales"]["verdict"] == sc.BAD                      # P/S > 5
    # P/E falls back to price / latest EPS when info has none: 150 / 13 = 11.5
    c = sc.build_checklist(_inputs(info={}), last_price=150.0, today=TODAY)
    assert "P/E 11.5" in _by_label(c["hallmarks"])["Bargain price"]["value"]


def test_negative_equity_is_a_red_flag_not_a_bargain():
    bal = {"Total Liabilities Net Minority Interest": [300, 290, 280, 270],
           "Stockholders Equity": [-50, -40, -30, -20],
           "Total Assets": [250, 250, 250, 250],
           "Current Assets": [30, 30, 30, 30], "Current Liabilities": [60, 60, 60, 60]}
    c = sc.build_checklist(_inputs(balance=bal, info={"trailingPE": 4.0, "priceToBook": -3.0}),
                           last_price=50.0, today=TODAY)
    h = _by_label(c["hallmarks"])
    assert h["Low liabilities"]["verdict"] == sc.BAD
    assert h["Bargain price"]["verdict"] == sc.BAD                 # a low P/E is not enough
    ratios = {x["label"]: x for _, cs in c["ratios"] for x in cs}
    assert ratios["Price to book"]["verdict"] == sc.BAD
    assert "meaningless" in ratios["Return on equity"]["value"]


def test_a_loss_is_flagged_and_has_no_bargain_price():
    inc = {"Total Revenue": [130, 120, 110, 100], "Net Income": [-5, 10, 12, 11],
           "Diluted EPS": [-2.0, 4.0, 5.0, 4.5]}
    c = sc.build_checklist(_inputs(income=inc, info={}), last_price=80.0, today=TODAY)
    h = _by_label(c["hallmarks"])
    assert h["Rising profits"]["verdict"] == sc.BAD and "a loss" in h["Rising profits"]["value"]
    assert h["Bargain price"]["verdict"] == sc.BAD and "speculation" in h["Bargain price"]["value"]


def test_lender_balance_sheet_checks_are_not_applicable():
    c = sc.build_checklist(_inputs(info={"trailingPE": 14.0, "sector": "Financial Services"}),
                           last_price=150.0, today=TODAY)
    assert c["is_financial"] and c["measured"] == 5
    ratios = {x["label"]: x for _, cs in c["ratios"] for x in cs}
    for name in ("Quick ratio", "Current ratio", "Debt to net equity", "Sales to receivables"):
        assert ratios[name]["verdict"] == sc.NA, name


def test_dividends_and_optionable_use_trailing_windows_and_the_fno_list():
    cut = pd.Series([6.0, 5.0], index=pd.to_datetime(["2025-07-01", "2026-07-01"]))
    c = sc.build_checklist(_inputs(dividends=cut, fno=("XYZ",)), last_price=150.0, today=TODAY)
    h = _by_label(c["hallmarks"])
    assert h["Growing dividends"]["verdict"] == sc.WATCH            # 5 < 6
    assert h["Optionable"]["verdict"] == sc.WATCH
    c = sc.build_checklist(_inputs(fno=None), last_price=150.0, today=TODAY)
    assert _by_label(c["hallmarks"])["Optionable"]["verdict"] == sc.NA


def test_no_statements_or_a_failing_fetch_give_none():
    empty = {"income": pd.DataFrame(), "balance": pd.DataFrame(), "info": {}}
    assert sc.build_checklist(empty) is None

    def boom(ticker):
        raise RuntimeError("yfinance down")
    assert sc.company_checklist("ABC.NS", fetch_fn=boom) is None
    assert "5 trading days" in sc.horizon_note(5, "1d")
    assert "speculation" in sc.horizon_note(12, "1h")


def test_payout_ratio_uses_the_books_bands():
    ratios = lambda c: {x["label"]: x for _, cs in c["ratios"] for x in cs}   # noqa: E731
    c = sc.build_checklist(_inputs(), last_price=150.0, today=TODAY)          # 8 / 26 = 31%
    assert ratios(c)["Payout ratio"]["verdict"] == sc.GOOD
    assert "30.8%" in ratios(c)["Payout ratio"]["value"]
    c = sc.build_checklist(_inputs(paid=(-20, -7, -6, -5)), last_price=150.0, today=TODAY)
    assert ratios(c)["Payout ratio"]["verdict"] == sc.WATCH            # 77%: above 70
    c = sc.build_checklist(_inputs(paid=(-24, -7, -6, -5)), last_price=150.0, today=TODAY)
    assert ratios(c)["Payout ratio"]["verdict"] == sc.BAD                     # 92%: above 80
    c = sc.build_checklist(_inputs(paid=(0, 0, 0, 0)), last_price=150.0, today=TODAY)
    assert ratios(c)["Payout ratio"]["verdict"] == sc.NA



def test_size_band_from_nse_indices_and_the_small_cap_rules():
    c = sc.build_checklist(_inputs(cap="NIFTY NEXT 50"), last_price=150.0, today=TODAY)
    assert c["size"]["band"] == "Large cap" and not c["size"]["checks"]
    c = sc.build_checklist(_inputs(cap="NIFTY MIDCAP 150"), last_price=150.0, today=TODAY)
    assert c["size"]["band"] == "Mid cap"
    # A small cap gets Ch. 14's rules: three years listed, 10% net margins for two years.
    c = sc.build_checklist(_inputs(cap="NIFTY SMALLCAP 250", years=2.0), last_price=150.0,
                           today=TODAY)
    chk = {x["label"]: x for x in c["size"]["checks"]}
    assert c["size"]["band"] == "Small cap"
    assert chk["Established"]["verdict"] == sc.WATCH
    assert chk["Profitable"]["verdict"] == sc.GOOD                            # 18% and 20%
    c = sc.build_checklist(_inputs(cap="none-of-them"), last_price=150.0, today=TODAY)
    assert c["size"]["band"] == "Micro cap"
    c = sc.build_checklist(_inputs(cap=None), last_price=150.0, today=TODAY)
    assert c["size"]["band"] is None


def test_thomsett_trend_tests():
    inc = {"Total Revenue": [130, 120, 110, 100], "Net Income": [26, 22, 20, 18],
           "Diluted EPS": [13.0, 11.0, 10.0, 9.0], "Cost Of Revenue": [80, 75, 70, 65],
           "Operating Income": [30, 26, 24, 22]}
    bal = {"Total Liabilities Net Minority Interest": [60, 58, 55, 50],
           "Stockholders Equity": [100, 90, 80, 70], "Total Assets": [160, 148, 135, 120],
           "Current Assets": [90, 80, 70, 60], "Current Liabilities": [40, 38, 35, 30],
           "Inventory": [20, 12, 11, 10], "Accounts Receivable": [20, 19, 18, 17],
           "Long Term Debt": [40, 30, 20, 10], "Tangible Book Value": [80, 75, 70, 60]}
    c = sc.build_checklist(_inputs(income=inc, balance=bal,
                                   info={"trailingPE": 12.0, "marketCap": 400.0}),
                           last_price=150.0, today=TODAY)
    t = {x["label"]: x for g, cs in c["ratios"] if g.startswith("Trends") for x in cs}
    assert t["Inventory turnover"]["verdict"] == sc.WATCH     # 6.5 -> 5.0 turns
    assert t["Debt capitalization"]["verdict"] == sc.WATCH     # 20% -> 25% -> 29%, every year
    assert "rising every year" in t["Debt capitalization"]["value"]
    assert t["Operating margin trend"]["verdict"] == sc.GOOD   # 21.7% -> 23.1%
    assert "5.00× tangible book" in t["Tangible book value"]["value"]
    assert "intangibles 20% of net worth" in t["Tangible book value"]["value"]
    ops = {x["label"]: x for g, cs in c["ratios"] if g == "Operating" for x in cs}
    assert "collection period" in ops["Sales to receivables"]["value"]


def test_returns_use_average_balances_and_a_slipping_payout_is_flagged():
    ratios = lambda c: {x["label"]: x for _, cs in c["ratios"] for x in cs}   # noqa: E731
    c = sc.build_checklist(_inputs(), last_price=150.0, today=TODAY)
    # Thomsett Ch. 2: 26 / average(100, 90) = 27.4%, not 26 / 100 = 26.0%.
    assert ratios(c)["Return on equity"]["value"] == "27.4%"
    assert ratios(c)["Return on assets"]["value"].startswith("16.9%")       # 26 / avg(160, 148)
    assert ratios(c)["Payout trend"]["verdict"] == sc.GOOD                    # 30% -> 32% -> 31%
    # 40% -> 32% -> 23% while profits rose: slipping two years running.
    c = sc.build_checklist(_inputs(paid=(-6, -7, -8, -5)), last_price=150.0, today=TODAY)
    assert ratios(c)["Payout trend"]["verdict"] == sc.WATCH
    assert "slipping" in ratios(c)["Payout trend"]["value"]
