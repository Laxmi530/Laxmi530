"""
Tests for :mod:`synthetic_check`.

The central one pins the blind spot in validating synthetic returns with a
Kolmogorov-Smirnov test alone (Hilpisch, RL for Finance, Ch. 5; README §57):
a shuffled copy of a volatility-clustered series has the identical marginal
distribution, passes KS, and has no clustering at all.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pytest

import synthetic_check as sc


def _garch(n=4000, seed=0, omega=1e-6, a=0.10, b=0.88):
    """GARCH(1,1) with Student-t(5) shocks: clustering, fat tails, multi-day kurtosis."""
    rng = np.random.default_rng(seed)
    z = rng.standard_t(5, n) / np.sqrt(5 / 3)
    r, h = np.empty(n), omega / (1 - a - b)
    for t in range(n):
        r[t] = np.sqrt(h) * z[t]
        h = omega + a * r[t] ** 2 + b * h
    return r


def test_ks_matches_scipy():
    stats = pytest.importorskip("scipy.stats")
    rng = np.random.default_rng(1)
    a, b = rng.standard_normal(900), rng.standard_normal(700) + 0.08
    mine, ref = sc.ks_2samp(a, b), stats.ks_2samp(a, b, method="asymp")
    assert mine["D"] == pytest.approx(ref.statistic, abs=1e-12)
    assert mine["p"] == pytest.approx(ref.pvalue, abs=0.01)


def test_a_shuffle_passes_ks_but_has_no_volatility_clustering():
    real = _garch()
    shuffled = np.random.default_rng(2).permutation(real)
    out = sc.compare_paths(real, shuffled)
    # Same marginal distribution, so KS cannot tell them apart...
    assert out["passes_ks"] and out["ks_D"] < 1e-12
    assert out["tail_ratio"] == pytest.approx(1.0)
    # ...but the clustering, and the fat tails of 20-day sums, are gone.
    assert out["clustering_ratio"] < 0.2, out["clustering_ratio"]
    assert out["agg_kurtosis_ratio"] < 0.5, out["agg_kurtosis_ratio"]
    assert "volatility clustering" in out["verdict"]


def test_a_series_matches_itself():
    real = _garch(seed=3)
    out = sc.compare_paths(real, real)
    assert out["verdict"] == "matches every checked fact"
    assert out["clustering_ratio"] == pytest.approx(1.0)


def test_gaussian_draws_miss_the_tail():
    real = _garch(seed=4)
    gauss = np.random.default_rng(5).normal(real.mean(), real.std(), len(real))
    out = sc.compare_paths(real, gauss)
    assert "1% tail" in out["verdict"] or not out["passes_ks"]
    assert "volatility clustering" in out["verdict"]


def test_block_bootstrap_keeps_short_lag_clustering_a_shuffle_loses():
    real = _garch(seed=6)
    boot = sc.stationary_bootstrap_path(real, len(real), block_mean=5, seed=7)
    shuf = np.random.default_rng(8).permutation(real)
    b, s = sc.compare_paths(real, boot), sc.compare_paths(real, shuf)
    assert b["clustering_ratio"] > 3 * max(s["clustering_ratio"], 0.01)
    # Longer blocks keep more of it.
    long_ = sc.compare_paths(real, sc.stationary_bootstrap_path(real, len(real), 40, 9))
    assert long_["clustering_ratio"] > b["clustering_ratio"]


def test_ks_degrades_gracefully():
    assert np.isnan(sc.ks_2samp([1.0], [1.0, 2.0])["p"])


def test_ks_p_value_is_correct_across_the_whole_range():
    # Identical samples: D = 0, p = 1 (a first version returned 0 here,
    # because the alternating series sums to zero at lambda = 0).
    x = np.random.default_rng(10).standard_normal(500)
    assert sc.ks_2samp(x, x)["p"] == pytest.approx(1.0)
    stats = pytest.importorskip("scipy.stats")
    rng = np.random.default_rng(11)
    for shift in (0.0, 0.03, 0.08, 0.15, 0.3):
        a, b = rng.standard_normal(600), rng.standard_normal(600) + shift
        assert sc.ks_2samp(a, b)["p"] == pytest.approx(
            stats.ks_2samp(a, b, method="asymp").pvalue, abs=0.01)
