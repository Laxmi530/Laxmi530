"""
Tests for ``market_context`` - the as-of alignment of daily index data onto
stock bars, which is where a look-ahead can enter.

Network-free: the index series are injected.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd

import market_context as mc


def _index_series(days, seed=0):
    rng = np.random.default_rng(seed)
    return pd.Series(1000 * np.exp(np.cumsum(rng.normal(0, 0.01, len(days)))),
                     index=pd.DatetimeIndex(days))


def test_daily_rows_take_the_same_days_index_close():
    days = pd.bdate_range("2024-01-01", periods=120)
    mkt = _index_series(days)
    stock = pd.DataFrame({"datetime": days, "adj_close": np.linspace(100, 120, 120)})
    out = mc.add_market_context(stock, "1d", _market_series=mkt, _vix_series=None)
    want = np.log(mkt / mkt.shift(1)).fillna(0.0).values
    assert np.allclose(out["mkt_ret_1"].values, want)


def test_hourly_rows_never_see_the_days_own_close():
    """
    Regression test: a 10:15 bar on day D used to be matched to day D's index
    close (stamped midnight), which prints at 15:30. Every bar of day D must
    carry day D-1's value instead.
    """
    days = pd.bdate_range("2024-01-01", periods=120)
    mkt = _index_series(days)
    bars = [d + pd.Timedelta(hours=h, minutes=15) for d in days for h in range(9, 16)]
    stock = pd.DataFrame({"datetime": bars,
                          "adj_close": np.linspace(100, 120, len(bars))})
    out = mc.add_market_context(stock, "1h", _market_series=mkt, _vix_series=None)
    daily_ret = np.log(mkt / mkt.shift(1))
    for k in (61, 90, 119):
        d = days[k]
        rows = out[pd.to_datetime(out["datetime"]).dt.normalize() == d]
        assert np.allclose(rows["mkt_ret_1"], daily_ret.iloc[k - 1])
        assert not np.allclose(rows["mkt_ret_1"], daily_ret.iloc[k])


def test_hourly_market_index_level_is_the_prior_close():
    days = pd.bdate_range("2024-01-01", periods=10)
    mkt = _index_series(days)
    bars = [d + pd.Timedelta(hours=11, minutes=15) for d in days]
    stock = pd.DataFrame({"datetime": bars, "adj_close": np.arange(1.0, 11.0)})
    out = mc.add_market_index(stock, "1h", _market_series=mkt)
    # Day 0 has no prior session; it is back-filled. From day 1 on: prior close.
    assert np.allclose(out["mkt_index"].values[1:], mkt.values[:-1])
