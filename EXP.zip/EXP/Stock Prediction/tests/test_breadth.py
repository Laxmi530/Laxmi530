"""
Tests for ``breadth`` - market breadth from the bhavcopy (Thomsett Ch. 8-9).

Network-free: bhavcopy-shaped frames are built by hand.
"""

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import pytest

import breadth


def _day(date, rows):
    """rows: (symbol, close, prevclose, turnover)."""
    return pd.DataFrame([{"datetime": pd.Timestamp(date), "symbol": s, "close": c,
                          "prevclose": p, "turnover": t} for s, c, p, t in rows])


def test_advances_declines_and_the_liquidity_floor():
    raw = _day("2020-01-01", [("A", 101, 100, 2e7), ("B", 99, 100, 2e7),
                              ("C", 102, 100, 2e7), ("D", 110, 100, 1e5)])   # D is illiquid
    b = breadth.daily_breadth(raw)
    row = b.iloc[0]
    assert (row.advances, row.declines, row.issues) == (2, 1, 3)
    assert row.net_ratio == pytest.approx(1 / 3)


def test_a_split_is_not_a_new_low_but_a_real_fall_is():
    dates = pd.bdate_range("2019-01-01", periods=260)
    rows = []
    px = 100.0
    for i, d in enumerate(dates):
        if i == 255:                      # 1:2 split: raw close halves, prevclose adjusted
            rows.append(("S", px / 2, px / 2, 2e7)); px /= 2
        else:
            rows.append(("S", px * 1.001, px, 2e7)); px *= 1.001
        fall = 100.0 * (0.999 ** i)
        rows.append(("F", fall * 0.999, fall, 2e7))
    raw = pd.concat([_day(d, [r for r in rows[2 * i:2 * i + 2]]) for i, d in enumerate(dates)])
    b = breadth.daily_breadth(raw)
    last = b.iloc[-1]
    assert last.lows == 1                 # F, falling every day; never S
    assert last.highs == 1                # S keeps making highs on the adjusted chain


def test_quintile_edges_and_the_live_reader():
    assert breadth.ad10_quintile(-0.5) == 1 and breadth.ad10_quintile(0.5) == 5
    assert breadth.ad10_quintile(0.0) == 3

    def fetch(d):
        if d.dayofweek == 0:
            return None                   # a holiday, skipped not counted
        return _day(d, [("A", 99, 100, 2e7), ("B", 99, 100, 2e7), ("C", 101, 100, 2e7)])
    out = breadth.live_breadth(today="2026-10-16", fetch_fn=fetch)
    assert out["ad10"] == pytest.approx(-1 / 3) and out["quintile"] == 1
    assert out["next_month_vol"] == breadth.NEXT_MONTH_VOL[0] and out["sessions"] == 10
    assert "weakest fifth" in out["message"]
    assert breadth.live_breadth(today="2026-10-16", lookback_days=5, fetch_fn=fetch) is None

    def boom(d):
        raise RuntimeError("NSE down")
    assert breadth.live_breadth(today="2026-10-16", fetch_fn=boom) is None
