"""
What the options market prices for a stock, read from NSE's live option chain.

Benklifa, *Think Like an Option Trader*, Ch. 2: a stock trader looks at a
price and asks where it goes next; an options trader looks at the same stock
and sees a DISTRIBUTION of prices that the market has already priced. This
module reads that distribution off the chain, so the app can show it next to
its own forecast:

* **Implied volatility** from the at-the-money straddle, the most liquid
  options on the chain, with Black-76 on the forward. The forward comes from
  put-call parity at that strike (F = K + (C - P) / DF), so dividends and the
  interest rate largely cancel; the rate enters only through discounting.
* **The expected move to expiry**: the straddle's price as a share of spot, the
  option trader's rule of thumb (about 0.8 standard deviations).
* **The term structure** (Ch. 5's "known unknowns"): when the first expiry's
  volatility stands well above the second's, the market is pricing an event
  before the first expiry. The forward volatility between the two expiries is
  what the market expects once the event has passed.
* **Defined risk** (Ch. 6): the cost of a put at the stop level, and the most a
  holder can lose through expiry with it, gaps included.

Two things this is not. It is **risk-neutral**: option prices carry a variance
risk premium, so implied volatility runs above what is later realised (India
VIX ran a median 27% above NIFTY's realised volatility, ``iv_data.py``), and
the probabilities read off it are not forecasts (README section 48). And it is
**live only**: NSE publishes no option-chain history, so none of this can be
backtested here. It is information beside the forecast, never an input to it.

NSE's API is bot-protected and has changed shape before (``iv_data.py`` was
written when the older endpoint returned nothing); every failure returns None.
"""

import math
import os
import time

import numpy as np
import pandas as pd

HOME = "https://www.nseindia.com/option-chain"
CONTRACT_INFO = "https://www.nseindia.com/api/option-chain-contract-info?symbol={symbol}"
CHAIN = "https://www.nseindia.com/api/option-chain-v3?type=Equity&symbol={symbol}&expiry={expiry}"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/130.0 Safari/537.36")

#: Approximate Indian short rate. It enters only through discounting, which
#: moves a near-expiry implied volatility by well under a tenth of a point.
RISK_FREE = 0.06
#: A first-expiry IV this far above the second's is read as an event premium.
EVENT_PREMIUM_RATIO = 1.15
#: India VIX against NIFTY's realised volatility, median (iv_data.py).
VARIANCE_PREMIUM = 1.27
TRADING_DAYS, CALENDAR_DAYS = 252, 365
_EXPIRY_HOUR = 15.5          # options expire at 15:30 IST


def _norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def black_price(F, K, T, sigma, df=1.0, kind="call"):
    """Black-76 price of a European option on a forward."""
    if T <= 0 or sigma <= 0:
        intrinsic = max(F - K, 0.0) if kind == "call" else max(K - F, 0.0)
        return df * intrinsic
    sd = sigma * math.sqrt(T)
    d1 = (math.log(F / K) + 0.5 * sd * sd) / sd
    d2 = d1 - sd
    if kind == "call":
        return df * (F * _norm_cdf(d1) - K * _norm_cdf(d2))
    return df * (K * _norm_cdf(-d2) - F * _norm_cdf(-d1))


def straddle_vol(straddle, F, K, T, df=1.0, lo=1e-4, hi=5.0, tol=1e-7):
    """The volatility at which a call plus a put at ``K`` cost ``straddle`` (bisection)."""
    if not (straddle > 0 and F > 0 and K > 0 and T > 0):
        return float("nan")
    price = lambda s: black_price(F, K, T, s, df, "call") + black_price(F, K, T, s, df, "put")  # noqa: E731
    if price(lo) > straddle or price(hi) < straddle:
        return float("nan")
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if price(mid) < straddle:
            lo = mid
        else:
            hi = mid
        if hi - lo < tol:
            break
    return 0.5 * (lo + hi)


def _mid(bid, ask, ltp):
    """Quote mid when the quote is two-sided and not absurdly wide, else last price."""
    bid, ask, ltp = (float(x) if x is not None else float("nan") for x in (bid, ask, ltp))
    if bid > 0 and ask >= bid and (ask - bid) / ((ask + bid) / 2.0) <= 0.5:
        return (bid + ask) / 2.0
    return ltp if ltp > 0 else float("nan")


def parse_chain(payload):
    """NSE option-chain-v3 JSON -> (spot, timestamp, DataFrame by strike)."""
    rec = payload["records"]
    rows = []
    for row in rec["data"]:
        ce, pe = row.get("CE") or {}, row.get("PE") or {}
        rows.append({
            "strike": float(row["strikePrice"]),
            "call": _mid(ce.get("buyPrice1"), ce.get("sellPrice1"), ce.get("lastPrice")),
            "put": _mid(pe.get("buyPrice1"), pe.get("sellPrice1"), pe.get("lastPrice")),
            "call_oi": float(ce.get("openInterest") or 0), "put_oi": float(pe.get("openInterest") or 0),
        })
    df = pd.DataFrame(rows).sort_values("strike").reset_index(drop=True)
    ts = pd.to_datetime(rec.get("timestamp"), format="%d-%b-%Y %H:%M:%S", errors="coerce")
    return float(rec["underlyingValue"]), ts, df


def fetch_chains(symbol, n_expiries=2, session=None):
    """Live chains for the nearest ``n_expiries`` expiries: {'spot', 'asof', 'chains': {expiry: df}}."""
    import requests
    s = session or requests.Session()
    if not s.cookies:                     # warm once; a reused session keeps its cookies
        s.get(HOME, headers={"User-Agent": _UA}, timeout=20)
    h = {"User-Agent": _UA, "Accept": "application/json, text/plain, */*", "Referer": HOME}
    from urllib.parse import quote
    sym = quote(symbol, safe="")         # M&M, GVT&D: an unescaped & ends the parameter
    info = s.get(CONTRACT_INFO.format(symbol=sym), headers=h, timeout=20).json()
    expiries = info.get("expiryDates") or []
    out = {"chains": {}}
    for e in expiries[:n_expiries]:
        spot, ts, df = parse_chain(s.get(CHAIN.format(symbol=sym, expiry=e), headers=h, timeout=20).json())
        out["chains"][pd.Timestamp(e)] = df
        out["spot"], out["asof"] = spot, ts
    return out if out["chains"] else None


def expiry_view(df, spot, expiry, asof, r=RISK_FREE):
    """ATM straddle, forward, implied volatility and expected move for one expiry."""
    exp_ts = pd.Timestamp(expiry).normalize() + pd.Timedelta(hours=_EXPIRY_HOUR)
    T = (exp_ts - pd.Timestamp(asof)).total_seconds() / (CALENDAR_DAYS * 86400.0)
    if T <= 0:
        return None
    ok = df.dropna(subset=["call", "put"])
    if ok.empty:
        return None
    row = ok.iloc[(ok["strike"] - spot).abs().argsort().iloc[0]]
    K, C, P = float(row.strike), float(row.call), float(row.put)
    disc = math.exp(-r * T)
    F = K + (C - P) / disc
    straddle = C + P
    iv = straddle_vol(straddle, F, K, T, disc)
    return {"expiry": str(pd.Timestamp(expiry).date()), "T_years": T,
            "calendar_days": T * CALENDAR_DAYS, "strike": K, "call": C, "put": P,
            "straddle": straddle, "forward": F, "iv": iv, "move_pct": straddle / spot}


def implied_gain_probability(threshold, sigma_h):
    """Risk-neutral P(price ends above +threshold) for a log-normal with no drift but the convexity term."""
    if not (sigma_h > 0):
        return float("nan")
    return 1.0 - _norm_cdf((math.log(1.0 + threshold) + 0.5 * sigma_h ** 2) / sigma_h)


def implied_event_move(first, second, event_date):
    """
    The move the market prices for one scheduled event before the first expiry.

    With the event inside the first expiry only, total variance to that expiry
    is the ordinary variance plus the event's: iv1^2 T1 = base^2 T1 + v. The
    forward volatility between the two expiries contains no event, so it
    stands in for ``base``: v = (iv1^2 - fwd^2) T1. Returns ``{'move', 'ratio'}``
    (the event day's 1-sigma move, and its variance against an ordinary
    session's), or None when the event is not strictly between now and the
    first expiry or the term structure leaves no room for it.
    """
    if first is None or second is None or event_date is None:
        return None
    ev = pd.Timestamp(event_date).normalize()
    if not (pd.Timestamp(first["expiry"]) >= ev):
        return None
    T1, T2 = first["T_years"], second["T_years"]
    var_fwd = (second["iv"] ** 2 * T2 - first["iv"] ** 2 * T1) / (T2 - T1)
    if not (var_fwd > 0):
        return None
    v = (first["iv"] ** 2 - var_fwd) * T1
    if not (v > 0):
        return None
    day = var_fwd / TRADING_DAYS
    return {"move": math.sqrt(v + day), "ratio": (v + day) / day}


def market_view(data, horizon_days, threshold, model_sigma_h=None, event_date=None):
    """
    The option market's view over the forecast horizon.

    Parameters
    ----------
    data : dict
        :func:`fetch_chains` output.
    horizon_days : float
        Forecast horizon in trading sessions.
    threshold : float
        The panel's move / stop threshold as a fraction (0.02 = 2%).
    model_sigma_h : float, optional
        The app's own 1-sigma log move over the horizon, for the comparison.

    Returns
    -------
    dict or None
        ``expiries`` (one :func:`expiry_view` each), ``used`` (the expiry
        covering the horizon), ``iv``, ``sigma_h`` (implied 1-sigma move over
        the horizon), ``ratio_to_model``, ``p_gain`` (risk-neutral), ``event``
        (True when the term structure shows an event premium),
        ``forward_iv`` (between the two expiries), and ``put`` (the protective
        put at the stop level: strike, cost and the capped loss).
    """
    spot, asof = float(data["spot"]), data["asof"]
    views = [v for v in (expiry_view(df, spot, e, asof) for e, df in sorted(data["chains"].items()))
             if v is not None and np.isfinite(v["iv"])]
    if not views:
        return None
    h_cal = float(horizon_days) * CALENDAR_DAYS / TRADING_DAYS
    used = next((v for v in views if v["calendar_days"] >= h_cal), views[-1])
    sigma_h = used["iv"] * math.sqrt(h_cal / CALENDAR_DAYS)
    out = {"spot": spot, "asof": str(asof), "expiries": views, "used": used,
           "iv": used["iv"], "sigma_h": sigma_h,
           "ratio_to_model": (sigma_h / model_sigma_h) if model_sigma_h and model_sigma_h > 0 else float("nan"),
           "p_gain": implied_gain_probability(threshold, sigma_h),
           "event": False, "forward_iv": float("nan"), "event_move": None, "put": None}
    if len(views) >= 2:
        a, b = views[0], views[1]
        var_fwd = (b["iv"] ** 2 * b["T_years"] - a["iv"] ** 2 * a["T_years"]) / (b["T_years"] - a["T_years"])
        out["forward_iv"] = math.sqrt(var_fwd) if var_fwd > 0 else float("nan")
        out["event"] = a["iv"] >= EVENT_PREMIUM_RATIO * b["iv"]
        out["event_move"] = implied_event_move(a, b, event_date)
    # Protective put at the stop level, on the expiry that covers the horizon.
    df = data["chains"][pd.Timestamp(used["expiry"])]
    puts = df[(df.strike <= spot * (1.0 - threshold)) & df.put.notna() & (df.put > 0)]
    if len(puts):
        p = puts.iloc[-1]
        out["put"] = {"strike": float(p.strike), "cost_pct": float(p.put) / spot,
                      "max_loss_pct": (spot - float(p.strike) + float(p.put)) / spot,
                      "expiry": used["expiry"]}
    return out


def snapshot_rows(symbol, data, collected_at=None):
    """
    One row per expiry for the option-chain history (``tools/collect_option_chains.py``).

    NSE keeps no option history, so the only way to test implied volatility
    against this project's cones, or the put/call ratio (Thomsett Ch. 8)
    against anything, is to record it from now on. Each row keeps the inputs
    as well as the derived volatility, so a later study can recompute.
    """
    spot, asof = float(data["spot"]), data["asof"]
    rows = []
    for e, df in sorted(data["chains"].items()):
        v = expiry_view(df, spot, e, asof)
        if v is None:
            continue
        rows.append({
            "collected_at": str(collected_at or pd.Timestamp.now().floor("s")),
            "asof": str(asof), "symbol": symbol, "spot": spot, "expiry": v["expiry"],
            "calendar_days": round(v["calendar_days"], 4), "strike": v["strike"],
            "call": v["call"], "put": v["put"], "forward": round(v["forward"], 4),
            "atm_iv": round(v["iv"], 6) if np.isfinite(v["iv"]) else np.nan,
            "call_oi": float(df["call_oi"].sum()), "put_oi": float(df["put_oi"].sum()),
            "n_strikes": int(len(df)),
        })
    return rows


_KEY = ["asof", "symbol", "expiry"]


def collect_snapshots(symbols, out, pause=1.0, n_expiries=2, dry_run=False, fetch_fn=None,
            verbose=True):
    """
    Snapshot ``symbols`` and append the new rows to ``out``.

    Returns ``(n_new_rows, failures)``. Rows already present for the same
    (asof, symbol, expiry) are skipped, so re-running is harmless.
    """
    import requests
    session = requests.Session()
    fetch = fetch_fn or (lambda s: fetch_chains(s, n_expiries=n_expiries, session=session))
    seen = set()
    if os.path.exists(out):
        prev = pd.read_csv(out, usecols=_KEY, dtype=str)
        seen = set(map(tuple, prev[_KEY].values))
    rows, failures, streak = [], [], 0
    stamp = pd.Timestamp.now().floor("s")
    for i, sym in enumerate(symbols, 1):
        try:
            data = fetch(sym)
            new = [r for r in (snapshot_rows(sym, data, stamp) if data else [])
                   if (r["asof"], r["symbol"], r["expiry"]) not in seen]
            rows.extend(new)
            streak = 0
            if not data:
                failures.append((sym, "no chain"))
        except Exception as exc:
            failures.append((sym, f"{type(exc).__name__}: {str(exc)[:60]}"))
            streak += 1
            if streak >= 3:                 # NSE throttling: re-warm and back off
                session = requests.Session()
                time.sleep(10.0)
                streak = 0
        if verbose and i % 25 == 0:
            print(f"  {i}/{len(symbols)}  rows so far {len(rows)}  failures {len(failures)}")
        time.sleep(pause)
    if rows and not dry_run:
        os.makedirs(os.path.dirname(out), exist_ok=True)
        pd.DataFrame(rows).to_csv(out, mode="a", index=False, header=not os.path.exists(out))
    return len(rows), failures


def option_view(ticker, horizon_days, threshold, model_sigma_h=None, event_date=None,
                fetch_fn=fetch_chains):
    """The live view for an NSE ticker, or None (not F&O, NSE unreachable, anything else)."""
    try:
        from corporate_events import nse_symbol
        sym = nse_symbol(ticker)
        if not sym:
            return None
        data = fetch_fn(sym)
        return (market_view(data, horizon_days, threshold, model_sigma_h, event_date)
                if data else None)
    except Exception:
        return None
