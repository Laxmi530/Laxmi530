"""
The O'Neil-disciple signals (Morales & Kacher, *Trade Like an O'Neil
Disciple*, Ch. 5 and 7), coded to the book's published rules.

* **Pocket pivot** (Ch. 5): an up day whose volume is at least the largest
  down-day volume of the prior 10 sessions (the "volume signature"), closing
  above the 50-day moving average. A *proper* one also starts from the 10-day
  average (the day's low at or within 1% above it; "extended" pivots fail) and
  does not follow "wedging" (price drifting up over the prior 10 sessions on
  falling volume).
* **Major gap-up** (Ch. 5): the open at least 0.75 x the 40-day average true
  range above the prior close, on volume at least 1.5 x its 50-day average;
  the book's sell rule is to exit if the gap day's intraday low is broken.
* **Market direction model** (Ch. 7): distribution days (the index down at
  least 0.1% on higher volume, or "churning": up under 0.1%, closing in the
  bottom quarter of its range, on higher volume); five in 20 sessions is a
  sell signal. A follow-through day (from session 4 of a rally attempt that
  began with the first up close after a new low, the index up at least a
  threshold on higher volume) is the buy signal.

Volume is rupee turnover: share volume jumps on a split, turnover does not.

* **Moving-average sell guide** (Ch. 5): a close crossing below the 50-day
  average on heavy volume (1.5 x its 50-day average); the control is the same
  crossing on ordinary volume.

README section 65 measures all four on NSE. Neither entry signal beats its own
control after costs, and the market model's timing is no better than shifted
copies of itself. The sell guide is the exception, working in its own
direction but not decisively. So the app shows these as the book's checklist,
with the measured verdict, not as calls.
"""

import numpy as np
import pandas as pd

PP_LOOKBACK = 10                # prior sessions for the volume signature
PP_EXTENSION = 0.01             # low within 1% above the 10-day average ("right at")
GAP_ATR_MULT, GAP_VOL_MULT = 0.75, 1.5
ATR_WINDOW, VOL_WINDOW = 40, 50
LEADER_FROM_HIGH = 0.15         # within 15% of the 52-week high (fundamentals proxy)
DIST_DOWN, CHURN_UP, CHURN_RANGE = -0.001, 0.001, 0.25
DIST_WINDOW, DIST_SELL = 20, 5
FTD_MIN_DAY = 4


def _adjusted_ohlc(g):
    g = g.sort_values("datetime")
    close = pd.to_numeric(g["close"], errors="coerce").to_numpy(float)
    adj = pd.to_numeric(g.get("adj_close", g["close"]), errors="coerce").to_numpy(float)
    ratio = np.where(close > 0, adj / close, np.nan)
    ratio = pd.Series(ratio).ffill().bfill().fillna(1.0).to_numpy()
    out = pd.DataFrame({
        "open": pd.to_numeric(g["open"], errors="coerce").to_numpy(float) * ratio,
        "high": pd.to_numeric(g["high"], errors="coerce").to_numpy(float) * ratio,
        "low": pd.to_numeric(g["low"], errors="coerce").to_numpy(float) * ratio,
        "close": adj,
    }, index=pd.to_datetime(g["datetime"].to_numpy()))
    vol = g["turnover"] if "turnover" in g else g["volume"] * g["close"]
    out["vol"] = pd.to_numeric(vol, errors="coerce").to_numpy(float)
    return out


def _slope(x):
    n = len(x)
    if n < 3 or not np.all(np.isfinite(x)):
        return np.nan
    t = np.arange(n) - (n - 1) / 2.0
    return float(np.dot(t, x - x.mean()) / np.dot(t, t))


def stock_signals(g, horizons=(5, 21, 63)):
    """
    Per-session pocket-pivot and gap-up flags for one stock, plus forward
    returns for the study. ``g`` is a bhavcopy-style frame (``datetime, open,
    high, low, close, adj_close, turnover`` or ``volume``).
    """
    d = _adjusted_ohlc(g)
    c, v = d["close"], d["vol"]
    d["ret"] = np.log(c).diff()
    d["ma10"], d["ma50"] = c.rolling(10).mean(), c.rolling(50).mean()
    up = d["ret"] > 0
    down_vol = v.where(d["ret"] < 0, 0.0)
    max_down = down_vol.shift(1).rolling(PP_LOOKBACK, min_periods=PP_LOOKBACK).max()
    signature = (v >= max_down) & (v > 0)
    above50 = c > d["ma50"]
    d["pp_core"] = up & signature & above50
    p_slope = np.log(c).shift(1).rolling(PP_LOOKBACK).apply(_slope, raw=True)
    v_slope = np.log(v.clip(lower=1.0)).shift(1).rolling(PP_LOOKBACK).apply(_slope, raw=True)
    wedging = (p_slope > 0) & (v_slope < 0)
    d["extension"] = d["low"] / d["ma10"] - 1.0
    d["pp_proper"] = d["pp_core"] & (d["extension"] <= PP_EXTENSION) & ~wedging
    d["pp_control"] = up & above50 & ~signature & max_down.notna()

    prev_c = c.shift(1)
    tr = pd.concat([d["high"] - d["low"], (d["high"] - prev_c).abs(), (d["low"] - prev_c).abs()],
                   axis=1).max(axis=1)
    atr = tr.shift(1).rolling(ATR_WINDOW, min_periods=ATR_WINDOW).mean()
    vol50 = v.shift(1).rolling(VOL_WINDOW, min_periods=VOL_WINDOW).mean()
    d["gap_major"] = ((d["open"] - prev_c) >= GAP_ATR_MULT * atr) & (v >= GAP_VOL_MULT * vol50)
    # The moving-average sell guide (Ch. 5): a close crossing below the 50-day on
    # heavy volume. Control: the same crossing on ordinary volume.
    crossed = (c < d["ma50"]) & (prev_c >= d["ma50"].shift(1))
    heavy = v >= GAP_VOL_MULT * vol50
    d["ma50_break_heavy"] = crossed & heavy
    d["ma50_break_light"] = crossed & ~heavy & vol50.notna()
    hi252 = c.rolling(252, min_periods=120).max()
    d["gap_leader"] = d["gap_major"] & (prev_c > d["ma50"].shift(1)) & (c >= (1 - LEADER_FROM_HIGH) * hi252)

    lc = np.log(c)
    for h in horizons:
        d[f"fwd_{h}"] = lc.shift(-h) - lc
    # The book's gap-up sell rule over 21 sessions: exit if the gap day's low breaks.
    lows, opens, closes = d["low"].to_numpy(), d["open"].to_numpy(), c.to_numpy()
    n = len(d)
    stop_ret = np.full(n, np.nan)
    stop_days = np.full(n, np.nan)
    stopped = np.zeros(n, bool)
    for t in np.nonzero(d["gap_major"].to_numpy())[0]:
        if t + 21 >= n:
            continue
        floor = lows[t]
        exit_px, k_exit = closes[t + 21], 21
        for k in range(1, 22):
            if lows[t + k] < floor:
                exit_px, k_exit = min(opens[t + k], floor), k
                stopped[t] = True
                break
        stop_ret[t] = np.log(exit_px / closes[t])
        stop_days[t] = k_exit
    d["stop_ret_21"], d["stop_days"], d["stopped"] = stop_ret, stop_days, stopped
    return d


def load_nifty(start, end):
    """NIFTY 50 daily OHLC from yfinance, never past ``end``."""
    import yfinance as yf
    h = yf.download("^NSEI", start=pd.Timestamp(start) - pd.Timedelta(days=90),
                    end=pd.Timestamp(end) + pd.Timedelta(days=1), progress=False, auto_adjust=False)
    h.columns = [c[0] if isinstance(c, tuple) else c for c in h.columns]
    h.index = pd.to_datetime(h.index).tz_localize(None)
    h = h[h.index <= pd.Timestamp(end)]
    return h.rename(columns=str.lower)[["open", "high", "low", "close"]]


def distribution_days(idx):
    """Boolean Series: the book's distribution days on an index frame (open/high/low/close/volume)."""
    r = idx["close"].pct_change()
    rng = (idx["high"] - idx["low"]).replace(0, np.nan)
    pos = (idx["close"] - idx["low"]) / rng
    heavier = idx["volume"] > idx["volume"].shift(1)
    churn = (r < CHURN_UP) & (pos <= CHURN_RANGE)
    return (heavier & ((r <= DIST_DOWN) | churn)).fillna(False)


def market_direction(idx, ftd_threshold=0.015):
    """
    Run the market direction model over an index frame.

    Returns a frame with ``dist_day``, ``dist_count`` (in the last 20 sessions,
    since the last follow-through), ``state`` ('uptrend' / 'correction'),
    ``signal`` ('sell' / 'ftd' / '') and ``rally_day``.
    """
    idx = idx.dropna(subset=["close", "volume"]).copy()
    dist = distribution_days(idx).to_numpy()
    close, high, low = idx["close"].to_numpy(), idx["high"].to_numpy(), idx["low"].to_numpy()
    vol = idx["volume"].to_numpy()
    n = len(idx)
    state = np.empty(n, object)
    signal = np.full(n, "", object)
    count = np.zeros(n, int)
    rally_arr = np.zeros(n, int)
    cur, low_mark, rally, last_reset = "uptrend", np.inf, 0, 0
    for t in range(n):
        lo = max(last_reset, t - DIST_WINDOW + 1)
        count[t] = int(dist[lo:t + 1].sum())
        ret = close[t] / close[t - 1] - 1.0 if t else 0.0
        if cur == "uptrend":
            if count[t] >= DIST_SELL:
                cur, signal[t], low_mark, rally = "correction", "sell", close[t], 0
        else:
            span = high[t] - low[t]
            if close[t] < low_mark:
                low_mark = close[t]
                rally = 1 if (span > 0 and (close[t] - low[t]) / span >= 0.5) else 0
            elif rally == 0 and ret > 0:
                rally = 1
            elif rally > 0:
                rally += 1
            if rally >= FTD_MIN_DAY and ret >= ftd_threshold and t and vol[t] > vol[t - 1]:
                cur, signal[t], rally, last_reset = "uptrend", "ftd", 0, t + 1
        state[t] = cur
        rally_arr[t] = rally
    return pd.DataFrame({"dist_day": dist, "dist_count": count, "state": state,
                         "signal": signal, "rally_day": rally_arr}, index=idx.index)


# ---------------------------------------------------------------------------
# The app's checklist: the book's signals for one stock, with what they
# measured on NSE (run_oneil.py, 2018-01 .. 2024-06, before the reserved period)
# ---------------------------------------------------------------------------

MEASURED = {
    "pocket_pivot": ("No edge on NSE: 21 sessions later the core pivot beat the market by "
                     "+0.03% (t 0.2), no better than an up day without the volume signature "
                     "(difference -0.07%, t -0.4), and -0.18% after a round trip's costs."),
    "gap_up": ("On NSE major gap-ups LAGGED the market by 1.65% over the next 21 sessions "
               "(2,503 events, t -2.9), the opposite of the book's advice; in stocks near their "
               "highs by 0.72%. The book's sell rule (exit below the gap day's low) brought "
               "that to about zero, stopping out 78% of trades."),
    "ma_sell": ("The one book signal that worked in its own direction: after a close below "
                "the 50-day on heavy volume (1.5x average), stocks lagged the market by 0.94% "
                "over 21 sessions (1,410 events), while ordinary-volume breaks did not "
                "(difference -1.02%, t -2.6; the same sign in both halves). Not strong enough "
                "to call proven after the ~20 tests in this study: a lead, queued for the "
                "reserved-period test."),
    "market": ("Long NIFTY in its uptrends and cash in corrections (1.0% follow-through) "
               "earned 9.4% a year against 13.0% for holding, with a -13% worst drawdown "
               "against -38%; but 14% of randomly shifted copies of the same signal did as "
               "well, so the timing itself is not distinguishable from luck. At the book's "
               "1.5% threshold it trailed holding outright."),
}


def checklist(hist):
    """
    The book's per-stock signals on the latest daily bar of ``hist`` (the app's
    history frame). Returns None when there is too little daily history.
    """
    if hist is None or len(hist) < 260 or "volume" not in hist:
        return None
    g = hist.rename(columns={"adj close": "adj_close"}).copy()
    if "turnover" not in g:
        g["turnover"] = pd.to_numeric(g["volume"], errors="coerce") * pd.to_numeric(g["close"], errors="coerce")
    d = stock_signals(g, horizons=())
    last = d.iloc[-1]
    recent = d.iloc[-21:]
    gaps = recent[recent["gap_major"]]
    gap = None
    if len(gaps):
        gday = gaps.index[-1]
        after = d.loc[d.index > gday, "low"]
        gap = {"date": str(gday.date()), "low": float(d.loc[gday, "low"]),
               "held": bool((after >= d.loc[gday, "low"]).all()),
               "leader": bool(d.loc[gday, "gap_leader"])}
    brk = d.iloc[-5:]
    heavy_break = (str(brk.index[brk["ma50_break_heavy"]][-1].date())
                   if bool(brk["ma50_break_heavy"].any()) else None)
    return {
        "date": str(d.index[-1].date()),
        "pp_core": bool(last["pp_core"]), "pp_proper": bool(last["pp_proper"]),
        "heavy_break": heavy_break,
        "above50": bool(last["close"] > last["ma50"]),
        "close_vs_ma50": float(last["close"] / last["ma50"] - 1.0),
        "close_vs_ma10": float(last["close"] / last["ma10"] - 1.0),
        "extension": float(last["extension"]),
        "gap": gap,
    }


def live_distribution_count(nifty_fn=None, fetch_fn=None, sessions=DIST_WINDOW, lookback_days=40):
    """
    NIFTY distribution days in the last ``sessions`` sessions (the model's sell
    condition is 5), with NSE's total equity turnover as the market's volume.
    Advisory: None on any failure.
    """
    try:
        end = pd.Timestamp.now().normalize()
        start = end - pd.Timedelta(days=lookback_days + 20)
        nifty = (nifty_fn or load_nifty)(start, end)
        if fetch_fn is None:
            import bhavcopy as bc
            fetch_fn = bc.fetch_day
        vols = {}
        for d in nifty.index[-(sessions + 1):]:
            day = fetch_fn(d)
            if day is not None and len(day):
                vols[pd.Timestamp(d).normalize()] = float(day["turnover"].sum())
        idx = nifty.copy()
        idx.index = idx.index.normalize()
        idx["volume"] = pd.Series(vols)
        idx = idx.dropna(subset=["volume"]).iloc[-(sessions + 1):]
        if len(idx) < sessions:
            return None
        dist = distribution_days(idx).iloc[1:]
        return {"count": int(dist.sum()), "sessions": int(len(dist)),
                "sell": bool(dist.sum() >= DIST_SELL),
                "dates": [str(x.date()) for x in dist[dist].index], "as_of": str(idx.index[-1].date())}
    except Exception:
        return None
