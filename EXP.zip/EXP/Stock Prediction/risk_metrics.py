"""
Pure risk-metric math for the Risk & Probability panel.

Extracted from UI.py so it carries **no Streamlit dependency** and can be unit
tested directly (the app imports these). Two read paths:

* ``empirical_risk`` — counts probabilities and tail metrics straight off a
  fat-tailed return sample (HAR-RV's conformal residuals). This is the honest
  path: it preserves the tails the model estimated and is the only place the
  downside reads (expected shortfall, semideviation, vol skew) are meaningful.
* ``risk_from_interval`` — a log-normal fallback from a model's median + 95%
  band, used only when no model exposes an empirical sample. Re-imposes
  normality, so the UI labels it as an approximation.
"""

import math

import numpy as np


def normal_cdf(x):
    """Standard-normal CDF Φ(x) via the error function (no SciPy dependency)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


#: The chance a stop is touched that the "1-in-5 stop" is sized for.
STOP_HIT_TARGET = 0.20


def stop_hit_probability(p_end):
    """
    P(a stop is touched before the horizon) from P(the price ENDS below it).

    A stop triggers on the path, not at the horizon, so the end-point
    probability the panel shows as ``p_loss`` understates the stop-out risk. The
    reflection principle makes the first-passage probability of a driftless
    random walk exactly twice the end-point one. Measured out of sample on
    ~170,000 NSE name-window-stop cases (``run_stop_loss.py``, Mladjenovic Ch.
    17): calibration error 0.040 in both a calm rising market (2022-24, where it
    overstates by about a third, because drift lowers stop-outs) and a crash
    (2020-21, where it is on target), against 0.040 and 0.086 for the end-point
    probability it replaces. A volatility-standardised excursion history of the
    stock's own was no better (0.043 / 0.044) and is not used.
    """
    p = float(p_end)
    return float(min(1.0, 2.0 * p)) if np.isfinite(p) else float('nan')


#: Thomsett's break-even inputs (*Stock Market Math*, Ch. 4), dated so they can
#: be revised: RBI's medium-term CPI target, and the short-term capital-gains
#: rate on listed equity held up to a year (20% from 23 July 2024) plus the 4%
#: health-and-education cess, before any income-dependent surcharge.
INFLATION_RATE = 0.04
STCG_TAX_RATE = 0.20 * 1.04
TRADING_DAYS = 252


def breakeven_move(horizon_days, segment='delivery', inflation=INFLATION_RATE,
                   tax=STCG_TAX_RATE, cost_bps=None):
    """
    The gross move a long trade needs over the horizon to come out level after
    costs, tax and inflation.

    Thomsett's break-even return (Ch. 4) is inflation / (1 - tax rate): what an
    investment must earn so that, after tax, it has kept pace with prices. A
    trade also pays its round-trip costs first, and the gain left after costs
    is what gets taxed, so over ``h`` sessions:

        B = cost + inflation * h / 252 / (1 - tax)

    ``cost`` is the itemised Indian statutory round trip
    (``strategy_metrics.india_round_trip_bps``; ~22 bp for delivery, almost all
    of it STT), before brokerage, spread and impact, so B is a floor.

    Returns
    -------
    dict
        ``move`` (fraction), ``cost``, ``inflation_part``, ``inflation``,
        ``tax``, ``horizon_days``.
    """
    if cost_bps is None:
        from strategy_metrics import india_round_trip_bps
        cost_bps = india_round_trip_bps(segment)['total']
    cost = float(cost_bps) / 1e4
    infl = float(inflation) * float(horizon_days) / TRADING_DAYS / (1.0 - float(tax))
    return {'move': cost + infl, 'cost': cost, 'inflation_part': infl,
            'inflation': float(inflation), 'tax': float(tax),
            'horizon_days': float(horizon_days)}


def trailing_stop_probability(p_end):
    """
    P(a trailing stop at the same distance is hit before the horizon).

    A trailing stop rises with the price, so it is hit at least as often as a
    fixed one. For driftless Brownian motion the drawdown from the running peak
    has the law of |W| (Levy), so the trailing stop is hit when |W| first leaves
    (-a, a), with a = -Phi^-1(p_end) the stop's distance in sigma units
    (``stops.trailing_probability``). Measured out of sample on ~170,000 NSE
    cases each in a calm market and a crash (``run_trailing_stops.py``,
    Mladjenovic Ch. 17): calibration error 0.054 and 0.056, against 0.086 and
    0.140 for the fixed-stop estimate it would otherwise be read from.
    """
    p = float(p_end)
    if not np.isfinite(p):
        return float('nan')
    if p >= 0.5:
        return 1.0
    from statistics import NormalDist
    from stops import no_exit_probability
    a = -NormalDist().inv_cdf(max(p, 1e-15))
    return float(1.0 - no_exit_probability(a))


def target_touch_probability(p_gain):
    """
    P(the price touches +x% before the horizon) from P(it ENDS above +x%).

    A sell order above the price (Mladjenovic Ch. 17's limit order) fills on a
    touch. The reflection principle upward: 2 x the end-point probability.
    Measured (``run_trailing_stops.py``): calibration error 0.038 in a calm
    market and 0.036 in a crash, against 0.111 and 0.124 for the end-point
    probability; it still runs a little low at 21 sessions.
    """
    p = float(p_gain)
    return float(min(1.0, 2.0 * p)) if np.isfinite(p) else float('nan')


def empirical_risk(last_actual, log_returns, threshold_pct):
    """
    Read risk probabilities and downside metrics off an empirical return sample.

    Counts probabilities straight from the sample (no Gaussian), so the fat tails
    survive into the numbers the user sees; VaR is an empirical quantile.

    Parameters
    ----------
    last_actual : float
        Last observed price (reference for "up"/"down").
    log_returns : np.ndarray
        Sample of horizon-end log-returns (centred near 0 for a random-walk
        point forecast).
    threshold_pct : float
        Move size (in %) for the gain/loss probabilities.

    Returns
    -------
    dict
        {'p_up', 'p_gain', 'p_loss', 'p_stop_hit', 'p_trail_hit', 'p_target_touch',
         'stop_1in5_pct', 'var5_pct',
         'range_low', 'range_high', 'cvar5_pct', 'down_semidev', 'up_semidev',
         'vol_skew'}. ``p_stop_hit`` is the chance a stop at -threshold is
        touched before the horizon (:func:`stop_hit_probability`);
        ``stop_1in5_pct`` the stop distance with a 1-in-5 chance of being
        touched. The last four are the downside-risk reads: expected shortfall
        and the up/down realized semideviation split.
    """
    r = np.asarray(log_returns, dtype=float)
    t = math.log(1.0 + threshold_pct / 100.0)
    t_dn = math.log(max(1.0 - threshold_pct / 100.0, 1e-9))
    q05, q025, q975 = np.quantile(r, [0.05, 0.025, 0.975])

    # Expected shortfall / CVaR(5%): the average loss given we're already in the
    # worst 5% tail — "if it's a bad day, how bad on average". Averaged as SIMPLE
    # returns: exp(mean log) - 1 is a geometric mean and, by Jensen's inequality,
    # overstates the average loss (VaR is unaffected — quantiles commute with exp).
    tail = r[r <= q05]
    cvar5 = float(np.mean(np.expm1(tail))) if len(tail) else float(math.exp(q05) - 1.0)

    # Realized semideviation split (Barndorff-Nielsen et al. 2010): dispersion of
    # down-moves vs up-moves; their ratio is a forward skew gauge.
    neg, pos = r[r < 0.0], r[r > 0.0]
    down_semidev = float(np.sqrt(np.mean(neg ** 2))) if len(neg) else 0.0
    up_semidev = float(np.sqrt(np.mean(pos ** 2))) if len(pos) else 0.0
    vol_skew = float(down_semidev / up_semidev) if up_semidev > 0 else float('nan')

    p_loss = float(np.mean(r < t_dn))
    # The stop with a STOP_HIT_TARGET chance of being touched: by reflection, the
    # level the price ENDS below with half that probability.
    q_stop = float(np.quantile(r, STOP_HIT_TARGET / 2.0))

    return {
        'p_up': float(np.mean(r > 0.0)),
        'p_gain': float(np.mean(r > t)),
        'p_loss': p_loss,
        'p_stop_hit': stop_hit_probability(p_loss),
        'p_trail_hit': trailing_stop_probability(p_loss),
        'p_target_touch': target_touch_probability(float(np.mean(r > t))),
        'stop_1in5_pct': float(-math.expm1(q_stop)),
        'var5_pct': float(math.exp(q05) - 1.0),
        'range_low': float(last_actual * math.exp(q025)),
        'range_high': float(last_actual * math.exp(q975)),
        'cvar5_pct': cvar5,
        'down_semidev': down_semidev,
        'up_semidev': up_semidev,
        'vol_skew': vol_skew,
    }


def risk_from_interval(median, lower, upper, last_actual, threshold_pct,
                       conf=0.95):
    """
    Fallback risk read from a model's median + (1-α) interval (Gaussian approx).

    Used ONLY when no model exposes an empirical sample. Approximates the
    horizon-end forecast as log-normal. Re-imposes normality, so it is labelled
    as an approximation in the UI and superseded whenever an empirical-residual
    model (HAR-RV) is selected.

    Returns
    -------
    dict or None
        {'p_up', 'p_gain', 'p_loss', 'p_stop_hit', 'p_trail_hit', 'p_target_touch',
         'stop_1in5_pct', 'var5_pct',
        'range_low', 'range_high'}, or None if degenerate.
    """
    if min(median, lower, upper, last_actual) <= 0 or upper <= lower:
        return None
    from statistics import NormalDist
    z = NormalDist().inv_cdf(1.0 - (1.0 - conf) / 2.0)   # 0.95 -> 1.96
    mu = math.log(median / last_actual)
    sigma = (math.log(upper) - math.log(lower)) / (2.0 * z)
    if sigma <= 0:
        return None
    t = math.log(1.0 + threshold_pct / 100.0)
    t_dn = math.log(max(1.0 - threshold_pct / 100.0, 1e-9))
    p_loss = normal_cdf((t_dn - mu) / sigma)
    return {
        'p_up': normal_cdf(mu / sigma),
        'p_gain': normal_cdf((mu - t) / sigma),
        'p_loss': p_loss,
        'p_stop_hit': stop_hit_probability(p_loss),
        'p_trail_hit': trailing_stop_probability(p_loss),
        'p_target_touch': target_touch_probability(normal_cdf((mu - t) / sigma)),
        'stop_1in5_pct': float(-math.expm1(
            mu + NormalDist().inv_cdf(STOP_HIT_TARGET / 2.0) * sigma)),
        'var5_pct': math.exp(mu - 1.6448536269514722 * sigma) - 1.0,
        'range_low': lower,
        'range_high': upper,
    }


# ---------------------------------------------------------------------------
# Results days (Benklifa, *Think Like an Option Trader*, Ch. 5: a scheduled
# event is a "known unknown" -- its date is public, its outcome is not)
# ---------------------------------------------------------------------------

#: A results session's variance against an ordinary session's, fitted on
#: 2018-2021 and stable in 2022-2024 (``run_results_days.py``): the session on
#: or after the board meeting, and the one after it (many report after the
#: close). RESULTS_RECAL is the 95% quantile's own shrinkage once results
#: windows are no longer inflating it (q_adj / q = 0.95-0.97 at 1-10 sessions).
RESULTS_DAY0_VAR = 2.86
RESULTS_DAY1_VAR = 3.74
RESULTS_RECAL = 0.96


def results_sessions(sessions, meeting_dates):
    """
    Count the results sessions inside a forecast window.

    ``sessions`` is the last observed session followed by the forecast
    sessions (dates, ascending); only the forecast part counts. For each
    meeting, day0 is the first session on or after it and day1 the next.
    Returns ``(n_day0, n_day1, first_meeting)``.
    """
    import pandas as pd
    days = pd.DatetimeIndex(pd.to_datetime(list(sessions))).normalize()
    n0 = n1 = 0
    first = None
    for d in sorted(pd.to_datetime(list(meeting_dates))):
        if not len(days) or pd.Timestamp(d).normalize() < days[0]:
            continue                      # already in the history the models saw
        k = int(days.searchsorted(pd.Timestamp(d).normalize()))
        hit = False
        if 1 <= k < len(days):
            n0 += 1
            hit = True
        if 1 <= k + 1 < len(days):
            n1 += 1
            hit = True
        if hit and first is None:
            first = pd.Timestamp(d)
    return n0, n1, first


def results_widening(horizon_sessions, n_day0, n_day1, k0=RESULTS_DAY0_VAR,
                     k1=RESULTS_DAY1_VAR, recal=RESULTS_RECAL):
    """
    The spread multiplier for a window containing results sessions.

    Variance adds: the window holds ``h`` ordinary sessions' worth plus each
    results session's excess, so the 1-sigma width scales by
    sqrt((h + n0 (k0 - 1) + n1 (k1 - 1)) / h), times ``recal``. Measured out of
    sample (2022 - mid-2024): a plain 95% band covered windows with results
    81.9% / 89.3% / 93.0% of the time at 1 / 5 / 10 sessions, the widened one
    94.8% / 94.5% / 95.2%. 1.0 when there is no results session.
    """
    if not (n_day0 or n_day1):
        return 1.0
    h = max(float(horizon_sessions), 1.0)
    return float(recal * math.sqrt((h + n_day0 * (k0 - 1.0) + n_day1 * (k1 - 1.0)) / h))


def widen_log_returns(log_returns, scale):
    """Stretch a return sample about its median by ``scale`` (tails kept)."""
    r = np.asarray(log_returns, dtype=float)
    if scale == 1.0 or not len(r):
        return r
    med = float(np.median(r))
    return med + float(scale) * (r - med)


def widen_interval(median, lower, upper, scale):
    """Stretch an interval about its median in log space by ``scale``."""
    if scale == 1.0 or not (median > 0 and lower > 0 and upper > 0):
        return lower, upper
    return (median * (lower / median) ** scale, median * (upper / median) ** scale)
