"""
Forward-looking volatility signal for the HAR-RV cone, from **India VIX**.

Why this module exists
----------------------
A reviewer's best remaining idea was to feed *implied* (option-derived,
forward-looking) volatility into the cone, since HAR-RV is built purely on
*realized* (backward-looking) variance and structurally cannot see what the
market expects next. The catch: **single-name NSE option-chain IV is not freely
or reliably available** — NSE's own API is bot-protected (HTTP 403 without a real
browser session, empty bodies from data centres), `nselib`'s wrapper fails the
same way, and yfinance serves no options for `.NS` tickers. Building a single-name
IV scraper would be fragile, frequently-empty dead code.

(Update, October 2026: NSE's newer ``option-chain-v3`` endpoint does answer
with a browser-like session, and ``option_market.py`` reads it live for the
app's options view (README section 64). It is still live-only and still
fragile, and NSE keeps no history, so nothing here changes: a cone input has
to be backtestable, and single-name IV cannot be.)

What *is* reliably free is **India VIX** (``^INDIAVIX``) — NSE's forward-looking
implied-volatility index for NIFTY, a plain quote on yfinance. It is the market's
own ~30-day forward vol estimate. A single stock's forward vol is mostly its
systematic (market-driven) component plus an idiosyncratic part, so we use India
VIX to tilt the cone:

    F = (VIX-implied market daily vol) / (NIFTY recently-realized daily vol)
    w = R^2 of the stock vs NIFTY            (its systematic variance share)
    m = clip(1 + w * (F - 1), [lo, hi])      (forward-vol multiplier on the cone)

``F > 1`` means the market is pricing in *more* forward vol than it has recently
realized (widen the cone); ``F < 1`` means calmer ahead (tighten). The stock only
responds in proportion to how market-linked it is (``w``), and ``m`` is clipped so
the cone can neither collapse nor explode. ``beta`` cancels in the ratio ``F``, so
only the correlation (linkage) matters.

This is weaker than true single-name IV — it carries only the *systematic* slice
of forward vol — but it is real forward-looking information, reliably free, and
**leak-free**: every lookup is "as of" the last bar in the passed DataFrame, so in
a walk-forward backtest a past origin only ever sees the VIX/NIFTY values that
existed at that origin. Every failure path returns a no-op multiplier of 1.0.
"""

import numpy as np
import pandas as pd

_VIX_SYMBOL = "^INDIAVIX"
_INDEX_SYMBOL = "^NSEI"          # NIFTY 50
_TRADING_DAYS = 252

# Tunables (documented; conservative by design).
_REALIZED_WINDOW = 21            # NIFTY realized-vol lookback (≈1 month)
_LINKAGE_WINDOW = 252            # window for stock~NIFTY correlation (R^2)
_F_CLIP = (0.5, 2.5)             # clamp the implied/realized ratio
_M_CLIP = (0.85, 1.30)          # clamp the final cone multiplier

# In-process cache of the fetched daily series (symbol -> Series). The app wraps
# the model call in st.cache_data already; this just avoids refetching VIX/NIFTY
# for every model and every backtest origin within one process.
_SERIES_CACHE = {}


def _fetch_close_series(symbol, period="10y"):
    """Daily close Series indexed by tz-naive date; {} -> empty on any failure."""
    if symbol in _SERIES_CACHE:
        return _SERIES_CACHE[symbol]
    s = pd.Series(dtype=float)
    try:
        import yfinance as yf
        h = yf.Ticker(symbol).history(period=period, interval="1d",
                                      auto_adjust=False)
        if h is not None and not h.empty and "Close" in h.columns:
            close = h["Close"].copy()
            close.index = pd.to_datetime(close.index).tz_localize(None).normalize()
            s = close[~close.index.duplicated(keep="last")].dropna()
    except Exception as exc:                     # network / parsing / yf changes
        print(f"iv_data: could not fetch {symbol} ({exc}); IV tilt disabled.")
    _SERIES_CACHE[symbol] = s
    return s


def _asof_value(series, asof):
    """Most recent value at or before ``asof`` (leak-free); None if none exists."""
    if series is None or series.empty:
        return None
    sub = series[series.index <= asof]
    return float(sub.iloc[-1]) if len(sub) else None


def _daily_returns_asof(series, asof, window):
    """Trailing ``window`` daily log returns ending at/before ``asof``."""
    if series is None or series.empty:
        return np.array([])
    sub = series[series.index <= asof].tail(window + 1)
    if len(sub) < 5:
        return np.array([])
    return np.diff(np.log(sub.to_numpy(float)))


def _to_daily_close(df):
    """Collapse a stock frame (daily or hourly) to a daily close Series."""
    d = df.copy()
    d["datetime"] = pd.to_datetime(d["datetime"])
    d = d.dropna(subset=["adj_close"]).set_index("datetime").sort_index()
    daily = d["adj_close"].resample("1D").last().dropna()
    daily.index = daily.index.normalize()
    return daily


#: Trailing days used to learn the normal level of the implied/realised ratio,
#: and the minimum needed before the centring is trusted at all. Two years is
#: long enough to average over one volatility regime without being so long that
#: a structural shift in the premium never washes out.
_PREMIUM_WINDOW = 504
_PREMIUM_MIN_OBS = 252


def _premium_baseline(vix, idx, asof, window=_PREMIUM_WINDOW,
                      min_obs=_PREMIUM_MIN_OBS):
    """
    The trailing median of ``implied / realised`` as of ``asof``.

    This is the *normal* level of the variance risk premium, against which a
    current reading is either high or low. The median is used rather than the
    mean because the ratio's upper tail is long (95th percentile 1.81 against a
    median of 1.27) and a mean would be dragged by crisis spikes.

    Returns ``None`` when there is too little history, which callers must treat
    as "no signal" rather than "no premium".
    """
    if vix is None or idx is None or len(vix) == 0 or len(idx) == 0:
        return None
    try:
        v = vix[vix.index <= asof].tail(window + _REALIZED_WINDOW + 1)
        i = idx[idx.index <= asof].tail(window + _REALIZED_WINDOW + 1)
        if len(v) < min_obs or len(i) < min_obs:
            return None
        r = np.log(i / i.shift(1))
        realised = r.rolling(_REALIZED_WINDOW).std()
        implied = (v / 100.0) / np.sqrt(_TRADING_DAYS)
        both = pd.concat({"imp": implied, "real": realised}, axis=1).dropna()
        both = both[(both["real"] > 0) & (both["imp"] > 0)].tail(window)
        if len(both) < min_obs:
            return None
        med = float((both["imp"] / both["real"]).median())
        return med if np.isfinite(med) and med > 0 else None
    except Exception:
        return None


def forward_vol_factor(df, interval="1d"):
    """
    Compute the India-VIX forward-vol multiplier for a stock's cone.

    Parameters
    ----------
    df : pd.DataFrame
        The stock frame the cone is being built on (must have 'datetime',
        'adj_close'). The "as of" date is its last bar, so this is leak-free
        inside a walk-forward backtest (the frame is origin-truncated there).
    interval : str
        Unused for the market computation (always daily), accepted for symmetry.

    Returns
    -------
    tuple(float, dict)
        ``(multiplier, info)``. ``multiplier`` is 1.0 (no-op) whenever the VIX or
        index data is unavailable or insufficient. ``info`` records the inputs
        (vix, implied/realized ratio F, linkage R^2, asof, reason) for audit.
    """
    info = {"multiplier": 1.0, "reason": "ok"}
    try:
        last = pd.to_datetime(df["datetime"]).max()
        asof = last.normalize()
    except Exception:
        return 1.0, {"multiplier": 1.0, "reason": "no datetime"}
    # VIX and NIFTY are daily closes stamped at midnight. An intraday origin on
    # day D must not read day D's close, which prints at 15:30; it gets D-1's.
    if last != asof:
        asof = asof - pd.Timedelta(days=1)
    info["asof"] = asof.date().isoformat()

    vix = _fetch_close_series(_VIX_SYMBOL)
    idx = _fetch_close_series(_INDEX_SYMBOL)

    vix_val = _asof_value(vix, asof)
    if vix_val is None or vix_val <= 0:
        return 1.0, {**info, "multiplier": 1.0, "reason": "VIX unavailable"}
    info["vix"] = round(vix_val, 2)

    # Market implied daily vol from the annualized VIX (%), and recently realized
    # daily vol of NIFTY — their ratio is the forward signal.
    iv_daily = (vix_val / 100.0) / np.sqrt(_TRADING_DAYS)
    mkt_rets = _daily_returns_asof(idx, asof, _REALIZED_WINDOW)
    if len(mkt_rets) < 10:
        return 1.0, {**info, "multiplier": 1.0, "reason": "index realized vol n/a"}
    rv_daily_mkt = float(np.std(mkt_rets, ddof=1))
    if rv_daily_mkt <= 0:
        return 1.0, {**info, "multiplier": 1.0, "reason": "zero realized vol"}
    F_raw = iv_daily / rv_daily_mkt
    info["F_raw"] = round(float(F_raw), 3)

    # ── Centre F on its own history, because F = 1 is not neutral ──────────
    # Implied volatility is a RISK-NEUTRAL quantity and realised volatility a
    # physical-measure one (Hilpisch, *Financial Theory with Python*, Ch. 5).
    # Their ratio therefore carries the variance risk premium and is above 1
    # almost all of the time, not half of it. Measured on 2,428 days of
    # ^INDIAVIX against NIFTY: median F = 1.270, mean 1.290, and **F > 1 on
    # 83.7% of days**.
    #
    # Treating 1.0 as the neutral point therefore multiplied the cone by
    # 1.05-1.16 (for R^2 of 0.2-0.6) on a *typical* day -- a constant widening
    # dressed up as a forward-looking signal. This divides F by its trailing
    # median so the multiplier responds to how the premium compares with its
    # own normal level, which is the only part of it that carries information.
    #
    # The baseline is strictly trailing (``<= asof``), so this stays leak-free
    # in a walk-forward backtest for the same reason every other lookup here
    # does. With too little history to form a baseline the factor falls back to
    # a no-op rather than to the uncentred value: a miscalibrated signal is
    # worse than none, and README §48 is the reason.
    base = _premium_baseline(vix, idx, asof)
    if base is None:
        return 1.0, {**info, "multiplier": 1.0, "reason": "no premium baseline"}
    info["premium_baseline"] = round(float(base), 3)
    F = float(np.clip(F_raw / base, *_F_CLIP))
    info["F"] = round(F, 3)

    # Stock's systematic variance share (R^2) vs NIFTY, over the overlap.
    stock_daily = _to_daily_close(df)
    stock_rets = np.diff(np.log(stock_daily.tail(_LINKAGE_WINDOW + 1).to_numpy(float))) \
        if len(stock_daily) > 6 else np.array([])
    w = 0.0
    if len(stock_rets) >= 30:
        # Align stock & index daily returns on common dates.
        sdf = pd.DataFrame({"s": stock_daily}).join(
            pd.DataFrame({"i": idx}), how="inner").dropna()
        sdf = sdf[sdf.index <= asof].tail(_LINKAGE_WINDOW + 1)
        if len(sdf) >= 30:
            sr = np.diff(np.log(sdf["s"].to_numpy(float)))
            ir = np.diff(np.log(sdf["i"].to_numpy(float)))
            if sr.std() > 0 and ir.std() > 0:
                corr = float(np.corrcoef(sr, ir)[0, 1])
                w = float(np.clip(corr ** 2, 0.0, 1.0))    # R^2 = systematic share
    info["linkage_r2"] = round(w, 3)

    m = float(np.clip(1.0 + w * (F - 1.0), *_M_CLIP))
    info["multiplier"] = round(m, 4)
    return m, info


def clear_cache():
    """Drop the in-process series cache (used by tests)."""
    _SERIES_CACHE.clear()
