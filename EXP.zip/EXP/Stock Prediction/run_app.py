"""
Start the forecasting app, installing any missing Python packages first.

    python run_app.py            # check, ask, install what is missing, launch
    python run_app.py --yes      # install without asking
    python run_app.py --check    # report only; install nothing, launch nothing
    python run_app.py -- --server.port 8600   # anything after -- goes to Streamlit

On Windows, double-clicking ``run_app.bat`` does the same. How the install
avoids the Prophet pin conflict in ``requirements.txt`` is explained in
``dependencies.py``. Packages installed at a different version from the pin
are reported and left alone.
"""

import os
import subprocess
import sys

import dependencies as deps


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    passthrough = argv[argv.index("--") + 1:] if "--" in argv else []
    flags = set(argv[:argv.index("--")] if "--" in argv else argv)

    if not deps.python_ok():
        print(f"Python {'.'.join(map(str, deps.MIN_PYTHON))}+ is required; this is "
              f"{sys.version.split()[0]} ({sys.executable}).")
        return 1
    missing, mismatched = deps.check()
    for name, _spec, pin, have in mismatched:
        print(f"  note: {name} {have} is installed; the app was tested with {pin}")
    if missing:
        print(f"{len(missing)} required package(s) are not installed in {sys.executable}:")
        print("  " + ", ".join(m[0] for m in missing))
        if "--check" in flags:
            return 1
        if "--yes" not in flags:
            try:
                answer = input("Install them now? This downloads from PyPI and can take "
                               "several minutes the first time. [Y/n] ").strip().lower()
            except EOFError:
                answer = "n"
            if answer not in ("", "y", "yes"):
                print("Nothing installed. To do it yourself: python run_app.py --yes")
                return 1
        if not deps.install([(n, s, p) for n, s, p, _ in missing]):
            return 1
        print("All required packages are installed.")
    else:
        print("All required packages are installed.")
    if "--check" in flags:
        return 0
    here = os.path.dirname(os.path.abspath(__file__))
    cmd = [sys.executable, "-m", "streamlit", "run", os.path.join(here, "UI.py"), *passthrough]
    print("Starting the app: " + " ".join(cmd))
    return subprocess.call(cmd, cwd=here)


if __name__ == "__main__":
    sys.exit(main())
