"""
The stock screens of Hough, *Your Next Great Stock* (2008), scored live for
the selected stock: which of the book's Part Three recipes it would pass, and
Part Four's checks on the screen survivors (deal breakers, "talk yourself out
of it", and the reasons to sell).

What this is, and what it is not
--------------------------------
**Information beside the forecast, not an input to it.** Hough's screens are
fundamental, and README section 32 measured that yfinance holds about a year of
point-in-time statement history per NSE name, so none of them can be
back-tested here. What the book says about them is its own evidence (US
studies, 1962-2006). The app shows today's statements for today's decision,
the use ``fundamentals.current_snapshot`` was always fine for.

The two claims that need only prices were tested on NSE before the reserved
period (``tests/validation/run_hough_screens.py``, README section 67); their
results are in :data:`MEASURED` and are shown next to the rule.

Adapting a 2008 US book to NSE
------------------------------
* Statements are the latest **fiscal year**, the book's own "easy method"
  (Ch. 16) where it asks for trailing twelve months; yfinance's quarterly
  history is too short for a TTM sum.
* Dollar cut-offs are converted at :data:`USD_INR` and are not inflation
  adjusted. The book calls them rough ("say, sales of $100 million").
* "Insiders" in yfinance's ownership fields are mostly **promoters**, and SEBI's
  minimum public shareholding caps them at 75%. So Ch. 24's "pitch stocks with
  more than three-quarters owned by insiders and institutions" would discard
  most of the NIFTY; it is shown as context, not as a deal breaker.
* Industry comparisons ("below the industry median") need every company in the
  industry, which the app does not load; those criteria are reported as not
  measurable rather than guessed. So are the screens built on analyst
  estimates (Ch. 14, 17, 18), which no free feed carries for NSE. Insider
  purchases (Ch. 19) come from SEBI's disclosures, through ``insiders.py``.

Thresholds are the book's, quoted in each ``rule``, except those marked as this
project's (the book describes the pattern but gives no number).
"""

import math

import numpy as np
import pandas as pd

from stock_checklist import (BAD, FINANCIAL_SECTORS, GOOD, INFO, NA, USD_INR, WATCH,
                             _average_balance, _check, _div, _finite, _money, _ok,
                             _ratio_series, _row, _ttm_dividends, statement_fx)

# Part Three recipes (US$ figures are the book's)
NEAR_HIGH = 0.05                 # Ch. 12-13: within 5% of the 52-week high
SALES_MIN_USD = 100e6            # Ch. 12-14: sales above $100 million
SALES_ON_SALE_MIN_USD = 200e6    # Ch. 21
VOLUME_MIN_SHARES = 100_000      # Ch. 12-13, 21: average daily volume
SALES_GROWTH_FAST = 0.20         # Ch. 12 refinement: one-year sales growth above 20%
INSIDER_MIN = 0.05               # Ch. 12 refinement: insiders own at least 5%
PEG_FLOOR, PEG_CEILING = 0.2, 1.5     # Ch. 13 (and Ch. 24: think twice above 1.5)
PS_MAX = 1.5                     # Ch. 21
ACCRUAL_CAP_USD = (200e6, 10e9)  # Ch. 20: market value
ACCRUAL_GROWTH_3Y = 0.15         # Ch. 20: three-year earnings growth
RD_SALES_MIN = RD_ASSETS_MIN = 0.05   # Ch. 15
PRICE_TO_RD_MAX = 20.0           # Ch. 15
F_SCORE_HIGH = 8                 # Ch. 22 / Piotroski: the high scorers are 8 and 9
# Ch. 23 guru screens
BUFFETT_ROE = 0.15
LYNCH_PEG = (0.5, 1.0)
LYNCH_GROWTH = (0.20, 0.50)
ZWEIG_GROWTH = 0.15
ZWEIG_PE_FLOOR = 5.0
# Ch. 24 deal breakers and checks
DEBT_YEARS_MAX = 0.5             # debt below half a year's income (net income + interest)
OWNERSHIP_MAX = 0.75             # insiders + institutions (context only on NSE, see above)
TURNOVER_MIN_USD = 1e6           # average daily value traded
ROIC_GOOD = 0.15
ROIC_TAX_FLOOR = 0.25            # "use a minimum rate of 25 percent or so"
# This project's cut-offs, where the book describes a pattern without a number
PLUNGE_2D = -0.10                # "a day or couple of days when it suddenly plummeted"
BUYOUT_JUMP, BUYOUT_FLAT, BUYOUT_SESSIONS = 0.15, 0.03, 10   # "jumped, then a flat line"
EARNINGS_DROP = 0.25             # "years that earnings were negative or sharply lower"
ISSUER_INSIDERS_MAX = 0.10       # Ch. 25: "a management team that doesn't own many shares"
GROWTH_TOLERANCE = 0.005         # growth rates within half a point count as equal
# yfinance restates a bonus issue in some statements and not others (HDFC Bank's
# reported EPS reads 88.68, 44.16, 44.82 across its 2025 bonus), so EPS here is
# net income / year-end shares, and per-share growth is refused across a year
# whose share count moved by 40% or more (a bonus, split or merger).
SHARE_JUMP = 1.4

# What the price-only claims measured on NSE (run_hough_screens.py, 2018-01 ..
# 2024-06, 400 liquid names, before the reserved period). README section 67.
MEASURED = {
    "falling_knife": (
        "Measured on NSE, 2018-24: a 12-month loser still falling this week did no worse over "
        "the next month than one that had stabilised (+0.15%, t 1.0). Waiting for it to "
        "stabilise saved 0.31% (t -2.1), but that is the lag every 12-month loser shows "
        "(momentum); net of it, this week's direction added -0.08% (t -0.7). So the year "
        "matters, the week does not."),
}

PASS, FAIL, PARTLY, CANT = "passes", "fails", "partly measurable", "can't be run here"
SCREEN_ICON = {PASS: "✅", FAIL: "❌", PARTLY: "⚠️", CANT: "➖"}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _pct(x, digits=1):
    return f"{x * 100:+.{digits}f}%" if _ok(x) else "—"


def _at(series, when):
    """A statement value at one period end, NaN when absent."""
    if when is None or not len(series) or when not in series.index:
        return float("nan")
    return _finite(series[when])


def _cagr(series):
    """Compound annual growth from the oldest to the latest period shown."""
    if len(series) < 2:
        return float("nan")
    first, last = _finite(series.iloc[0]), _finite(series.iloc[-1])
    years = len(series) - 1
    if not (_ok(first) and _ok(last)) or first <= 0 or last <= 0:
        return float("nan")
    return (last / first) ** (1.0 / years) - 1.0


def _yoy(series):
    if len(series) < 2:
        return float("nan")
    prev, last = _finite(series.iloc[-2]), _finite(series.iloc[-1])
    return last / prev - 1.0 if _ok(prev) and _ok(last) and prev > 0 else float("nan")


def _usd(x):
    return f"${x / 1e9:,.0f} billion" if x >= 1e9 else f"${x / 1e6:,.0f} million"


def _inr_of_usd(x):
    return x * USD_INR


def _crore(x):
    return f"₹{x / 1e7:,.0f} cr" if _ok(_finite(x)) else "—"


# ---------------------------------------------------------------------------
# Prices (the app's own daily history)
# ---------------------------------------------------------------------------

def price_facts(hist):
    """
    The price-based facts the book's screens and deal breakers use, from the
    app's daily history frame. None when there is under ~6 months of it.
    """
    if hist is None or len(hist) < 130 or "close" not in hist:
        return None
    g = hist.rename(columns={"adj close": "adj_close"}).copy()
    if "datetime" not in g:
        g = g.rename_axis("datetime").reset_index()
    g = g.sort_values("datetime")
    idx = pd.to_datetime(g["datetime"].to_numpy())
    raw = pd.Series(pd.to_numeric(g["close"], errors="coerce").to_numpy(float), index=idx)
    adj = pd.Series(pd.to_numeric(g.get("adj_close", g["close"]), errors="coerce").to_numpy(float),
                    index=idx)
    vol = (pd.Series(pd.to_numeric(g["volume"], errors="coerce").to_numpy(float), index=idx)
           if "volume" in g else pd.Series(np.nan, index=idx))
    ok = adj > 0
    adj, raw, vol = adj[ok], raw[ok], vol[ok]
    if len(adj) < 130:
        return None
    last = float(adj.iloc[-1])

    def back(k):
        return last / float(adj.iloc[-1 - k]) - 1.0 if len(adj) > k else float("nan")

    year = adj.iloc[-252:]
    r2 = (adj / adj.shift(2) - 1.0).iloc[-252:]
    worst = r2.min() if r2.notna().any() else float("nan")
    worst_day = r2.idxmin() if r2.notna().any() else None
    rec = adj.iloc[-5:]
    down_days = int((rec.diff().dropna() < 0).sum()) + (1 if len(adj) > 5 and rec.iloc[0] < adj.iloc[-6] else 0)

    # Ch. 24's buyout chart: a jump, then a flat line.
    buyout = None
    r1 = adj.pct_change()
    recent = r1.iloc[-63:]
    for day in recent.index[recent >= BUYOUT_JUMP][::-1]:
        after = adj.loc[adj.index >= day]
        if len(after) - 1 >= BUYOUT_SESSIONS:
            base = float(after.iloc[0])
            if bool(((after / base - 1.0).abs() <= BUYOUT_FLAT).all()):
                buyout = {"date": str(day.date()), "jump": float(recent[day]),
                          "sessions": len(after) - 1}
            break

    tail = slice(-63, None)
    return {
        "date": str(adj.index[-1].date()),
        "close": last,
        "high_52w": float(year.max()),
        "from_high": last / float(year.max()) - 1.0,
        "r5": back(5), "r63": back(63), "r126": back(126), "r252": back(252),
        "down_days_5": down_days,
        "worst_2d": float(worst) if _ok(_finite(worst)) else float("nan"),
        "worst_2d_date": str(worst_day.date()) if worst_day is not None else None,
        "buyout": buyout,
        "avg_volume": float(vol.iloc[tail].mean()) if vol.notna().any() else float("nan"),
        "median_turnover": float((raw * vol).iloc[tail].median()) if vol.notna().any() else float("nan"),
        "sessions": len(adj),
    }


def market_returns(close):
    """3- and 6-month price change of a market index close series."""
    if close is None or len(close) < 127:
        return None
    c = pd.Series(close).dropna()
    last = float(c.iloc[-1])
    return {"r63": last / float(c.iloc[-64]) - 1.0, "r126": last / float(c.iloc[-127]) - 1.0,
            "date": str(pd.Timestamp(c.index[-1]).date())}


# ---------------------------------------------------------------------------
# Statements
# ---------------------------------------------------------------------------

def _lines(inputs):
    income, balance, cash = inputs.get("income"), inputs.get("balance"), inputs.get("cashflow")
    L = {
        "revenue": _row(income, "Total Revenue", "Operating Revenue"),
        "net": _row(income, "Net Income", "Net Income Common Stockholders"),
        "eps": _row(income, "Diluted EPS", "Basic EPS"),
        "gross": _row(income, "Gross Profit"),
        "op_income": _row(income, "Operating Income"),
        "pretax": _row(income, "Pretax Income"),
        "tax": _row(income, "Tax Provision"),
        "interest": _row(income, "Interest Expense", "Interest Expense Non Operating"),
        "rd": _row(income, "Research And Development"),
        "unusual": _row(income, "Total Unusual Items", "Total Unusual Items Excluding Goodwill"),
        "assets": _row(balance, "Total Assets"),
        "equity": _row(balance, "Stockholders Equity", "Common Stock Equity"),
        "ltd": _row(balance, "Long Term Debt And Capital Lease Obligation", "Long Term Debt"),
        "debt": _row(balance, "Total Debt"),
        "cur_debt": _row(balance, "Current Debt And Capital Lease Obligation", "Current Debt"),
        "cur_assets": _row(balance, "Current Assets"),
        "cur_liab": _row(balance, "Current Liabilities"),
        "cash": _row(balance, "Cash Cash Equivalents And Short Term Investments",
                     "Cash And Cash Equivalents"),
        "shares": _row(balance, "Ordinary Shares Number", "Share Issued"),
        "cfo": _row(cash, "Operating Cash Flow", "Cash Flow From Continuing Operating Activities"),
        "cfi": _row(cash, "Investing Cash Flow", "Cash Flow From Continuing Investing Activities"),
        "cff": _row(cash, "Financing Cash Flow", "Cash Flow From Continuing Financing Activities"),
        "fcf": _row(cash, "Free Cash Flow"),
        "capex": _row(cash, "Capital Expenditure"),
        "dividends_paid": -_row(cash, "Cash Dividends Paid", "Common Stock Dividend Paid"),
        "buybacks": -_row(cash, "Repurchase Of Capital Stock", "Common Stock Payments"),
        "issued": _row(cash, "Issuance Of Capital Stock", "Common Stock Issuance"),
        "net_issued": _row(cash, "Net Common Stock Issuance"),
    }
    if not len(L["fcf"]) and len(L["cfo"]) and len(L["capex"]):
        L["fcf"] = (L["cfo"] + L["capex"].reindex(L["cfo"].index)).dropna()

    # Statement money in rupees, so it can be set against the rupee market value.
    info = inputs.get("info") or {}
    fx = statement_fx(info)
    L["fx_ok"] = _ok(fx)
    L["cur"] = "INR" if L["fx_ok"] else str(info.get("financialCurrency") or "INR")
    if L["fx_ok"] and fx != 1.0:
        for k in ("revenue", "net", "eps", "gross", "op_income", "pretax", "tax", "interest", "rd",
                  "unusual", "assets", "equity", "ltd", "debt", "cur_debt", "cur_assets", "cur_liab",
                  "cash", "cfo", "cfi", "cff", "fcf", "capex", "dividends_paid", "buybacks", "issued",
                  "net_issued"):
            L[k] = L[k] * fx

    # EPS from net income and the balance-sheet share count (see SHARE_JUMP).
    L["share_jump"] = None
    sh = L["shares"]
    if len(sh) >= 2:
        ratio = (sh / sh.shift(1)).dropna()
        jumps = ratio[(ratio >= SHARE_JUMP) | (ratio <= 1.0 / SHARE_JUMP)]
        if len(jumps):
            q = jumps.index[-1]
            L["share_jump"] = (f"the share count changed {(jumps[q] - 1) * 100:+.0f}% in FY{q.year} "
                               "(a bonus, split or merger), so per-share growth across it is not comparable")
    if len(sh) and len(L["net"]):
        derived = _ratio_series(L["net"], sh)
        if len(derived) >= 2 or not len(L["eps"]):
            L["eps"] = derived
    return L


def piotroski(L, is_fin):
    """
    Piotroski's nine-point score as Hough lists it (Ch. 22). Each point is a
    year-on-year comparison of the two latest fiscal years. Lenders are left
    out, as in Piotroski's study: gross margin and the current ratio do not
    exist for a bank.
    """
    rule = ("Piotroski F-score (Ch. 22): one point each for positive earnings, earnings "
            "growing (return on assets up), positive operating cash flow, cash flow above "
            "earnings, debt/assets falling, current ratio rising, no net share issuance, "
            "gross margin rising, asset turnover rising. His winners scored 8-9.")
    if is_fin:
        return {"score": None, "scored": 0, "checks": [], "rule": rule,
                "why": "not defined for lenders (Piotroski's study left them out)"}
    net, assets, rev, cur = L["net"], L["assets"], L["revenue"], L["cur"]
    if len(net) < 2 or len(assets) < 2:
        return {"score": None, "scored": 0, "checks": [], "rule": rule,
                "why": "needs two years of statements"}
    y0, y1 = net.index[-1], net.index[-2]
    y2 = net.index[-3] if len(net) >= 3 else None

    def begin(year, prior):
        a = _at(assets, prior) if prior is not None else float("nan")
        return a if _ok(a) else _at(assets, year)

    roa0 = _div(_at(net, y0), begin(y0, y1))
    roa1 = _div(_at(net, y1), begin(y1, y2))
    cfo0 = _at(L["cfo"], y0)
    checks = []

    def point(label, ok, value):
        verdict = NA if ok is None else (GOOD if ok else WATCH)
        checks.append(_check(label, value, verdict, ""))

    point("Profitable", None if not _ok(roa0) else roa0 > 0, f"return on assets {_pct(roa0)}")
    point("Return on assets rising", None if not (_ok(roa0) and _ok(roa1)) else roa0 > roa1,
          f"{_pct(roa1)} → {_pct(roa0)}")
    point("Operating cash flow positive", None if not _ok(cfo0) else cfo0 > 0,
          _money(cfo0, cur) if _ok(cfo0) else "not reported")
    point("Cash flow above earnings", None if not (_ok(cfo0) and _ok(_at(net, y0))) else cfo0 > _at(net, y0),
          f"operating cash {_money(cfo0, cur)} against profit {_money(_at(net, y0), cur)}"
          if _ok(cfo0) else "not reported")
    ltd = L["ltd"]
    if len(ltd):
        lev0, lev1 = _div(_at(ltd, y0), _at(assets, y0)), _div(_at(ltd, y1), _at(assets, y1))
        if _ok(lev0) and _ok(lev1):
            # Hough's compromise: unchanged at zero counts, so a debt-free company scores.
            point("Debt/assets falling", lev0 < lev1 or (lev0 == 0 and lev1 == 0),
                  f"{lev1 * 100:.1f}% → {lev0 * 100:.1f}%")
        else:
            point("Debt/assets falling", None, "not reported")
    else:
        point("Debt/assets falling", True, "no long-term debt reported")
    cr0 = _div(_at(L["cur_assets"], y0), _at(L["cur_liab"], y0))
    cr1 = _div(_at(L["cur_assets"], y1), _at(L["cur_liab"], y1))
    point("Current ratio rising", None if not (_ok(cr0) and _ok(cr1)) else cr0 > cr1,
          f"{cr1:.2f} → {cr0:.2f}" if _ok(cr0) and _ok(cr1) else "not reported")
    ni = _at(L["net_issued"], y0)
    if not _ok(ni):
        iss, bb = _at(L["issued"], y0), _at(L["buybacks"], y0)
        ni = (iss if _ok(iss) else 0.0) - (bb if _ok(bb) else 0.0) if (_ok(iss) or _ok(bb)) else float("nan")
    if _ok(ni):
        point("No net share issuance", ni <= 0, f"net issuance {_money(ni, cur)}" if ni > 0
              else "none" if ni == 0 else f"net buyback {_money(-ni, cur)}")
    else:
        sh0, sh1 = _at(L["shares"], y0), _at(L["shares"], y1)
        point("No net share issuance", None if not (_ok(sh0) and _ok(sh1)) else sh0 <= sh1,
              f"shares {sh1 / 1e7:,.1f} cr → {sh0 / 1e7:,.1f} cr" if _ok(sh0) and _ok(sh1) else "not reported")
    gm0, gm1 = _div(_at(L["gross"], y0), _at(rev, y0)), _div(_at(L["gross"], y1), _at(rev, y1))
    point("Gross margin rising", None if not (_ok(gm0) and _ok(gm1)) else gm0 > gm1,
          f"{gm1 * 100:.1f}% → {gm0 * 100:.1f}%" if _ok(gm0) and _ok(gm1) else "not reported")
    at0, at1 = _div(_at(rev, y0), begin(y0, y1)), _div(_at(rev, y1), begin(y1, y2))
    point("Asset turnover rising", None if not (_ok(at0) and _ok(at1)) else at0 > at1,
          f"{at1:.2f} → {at0:.2f}" if _ok(at0) and _ok(at1) else "not reported")
    scored = [c for c in checks if c["verdict"] != NA]
    return {"score": sum(c["verdict"] == GOOD for c in scored), "scored": len(scored),
            "checks": checks, "rule": rule, "why": None, "year": str(y0.date())}


def roic_series(L):
    """Hough's ROIC (Ch. 24): after-tax operating profit over invested capital."""
    op, assets, cl = L["op_income"], L["assets"], L["cur_liab"]
    if not len(op) or not len(assets) or not len(cl):
        return pd.Series(dtype=float)
    capital = {}
    for q in assets.index.intersection(cl.index):
        cd = _at(L["cur_debt"], q)
        capital[q] = _finite(assets[q]) - (_finite(cl[q]) - (cd if _ok(cd) else 0.0))
    cap = _average_balance(pd.Series(capital, dtype=float).sort_index())
    out = {}
    for q in op.index.intersection(cap.index):
        rate = _div(_at(L["tax"], q), _at(L["pretax"], q))
        rate = max(rate, ROIC_TAX_FLOOR) if _ok(rate) else ROIC_TAX_FLOOR
        out[q] = _div(_finite(op[q]) * (1.0 - rate), cap[q])
    s = pd.Series(out, dtype=float).sort_index()
    return s[s.apply(_ok)]


# ---------------------------------------------------------------------------
# The whole read
# ---------------------------------------------------------------------------

def build_screens(inputs, hist=None, market=None, today=None, insider=None):
    """
    Score one company against Hough's screens and checks.

    Parameters
    ----------
    inputs : dict
        ``stock_checklist.fetch_inputs``' output (annual ``income``,
        ``balance``, ``cashflow``, ``info``, ``dividends``).
    hist : DataFrame, optional
        The app's daily history (``datetime, close, adj close, volume``).
    market : dict, optional
        :func:`market_returns` of a market index, for Ch. 21's "above the
        database average" price tests.
    today : date-like, optional
        For the trailing dividend (injectable for tests).
    insider : dict, optional
        ``insiders.live_view`` for this stock (SEBI disclosures), for Ch. 19.

    Returns
    -------
    dict or None
        ``screens`` (list of recipe results), ``fscore``, ``survivor``
        (Ch. 24 checks), ``sell`` (Ch. 25 signs), ``price`` and ``metrics``.
        None when there are no statements at all.
    """
    info = inputs.get("info") or {}
    L = _lines(inputs)
    if not len(L["revenue"]) and not len(L["net"]):
        return None
    is_fin = info.get("sector") in FINANCIAL_SECTORS
    fin_why = "not meaningful for a lender"
    px = price_facts(hist)
    today = pd.Timestamp(today) if today is not None else pd.Timestamp.now()
    price = px["close"] if px else _finite(info.get("currentPrice"))
    cur = L["cur"]
    # Market value is in rupees; set against statements only when they are too.
    mcap = _finite(info.get("marketCap")) if L["fx_ok"] else float("nan")
    rev, net, eps = L["revenue"], L["net"], L["eps"]
    sales = _finite(rev.iloc[-1]) if len(rev) and L["fx_ok"] else float("nan")

    # ---- shared metrics ----------------------------------------------------
    pe = _finite(info.get("trailingPE"))
    if not _ok(pe) and len(eps) and _ok(price) and eps.iloc[-1] > 0:
        pe = price / float(eps.iloc[-1])
    if len(net) and net.iloc[-1] <= 0:
        pe = float("nan")
    ps = _finite(info.get("priceToSalesTrailing12Months"))
    if not _ok(ps) or statement_fx(info) != 1.0:      # Yahoo's is wrong for a USD filer
        ps = _div(mcap, sales)
    pb = _finite(info.get("priceToBook"))
    ttm_div = _ttm_dividends(inputs.get("dividends"), today)[0]
    div_yield = _div(ttm_div, price) if ttm_div > 0 else 0.0
    eps_growth = _cagr(eps) if not L["share_jump"] else float("nan")
    eps_years = len(eps) - 1
    eps_why = L["share_jump"] or "no earnings growth to divide by"
    lynch_peg = (_div(pe, eps_growth * 100 + div_yield * 100)
                 if _ok(pe) and _ok(eps_growth) and eps_growth + div_yield > 0 else float("nan"))
    fwd_peg = _finite(info.get("pegRatio"))
    sales_g1, sales_cagr = _yoy(rev), _cagr(rev)
    net_g1, net_cagr = _yoy(net), _cagr(net)
    fcf = L["fcf"]
    accrual = (_finite(fcf.iloc[-1]) - _finite(net.reindex(fcf.index).iloc[-1])
               if len(fcf) and len(net) else float("nan"))
    roic = roic_series(L) if not is_fin else pd.Series(dtype=float)
    fscore = piotroski(L, is_fin)
    insiders = _finite(info.get("heldPercentInsiders"))
    institutions = _finite(info.get("heldPercentInstitutions"))
    years_shown = len(rev)

    # Net payout yield (Ch. 16): dividends + buybacks - new shares, over market value.
    def last(s):
        return _finite(s.iloc[-1]) if len(s) else 0.0
    dv, bb, iss = last(L["dividends_paid"]), last(L["buybacks"]), last(L["issued"])
    npy = _div(dv + bb - iss, mcap) if _ok(mcap) and (len(L["dividends_paid"]) or len(L["buybacks"])) else float("nan")

    metrics = {"pe": pe, "ps": ps, "pb": pb, "div_yield": div_yield, "eps_growth": eps_growth,
               "eps_why": eps_why, "currency": cur,
               "lynch_peg": lynch_peg, "fwd_peg": fwd_peg, "net_payout_yield": npy,
               "accrual": accrual, "roic": float(roic.iloc[-1]) if len(roic) else float("nan"),
               "market_cap": mcap, "sales": sales, "usd_inr": USD_INR}

    def crit(label, ok, value):
        return {"label": label, "ok": ok, "value": value}

    def near_high():
        if not px:
            return crit("Within 5% of the 52-week high", None, "no daily history")
        return crit("Within 5% of the 52-week high", px["from_high"] >= -NEAR_HIGH,
                    f"{_pct(px['from_high'])} from ₹{px['high_52w']:,.2f}")

    def sales_over(usd):
        lim = _inr_of_usd(usd)
        return crit(f"Sales above {_usd(usd)} (≈{_crore(lim)})",
                    None if not _ok(sales) else sales > lim, _crore(sales))

    def volume_over():
        v = px["avg_volume"] if px else float("nan")
        return crit(f"Average daily volume above {VOLUME_MIN_SHARES:,} shares",
                    None if not _ok(v) else v > VOLUME_MIN_SHARES,
                    f"{v:,.0f} shares (3 months)" if _ok(v) else "no volume data")

    screens = []

    def screen(name, chapter, core, extra=(), note=""):
        known = [c for c in core if c["ok"] is not None]
        if not known:
            status = CANT
        elif any(c["ok"] is False for c in known):
            status = FAIL
        elif len(known) < len(core):
            status = PARTLY
        else:
            status = PASS
        screens.append({"name": name, "chapter": chapter, "status": status,
                        "icon": SCREEN_ICON[status], "criteria": list(core),
                        "refinements": list(extra), "note": note})

    # Ch. 12 Buy High, Sell Higher
    screen("Buy High, Sell Higher", "Ch. 12",
           [near_high(), sales_over(SALES_MIN_USD), volume_over()],
           [crit("One-year sales growth above 20%",
                 None if not _ok(sales_g1) else sales_g1 > SALES_GROWTH_FAST, _pct(sales_g1)),
            crit("Insiders own at least 5%", None if not _ok(insiders) else insiders >= INSIDER_MIN,
                 f"{insiders * 100:.1f}% (on NSE mostly promoters)" if _ok(insiders) else "not reported")],
           "Tested on NSE in README §53: stocks near their 52-week high did better (rank IC +0.040, "
           "t 1.89), not decisively.")

    # Ch. 13 Impatient Value: PEG on forecast growth; the trailing PEG stands in.
    peg, peg_src = (fwd_peg, "Yahoo's forward PEG") if _ok(fwd_peg) else (lynch_peg, "trailing PEG")
    screen("Impatient Value", "Ch. 13",
           [crit("PEG between 0.2 and 1.5", None if not _ok(peg) else PEG_FLOOR < peg < PEG_CEILING,
                 f"{peg:.2f} ({peg_src})" if _ok(peg) else eps_why),
            near_high(), sales_over(SALES_MIN_USD), volume_over()],
           note="The book's PEG uses analysts' five-year growth forecasts; where Yahoo has none, "
                "past EPS growth stands in.")

    # Ch. 14 Surprise, Surprise; Ch. 17 Bold Is Beautiful; Ch. 18 Rising Expectations
    for name, ch, need in (
            ("Surprise, Surprise", "Ch. 14",
             "last quarter's earnings AND sales surprise against analysts' estimates"),
            ("Bold Is Beautiful", "Ch. 17", "individual analysts' estimate revisions, week by week"),
            ("Rising Expectations", "Ch. 18", "analysts' rating upgrades and downgrades, by industry")):
        screen(name, ch, [crit("Needs " + need, None, "no free feed carries it for NSE")])

    # Ch. 15 Tomorrow's Breakthrough (R&D)
    rd = L["rd"]
    if len(rd):
        rd0 = _finite(rd.iloc[-1])
        screen("Tomorrow's Breakthrough", "Ch. 15", [
            crit("R&D at least 5% of sales", _div(rd0, sales) >= RD_SALES_MIN if _ok(_div(rd0, sales)) else None,
                 _pct(_div(rd0, sales))),
            crit("R&D at least 5% of assets",
                 _div(rd0, last(L["assets"])) >= RD_ASSETS_MIN if _ok(_div(rd0, last(L["assets"]))) else None,
                 _pct(_div(rd0, last(L["assets"])))),
            crit("R&D up on the year before", None if len(rd) < 2 else rd0 > _finite(rd.iloc[-2]),
                 f"{_money(_finite(rd.iloc[-2]), cur)} → {_money(rd0, cur)}" if len(rd) >= 2 else "one year"),
            crit("Market value under 20× R&D", None if not _ok(_div(mcap, rd0)) else _div(mcap, rd0) < PRICE_TO_RD_MAX,
                 f"{_div(mcap, rd0):.1f}×" if _ok(_div(mcap, rd0)) else "—")])
    else:
        screen("Tomorrow's Breakthrough", "Ch. 15",
               [crit("Needs research and development spending", None,
                     "not reported separately in this company's statements (common on NSE)")])

    # Ch. 16 New Dogs
    screen("New Dogs", "Ch. 16",
           [crit("Highest net payout yields in the index", None,
                 f"this company's is {_pct(npy)}; ranking it needs every index member's cash flows")
            if _ok(npy) else crit("Highest net payout yields in the index", None, "cash flow not reported")],
           note="The book's Dogs are the ten highest net payout yields among the Dow's 30; the "
                "NIFTY 50 analogue is not loaded here.")

    # Ch. 19 Follow the Leaders, from SEBI insider-trading disclosures
    import insiders as _ins
    analysts = _finite(info.get("numberOfAnalystOpinions"))
    cap10 = _inr_of_usd(10e9)
    cap_crit = crit(f"Market value under $10 billion (≈{_crore(cap10)})",
                    None if not _ok(mcap) else mcap < cap10, _crore(mcap))
    analyst_crit = crit("Six or fewer analysts in the earnings consensus",
                        None if not _ok(analysts) else analysts <= 6,
                        f"{analysts:.0f} analysts" if _ok(analysts) else "not reported")
    if insider:
        b = insider["buy"]
        span = f"disclosed {insider['from']} to {insider['to']}"
        screen("Follow the Leaders", "Ch. 19", [
            crit(f"Insider open-market purchases over $100,000 (≈₹{_ins.MIN_VALUE / 1e5:.0f} lakh)",
                 b["value"] >= _ins.MIN_VALUE, f"₹{b['value'] / 1e5:,.1f} lakh, {span}"),
            crit("At least two insider buys", b["n"] >= _ins.MIN_BUYS,
                 f"{b['n']} buys by {b['buyers']} people"),
            crit("Under 5% of the shares", b["pct"] < _ins.MAX_PCT if b["n"] else None,
                 f"{b['pct']:.2f}% of the shares" if b["n"] else "no purchases"),
            cap_crit, analyst_crit],
            [crit("An executive (key managerial personnel) among the buyers", b["executive"] if b["n"] else None,
                  ", ".join(b["kinds"]) if b["kinds"] else "no purchases"),
             crit("Several buyers, not one", b["buyers"] >= 2 if b["n"] else None, f"{b['buyers']} buyers")],
            _ins.MEASURED["leaders"])
    else:
        screen("Follow the Leaders", "Ch. 19",
               [crit("Insider purchases (SEBI disclosures)", None, "NSE's disclosures could not be read just now")])

    # Ch. 20 Accrual to Be Kind
    lo, hi = (_inr_of_usd(x) for x in ACCRUAL_CAP_USD)
    screen("Accrual to Be Kind", "Ch. 20", [
        crit("Free cash flow above net income (negative accruals)",
             None if (is_fin or not _ok(accrual)) else accrual > 0,
             fin_why if is_fin else (f"free cash flow minus profit {_money(accrual, cur)}"
                                     if _ok(accrual) else "not reported")),
        crit(f"Market value {_usd(ACCRUAL_CAP_USD[0])} to {_usd(ACCRUAL_CAP_USD[1])} (≈{_crore(lo)} to {_crore(hi)})",
             None if not _ok(mcap) else lo <= mcap <= hi, _crore(mcap)),
        crit(f"Earnings growth above 15% a year ({max(len(net) - 1, 0)} years shown; the book: three)",
             None if not _ok(net_cagr) else net_cagr > ACCRUAL_GROWTH_3Y, _pct(net_cagr)),
        crit("Last year's earnings growth above that rate",
             None if not (_ok(net_g1) and _ok(net_cagr)) else net_g1 > net_cagr, _pct(net_g1)),
        crit("P/E below the industry median", None, f"P/E {pe:.1f}; industry median not loaded" if _ok(pe) else "no P/E")])

    # Ch. 21 Sales on Sale (O'Shaughnessy's Cornerstone Growth)
    def above_market(k, label):
        if not px or not market:
            return crit(f"{label} price change above the market's", None, "market index unavailable")
        mine, theirs = px[f"r{k}"], market[f"r{k}"]
        return crit(f"{label} price change above the market's", None if not _ok(mine) else mine > theirs,
                    f"{_pct(mine)} against NIFTY 50 {_pct(theirs)}")
    screen("Sales on Sale", "Ch. 21", [
        sales_over(SALES_ON_SALE_MIN_USD), volume_over(),
        crit("Price/sales below 1.5", None if not _ok(ps) else ps < PS_MAX, f"{ps:.2f}" if _ok(ps) else "—"),
        crit("Earnings up on the year", None if not _ok(net_g1) else net_g1 > 0, _pct(net_g1)),
        above_market(63, "3-month"), above_market(126, "6-month")],
        note="The book's 'database average' is every stock in the screener; NIFTY 50 stands in.")

    # Ch. 22 Combination Platter
    fs = fscore
    screen("Combination Platter", "Ch. 22", [
        crit("Price/book in the cheapest quarter of the market", None,
             f"P/B {pb:.2f}; ranking it needs the whole market" if _ok(pb) else "P/B not available"),
        crit(f"F-score {F_SCORE_HIGH} or 9 (all nine signals)", None if fs["score"] is None
             else fs["score"] >= F_SCORE_HIGH,
             (f"{fs['score']} of {fs['scored']}" if fs["score"] is not None else fs["why"]))],
        note="Piotroski built the score on the cheapest fifth of stocks by price/book; on an "
             "expensive stock it reads as a quality score, not his strategy.")

    # Ch. 23 guru screens
    roe = _ratio_series(net, _average_balance(L["equity"]))
    roe0 = float(roe.iloc[-1]) if len(roe) else float("nan")
    op = L["op_income"]
    p_fcf = _div(mcap, last(fcf)) if len(fcf) and last(fcf) > 0 and not is_fin else float("nan")
    screen("Buffett-style", "Ch. 23", [
        crit(f"Operating profit positive every year ({len(op)} shown; the book: five or more)",
             None if not len(op) else bool((op > 0).all()),
             ", ".join(_money(_finite(v), cur) for v in op.values[-4:]) if len(op) else "not reported"),
        crit("Return on equity at least 15%", None if not _ok(roe0) else roe0 >= BUFFETT_ROE, _pct(roe0)),
        crit("Cheap against cash earnings (low price/free cash flow)", None,
             f"price/free cash flow {p_fcf:.1f}; the book sets no cut-off" if _ok(p_fcf)
             else (fin_why if is_fin else "no positive free cash flow"))])
    screen("Lynch-style", "Ch. 23", [
        crit("PEG with dividend (P/E ÷ (growth + yield)) between 0.5 and 1.0",
             None if not _ok(lynch_peg) else LYNCH_PEG[0] <= lynch_peg <= LYNCH_PEG[1],
             f"{lynch_peg:.2f} = {pe:.1f} ÷ ({eps_growth * 100:.1f} + {div_yield * 100:.1f})"
             if _ok(lynch_peg) else ("no P/E: a loss" if not _ok(pe) else eps_why)),
        crit(f"EPS growth 20-50% a year ({eps_years} years shown)",
             None if not _ok(eps_growth) else LYNCH_GROWTH[0] <= eps_growth <= LYNCH_GROWTH[1],
             _pct(eps_growth) if _ok(eps_growth) else eps_why),
        crit("Debt/capital below the industry average", None, "industry average not loaded"),
        crit("Insider buying", None, "not loaded")])
    screen("Zweig-style", "Ch. 23", [
        crit(f"Earnings growth at least 15% a year ({max(len(net) - 1, 0)} years shown)",
             None if not _ok(net_cagr) else net_cagr >= ZWEIG_GROWTH, _pct(net_cagr)),
        crit(f"Sales growth at least 15% a year ({max(len(rev) - 1, 0)} years shown)",
             None if not _ok(sales_cagr) else sales_cagr >= ZWEIG_GROWTH, _pct(sales_cagr)),
        crit("Sales growth accelerating (last year above the average)",
             None if not (_ok(sales_g1) and _ok(sales_cagr)) else sales_g1 > sales_cagr, _pct(sales_g1)),
        crit("Earnings growth accelerating", None if not (_ok(net_g1) and _ok(net_cagr)) else net_g1 > net_cagr,
             _pct(net_g1)),
        crit("P/E at least 5", None if not _ok(pe) else pe >= ZWEIG_PE_FLOOR, f"{pe:.1f}" if _ok(pe) else "no P/E"),
        crit("Each of the last four quarters up on a year earlier", None,
             "yfinance holds too few quarters")])

    survivor = _survivor_checks(L, info, px, is_fin, fin_why, metrics, roic)
    sell = _sell_signs(L, insiders, is_fin)
    return {"screens": screens, "fscore": fscore, "survivor": survivor, "sell": sell,
            "price": px, "metrics": metrics, "market": market, "is_financial": is_fin,
            "fiscal_year_end": str(rev.index[-1].date()) if len(rev) else None,
            "years_shown": years_shown,
            "insiders": insiders, "institutions": institutions}


def _survivor_checks(L, info, px, is_fin, fin_why, m, roic):
    """Ch. 24: deal breakers, then 'cheap and growing', 'strong', 'well managed'."""
    out, cur = [], L["cur"]
    # -- deal breakers: the chart --
    rule = ("Ch. 24: was there a day or two when it suddenly plummeted? Check the news. An earnings "
            "miss is no reason to discard it; fraud, delayed results, restatements or trouble paying "
            "creditors are. Flagged here at a 10% two-session fall (this project's cut-off).")
    if px and _ok(px["worst_2d"]):
        bad = px["worst_2d"] <= PLUNGE_2D
        out.append(("Deal breakers", _check(
            "Sudden plunge in the past year",
            f"worst two sessions {_pct(px['worst_2d'])} to {px['worst_2d_date']}"
            + (": read the news from then" if bad else ""), WATCH if bad else GOOD, rule)))
    rule = ("Ch. 24: if it has fallen over the past year and was still moving lower over the past "
            "week, set it aside until it stabilises, even at a higher price. " + MEASURED["falling_knife"])
    if px and _ok(px["r252"]) and _ok(px["r5"]):
        knife = px["r252"] < 0 and px["r5"] < 0
        out.append(("Deal breakers", _check(
            "Still falling after a down year",
            f"{_pct(px['r252'])} over the year, {_pct(px['r5'])} over the last 5 sessions "
            f"(down on {px['down_days_5']} of 5)", WATCH if knife else GOOD, rule)))
    rule = ("Ch. 24: a jump, then a flat line, is the chart of a company being bought out. Flagged "
            "here at a 15% one-session jump in the last three months followed by 10+ sessions "
            "within 3% of it (this project's cut-offs).")
    if px:
        b = px["buyout"]
        out.append(("Deal breakers", _check(
            "Buyout pattern",
            (f"jumped {_pct(b['jump'])} on {b['date']}, then flat for {b['sessions']} sessions: "
             "check for an offer" if b else "none in the last three months"), WATCH if b else GOOD, rule)))
    # -- debt, ownership, liquidity --
    rule = ("Ch. 24: debt under half a year's income (net income plus interest expense, so "
            "interest is not judged after it is paid). Lenders have different rules.")
    debt, net, intr = L["debt"], L["net"], L["interest"]
    if is_fin:
        out.append(("Deal breakers", _check("Debt against a year's income", fin_why, NA, rule)))
    elif len(net):
        d = _finite(debt.iloc[-1]) if len(debt) else 0.0
        inc = _finite(net.iloc[-1]) + (abs(_finite(intr.iloc[-1])) if len(intr) and _ok(_finite(intr.iloc[-1])) else 0.0)
        if inc <= 0:
            out.append(("Deal breakers", _check("Debt against a year's income",
                                                 "no income to service it" if d > 0 else "no debt, but a loss",
                                                 BAD if d > 0 else WATCH, rule)))
        else:
            yrs = d / inc
            out.append(("Deal breakers", _check(
                "Debt against a year's income",
                f"debt {_money(d, cur)} = {yrs:.2f} years of income" + (" (above the book's half-year line)"
                                                                         if yrs > DEBT_YEARS_MAX else ""),
                GOOD if yrs <= DEBT_YEARS_MAX else WATCH, rule)))
    ins, inst = _finite(info.get("heldPercentInsiders")), _finite(info.get("heldPercentInstitutions"))
    rule = ("Ch. 24: consider pitching stocks more than three-quarters owned by insiders and "
            "institutions. On NSE, yfinance's 'insiders' are mostly promoters, whom SEBI caps at "
            "75%, so this is context here, not a deal breaker.")
    if _ok(ins) or _ok(inst):
        tot = (ins if _ok(ins) else 0.0) + (inst if _ok(inst) else 0.0)
        out.append(("Deal breakers", _check(
            "Owned by insiders and institutions",
            f"{tot * 100:.0f}% (insiders and promoters {ins * 100 if _ok(ins) else 0:.0f}%, institutions "
            f"{inst * 100 if _ok(inst) else 0:.0f}%)", INFO, rule)))
    lim = _inr_of_usd(TURNOVER_MIN_USD)
    rule = (f"Ch. 24: think about disregarding stocks trading less than $1 million a day "
            f"(≈{_crore(lim)} at ₹{USD_INR:.0f}/$): institutions stay away and a big sell order moves it.")
    if px and _ok(px["median_turnover"]):
        out.append(("Deal breakers", _check(
            "Value traded each day", f"median {_crore(px['median_turnover'])} over 3 months",
            GOOD if px["median_turnover"] >= lim else WATCH, rule)))

    # -- cheap and growing --
    rev, eps = L["revenue"], L["eps"]
    sg, ng, eg = _cagr(rev), _cagr(net), m["eps_growth"]
    rule = ("Ch. 24: earnings should grow at least as fast as sales, or the company may be cutting "
            "prices to ring the register.")
    if _ok(sg) and _ok(ng):
        out.append(("Cheap and growing", _check(
            "Earnings keeping up with sales", f"earnings {_pct(ng)} a year, sales {_pct(sg)} "
            f"({len(rev) - 1} years)", GOOD if ng >= sg - GROWTH_TOLERANCE else WATCH, rule)))
    rule = ("Ch. 24: earnings per share should grow at least as fast as earnings, or shares are "
            "being issued too freely.")
    if L["share_jump"]:
        out.append(("Cheap and growing", _check("EPS keeping up with earnings", L["share_jump"], NA, rule)))
    elif _ok(eg) and _ok(ng):
        out.append(("Cheap and growing", _check(
            "EPS keeping up with earnings", f"EPS {_pct(eg)} a year, earnings {_pct(ng)}",
            GOOD if eg >= ng - GROWTH_TOLERANCE else WATCH, rule)))
    rule = ("Ch. 24: look into any year earnings were negative or sharply lower (a big-bath "
            "charge is a sign of past failures). 'Sharply' is a fall of a quarter here (this "
            "project's cut-off).")
    if len(net) >= 2:
        bad_years = [f"FY{q.year}" for q, prev in zip(net.index[1:], net.values[:-1])
                     if net[q] <= 0 or (prev > 0 and net[q] / prev - 1.0 <= -EARNINGS_DROP)]
        bad_years = ([f"FY{net.index[0].year}"] if net.iloc[0] <= 0 else []) + bad_years
        out.append(("Cheap and growing", _check(
            "Loss or sharp fall in any year shown",
            ("in " + ", ".join(bad_years) + ": look into what happened") if bad_years else
            f"none in {len(net)} years", WATCH if bad_years else GOOD, rule)))
    rule = ("Ch. 24: think carefully about a P/E more than 1.5 times the long-term growth rate (PEG "
            "above 1.5). Here the growth is the past EPS growth, which the book says to prefer "
            "when forecasts look too rosy.")
    if _ok(m["pe"]) and _ok(m["eps_growth"]):
        peg = _div(m["pe"], m["eps_growth"] * 100) if m["eps_growth"] > 0 else float("nan")
        out.append(("Cheap and growing", _check(
            "P/E against growth (PEG)",
            f"{peg:.2f} = P/E {m['pe']:.1f} ÷ {m['eps_growth'] * 100:.1f}% EPS growth" if _ok(peg)
            else f"P/E {m['pe']:.1f} with EPS shrinking: no PEG",
            GOOD if _ok(peg) and peg <= PEG_CEILING else WATCH, rule)))
    elif L["share_jump"]:
        out.append(("Cheap and growing", _check("P/E against growth (PEG)", L["share_jump"], NA, rule)))

    # -- strong --
    cfo, cfi, cff = L["cfo"], L["cfi"], L["cff"]
    rule = ("Ch. 24: operating plus investing cash flow that consistently falls short of net income "
            "is a company living on accounting rules, not cash.")
    common = cfo.index.intersection(cfi.index).intersection(net.index)
    if is_fin:
        out.append(("Strong", _check("Cash flow against profit", fin_why, NA, rule)))
    elif len(common) >= 3:
        short = [q for q in common if cfo[q] + cfi[q] < net[q]]
        out.append(("Strong", _check(
            "Cash flow against profit", f"operating + investing below net income in {len(short)} of "
            f"{len(common)} years", WATCH if len(short) == len(common) else GOOD, rule)))
    rule = ("Ch. 24: financing cash flow positive year after year may mean the company leans on "
            "borrowing and new shares to fund itself.")
    if is_fin:
        out.append(("Strong", _check("Financing cash flow", fin_why, NA, rule)))
    elif len(cff) >= 3:
        pos = int((cff > 0).sum())
        out.append(("Strong", _check(
            "Financing cash flow", f"positive in {pos} of {len(cff)} years",
            WATCH if pos == len(cff) else GOOD, rule)))
    rule = ("Ch. 24 / Ch. 22: Piotroski's nine signals of improving profitability, strength and "
            "efficiency; his winners scored 8 or 9.")
    fs = piotroski(L, is_fin)
    out.append(("Strong", _check(
        "Piotroski F-score", f"{fs['score']} of {fs['scored']} (FY{fs['year'][:4]})" if fs["score"] is not None
        else fs["why"], NA if fs["score"] is None else (GOOD if fs["score"] >= F_SCORE_HIGH else
                                                       (WATCH if fs["score"] >= 5 else BAD)), rule)))

    # -- well managed --
    rule = ("Ch. 24: return on invested capital = operating profit after tax (at least 25%) ÷ "
            "(total assets − non-debt current liabilities), averaged over the year. 15% or more "
            "is a good sign, and a high, stable ROIC one of the best.")
    if is_fin:
        out.append(("Well managed", _check("Return on invested capital", fin_why, NA, rule)))
    elif len(roic):
        path = " → ".join(f"{v * 100:.1f}%" for v in roic.iloc[-3:])
        falling = len(roic) >= 3 and bool((roic.iloc[-3:].diff().dropna() < 0).all())
        v = float(roic.iloc[-1])
        out.append(("Well managed", _check(
            "Return on invested capital", path + (" (falling two years running)" if falling else ""),
            BAD if v < 0 else (GOOD if v >= ROIC_GOOD and not falling else WATCH), rule)))
    rule = ("Ch. 20 (Sloan): free cash flow minus net income. Positive means part of the earnings "
            "is hidden; negative means paper profits ahead of cash, which predicted poor returns.")
    if is_fin:
        out.append(("Well managed", _check("Accruals", fin_why, NA, rule)))
    elif _ok(m["accrual"]):
        assets = L["assets"]
        scale = _div(m["accrual"], _finite(assets.iloc[-1])) if len(assets) else float("nan")
        out.append(("Well managed", _check(
            "Accruals", f"free cash flow minus profit {_money(m['accrual'], cur)}"
            + (f" ({_pct(scale)} of assets)" if _ok(scale) else ""), GOOD if m["accrual"] > 0 else WATCH, rule)))
    rule = ("Ch. 16 (Boudoukh et al.): dividends plus buybacks minus new shares, over market value. "
            "High net payout yields beat the market by five points a year in their US study. "
            "Context: the book ranks it, it sets no level.")
    if _ok(m["net_payout_yield"]):
        dv, bb, iss = (_finite(L[k].iloc[-1]) if len(L[k]) else 0.0 for k in ("dividends_paid", "buybacks", "issued"))
        mc = m["market_cap"]
        out.append(("Well managed", _check(
            "Net payout yield", f"{_pct(m['net_payout_yield'])} (dividends {_pct(_div(dv, mc))}, buybacks "
            f"{_pct(_div(bb, mc))}, new shares {_pct(-_div(iss, mc) if iss else 0.0)})", INFO, rule)))
    return out


def _sell_signs(L, insiders, is_fin):
    """Ch. 25: the signs to rethink holding a growth or a value stock."""
    out = []
    rule = ("Ch. 25: one-time accounting charges that, contrary to the name, turn up every period. "
            "Flagged when unusual items reduced profit in three or more of the years shown.")
    u = L["unusual"]
    if len(u):
        hits = int((u < 0).sum())
        out.append(_check("Recurring one-time charges", f"charges in {hits} of {len(u)} years",
                          WATCH if hits >= 3 else GOOD, rule))
    rule = ("Ch. 25: a management team that does not own many shares and regularly issues new ones. "
            "Flagged when the share count rose every year shown and insiders hold under 10% "
            "(this project's cut-off).")
    sh = L["shares"]
    if len(sh) >= 3:
        rising = bool((sh.diff().dropna() > 0).all())
        low_own = _ok(insiders) and insiders < ISSUER_INSIDERS_MAX
        out.append(_check(
            "Regular share issuance",
            f"shares {sh.iloc[0] / 1e7:,.1f} cr → {sh.iloc[-1] / 1e7:,.1f} cr"
            + (f"; insiders and promoters {insiders * 100:.0f}%" if _ok(insiders) else ""),
            WATCH if rising and low_own else (INFO if rising else GOOD), rule))
    rule = ("Ch. 25: a cash build-up with no word on how it will be spent (Ch. 6: companies "
            "with too much cash tend to underperform). Context: read what management says.")
    cash, assets = L["cash"], L["assets"]
    share = _ratio_series(cash, assets)
    if len(share) >= 2 and not is_fin:
        out.append(_check("Cash share of assets",
                          " → ".join(f"{v * 100:.0f}%" for v in share.iloc[-3:]), INFO, rule))
    return out


def company_screens(ticker, hist=None, market_close=None, fetch_fn=None):
    """The live screens for one ticker, or None on any failure (advisory)."""
    try:
        import stock_checklist as sc
        inputs = (fetch_fn or sc.fetch_inputs)(ticker)
        return build_screens(inputs, hist=hist, market=market_returns(market_close))
    except Exception:
        return None
