"""
Economic (investment-strategy) evaluation of a forecast.

Motivated by *Hands-On Deep Learning for Finance* (Troiano et al.), Chapter 3,
"Evaluating investment strategy" — the section that lists the metrics a
practitioner actually judges a model by: **cumulative and monthly returns, the
information coefficient, the information ratio and Sharpe ratio, maximum
drawdown, and the Sortino ratio**.

Why this module exists
----------------------
Everything in ``backtest.py`` is a *statistical* score: RMSE, MAE, SMAPE, MASE,
directional accuracy, interval coverage, Diebold-Mariano. Those answer "is the
number close?" — they never answer the only question a user of a forecast
actually has: **"would acting on this have made or lost money, after costs?"**

The distinction matters and is not cosmetic:

* A model can win on RMSE and lose money, because RMSE is dominated by the
  *magnitude* of quiet periods while P&L is dominated by the *sign* on the few
  large moves.
* A model can lose on RMSE and make money, because a small, persistent
  directional tilt is invisible to a squared-error metric.
* Trading costs turn a marginal statistical edge into a negative one. A forecast
  with 52% directional accuracy at a 5-day horizon is worthless once you pay
  ~10 bps per round trip; nothing in the statistical metric set reveals that.

So this module converts a sequence of *forecasts and realisations* into a
strategy return stream and scores it the way the book does. It is deliberately
**pure** (numpy / pandas only, no I/O, no modelling backend), so the walk-forward
harness, the calibration harness and the tests can all use it.

Reading the numbers honestly
----------------------------
This project's own walk-forward evidence (README "Empirical findings") is that
**no model has a data-snooping-robust edge over the random walk** at these
horizons — White's Reality Check p = 0.90, Hansen's SPA p = 0.87. The expected
result from this module is therefore a **Sharpe near zero, negative after
costs**. That is not a bug in the metrics; it is the metrics doing their job, and
it is exactly why the app's value sits in calibrated uncertainty rather than in a
directional call. A Sharpe that looks good here should be treated as a red flag
to check for leakage or origin overlap before it is treated as a discovery.
"""

import math as _math

import numpy as np
import pandas as pd

# Bars per year, used to annualise. NSE trades ~252 sessions; yfinance returns 7
# hourly bars per session (09:15-15:30), matching model_utils.NSE_BARS_PER_SESSION.
SESSIONS_PER_YEAR = 252
BARS_PER_SESSION = 7
PERIODS_PER_YEAR = {'daily': SESSIONS_PER_YEAR,
                    'hourly': SESSIONS_PER_YEAR * BARS_PER_SESSION}

# Default one-way transaction cost in basis points. 10 bps is a deliberately
# gentle retail-ish assumption for a liquid NSE large cap (brokerage + STT +
# exchange fees + a slice of spread/impact); raise it to stress a strategy.
DEFAULT_COST_BPS = 10.0

#: Statutory charges on NSE, as fractions of traded value, per segment, as a
#: dated history: each entry applies from its date until the next. A backtest
#: should be charged the rate in force at the time, not today's.
#:
#: - Futures STT (sell side): 0.01% until 31 Mar 2023; 0.0125% from 1 Apr 2023
#:   (Finance Act 2023); 0.02% from 1 Oct 2024; 0.05% from 1 Apr 2026
#:   (Budget 2026). Delivery and intraday STT are unchanged throughout.
#: - NSE transaction fees: cash 0.00322% and futures 0.00188% until 30 Sep
#:   2024; 0.00297% and 0.00173% from 1 Oct 2024.
#: - Stamp duty (buy side, uniform nationally since 1 Jul 2020): delivery
#:   0.015%, intraday 0.003%, futures 0.002%. Before July 2020 it varied by
#:   state; the uniform rates are used for earlier dates.
#: - SEBI turnover fee ~0.0001% per side; GST 18% on brokerage plus exchange
#:   and SEBI fees. Brokerage is the broker's choice and a separate argument.
#:
#: STT and stamp dominate and are statutory. Rates verified against broker and
#: exchange notices in October 2026; re-verify after any budget.
INDIA_CHARGES_HISTORY = [
    ("2018-01-01", {
        'delivery': {'stt_buy': 0.001, 'stt_sell': 0.001, 'stamp_buy': 0.00015,
                     'exchange': 0.0000322, 'sebi': 0.000001},
        'intraday': {'stt_buy': 0.0, 'stt_sell': 0.00025, 'stamp_buy': 0.00003,
                     'exchange': 0.0000322, 'sebi': 0.000001},
        'futures':  {'stt_buy': 0.0, 'stt_sell': 0.0001, 'stamp_buy': 0.00002,
                     'exchange': 0.0000188, 'sebi': 0.000001}}),
    ("2023-04-01", {'futures': {'stt_sell': 0.000125}}),
    ("2024-10-01", {'delivery': {'exchange': 0.0000297},
                    'intraday': {'exchange': 0.0000297},
                    'futures': {'stt_sell': 0.0002, 'exchange': 0.0000173}}),
    ("2026-04-01", {'futures': {'stt_sell': 0.0005}}),
]
GST_RATE = 0.18


def india_charges(as_of=None):
    """The charge schedule in force on ``as_of`` (default: the latest)."""
    sched = {}
    when = pd.Timestamp(as_of) if as_of is not None else None
    for k, (start, change) in enumerate(INDIA_CHARGES_HISTORY):
        # The first entry is the base schedule and applies to every earlier
        # date too; only later revisions are gated by date.
        if k > 0 and when is not None and pd.Timestamp(start) > when:
            break
        for seg, rates in change.items():
            sched.setdefault(seg, {}).update(rates)
    return sched


#: The schedule in force today.
INDIA_CHARGES = india_charges()


def india_round_trip_bps(segment='delivery', brokerage_bps_per_side=0.0,
                         rates=None, as_of=None):
    """
    Itemised statutory cost of one Indian round trip (buy, then sell), in bp.

    Every cost verdict in this project had rested on one assumed number
    ("~20 bp of STT"). Kanwar & Gupta, *Python for Trading on Technical*,
    "Cost of Trade", itemise the charges and make the point that matters:
    delivery equity carries STT on both sides, so it costs several times what
    the same position costs through single-stock futures. A delivery round
    trip is about 22.2 bp throughout; a futures round trip was ~1.7 bp before
    April 2023, ~2.6 bp from October 2024 and ~5.6 bp from April 2026; an
    intraday one about 3.5 bp. All before brokerage, spread and impact.

    Parameters
    ----------
    segment : {'delivery', 'intraday', 'futures'}
    brokerage_bps_per_side : float, optional
        Broker commission per side, in bp. Zero for most discount brokers on
        delivery; GST applies to it.
    rates : dict, optional
        A custom schedule with the same keys as one segment of
        :func:`india_charges`, overriding the dated history.
    as_of : datetime-like, optional
        Use the schedule in force on this date (see
        :data:`INDIA_CHARGES_HISTORY`); default the latest.

    Returns
    -------
    dict
        Each component in bp, and ``'total'``. Spread, impact and depository
        (DP) charges are not included: the first two depend on size and
        liquidity, and DP is a fixed fee per scrip per sell day.
    """
    if rates is None:
        sched = india_charges(as_of)
        if segment not in sched:
            raise ValueError(f"segment must be one of {sorted(sched)}")
        rates = sched[segment]
    bp = 1e4
    stt = (rates['stt_buy'] + rates['stt_sell']) * bp
    stamp = rates['stamp_buy'] * bp
    exchange = 2.0 * rates['exchange'] * bp
    sebi = 2.0 * rates['sebi'] * bp
    brokerage = 2.0 * float(brokerage_bps_per_side)
    gst = GST_RATE * (brokerage + exchange + sebi)
    return {'stt': stt, 'stamp': stamp, 'exchange': exchange, 'sebi': sebi,
            'brokerage': brokerage, 'gst': gst,
            'total': stt + stamp + exchange + sebi + brokerage + gst}

_EPS = 1e-12


# ==========================================
# Forecast -> return conversion
# ==========================================
def forecast_log_returns(anchor, predicted_prices):
    """
    Convert a predicted price path into predicted **cumulative log returns**.

    The anchor is the last observed price at the forecast origin, so step ``h``
    of the result is ``log(pred[h] / anchor)`` — the model's claim about the
    total move from the origin to ``h``. Working in cumulative-return space (not
    price space) makes the numbers scale-free and directly comparable to the
    realised move, which is what every metric below consumes.

    Parameters
    ----------
    anchor : float
        Last observed price immediately before the forecast.
    predicted_prices : array-like
        Predicted price path over the horizon.

    Returns
    -------
    np.ndarray
        Cumulative predicted log returns, one per horizon step.
    """
    p = np.asarray(predicted_prices, dtype=np.float64)
    a = float(anchor)
    if a <= 0:
        return np.full(len(p), np.nan)
    with np.errstate(divide='ignore', invalid='ignore'):
        out = np.log(np.where(p > 0, p, np.nan) / a)
    return out


def realized_log_returns(anchor, actual_prices):
    """
    Realised cumulative log returns of the same shape as the forecast.

    Mirror of :func:`forecast_log_returns` on the realised path, so the two
    arrays are aligned step-for-step and can be compared or multiplied.
    """
    return forecast_log_returns(anchor, actual_prices)


# ==========================================
# Signal construction
# ==========================================
def position_from_signal(pred_ret, mode='sign', deadband=0.0, max_leverage=1.0,
                         scale=None):
    """
    Map a predicted return into a position in [-max_leverage, +max_leverage].

    Three modes, deliberately simple so the metric reflects the *forecast* rather
    than a clever overlay:

    * ``'sign'`` — long if the forecast is up, short if down (the classic
      directional read; what "directional accuracy" implies you would do).
    * ``'deadband'`` — as ``'sign'`` but flat unless ``|pred_ret| > deadband``.
      This is the economic analogue of the app's abstention gate: no trade unless
      the claimed move is big enough to be worth the cost.
    * ``'scaled'`` — position proportional to ``pred_ret / scale``, clipped.
      Rewards a model whose *magnitude* is informative, not just its sign.

    Parameters
    ----------
    pred_ret : array-like
        Predicted (cumulative) log returns.
    mode : {'sign', 'deadband', 'scaled'}, optional
        Position rule. Default 'sign'.
    deadband : float, optional
        Minimum |predicted return| to take a position (``'deadband'`` mode).
        Expressed in log-return units, e.g. 0.005 = 0.5%.
    max_leverage : float, optional
        Absolute position cap. Default 1.0 (fully invested, no leverage).
    scale : float, optional
        Denominator for ``'scaled'`` mode; defaults to the standard deviation of
        ``pred_ret`` so the positions are self-normalising.

    Returns
    -------
    np.ndarray
        Positions aligned with ``pred_ret`` (NaN forecasts -> flat).
    """
    r = np.asarray(pred_ret, dtype=np.float64)
    r = np.where(np.isfinite(r), r, 0.0)

    if mode == 'scaled':
        s = float(scale) if scale else float(np.std(r))
        if s <= _EPS:
            return np.zeros_like(r)
        return np.clip(r / s, -max_leverage, max_leverage)

    pos = np.sign(r) * max_leverage
    if mode == 'deadband' and deadband > 0:
        pos = np.where(np.abs(r) > deadband, pos, 0.0)
    return pos


# ==========================================
# Core strategy statistics (book Ch. 3)
# ==========================================
def cumulative_returns(period_returns):
    """
    Compound a stream of simple period returns into an equity curve.

    Returns the curve **including the starting point 1.0**, so the array has
    ``len(period_returns) + 1`` elements and drawdowns measured on it are
    well-defined from the first period.
    """
    r = np.asarray(period_returns, dtype=np.float64)
    r = np.where(np.isfinite(r), r, 0.0)
    return np.concatenate([[1.0], np.cumprod(1.0 + r)])


def total_return(period_returns):
    """Total compounded return over the whole sample (0.10 = +10%)."""
    curve = cumulative_returns(period_returns)
    return float(curve[-1] - 1.0)


def annualized_return(period_returns, periods_per_year):
    """
    Geometric annualised return (CAGR) of the period-return stream.

    Uses the compounded total over the realised number of periods, so it is
    comparable across samples of different length.
    """
    r = np.asarray(period_returns, dtype=np.float64)
    n = len(r)
    if n == 0:
        return float('nan')
    growth = cumulative_returns(r)[-1]
    if growth <= 0:
        return -1.0
    return float(growth ** (periods_per_year / n) - 1.0)


def annualized_volatility(period_returns, periods_per_year):
    """Annualised standard deviation of the period returns (sqrt-time scaling)."""
    r = np.asarray(period_returns, dtype=np.float64)
    if len(r) < 2:
        return float('nan')
    return float(np.std(r, ddof=1) * np.sqrt(periods_per_year))


def sharpe_ratio(period_returns, periods_per_year, risk_free_annual=0.0):
    """
    Annualised Sharpe ratio: excess return per unit of total volatility.

    The risk-free rate is de-annualised to the bar frequency before subtraction,
    so the ratio is correct for both daily and hourly streams. Returns NaN when
    the sample is too short or has no dispersion (a constant stream has no
    meaningful Sharpe, and dividing by ~0 would manufacture a huge number).

    Parameters
    ----------
    period_returns : array-like
        Simple (not log) returns per bar.
    periods_per_year : int
        Bars per year (see :data:`PERIODS_PER_YEAR`).
    risk_free_annual : float, optional
        Annual risk-free rate as a fraction (0.06 = 6%). Default 0.
    """
    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r)]
    if len(r) < 2:
        return float('nan')
    rf_bar = (1.0 + risk_free_annual) ** (1.0 / periods_per_year) - 1.0
    excess = r - rf_bar
    sd = float(np.std(excess, ddof=1))
    if sd <= _EPS:
        return float('nan')
    return float(np.mean(excess) / sd * np.sqrt(periods_per_year))


def sharpe_standard_error(sharpe, n_periods, periods_per_year):
    """
    Approximate standard error of an **annualised** Sharpe estimate.

    Essential context, not a nicety: a Sharpe computed from a handful of
    non-overlapping trades has an enormous sampling error, and quoting the point
    estimate alone invites reading noise as skill. Under i.i.d. returns the
    per-period estimator has ``SE ~ sqrt((1 + SR_p^2 / 2) / n)`` (Lo, 2002), and
    annualising multiplies by ``sqrt(periods_per_year)`` — the same factor
    applied to the Sharpe itself, so the *ratio* of estimate to standard error
    is unchanged but the displayed magnitudes stay comparable.

    The practical consequence: at 8 trades a year of weekly rebalancing, the
    annualised SE is around 2.5, so **any |Sharpe| below ~5 is inside two
    standard errors of zero**. Forgetting the annualisation factor here (using a
    bare ``1/sqrt(n)``) understates the error by ``sqrt(periods_per_year)`` and
    makes noise look like a discovery.

    Parameters
    ----------
    sharpe : float
        The annualised Sharpe estimate.
    n_periods : int
        Number of (ideally non-overlapping) return observations.
    periods_per_year : float
        Effective observation frequency used to annualise.

    Returns
    -------
    float
        Approximate standard error on the same (annualised) scale; NaN if the
        sample is too small.
    """
    if n_periods is None or n_periods < 2 or not np.isfinite(periods_per_year):
        return float('nan')
    sr_period = (sharpe / np.sqrt(periods_per_year)
                 if np.isfinite(sharpe) else 0.0)
    se_period = np.sqrt((1.0 + 0.5 * sr_period ** 2) / n_periods)
    return float(se_period * np.sqrt(periods_per_year))


def _norm_cdf(x):
    """Standard-normal CDF from ``math.erf`` -- stdlib, no SciPy."""
    return 0.5 * (1.0 + _math.erf(float(x) / _math.sqrt(2.0)))


def _norm_ppf(p):
    """
    Inverse standard-normal CDF (Acklam's rational approximation).

    Written out rather than imported because this project has **no SciPy
    dependency** -- the same reason ``feature_drift`` carries a closed-form
    Kolmogorov distribution. Accurate to better than 1e-9 in the central region,
    refined by one Halley step against :func:`_norm_cdf`, which is far more
    precision than a Sharpe threshold needs.
    """
    if not 0.0 < p < 1.0:
        return float('nan')
    a = (-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00)
    p_low, p_high = 0.02425, 1.0 - 0.02425
    if p < p_low:
        q = _math.sqrt(-2.0 * _math.log(p))
        x = ((((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
             / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0))
    elif p > p_high:
        q = _math.sqrt(-2.0 * _math.log(1.0 - p))
        x = -((((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
              / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0))
    else:
        q, r = p - 0.5, (p - 0.5) ** 2
        x = ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
             / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0))
    # One Halley refinement.
    e = _norm_cdf(x) - p
    u = e * _math.sqrt(2.0 * _math.pi) * _math.exp(x * x / 2.0)
    return float(x - u / (1.0 + x * u / 2.0))


def probabilistic_sharpe_ratio(period_returns, benchmark_sr=0.0,
                               periods_per_year=None):
    """
    Probabilistic Sharpe Ratio (Bailey & López de Prado 2012; AFML §14.7.2).

    The probability that a strategy's **true** Sharpe exceeds ``benchmark_sr``,
    given the observed Sharpe, the track-record length, and the **shape** of the
    return distribution:

    .. math::
        \\widehat{PSR}(SR^*) = Z\\left[\\frac{(\\hat{SR}-SR^*)\\sqrt{T-1}}
        {\\sqrt{1-\\gamma_3\\hat{SR}+\\frac{\\gamma_4-1}{4}\\hat{SR}^2}}\\right]

    What it adds over :func:`sharpe_standard_error`
    ------------------------------------------------
    That function assumes i.i.d. **Gaussian** returns. PSR keeps the track-record
    length and adds the two ways real strategy returns break that assumption:
    **negative skew** and **fat tails** both inflate a naive Sharpe. A strategy
    that earns steadily and loses catastrophically -- the classic
    short-volatility profile -- posts a flattering Sharpe that PSR discounts.

    Note the denominator: ``gamma_3`` enters with a **negative** sign, so
    *negative* skew makes it larger and the probability smaller. That is the
    whole point.

    Parameters
    ----------
    period_returns : array-like
        Simple returns per bar.
    benchmark_sr : float, optional
        The Sharpe to beat. **Per period**, not annualised, unless
        ``periods_per_year`` is given -- in which case it is de-annualised for
        you. Default 0.
    periods_per_year : float, optional
        Supply to interpret ``benchmark_sr`` on an annual scale.

    Returns
    -------
    float
        A probability in [0, 1]; NaN on a sample too short or degenerate.
    """
    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r)]
    n = len(r)
    if n < 4:
        return float('nan')
    sd = float(np.std(r, ddof=1))
    if sd <= _EPS:
        return float('nan')
    sr = float(np.mean(r)) / sd                      # per period
    sr_star = float(benchmark_sr)
    if periods_per_year:
        sr_star = sr_star / _math.sqrt(float(periods_per_year))

    z = (r - np.mean(r)) / sd
    skew = float(np.mean(z ** 3))
    kurt = float(np.mean(z ** 4))                    # non-excess: 3 for Gaussian

    denom_sq = 1.0 - skew * sr + 0.25 * (kurt - 1.0) * sr ** 2
    if denom_sq <= _EPS:
        return float('nan')
    stat = (sr - sr_star) * _math.sqrt(n - 1) / _math.sqrt(denom_sq)
    return float(_norm_cdf(stat))


def expected_max_sharpe(sharpe_variance, n_trials):
    """
    The Sharpe you should expect from the **best of N trials on pure noise**.

    From Bailey & López de Prado (2014), AFML §14.7.3:

    .. math::
        SR^*_0 = \\sqrt{V[SR_n]}\\left[(1-\\gamma)Z^{-1}\\!\\left(1-\\frac{1}{N}\\right)
        + \\gamma Z^{-1}\\!\\left(1-\\frac{1}{Ne}\\right)\\right]

    with :math:`\\gamma` the Euler-Mascheroni constant. This is the number that
    makes multiple testing concrete: run enough strategies with **zero** skill
    and the best one still posts a respectable Sharpe, purely from the maximum
    of N draws.

    Parameters
    ----------
    sharpe_variance : float
        Variance of the **per-period** Sharpe estimates across the trials.
    n_trials : int
        Number of (effectively independent) trials.

    Returns
    -------
    float
        The expected maximum per-period Sharpe under the null.
    """
    if (not np.isfinite(sharpe_variance) or sharpe_variance < 0
            or n_trials is None or n_trials < 2):
        return float('nan')
    gamma = 0.5772156649015329          # Euler-Mascheroni
    n = float(n_trials)
    term = ((1.0 - gamma) * _norm_ppf(1.0 - 1.0 / n)
            + gamma * _norm_ppf(1.0 - 1.0 / (n * _math.e)))
    return float(_math.sqrt(sharpe_variance) * term)


def deflated_sharpe_ratio(period_returns, all_trial_sharpes,
                          periods_per_year=None):
    """
    Deflated Sharpe Ratio (Bailey & López de Prado 2014; AFML §14.7.3).

    A :func:`probabilistic_sharpe_ratio` whose benchmark is not chosen but
    **derived from how many strategies were tried**. The threshold is
    :func:`expected_max_sharpe` -- the Sharpe the best of ``N`` worthless trials
    would be expected to reach -- so DSR answers the question a bare Sharpe
    cannot: *is this better than the best thing noise would have handed me?*

    Why this project needs it
    -------------------------
    The existing SPA / Reality Check machinery already corrects for selection
    bias across a model set. DSR is complementary rather than redundant on two
    counts: it uses the **trial count and the dispersion of their Sharpes**
    explicitly, and it carries PSR's **skew and kurtosis** correction, which SPA
    does not. A strategy can clear SPA and still fail DSR if its returns are
    badly skewed or its peer trials were tightly clustered.

    Parameters
    ----------
    period_returns : array-like
        The selected strategy's per-bar simple returns.
    all_trial_sharpes : array-like
        **Per-period** Sharpe of every trial run, the winner included. Passing
        annualised figures here silently inflates the threshold -- the variance
        scales with ``periods_per_year`` -- so they are de-annualised for you
        when ``periods_per_year`` is supplied.
    periods_per_year : float, optional
        If given, ``all_trial_sharpes`` are treated as annualised and converted.

    Returns
    -------
    dict
        ``{'dsr', 'psr_vs_zero', 'sr_star', 'n_trials', 'observed_sr',
        'skew', 'kurtosis', 'n_obs'}``. ``dsr`` is a probability; a value below
        ~0.95 means the result is **not** distinguishable from the best of N
        lucky draws.
    """
    s = np.asarray(all_trial_sharpes, dtype=np.float64)
    s = s[np.isfinite(s)]
    if periods_per_year:
        s = s / _math.sqrt(float(periods_per_year))
    n_trials = len(s)

    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r)]
    out = {"dsr": float('nan'), "psr_vs_zero": float('nan'),
           "sr_star": float('nan'), "n_trials": int(n_trials),
           "observed_sr": float('nan'), "skew": float('nan'),
           "kurtosis": float('nan'), "n_obs": int(len(r))}
    if len(r) < 4 or n_trials < 2:
        return out

    sd = float(np.std(r, ddof=1))
    if sd <= _EPS:
        return out
    z = (r - np.mean(r)) / sd
    out["observed_sr"] = float(np.mean(r)) / sd
    out["skew"] = float(np.mean(z ** 3))
    out["kurtosis"] = float(np.mean(z ** 4))
    out["psr_vs_zero"] = probabilistic_sharpe_ratio(r, 0.0)

    sr_star = expected_max_sharpe(float(np.var(s, ddof=1)), n_trials)
    out["sr_star"] = sr_star
    if np.isfinite(sr_star):
        out["dsr"] = probabilistic_sharpe_ratio(r, sr_star)
    return out


def probability_of_backtest_overfitting(returns_matrix, n_blocks=16):
    """
    Probability of Backtest Overfitting by CSCV (Bailey, Borwein, López de
    Prado & Zhu 2017, "The Probability of Backtest Overfitting").

    The question a parameter sweep raises and a single backtest cannot answer:
    **if I pick the configuration that did best in-sample, how often does it
    turn out below average out-of-sample?** Hilpisch, *Python for Algorithmic
    Trading*, Ch. 4, brute-forces 500 SMA pairs for the best in-sample gross
    performance and cites this paper as the reason not to trust the result;
    this is the paper's test.

    Combinatorially symmetric cross-validation: cut the T periods into
    ``n_blocks`` contiguous blocks (contiguous, so serial dependence stays
    inside a block), and for each of the C(S, S/2) ways to choose half of them
    as in-sample:

    1. find the configuration with the best in-sample Sharpe;
    2. find its relative rank ``w`` among all configurations out-of-sample;
    3. record the logit ``ln(w / (1 - w))``.

    PBO is the share of splits whose logit is <= 0: the in-sample winner landed
    at or below the out-of-sample median. With no skill anywhere, PBO is about
    0.5; a genuinely better configuration drives it toward 0; selection that
    picks noise which then reverses pushes it above 0.5.

    Parameters
    ----------
    returns_matrix : array-like, shape (T, N)
        Per-period returns of N configurations over the same T periods.
    n_blocks : int, optional
        S, even. Default 16, the paper's choice (12,870 splits).

    Returns
    -------
    dict
        ``{'pbo', 'n_splits', 'n_configs', 'logits', 'is_sr_best',
        'oos_sr_best', 'prob_oos_loss', 'median_oos_rank'}``.
        ``prob_oos_loss`` is the share of splits where the in-sample winner
        had a negative out-of-sample Sharpe.

    The paper also regresses the winner's out-of-sample Sharpe on its
    in-sample Sharpe ("performance degradation"). That slope is deliberately
    not returned: the two halves are complementary, so when the same
    configuration wins every split, a better in-sample half mechanically
    means a worse out-of-sample one, and the slope is negative even for a
    genuine edge. It cannot distinguish skill from overfitting; PBO can.
    """
    from itertools import combinations

    R = np.asarray(returns_matrix, dtype=np.float64)
    if R.ndim != 2:
        raise ValueError("returns_matrix must be 2-D (periods x configurations)")
    S = int(n_blocks)
    if S < 2 or S % 2:
        raise ValueError("n_blocks must be an even integer >= 2")
    T, N = R.shape
    nan = {'pbo': float('nan'), 'n_splits': 0, 'n_configs': int(N),
           'logits': np.array([]), 'is_sr_best': np.array([]),
           'oos_sr_best': np.array([]), 'prob_oos_loss': float('nan'),
           'median_oos_rank': float('nan')}
    if N < 2 or T < 2 * S:
        return nan
    R = np.where(np.isfinite(R), R, 0.0)

    # Per-block sufficient statistics, so every split is a matrix product.
    edges = np.linspace(0, T, S + 1).astype(int)
    cnt = np.diff(edges).astype(np.float64)
    s1 = np.array([R[a:b].sum(axis=0) for a, b in zip(edges[:-1], edges[1:])])
    s2 = np.array([(R[a:b] ** 2).sum(axis=0) for a, b in zip(edges[:-1], edges[1:])])

    combos = list(combinations(range(S), S // 2))
    M = np.zeros((len(combos), S))
    for i, c in enumerate(combos):
        M[i, list(c)] = 1.0

    def _sharpe(mask):
        n = mask @ cnt
        m1 = (mask @ s1) / n[:, None]
        var = (mask @ s2) / n[:, None] - m1 ** 2
        var *= (n / np.maximum(n - 1.0, 1.0))[:, None]
        sd = np.sqrt(np.maximum(var, 0.0))
        with np.errstate(divide='ignore', invalid='ignore'):
            return np.where(sd > _EPS, m1 / sd, 0.0)

    sr_is, sr_oos = _sharpe(M), _sharpe(1.0 - M)
    best = np.argmax(sr_is, axis=1)
    rows = np.arange(len(combos))
    oos_best = sr_oos[rows, best]
    # Relative rank in (0, 1): ties split evenly, so a constant column is mid-rank.
    below = (sr_oos < oos_best[:, None]).sum(axis=1)
    ties = (sr_oos == oos_best[:, None]).sum(axis=1)
    w = (below + 0.5 * (ties + 1.0)) / (N + 1.0)
    logits = np.log(w / (1.0 - w))

    return {'pbo': float(np.mean(logits <= 0.0)), 'n_splits': int(len(combos)),
            'n_configs': int(N), 'logits': logits,
            'is_sr_best': sr_is[rows, best], 'oos_sr_best': oos_best,
            'prob_oos_loss': float(np.mean(oos_best < 0.0)),
            'median_oos_rank': float(np.median(w))}


def sortino_ratio(period_returns, periods_per_year, target_annual=0.0):
    """
    Annualised Sortino ratio: excess return per unit of **downside** deviation.

    Sharpe punishes upside and downside dispersion equally, which is the wrong
    penalty for an asymmetric return distribution — a strategy with big positive
    outliers is not risky in the way an investor means. Sortino replaces the
    denominator with the root-mean-square of returns *below* the target
    (Sortino & van der Meer), so only the losses count. This is the same
    "downside matters more" logic the HAR-RV semivariance work applies to the
    volatility cone.

    Returns NaN when there are no downside observations (an infinite ratio is
    not a useful number to display).
    """
    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r)]
    if len(r) < 2:
        return float('nan')
    target_bar = (1.0 + target_annual) ** (1.0 / periods_per_year) - 1.0
    excess = r - target_bar
    downside = np.minimum(excess, 0.0)
    dd = float(np.sqrt(np.mean(downside ** 2)))
    if dd <= _EPS:
        return float('nan')
    return float(np.mean(excess) / dd * np.sqrt(periods_per_year))


def information_ratio(period_returns, benchmark_returns, periods_per_year):
    """
    Annualised information ratio: active return per unit of tracking error.

    ``IR = mean(active) / std(active) * sqrt(periods)`` where
    ``active = strategy - benchmark``. Where Sharpe measures reward per unit of
    *total* risk against cash, IR measures reward per unit of *deviation from
    the benchmark* — the right question for a forecast whose alternative is
    simply holding the stock (buy-and-hold), which is the benchmark used
    throughout this module.
    """
    a = np.asarray(period_returns, dtype=np.float64)
    b = np.asarray(benchmark_returns, dtype=np.float64)
    n = min(len(a), len(b))
    if n < 2:
        return float('nan')
    active = a[:n] - b[:n]
    active = active[np.isfinite(active)]
    if len(active) < 2:
        return float('nan')
    sd = float(np.std(active, ddof=1))
    if sd <= _EPS:
        return float('nan')
    return float(np.mean(active) / sd * np.sqrt(periods_per_year))


def max_drawdown(period_returns):
    """
    Worst peak-to-trough decline of the equity curve, as a negative fraction.

    Drawdown is the metric that decides whether a strategy is *survivable* — an
    investor is stopped out by the path, not by the average. Returned as a
    negative number (-0.25 = a 25% peak-to-trough loss) with the peak/trough
    positions so a caller can show *when* it happened.

    Returns
    -------
    dict
        {'max_drawdown', 'peak_index', 'trough_index', 'recovery_index'} —
        ``recovery_index`` is None if the curve never regained the prior peak.
    """
    curve = cumulative_returns(period_returns)
    running_max = np.maximum.accumulate(curve)
    dd = curve / running_max - 1.0
    trough = int(np.argmin(dd))
    mdd = float(dd[trough])
    peak = int(np.argmax(curve[:trough + 1])) if trough > 0 else 0
    recovery = None
    after = np.where(curve[trough:] >= curve[peak])[0]
    if len(after):
        recovery = int(trough + after[0])
    return {'max_drawdown': mdd, 'peak_index': peak,
            'trough_index': trough, 'recovery_index': recovery}


def calmar_ratio(period_returns, periods_per_year):
    """
    Annualised return divided by the absolute maximum drawdown.

    A blunt but very readable "return per unit of worst pain" gauge. NaN when
    there is no drawdown to divide by.
    """
    mdd = abs(max_drawdown(period_returns)['max_drawdown'])
    if mdd <= _EPS:
        return float('nan')
    return float(annualized_return(period_returns, periods_per_year) / mdd)


def hit_rate(period_returns):
    """Fraction of periods with a strictly positive return (flat bars excluded)."""
    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r) & (r != 0.0)]
    if len(r) == 0:
        return float('nan')
    return float(np.mean(r > 0.0))


def profit_factor(period_returns):
    """
    Gross profit divided by gross loss.

    > 1 means the winners outweigh the losers in aggregate. Complements the hit
    rate: a strategy can win 40% of the time and still have a profit factor
    above 1 if the wins are larger.
    """
    r = np.asarray(period_returns, dtype=np.float64)
    r = r[np.isfinite(r)]
    gains = float(r[r > 0].sum())
    losses = float(-r[r < 0].sum())
    if losses <= _EPS:
        return float('inf') if gains > 0 else float('nan')
    return float(gains / losses)


# ==========================================
# Information coefficient
# ==========================================
def information_coefficient(pred_returns, actual_returns):
    """
    Pearson correlation between predicted and realised returns.

    The book's "information coefficient": the linear-signal content of a
    forecast. Unlike RMSE it is scale-free and unaffected by a constant bias, so
    it isolates *co-movement* — does the forecast go up when the outcome does?
    Values are typically tiny in this domain (an IC of 0.05 is a real signal in
    practice); the sign matters as much as the magnitude.

    Returns NaN if either series is constant (correlation undefined).
    """
    p = np.asarray(pred_returns, dtype=np.float64)
    a = np.asarray(actual_returns, dtype=np.float64)
    n = min(len(p), len(a))
    mask = np.isfinite(p[:n]) & np.isfinite(a[:n])
    p, a = p[:n][mask], a[:n][mask]
    if len(p) < 3 or np.std(p) <= _EPS or np.std(a) <= _EPS:
        return float('nan')
    return float(np.corrcoef(p, a)[0, 1])


def _rankdata(x):
    """Average-tie ranks (a tiny stand-in for ``scipy.stats.rankdata``)."""
    x = np.asarray(x, dtype=np.float64)
    order = np.argsort(x, kind='mergesort')
    ranks = np.empty(len(x), dtype=np.float64)
    ranks[order] = np.arange(1, len(x) + 1, dtype=np.float64)
    # Average the ranks inside each group of tied values.
    sorted_x = x[order]
    i = 0
    while i < len(x):
        j = i
        while j + 1 < len(x) and sorted_x[j + 1] == sorted_x[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = np.mean(ranks[order[i:j + 1]])
        i = j + 1
    return ranks


def rank_information_coefficient(pred_returns, actual_returns):
    """
    Spearman (rank) information coefficient.

    Rank IC is the robust cousin of the Pearson IC: it is immune to the fat
    tails and single-outlier dominance that plague raw return correlations, so
    it is the standard reported figure in factor research. Implemented via
    average-tie ranks so the module keeps its numpy-only dependency.
    """
    p = np.asarray(pred_returns, dtype=np.float64)
    a = np.asarray(actual_returns, dtype=np.float64)
    n = min(len(p), len(a))
    mask = np.isfinite(p[:n]) & np.isfinite(a[:n])
    p, a = p[:n][mask], a[:n][mask]
    if len(p) < 3:
        return float('nan')
    return information_coefficient(_rankdata(p), _rankdata(a))


def ic_t_stat(ic, n):
    """
    t-statistic of an information coefficient over ``n`` observations.

    ``t = IC * sqrt((n - 2) / (1 - IC^2))``. Included because a small IC on a
    small sample is indistinguishable from zero, and the project's convention is
    that no skill claim ships without a significance figure next to it.
    """
    if not np.isfinite(ic) or n < 3 or abs(ic) >= 1.0:
        return float('nan')
    return float(ic * np.sqrt((n - 2) / (1.0 - ic ** 2)))


# ==========================================
# Period-return tables (book: "cumulative and monthly returns")
# ==========================================
def period_return_table(dates, period_returns, freq='ME'):
    """
    Aggregate a return stream into calendar buckets (default monthly).

    The book reports "cumulative and monthly returns" because a single
    annualised number hides *when* the strategy worked; a monthly table shows
    whether the P&L came from one lucky month or was broadly distributed.

    Parameters
    ----------
    dates : array-like of datetime-like
        Timestamp for each return (same length as ``period_returns``).
    period_returns : array-like
        Simple returns per bar.
    freq : str, optional
        pandas offset alias for the bucket. Default 'ME' (month end).

    Returns
    -------
    pd.DataFrame
        Columns ['period', 'return', 'n_periods'] with compounded bucket returns.
    """
    n = min(len(dates), len(period_returns))
    s = pd.Series(np.asarray(period_returns, dtype=np.float64)[:n],
                  index=pd.to_datetime(pd.Series(list(dates)[:n])))
    grp = s.groupby(pd.Grouper(freq=freq))
    out = grp.apply(lambda x: float(np.prod(1.0 + x.values) - 1.0) if len(x) else np.nan)
    counts = grp.size()
    return pd.DataFrame({'period': out.index, 'return': out.values,
                         'n_periods': counts.values}).dropna(subset=['return'])


# ==========================================
# The bundle
# ==========================================
def evaluate_strategy(pred_returns, actual_returns, interval='daily',
                      cost_bps=DEFAULT_COST_BPS, mode='sign', deadband=0.0,
                      max_leverage=1.0, risk_free_annual=0.0, dates=None,
                      periods_per_bar=1):
    """
    Score a forecast the way an investor would: turn it into P&L, then measure.

    Pipeline: predicted returns -> position (:func:`position_from_signal`) ->
    gross P&L -> subtract transaction costs on position *changes* -> the full
    metric set from the book's Chapter 3, plus a buy-and-hold benchmark computed
    on exactly the same realisations so the comparison is apples-to-apples.

    Costs are charged on ``|Δposition|`` (so a flip from long to short costs two
    one-way trades and staying put costs nothing), which is the honest way to
    make a marginal statistical edge fail — most short-horizon "edges" do not
    survive it.

    Parameters
    ----------
    pred_returns : array-like
        Predicted log returns per (non-overlapping) rebalance period.
    actual_returns : array-like
        Realised log returns over the same periods, aligned element-wise.
    interval : str, optional
        'daily' or 'hourly' — selects the annualisation factor.
    cost_bps : float, optional
        One-way transaction cost in basis points. Default 10.
    mode, deadband, max_leverage
        Passed to :func:`position_from_signal`.
    risk_free_annual : float, optional
        Annual risk-free rate for Sharpe/Sortino. Default 0.
    dates : array-like, optional
        Timestamps for the monthly table (omitted when None).
    periods_per_bar : int, optional
        How many bars each evaluated period spans (e.g. 5 for a 5-day-horizon
        forecast rebalanced every 5 bars). Used to annualise correctly: the
        effective observation frequency is ``PERIODS_PER_YEAR / periods_per_bar``.

    Returns
    -------
    dict
        Strategy and benchmark metrics, the position/return streams, and the
        optional monthly table. Every value is a plain float / array so the
        result is JSON-friendly and easy to tabulate.
    """
    pred = np.asarray(pred_returns, dtype=np.float64)
    real = np.asarray(actual_returns, dtype=np.float64)
    n = min(len(pred), len(real))
    pred, real = pred[:n], real[:n]

    ppy = PERIODS_PER_YEAR.get(interval, SESSIONS_PER_YEAR)
    eff_ppy = max(ppy / max(int(periods_per_bar), 1), 1.0)

    pos = position_from_signal(pred, mode=mode, deadband=deadband,
                               max_leverage=max_leverage)

    # Simple returns for compounding; log returns are for the signal only.
    real_simple = np.expm1(np.where(np.isfinite(real), real, 0.0))

    gross = pos * real_simple
    # Cost on the change in position, starting from flat.
    turnover = np.abs(np.diff(np.concatenate([[0.0], pos])))
    cost = turnover * (cost_bps / 1e4)
    net = gross - cost

    bench = real_simple            # buy-and-hold over the same periods
    mdd = max_drawdown(net)
    ic = information_coefficient(pred, real)
    ric = rank_information_coefficient(pred, real)

    # Directional hit rate over the pairs where BOTH sides are finite; an
    # all-NaN forecast leaves nothing to score, so report NaN rather than
    # averaging an empty slice.
    both = np.isfinite(pred) & np.isfinite(real)
    dir_hit = (float(np.mean(np.sign(pred[both]) == np.sign(real[both])))
               if both.any() else float('nan'))

    out = {
        'n_periods': int(n),
        'interval': interval,
        'periods_per_year_effective': float(eff_ppy),
        'cost_bps': float(cost_bps),
        'position_mode': mode,

        # Return / risk (net of costs)
        'total_return': total_return(net),
        'annualized_return': annualized_return(net, eff_ppy),
        'annualized_volatility': annualized_volatility(net, eff_ppy),
        'sharpe': sharpe_ratio(net, eff_ppy, risk_free_annual),
        'sortino': sortino_ratio(net, eff_ppy, risk_free_annual),
        'information_ratio': information_ratio(net, bench, eff_ppy),
        'max_drawdown': mdd['max_drawdown'],
        'calmar': calmar_ratio(net, eff_ppy),
        'hit_rate': hit_rate(net),
        'profit_factor': profit_factor(net),
        'avg_turnover': float(np.mean(turnover)) if n else float('nan'),
        'total_cost': float(np.sum(cost)),

        # Gross (pre-cost) — the gap to net is the cost drag.
        'gross_total_return': total_return(gross),
        'gross_sharpe': sharpe_ratio(gross, eff_ppy, risk_free_annual),

        # Signal quality
        'information_coefficient': ic,
        'rank_information_coefficient': ric,
        'ic_t_stat': ic_t_stat(ic, n),
        'directional_hit_rate': dir_hit,

        # Benchmark: hold the stock over the identical periods.
        'benchmark_total_return': total_return(bench),
        'benchmark_sharpe': sharpe_ratio(bench, eff_ppy, risk_free_annual),
        'benchmark_max_drawdown': max_drawdown(bench)['max_drawdown'],

        # Streams, for plotting / further analysis.
        'positions': pos,
        'net_returns': net,
        'gross_returns': gross,
        'equity_curve': cumulative_returns(net),
        'benchmark_equity_curve': cumulative_returns(bench),
    }

    out['excess_vs_benchmark'] = out['total_return'] - out['benchmark_total_return']
    out['beats_benchmark'] = bool(out['excess_vs_benchmark'] > 0)

    # Sampling error on the Sharpe, and whether the estimate clears 2 SE. With a
    # walk-forward origin count in the single digits this is almost always False,
    # which is the honest headline — so it travels with the number.
    out['sharpe_se'] = sharpe_standard_error(out['sharpe'], n, eff_ppy)
    se = out['sharpe_se']
    out['sharpe_significant'] = bool(
        np.isfinite(se) and se > 0 and np.isfinite(out['sharpe'])
        and abs(out['sharpe']) > 2.0 * se)

    if dates is not None:
        try:
            out['monthly'] = period_return_table(dates, net)
        except Exception as exc:                    # never let a table break the run
            print(f"strategy_metrics: monthly table skipped ({exc})")

    return out



# ==========================================
# Cross-model panel (for data-snooping correction)
# ==========================================
def strategy_return_panel(per_model_signals, cost_bps=DEFAULT_COST_BPS,
                          mode='sign', deadband=0.0, max_leverage=1.0,
                          benchmark='buy_and_hold'):
    """
    Build the aligned (T, K) **performance-differential** panel for K strategies.

    Why this exists: ranking K models by Sharpe and reporting the winner is the
    same data-snooping mistake ``tests/validation/multiple_testing.py`` was written
    to correct for RMSE. With enough candidates one will look profitable by luck,
    and the more models you try the more certain that becomes. The economic table
    needs the identical treatment — so this assembles the panel that White's
    Reality Check and Hansen's SPA consume, with the sign convention they expect
    (``d[t, k] > 0`` means strategy k beat the benchmark at time t).

    **Alignment is mandatory, not cosmetic.** The bootstrap resamples *rows*, so
    it can only preserve the cross-model dependence if every column refers to the
    same origin. Models are therefore intersected on their common origins and any
    model that failed at an origin drops that origin for everyone — the same
    discipline ``collect_loss_panel`` applies to the loss panel.

    Parameters
    ----------
    per_model_signals : dict[str, pd.DataFrame]
        Model name -> the ``signals`` frame from ``backtest.walk_forward_backtest``
        (columns 'origin', 'pred_return', 'real_return').
    cost_bps : float, optional
        One-way transaction cost in basis points. Default 10.
    mode, deadband, max_leverage
        Passed to :func:`position_from_signal`.
    benchmark : {'buy_and_hold', 'cash'}, optional
        What the strategy must beat. 'buy_and_hold' (default) is the honest bar
        for a single-name forecast — the alternative to trading the signal is
        simply holding the stock. 'cash' tests profitability in absolute terms.

    Returns
    -------
    (list of str, np.ndarray, np.ndarray)
        ``(names, d, origins)`` where ``d`` has shape (T, K). Returns empty
        structures if fewer than two models share at least 3 origins.
    """
    usable = {k: v for k, v in (per_model_signals or {}).items()
              if v is not None and len(v) and 'origin' in getattr(v, 'columns', [])}
    if len(usable) < 2:
        return [], np.empty((0, 0)), np.empty(0)

    common = None
    for v in usable.values():
        s = set(int(o) for o in v['origin'].values)
        common = s if common is None else (common & s)
    origins = np.array(sorted(common), dtype=int)
    if len(origins) < 3:
        return [], np.empty((0, 0)), np.empty(0)

    names, cols = [], []
    for name, v in usable.items():
        sub = v[v['origin'].isin(origins)].sort_values('origin')
        pred = sub['pred_return'].values.astype(float)
        real = sub['real_return'].values.astype(float)
        pos = position_from_signal(pred, mode=mode, deadband=deadband,
                                   max_leverage=max_leverage)
        real_simple = np.expm1(np.where(np.isfinite(real), real, 0.0))
        turnover = np.abs(np.diff(np.concatenate([[0.0], pos])))
        net = pos * real_simple - turnover * (cost_bps / 1e4)
        bench = real_simple if benchmark == 'buy_and_hold' else 0.0
        names.append(name)
        cols.append(net - bench)

    return names, np.column_stack(cols), origins

def format_strategy_report(result, name='model'):
    """
    Render :func:`evaluate_strategy` output as a short human-readable block.

    Kept separate from the computation so the metrics stay pure and the printing
    can be reused by the CLI drivers.
    """
    r = result
    def f(key, pct=False, digits=2):
        v = r.get(key, float('nan'))
        if v is None or (isinstance(v, float) and not np.isfinite(v)):
            return "n/a"
        return f"{v * 100:.{digits}f}%" if pct else f"{v:.{digits}f}"

    lines = [
        f"=== Strategy evaluation: {name} "
        f"({r['n_periods']} periods, {r['cost_bps']:.0f} bps/side, "
        f"{r['position_mode']}) ===",
        f"  Total return      : {f('total_return', pct=True)}   "
        f"(gross {f('gross_total_return', pct=True)}, "
        f"buy&hold {f('benchmark_total_return', pct=True)})",
        f"  Annualised return : {f('annualized_return', pct=True)}   "
        f"vol {f('annualized_volatility', pct=True)}",
        f"  Sharpe / Sortino  : {f('sharpe')} / {f('sortino')}   "
        f"(gross Sharpe {f('gross_sharpe')}, buy&hold {f('benchmark_sharpe')})",
        f"  Sharpe ± SE       : {f('sharpe')} ± {f('sharpe_se')}  -> "
        f"{'outside' if r.get('sharpe_significant') else 'INSIDE'} 2 SE of zero"
        f"{'' if r.get('sharpe_significant') else ' (indistinguishable from noise)'}",
        f"  Information ratio : {f('information_ratio')}  vs buy-and-hold",
        f"  Max drawdown      : {f('max_drawdown', pct=True)}   "
        f"(buy&hold {f('benchmark_max_drawdown', pct=True)})  "
        f"Calmar {f('calmar')}",
        f"  Hit rate / PF     : {f('hit_rate', pct=True)} / {f('profit_factor')}",
        f"  IC / rank IC      : {f('information_coefficient', digits=4)} / "
        f"{f('rank_information_coefficient', digits=4)}  "
        f"(t={f('ic_t_stat')})",
        f"  Cost drag         : {f('total_cost', pct=True)} of notional, "
        f"avg turnover {f('avg_turnover')}",
    ]
    verdict = ("BEATS buy-and-hold" if r.get('beats_benchmark')
               else "does NOT beat buy-and-hold")
    lines.append(f"  Verdict           : {verdict}"
                 f"  (excess {f('excess_vs_benchmark', pct=True)})")
    return "\n".join(lines)


# ==========================================
# Cross-sectional IC: the Fama-MacBeth form
# ==========================================
# :func:`ic_t_stat` above is the ordinary correlation t-test, which assumes n
# INDEPENDENT observations. That assumption holds for a single ticker's time
# series and fails badly on a pooled panel: forty names on the same date share
# the market move, so a panel of 6,887 rows over 574 dates carries nothing like
# 6,887 independent observations. Feeding the row count to ic_t_stat inflates
# the t-statistic by roughly sqrt(names per date).
#
# The factor-research standard (Fama-MacBeth 1973) avoids this: compute the IC
# WITHIN each date's cross-section, then t-test the resulting time series of
# ICs. The unit of observation becomes the date, which is the level at which
# the observations are actually close to independent.
def ic_by_date(dates, score, forward, min_names=5, rank=True):
    """
    Information coefficient computed within each date's cross-section.

    Parameters
    ----------
    dates : array-like
        Date (or datetime) per row; rows sharing a value form one cross-section.
    score, forward : array-like
        Model score and realised forward return, aligned with ``dates``.
    min_names : int
        Skip a date with fewer than this many usable names — a correlation over
        three names is noise, and including it widens the IC series' variance
        without adding information.
    rank : bool
        Spearman (rank) IC when True, Pearson when False. Rank is the default
        because cross-sectional returns are fat-tailed and a single outlier
        otherwise dominates the date's correlation.

    Returns
    -------
    pandas.Series
        IC indexed by date, sorted. Empty if no date qualifies.
    """
    df = pd.DataFrame({
        'date': np.asarray(dates),
        's': np.asarray(score, dtype=float),
        'f': np.asarray(forward, dtype=float),
    }).dropna()
    if df.empty:
        return pd.Series(dtype=float)

    out = {}
    for d, grp in df.groupby('date', sort=True):
        if len(grp) < min_names:
            continue
        a, b = grp['s'].values, grp['f'].values
        if rank:
            a = pd.Series(a).rank().values
            b = pd.Series(b).rank().values
        if np.std(a) < _EPS or np.std(b) < _EPS:
            continue
        out[d] = float(np.corrcoef(a, b)[0, 1])
    # An empty result is meaningful, not an error: it means no date had
    # min_names usable names, i.e. the cross-section is too narrow to
    # support a within-date correlation at all. Callers must report that
    # rather than fall back to the pooled statistic.
    return pd.Series(out, dtype=float).sort_index()


def newey_west_se(x, lags=0):
    """
    Newey-West standard error of a mean, robust to serial correlation.

    Needed because a 5-day forward return sampled every day makes consecutive
    dates' ICs **overlapping**: they share four of five days of outcome, so they
    are autocorrelated by construction. Treating them as independent understates
    the standard error and overstates the t-statistic - the same error the
    project's overlapping-origin caveat flags in the backtest. Use
    ``lags = horizon - 1``.
    """
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 3:
        return float('nan')
    e = x - x.mean()
    var = float(e @ e) / n
    for lag in range(1, int(min(lags, n - 1)) + 1):
        w = 1.0 - lag / (lags + 1.0)           # Bartlett kernel
        cov = float(e[lag:] @ e[:-lag]) / n
        var += 2.0 * w * cov
    if not np.isfinite(var) or var <= 0:
        return float('nan')
    return float(np.sqrt(var / n))


def fama_macbeth_ic(ic_series, lags=0):
    """
    Mean IC and its t-statistic from a per-date IC series.

    Returns
    -------
    dict
        {'mean_ic', 't_stat', 'n_dates', 'ic_std', 'hit_rate'} - ``hit_rate``
        being the share of dates with a positive IC, a useful sanity read: a
        genuine factor is right more often than not, not right enormously on a
        handful of dates.
    """
    s = pd.Series(ic_series, dtype=float).dropna()
    n = int(len(s))
    if n < 3:
        return {'mean_ic': float('nan'), 't_stat': float('nan'),
                'n_dates': n, 'ic_std': float('nan'), 'hit_rate': float('nan')}
    mean_ic = float(s.mean())
    se = newey_west_se(s.values, lags=lags)
    t = float(mean_ic / se) if np.isfinite(se) and se > 0 else float('nan')
    return {'mean_ic': mean_ic, 't_stat': t, 'n_dates': n,
            'ic_std': float(s.std(ddof=1)),
            'hit_rate': float((s > 0).mean())}


# ==========================================
# Psychological tolerance (Klaas, Ch. 4)
# ==========================================
# "Machine Learning for Finance" lists four backtest biases: look-ahead,
# survivorship, overfitting - all of which this project already guards against -
# and one it did not measure:
#
#   "Consider an algorithm that loses money for four months in a row before
#    making it all back in a backtest. We might feel satisfied... However, if the
#    algorithm loses money for four months in a row in real life and we don't
#    know whether it will make that amount back, then will we sit tight or pull
#    the plug? In the backtest, we know the final result, but in real life, we
#    do not."
#
# max_drawdown answers "how deep?". Depth is what you lose; DURATION is what
# makes you abandon the strategy before it recovers - and a backtest reader
# knows the recovery happened, which is exactly the knowledge a live operator
# lacks. These functions measure the duration side.
def drawdown_series(period_returns):
    """Fractional drawdown at every point of the equity curve (<= 0)."""
    curve = cumulative_returns(period_returns)
    if len(curve) == 0:
        return np.array([], dtype=float)
    return curve / np.maximum.accumulate(curve) - 1.0


def time_under_water(period_returns, periods_per_year=None):
    """
    How long the strategy spends below its previous high-water mark.

    Parameters
    ----------
    period_returns : array-like
        Per-period strategy returns.
    periods_per_year : int, optional
        When given, durations are also reported in years, which is the unit an
        investor's patience is actually denominated in.

    Returns
    -------
    dict
        ``longest_underwater`` (periods from a peak until that peak is regained;
        an unrecovered run counts to the end of the sample),
        ``currently_underwater`` (periods since the last high, i.e. the run an
        investor would be sitting in *now*), ``fraction_underwater``, and
        ``longest_losing_streak`` (consecutive losing periods - the book's
        "four months in a row"). Durations in years are added when
        ``periods_per_year`` is supplied.
    """
    r = np.asarray(period_returns, dtype=float)
    r = r[np.isfinite(r)]
    out = {'longest_underwater': 0, 'currently_underwater': 0,
           'fraction_underwater': float('nan'), 'longest_losing_streak': 0,
           'unrecovered': False}
    if len(r) == 0:
        return out

    dd = drawdown_series(r)
    underwater = dd < -_EPS

    # Longest run below the high-water mark.
    longest = run = 0
    for flag in underwater:
        run = run + 1 if flag else 0
        longest = max(longest, run)

    # The run still open at the end of the sample. Reported separately because
    # an unrecovered drawdown is the one an investor is actually living through;
    # a backtest that ends mid-drawdown looks calmer than it was.
    current = 0
    for flag in underwater[::-1]:
        if not flag:
            break
        current += 1

    # Consecutive losing periods - the book's example is stated this way.
    streak = run = 0
    for x in r:
        run = run + 1 if x < 0 else 0
        streak = max(streak, run)

    out.update({
        'longest_underwater': int(longest),
        'currently_underwater': int(current),
        'fraction_underwater': float(np.mean(underwater)),
        'longest_losing_streak': int(streak),
        'unrecovered': bool(current > 0),
    })
    if periods_per_year:
        ppy = float(periods_per_year)
        out['longest_underwater_years'] = round(longest / ppy, 2)
        out['currently_underwater_years'] = round(current / ppy, 2)
    return out
