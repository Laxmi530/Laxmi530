"""
Stop-loss risk: how likely is a stop to be hit, and where should it go?

Mladjenovic, *Stock Investing For Dummies* (7th ed.), Ch. 17, recommends
stop-loss and trailing-stop orders as "an important technique in wealth
preservation": "most investors set a stop-loss amount at about 10 percent below
the market value", 5% if nervous, William O'Neill's 8%, 20-25% for volatile
stocks, and "knowing the beta gives you a general idea of the stock's trading
range" for placing one.

Two things in that advice are measurable here, and the app needed both:

1. **A stop triggers on the path, not at the horizon.** The risk panel's
   ``P(loss > x%)`` is the chance the price *ends* below -x%. A stop at -x% is
   hit if the price *touches* -x% at any point before then, which is more
   likely: for a driftless random walk the reflection principle makes it
   exactly twice as likely. Reading the end-point probability as the stop-out
   probability understates it.
2. **A fixed percentage means different things on different stocks.** 10% is a
   wide stop on a quiet large cap and a tight one on a volatile mid cap. The
   book's own fix is to scale by volatility, which it calls beta. Beta is not
   volatility: it is correlation times relative volatility, so a stock can have
   a low beta and a wide range. ``run_stop_loss.py`` measures which of the two
   actually predicts stop-outs on NSE.

Estimators of the stop-hit probability, in order of how much they assume:

* ``endpoint_probability`` -- P(end below the stop) under a log-normal. What
  the panel showed. A lower bound, not the stop-out probability.
* ``reflection_probability`` -- 2 x Phi(ln(1 - x) / (sigma sqrt h)): the
  first-passage probability of driftless Brownian motion.
* ``stop_hit_probability`` -- the stock's OWN history: the deepest intraday
  low over every past ``h``-bar window, divided by the volatility forecast at
  its start, so each window is in units of its own sigma. The current forecast
  sigma then reads a probability off that distribution. No Gaussian, no
  continuous-path assumption, and gaps and fat tails are whatever the stock
  did.

**What the measurement chose** (``run_stop_loss.py``, ~170,000 out-of-sample
name-window-stop cases on NSE): the end-point probability understates the
stop-out rate by about half (calibration error 0.086 in the 2020-21 crash); the
reflection principle is on target in the crash and about a third too high in
the rising 2022-24 market, where drift lowers stop-outs (0.040 in both); the
stock's own excursion history is no better (0.043 / 0.044). So the app ships
the simplest one: ``risk_metrics.stop_hit_probability`` = 2 x the end-point
probability it already computed. The empirical estimator stays here, measured,
for research.

numpy / pandas only.
"""

import math

import numpy as np
import pandas as pd

_EPS = 1e-12
#: Bars a stop-hit estimate needs before it is trusted.
MIN_WINDOWS = 120


def _norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _ewma_sigma(log_returns, lam=0.94, warmup=20):
    """One-step-ahead EWMA sigma per bar (uses bars strictly before each one)."""
    from var_models import ewma_volatility
    return ewma_volatility(np.asarray(log_returns, dtype=float), lam=lam, warmup=warmup)


def adjusted_lows(df):
    """
    Lows on the adjusted-close basis.

    A raw low and an adjusted close are on different bases whenever a split or
    dividend lies ahead of the bar, which would put a split-sized error into
    every stop test (the trap ``event_backtest.adjust_ohlc`` exists for).
    """
    close = pd.to_numeric(df["close"], errors="coerce").to_numpy(float)
    adj = pd.to_numeric(df["adj_close"], errors="coerce").to_numpy(float)
    low = pd.to_numeric(df["low"], errors="coerce").to_numpy(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(close > 0, adj / close, np.nan)
    ratio = pd.Series(ratio).ffill().bfill().fillna(1.0).to_numpy()
    return low * ratio, adj


def _window_minima(low, adj, horizon):
    """log(min low over bars t+1..t+h / close_t) for every origin t with h bars ahead."""
    n = len(adj)
    if n <= horizon + 1:
        return np.array([])
    lows = pd.Series(low).rolling(horizon).min().shift(-horizon).to_numpy()
    with np.errstate(divide="ignore", invalid="ignore"):
        m = np.log(lows / adj)
    return m[:n - horizon]


def standardised_excursions(df, horizon):
    """
    The deepest move against a long position over each past ``horizon``-bar
    window, in units of the volatility forecast at the window's start.

    Returns ``(u, sigma)``: ``u[t] = log(min low[t+1..t+h] / close[t]) /
    (sigma[t] * sqrt(h))``, where ``sigma[t]`` is the one-step EWMA forecast
    made with bars up to ``t``. Each window is therefore measured in its own
    regime's units, which is what lets one distribution serve calm and
    volatile periods.
    """
    low, adj = adjusted_lows(df)
    ok = np.isfinite(adj) & (adj > 0)
    low, adj = low[ok], adj[ok]
    if len(adj) < MIN_WINDOWS + horizon + 2:
        return np.array([]), np.array([])
    r = np.diff(np.log(adj))
    # sigma for bar t+1 is known at the close of t; align it to origin t.
    sig_next = _ewma_sigma(r)                 # sig_next[k] forecasts r[k] = bar k+1
    sigma = np.r_[sig_next, np.nan][:len(adj)]
    m = _window_minima(low, adj, horizon)
    s = sigma[:len(m)]
    u = m / (s * math.sqrt(horizon))
    good = np.isfinite(u)
    return u[good], s[good]


def endpoint_probability(stop_pct, sigma_h, mu_h=0.0):
    """P(log return at the horizon <= ln(1 - stop)) under a Normal(mu_h, sigma_h)."""
    if sigma_h is None or not np.isfinite(sigma_h) or sigma_h <= 0:
        return float("nan")
    b = math.log(max(1.0 - stop_pct, _EPS))
    return _norm_cdf((b - mu_h) / sigma_h)


def reflection_probability(stop_pct, sigma_h):
    """First-passage probability of driftless Brownian motion: 2 x Phi(b / sigma_h)."""
    p = endpoint_probability(stop_pct, sigma_h)
    return float(min(1.0, 2.0 * p)) if np.isfinite(p) else float("nan")


def no_exit_probability(a):
    """
    P(sup_{0<=t<=1} |W_t| < a) for standard Brownian motion.

    The image series sum_k (-1)^k [Phi((2k+1)a) - Phi((2k-1)a)], which converges
    for every a > 0; the number of terms grows as a shrinks so the tail stays
    below 1e-12.
    """
    if not np.isfinite(a) or a <= 0:
        return 0.0
    K = int(10.0 / a) + 5
    s = 0.0
    for k in range(-K, K + 1):
        s += (-1) ** (k % 2) * (_norm_cdf((2 * k + 1) * a) - _norm_cdf((2 * k - 1) * a))
    return float(min(1.0, max(0.0, s)))


def trailing_probability(stop_pct, sigma_h):
    """
    P(a trailing stop ``stop_pct`` below the running peak is hit within the horizon).

    For driftless Brownian motion the drawdown from the running maximum, M - W,
    has the law of |W| (Levy), so the first time the drawdown reaches
    a = |ln(1 - stop)| / sigma_h is the first time |W| leaves (-a, a):
    ``1 - no_exit_probability(a)``. Always at least the fixed-stop
    :func:`reflection_probability`, and about twice it for a deep stop.
    """
    if sigma_h is None or not np.isfinite(sigma_h) or sigma_h <= 0:
        return float("nan")
    a = -math.log(max(1.0 - stop_pct, _EPS)) / sigma_h
    return 1.0 - no_exit_probability(a)


def touch_up_probability(target_pct, sigma_h):
    """P(the price touches +``target_pct`` within the horizon): the reflection principle upward."""
    if sigma_h is None or not np.isfinite(sigma_h) or sigma_h <= 0:
        return float("nan")
    b = math.log(1.0 + target_pct) / sigma_h
    return float(min(1.0, 2.0 * (1.0 - _norm_cdf(b))))


def stop_hit_probability(df, stop_pct, horizon, sigma_now=None, excursions=None):
    """
    P(a stop ``stop_pct`` below today's close is touched within ``horizon`` bars).

    Read off the stock's own history of volatility-standardised excursions
    (:func:`standardised_excursions`) at today's volatility. ``sigma_now`` is a
    one-bar sigma; by default the EWMA forecast for the next bar, which is the
    same estimator each historical window was standardised with.

    Returns
    -------
    dict
        ``{'probability', 'reflection', 'endpoint', 'sigma_now', 'n_windows'}``.
        ``probability`` is NaN when there are fewer than :data:`MIN_WINDOWS`
        historical windows.
    """
    if excursions is None:
        u, _ = standardised_excursions(df, horizon)
    else:
        u = np.asarray(excursions, dtype=float)
    if sigma_now is None:
        adj = pd.to_numeric(df["adj_close"], errors="coerce").dropna().to_numpy(float)
        adj = adj[adj > 0]
        from var_models import ewma_next_sigma
        sigma_now = ewma_next_sigma(np.diff(np.log(adj))) if len(adj) > 21 else float("nan")
    sig_h = float(sigma_now) * math.sqrt(horizon) if np.isfinite(sigma_now) else float("nan")
    out = {"probability": float("nan"),
           "reflection": reflection_probability(stop_pct, sig_h),
           "endpoint": endpoint_probability(stop_pct, sig_h),
           "sigma_now": float(sigma_now), "n_windows": int(len(u))}
    if len(u) >= MIN_WINDOWS and np.isfinite(sig_h) and sig_h > 0:
        thr = math.log(max(1.0 - stop_pct, _EPS)) / sig_h
        out["probability"] = float(np.mean(u <= thr))
    return out


def stop_for_probability(df, target_prob, horizon, sigma_now=None, excursions=None):
    """
    The stop distance with a ``target_prob`` chance of being hit within ``horizon``.

    The inverse of :func:`stop_hit_probability`, and the quantitative version of
    the book's advice to size a stop by the stock's volatility rather than use
    one percentage for every stock. Returns a positive fraction (0.07 = 7%
    below today's close), or NaN with too little history.
    """
    if excursions is None:
        u, _ = standardised_excursions(df, horizon)
    else:
        u = np.asarray(excursions, dtype=float)
    if sigma_now is None:
        adj = pd.to_numeric(df["adj_close"], errors="coerce").dropna().to_numpy(float)
        adj = adj[adj > 0]
        from var_models import ewma_next_sigma
        sigma_now = ewma_next_sigma(np.diff(np.log(adj))) if len(adj) > 21 else float("nan")
    if len(u) < MIN_WINDOWS or not np.isfinite(sigma_now) or sigma_now <= 0:
        return float("nan")
    q = float(np.quantile(u, float(target_prob)))
    return float(-math.expm1(q * float(sigma_now) * math.sqrt(horizon)))


def beta(stock_returns, market_returns):
    """OLS beta of stock on market log returns (NaN on a degenerate sample)."""
    s = np.asarray(stock_returns, dtype=float)
    m = np.asarray(market_returns, dtype=float)
    ok = np.isfinite(s) & np.isfinite(m)
    s, m = s[ok], m[ok]
    if len(s) < 20 or np.var(m) <= _EPS:
        return float("nan")
    return float(np.cov(s, m, ddof=1)[0, 1] / np.var(m, ddof=1))
