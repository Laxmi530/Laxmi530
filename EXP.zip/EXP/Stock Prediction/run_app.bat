@echo off
rem Double-click to start the forecasting app. Installs any missing Python
rem packages first (it asks before downloading). See run_app.py.
cd /d "%~dp0"
python run_app.py %*
if errorlevel 1 pause
