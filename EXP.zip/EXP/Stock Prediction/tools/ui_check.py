"""
Check the Streamlit app the way a user meets it: interaction scenarios, and
the real page in Chrome at phone-to-4K widths.

Why this exists
---------------
The first UI audit (README section 66) needed both, and both were written as
throwaway scripts. Streamlit's ``AppTest`` runs the script and its widgets but
renders nothing, so it cannot see a chart legend covering the data or a table
cut off on a phone; a browser can, but cannot cheaply drive twenty scenarios.

Usage
-----
::

    python tools/ui_check.py scenarios            # AppTest: reset, submit, re-runs, hourly
    python tools/ui_check.py browser              # starts its own app, log off; Chrome at 5 widths
    python tools/ui_check.py browser --url http://localhost:8501 --out shots/   # an app you started

``browser`` needs Playwright with an installed Chrome (``channel="chrome"``).
By default it starts its own app on a spare port with
``STOCKAPP_USE_PREDICTION_LOG=0`` and stops it afterwards, because its Submit
is a real run and would otherwise be written to the forward prediction log
(README section 66; two test runs got into the log that way before this
default existed). With ``--url`` it uses an app you started; start that one
with the same variable set. It submits one quick run (two fast models), then for
each width saves a screenshot, measures any element wider than the screen, and
reads the Submit/Reset button colours. ``scenarios`` replaces
``prediction_log.log_forecast`` with a counter, so it never writes the real
log, and reports exceptions, errors and warnings for each step.
"""

import argparse
import os
import sys
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMPANY = "Tata Consultancy Services Limited"
FAST_MODELS = ["HAR-RV (volatility)", "Kalman (local trend)"]
VIEWPORTS = [("phone", 390, 844), ("tablet", 820, 1180), ("laptop", 1366, 768),
             ("desktop", 1920, 1080), ("wide", 2560, 1440)]


def scenarios():
    """Interaction scenarios with AppTest. Returns the number of problems found."""
    os.chdir(_ROOT)
    sys.path.insert(0, _ROOT)
    os.environ.setdefault("STOCKAPP_QUIET", "1")
    from streamlit.testing.v1 import AppTest
    import prediction_log
    logged = []
    prediction_log.log_forecast = lambda **k: logged.append(k["model"]) or "x"
    problems = 0

    def report(at, label, expect_warning=None):
        nonlocal problems
        exc = [str(e.value)[:300] for e in at.exception]
        errs = [e.value[:200] for e in at.error]
        warns = [w.value[:140] for w in at.warning if "Caution" not in w.value]
        unexpected = [w for w in warns if not (expect_warning and expect_warning in w)]
        bad = bool(exc or errs or unexpected)
        problems += bad
        print(f"{'PROBLEM' if bad else 'ok':>7}  {label}" + (f"  exceptions={exc} errors={errs} warnings={unexpected}" if bad else ""))

    def button(at, label):
        return next(b for b in at.sidebar.button if b.label == label)

    at = AppTest.from_file("UI.py", default_timeout=1800).run()
    report(at, "first load")
    button(at, "Reset").click()
    at.run()
    report(at, "Reset before any Submit")
    if at.sidebar.selectbox(key="sb_period").value != 5:
        problems += 1
        print("PROBLEM  Reset did not restore the 5-day default horizon")
    at.sidebar.multiselect(key="sb_models").set_value([])
    at.run()
    button(at, "Submit").click()
    at.run()
    report(at, "Submit with no models selected", expect_warning="No models selected")
    at.sidebar.selectbox(key="sb_company").set_value(COMPANY)
    at.sidebar.multiselect(key="sb_models").set_value(FAST_MODELS)
    at.sidebar.checkbox(key="sb_assess").set_value(False)
    at.run()
    button(at, "Submit").click()
    at.run()
    report(at, "daily run")
    allowed = {"Date", "Date / time", "Forecast (₹)", "Lower 95% (₹)", "Upper 95% (₹)"}
    for d in at.dataframe:
        cols = set(map(str, getattr(d.value, "columns", [])))
        if "Forecast (₹)" in cols and not cols <= allowed:
            problems += 1
            print(f"PROBLEM  a predicted-values table shows internal columns: {sorted(cols - allowed)}")
    labels = [e.label for e in at.expander]
    for panel in ("Company check", "Stock screens"):
        if not any(panel in lab for lab in labels):
            problems += 1
            print(f"PROBLEM  the daily run has no '{panel}' panel")
    n = len(logged)
    at.number_input[0].set_value(3.0)
    at.run()
    report(at, "threshold changed after results")
    if len(logged) != n:
        problems += 1
        print(f"PROBLEM  a re-run logged the forecast again ({n} -> {len(logged)})")
    at.sidebar.radio(key="sb_freq").set_value("1 Hour")
    at.run()
    button(at, "Submit").click()
    at.run()
    report(at, "hourly run")
    button(at, "Reset").click()
    at.run()
    report(at, "Reset after results")
    if any(m.value.startswith("### Model:") for m in at.markdown):
        problems += 1
        print("PROBLEM  Reset left results on the page")
    print(f"\n{problems} problem(s)")
    return problems


def serve(port=8599, timeout=180):
    """Start the app on ``port`` with the prediction log off; return the process."""
    import subprocess
    import urllib.request
    env = dict(os.environ, STOCKAPP_USE_PREDICTION_LOG="0", STOCKAPP_QUIET="1")
    proc = subprocess.Popen([sys.executable, "-m", "streamlit", "run", "UI.py", "--server.port", str(port),
                             "--server.headless", "true"], cwd=_ROOT, env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            urllib.request.urlopen(f"http://localhost:{port}/", timeout=5)
            return proc
        except Exception:
            if proc.poll() is not None:
                raise RuntimeError("the app exited while starting")
            time.sleep(1)
    proc.terminate()
    raise RuntimeError(f"the app did not answer on port {port} within {timeout}s")


def browser(url, out):
    """Chrome at five widths: screenshots, overflow and button colours."""
    from playwright.sync_api import sync_playwright
    os.makedirs(out, exist_ok=True)
    errors = []
    with sync_playwright() as p:
        b = p.chromium.launch(channel="chrome", headless=True)
        page = b.new_page(viewport={"width": 1366, "height": 900})
        page.on("console", lambda m: errors.append(m.text[:200]) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(str(e)[:200]))
        page.goto(url, wait_until="networkidle", timeout=120000)
        page.wait_for_selector("text=Select parameters and click Submit", timeout=180000)
        sb = page.locator('[data-testid="stSidebar"]')
        sb.locator('[data-testid="stSelectbox"]').first.click()
        page.keyboard.type(COMPANY[:24])
        time.sleep(1.5)
        page.get_by_role("option", name=COMPANY, exact=True).first.click()
        ms = sb.locator('[data-testid="stMultiSelect"]').first
        ms.locator('[aria-label="Clear all"], [title="Clear all"]').first.click()
        for m in FAST_MODELS:
            ms.locator("input").click()
            page.keyboard.type(m[:8])
            time.sleep(0.8)
            page.get_by_role("option", name=m, exact=True).first.click()
        page.keyboard.press("Escape")
        sb.get_by_role("button", name="Submit").click()
        page.wait_for_selector(".js-plotly-plot", timeout=900000)
        time.sleep(5)
        for name, w, h in VIEWPORTS:
            page.set_viewport_size({"width": w, "height": h})
            time.sleep(2)
            page.screenshot(path=os.path.join(out, f"{name}_screen.png"))
            page.set_viewport_size({"width": w, "height": 7000})
            time.sleep(3)
            page.screenshot(path=os.path.join(out, f"{name}_full.png"))
            # Tables scroll inside their own frame by design; measure frames,
            # and every other element, against the screen width.
            over = page.evaluate("""() => {
                const vw = document.documentElement.clientWidth;
                // A table in a closed expander keeps the width it was laid out at
                // and re-measures when opened, so only visible tables count.
                const frames = Array.from(document.querySelectorAll('[data-testid="stDataFrame"]'))
                    .filter(d => !d.closest('details:not([open])'))
                    .map(d => d.getBoundingClientRect()).filter(r => r.width > 0 && r.height > 0 && r.right > vw + 2).length;
                const charts = Array.from(document.querySelectorAll('.js-plotly-plot'))
                    .map(d => d.getBoundingClientRect()).filter(r => r.width > 0 && r.right > vw + 2).length;
                return {vw, page_scrolls_sideways: document.documentElement.scrollWidth > vw,
                        tables_wider_than_screen: frames, charts_wider_than_screen: charts};
            }""")
            print(f"{name:>8} {w}x{h}: {over}")
        colours = page.evaluate("""() => Array.from(document.querySelectorAll('[data-testid="stSidebar"] button'))
            .filter(b => /Submit|Reset/.test(b.innerText))
            .map(b => b.innerText.trim() + ' ' + getComputedStyle(b).backgroundColor)""")
        print("buttons:", colours)
        b.close()
    print("browser console errors:", errors or "none")
    print(f"screenshots in {os.path.abspath(out)}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Check the Streamlit app.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("scenarios")
    br = sub.add_parser("browser")
    br.add_argument("--url", default=None,
                    help="use an app you started (start it with STOCKAPP_USE_PREDICTION_LOG=0); "
                         "default: start one with the log off")
    br.add_argument("--port", type=int, default=8599)
    br.add_argument("--out", default=os.path.join(_ROOT, ".ui_check"))
    a = ap.parse_args(argv)
    if a.cmd == "scenarios":
        return 1 if scenarios() else 0
    if a.url:
        print("Using your app at", a.url, "- its Submit writes to the prediction log unless it was "
              "started with STOCKAPP_USE_PREDICTION_LOG=0")
        browser(a.url, a.out)
        return 0
    proc = serve(a.port)
    try:
        browser(f"http://localhost:{a.port}", a.out)
    finally:
        proc.terminate()
    return 0


if __name__ == "__main__":
    sys.exit(main())
