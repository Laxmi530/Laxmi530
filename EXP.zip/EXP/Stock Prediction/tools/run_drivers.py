"""
Re-run the research drivers offline, safely, and check they reproduce.

Why this exists
---------------
An end-to-end check should re-run every driver in ``tests/validation/``, but
two things make that dangerous to do by hand:

1. **The reserved period.** Any driver that reaches yfinance downloads data up
   to today and so reads the 2025+ test period, and some do so through a
   module they import (README section 59 re-ran two by mistake). Grepping for
   ``yfinance`` misses those. So each driver runs in its own process with a
   fake ``yfinance`` package first on the path that raises on any use: a
   driver that needs live data stops with ``BLOCKED`` instead of reading it.
2. **The evidence files.** Drivers overwrite their result CSVs, which back
   figures in the README. Every CSV is backed up first, the fresh output is
   compared with it (a reproducibility check), and the originals are restored.

Two other routes to live prices are closed the same way, inside each
driver's process only: ``safe_fetch`` would answer a blocked download from its
last-known-good cache (``.data_cache/``, which can hold 2025+ prices), so that
cache becomes an empty folder; and ``get_data`` falls back to nselib's live NSE
history, so its two price fetchers raise. (nselib itself stays available:
``bhavcopy`` uses it for corporate actions bounded by a study's end date.)

Usage
-----
::

    python tools/run_drivers.py                      # every run_*.py
    python tools/run_drivers.py run_oneil run_52week_high
    python tools/run_drivers.py --timeout 1800 --jobs 3
    python tools/run_drivers.py --keep               # keep the fresh CSVs instead of restoring

``--allow-live`` turns the guard off for the named drivers only, for the
owner's decision to run the ones that read live prices up to today, and so the
reserved period. Each driver that reads past 2024 gets a row in
``tests/validation/holdout_ledger.csv`` (the ledger ``bhavcopy`` keeps) with
the purpose; the result CSVs are always restored, so no published figure takes
in reserved-period data; and the forward prediction log's checksum is compared
before and after.

Outcomes: ``ok`` (exit 0, never touched live data), ``BLOCKED`` (tried to fetch
live prices, even if it caught the error), ``FAILED`` (any other error; the
last lines are printed), ``TIMEOUT``. For each CSV a driver rewrote:
``identical``, ``same within 1e-6``, or the largest relative difference.
"""

import argparse
import concurrent.futures as cf
import glob
import os
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(_HERE)
VALID = os.path.join(ROOT, "tests", "validation")
MARK = "OFFLINE GUARD: yfinance is blocked"
#: Every driver's full output, kept per run (gitignored), so errors a driver
#: caught and printed can be read after it exited 0.
LOG_ROOT = os.path.join(ROOT, ".driver_logs")
#: Files the backup/restore must never touch. The ledger is written DURING a
#: live run; restoring "new files" once deleted it.
PROTECTED = {"holdout_ledger.csv"}

import re as _re                                                    # noqa: E402
#: Lines that mean something went wrong inside a driver that still exited 0.
SUSPECT = _re.compile(r"Traceback|\b[A-Z]\w*(Error|Exception)\b|\bfail(ed|ure|s)?\b|\bnan%|"
                      r"cannot continue|could not|\bskipp(ed|ing)\b", _re.I)
#: Known-benign lines (library chatter, and the words in ordinary output).
BENIGN = _re.compile(r"TensorFlow GPU support|reset_default_graph|oneDNN|absl::|cuda|"
                     r"mean_(absolute|squared)_error|squared_error|forecast error|tracking error|"
                     r"error bars?|standard error|fail to reject|failure rate|fails? (the|its|to clear)|"
                     r"rate of failures|proportion of failures|\bPOF\b|"
                     # statistical verdicts the drivers print by design (read 2026-10-20)
                     r"\b(pass|fail)\s*$|FAILS? joint test|fails multiple-testing|FAIL: the ordering|"
                     r"rate (OK|REJECTED)|independence test|cum_sq_error|Skipping resolution", _re.I)

GUARD = f'''"""A stand-in for yfinance that refuses to fetch (tools/run_drivers.py)."""
import os as _os
class _Blocked(RuntimeError):
    pass
def __getattr__(name):
    # Leave a mark even if the caller swallows the error, so the runner can
    # tell "needed live data" from a real failure.
    flag = _os.environ.get("OFFLINE_GUARD_FLAG")
    if flag:
        open(flag, "a").close()
    raise _Blocked("{MARK} (yfinance.%s)" % name)
'''

# Loaded at interpreter start (sitecustomize): patches two project modules as
# they are imported, so no live or cached 2025+ prices can reach a driver.
SITE = '''import importlib.abc, importlib.util, sys, tempfile
_EMPTY = tempfile.mkdtemp(prefix="empty_data_cache_")
_MARK = "%s"
def _blocked(*a, **k):
    import os
    flag = os.environ.get("OFFLINE_GUARD_FLAG")
    if flag:
        open(flag, "a").close()
    raise RuntimeError(_MARK + " (get_data's live price fetch)")
def _patch_safe_fetch(m):
    m._CACHE_DIR = _EMPTY
def _patch_get_data(m):
    m.get_whole_stock_data = _blocked
    m.get_stock_data_using_nselib = _blocked
_PATCHES = {"safe_fetch": _patch_safe_fetch, "get_data": _patch_get_data}
class _SafeFetchHook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path=None, target=None):
        if name not in _PATCHES:
            return None
        sys.meta_path.remove(self)
        try:
            spec = importlib.util.find_spec(name)
        finally:
            sys.meta_path.insert(0, self)
        if spec is None or spec.loader is None:
            return spec
        run = spec.loader.exec_module
        def exec_module(module, _run=run, _fix=_PATCHES[name]):
            _run(module)
            _fix(module)
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, _SafeFetchHook())
''' % MARK


def _guard_dir():
    d = tempfile.mkdtemp(prefix="offline_guard_")
    os.makedirs(os.path.join(d, "yfinance"))
    with open(os.path.join(d, "yfinance", "__init__.py"), "w", encoding="utf-8") as f:
        f.write(GUARD)
    with open(os.path.join(d, "sitecustomize.py"), "w", encoding="utf-8") as f:
        f.write(SITE)
    return d


def _kill_tree(proc):
    """Kill a driver and every process it started (joblib and loky workers too)."""
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
    else:
        proc.kill()
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        pass


def suspects(out):
    """Lines of a driver's output that look like a caught error."""
    return [l.strip() for l in out.splitlines() if SUSPECT.search(l) and not BENIGN.search(l)]


def run_one(path, guard, timeout, live=False, log_dir=None):
    flag = os.path.join(guard, "touched_" + os.path.basename(path) + ".flag")
    env = dict(os.environ, PYTHONIOENCODING="utf-8", STOCKAPP_QUIET="1", MPLBACKEND="Agg")
    if not live:
        env.update(PYTHONPATH=guard + os.pathsep + os.environ.get("PYTHONPATH", ""),
                   OFFLINE_GUARD_FLAG=flag)
    # Output goes to a file, not a pipe: a driver's worker processes can keep a
    # pipe open after the driver exits, and reading it then never returns (two
    # drivers "timed out" after 9.5 hours that way, with their results written).
    log = os.path.join(log_dir or guard, os.path.basename(path) + ".log")
    t0 = time.time()
    with open(log, "w", encoding="utf-8", errors="replace") as f:
        proc = subprocess.Popen([sys.executable, path], cwd=ROOT, env=env, stdout=f,
                                stderr=subprocess.STDOUT)
        try:
            code = proc.wait(timeout=timeout)
            status = None
        except subprocess.TimeoutExpired:
            _kill_tree(proc)
            code, status = None, "TIMEOUT"
    with open(log, encoding="utf-8", errors="replace") as f:
        out = f.read()
    if status is None and live:
        status = "ok" if code == 0 else "FAILED"
    if status is None:
        touched = MARK in out or os.path.exists(flag)
        # A driver that needed live data is BLOCKED even if it caught the error
        # and exited 0: its "ok" would be a run on no data.
        status = "BLOCKED" if touched else ("ok" if code == 0 else "FAILED")
    return os.path.basename(path), status, time.time() - t0, out


def compare(old, new):
    """How a fresh CSV differs from the stored one."""
    try:
        a, b = pd.read_csv(old), pd.read_csv(new)
    except Exception as e:                       # noqa: BLE001
        return f"unreadable ({e.__class__.__name__})"
    if a.shape != b.shape or list(a.columns) != list(b.columns):
        return f"shape {a.shape} -> {b.shape}"
    if a.equals(b):
        return "identical"
    num = a.select_dtypes("number").columns
    other = [c for c in a.columns if c not in num]
    if other and not a[other].astype(str).equals(b[other].astype(str)):
        return "text columns differ"
    x, y = a[num].to_numpy(float), b[num].to_numpy(float)
    both_nan = np.isnan(x) & np.isnan(y)
    diff = np.where(both_nan, 0.0, np.abs(x - y) / np.maximum(np.abs(x), 1e-12))
    worst = float(np.nanmax(diff)) if diff.size else 0.0
    return "same within 1e-6" if worst < 1e-6 else f"max relative difference {worst:.2e}"


def _digest(path):
    import hashlib
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _ledger(names, purpose):
    """One row per live driver in bhavcopy's holdout ledger, written before it runs."""
    if ROOT not in sys.path:
        sys.path.insert(0, ROOT)
    import bhavcopy
    path = bhavcopy.HOLDOUT_LEDGER
    rows = pd.DataFrame([{"opened_at_utc": pd.Timestamp.now("UTC").isoformat(timespec="seconds"),
                          "end": pd.Timestamp.now().date().isoformat(), "purpose": purpose.strip(),
                          "script": n} for n in names])
    rows.to_csv(path, mode="a", header=not os.path.exists(path), index=False)
    print(f"  {len(rows)} rows appended to {os.path.relpath(path, ROOT)}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Re-run research drivers offline and check they reproduce.")
    ap.add_argument("names", nargs="*", help="driver names (default: every run_*.py)")
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--keep", action="store_true", help="keep fresh CSVs instead of restoring the originals")
    ap.add_argument("--allow-live", action="store_true",
                    help="no guard: the named drivers may read live prices to today (the reserved "
                         "period); each run is written to the holdout ledger")
    ap.add_argument("--ledger", nargs="*", default=None,
                    help="with --allow-live, the drivers that actually read past 2024 (default: all named)")
    ap.add_argument("--purpose", default="", help="why, for the holdout ledger (required with --allow-live)")
    a = ap.parse_args(argv)
    if a.allow_live and (not a.names or not a.purpose.strip()):
        ap.error("--allow-live needs the driver names and a --purpose")
    if a.allow_live and a.keep:
        ap.error("--allow-live never keeps fresh CSVs: they would put reserved-period data into published figures")
    paths = sorted(glob.glob(os.path.join(VALID, "run_*.py")))
    # The slowest first, so a parallel run finishes sooner.
    slow_first = ("run_multi_backtest.py", "run_full_backtest.py", "run_epistemic_eval.py")
    paths.sort(key=lambda p: (os.path.basename(p) not in slow_first, os.path.basename(p)))
    if a.names:
        want = {n if n.endswith(".py") else n + ".py" for n in a.names}
        paths = [p for p in paths if os.path.basename(p) in want]
    backup = tempfile.mkdtemp(prefix="validation_csv_")
    before = {}
    for f in glob.glob(os.path.join(VALID, "*.csv")):
        if os.path.basename(f) in PROTECTED:
            continue
        shutil.copy2(f, backup)
        before[os.path.basename(f)] = os.path.getmtime(f)
    guard = _guard_dir()
    log_dir = os.path.join(LOG_ROOT, time.strftime("%Y%m%d-%H%M%S") + ("-live" if a.allow_live else ""))
    os.makedirs(log_dir, exist_ok=True)
    results = []
    log_file = os.path.join(ROOT, ".prediction_log", "predictions.jsonl")
    log_before = _digest(log_file)
    mode = "LIVE: guard off" if a.allow_live else "yfinance blocked"
    print(f"{len(paths)} drivers, {a.jobs} at a time, {a.timeout}s each; {mode}; CSVs backed up")
    if a.allow_live:
        named = [os.path.basename(p) for p in paths]
        want = None if a.ledger is None else {n if n.endswith(".py") else n + ".py" for n in a.ledger}
        _ledger([n for n in named if want is None or n in want], a.purpose)
    try:
        with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
            futs = [ex.submit(run_one, p, guard, a.timeout, a.allow_live, log_dir) for p in paths]
            for fut in cf.as_completed(futs):
                name, status, secs, out = fut.result()
                results.append((name, status, secs, out))
                n_sus = len(suspects(out)) if status == "ok" else 0
                print(f"  {status:<8}{secs:7.0f}s  {name}" + (f"   ({n_sus} suspect lines)" if n_sus else ""),
                      flush=True)
    finally:
        changed = []
        for f in glob.glob(os.path.join(VALID, "*.csv")):
            b = os.path.basename(f)
            if b in PROTECTED:
                continue
            if b in before and os.path.getmtime(f) != before[b]:
                changed.append((b, compare(os.path.join(backup, b), f)))
            elif b not in before:
                changed.append((b, "new file"))
        if not a.keep:
            for b, _ in changed:
                src = os.path.join(backup, b)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(VALID, b))
                else:
                    os.remove(os.path.join(VALID, b))
        shutil.rmtree(guard, ignore_errors=True)

    print("\nThe forward prediction log is " + ("unchanged." if _digest(log_file) == log_before
                                                 else "CHANGED during the run - check it."))
    print("Summary:", ", ".join(f"{s} {sum(r[1] == s for r in results)}"
                                  for s in ("ok", "BLOCKED", "FAILED", "TIMEOUT")))
    for name, status, _, out in sorted(results):
        if status in ("FAILED", "TIMEOUT"):
            tail = "\n      ".join(out.strip().splitlines()[-8:])
            print(f"\n  {status} {name}:\n      {tail}")
    flagged = [(n, suspects(o)) for n, st, _, o in sorted(results) if st == "ok" and suspects(o)]
    if flagged:
        print("\nExited 0 but printed lines that look like caught errors (read them; full logs in "
              + os.path.relpath(log_dir, ROOT) + "):")
        for n, lines in flagged:
            print(f"  {n}: {len(lines)}")
            for line in list(dict.fromkeys(lines))[:6]:
                print(f"      {line[:160]}")
    print(f"\nFull output of every driver: {os.path.relpath(log_dir, ROOT)}")
    if changed:
        print("\nResult CSVs the drivers rewrote, against the stored versions"
              + ("" if a.keep else " (originals restored)") + ":")
        for b, verdict in sorted(changed):
            print(f"  {b:<44} {verdict}")
    return 0 if not any(r[1] in ("FAILED", "TIMEOUT") for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
