# `tools/` — research scaffolding

Small command-line utilities for *working on* this project. Each one exists
because it was written into a scratchpad, thrown away, and written again.

**These are not part of the product.** Nothing the app imports may import from
here, and the research drivers in `tests/validation/` deliberately keep their
own explicit setup so a reader can follow the order of operations. If something
here becomes load-bearing, it belongs in a real module with tests.

| Tool | Answers |
|---|---|
| [`book.py`](book.py) | What does this PDF say? |
| [`check.py`](check.py) | Do the repo and its two documents still agree? |
| [`collect_option_chains.py`](collect_option_chains.py) | Record today's option chains, because NSE keeps no history. |
| [`holdout_power.py`](holdout_power.py) | Could the reserved period confirm this lead, or would it waste the one shot? |
| [`panel.py`](panel.py) | Give me the NSE panel, fast, and tell me what is odd about it. |
| [`run_drivers.py`](run_drivers.py) | Do the research drivers still run and reproduce, without touching the reserved period? |
| [`ui_check.py`](ui_check.py) | Does the app work at every screen size, and when it is used? |
| [`splice.py`](splice.py) | Edit a file at a marker without a shell mangling it. |

---

## `book.py` — read a PDF without poppler

The editor's PDF reader shells out to `pdftoppm`, which is not installed here,
so `Read` on a PDF fails outright. PyMuPDF is installed and extracts text
directly.

```bash
python tools/book.py --list                       # the 27 books available
python tools/book.py tsang --toc                  # find and print the contents
python tools/book.py tsang --pages 93-101
python tools/book.py kaabar --search "fractional"
python tools/book.py hilpisch --outline           # embedded bookmarks
```

The name is any unambiguous case-insensitive fragment of the filename.
Ambiguous fragments list the candidates rather than guessing.

`--toc` matters more than it looks: printed page numbers disagree with PDF page
numbers by however long the front matter is, so "the contents are on page 9" is
usually wrong by two to six pages. It searches for the heading *and* for the
number-column shape that contents pages have, which handles the common case
where extraction puts the chapter title and its page number on separate lines.

`Books/` is gitignored — copyrighted, ~349 MB — so the tool ships and the books
do not. It says so clearly when the folder is absent.

---

## `check.py` — the things tests do not catch

Every check here is a mistake actually made in this project and then re-checked
by hand on every subsequent edit.

```bash
python tools/check.py                  # ~2 seconds
python tools/check.py --tests          # + collect the suite (slow, imports TF)
python tools/check.py --only anchors,pins
```

| Check | Catches |
|---|---|
| `syntax` | any `.py` that stopped parsing |
| `anchors` | `](#...)` links to headings that do not exist — three at once while writing §44, and one that had been broken far longer |
| `ordinals` | two sections both claiming "the *n*th negative result", a tally maintained by hand across 2,500 lines |
| `docx` | a README section with no counterpart in `generate_docx.js`, which is a separate script and therefore diverges silently |
| `pins` | `requirements.txt` drifting from the installed environment — the drift that took eight libraries down and made `fracdiff.adf_pvalue` return `NaN` without raising |
| `tests` | a stated test count left stale after tests were added *(opt-in)* |

Exits non-zero on any problem, so it can gate a commit. None of these breaks a
test, which is exactly why they survive.

The README↔docx chapter offset (README §43 = docx 3.44) is recorded as
`DOCX_OFFSET` rather than rediscovered.

---

## `collect_option_chains.py` — the option history NSE does not keep

Nothing option-based in this project can be backtested, because NSE publishes
no option-chain history (README §48, §64). This records it, one snapshot a day
per F&O stock, so that in six to twelve months the question can be asked
properly: does single-stock implied volatility make the cones better?

```bash
python tools/collect_option_chains.py                     # all ~213 F&O stocks, ~4 minutes
python tools/collect_option_chains.py --symbols TCS,INFY  # a few
python tools/collect_option_chains.py --dry-run           # fetch, write nothing
```

Rows go to `.option_history/option_chains.csv`: per stock and expiry, the spot
price, the at-the-money strike, call and put prices, the parity forward, the
straddle-implied volatility, and total call and put open interest. Re-running on
the same day adds nothing. Schedule it daily after the close, for example as a
Windows Task Scheduler entry running the command from the project folder.

The tool is a thin CLI. The logic is `option_market.collect_snapshots`, which is
tested like product code: under this folder's own rule, anything load-bearing
belongs in a real module with tests.

---

## `holdout_power.py` — would the reserved period settle it?

```bash
python tools/holdout_power.py                    # the period from 2025-01-01 to today, less a quarter
python tools/holdout_power.py --years 0.48       # e.g. Jul-Dec 2024, unused and not reserved
python tools/holdout_power.py --bar 2.24         # two tests, Bonferroni
```

The reserved period can be spent once, and several leads are queued for it.
A t-statistic grows with the square root of time, so a lead found at `t` over
`Y` years has an expected `t * sqrt(H / Y)` over a holdout of `H` years, and a
chance of about `Phi(E[t] - bar)` of clearing the bar. That is optimistic: a lead
picked for looking significant overstates itself, most when it was one of many
tests (the last column). Add a candidate to `CANDIDATES` and re-run. Built for
the Ch. 6 scorecard in README §67.

---

## `run_drivers.py` — re-run the drivers, offline and safely

```bash
python tools/run_drivers.py                      # every run_*.py, 2 at a time
python tools/run_drivers.py run_oneil --keep     # one driver, keep its fresh CSV
python tools/run_drivers.py --jobs 3 --timeout 10800
```

Each driver runs in its own process with yfinance replaced by a stand-in that
raises, `safe_fetch`'s fallback cache emptied and `get_data`'s live fetchers
blocked, so none can read the reserved period; a driver that tried is reported
`BLOCKED` even if it caught the error. Output goes to a file and a timeout kills
the whole process tree (a pipe held open by worker processes once hung a run for
hours). Result CSVs are backed up, compared with the fresh output (`identical`,
`same within 1e-6`, or the largest difference) and restored unless `--keep`.
Every driver's full output is kept in `.driver_logs/` and scanned for errors a
driver caught and printed while still exiting 0.

```bash
python tools/run_drivers.py run_spa run_full_backtest --allow-live     --purpose "why the reserved period is being read"
```

`--allow-live` is for the drivers that need live prices, which read the reserved
period: it needs the owner's approval and a stated purpose, writes one row per
driver to `tests/validation/holdout_ledger.csv` before starting (`--ledger`
names the ones that really read past 2024), always restores the result CSVs
(`--keep` is refused), checks the prediction log's checksum, and never touches
the ledger itself. Built for the README §68 audit.

---

## `ui_check.py` — the app at every screen size, and in use

```bash
python tools/ui_check.py scenarios                            # AppTest interaction scenarios
python tools/ui_check.py browser                             # starts its own app, log off
```

`AppTest` runs `UI.py` and its widgets but renders nothing, so it cannot see a
legend covering a chart or a table cut off on a phone; a browser can, but cannot
cheaply drive many scenarios. This does both. `scenarios` covers Reset, an empty
Submit, daily and hourly runs, and a threshold change after results. It replaces
`prediction_log.log_forecast` with a counter, so it never writes the real log, and
exits non-zero if a re-run logs the forecast again, Reset misses its defaults, or a
daily run lacks the company check or the stock screens (README §67).
`browser` (Playwright with the installed Chrome) submits one quick run, then at
390 / 820 / 1366 / 1920 / 2560 px saves screenshots to `.ui_check/`, checks that
the page never scrolls sideways and that no chart or visible table is wider than
the screen, and reads the Submit/Reset colours. Built for the README §66 audit.

---

## `panel.py` — the NSE panel in one call

Every driver and every ad-hoc check opens with the same twelve lines: fetch
corporate actions over a lookback, `build_panel`, group by symbol, take
`adj_close`, sort, drop non-positive prices, drop short series. Each step fails
quietly when wrong — forget the action lookback and a 1:10 split becomes a −90%
return.

```bash
python tools/panel.py                              # summary + audit
python tools/panel.py --start 2022-01-01 --n 400
python tools/panel.py --refresh                    # ignore the cache
```

```python
import sys; sys.path.insert(0, "tools")
import panel
series = panel.by_symbol()        # {symbol: adjusted close Series}
df, rep = panel.load()            # the raw long panel
```

Defaults are the window and universe size the published sections use
(2022-01-01 → 2024-06-30, n=400), so an ad-hoc check measures the same thing
the drivers did. Builds take 30–60s; results are cached to `.panel_cache/`
keyed on the parameters, which is the difference between checking something
properly and checking it against yfinance because that was faster.

### What the audit found

Building this surfaced a real issue. The liquidity screen selects on
**turnover**, and NSE ETFs trade in the same series as equities, so the
universe contains four of them:

| Symbol | Annualised vol | Zero-return days | |
|---|---|---|---|
| `LIQUIDBEES` | **0.0%** | **53.9%** | money-market fund, near-constant price |
| `GOLDBEES` | 11.6% | 1.8% | gold tracker |
| `NIFTYBEES` | 12.8% | 0.2% | **the index itself** |
| `BANKBEES` | 16.2% | 0.2% | bank index tracker |

An index tracker inside a *stock-selection* cross-section is a category error —
it is the thing being selected against, not a candidate. `LIQUIDBEES` is a cash
equivalent that cannot be ranked against a stock at all.

They are **reported, never silently dropped**: at ~4 names in 400 the effect on
any published figure is negligible, and quietly changing the universe would
make README §38–§44 irreproducible. The right fix, if it is ever worth making,
is an instrument-type filter in `bhavcopy.liquidity_screen` with the affected
sections re-run and their numbers updated — not a quiet exclusion here.

### Precision, on the research path

`data_quality.py` raises `COARSE_PRICE_GRID` (README §46) for names whose tick
is a material share of a daily move — but only on the **app** path. The
research path (`bhavcopy.build_panel` → the drivers) never calls that gate, and
the coarse names are in the panel: `MERCATOR`, `UNITECH` and `RCOM` all sit in
the 400-name universe with roughly half their daily returns exact duplicates of
another day's.

So the audit reports the same dimension here:

```
  COARSE PRICE GRID -- returns are materially quantised:
    LIQUIDBEES     Rs  1,000.0  tick 0.01  grid is  139% of a daily move
    IDEA           Rs      9.2  tick 0.04  grid is   13% of a daily move
    SUZLON         Rs      9.7  tick 0.05  grid is   12% of a daily move
```

Reported, left in — the same rule as the ETFs. §46 measured the reversal signal
inside every precision quintile and found it present at all of them, so
dropping these names would change the published universe without changing a
result. The tick is read from the **unadjusted** close: corporate-action
adjustment multiplies prices by a non-integer factor and destroys the grid.
---

## `splice.py` — edit a file at a marker, without a shell in the way

Inserting a documentation section or replacing a function body is the most
repeated operation in this project, and it kept being done by piping a Python
script through a bash heredoc. That failed three times in one session, and the
third failure was silent and destructive:

```
r"\bthe (" + "|".join(_ORDINALS) + ...     what was written
r"<0x08>the (" + ...                       what landed in the file
```

The heredoc turned the two characters `\b` into a single **backspace control
character**. The regex then matched nothing, so `check_ordinals` reported
`[ ok ]` on every run — *including runs where the document was wrong* — and it
was only caught by deliberately planting a duplicate and noticing the check
still passed.

The bug class is "text containing escapes passes through a shell". This removes
the shell: the payload is read from a **file**, byte for byte.

```bash
# insert before / after the line containing a marker
python tools/splice.py README.md --before "## Reading the screen" --payload new.md

# replace from START's line up to (not including) END's — Python slice semantics
python tools/splice.py README.md --between "#### The null" "### 45." --payload x.md

# delete that span
python tools/splice.py tools/check.py --between "def old(" "def next(" --delete

# look first
python tools/splice.py README.md --before "## Caveats" --payload x.md --dry-run
```

Markers match as a **substring of a line**, which is how you actually remember
them; `--regex` switches to a pattern, `--occurrence N` picks among duplicates.

### Four guards, each earned

| Guard | Prevents |
|---|---|
| **Control characters rejected** — in the payload *and* in the result | The exact bug above. It cannot be committed now. |
| **Markers must be unique** | An ambiguous marker is an error listing every match, never a guess. Silently taking the first match is how an edit lands in the wrong section. |
| **The edit is verified after writing** | A splice that quietly changed nothing is the second-worst outcome after one that corrupted something. Both now fail loudly. |
| **Syntax checked** — `ast` for `.py`, `node --check` for `.js` | A file that stopped parsing is reported with its backup path, rather than discovered later. |

A `.splicebak` is kept beside the file unless `--no-backup` is passed.

### It tests itself, and `check.py` runs that test

`python tools/splice.py --selftest` exercises all ten behaviours on temporary
files. It is also wired in as the `tools` check, so it runs with everything
else rather than waiting to be remembered — a guard nobody tests is decoration,
which is the whole lesson of the bug that prompted this.

Verified the way the original failure should have been: sabotage the
control-character guard, and the check reports
`splice guard failed -- control_chars_rejected: a backspace character was accepted`.
