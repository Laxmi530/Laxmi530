"""
Record NSE's option chains, one snapshot a day, so they can be tested later.

Why this exists
---------------
NSE keeps no option-chain history, which is the one reason nothing option-based
in this project can be backtested (README sections 48 and 64): not whether
single-stock implied volatility would make the cones better, not whether the
put/call ratio (Thomsett, *Stock Market Math*, Ch. 8) forecasts anything. The
only way to get that history is to record it, the same way the prediction log
records forecasts. A year of daily snapshots is ~250 dates x ~210 names, enough
for a pre-registered test.

Each row is one stock and expiry: spot, the at-the-money strike, call and put
prices, the parity forward, the straddle-implied volatility, and total call
and put open interest. Inputs are kept alongside the derived volatility so a
later study can recompute it a different way.

Usage
-----
::

    python tools/collect_option_chains.py                     # every F&O stock
    python tools/collect_option_chains.py --symbols TCS,INFY  # a few
    python tools/collect_option_chains.py --dry-run           # fetch, don't write

Run it once a day after the close (NSE's chain timestamps at 15:30 IST). On
Windows, a daily Task Scheduler entry running this command from the project
folder does it; the script is idempotent, so a second run the same day adds
nothing. A full run is ~210 names at about a second each.

It never touches the reserved bhavcopy holdout: this is new data from today on.
"""

import argparse
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

import option_market as om                 # noqa: E402

OUT = os.path.join(_ROOT, ".option_history", "option_chains.csv")


def fno_symbols():
    from nselib import capital_market
    return sorted(capital_market.fno_equity_list()["symbol"].astype(str).str.upper())


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--symbols", help="comma-separated NSE symbols (default: every F&O stock)")
    ap.add_argument("--out", default=OUT)
    ap.add_argument("--pause", type=float, default=1.0)
    ap.add_argument("--expiries", type=int, default=2)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    syms = [s.strip().upper() for s in a.symbols.split(",")] if a.symbols else fno_symbols()
    print(f"collecting {len(syms)} option chains -> {a.out}{' (dry run)' if a.dry_run else ''}")
    n, failures = om.collect_snapshots(syms, a.out, a.pause, a.expiries, a.dry_run)
    print(f"{n} new rows; {len(failures)} failures"
          + (": " + ", ".join(f"{s} ({why})" for s, why in failures[:10]) if failures else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
