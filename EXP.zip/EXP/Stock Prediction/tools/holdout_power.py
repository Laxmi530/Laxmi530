"""
How much power would the reserved period have to confirm each candidate?

Why this exists
---------------
The reserved final-test period (from 2025-01-01, README section 21) can be
spent once. Five leads are queued for it, each found with some t-statistic
over some number of years before 2025. If the in-sample effect were exactly
the true one, a t-statistic grows with the square root of time, so the
expected t over a holdout of ``H`` years is ``t_in * sqrt(H / years_in)``, and
the chance of clearing a two-sided bar is about ``Phi(E[t] - bar)``. That is
an OPTIMISTIC power: a lead chosen because it looked significant overstates
its own effect (the winner's curse), most for the leads picked from many
tests. Written for the Hough Ch. 6 scorecard (README section 67), kept so a
new candidate can be added to :data:`CANDIDATES` and the table re-run.

Usage
-----
::

    python tools/holdout_power.py                    # holdout to today, alpha 0.05
    python tools/holdout_power.py --years 1.5 --bar 2.24
"""

import argparse
import math

import pandas as pd

HOLDOUT_START = pd.Timestamp("2025-01-01")

#: (name, README section number, in-sample |t|, years of in-sample data behind it, tests it was one of)
CANDIDATES = [
    # Confirmed out of sample on Jul-Dec 2024 (IC -0.0276, t -2.33, README section 67).
    ("Residual reversal, k = 5", "49", 7.75, 5.5, 3),
    ("52-week high (rank IC)", "53", 1.89, 5.5, 1),
    ("Dividend payer vs non-payer", "60", 2.06, 5.25, 4),
    ("Heavy-volume 50-day break", "65", 2.55, 6.5, 20),
    ("Insider buying (Ch. 19 screen)", "67", 1.40, 5.25, 1),
]


def _phi(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def power_table(holdout_years, bar=1.96, power_target=0.80):
    rows = []
    z_target = bar + 0.8416 if abs(power_target - 0.80) < 1e-9 else bar + _inv_phi(power_target)
    for name, sec, t, yrs, tests in CANDIDATES:
        et = t * math.sqrt(holdout_years / yrs)
        rows.append({"candidate": name, "section": sec, "t_in_sample": t, "years_in_sample": yrs,
                     "one_of_n_tests": tests, "expected_t": et, "power": _phi(et - bar),
                     "years_for_even_odds": yrs * (bar / t) ** 2,
                     "years_for_80pct": yrs * (z_target / t) ** 2})
    return pd.DataFrame(rows)


def _inv_phi(p):
    lo, hi = -10.0, 10.0
    for _ in range(100):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if _phi(mid) < p else (lo, mid)
    return (lo + hi) / 2


def main(argv=None):
    ap = argparse.ArgumentParser(description="Optimistic power of the reserved period for each candidate.")
    ap.add_argument("--years", type=float, default=None,
                    help="holdout length in years (default: 2025-01-01 to today, less a quarter for the horizon)")
    ap.add_argument("--bar", type=float, default=1.96, help="two-sided |t| bar (2.24 for two tests)")
    a = ap.parse_args(argv)
    years = a.years if a.years is not None else (pd.Timestamp.now() - HOLDOUT_START).days / 365.25 - 0.25
    df = power_table(years, a.bar)
    print(f"Holdout of {years:.2f} years, bar |t| > {a.bar}; optimistic (assumes the in-sample effect is true)\n")
    print(df.to_string(index=False, formatters={
        "expected_t": "{:.2f}".format, "power": "{:.0%}".format,
        "years_for_even_odds": "{:.1f}".format, "years_for_80pct": "{:.1f}".format}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
