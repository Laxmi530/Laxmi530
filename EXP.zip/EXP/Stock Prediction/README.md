# Stock Price Forecasting App

A multi-model stock-price forecasting toolkit built with **Streamlit**, targeting **Indian markets (NSE/BSE)** with support for global tickers. The app runs **20 forecasting models** in parallel — spanning statistical, machine-learning, deep-learning, ensemble, and foundation-model approaches — presents interactive Plotly comparisons, and ships with a **walk-forward backtesting harness** that measures every model against the only honest yardstick for stock prices: the naive random walk.

> **Disclaimer:** This project is for educational and research purposes only. Predictions are **not** financial advice.

---

## Table of Contents

1. [What this project does](#what-this-project-does)
2. [Models](#models)
3. [Project structure](#project-structure)
4. [Concepts explained](#concepts-explained) — *the educational core*
   - [The forecasting problem and what "robust" means](#1-the-forecasting-problem-and-what-robust-means)
   - [Predict log returns, not prices](#2-predict-log-returns-not-prices)
   - [Feature engineering](#3-feature-engineering)
   - [Robustness to outliers](#4-robustness-to-outliers)
   - [Recursive vs. direct multi-horizon forecasting](#5-recursive-vs-direct-multi-horizon-forecasting)
   - [Avoiding data leakage](#6-avoiding-data-leakage-look-ahead-bias)
   - [Volatility and uncertainty: GARCH + Monte Carlo](#7-volatility-and-uncertainty-garch--monte-carlo)
   - [Quantile regression](#8-quantile-regression)
   - [Conformal prediction](#9-conformal-prediction-distribution-free-intervals)
   - [The cross-family meta-ensemble](#10-the-cross-family-meta-ensemble)
   - [Model-by-model summary](#11-model-by-model-summary)
   - [Volatility forecasting with HAR-RV](#12-volatility-forecasting-with-har-rv)
   - [Confidence, abstention, and risk outputs](#13-confidence-abstention-and-risk-outputs)
   - [Validating the uncertainty (calibration)](#14-validating-the-uncertainty-calibration)
   - [Data-snooping-robust model selection (Reality Check & SPA)](#15-data-snooping-robust-model-selection-reality-check--spa)
   - [Currency conversion to INR and its audit trail](#16-currency-conversion-to-inr-and-its-audit-trail)
   - [Input data-quality gating](#17-input-data-quality-gating)
   - [Price-adjustment hygiene (adjusted vs. raw close)](#18-price-adjustment-hygiene-adjusted-vs-raw-close)
   - [Forward-looking volatility from India VIX](#19-forward-looking-volatility-from-india-vix)
   - [Downside risk: semivariance, expected shortfall, and the asymmetric cone](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)
   - [Operational robustness: reproducibility, resilient fetch, event-risk gating](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)
   - [Economic evaluation: does the forecast make money?](#22-economic-evaluation-does-the-forecast-make-money)
   - [Deep volatility forecasting (Vol-LSTM) and CNN-LSTM](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)
   - [Value-at-Risk estimation and VaR backtesting](#24-value-at-risk-estimation-and-var-backtesting)
   - [Regime novelty from a denoising autoencoder](#25-regime-novelty-from-a-denoising-autoencoder)
   - [Book coverage: what was taken, what was left, and why](#26-book-coverage-what-was-taken-what-was-left-and-why)
   - [Hyperparameter search, nested so it cannot cheat](#27-hyperparameter-search-nested-so-it-cannot-cheat)
   - [Going live: the forward prediction log and paper portfolio](#28-going-live-the-forward-prediction-log-and-paper-portfolio)
   - [Cross-sectional classification: pooling the universe](#29-cross-sectional-classification-pooling-the-universe)
   - [Testing the abstention claim: class weighting, and a t-statistic that was wrong](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong)
   - [Architecture as configuration, and the hole it closed in the manifest](#31-architecture-as-configuration-and-the-hole-it-closed-in-the-manifest)
   - [Fundamentals: the right experiment, blocked by data](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)
   - [Epistemic uncertainty and psychological tolerance (Klaas)](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result)
   - [The Kalman filter: the model class that was missing](#34-the-kalman-filter-the-model-class-that-was-missing)
   - [Feature drift and attribution](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)
   - [Fractional differentiation](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result)
   - [The Diebold-Mariano kernel fix](#37-the-diebold-mariano-kernel-fix-and-the-windows-race-it-uncovered)
   - [Universe expansion: point-in-time data, and the first positive result](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)
   - [Costing the reversal signal: the eleventh negative result](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)
   - [Range-based volatility (Sharma & Mehta Ch. 18)](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result)
   - [Open interest, and a look-ahead worth 2.9 sigma](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result)
   - [Microstructural features (López de Prado Ch. 19)](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement)
   - [The Deflated Sharpe Ratio (AFML §14.7)](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39)
   - [Directional Change (Tsang Ch. 6): the fifteenth negative result](#44-directional-change-tsang-ai-for-finance-ch-6--the-fifteenth-negative-result-and-a-null-that-survived-three-controls)
   - [Event-based backtesting (Hilpisch Ch. 11)](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed)
   - [Price precision (Buzzelli Ch. 3), and a falsification of §38](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38)
   - [The identifier is not the ticker (Khraisha Ch. 3)](#47-the-identifier-is-not-the-ticker-khraisha-financial-data-engineering-ch-3--a-hole-in-the-survivorship-free-panel)
   - [Risk-neutral is not physical (Hilpisch Ch. 5)](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)
   - [Residual reversal (Tatsat Ch. 7), and a rebalance-phase artefact in §39](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)
   - [Jensen's inequality in expected shortfall (Sadr A.2.4), a units error in shipped code](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)
   - [A p-value is not the probability of no edge (Kanungo Ch. 4)](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4)
   - [Hilpisch's technical rules, optimised and tested: the Probability of Backtest Overfitting](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting)
   - [The 52-week high (Yan Ch. 8): the book has the sign backwards, and the data cannot settle it](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it)
   - [Monte Carlo noise in the cone (Hilpisch Ch. 12): variance reduction is for means, not tails](#54-monte-carlo-noise-in-the-cone-hilpisch-python-for-finance-ch-12--variance-reduction-is-for-means-not-tails)
   - [Cost of trade (Kanwar & Gupta): futures don't rescue reversal, and a train/serve skew in shipped code](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)
   - [Long memory and wavelets (Mariani & Florescu Ch. 5, 12–13): persistence that is the estimator's, and a forecast that is the future](#56-long-memory-and-wavelets-mariani--florescu-quantitative-finance-ch-5-1213--persistence-that-is-the-estimators-and-a-forecast-that-is-the-future)
   - [Synthetic returns (Hilpisch, RL for Finance Ch. 5): a test that a shuffle passes, and what the project's own generators keep](#57-synthetic-returns-hilpisch-reinforcement-learning-for-finance-ch-5--a-test-that-a-shuffle-passes-and-what-the-projects-own-generators-keep)
   - [Cross-check of §50–§57: what was re-verified, and five defects it found](#58-cross-check-of-5057--what-was-re-verified-and-five-defects-it-found)
   - [Full audit of §1–§57: every module read, every offline driver re-run, and what it found](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)
   - [Stops, dividends and factors (Mladjenovic Ch. 6, 15, 17): a stop is hit twice as often as the panel implied](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)
   - [A company check beside the forecast (Mladjenovic Ch. 3, 4, 21, App. B): the information the price models cannot see](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)
   - [Trailing stops and targets (Mladjenovic Ch. 17): the book's 8% trailing stop is hit within a quarter 96% of the time](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time)
   - [Breadth, break-even and balance-sheet trends (Thomsett, *Stock Market Math*): weak breadth forecasts a more volatile market, not a falling one](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)
   - [Results days and the options market (Benklifa, *Think Like an Option Trader*): a 95% band covered only 82% of one-day windows holding a results day](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)
   - [The O'Neil-disciple signals (Morales & Kacher): pocket pivots add nothing, and major gap-ups lag the market](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market)
   - [UI audit: every screen size, and five bugs, one of them duplicating the prediction log](#66-ui-audit-every-screen-size-and-five-bugs--one-of-them-duplicating-the-prediction-log)
   - [Stock screens (Hough, *Your Next Great Stock*): a falling stock's last week tells you nothing](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)
   - [Second end-to-end audit: a polluted prediction log, a mislabelled median, and a runner that cannot read the reserved period](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period)
   - [A 95% band for Hybrid ARIMA+LSTM: the last model without one, and two slow paths found on the way](#69-a-95-band-for-hybrid-arimalstm--the-last-model-without-one-and-two-slow-paths-found-on-the-way)
   - [The charts: a cone from the last close, trading days side by side, and every model on one chart](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)
   - [Adaptive conformal for every model, and the novelty gate in a real crash: neither earns its place](#71-adaptive-conformal-for-every-model-and-the-novelty-gate-in-a-real-crash--neither-earns-its-place)
   - [Third audit: a withheld row that blamed the model, a failed forecast that voted Bearish, and a banner ahead of its gate](#72-third-audit--a-withheld-row-that-blamed-the-model-a-failed-forecast-that-voted-bearish-and-a-banner-ahead-of-its-gate)
   - [The label-horizon paradox on the NSE panel: a shorter label scores better, and nothing can pick it](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it)
   - [Renamed companies lost their corporate actions](#74-renamed-companies-lost-their-corporate-actions)
   - [A no-trade band on the residual reversal: it trims turnover by 29% and still falls 4.6 bp short](#75-a-no-trade-band-on-the-residual-reversal--it-trims-turnover-by-29-and-still-falls-46-bp-short)
5. [The app: from a price line to honest uncertainty](#the-app-from-a-price-line-to-honest-uncertainty)
6. [Reading the screen: which numbers support a decision](#reading-the-screen-which-numbers-support-a-decision) — *the user's guide*
7. [Evaluation and backtesting](#evaluation-and-backtesting)
8. [Empirical findings](#empirical-findings)
9. [Shared modules reference](#shared-modules-reference)
10. [Getting started](#getting-started)
11. [Dependencies](#dependencies)
12. [Caveats and limitations](#caveats-and-limitations)

---

## What this project does

- **India-first company search** — merged NSE + BSE listings with automatic ticker resolution.
- **INR normalization** — each historical bar is converted to INR at **that date's own FX rate** (`USDINR=X` etc. from yfinance), not a single current rate, so returns/volatility aren't distorted; an open.er-api.com live rate is the fallback. The app shows an **auditable notice** of which conversion path was used (period-accurate historical vs. a degraded live-uniform rescale vs. unconverted) — see [§16](#16-currency-conversion-to-inr-and-its-audit-trail).
- **Daily and hourly forecasting** with a configurable horizon.
- **20 models** compared side-by-side in one run (pick any subset), each producing a price path and — for most models — a **calibrated 95% confidence band**.
- **Honest, uncertainty-first output:** a per-model **confidence gate** (High / Medium / Low / No-edge) backed by walk-forward skill vs. a random walk, an **abstention banner** when nothing beats the baseline, and a **Risk & Probability** panel (P(up), P(gain/loss > X%), VaR-style downside, 95% range).
- **Two dedicated volatility models (HAR-RV and Vol-LSTM)** — they forecast the *risk cone* where skill genuinely exists, rather than a point price.
- **Economic as well as statistical evaluation** — the backtest reports Sharpe, Sortino, information ratio, maximum drawdown and the information coefficient **net of transaction costs**, because "low RMSE" and "would have made money" are different claims.
- **Interactive Plotly charts** with history overlay, the 95% band, and the naive random-walk baseline drawn for reference, plus a styled summary comparison table.
- **A backtesting harness** (`backtest.py`, with CLI drivers in `tests/validation/`) that walk-forward-evaluates any model on real data and reports skill metrics, a baseline ladder, and a Diebold-Mariano significance test.
- **Automatic GPU/CPU selection** — the deep models and Chronos use a GPU when one is present, and fall back to CPU otherwise.

### Robustness work baked in

This codebase went through a deliberate robustness pass. The headline changes (all explained in [Concepts](#concepts-explained)):

- Neural nets now predict **returns**, not the raw price level, with the scaler fit on **training data only** (no look-ahead).
- The tree/ML models and the neural nets forecast multiple steps **directly** instead of feeding predictions back recursively — this removed large multi-step error accumulation.
- **Conformal prediction intervals** were added so 12 of 14 base models carry calibrated uncertainty.
- A **cross-family meta-ensemble** combines the most reliable models robustly.
- **Cross-sectional market context** (market/sector/VIX features, `market_context.py`) can be fed to every family — trees, neural nets, and ARIMAX — but a controlled backtest showed it did not improve 5-day forecasts, so it ships **off by default** (opt-in). See [Empirical findings](#empirical-findings). *(When switched on for **hourly** data it carried a look-ahead until [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found): index values are daily closes stamped at midnight, so a 10:15 bar received that day's 15:30 close. Intraday rows now take the previous session's values; the India-VIX tilt had the same flaw and the same fix.)*
- **Purged/embargoed validation** removes the label-overlap that was quietly inflating early-stopping and conformal-coverage numbers.
- **NSE-exchange-calendar-aware horizons** — forecast timestamps are generated from the real NSE trading calendar (`pandas_market_calendars`), so future dates skip weekends **and** exchange holidays; hourly forecasts land on genuine session bars (09:15–15:15, ~7 per trading day) instead of a naïve 9–16h grid. The horizon is chosen in **trading days** for both frequencies — for hourly the choice maps to *days × 7* session bars internally — so "5 days" means the same thing whether you forecast daily or hourly.
- **Intraday NSE-session features (hourly)** — the tree/ML models get bar-in-session, first/last-bar flags, return-since-open, overnight gap, and same-bar-yesterday return; all leak-free and train/serve-consistent (see [§3](#3-feature-engineering)), toggleable via `USE_INTRADAY_FEATURES`.
- **History-span surfacing** — the app reports the actual hourly lookback (bars/sessions/dates) and **warns when it's short**, since intraday history is provider-capped and hourly models train on far less data than daily.
- The backtest now grades against **stronger baselines** (drift, AR(1)) and runs a **Diebold-Mariano test** so an apparent edge is checked for statistical significance, not just a smaller RMSE.
- After the evidence showed point forecasts are mostly within noise, the product **pivoted to uncertainty-as-the-deliverable**: a confidence/abstention gate, a probability/risk panel, distribution-first framing, and a dedicated **HAR-RV volatility model** with a **conformalized** (distribution-free, per-horizon) cone that is now **adaptive (ACI)** — it responds to recent volatility regime shifts.
- The **risk panel now reads probabilities off the empirical, fat-tailed conformal distribution** (P(up), P(move), VaR), instead of re-imposing a normal distribution at the output — and the **directional Sentiment/Direction call is withheld** for any model the gate rates "No edge", so the app never asserts conviction its own tests don't support.
- A **calibration harness** (`calibration.py` / `run_calibration.py`) *validates* those probabilistic claims — **CRPS, PIT, reliability/ECE, coverage quality, and nested gate validation** — so the uncertainty is measured, not asserted. See [§14](#14-validating-the-uncertainty-calibration).
- An **input data-quality gate** (`data_quality.py`) scores every fetched series *before* it is trusted — missing/duplicate/stale candles, bad OHLC, zero-volume, abnormal gaps, short hourly span, currency status — and **abstains** (or drops to **risk-cone-only**, withholding directional calls) when the data is too poor, with explicit **reason codes** surfaced in the UI. See [§17](#17-input-data-quality-gating).
- The **no-edge finding is operationalized in the UI**: every model row carries a plain-language **Basis** reason code (tied to its Diebold-Mariano p-value / coverage / data-quality), and a standing notice states that the data-snooping-robust tests found no confirmed winner — so the table is never read as crowning a "best" model. See [§17](#17-input-data-quality-gating).
- A **price-adjustment hygiene audit** (`audit_price_adjustment.py`) quantified the only remaining look-ahead the reviewers flagged (training on yfinance's back-adjusted close) and confirmed it is immaterial for this return-based pipeline. See [§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close).
- A **forward-looking volatility input** (`iv_data.py`) can tilt the HAR-RV cone by the **India VIX** implied/realized ratio — the one signal HAR-RV's backward-looking realized variance structurally can't see. Single-name option IV proved unavailable for free, so this uses the reliably-free market-level VIX scaled by each stock's market linkage; it ships **off** after an A/B showed it coverage-neutral on calm data. See [§19](#19-forward-looking-volatility-from-india-vix).
- **Downside-risk reporting** (always on): the risk panel now reports **expected shortfall (CVaR)**, the **downside/upside realized-semideviation split**, and the **vol-skew** ratio off HAR-RV's empirical residual sample — the left-tail reads a risk user actually cares about. An optional **asymmetric cone** (`asymmetric=`) widens the downside edge when the loss tail is fatter; A/B-gated, ships off. See [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone).
- **Operational robustness** (the ship-readiness layer): **seed-pinned reproducibility** with an auditable per-run manifest (`reproducibility.py`); a **resilient data fetch** with retries, last-known-good cache fallback, and a source status the gate consumes (`safe_fetch.py`); **structured event-risk reason codes** (abnormal price/volume → withhold direction, show the cone); and the serving-gate logic extracted to a pure, unit-tested module (`gating.py`). See [§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating).
- **Economic evaluation** (`strategy_metrics.py`) answers the question the statistical metrics never did — *"would acting on this forecast have made money, after costs?"* — with Sharpe, Sortino, information ratio, maximum drawdown and the information coefficient, charged for transaction costs on every position change. `walk_forward_backtest` now returns a `strategy` block alongside the RMSE table, and flags overlapping trade windows instead of quietly reporting an optimistic Sharpe. See [§22](#22-economic-evaluation-does-the-forecast-make-money).
- **VaR estimation *and* VaR backtesting** (`var_models.py`): five estimators (Gaussian, historical simulation, Cornish-Fisher, filtered historical simulation, a block-bootstrap generative sampler) plus **Kupiec's proportion-of-failures** and **Christoffersen's independence / conditional-coverage** tests. The app reported a VaR before; it never *validated* one — and clustered breaches, which only the independence test catches, are the failure mode that actually matters. See [§24](#24-value-at-risk-estimation-and-var-backtesting).
- **Two model additions where the evidence says value can exist**: **Vol-LSTM** (`vol_lstm_model.py`), a deep counterpart to HAR-RV that can express non-linear variance dynamics and the leverage effect, with the same flat-point / conformal-cone contract; and **CNN-LSTM** (`CNN_LSTM_model.py`), an architecturally distinct sequence model (causal convolutions → recurrence). See [§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm).
- **A latent HAR-RV bias, found and fixed.** Scoring the raw *variance* forecast (not just the interval) revealed that HAR-RV was over-stating volatility by **~1.9×**: it converted its log-variance forecast to a level with the log-normal Jensen correction, which assumes a Gaussian residual, but a regression on `log(r²)` has a **log-χ²** residual. The conformal layer had been silently cancelling the error — coverage was fine, the *reported* volatility was not. `forecast_har_variance` now uses a data-estimated offset (`har_level_offset`); the fix is coverage- and width-neutral, moves HAR-RV from last to second on QLIKE, and is pinned by two regression tests. See [Empirical findings](#volatility-model-comparison--and-the-latent-har-rv-bias-it-exposed-now-fixed).
- A **regime-novelty gate** (`autoencoder_regime.py` + `gating.apply_novelty_gate`): a denoising autoencoder's reconstruction error detects when the current market state is **off-manifold** relative to what the models were fitted on, and withholds the directional call. This closes a real blind spot — a backtest-derived confidence bucket describes the *past* regime and says nothing about a novel present. See [§25](#25-regime-novelty-from-a-denoising-autoencoder).
- A **regression test suite** (`test_intraday_parity.py`, `test_data_quality.py`, `test_iv_data.py`, `test_har_downside.py`, `test_reproducibility.py`, `test_gates.py`, `test_safe_fetch.py`, `test_strategy_metrics.py`, `test_backtest_strategy.py`, `test_var_models.py`, `test_novelty_gate.py`, `test_new_models_smoke.py`) locks in the highest silent-bug risks: intraday-feature train/serve parity and leak-freeness, the data-quality gate, the VIX factor, the downside/semivariance math, seeded reproducibility, the **serving gates** (abstention / no-edge / **novelty** / conviction), the resilient-fetch fallback, the economic-metric arithmetic and its cost accounting, the VaR estimators and their calibration tests, and the new models' output contract (including a check that CNN-LSTM's convolutions are causal, i.e. cannot see forward inside the window).
- Shared logic was consolidated into reusable modules (`model_utils.py`, `direct_forecast.py`, `market_context.py`, `HAR_RV_model.py`, `vol_lstm_model.py`, `calibration.py`, `data_quality.py`, `iv_data.py`, `risk_metrics.py`, `strategy_metrics.py`, `var_models.py`, `autoencoder_regime.py`, `gating.py`, `reproducibility.py`, `safe_fetch.py`).

---

## Models

| # | Category | Model | Module | Forecast strategy | Intervals? |
|---|---|---|---|---|---|
| 1 | Statistical | Auto-ARIMA + GARCH (Monte Carlo) | `ARIMA_GARCH.py` | Simulation | ✅ |
| 2 | Statistical | ARIMAX + GARCH (exogenous + market context) | `ARIMAX_model.py` | Simulation | ✅ |
| 3 | Statistical | Markov Regime-Switching AR | `RegimeSwitching_model.py` | Simulation | ✅ |
| 4 | Prophet | Facebook Prophet | `fb_prophet_model.py` | Additive decomposition | ✅ |
| 5 | Machine Learning | XGBoost | `ML_model.py` | Direct multi-horizon | ✅ (conformal) |
| 6 | Machine Learning | LightGBM | `ML_model.py` | Direct multi-horizon | ✅ (conformal) |
| 7 | Ensemble | XGB + LGB + Ridge stacking | `Ensemble_model.py` | Direct multi-horizon | ✅ (conformal) |
| 8 | Quantile | LightGBM quantile regression | `Quantile_model.py` | Direct multi-horizon | ✅ (native) |
| 9 | Deep Learning | LSTM | `DL_model.py` | Direct multi-horizon | ✅ (conformal) |
| 10 | Deep Learning | GRU | `DL_model.py` | Direct multi-horizon | ✅ (conformal) |
| 11 | Deep Learning | Transformer | `Transformer_model.py` | Direct multi-horizon | ✅ (conformal) |
| 12 | Deep Learning | N-BEATS (capacity-reduced) | `NBeats_model.py` | Direct multi-horizon | ✅ (conformal) |
| 13 | Deep Learning | Temporal Convolutional Network | `TCN_model.py` | Direct multi-horizon | ✅ (conformal) |
| 14 | Hybrid | ARIMA + LSTM on residuals | `Hybrid_model.py` | Recursive | ✅ (conformal) |
| 15 | Foundation | Amazon Chronos-2 (+ covariates) | `chronos_model.py` | Native multi-step | ✅ |
| 16 | **Volatility** | **HAR-RV** (flat price + conformalized risk cone) | `HAR_RV_model.py` | Variance forecast | ✅ (conformal) |
| 17 | **Meta-ensemble** | **Median of Quantile-LGBM + XGBoost + ARIMA+GARCH** | `meta_ensemble.py` | Combination | ✅ |
| 18 | Deep Learning | **CNN-LSTM** (LSTM over a causal conv stack) | `CNN_LSTM_model.py` | Direct multi-horizon | ✅ (conformal) |
| 19 | **Volatility** | **Vol-LSTM** (deep counterpart to HAR-RV) | `vol_lstm_model.py` | Variance forecast | ✅ (conformal + ACI) |
| 20 | **State-space** | **Kalman** (damped local linear trend) | `kalman_model.py` | Filtered state, damped extrapolation | ✅ (native + conformal) |

**HAR-RV and Vol-LSTM are deliberately different:** they make *no directional claim* (their point forecast is the random walk) and their deliverable is the volatility cone — see [§12](#12-volatility-forecasting-with-har-rv) and [§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm). They will therefore show "No edge" in the confidence column by design; their value is the calibrated interval, not the price line.

Every model exposes the same entry point, `run_*_prediction(df, interval, horizon)`, and returns a DataFrame with at least `datetime` and `predicted_price` (plus `lower_bound`, `upper_bound`, `volatility` where intervals exist).

---

## Project structure

```
Stock Prediction/
├── run_app.py                # Launcher: installs any missing packages, then starts the app (run_app.bat on Windows)
├── dependencies.py           # Finds missing packages; installs them around the Prophet pin conflict (stdlib only)
├── UI.py                     # Streamlit app: model selection, confidence gate,
│                             #   risk panel, distribution-first charts, GPU label
├── charts.py                 # The forecast charts: cone from the last close, trading-day axis, all-models chart
├── get_data.py               # Data ingestion, ticker resolution, INR conversion
│
│   # ── Shared infrastructure (new) ─────────────────────────────
├── model_utils.py            # Shared helpers: features, RSI, GARCH, dates,
│                             #   conformal NN forecasting, GPU detection, training
├── direct_forecast.py        # Direct multi-horizon engine + conformal for tree models
├── market_context.py         # Market / sector / VIX context + excess-return hook (opt-in)
├── backtest.py               # Walk-forward backtest + baselines + DM test + confidence_bucket
├── data_quality.py           # Input data-quality scoring + reason-coded abstention gate
├── iv_data.py                # India-VIX forward-vol factor for the HAR-RV cone (opt-in)
├── risk_metrics.py           # Pure risk math: empirical P/VaR/CVaR/semideviation, log-normal fallback
├── strategy_metrics.py       # Economic evaluation: Sharpe/Sortino/IR/drawdown/IC, cost-aware
├── var_models.py             # VaR estimators (Gaussian/HS/CF/FHS/generative) + Kupiec & Christoffersen
├── autoencoder_regime.py     # Denoising autoencoder -> regime-novelty score for the gate
├── fracdiff.py               # Fractional differencing + ADF/KPSS stationarity testing
├── bhavcopy.py               # Point-in-time NSE prices from daily bhavcopy + corporate-action adjustment
├── range_volatility.py       # Parkinson/Garman-Klass/Rogers-Satchell/Yang-Zhang variance from OHLC
├── microstructure.py         # Corwin-Schultz spread, Roll, Amihud/Kyle impact from daily OHLCV
├── long_memory.py            # R/S Hurst (book + Anis-Lloyd-Peters), Lo's modified R/S, DFA, fGn
├── synthetic_check.py        # KS plus the stylized facts it can't see, for synthetic return paths
├── stops.py                  # Stop-loss risk: end-point vs reflection vs own-history touch probability, beta
├── corporate_events.py       # Announced ex-dividend dates inside a forecast horizon (the quoted-price drop)
├── stock_checklist.py        # Company check: Ch. 21's measurable hallmarks and App. B's ratio rules, live
├── breadth.py                # Market breadth from the bhavcopy: advance/decline, new highs/lows, live ad10
├── option_market.py          # Live NSE option chain: straddle IV, expected move, results-day move, protective put
├── oneil.py                  # O'Neil-disciple rules: pocket pivots, major gap-ups, distribution / follow-through days
├── hough.py                  # Hough's stock screens, survivor checks and sell signs for one stock, live
├── insiders.py               # SEBI insider-trading disclosures from NSE (both endpoints), and Ch. 19's screen
├── directional_change.py     # Event-based (threshold) sampling: DC events + lookahead-safe per-bar state
├── event_backtest.py         # Path-aware backtesting: MAE/MFE, stop-loss/take-profit/trailing, gap fills
├── tools/                    # Research scaffolding (NOT imported by the app or tests) -- see tools/README.md
│   ├── book.py               #   read a PDF without poppler; --toc finds the contents pages
│   ├── check.py              #   README anchors / section tally / docx parity / pin drift; exits non-zero
│   ├── collect_option_chains.py # one option-chain snapshot a day per F&O stock, so implied vol can be tested later
│   ├── panel.py              #   the NSE panel in one call, cached, with an instrument-type audit
│   ├── ui_check.py           #   the app in Chrome at 5 widths, and AppTest interaction scenarios
│   ├── holdout_power.py      #   how much power the reserved period has to confirm each queued candidate
│   ├── run_drivers.py        #   every research driver, unable to read the reserved period; results compared
│   └── splice.py             #   edit a file at a marker; rejects control chars, verifies, self-tests
├── feature_drift.py          # Input-distribution drift (permutation PSI + Wasserstein; KS reported)
├── explain.py                # Exact TreeSHAP attribution (no new dependency)
├── kalman_model.py           # Damped local-linear-trend state-space model (native + conformal bands)
├── epistemic.py              # MC-dropout model uncertainty (off by default; failed its cross-model check)
├── fundamentals.py           # Point-in-time fundamental features + coverage audit (look-ahead-proof as-of join)
├── architectures.py          # Declarative network specs + realised-architecture record for the manifest
├── config.py                 # Feature-flag registry + serve-time tunables (STOCKAPP_* env overrides)
├── console.py                # Terminal mirror of the decision layer: startup banner, run header, run summary
├── gating.py                 # Pure serving-gate logic: gated direction, conviction, dq + novelty override, reason codes
├── reproducibility.py        # Seed pinning (all RNGs) + auditable run manifest
├── safe_fetch.py             # Resilient fetch: retries + last-known-good cache + source status
├── meta_ensemble.py          # Cross-family median meta-ensemble
│
│   # ── Tests & validation (not used by the app; kept for reference) ─
├── tests/
│   ├── conftest.py           # pytest path bootstrap (adds repo root to sys.path)
│   ├── test_intraday_parity.py   # intraday-feature train/serve parity + leak-freeness
│   ├── test_data_quality.py      # data-quality gate reason codes & modes
│   ├── test_iv_data.py           # India-VIX factor leak-freeness, bounds, fallback
│   ├── test_har_downside.py      # semivariance split, asymmetric cone, downside metrics
│   ├── test_reproducibility.py   # seed determinism + run manifest
│   ├── test_gates.py             # confidence bucket / abstention / no-edge / conviction gates
│   ├── test_safe_fetch.py        # retries, cache fallback, source status
│   ├── test_strategy_metrics.py  # Sharpe/Sortino/IR/drawdown/IC + cost-aware strategy bundle
│   ├── test_backtest_strategy.py # economic-evaluation wiring in walk_forward_backtest
│   ├── test_var_models.py        # VaR estimators + Kupiec / Christoffersen backtests
│   ├── test_novelty_gate.py      # regime-novelty gate + pure autoencoder helpers
│   ├── test_new_models_smoke.py  # Vol-LSTM / CNN-LSTM / autoencoder contract tests (slow, needs TF)
│   ├── test_directional_change.py # DC events + the prefix-invariance proof that dc_state cannot peek
│   ├── test_event_backtest.py # path-dependent exits; each test fails toward optimism, not a crash
│   ├── test_price_precision.py # tick size vs daily move; the grid check must not force abstention
│   ├── test_market_context.py  # daily vs intraday as-of alignment: an hourly bar never sees the day's close
│   ├── test_arimax.py          # the regressors reach the model, lagged; meta-ensemble keeps its validated member
│   ├── test_chronos_offline.py # Chronos data prep makes no network call
│   ├── audit_price_adjustment.py # one-shot adjusted-vs-raw-close look-ahead audit
│   └── validation/           # manual evaluation/research drivers + their libraries (CLI, network, slow)
│       ├── calibration.py          # Calibration harness lib: CRPS, PIT, reliability/ECE, gate validation, ACI/IV/asym A/Bs
│       ├── multiple_testing.py     # Lib: White's Reality Check + Hansen's SPA (data-snooping-robust selection)
│       ├── cross_sectional.py      # Lib: cross-sectional ranking probe (rank-IC, long-short)
│       ├── run_full_backtest.py    # whole-suite backtest on one ticker
│       ├── run_multi_backtest.py   # variance-aware ranking across tickers
│       ├── run_cross_sectional.py  # cross-sectional signal probe over a universe
│       ├── run_calibration.py      # validate the uncertainty (CRPS / PIT / reliability / gate)
│       ├── run_spa.py              # SPA / Reality Check — does ANY model beat the random walk?
│       ├── run_stress_test.py      # ACI vs static cone across stress (2020/2022) vs calm windows
│       ├── run_strategy_eval.py    # economic leaderboard: Sharpe/Sortino/IR/drawdown after costs
│       ├── run_var_backtest.py     # VaR method comparison + Kupiec / Christoffersen tests
│       └── run_vol_comparison.py   # HAR-RV vs Vol-LSTM vs GARCH (QLIKE / CSE + cone A/B)
│
│   # ── Models ──────────────────────────────────────────────────
├── ARIMA_GARCH.py            # Auto-ARIMA + GARCH (Monte Carlo)
├── ARIMAX_model.py           # ARIMAX + GARCH with exogenous features
├── RegimeSwitching_model.py  # Markov regime-switching autoregression
├── fb_prophet_model.py       # Prophet
├── ML_model.py               # XGBoost / LightGBM (+ shared feature engineering)
├── Ensemble_model.py         # Stacking ensemble (XGB + LGB + Ridge)
├── Quantile_model.py         # LightGBM quantile regression
├── DL_model.py               # LSTM / GRU
├── Transformer_model.py      # Time-series Transformer
├── NBeats_model.py           # N-BEATS
├── TCN_model.py              # Temporal Convolutional Network
├── CNN_LSTM_model.py         # CNN-LSTM hybrid (LSTM over a causal conv stack)
├── Hybrid_model.py           # ARIMA + LSTM hybrid, split-conformal 95% band (§69)
├── chronos_model.py          # Amazon Chronos-2 foundation model
├── HAR_RV_model.py           # HAR realized-volatility model (conformalized cone)
├── vol_lstm_model.py         # Vol-LSTM: deep realized-volatility model (conformal + ACI cone)
│
├── requirements.txt
├── README.md                 # This file
├── generate_docx.js          # Builds Stock_Prediction_Documentation.docx from this README's
│                             #   material — re-run `node generate_docx.js` after doc changes
├── DOCUMENTATION.md          # SUPERSEDED older per-model reference (13-model era; see its banner)
└── Stock_Prediction_Documentation.docx  # Detailed Word documentation
```

---

## Concepts explained

This section explains every important idea in the codebase from first principles. You do **not** need a finance or ML background to follow it.

### 1. The forecasting problem and what "robust" means

A **time series** is a sequence of values ordered in time (here, a stock's daily or hourly price). Forecasting means predicting future values from past ones. Stock prices are notoriously hard because they behave close to a **random walk**: the best naive guess for tomorrow's price is *today's price*. Markets are largely **efficient** — most predictable patterns are already priced in.

This has a crucial consequence: **chasing a lower price error (RMSE) is often a losing game.** A model can look "accurate" simply by echoing the last price. So in this project, *robust* does **not** mean "lowest RMSE." It means:

1. **Never blow up** — no catastrophic forecasts on any ticker.
2. **Consistently match or beat the random walk** out-of-sample, across different stocks.
3. **Quantify uncertainty honestly** — produce confidence intervals that actually contain the truth ~95% of the time.

Everything below serves those three goals.

### 2. Predict log returns, not prices

A **log return** is `r_t = ln(P_t / P_{t-1})` — the percentage change between consecutive prices, in log space. We forecast returns instead of raw prices for two reasons:

- **Stationarity.** Raw prices trend and drift (their mean/variance change over time), which violates the assumptions of most models. Returns are roughly **stationary** (stable mean near zero), which models handle far better.
- **Scale-free.** A ₹50 stock and a ₹5,000 stock have comparable return distributions, so the same model and features transfer across tickers.

To recover a price from a return: `P_t = P_{t-1} · exp(r_t)`. For a multi-step forecast we predict a **cumulative log return** `ln(P_{t+h}/P_t)` and reconstruct `P_{t+h} = P_t · exp(cumulative return)`.

Originally the neural nets predicted the *scaled price level* directly; this was changed to returns because predicting the level on near-random-walk data makes the network simply echo the last price (the "persistence trap") and pushes future prices outside the scaler's fitted range.

### 3. Feature engineering

Models that take tabular inputs (XGBoost, LightGBM, ensembles, and the neural nets) are fed engineered **features** derived only from past prices/volume, so they never peek at the future. All are **scale-invariant** (ratios, returns, normalised indicators) so they generalise across price levels. Defined in `ML_model.create_features` (tabular) and `model_utils.compute_price_features` (sequence models):

- **Log returns** over several lags (1, 2, 3, 5, 10) — short-term momentum.
- **Moving-average ratios** (price / SMA) and **SMA-short / SMA-long** — trend direction.
- **Rolling volatility** at multiple windows — recent risk level.
- **RSI (Relative Strength Index)** via Wilder's smoothing — momentum oscillator (0–100) measuring the balance of up-moves vs. down-moves.
- **MACD** (normalised) — difference of fast/slow exponential moving averages; a trend/momentum signal.
- **Price z-score** — how far price sits from its recent mean, in standard deviations (a mean-reversion signal). A separate Bollinger-band position was removed: it was exactly half the z-score ([§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)).
- **ATR / range** — normalised intraday range (volatility proxy).
- **Volume ratio / change** — is today's volume unusual?
- **Calendar features** — day-of-week, month, hour (hourly only) — seasonality.
- **Intraday NSE-session features (hourly only)** — `bar_in_session` (0–6), `is_first_bar` / `is_last_bar`, `ret_since_open`, `overnight_gap` (today's open vs the previous session's close), and `same_hour_prev_day_ret` (vs the same bar one session ago). These capture genuine intraday structure (open/close auction effects, the overnight gap, intraday seasonality) that day-level features miss. They're **leak-free** (current-and-past only) and **train/serve-consistent** — computed identically in the vectorized `create_features` and the scalar `_features_from_buffers` (NSE sessions are 7 contiguous hourly bars, so "*N* bars back = same bar of an earlier session" is exact). They apply to the **tree/ML family** and can be A/B'd via `ML_model.USE_INTRADAY_FEATURES`.

The neural nets use a compact 9-feature matrix (price, log return, SMA ratio, two volatilities, RSI, momentum, z-score, acceleration), all computable from a price buffer so the same definitions apply during training and prediction. (The intraday-session features above are tree/ML-only — the NN feature matrix is datetime-less by construction.)

**Cross-sectional market context (`market_context.py`).** All of the features above are *self-referential* — derived from the stock alone. But short-horizon returns are dominated by the **market**: a stock's next move is mostly its **beta** times the index move plus a smaller stock-specific (alpha) component. Withholding the market is withholding the most predictable part of the return. So the pipeline fetches a market index (NIFTY 50 by default) and a volatility index (India VIX) and attaches eight **causal** context columns to the data once, up front:

- `mkt_ret_1`, `mkt_ret_5` — contemporaneous and trailing-5 index log return,
- `excess_ret_1` — stock return minus market return (an **alpha** proxy),
- `rel_strength_20` — trailing 20-period stock-minus-market strength,
- `beta_60`, `corr_60` — rolling 60-period beta and correlation to the index,
- `vix_change`, `vix_z_60` — volatility-index change and rolling z-score (a fear/regime gauge).

Because `create_features` carries extra columns through and `horizon_feature_cols` treats any non-raw, non-target column as a feature, the **tree, ensemble, and meta models consume these automatically**. The **neural nets** get the same context (concatenated onto their feature matrix inside `forecast_nn_direct`), and **ARIMAX** takes `mkt_ret_1`/`vix_change` as **exogenous regressors**. Every feature is contemporaneous or trailing (no look-ahead), missing index data is filled with a neutral 0 so context can never truncate the stock history, and if the index can't be fetched the data passes through unchanged.

> **Empirical caveat — this is off by default.** A controlled A/B backtest on Indian tickers (where NIFTY is the *correct* proxy) showed these features **did not improve 5-day forecasts** and **made the single tree models worse** (extra overfitting surface at this horizon — see [Empirical findings](#empirical-findings)). They therefore ship **disabled** (`USE_MARKET_CONTEXT = False` in `config.py`; `--with-context` flag on the backtest drivers). For a non-Indian ticker the NIFTY/India-VIX defaults are only an approximate proxy ([caveats](#caveats-and-limitations)).

> **Excess-return reframing was also tried — and also didn't help.** The reviewers' deeper idea was to predict the *excess* return (stock − market) instead of the absolute return (`market_context.add_market_index` attaches an `mkt_index` column; the direct target builders then subtract the market's cumulative return). A controlled A/B showed it **did not improve absolute-price RMSE** (it hurt the tree singles and was neutral for the ensemble). This is expected: because the expected short-horizon market move is ~0, reconstruction re-injects the unforecastable market noise, so the price error can't shrink unless de-noising made the alpha dramatically more learnable — which, on single stocks at a 5-day horizon, it didn't. It is therefore **off by default too** (no `mkt_index` is attached unless you opt in). The broader lesson: **market data helps cross-sectional/ranking problems, not single-stock absolute-price forecasting at this horizon.**

### 4. Robustness to outliers

Financial returns have **fat tails** — extreme moves happen far more often than a normal distribution predicts. Three defences are used:

- **Winsorization** (`model_utils.winsorize`) — clip values at the 1st/99th percentiles so a single crash/spike doesn't dominate training. The clip bounds can be fit on the training block only (`winsorize_bounds`) and reused on later data, keeping the preprocessing free of look-ahead bias.
- **Huber loss** — a loss function that behaves like squared error for small errors but like absolute error for large ones, so outliers don't dominate the gradient. Used by the gradient-boosting and neural models.
- **Fat-tailed GARCH innovations** — the volatility models can use Student-t / skewed-t distributions (see §7).

### 5. Recursive vs. direct multi-horizon forecasting

To forecast `h` steps ahead there are two strategies:

- **Recursive (iterative):** predict one step, append the prediction, recompute features, predict the next step, and so on. Simple, but **errors compound** — each step's mistake feeds into the next — and it can drift badly over the horizon.
- **Direct:** train the model to predict step `h` *directly* from the **observed** data at the origin (no feedback). For each horizon `h` we use the cumulative-return target `ln(P_{t+h}/P_t)`. Either train one model per horizon (tree models) or one network with `h` outputs (neural nets).

This project **switched the tree/ML models and the neural nets from recursive to direct**, which was the single biggest robustness win. In the backtest the gradient-boosted models improved ~25–34% in RMSE and moved from "worse than the random walk" to beating it. (Direct forecasting also implicitly fixed a one-bar origin offset that the recursive path had.)

- Tree models: `direct_forecast.py` (`make_horizon_targets`, `training_frame`, `compute_origin_row`).
- Neural nets: `model_utils.forecast_nn_direct` (a single network with `Dense(horizon)` outputs).

### 6. Avoiding data leakage (look-ahead bias)

**Data leakage** is when information from the future sneaks into training, inflating apparent accuracy and producing models that fail in the real world. Two specific fixes:

- **Scaler fit on training rows only.** A `MinMaxScaler` learns each feature's min/max. Originally it was fit on the *entire* series — including the validation period — leaking the future feature range. It is now fit on the **training portion only**, then applied to validation/recent data.
- **Targets are strictly future, features strictly past.** Rolling features use only past windows; the prediction target is a future return. For model *selection* the harness uses **walk-forward** splitting (see §[Evaluation](#evaluation-and-backtesting)), not random k-fold (which leaks across the time boundary).
- **Purged / embargoed validation for overlapping labels.** The direct multi-horizon target `ln(P_{t+h}/P_t)` spans `h` future bars, so the *last* training samples and the *first* validation/calibration samples share overlapping future windows — an overlap that quietly makes early-stopping `val_loss` and conformal coverage look better than reality. The pipeline now drops an **embargo gap** of `h` samples between the train block and the held-out block at all three internal split points: `temporal_train_val_split` (NN early stopping), `forecast_nn_direct` (NN conformal calibration), and `conformal_halfwidth` (tree conformal calibration). This is the same "purging" idea used in financial ML, applied wherever a future-spanning label is held out.

### 7. Volatility and uncertainty: GARCH + Monte Carlo

Stock volatility **clusters** — calm and turbulent periods come in runs. **GARCH** (Generalized Autoregressive Conditional Heteroskedasticity) models this: it predicts that tomorrow's variance depends on recent squared shocks and recent variance.

The statistical models (`ARIMA_GARCH`, `ARIMAX_model`) fit GARCH on the residuals and select the best variant by **BIC** (Bayesian Information Criterion, which rewards fit while penalising complexity) among:

- **GARCH** (symmetric), **GJR-GARCH** and **EGARCH** (asymmetric — "bad news" raises volatility more than "good news"),
- with **Normal, Student-t, skewed-t, GED** innovation distributions (the fat-tailed ones capture extreme moves).

Forecasts are then generated by **Monte Carlo simulation** (`model_utils.simulate_price_paths`): simulate thousands of future return paths through the fitted dynamics, build price paths, and read off the **median** (point forecast) and the **2.5th/97.5th percentiles** (95% interval). This naturally produces wider intervals in volatile regimes.

### 8. Quantile regression

Instead of predicting the mean, **quantile regression** predicts a specific percentile. `Quantile_model.py` trains three LightGBM models per horizon — for the **2.5th, 50th (median), and 97.5th** percentiles of the cumulative return — using the **pinball loss**. The median is the point forecast; the outer two form a native 95% interval whose width grows with horizon. Unlike a Gaussian "±1.96σ" band, this makes no symmetry/normality assumption.

### 9. Conformal prediction (distribution-free intervals)

Many models output only a point forecast. **Conformal prediction** wraps *any* model to produce a calibrated interval, with minimal assumptions. The split-conformal recipe used here:

1. Hold out a recent **calibration** block the model didn't train on (with an **embargo gap** of `h` bars before it, so the future-spanning labels don't overlap — see §6).
2. Measure the model's **errors** (residuals) on that block, **per horizon step**.
3. The (1−α) quantile of those absolute residuals is the interval **half-width**; the band is `forecast · exp(±half-width)` in return space.

Because stock data is not exchangeable (it has trend and changing volatility), the split is **temporal** (calibrate on the most recent block) and the half-width is computed **per horizon**, so intervals widen with horizon. This was added to:

- the tree/ML models — `direct_forecast.conformal_halfwidth` (a separate calibration fit per horizon), and
- the neural nets — inside `model_utils.forecast_nn_direct` (one calibration pass per held-out window).

Coverage is then *checked empirically* by the backtest (does the "95%" band really contain ~95% of outcomes?).

### 10. The cross-family meta-ensemble

The multi-ticker backtest showed there is **no universal winner**: tree models won some stocks, statistical models won others. So `meta_ensemble.py` combines **different model families** — Quantile-LGBM and XGBoost (tree) plus ARIMA+GARCH (statistical) — and aggregates them with the **median** of the per-horizon point forecasts. *(The statistical member was listed as ARIMAX, but ARIMAX's regressors never reached the model, so every published meta-ensemble figure was measured with plain ARIMA on ARIMAX's prepared returns. The member is now exactly that, `run_arimax_prediction(use_exog=False)`, named as what it was; [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found).)*

The median is deliberate: it is **robust to a single model misfiring**, which is exactly the failure mode (one family doing badly on a given ticker). Confidence bounds are averaged across the constituents. The result tracks whichever family suits the current ticker without needing to know which in advance, and it degrades gracefully if a constituent fails.

### 11. Model-by-model summary

- **ARIMA + GARCH** — Auto-ARIMA models the linear autocorrelation of returns; GARCH models the volatility; Monte Carlo produces the forecast and interval. Strong, stable, near-flat point forecasts.
- **ARIMAX + GARCH** — ARIMA plus **exogenous regressors** (volume ratio, range, RSI, momentum, calendar), entering **lagged one bar**. *Until [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found) none of them reached the model: pmdarima 2.x takes regressors as `X` and silently ignored the `exogenous=` keyword, so every ARIMAX figure published before §59 is plain ARIMA. Fitted honestly, the regressors cost ~3% RMSE against plain ARIMA on five NSE names — another negative result.*
- **Regime Switching** — a **Markov** model with hidden bull/bear (low-/high-volatility) states, each with its own mean and variance; forecasts via regime-aware simulation.
- **Prophet** — additive decomposition into trend + seasonality + holidays (log-space). Easy to use but can over-extrapolate trends — see [caveats](#caveats-and-limitations).
- **XGBoost / LightGBM** — gradient-boosted decision trees on the engineered features; **direct multi-horizon** with **conformal** intervals. Among the most robust models.
- **Stacking Ensemble** — XGB + LGB + Ridge base learners combined by a Ridge meta-learner trained on **out-of-fold** (leakage-safe) predictions; direct multi-horizon + conformal.
- **Quantile-LGBM** — native probabilistic intervals via quantile regression; consistently the most robust single model in the backtest.
- **LSTM / GRU** — recurrent neural networks that learn temporal patterns; now **direct multi-horizon** (multi-output) with conformal bands.
- **Transformer** — self-attention sequence model with causal masking; direct multi-horizon + conformal.
- **TCN** — dilated causal convolutions with skip connections; direct multi-horizon + conformal.
- **N-BEATS** — fully-connected residual stack; **capacity-reduced** (64 units × 2 blocks) after the original 256-unit version overfit badly; direct multi-horizon + conformal.
- **Hybrid ARIMA + LSTM** — ARIMA captures the linear part, an LSTM models the non-linear residual.
- **Chronos-2** — Amazon's pretrained time-series **foundation model**, run zero-shot with engineered covariates.
  - **Pretraining contamination: a standing caveat on any Chronos result.** A foundation model can score well because its pretraining corpus contained the series it is being tested on, not because it forecasts. Every other model in this zoo is fitted inside the walk-forward, so none of them has this failure mode. The local model card lists the training sources (a subset of Chronos Datasets, a subset of GIFT-Eval Pretrain, and synthetic data) and cites a technical report dated **October 2025**. It states **no data cutoff**, and nothing on disk shows whether any NSE equity series is in the corpus. So the leakage term in *observed skill = forecasting + contamination + noise* is unknown, and is recorded as unknown rather than assumed to be zero. *(Source: Large Language Models in Finance, §13.4.6.)*
  - **Why the current verdict is safe:** contamination can only *inflate* apparent skill, and Chronos-2 already shows **no edge over the random walk** (DM p = 0.61). The true skill can therefore only be lower than what was measured.
  - **What would not be safe:** reading a future Chronos edge at face value. If one ever appears, re-run it on data published **after** October 2025 before believing it. The bhavcopy cache already covers 2025-11 to 2026-08, so that check needs no new data. That span is inside the reserved final test period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)), so it's opened deliberately with `allow_holdout=True` and a stated purpose, and the opening is logged.
- **HAR-RV** — a volatility model (see §12); flat point forecast + a conformalized risk cone.
- **Meta-Ensemble** — the median combination described in §10.

### 12. Volatility forecasting with HAR-RV

The backtest taught the central lesson of this domain: at single-name daily/hourly horizons the **return** (the price *direction*) is essentially a random walk — no feature set reliably beat it. But the **second moment** is different: **volatility clusters and is genuinely forecastable** (it's the same property GARCH exploits). So `HAR_RV_model.py` adds a model that stops pretending to predict the price and instead forecasts the *risk*.

**HAR-RV** (Heterogeneous AutoRegressive model of Realized Volatility, Corsi 2009) explains today's (log) realized variance with its own **daily, weekly, and monthly** lagged averages — three horizons of memory that capture volatility's long persistence with just four OLS parameters. The model:

1. builds a realized-variance series from the bar returns,
2. fits the HAR regression and rolls it forward to get a per-step **log**-variance forecast,
3. converts log → level with a **data-estimated offset** (`har_level_offset`), sums the step variances (variance is additive) to get the cumulative variance to each horizon, and
4. wraps a **flat (random-walk) price path** in a `last_price · exp(±k · √cum_var)` band.

Step 3 is subtler than it looks and was originally wrong. Exponentiating the mean of `log(r²)` does not give the variance: writing `r = σ·z`, `log(r²) = log(σ²) + log(z²)` and `E[log z²] = −1.27` for Gaussian `z`. The textbook repair — the log-normal Jensen correction `exp(μ + σ²_resid/2)` — assumes a **Gaussian** residual, but this residual is **log-χ²**, with variance `π²/2 ≈ 4.93`, so that correction over-shot and inflated volatility by a measured **~1.9×**. The offset is now estimated from the data instead (`c = log(mean RV) − mean(log RV)`), which recovers 1.27 on Gaussian returns and self-adjusts for fat tails. The bug was invisible for a long time because the conformal layer in step 4 cancels it; see [Empirical findings](#volatility-model-comparison--and-the-latent-har-rv-bias-it-exposed-now-fixed) for how the variance-forecast scoring in `run_vol_comparison.py` surfaced it.

It makes **no directional claim** — embodying the honest position that the point forecast is unforecastable but the cone is not. The multiplier `k` is **conformalized per horizon**: rather than the textbook normal `1.96` (which under-covers because returns are fat-tailed), `k_h` is the empirical quantile of recent *cumulative* standardized residuals, so the band is distribution-free and calibrated to the realized h-step move. A useful diagnostic falls out of this: if the fitted `k_h` sits far *below* 1.96, the variance forecast it is correcting is probably biased high — which is precisely how the level bug announced itself.

**Adaptive (ACI) refinement (default on).** A static `k_h` is the quantile of the *whole* calibration pool — it can't tell that the *recent* stretch has been systematically under-covering (a volatility regime shift), which is the exact failure the backtest exposed. So the cone now applies **Adaptive Conformal Inference** (Gibbs & Candès 2021): walking the calibration residuals in time order it updates the miscoverage level `α_{t+1} = α_t + γ(α* − err_t)` — a run of misses (high-vol regime) drives `α` down → a higher quantile → a **wider** cone; a run of easy covers tightens it. Because `α` carries memory, the value at the end of the stream is recency-weighted, so the live multiplier reflects the *current* regime, not the long-run average. It's a parameter (`adaptive=True`, `aci_gamma`) on `run_har_rv_prediction`, so the calibration harness can A/B it (see [Empirical findings](#empirical-findings)). On a calm window it can slightly over-tighten an already-well-calibrated name; its upside is regime response — discussed in [caveats](#caveats-and-limitations). At scale (57 names, about 8,000 origins; [§71](#71-adaptive-conformal-for-every-model-and-the-novelty-gate-in-a-real-crash--neither-earns-its-place)) the ACI cone covered 94.8% at five sessions against static's 95.7%, with bands 7% narrower, and stays the default.

### 13. Confidence, abstention, and risk outputs

Because the backtest showed most point "wins" are within noise, the app treats **uncertainty as the deliverable**, not the price line:

- **Confidence gate** — at request time the app runs a quick walk-forward backtest for each model and labels it **High / Medium / Low / No edge** from its RMSE improvement over the best naive baseline, the **Diebold-Mariano** p-value, and interval coverage (the rule is `backtest.confidence_bucket`, the single source of truth shared with the offline validation harness — see [§14](#14-validating-the-uncertainty-calibration)). Low/No-edge means *"use the range, not the point."*
- **Abstention banner** — when *no* model reliably beats the random walk for the chosen ticker/horizon, the app says so prominently rather than presenting a confident-looking line.
- **Gated directional call** — the **Sentiment / Direction** columns are *withheld* ("No edge", "–") for any model the gate labels "No edge", so the app never asserts a Bullish/Bearish view off a point forecast its own test says is no better than a coin flip.
- **Risk & Probability panel (read off the empirical, fat-tailed distribution).** **P(up)**, **P(gain > +X%)**, **P(loss > X%)**, the **VaR-style 5% downside**, and the 95% **range** are counted *directly from HAR-RV's conformal residual sample* — the genuine fat-tailed distribution — not from a normal approximation. (Earlier versions re-imposed a log-normal at this last step, discarding exactly the tails the conformal machinery had estimated; that is fixed.) When no fat-tailed model (HAR-RV) is in the run, the panel falls back to a log-normal read of each model's interval and **says so explicitly** in the caption. The panel also reports the **downside-specific** reads — **expected shortfall (CVaR)**, the **downside/upside semideviation split**, and the **vol-skew** ratio — off the same empirical sample (see [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)).
- **Distribution-first charts** — every chart draws the **naive random-walk baseline** next to the forecast and frames the band as the plausible-outcome cone.

These reframe the same underlying models around what they actually know.

### 14. Validating the uncertainty (calibration)

A probabilistic product is only honest if its probabilities are **calibrated** — a "95%" interval that covers 80% of the time, or a "P(up)=70%" that is right 55% of the time, is worse than silence. `calibration.py` (driver: `run_calibration.py`) is the validation harness for exactly this. It does *not* add a model; it checks the claims the app already makes, with standard proper tools:

- **CRPS** (Continuous Ranked Probability Score) — the gold-standard *proper* score for a full predictive distribution; it jointly rewards calibration **and** sharpness (lower is better, generalises MAE to distributions). Reported per horizon, and — crucially — **empirical-sample CRPS vs log-normal-approximation CRPS side by side** for HAR-RV, so the value of the fat tails is *measured*, not asserted.
- **PIT** (Probability Integral Transform) — `F_pred(actual)` should be Uniform(0,1) if the distribution is calibrated; a U-shape means over-confident (too narrow), a hump means too wide. Summarised by a KS distance to uniform.
- **Reliability / ECE** — bins predicted **P(up)** and **P(move > X%)** and compares to the realised frequency; the Expected Calibration Error says whether "70%" really means 70%. (P(up) reliability is meaningful for *directional* models; HAR-RV's is ~0.5 by design.)
- **Coverage quality, not just coverage** — coverage *and* mean interval width, their efficiency ratio, and the lower/upper **tail-miss balance** (misses skewed downside ⇒ the cone underestimates crash risk).
- **Gate validation** — a nested walk-forward assigns each origin a confidence bucket from *past-only* data (the same `backtest.confidence_bucket` the UI ships) and measures the realised next-horizon skill, so you can check that "High" actually beats "No edge" out-of-sample rather than being theatre.

An illustrative single-ticker run (RELIANCE.NS, 5-day horizon) is summarised in [Empirical findings](#empirical-findings); the headline is that HAR-RV's **empirical fat-tailed CRPS beats its log-normal approximation**, confirming the risk-panel fix in §13 helps the proper score and is not just principled.

### 15. Data-snooping-robust model selection (Reality Check & SPA)

The Diebold-Mariano test (§"Is the edge real?") is **pairwise** — it asks whether *one* model beats the random walk. But the app compares **17 models** across several tickers, and picking the best-looking one reintroduces the very bias DM guards against: with enough candidates, one wins by luck. `multiple_testing.py` (driver: `run_spa.py`) closes that gap with the standard data-snooping corrections, both over a **stationary bootstrap** (Politis–Romano) of the aligned loss differentials, with the block length chosen automatically from the data (Politis–White 2004):

- **White's Reality Check** (2000) — bootstraps `max_k √T · mean(loss_benchmark − loss_model_k)` under the least-favourable null. Conservative; used as the headline verdict here.
- **Hansen's SPA** (2005) — studentizes (Newey–West HAC) and applies the *consistent* recentering that drops hopeless models from the null, so it's more powerful. Reported as a companion; it can be mildly liberal at small sample, so a borderline SPA rejection that the Reality Check doesn't confirm is treated as unconfirmed.

H0 for both: *no model in the set beats the benchmark.* The experiment unit is the **forecast origin** (one mean loss per origin), not the within-horizon step, so the bootstrapped events are near-independent. This is the rigorous capstone to the DM work: it answers the honest question **"after trying K models, is there evidence that *any* of them genuinely beats the random walk?"** The result is in [Empirical findings](#empirical-findings).

### 16. Currency conversion to INR and its audit trail

The app is INR-centric but can forecast foreign-listed names, so prices are converted to INR in [`get_data.py`](get_data.py). The conversion is **period-accurate by default**: it fetches the historical FX series (`USDINR=X`, `EURINR=X`, …) and converts **each bar at its own date's rate**, so a 2019 price uses the 2019 rate and a 2026 price uses the 2026 rate. This matters — converting the whole history at one current rate would leave day-to-day *returns* unchanged but distort the *level* path the volatility models see. Weekend/holiday gaps are forward/back-filled from the nearest trading day.

There are two fallbacks, used only when the historical series can't cover the data: a few un-coverable early dates are filled with **today's** rate, and if the whole historical fetch fails, the entire series is rescaled by today's rate (a degraded mode). If even the live rate fails, prices are left unconverted.

Because those fallbacks change what the ₹ numbers *mean*, every fetch carries an **audit tag** (`df.attrs['fx_conversion']`) recording the path taken, and the UI renders it above the results:
- **historical** → a quiet caption ("converted at each date's own historical rate; latest ≈ ₹X/USD");
- **live-uniform** → a **warning** that historical *levels* are rescaled and not period-accurate;
- **unconverted** → an **error** that the ₹ labels don't apply.

This makes the conversion reviewer-auditable rather than invisible. (Building this audit trail also surfaced and fixed a latent bug where a `DataFrame.drop` call threw before the conversion ran, silently returning foreign prices labelled as INR — see [caveats](#caveats-and-limitations).)

**Scope note — this is a dormant safety net.** The company selector is built **only from NSE + BSE listings** (`get_data.company_list`), so every selectable stock is **quoted in INR already** and the conversion path is *never* taken in normal use (the audit tag reads `none`). `_convert_to_inr` can only fire for a foreign ticker reached via the API-search fallback for a name *not* in the dropdown — an edge case the UI doesn't expose. Consequently there is **no FX applied to an Indian hourly series at all**, so intraday-FX granularity is moot for this product; it would only matter if the universe were ever widened to foreign listings. The audit tag exists precisely so that, *if* that dormant path ever fires, it is surfaced loudly rather than silently mislabelling prices.

### 17. Input data-quality gating

A forecast is only as trustworthy as the data feeding it, and the source here is yfinance — which can serve stale candles, missing bars, zero-volume rows, or (rarely) inconsistent OHLC. A weak prediction caused by *bad data* is indistinguishable, in the output, from one caused by a weak *model* — unless you check. So `data_quality.py` scores every fetched series **before** any model output is trusted, and makes data quality part of the gate (the discipline both reviewers asked for).

`assess_data_quality(df, interval, horizon)` runs a battery of pure checks and returns a structured report — a 0–100 score, a tier, a serving **mode**, and a list of **reason codes** (each with a severity and a human message):

- **Insufficient / thin history** — fewer bars than needed to fit and walk-forward-assess a horizon-step forecast (interval-aware floor).
- **Short hourly window** — provider-capped intraday history below ~100 sessions.
- **Duplicate / unsorted timestamps** — would corrupt feature construction.
- **Missing / non-positive prices** — NaNs or ≤ 0 levels that break log-return modeling.
- **Bad OHLC bars** — `high < low`, or close outside the bar's range.
- **Zero-volume bars** — illiquidity / halts (fraction-based).
- **Stale last candle** — the feed hasn't updated within the expected cadence.
- **Calendar gap** — a genuine data hole, measured in *calendar days* against an interval-aware threshold so normal overnight/weekend/holiday gaps don't false-flag.
- **Abnormal recent jump** — a large robust-z return spike in the last few bars (possible unadjusted corporate action or event risk).
- **Currency status** — reads `get_data`'s `fx_conversion` audit tag (degraded → warn, unconverted → critical).

The reason codes drive a **serving mode**, not just a number:

| Mode | When | UI behaviour |
|---|---|---|
| `normal` | clean data | forecast as usual |
| `warn` | minor caveats | forecast with a data-quality warning |
| `risk_cone_only` | a non-fatal critical (illiquidity, bad bars) | **withhold directional calls**, steer to the risk cone |
| `abstain` | a fatal flaw (insufficient history, stale feed, unconverted currency, non-positive prices) | **don't present a directional forecast** |

In the app, a degraded gate forces every model's confidence bucket to **"No edge"**, reusing the existing abstention machinery so directional calls vanish consistently, and a 🩺 banner plus an expandable per-check list make the verdict auditable. This is wired alongside the existing skill gate and the SPA/Reality-Check framing: **every model row now shows a plain-language *Basis* reason code** (e.g. "no edge vs random walk (DM p=0.42)", "withheld — data quality"), and a standing notice states that the data-snooping-robust tests found **no confirmed winner** — so the comparison table is never read as crowning a "best" model. The gate's behaviour is covered by `test_data_quality.py`.

### 18. Price-adjustment hygiene (adjusted vs. raw close)

A reviewer flagged a subtle potential leak: yfinance retro-adjusts its `Adj Close` series for **all** splits and dividends, including ones that occur *after* a given bar, and this whole pipeline models log returns off `adj_close`. Could a past bar therefore "know" about a future corporate action? `audit_price_adjustment.py` measures it directly on real NSE names, and the answer is **no — it is immaterial for this pipeline**, for three concrete reasons:

1. **Live serving has zero leak.** At serve time the latest bar's adjustment factor is 1.0, so only actions that have *already* happened are baked in — exactly the information a real user would have.
2. **The leak is confined to corporate-action bars** (≈ 0.4–1.6 % of bars in the audited sample). On those exact bars the *adjusted* return is the economically-correct value (it removes the artificial split/dividend price jump); on every other bar the adjusted and raw returns are **identical**, so every scale-invariant feature (returns, ratios, RSI, volatility, z-scores) is unchanged.
3. **The level distortion cancels where it matters.** Past *price levels* can be rescaled by up to ~10–18 % at the oldest origin, but the models forecast *log returns* and the metrics that drive the gate (Diebold-Mariano, SPA, MASE) are scale-invariant, so a piecewise rescale of levels cancels in every model-vs-baseline comparison.

Switching to *raw* close would be **worse**: it would inject fake ~2–3 % jumps at every ex-dividend/split date as if they were real returns, corrupting volatility and RSI. Using the adjusted (total-return) series is the correct choice for return modeling; the residual look-ahead is documented rather than "fixed" because fixing it (point-in-time re-adjustment per origin) would buy nothing measurable here. The audit script is kept so the claim is reproducible.

#### The fallback path was a different story

All of the above concerns the **primary** yfinance path, which was correct. The **nselib daily fallback** — which fires only when yfinance returns nothing, and does fire, because NSE renames leave yfinance with no quote at all (`TATAMOTORS` → `TMPV`) — was not. Being the least-exercised code in the fetch layer and the only module with **no test coverage**, it had accumulated four defects:

1. **`AveragePrice` was mapped to `adj_close`.** That column is **VWAP**, not a close, and it is **completely unadjusted**. Across CESC's 10:1 split it yields a **−89.5%** one-day return in the exact column this section argues so carefully about — a far worse version of the "fake 2–3% jump" the design explicitly rejects.
2. **No `Series` filter.** Before ~2003 several names traded in two series simultaneously, so the pull returned **two rows per date** — 442 of RELIANCE's 6,863 rows. Duplicate dates corrupt every rolling window downstream.
3. **Unsorted output**, not monotonic in either direction.
4. **`datetime` returned as a string** where the yfinance path returns `datetime64`.

Measured against yfinance's `Adj Close` on RELIANCE over 2,879 overlapping days:

| | Return correlation | Worst-day gap |
|---|---|---|
| Before (VWAP as `adj_close`) | **0.527** | **69%** |
| After | **0.996** | 8% |

Mean absolute return difference is now **0.000035**. `close` comes from `ClosePrice`, VWAP is retained as its own `vwap` column rather than discarded, and `adj_close` is built from NSE's corporate-action feed via [`bhavcopy`](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) — **one request, ~4 s** for 26 years, measured before committing to the design.

**The residual 8% is a single day: 2023-07-20, the Jio Financial demerger.** Demergers are deliberately not handled — the correct adjustment depends on the listed value of the spun-off entity, which the action feed does not carry — so this is a named gap rather than a guess.

**Degradation is declared, not hidden.** If the action feed is unreachable, `adj_close` falls back to the raw close *and* `attrs['price_adjustment']['adjusted']` is set `False` with the reason. Serving unadjusted prices under the name `adj_close` without saying so was the original bug; failing silently would have recreated it in a new form. 14 offline tests in `tests/test_nselib_fallback.py` pin all of it.

This is also where the §38 research module pays back into the product: `bhavcopy.corporate_actions` and `adjust_prices` were built to measure model skill honestly, and they are what makes the fallback correct.

### 19. Forward-looking volatility from India VIX

HAR-RV's cone is built entirely on **realized** (backward-looking) variance — it forecasts future risk from how volatile the recent past was. The one thing it structurally *cannot* see is what the market **expects** next, which is exactly what option-**implied** volatility encodes. Injecting implied vol was a reviewer's strongest remaining idea, precisely because it targets volatility (where skill exists) rather than direction (where the SPA/Reality-Check tests proved there is none).

**The honest data-feed finding.** True **single-name** NSE option-chain IV is **not freely or reliably available**: NSE's own API is bot-protected (HTTP 403 without a real browser session; empty bodies from data centres), `nselib`'s wrapper fails the same way, and yfinance serves no options for `.NS` tickers. Building a single-name IV scraper would be fragile, frequently-empty dead code — so, consistent with this project's discipline, it was **not** built. What *is* reliably free is **India VIX** (`^INDIAVIX`), NSE's forward-looking implied-vol index for NIFTY — a plain quote, already referenced by the market-context module.

So `iv_data.py` uses India VIX to tilt the cone with the *systematic* slice of forward vol:

- `F = (VIX-implied market daily vol) / (NIFTY recently-realized daily vol)` — the market's **implied/realized** ratio. `F > 1` ⇒ the market prices in *more* forward vol than recently realized (widen the cone); `F < 1` ⇒ calmer ahead (tighten).
- `w = R²` of the stock vs NIFTY — its **systematic variance share** (how market-linked it is; `beta` cancels in the ratio `F`).
- `m = clip(1 + w·(F − 1), [0.85, 1.30])` — the forward-vol multiplier applied to the cone's cumulative sigma (so the band **and** the empirical risk distribution stay consistent).

It is **leak-free** — every VIX/NIFTY lookup is "as of" the last bar of the passed frame, so a walk-forward origin only ever sees the VIX that existed then (verified in `test_iv_data.py`) — and every failure path returns a no-op multiplier of 1.0.

**The honest A/B verdict (ships off).** Run through the calibration harness (`compare_iv_adjust`) on RELIANCE / TCS / INFY, the tilt was **coverage-neutral on the calm 2021–2026 window** (RELIANCE slightly *worse*, the other two unchanged), because in calm regimes implied ≈ realized so the multiplier barely moves. Even with origins **concentrated in the 2020 COVID crash** it stayed coverage-neutral while correctly **widening** the cone (~1.4 pp) as VIX spiked — the right *direction*, but no measurable coverage payoff on the available data. So, exactly like market-context and excess-return, it ships **off by default** (`USE_IV_ADJUST = False`, or `iv_adjust=` on `run_har_rv_prediction`): a principled, forward-looking, opt-in research feature, not a claimed win. See [Empirical findings](#empirical-findings).

### 20. Downside risk: semivariance, expected shortfall, and the asymmetric cone

A risk user does not care equally about both tails — they care about **how bad the bad case is**. Symmetric volatility treats a +5% and a −5% move as the same; for a risk instrument that is the wrong emphasis. This project adds three left-tail-specific reads, all built on HAR-RV's existing empirical conformal residual sample (so they inherit its fat tails, no Gaussian).

**Realized semivariance (the foundation).** Realized variance splits into a **downside** and an **upside** half — `RS⁻ = Σ r²·1{r<0}`, `RS⁺ = Σ r²·1{r>0}`, with `RS⁻ + RS⁺ = RV` (Barndorff-Nielsen, Kinnebrock & Shephard 2010). Patton & Sheppard (2015, *"Good Volatility, Bad Volatility"*) show the *downside* half carries most of the predictive content for future volatility. HAR-RV exposes the recent **downside share** (`attrs['downside_share']`) for transparency.

**Always-on downside reporting (the user-facing win).** The Risk & Probability panel now adds, alongside VaR and the 95% range:
- **Expected shortfall (CVaR, worst 5%)** — the *average* outcome given you are already in the worst 5% tail ("if it's a bad day, how bad on average"), a more honest left-tail number than VaR, which is only the threshold.
- **Downside vol / upside vol** — the realized **semideviation** split (dispersion of down-moves vs up-moves).
- **Vol skew** — their ratio; **> 1** means the downside is the fatter side of this stock's outcome distribution.

These are pure *reporting* of the distribution HAR-RV already estimates (no model change, no skill claim), so they are always on whenever a fat-tailed model is in the run. The math lives in the Streamlit-free `risk_metrics.py` and is covered by `test_har_downside.py`.

**The asymmetric cone (opt-in, A/B-gated).** Going one step further, the cone itself can be made **asymmetric** (`asymmetric=True`): instead of a symmetric `exp(±k·σ)` band, the lower and upper edges get **separate multipliers** from the left- and right-tail quantiles of the signed residuals (each at the one-sided level, static or via one-sided ACI), so a fatter loss tail produces a wider *downside* edge. On a single recent RELIANCE fit this correctly pushed the downside to −8.1% while pulling the upside to +4.7% (vs a symmetric ±~8%). But an A/B on calm 2021–26 data was **mixed on tail-miss balance** (better for INFY, worse for RELIANCE/TCS): splitting the calibration into two half-size per-side samples adds estimation noise when the residuals are near-symmetric, which is the common case in calm regimes. So — consistent with the project's discipline — the asymmetric cone ships **off by default** (`USE_ASYMMETRIC_CONE = False`); it is a principled opt-in that should pay off under genuine, persistent skew. See [Empirical findings](#empirical-findings).

**Why not a full HAR-RS forecast?** Feeding downside semivariance into the HAR *regression* (a "good vol / bad vol" forecast) is the natural extension, but it requires forecasting the semivariance components forward recursively, and — as the IV and asymmetric-cone A/Bs both showed — changes to the *central* variance forecast move the empirically-conformalized cone's coverage very little. So it is deliberately left as documented future work rather than built speculatively.

### 21. Operational robustness: reproducibility, resilient fetch, event-risk gating

Two independent reviews converged on the same conclusion: the *forecasting* question is closed (the four killed experiments — market context, excess returns, IV tilt, asymmetric cone — collectively confirm the SPA wall), so the remaining robustness is **operational and presentational**, not more modeling. This section is that layer — making the app reliable, auditable, and honest about its serving behaviour.

**Seed-pinned reproducibility + run manifest (`reproducibility.py`).** `set_all_seeds` pins every RNG (`random`, NumPy, TensorFlow, PyTorch-if-present) from one call at the start of each run, so a forecast is reproducible given the seed — and the NN path now goes through the same call (it previously seeded only TF/NumPy). `run_manifest` records the seed, interpreter and key package versions, the run parameters, the data's as-of date, and a UTC timestamp; the UI surfaces it in a **"Run details (reproducibility)"** expander. This doesn't make markets predictable — it makes your *experiments auditable*. *(One RNG it did not pin, found in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found): `arch`'s simulation draws from the fitted distribution's own generator, which no global seed reaches, so the ARIMA/ARIMAX cones differed run to run until `simulate_price_paths` reseeded it.)*

**The half of that guarantee that was missing, found the hard way.** The manifest *recorded* package versions and **nothing ever compared them to `requirements.txt`** — it was write-only. A run on `scikit-learn 1.9.0` produced a manifest saying so while the pin file said `1.8.0`, and the two never met.

The consequence was not hypothetical. The environment drifted to **numpy 1.26.4** against a pin of **2.4.6**, and because scipy ≥ 1.14 is built against numpy 2.x and references `np.long`, **eight libraries stopped importing**: scipy, scikit-learn, statsmodels, arch, pmdarima, LightGBM, XGBoost. Some failures were loud. One was not — `fracdiff.adf_pvalue` catches its exception and returns `NaN`, so [§36](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result)'s stationarity tests reported **nothing at all**, with no error, for as long as the drift lasted. That is the third instance in this project of the same pattern named in [§37](#37-the-diebold-mariano-kernel-fix-and-the-windows-race-it-uncovered): *the deliberate swallow that makes a module robust in production is the one that makes breakage invisible.*

`check_pins()` closes it. It parses the exact (`==`) pins, compares them against what is installed, and separates **drifted** from **missing** — a package pinned-but-absent needs a different fix from one at the wrong version. Every manifest now carries a `pin_drift` field, `None` on a matching environment and a `{pkg: {pinned, installed}}` map otherwise, so **a run on a drifted stack says so in its own audit record**.

**Two bugs in `requirements.txt` itself, both of which made it uninstallable.** `pip install -r requirements.txt` failed with `ResolutionImpossible`:

* `streamlit==1.54.0` caps `pandas<3`, contradicting `pandas==3.0.3` outright. **Fixed** — 1.58.0 allows `pandas<4`.
* `prophet==1.2.2` declares `numpy<2.4.0, pandas<3`. That one is **conservative upstream metadata, not a real incompatibility**: verified on this exact stack, Prophet imports, fits and predicts correctly. Loosening the numpy pin to satisfy the declaration would be the wrong fix, since numpy 2.x is mandatory for scipy. The file now documents `pip install --no-deps -r requirements.txt` as the command that works, and why. *(Superseded: `--no-deps` also skips every transitive dependency, so it only works on a machine that already has them. `python run_app.py` now installs in two phases that handle Prophet properly; see [Getting started](#getting-started).)*

**Four pins were aligned to the installed versions rather than the reverse** (`scikit-learn` 1.8.0→1.9.0, `tensorflow` 2.20.0→2.21.0, `xgboost` 3.1.2→3.2.0, `yfinance` 1.0→1.4.1). That direction was forced by the evidence: nothing recorded which versions produced the published figures — the prediction log stores `run_id` and `seed` but not packages — so the pinned set had no evidence behind it beyond being written down, while the installed set passes all 741 tests. Pinning what is tested is the only defensible choice, and the gap it exposes is exactly why `pin_drift` is now in the manifest.

**The manifest now records which numbers a run used, not just which ticker.** The manifest held the seed, the interpreter, every package version and the fetch time, and it still couldn't prove two runs saw the same data. Adjusted prices are **restated retroactively**: every dividend or split rescales the whole earlier history. Measured with `bhavcopy.adjust_prices(as_of=...)` on ten NSE large caps, **every one** of their 2022 trading days carries a different adjusted close depending on whether the history was fetched in January 2023 or June 2024. The largest change is **6.7%** (ITC); RELIANCE's is 0.35%, TCS's 4.8%. So two runs with the same ticker, seed and packages can have been fed different inputs, and nothing recorded could say so.

`data_fingerprint(df)` hashes the market-data columns (OHLC, `adj_close`, volume) after canonicalising them. Row and column order don't matter, engineered feature columns are ignored, floats are rounded so representation noise can't move the hash, and `-0.0` and NaN are normalised. `run_manifest(data=...)` records it, the app passes its training frame and shows the hash in the run-details caption, and `diff_manifests(a, b)` lists what differs between two runs with the data first, ignoring the run timestamp. On the real restatement it does what's needed:

| RELIANCE, the same 248 sessions of 2022 | fingerprint |
|---|---|
| fetched as of January 2023 | `c2c21bff4e8aa2aa` |
| the same fetch, repeated | `c2c21bff4e8aa2aa` |
| fetched as of June 2024 | `2343ddb7d734bc05` |

Row count and end date are identical across all three, so only the hash can tell the June 2024 fetch apart, and `diff_manifests` names `data` as the one thing that changed. This is the data-provenance item of the reproducibility protocol in *Large Language Models in Finance* (§15.8). Ten tests pin it, including one that restates a single old price by RELIANCE's measured 0.35%.

**There is now a reserved final test period, and it's enforced.** The same book's leakage-aware protocol (§13.4) asks for "a final untouched test period" and warns against letting it "become part of the creative loop". This project had none. Every published result stops at **2024-06-30**, and §38's second-period replication stops at **2024-12-31**, so **2025-01-01 onward** is the span no published number has used: 411 trading days, through 2026-08-31. But nothing marked it reserved, and §38's own driver had drifted to a default end date of 2026-06-30, so its next run would have spent it without anyone deciding to.

A holdout protected only by convention gets spent by the first person who forgets. So `bhavcopy.load_cache`, and through it `build_panel`, now **refuses** any read reaching `HOLDOUT_START` (2025-01-01). That's the same pattern as `fundamentals.as_of_join` refusing a non-point-in-time frame. It opens only with `allow_holdout=True` **and** a stated `purpose`, and every opening is appended to `tests/validation/holdout_ledger.csv`, which is committed. So the number of times the final test has been looked at is itself on the record, which is what a deflated Sharpe needs to count trials honestly. The app is unaffected, because it never reads the bhavcopy cache. §38's driver default is back to the 2024-06-30 its table publishes. Five tests pin the guard. **No study has used the holdout.** The ledger's 34 rows (20 October 2026) are an owner-approved bug check of the drivers that read live prices; their results were discarded ([§68](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period)). Five candidates are queued for it; [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces) rates them on Hough's five signs and on the power the period would have to confirm each.

**Resilient data fetch (`safe_fetch.py`).** Because the app fetches live from yfinance, a transient empty response or rate-limit must not silently produce a degraded forecast that *looks* healthy ("a weak prediction can come from bad fetch behaviour, not model weakness"). `fetch_with_fallback` wraps the fetch with bounded **retries + exponential backoff**, empty/error detection, **partial-data detection**, and a persistent **last-known-good disk cache**. Every result carries `attrs['source']` ∈ {`live`, `partial`, `cached_fallback`}, which the data-quality gate turns into a reason code: a **cache-fallback serve is downgraded to risk-cone-only** (the directional call is withheld until live data returns), surfaced in the UI as *"Live fetch failed; using cached data (~N days old). Forecast downgraded to risk-cone-only."*

**Structured event-risk reason codes (`data_quality.py`).** Beyond the earlier abnormal-jump check, the gate now also flags an **abnormal recent volume spike** (latest bar ≫ its 20-bar median). Both are price/volume-only **event-risk** signals (no fragile news/earnings scraping). When either fires, `event_risk` is set and the serving mode drops to **risk-cone-only** — a known event makes the *direction* especially unreliable while the *cone*, widened around the event, is exactly what should be shown. The UI banner reads *"Event risk detected — showing the risk cone, not directional calls."*

**The serving gates are a pure, tested module (`gating.py`).** The product's trust lives in the gates, not the models, so the gate rules were extracted from the UI into a Streamlit-free module and unit-tested directly (`test_gates.py`): the directional call is withheld when the bucket is "No edge"; degraded/event-risk/cache-fallback data forces every model to "No edge"; conviction is the move measured in units of the model's own band (so a *wide* interval mechanically yields |conviction| < 1 — "inside the band"); and a weak Diebold-Mariano p-value can never produce a "High" confidence. Together with the existing reproducible-seed and resilient-fetch layers, the result is the controlled-serving behaviour the reviewers identified as the only robustness still open:

```
Good data + validated edge → directional forecast + interval + confidence
Good data + no edge        → random-walk price + HAR-RV/ACI risk cone
Bad data                   → abstain or risk-cone-only
Event / cache-fallback     → widen + withhold direction (cone only)
Many models, SPA no winner → never imply a "best model"
```

### 22. Economic evaluation: does the forecast make money?

Everything in §14–§15 is a *statistical* score — RMSE, MASE, CRPS, Diebold-Mariano, SPA. None of them answers the only question a user of a forecast actually has: **would acting on it have made money, after costs?** `strategy_metrics.py` closes that gap with the metric set from *Hands-On Deep Learning for Finance* Ch. 3 ("Evaluating investment strategy"): cumulative and monthly returns, the **information coefficient**, the **information ratio**, **Sharpe** and **Sortino**, and **maximum drawdown**.

The distinction is not cosmetic. RMSE is dominated by the *magnitude* of quiet periods; P&L is dominated by the *sign* on the few large moves. Neither is a monotone function of the other, so a model can win on RMSE and lose money — or the reverse. And transaction costs act as a hard filter that no statistical metric applies: a 52% directional hit rate at a 5-day horizon is worthless once you pay ~10 bps per round trip.

**How the conversion works.** `evaluate_strategy` takes the per-origin (predicted, realised) horizon-end log returns, maps the forecast to a **position** (`sign`, `deadband`, or `scaled`), computes gross P&L, then charges cost on `|Δposition|` — so a long→short flip costs two one-way trades and staying put costs nothing. Everything downstream (Sharpe, Sortino, drawdown, information ratio vs **buy-and-hold over the identical periods**) is computed on the net stream, with the gross figures reported alongside so the cost drag is visible.

Three deliberate design points:

- **`deadband` mode is the economic twin of the abstention gate.** Only trade when the claimed move clears the round-trip cost hurdle. It is the same "don't act on a signal smaller than your uncertainty" logic that `gating.conviction` applies to the interval.
- **Sortino, not just Sharpe.** Sharpe punishes upside and downside dispersion equally, which is the wrong penalty for an asymmetric return distribution — the same reasoning that motivated the semivariance work in [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone).
- **Overlap is flagged, not hidden.** `walk_forward_backtest` now returns a `strategy` block, and if the origin spacing is shorter than the horizon the trades overlap, the return stream is serially dependent and every risk-adjusted figure is optimistic. The harness sets `overlapping_origins=True` and prints a caveat rather than reporting a prettier Sharpe.

**Every Sharpe travels with its standard error.** A Sharpe computed from a handful of non-overlapping trades has an enormous sampling error, and quoting the point estimate alone invites reading noise as skill. `sharpe_standard_error` uses Lo (2002) — `SE ≈ √((1 + SR²/2)/n)` per period, **annualised by √(periods/year)** — and `sharpe_significant` reports whether the estimate clears 2 SE. The annualisation is the load-bearing part: a bare `1/√n` understates the error by `√(periods/year)`, so at 8 weekly trades it would report ±0.35 when the true figure is **±2.5**. That is the difference between "Sharpe 3.2 looks great" and "Sharpe 3.2 is 1.3 SE from zero".

**Expected result, stated up front.** Given `run_spa.py`'s verdict (White's Reality Check *p* = 0.899, Hansen's SPA *p* = 0.874 — no model has a selection-bias-free edge), the honest expectation is **Sharpe ≈ 0, negative after costs, and nothing statistically distinguishable**. That is the metrics working, not failing. A strongly positive Sharpe on a handful of origins is a **red flag to investigate** — overlapping trades, too few origins, a leak — before it is a discovery. `run_strategy_eval.py` therefore prints Sharpe ± SE and a significance flag next to every model, and reports the **rank correlation between the RMSE ranking and the Sharpe ranking** to show how differently the two order the same models.

**First run on real data** (RELIANCE.NS, 5-day horizon, 8 non-overlapping origins, 10 bps/side, `--fast` subset) — illustrative, tiny sample:

| Model | RMSE | MASE | Total ret % | Sharpe | Sortino | Max DD % | IC (t) |
|---|---|---|---|---|---|---|---|
| RegimeSwitching | 23.97 | 1.72 | **+7.39** | **3.20** | 7.28 | −2.43 | n/a |
| Ensemble-Stack | **22.59** | 1.58 | −1.83 | −0.69 | −0.88 | −4.80 | 0.33 (0.86) |
| ARIMAX+GARCH | 23.90 | 1.72 | −2.53 | −0.94 | −1.22 | −5.09 | 0.46 (1.27) |
| XGBoost / LightGBM | 26.3 | 1.89 | −7.39 | −3.37 | −3.50 | −9.83 | ≈0 |
| Quantile-LGBM | 27.31 | 2.00 | −8.42 | −4.02 | −3.99 | −10.42 | 0.04 (0.10) |
| ARIMA+GARCH | 23.96 | 1.73 | −9.13 | −4.26 | −4.11 | −9.54 | −0.25 (−0.63) |

(Buy-and-hold returned −7.30% over the same periods. The ARIMAX+GARCH row is ARIMA without regressors on ARIMAX's data preparation, see [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found).) **Six of seven models lose money**, and the one that does not — RegimeSwitching at Sharpe 3.20 — sits well inside its own ±2.5 standard error, i.e. **statistically indistinguishable from zero**; `sharpe_significant` is `False` for every row. The tree models are the worst economically, mirroring their position in the SPA table. The RMSE↔Sharpe rank correlation was **+0.45** — positively related but far from identical, confirming that the two tables genuinely order the models differently and that reporting only one of them would be misleading. All of this is consistent with the SPA result rather than in tension with it.

### 23. Deep volatility forecasting (Vol-LSTM) and CNN-LSTM

Two model additions drawn from the book, chosen to sit where this project's evidence says value can exist.

**Vol-LSTM (`vol_lstm_model.py`) — Ch. 5, "Volatility Forecasting by LSTM."** The book's chapter builds an LSTM on realized volatility and benchmarks it against a plain RNN and **GARCH** using the cumulative squared error. That is the right place to spend a neural network here: the first moment is a random walk at these horizons (§15), but volatility clusters and is genuinely forecastable — which is exactly why HAR-RV and the GARCH layer earn their place. Vol-LSTM is therefore the **deep counterpart to HAR-RV**, and honours the same contract: flat random-walk point path, conformalized cone as the deliverable, `run_*_prediction(df, interval, horizon)` signature.

What it can express that HAR-RV cannot:

| | HAR-RV | Vol-LSTM |
|---|---|---|
| Inputs | 3 linear lags of log-RV (day / week / month) | a 60-bar window of 5 causal channels |
| Parameters | 4 (OLS) | ~15k (2 stacked LSTM layers, 48/24 units) |
| Non-linearity | none | yes |
| Leverage effect | no (symmetric in the sign of returns) | **yes** — a signed-return channel lets a −3% day imply more future variance than a +3% day |
| "Bad volatility" | reported, not used | a downside-share channel is an input |

The HAR averages are handed to the network as explicit channels rather than left to be rediscovered from raw lags — a cheap inductive bias that matters a lot on ~1000 rows. Capacity is deliberately modest, because N-BEATS already taught this codebase what an over-parameterised network does to a ~700-row window.

**One numerical detail worth knowing.** The network predicts the mean of `log(r²)`, and exponentiating that mean does **not** give the conditional variance: with `r = σ·z`, `log(r²) = log(σ²) + log(z²)` and `E[log z²] = −1.27` for Gaussian `z` (the mean of a log-χ²(1)). The classic Jensen fix `exp(μ + σ²_resid/2)` is *also* wrong here, because the residual is log-χ² rather than Gaussian — with a residual variance near `π²/2 ≈ 4.93` it over-corrects by an order of magnitude in variance terms, roughly doubling the reported volatility. Vol-LSTM instead estimates the level offset from the training block directly (`c = log(mean RV) − mean(log RV)`), which reproduces the theoretical 1.27 on Gaussian data and self-adjusts for the percentile clipping and for genuinely fat tails. The effect is visible in the conformal multipliers: with the debiased level they land near the Gaussian 1.96, instead of ~0.9 (a multiplier well below 1.96 is the tell-tale sign that the cone is silently compensating for a mis-scaled variance forecast — the *interval* stays calibrated either way, but the reported per-step volatility does not).

**CNN-LSTM (`CNN_LSTM_model.py`) — Ch. 7, "Asset Allocation by LSTM over a CNN."** The zoo already had four sequence architectures, but each reads the look-back window one particular way: LSTM/GRU step through every bar equally; the Transformer attends globally (the most data-hungry option on ~1000 rows); the TCN is all convolution and no recurrence; N-BEATS flattens the window and discards ordering. CNN-LSTM occupies the remaining corner — **local translation-invariant pattern extraction, then temporal state**. The Conv1D stack acts as a learned multi-scale indicator bank (a filter can key on "three rising bars then a gap" *wherever* it appears in the window), and one max-pool halves the sequence so the LSTM models a handful of pattern activations over 45 steps rather than 90 raw bars — fewer recurrent parameters and a shorter gradient path, which is what a small-sample series wants.

Convolutions use `padding='causal'`, not `'same'`: with `'same'` a filter reaches *forward*, leaking future bars of the window into earlier timesteps. Harmless for an image classifier, wrong for a time series, and precisely the kind of leak that quietly inflates a validation score. `test_new_models_smoke.py` asserts the padding.

Both models reuse the shared engines (`forecast_nn_direct` for CNN-LSTM; HAR-RV's ACI machinery for Vol-LSTM's cone), so they inherit direct multi-horizon targets, training-block-only scaling, embargoed validation, and per-horizon conformal intervals for free — and any future improvement to those layers lands in them automatically.

### 24. Value-at-Risk estimation and VaR backtesting

Book Ch. 9 ("Risk Measurement Using GAN") opens with "Estimating value at risk" and "Computing methods and drawbacks" and closes with "Benchmarking results". `var_models.py` implements that arc, and in doing so fixes a real gap: the app already *reported* a 5% VaR and expected shortfall off HAR-RV's conformal residuals ([§13](#13-confidence-abstention-and-risk-outputs)), but nothing ever **validated a VaR number**. Interval coverage checks the two-sided 95% cone — a different question from *"does the left tail break exactly 5% of the time, and are the breaks independent?"*

That second clause is the one that matters. A VaR model can have textbook-perfect unconditional coverage and still be useless because every breach arrives in the same week — clustered breaches are what actually destroy a position.

**The estimators, and the drawback each one answers:**

| Method | Idea | Known drawback |
|---|---|---|
| **variance-covariance** | Gaussian quantile of `μ`, `σ` | equity returns are leptokurtic → systematically **under**-reserves; √t scaling assumes i.i.d. |
| **historical simulation** | empirical quantile of past returns | **unconditional** — a calm estimate persists into a crisis; noisy tail (5% of 250 bars = 12 points) |
| **cornish-fisher** | Gaussian quantile shifted by sample skew/kurtosis | asymptotic in the moments; **and it moves the wrong way at α = 5%** — see below |
| **FHS** (filtered historical simulation) | standardise by EWMA σ → bootstrap the residuals → rescale by the *current* σ | needs a volatility filter; MC noise |
| **generative** | block-bootstrap sampler (contiguous blocks preserve clustering *and* autocorrelation) | not a marginal-only sampler; GAN arm available but see below |

**The Cornish-Fisher trap (a real finding from running this).** The expansion's kurtosis term scales with `z³ − 3z`, which is **positive** for `|z| < √3 ≈ 1.732` — and the 5% quantile sits at `z = −1.645`, *inside* that range. So when excess kurtosis is large enough to dominate the skew term, the "fat-tail correction" makes the 5% quantile **less** negative and *reduces* the reserve, which is the opposite of the intuition. On RELIANCE's full history (excess kurtosis ≈ 50) this drove the 5% exception rate to 10.8% against a 1.45% average reserve — comfortably the worst method in the table — while at α = 0.5% the sign flips and the same expansion widens dramatically. Cornish-Fisher therefore ships as a documented **cautionary reference point**, not a recommendation; `test_var_models.py` pins both halves of the behaviour so the surprising row in the driver output reads as a known property rather than a suspected bug.

**On the GAN.** The chapter's technique is a GAN over returns. The idea is sound but, applied to a single stock, it hits a hard data limit worth stating plainly: a GAN on ~1000 daily returns is fitting a distribution from a sample that is small even for a histogram. In practice it mode-collapses or memorises, and its **tail — the only region VaR cares about — is where it is least trustworthy**. That is a bad trade for a risk number. So the default generator is the stationary block bootstrap (Politis & Romano): generative in the sense that matters (novel paths with the right dependence), no training, cannot mode-collapse, reproducible. `prefer_gan=True` opts into a compact 1-D GAN for comparison, imports TensorFlow lazily, and falls back silently on any failure — so enabling it can never break a caller, but its tail should be checked with `backtest_var` before it is trusted.

**Expected Shortfall is backtested too.** Every estimator reports `es_return` next to `var_return`, and an early version of this module validated only the VaR — repeating, one level down, exactly the criticism it was written to answer. `acerbi_szekely_z2` (Acerbi & Székely 2014) closes that. ES is famously **not elicitable**, so it has no scoring function that pins it down the way a quantile loss pins down VaR; the Z2 test sidesteps that by conditioning on the breaches actually observed. `Z2 < 0` means realised tail losses were **worse** than the ES promised (the dangerous direction); `Z2 > 0` means the model was conservative. Significance comes from a bootstrap under the null, and getting that null right is the whole trick — see the note below. `backtest_es` and `compare_es_methods` mirror the VaR harness. Read the two tables together: **a method can pass Kupiec (right breach *frequency*) while failing Z2 (breaches far *worse* than promised)**, and that combination is precisely the one that quietly under-reserves a portfolio.

> **A bug worth recording.** The first Z2 implementation built its H0 bootstrap by resampling the *observed* exceedance severities — which already encode the model's mis-calibration. The null therefore centred on the observed failure (measured: −1.045 instead of ~0), so the test could never reject on severity and reported **p = 1.00 for a model whose realised tail was 1.9× its predicted ES**. The pool is now re-centred to unit mean, imposing H0 while preserving the observed dispersion. After the fix, on fat-tailed data the Gaussian ES is correctly rejected (severity ratio 1.88, p = 0.0015) while historical simulation passes (severity ratio 1.01, p = 0.16; 1.02, p = 0.125 after the [§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code) units fix); on genuinely Gaussian data all methods pass. `test_es_null_distribution_is_centred_at_zero` pins it.

**The VaR backtests.** `kupiec_pof_test` (proportion of failures, χ²(1)) asks whether the breach *rate* is right; `christoffersen_independence_test` (χ²(1)) asks whether the breaches are **clustered**, by testing `π₀₁ = π₁₁` in a first-order Markov chain on the exception indicator; `christoffersen_conditional_coverage` sums the two on χ²(2) for the joint verdict. `backtest_var` runs a rolling out-of-sample harness (each estimate sees only past bars) and `compare_var_methods` ranks every method on one history. `avg_var_loss` is printed next to every *p*-value on purpose: a model can pass coverage by simply reserving an enormous amount, and the width is what that safety cost. Run it with `python tests/validation/run_var_backtest.py TICKER [--alpha 0.01]`.

#### Karasan, *ML for Financial Risk Management with Python*, Ch. 4–5: one pin added, the rest checked

Karasan's market-risk chapter covers the same ground as this section: variance-covariance, historical and Monte Carlo VaR, and ES. It adds two ideas. Checking both turned up one gap in this project's tests and three errors in the book.

**Liquidity-augmented ES is declined, for a measured reason.** The idea (Bangia et al., 1999) is sound: an exit costs half the spread, so add ½·(μ + kσ) of the proportional spread to ES. But the spread *level* is exactly what [§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement) showed this project cannot measure from daily bars. Corwin-Schultz reads 44 bp for the most liquid NSE quintile against ~1–3 bp actual. At a true large-cap spread the add-on is about 2 bp, against a 1-day 5% ES of ~300 bp, so under 1%. A precise-looking term built on a mis-measured input would make the number less honest, not more.

**The book's implementation has three errors worth knowing before porting it:**

1. **Its Gaussian ES is 3.42 × VaR.** `norm.expect(lambda x: VaR, lb=conf_level) / (1 - conf_level)` treats the confidence level 0.95 as a point on the return axis, so it integrates a constant over P(X > 0.95) = 0.171. The book's own IBM figures show it: 145,761 / 42,606 = 3.42. The correct ratio is φ(z)/(α·|z|) = **1.254** at 5%.
2. **The liquidity term is per share.** ½·P_last·spread (≈ $72) is added to the ES of a $1m position (≈ $145,000). Scaled to the position, the same spreads give roughly $5,600–$15,600, two orders of magnitude more.
3. **The spread average mixes units**: a dollar spread (`quoted`) is averaged with two proportional ones.

**This project's Gaussian ES was already right, but nothing proved it.** The only ES assertion was "ES is worse than VaR", which error 1 passes comfortably. `test_variance_covariance_es_matches_the_gaussian_tail_mean` now pins the ratio (1.254 at 5%, 1.146 at 1%) and checks it independently against the tail mean of 4 million Gaussian draws.

**SVR-GARCH (Ch. 4) is a cautionary example.** The book reports an RMSE of 0.000462 against GARCH's 0.0878. The test is misaligned: the model is trained on *next-day* 5-day realised volatility and scored against *same-day* realised volatility, which is its own first feature column. Even aligned correctly, the target shares 4 of its 5 days with that feature. Measured on five NSE large caps (2018–2024 panel, last 252 days):

| | RMSE, overlapping target (book's) | RMSE, next disjoint 5 days |
|---|---|---|
| "tomorrow = today" | 0.30–0.45% | 0.70–1.07% |
| a constant (training mean) | — | 0.56–0.93% |

On the overlapping target, persistence looks like skill. On a disjoint target it loses to a constant. An overlapping target rewards copying, not forecasting. `run_rv_overlap.py` reproduces the table.

**The rest of the book:**

| Ch. | Topic | Status here |
|---|---|---|
| 1 | Risk fundamentals, information asymmetry | Background |
| 2–3 | ARIMA, RNN, LSTM | The existing model zoo |
| 4 | ARCH, GARCH, GJR, EGARCH; NN volatility | `run_vol_comparison.py`, `vol_lstm_model.py` |
| 4 | Bayesian GARCH by Metropolis–Hastings | Parameter uncertainty: the neighbouring question [§33](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result) answered negatively |
| 5 | Marchenko–Pastur denoising | This project's VaR is single-asset, so there's no covariance to denoise. The book applies it to 3 assets, and its denoised VaR prints identical to the raw one |
| 5 | VaR, ES | This section; ES pin added above |
| 6 | Credit risk (PD models) | Different product |
| 7 | Liquidity measures; Gaussian-mixture clustering | Amihud, Roll, Corwin-Schultz and Kyle are in `microstructure.py`; the quote-based measures need quotes |
| 8 | Fraud and operational risk | Different product |
| 9 | Stock-price crash risk (NCSKEW, DUVOL, MCD) | Its logistic panel needs governance and accounting data. The price-only question was tested: see below |
| 10 | HMM vs Fama-French; synthetic data | `RegimeSwitching_model.py` is a Markov-switching model; `var_models` already has a block-bootstrap generator |

**Crash risk (Ch. 9), tested on prices alone: persistent, but not beyond volatility.** The book's crash model explains crashes with governance and accounting variables. The question that needs only prices, and that decides whether crash risk belongs in this product's risk panel, is narrower: does this year's crash risk predict next year's, once volatility (which the app already forecasts), past return and size are accounted for? `run_crash_risk.py` computes the literature's three measures on a year of weekly firm-specific returns (residuals from a market model with two leads and lags, with leads that fall in the next year dropped):
- **NCSKEW**, negative skewness;
- **DUVOL**, down-week against up-week variance;
- **CRASH**, a week more than 3.09 sd below the mean.

The panel is 400 survivorship-free names, 2018–2023: 1,835 stock-years and five year-to-year pairs. 2024 is excluded because its second half is in the reserved test period. The pass rule was fixed beforehand: the NCSKEW coefficient must have the same sign in all five pairs and |t| > 2.78 (5%, 4 df).

| Outcome next year | Controls | Coefficient per pair (18→19 … 22→23) | Mean | t | Verdict |
|---|---|---|---|---|---|
| NCSKEW | none | +0.078, +0.162, +0.109, +0.235, +0.187 | +0.154 | +5.52 | pass |
| NCSKEW | volatility, return, size | −0.002, +0.122, +0.023, +0.214, +0.073 | +0.086 | +2.24 | fail |
| DUVOL | volatility, return, size | +0.006, +0.083, −0.030, +0.240, +0.109 | +0.081 | +1.74 | fail |
| CRASH | volatility, return, size | +0.004, +0.091, −0.066, +0.102, −0.009 | +0.024 | +0.77 | fail |

**Raw crash risk persists** (rank correlation +0.15, positive in every pair), which agrees with Chen, Hong & Stein. For scale, volatility persists at +0.58. **Most of that persistence goes once the controls are in.** What remains (+0.09) has the wrong sign in one pair and misses the pre-set bar. The outcome a user would actually care about, whether the stock crashes next year, isn't predicted at all (t = 0.77). Sorting on this year's NCSKEW, next year's crash rate runs from 12.8% in the least crash-prone quintile to 18.6% in the most, but not monotonically. So crash risk doesn't go into the risk panel: the volatility forecast already carries what it would add.

### 25. Regime novelty from a denoising autoencoder

Book Ch. 4 ("Index Replication by Autoencoders") builds a vanilla autoencoder and then explores the **denoising** and **sparse** variants. `autoencoder_regime.py` implements all three on one architecture — but *not* for the obvious purpose.

**What it deliberately does not do.** The tempting use of an AE in a forecasting pipeline is dimensionality reduction: compress the feature window to a latent code and feed that to the predictor. This project has already run that experiment in a different guise and reported the answer honestly — market-context features and excess-return reframing both **hurt or did nothing** ([Empirical findings](#empirical-findings)), because at a 5-day single-name horizon the first moment is a random walk and extra representation capacity is mostly extra overfitting surface. Adding a learned compression in front of a model that cannot beat a random walk would be more of the same. So `latent_codes()` exists as an available research function and is wired into **no** forecaster.

**What it does instead.** An autoencoder trained on one regime reconstructs that regime well and anything else badly, so reconstruction error is a **distribution-shift detector** — and that plugs straight into the layer that carries this project's value, the serving gate. The app already abstains on degraded data (`data_quality`) and on models with no measured edge (`gating`). What it could not see is *"today's market state is unlike anything these models were fitted on"*. A backtest-derived confidence bucket is a statement about the **past** regime; it says nothing about a novel present. That blind spot is what this closes.

`regime_novelty` returns a verdict from the reconstruction error's percentile in a held-out reference distribution:

| Percentile | Verdict | Gate action |
|---|---|---|
| < 95th | `familiar` | none — normal confidence machinery applies |
| 95th–99.5th | `unusual` | **annotated only** (`"· unusual regime"` in the Basis column) |
| > 99.5th | `unprecedented` | `gating.apply_novelty_gate` forces every model to **"No edge"** |

The threshold split is deliberately conservative: equity data is fat-tailed and a 95th-percentile window is a normal monthly occurrence, so gating on it would abstain far too often to be useful.

**It is wired into the app**, behind `USE_REGIME_NOVELTY` in `config.py` (cached per company/interval, since the answer is identical for every model in a run) and applied immediately after the data-quality gate. It ships **off by default** for the same reason the IV tilt and the asymmetric cone do — on the calm 2021–26 window it should almost never fire, so its value cannot be demonstrated there, and an unvalidated feature does not ship on in this project. The stress test has since been run ([§71](#71-adaptive-conformal-for-every-model-and-the-novelty-gate-in-a-real-crash--neither-earns-its-place)): it flags the 2020 crash, but no earlier than a 20-day volatility reading, calls 2.7–5.9% of calm sessions "unprecedented" against 0.5% by design, and adds nothing the volatility reading does not, so it stays off. Every failure path returns `verdict='unknown'`, a no-op for the gate, so turning it on can only ever make the app *more* conservative.

**Three properties keep it honest.** *(1) Leak-free by construction* — the AE is fitted on the earliest 70% of windows, its reference error distribution is measured on a held-out middle 20% it never saw (in-sample errors are systematically too small and would make *everything* look novel), and only then is the latest window scored; inside a walk-forward backtest an origin-truncated frame yields a genuinely out-of-sample read. *(2) Scale-free* — windows come from the shared `compute_price_features` matrix and are standardised on training statistics, so a ₹100 and a ₹4000 stock give comparable numbers. *(This was only true across stocks, not within one: the matrix's first column is the raw adjusted close, standardised on the earliest 70% of history, so a stock that had since trended was scored novel for its **price level**. Measured over eight NSE names, the most recent 10% of windows were flagged "unusual" at a median 21% and "unprecedented" at 8%; dropping the price column cut those to 13% and 5% — TITAN, up 3.75× over the window, fell from 43% to 12%. The windows now use the eight scale-free columns ([§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found), `run_novelty_price_level.py`). Even so, 5% "unprecedented" against a design rate of 0.5% means the reference block, which sits next to the score block in time, is not an exchangeable null; the gate stays off by default.)* *(3) Never fatal* — TensorFlow is imported lazily and every failure path returns `verdict='unknown'`, which is a no-op for the gate.

The denoising variant is the load-bearing one: with a generous bottleneck a vanilla AE happily learns a near-identity map, which makes it a poor novelty detector. Injecting Gaussian noise during training only (and reconstructing the *clean* input) forces the network onto the data manifold, which is what makes an *off-manifold* window's error large. `cone_multiplier` (bounded to 1.0–1.5) is offered as a widening suggestion but applied **nowhere automatically** — the HAR-RV/Vol-LSTM cones are conformally calibrated, and silently multiplying a calibrated interval by an uncalibrated factor would break the guarantee that makes it useful. Treat it as a research knob to A/B, like the India-VIX tilt.


### 26. Book coverage: what was taken, what was left, and why

The additions in §22–§25 came from *Hands-On Deep Learning for Finance* (Troiano et al.). That book has 13 chapters and only five fed into this codebase, so this section records the whole triage — including the items that are **still open**, because a partial reading presented as a complete one is the same failure mode this project spends the rest of its documentation avoiding.

| Ch. | Topic | Status here |
|---|---|---|
| 1 | Deep learning for finance 101, autoencoder warm-up | Folded into §25 |
| 2 | Designing neural network architectures (MLP, CNN, RNN, LSTM, GRU) | Already covered by the existing model zoo |
| 3 | **Evaluating investment strategy** (IC, IR, Sharpe, Sortino, drawdown) | **Implemented** — §22 |
| 3 | **Tuning the model** (grid / random / Bayesian search) | **Implemented** — §27, nested; found no generalising gain |
| 3 | **Going live** (paper portfolios, benchmarking live vs model) | **Implemented** — §28 |
| 4 | **Index replication by autoencoders** (vanilla / denoising / sparse) | **Implemented**, repurposed as a novelty gate — §25 |
| 5 | **Volatility forecasting by LSTM** (vs RNN, vs GARCH, cumulative sq. error) | **Implemented** — §23 |
| 6 | **Trading rule identification by CNN** (3-class, asset-stratified) | **Implemented** — §29 (tabular GBM, not a CNN; reason given there) |
| 7 | **Asset allocation by LSTM over a CNN** | **Implemented** — §23 |
| 8 | Digesting news using NLP with BLSTM | Skipped — needs a licensed news feed; the same "fragile, frequently-empty dead code" argument that killed single-name option IV ([§19](#19-forward-looking-volatility-from-india-vix)) applies |
| 9 | **Risk measurement using GAN** | **Implemented**, via FHS + block bootstrap rather than a GAN — §24 |
| 10 | Chart visual analysis by transfer learning (ResNet50) | Skipped — rendering price windows as images to reuse ImageNet features discards the numeric precision the models already have; a well-documented dead end for tabular series |
| 11 | Better chart analysis using CapsNets | Skipped — exotic, little independent replication, and the project's own evidence is that *more* capacity is the wrong direction here |
| 12 | Training trader robots using deep RL (DQN) | Skipped — RL needs either a simulator or vastly more data than one ticker's history, and it optimises a *directional* policy, which [§15](#15-data-snooping-robust-model-selection-reality-check--spa) says has no edge to find |
| 13 | What next? (AutoML, distributed training, HFT) | AutoML overlaps the tuning gap; the rest is infrastructure, not modelling |

All three of the genuine gaps flagged in the original triage have since been closed: hyperparameter tuning in [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat), the forward paper-portfolio log in [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio), and cross-sectional classification in [§29](#29-cross-sectional-classification-pooling-the-universe). The original reasoning is kept below, because *why* each was deprioritised is as much a part of the record as the eventual result.

**1. Hyperparameter tuning (Ch. 3, pp. 128–135) — since closed, see [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat).** Every model in this repo carried **hardcoded** hyperparameters: XGBoost's `max_depth=5, learning_rate=0.03`, the LSTM's `64/64/32`, Vol-LSTM's `48/24`, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search. The book covers grid search, random search — noting that random beats grid at equal budget, because grid re-tests irrelevant factors along its regular lattice — and Bayesian optimisation (SMBO/TPE), which directs the search using a surrogate model instead of treating each trial as independent.

The honest counter-argument, and the reason it was deprioritised rather than forgotten: with the SPA verdict at *p* = 0.87, tuning is very likely to buy a *better-fit* model rather than a *predictive* one, and a search run against a walk-forward objective on ~40 origins is an efficient way to manufacture exactly the data-snooped edge [§15](#15-data-snooping-robust-model-selection-reality-check--spa) exists to detect. If it is built, it must be **nested** (inner search on past data only, outer evaluation untouched — the structure `calibration.validate_gate` already uses) and its winner must be run through `run_spa.py` before any improvement is believed. The place it is most likely to genuinely pay is **Vol-LSTM and HAR-RV's window lengths**, since volatility *is* forecastable and those windows were picked by convention, not measurement.

**2. Classification + asset stratification (Ch. 6) — since closed, see [§29](#29-cross-sectional-classification-pooling-the-universe).** The chapter frames trading as **3-class classification** (buy / do nothing / short) over a 30-day horizon, trained across **2,700 NASDAQ stocks** with an *asset-stratified* split — fit on 700 names, validate on 300 entirely different ones. Two things here are absent from this project:

- **There is no classifier at all.** Every model regresses a price or a variance, and P(up) is derived second-hand from a regression interval. The calibration harness measured that derived probability at **ECE ≈ 0.31 — badly overconfident** ([Empirical findings](#empirical-findings)). A purpose-built classifier with isotonic or Platt calibration is the standard fix, and an explicit "do nothing" class is a natural fit for a product whose central feature is *abstention*.
- **Pooling across a universe attacks the actual binding constraint.** Every "no edge" result here rests on ~1000 rows for one ticker. The book's stratification turns that into millions of rows and validates on unseen *assets*, which is a stronger generalisation claim than unseen *time*. This project's own cross-sectional probe ([§ cross-sectional](#empirical-findings)) found 12-1 momentum with the right sign but *t* ≈ 1, and explicitly concluded it needs **hundreds of names** — Chapter 6 is the recipe for exactly that. It is a deliberate product fork (rank a universe, don't forecast one name), which is why it was not slipped in as a tweak.

**3. Going live: paper portfolios and live-vs-model benchmarking (Ch. 3, pp. 135–142) — since closed, see [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio).** `prediction_log.py` now writes an append-only forward log at serve time, resolves realised outcomes as horizons mature, and reports live coverage drift, live gate validation and a paper portfolio. The remaining unimplemented parts of that chapter (soft launch, capital commitment, compliance sign-off) are organisational rather than technical and are out of scope for this codebase.

#### Every book reviewed, and what came of it

The table above triages one book chapter by chapter. This one is the ledger across all of them, kept for the same reason: **a book that was read and yielded nothing is a result**, and without a record of it the next reader re-reads it.

| Source | Taken | Where |
|---|---|---|
| Troiano et al., *Hands-On Deep Learning for Finance* | 5 of 13 chapters | §22–§25, §27–§29 (triaged above) |
| Klaas, *Machine Learning for Finance* | Backtest-bias checklist; drawdown **duration** | §33, `time_under_water` |
| Kaabar, *Deep Learning for Finance* | Fractional differencing + ADF/KPSS (Ch. 3) | §36 — a documented null. `Books/` holds the **Early Release** (229 pp, ends at Ch. 6); the rest is a maths, probability and Python primer |
| Sharma & Mehta (eds.), *Deep Learning Tools…* | Range volatility (Ch. 18); open interest | §40, §41 — both null |
| López de Prado, *Advances in Financial ML* | Microstructure (Ch. 19); PSR/DSR (§14.7) | §42, §43 |
| Tsang, *AI for Finance* | Directional Change (Ch. 6) | §44 — null, with two reusable guards |
| Hilpisch, *Artificial Intelligence in Finance* | Event-based backtesting (Ch. 11) | §45 — the rest was already here. **Two files of this title exist**: the complete 477-page edition (the one §45 is sourced from) and a 175-page **early-release preview** holding only Ch. 1–3. The preview is a strict subset — it stops before Ch. 4's "Debunking Central Assumptions", which is the chapter that makes Ch. 3's normative theory interesting — and needs no separate review. |
| Khraisha, *Financial Data Engineering* | Identifier permanence/immutability (Ch. 3) | §47 — the rest is enterprise data-platform infrastructure |
| Hilpisch, *Financial Theory with Python* | Risk-neutral vs physical measure (Ch. 5) | §48 — fixed a live calibration error in `iv_data.py`; the rest prices derivatives this project does not hold |
| Buzzelli, *Data Quality Engineering in Financial Services* | Precision, the 8th quality dimension (Ch. 3) | §46 — 7 of 8 dimensions were already covered |
| *Large Language Models in Finance* (hands-on guide: architectures, agents, RAG, governance, evaluation) | **A data fingerprint in the run manifest** (§15.8's data provenance); **an enforced reserved final test period** (§13.4's leakage-aware protocol); a pretraining-contamination caveat on Chronos-2 (§13.4.6) | [§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating): `data_fingerprint`, `diff_manifests`, `bhavcopy.HOLDOUT_START` and the holdout ledger. Model list under Chronos-2, and `chronos_model.py`'s docstring. The book is about LLMs for **text** — fine-tuning (LoRA, QLoRA, RLHF/DPO), RAG, agents, MCP tool governance, document and advisory systems — and this project has no text feed (§26 declined NLP for needing a licensed one). Its Ch. 13 leakage taxonomy was checked item by item: temporal and label leakage are [§6](#6-avoiding-data-leakage-look-ahead-bias)'s purging and embargo; restated-filing leakage is `fundamentals.py`'s as-of join and §18's adjustment audit; prompt and backtest overfitting are [§15](#15-data-snooping-robust-model-selection-reality-check--spa), §27's nested search and [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39); prompt, tool and agent-memory leakage do not apply, because there are no LLM agents here. Pretraining contamination was the one gap, because Chronos-2 is the one pretrained model the project ships. |
| Mladjenovic, *Stock Investing For Dummies* (7th ed.) | Stop-loss risk (Ch. 17); ex-dividend dates (Ch. 6); the buildable micro factors (Ch. 15); the great-stock hallmarks, ratio rules, horizons and risk types (Ch. 3, 4, 21, App. B) | [§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date) — P(stop hit) and a volatility-sized stop in the risk panel; an ex-dividend notice; a prediction-log dividend bias fixed; dividend yield a lead (really payer status), not shipped; [§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see) — a company check (six measurable hallmarks, the App. B ratio tests) and a risks-not-modelled table in the UI, information only; payout ratio and size band added. [§62](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time) — P(trailing stop hit) and P(target touched) in the risk panel: the book's 8% trailing stop is hit within a quarter 96% of the time |
| Thomsett, *Stock Market Math* | Market breadth (Ch. 8–9); the break-even return after tax and inflation (Ch. 1, 4); balance-sheet and operating trend tests (Ch. 6–7) | [§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one) — weak breadth forecasts next-month market volatility beyond HAR, leverage and India VIX (t −3.4, OOS error −5.5%), not returns, and adds under 1% for a single stock: shipped as a market-context caption. A break-even move and P(clearing it) in the risk panel; five trend tests in the company check. Two bugs fixed: failed bhavcopy downloads cached as holidays (ten 2024 trading days lost), and a BSE outage that emptied the company list |
| Benklifa, *Think Like an Option Trader* | Known unknowns: results days (Ch. 5); how an options trader reads a chain: implied volatility, the straddle's expected move, defined risk (Ch. 2–3, 6) | [§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day) — results sessions carry 2.86× and 3.74× an ordinary day's variance; a plain 95% band covered 82% / 89% / 93% of 1 / 5 / 10-session windows holding one, a measured widening restores ~95% out of sample and now widens the risk panel when NSE's calendar shows results in the horizon. A live options view (implied vol, expected move, the market's results-day move, protective-put cost). A ticker bug fixed: 5 Nifty 100 names (HAL, IDEA, INFY, LTM, TMCV) were forecast from a US listing; Budget, RBI-policy and F&O-expiry days measured and not shipped (unstable or no effect); an option-chain history started (421 rows, all 213 F&O stocks, first day) |
| Morales & Kacher, *Trade Like an O'Neil Disciple* | Pocket pivots, buying major gap-ups and the 50-day sell guide (Ch. 5); Dr. K's market direction model, distribution and follow-through days (Ch. 7) | [§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market) — pocket pivots: +0.03% over 21 days, no better than an up day without the volume signature (t −0.4), −0.18% after costs. Major gap-ups LAG the market by 1.65% over a month (t −2.9), a reversal; the book's gap-low stop brings leaders to zero. The market model's timing is no better than shifted copies of itself (p 0.14; at the book's 1.5% it trails holding). The heavy-volume 50-day break is the one rule that worked in its own direction (−1.02% against an ordinary break over a month, t −2.6, same sign in both halves): a lead queued for the reserved-period test. Shown as a checklist with the measured verdicts, not as calls |
| Hough, *Your Next Great Stock* | The eleven screen recipes and guru screens (Part 3); deal breakers and "talk yourself out of it" (Ch. 24); when to sell (Ch. 25); data mining and lurking variables (Ch. 6) | [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces) — the falling-knife deal breaker has no support: a 12-month loser still falling this week does no worse over a month than one that stabilised (+0.10%, t 0.6); waiting saves 0.31% only because every 12-month loser lags (net −0.08%, t −0.7). The XYZ experiment on NSE: the best 3 of 22 first letters earned +10.0%/yr in sample, below the +12.8% that random groups give, and +2.3% after (88th percentile of random picks); 'T' held up, but not because of the Tata group inside it. A live screens panel scores every recipe the free data supports and lists the rest as can't-run. Three data defects fixed: USD filers (Infosys's price/tangible book read 563×), Yahoo's P/S for them, and bonus issues in vendor EPS Insider buying (Ch. 19) from SEBI disclosures, point-in-time: after the book's screen, stocks beat a momentum- and reversal-matched benchmark by +1.71% over a quarter (t 1.4, 252 events), the book's size but not confirmable; queued as a reserved-period candidate. NSE moved the disclosures to a new endpoint on 2 May 2026; both are read Ch. 6's five signs applied to the five reserved-period candidates: the usable ones (50-day break, insider buying) have 12–24% power in the period so far; only residual reversal (98%) could be confirmed,; run on Jul–Dec 2024, unused by any panel study and before the period, it is **confirmed** (IC −0.0245, t −2.21, 73% of its published size) |
| Hilpisch, *Reinforcement Learning for Finance* | Validating synthetic returns (Ch. 5) | [§57](#57-synthetic-returns-hilpisch-reinforcement-learning-for-finance-ch-5--a-test-that-a-shuffle-passes-and-what-the-projects-own-generators-keep) — new `synthetic_check.py`. The book's KS test passes a shuffle that keeps none of the volatility clustering. The project's default block bootstrap keeps about a fifth (docstring corrected); its GAN keeps none. Multi-day VaR coverage didn't separate block lengths, so the default stays. The Ch. 6 agent's "never loses money" is reproduced, and beaten, by "always short" on its own simulator. |
| Mariani & Florescu, *Quantitative Finance* | R/S Hurst, Lo's modified R/S, DFA (Ch. 12–13); wavelets (Ch. 5) | [§56](#56-long-memory-and-wavelets-mariani--florescu-quantitative-finance-ch-5-1213--persistence-that-is-the-estimators-and-a-forecast-that-is-the-future) — new `long_memory.py`. The book's R/S reads 0.566 on NSE returns and 0.561 on the same returns shuffled: the persistence is the estimator's. Volatility memory is real (DFA 0.71). Its crash-warning claim holds weakly for DFA only, and DFA doesn't improve HAR-RV's forecast. Whole-series wavelet denoising forecasts direction at 61.8%, causal 50.1%. The rest is derivatives pricing. |
| Kanwar & Gupta, *Python for Trading on Technical* | Itemised Indian costs; trading through futures ("Cost of Trade") | [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code) — `india_round_trip_bps` and point-in-time `fno_members`. Residual reversal on F&O names breaks even at 5.2 bp: futures don't rescue it. Following the features up found a train/serve skew (`atr_norm` served 46% low) and a duplicate feature, both fixed. The book's indicators overlap existing features at 0.63–0.93; its SMA × RSI setup has PBO 0.79; of its five candlestick patterns only Marubozu survives, mostly as a move you can't trade; its MACD, BOP and Stochastic rules have no timing value outside the 2020 crash. |
| Hilpisch, *Python for Finance* | Variance reduction (Ch. 12) | [§54](#54-monte-carlo-noise-in-the-cone-hilpisch-python-for-finance-ch-12--variance-reduction-is-for-means-not-tails) — the cone's Monte Carlo edge moves 2–3% of its half-width between seeds; antithetic variates don't help a tail quantile and moment matching makes fat-tailed ones worse. The fallback path's 1,000 simulations raised to `N_SIMS`. Ch. 15's text contradicts its own output twice. The rest overlaps the author's other three books. |
| Yan, *Python for Finance* | The 52-week-high strategy (Ch. 8) | [§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it) — the book states the rule contrarian; NSE agrees with George & Hwang's opposite sign on every starting day (IC +0.039, t 1.85), but the book's gross isn't distinguishable from zero (t ≤ 1.56). Its January-effect test compares variances, not means. The rest is Python tooling and option pricing. |
| Hilpisch, *Python for Algorithmic Trading* | Probability of Backtest Overfitting; SMA, momentum and mean-reversion rules (Ch. 4) | [§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting) — `probability_of_backtest_overfitting` (CSCV). The book's brute-force grids look good in-sample and gross; net of costs and out of sample none of the three families beats buy & hold, and selecting from the grid is close to a coin flip (median PBO 0.42–0.52). The rest is infrastructure and broker APIs. |
| Kanungo, *Probabilistic Machine Learning for Finance and Investing* | The inverse fallacy (Ch. 4) | [§51](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4) — the confidence badge now prints the least the probability of no edge can be (Sellke–Bayarri–Berger), so 'DM p=0.14' can't be read as '86% sure'. Ch. 7's Bayesian market model predicts from the same day's market return. |
| Sadr, *Mathematical Techniques in Finance* | Jensen's inequality (A.2.4) | [§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code) — expected shortfall was a geometric mean of the tail labelled as an average, in `var_models` and the app's ES tile; fixed, overstated the average loss by up to 3.5% of itself. Bonds, futures, options and rates derivatives priced instruments this project doesn't have; Kelly sizes every bet at zero without an edge. |
| Karasan, *ML for Financial Risk Management with Python* | An exact pin on Gaussian ES (Ch. 5) | [§24](#24-value-at-risk-estimation-and-var-backtesting) — the book's Gaussian ES is 3.42 × VaR (correct: 1.254), and this project's only ES test would have passed it; now pinned. Liquidity-augmented ES declined: it needs a spread level §42 showed daily bars can't measure, and at real large-cap spreads it adds under 1%. SVR-GARCH's headline RMSE comes from scoring against its own input. Ch. 9's crash risk, tested on prices: persistent (+0.15), but not beyond volatility, return and size (t 2.24, fails a pre-set bar of 2.78). |
| Tatsat, Puri & Lookabaugh, *ML and Data Science Blueprints for Finance* | PCA residual reversal (Ch. 7) | [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39) — removing common factors nearly doubles the reversal t-statistic (−4.16 → −8.08) at the same turnover; the reconciliation also exposed §39's book as the best of five rebalance starting days, and re-running §45 on all five removed its stop-loss point estimate |
| Jeyaraman, *LLM Ops for Finance* | Wasserstein-1 drift detection (Ch. 7) | [§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction) — closes decile PSI's blind spot for tail-only drift. The rest is LLM operations: GPU and storage sizing, cloud vs on-prem, LLM fine-tuning, deployment pipelines, anonymisation, API design, real-time streaming. Ch. 7's other drift tools were already here (KS, covariate-shift detection, outcome monitoring in `prediction_log.py`, ensembles, an online-learning arm), and retraining pipelines don't apply because every forecast is a full refit on the latest data. |
| **Raj Chellia, Dutta et al. (eds.), *Generative AI in Finance*** | **Nothing** | A 22-chapter edited volume, mostly surveys: accounting and banking automation, fraud detection (ad-click, credit card, documents), ethics and regulation, HR compliance, generative product design and additive manufacturing, insurance on blockchain. Ch. 19's explainable AI is `explain.py`'s exact TreeSHAP ([§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)); Ch. 3's synthetic data is the block-bootstrap generator in `var_models.py` ([§24](#24-value-at-risk-estimation-and-var-backtesting)), chosen over a GAN when Troiano Ch. 9 was triaged. **Ch. 4 is the only testable claim, and it does not survive reading.** It reports a GAN at MAE 0.012 against ARIMA 0.034 and regression 0.038, with no named series, period or horizon, no zero or random-walk baseline and no significance test. For scale, simply forecasting **zero** on this panel's daily returns gives MAE **0.018** on the median NSE name, and only the calmest 5% of names reach 0.012; an ARIMA at 0.034 would be losing to zero by about 2×, which suggests a broken baseline rather than a strong competitor. It also reports the GAN's lower VaR (0.025 vs 0.055) as "better risk assessment". A lower VaR is a smaller reserve, not a better one. §24 backtests every VaR with Kupiec and Christoffersen precisely because a model can look good by under-reserving. |
| **Domash, *Fire Your Stock Analyst!*** | **Nothing** | Retail fundamental stock-picking. Tools #1–#10 (analyst ratings and earnings surprise, implied-growth and GARP valuation, target prices, growth and margin analysis, management quality, cash-flow red flags, insider/institutional ownership) all need fundamental, estimate or ownership history, which is [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)'s wall: `yfinance` gives a median of **5 quarterly periods** per NSE name (16% panel coverage, ~1 independent label date), and there is no free NSE source for estimates or ownership. Tool #11 (moving averages, short- vs long-MA comparison) is already `ma_ratio_{w}` in `ML_model.py`, and momentum was measured in §38. The pump-and-dump appendix is covered by `data_quality.py`'s abnormal-gap and abnormal-volume event flags. The PDF is a low-quality OCR scan. |
| **Test & Broker, *Artificial Intelligence in Finance*** | **Nothing** | **See below** |

**Why the last one yielded nothing.** Despite its title it contains no AI-in-finance content. It is four beginner texts bound together: *Stock Market Investing for Beginners* (what a broker is, how to read a stock quote), *Options Trading for Beginners* (prose descriptions of covered calls and iron condors, no formulas), *Python for Beginners* (design patterns, a Telegram bot, a Raspberry Pi thermal imager, a three-part Pygame Breakout tutorial) and a *Python Crash Course* (Day 1–7: tuples, indentation, `if`/`elif`). Full-text search returns **zero** matches for *backtest*, *Sharpe*, *GARCH*, *LSTM*, *cross-validation*, *overfitting*, *regression*, *Monte Carlo*, *time series* and *portfolio optimization*. The seven hits for *neural network* are a glossary entry, a chatbot, and **a CNN that detects cars in a parking lot**.

Its one genuinely finance-shaped chapter, "Top Indicators of a Winning Investment", lists trend lines, SMA, rate of change, RSI, MACD, Bollinger Bands and Fibonacci retracements. All but the last two are already in `ML_model.py` — RSI with proper Wilder smoothing, normalised MACD line and histogram, Bollinger band position, ATR — built with train/serve parity ([§6](#6-avoiding-data-leakage-look-ahead-bias)). Rate of change is `log_return_N`, already a feature. Only **Fibonacci retracement** is absent, and deliberately: its levels come from a number sequence, not from the data. [§44](#44-directional-change-tsang-ai-for-finance-ch-6--the-fifteenth-negative-result-and-a-null-that-survived-three-controls)'s `dc_state.retrace` is the principled form of the same intuition — where price sits between its recent extreme and a reversal — with the threshold chosen by the analyst and the result measured against a null.

The risk chapter (standard deviation, beta, VaR, CVaR, implied and historical volatility) is likewise fully covered by `risk_metrics.py`, `var_models.py` (five estimators plus Kupiec and Christoffersen backtests — [§24](#24-value-at-risk-estimation-and-var-backtesting)) and `iv_data.py`.


### 27. Hyperparameter search, nested so it cannot cheat

Book Ch. 3's "Tuning the model" (pp. 128–135) covers grid search, random search — noting that **random beats grid at equal budget**, because a regular lattice keeps re-testing values of parameters that turn out not to matter — and Bayesian optimisation (SMBO/TPE), which directs the search with a surrogate model instead of treating every trial as independent. `tuning.py` implements all three.

Until now, **every model here carried hardcoded hyperparameters**: XGBoost's `max_depth=5, learning_rate=0.03`, the LSTM's `64/64/32`, Vol-LSTM's `48/24`, N-BEATS' capacity (itself reduced by hand after it overfit). Not one was chosen by a search.

**Why a naive search would have been worse than none.** With the SPA verdict at *p* = 0.87, a search over *N* configurations evaluated on the same origins you later report is an efficient machine for manufacturing exactly the snooped edge [§15](#15-data-snooping-robust-model-selection-reality-check--spa) exists to detect: 50 configurations is 50 more chances for noise to look like skill. So the module has two **structural** guards, not optional ones:

1. **`nested_search` is the only entry point that produces a reportable number.** The search sees a training prefix (default 70%); the tail is untouched during the search and scored exactly twice at the end — once for the tuned config, once for the **default**. The output therefore answers *"did tuning help out of sample?"*, not *"what fit best in-sample?"*, and an inner win with a holdout loss — the signature of overfitting the search itself — is made visible rather than hidden behind a single best-score number. *(Until [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found) the tail was not in fact untouched: the holdout call passed the whole history and the ready-made objective re-scored two inner origins. The holdout call now passes `score_from`, and an objective that cannot accept it is refused.)*
2. **Every result carries its own selection-bias warning**, naming the number of configurations tried and pointing at `run_spa.py` as the required next step. A search result is a hypothesis, not a finding.

**TPE, and a bug worth recording.** The Bayesian sampler is a ~40-line Tree-structured Parzen Estimator (no GP library, replacing the book's `hyperopt` import): split the trials into a good set (best γ fraction) and a bad set, model `p(param | good)` and `p(param | bad)` as smoothed histograms, then sample from the good distribution and keep the candidate maximising `l(x)/g(x)` — equivalent to maximising Expected Improvement.

The first version took the deterministic argmax over sampled candidates and **collapsed**: once a configuration looked best it was proposed again and again. Measured on a 10×10 space it burned **12 of 30 trials on a single point** and finished *worse than random search* (−1.845 vs −1.296). Suppressing already-evaluated candidates (with a random unseen fallback) restores the exploration a continuous-space TPE gets for free:

| Sampler | Budget | Mean best score over 6 seeds |
|---|---|---|
| Random | 30 trials | −1.429 |
| **TPE (after the fix)** | 30 trials | **−0.001** |
| Grid (exhaustive) | 100 trials | −0.092 |

TPE at 30 trials now beats an exhaustive 100-trial grid, because the grid can only ever land on lattice points. `test_tpe_beats_random_at_equal_budget` pins the ordering.

**What it was pointed at, and what happened.** Not the price models — the honest expectation there is a better-fitting model with the same absent edge. The promising target is the **volatility** side, where signal demonstrably exists and the windows were picked by convention: HAR-RV's canonical Corsi lags `(1, 5, 22)` have never been measured on NSE names. `qlike_objective_har` scores the *variance forecast* (not the cone — the conformal layer adapts to whatever the variance does, which is how the 1.9× level bias hid for so long) using QLIKE, the loss robust to `r²` proxy noise. The result is [§ below](#does-tuning-har-rvs-lags-help-no--the-fifth-negative-result).

### 28. Going live: the forward prediction log and paper portfolio

Book Ch. 3's "Going live" (pp. 135–142) walks prototype → transition → **paper portfolio** → soft launch, with continuous **benchmarking of live results against model diagnostics**. `prediction_log.py` implements the parts that apply to a single-user app.

**Every evaluation before this one was backward.** Pick historical origins, re-fit, score against what already happened. That is the right way to *build* a model and an inadequate way to *operate* one, because it can only tell you how the model would have done on data that already existed when you tested it. Nothing recorded what the app **actually served**, leaving three questions unanswerable:

1. **Is the cone still calibrated?** A conformal interval is calibrated at fit time and decays silently as the regime moves. Coverage on 2021–26 backtest origins says nothing about coverage on what was served last month.
2. **Did the confidence gate work?** Buckets are assigned *before* outcomes exist, so whether they sorted realised skill is checkable only against outcomes that arrived afterwards.
3. **Would the served signals have made money?** [§22](#22-economic-evaluation-does-the-forecast-make-money) simulates a portfolio backwards over chosen origins; a paper portfolio runs what the app really emitted, in order, with no origin selection at all.

**Why append-only is the whole point.** A prediction is written before its outcome exists and is never rewritten — only annotated with the realised price once that price is knowable. That single property makes the resulting numbers immune to the data-snooping the rest of this project works hard to correct: no origin selection, no re-fitting, no choice of which forecasts to count. Every served forecast is in the sample, including the embarrassing ones. `test_resolution_never_rewrites_the_prediction_itself` pins it.

**What it records.** One JSONL row per (run, model, horizon step), including the **gate verdicts in force at serve time** — confidence bucket, data-quality mode, novelty verdict. Without that context the log could say whether forecasts were accurate but not whether the *gates* were doing their job, which is the more valuable question for a product whose central feature is abstention.

**Alerting that can be trusted.** `drift_report` compares live coverage to the nominal 95% with a binomial CI and **fires only when the CI excludes the target**. Below that bar the sample cannot distinguish drift from noise, and an alert that fires on noise teaches people to ignore alerts. It also isolates the most recent N predictions per model, so a year of good coverage cannot bury five misses in the last ten. Verified end-to-end: an honest cone (0.933, CI [0.87, 1.00]) stays silent; a deliberately over-confident one (0.083, CI [0.01, 0.15]) fires with a "recalibrate before trusting it" message.

> **A third self-inflicted bug, caught the same way.** `gate_validation`'s monotonicity check was `hits[i] <= hits[i+1]` — which **every tie satisfies**. An end-to-end run where both buckets had identical realised accuracy (0.517 vs 0.517) was duly reported as *"the gate IS informative"*. A gate that discriminates nothing being declared a success is precisely the over-claim this project exists to avoid. It now requires a strict spread (`_GATE_MIN_SPREAD`) and reports **"FLAT — the labels are not discriminating yet"** otherwise. `test_flat_gate_is_not_declared_informative` fails against the old behaviour.

> **A fourth, found by the full audit ([§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)).** "Never rewritten" made one mistake permanent. `resolve_outcomes` filled a target with the last bar at or before it, so a target whose bar had not printed yet — a feed one session behind, or a daily target looked up during its own session, since targets are stamped 00:00 and count as "matured" from midnight — was resolved at a **stale or partial price**, and resolution never revisits a row. A target now resolves only once the history runs strictly past it (a later date for daily, a later bar for hourly). `test_a_target_the_feed_has_not_reached_stays_pending`.

> **A fifth, from Mladjenovic Ch. 6 ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)).** The outcome was stored on the adjustment basis of a fetch made later, so a dividend going ex between the target and that fetch shrank it by the dividend yield. Outcomes are now the total return from origin to target measured in one fetch.

**It ships ON** (`USE_PREDICTION_LOG` in `config.py`), unlike every other toggle — because it changes no forecast and makes no claim, it only records what already happened, and a log that is off by default records nothing and is therefore worthless. Writing is best-effort and wrapped: a log failure is not a forecast failure. Read it with `python tests/validation/run_drift_report.py --resolve`.


### 29. Cross-sectional classification: pooling the universe

Book Ch. 6 ("Trading Rule Identification by CNN") frames trading as **3-class classification** — buy / do nothing / short — trained across **2,700 NASDAQ stocks** with an **asset-stratified** split: fit on 700 names, validate on 300 entirely different ones. `cross_sectional_panel.py` builds that panel; `cross_sectional_model.py` is the model.

**Why this was the highest-upside item in the book for this project.** Every "no edge" verdict here — SPA *p* = 0.87, MASE > 1 almost everywhere, six of seven models losing money — was measured on **~1000 rows of a single ticker**. That is the binding constraint, and no additional architecture fixes it. Pooling changes both the sample size *and the question*: not *"what will this stock do?"* (absolute, and the evidence says random walk) but *"which of these will outperform the others?"* (relative, with a far better documented empirical basis). This project's own earlier probe found 12-1 momentum with the right sign at *t* ≈ 1 and concluded it needed **hundreds of names**.

**The asset split is a stronger claim than the walk-forward split used everywhere else.** A temporal split asks "does this survive into next month?"; an asset split asks "does this exist in stocks the model has never seen?" — much harder to satisfy by memorisation, since there is no shared price level, regime history, or idiosyncratic noise to latch onto. The default `mode='combined'` requires **both**: unseen names *and* unseen dates. An asset split alone still lets the model see the same calendar period on both sides, so a market-wide regime present in both would inflate the score.

**Three leakage traps it is built against.** *(1) Survivorship* — the universe is an explicit literal list, not a live index scrape, because an index API returns **today's** constituents and back-testing those over ten years silently selects the winners; every dropped ticker is recorded with a reason. *(2) Cross-sectional look-ahead* — every rank is computed **within a single date's cross-section**, never from full-history statistics; `test_cross_sectional_ranks_are_within_date_and_causal` proves truncating the panel does not change a past date's rank. *(3) Forward columns as features* — one `fwd_return` left in the feature list and the classifier scores ~100% on a near-random problem, so the exclusion list is centralised in `feature_columns` and asserted directly.

**Why a gradient-boosted tree, not the book's CNN.** The book renders indicator windows as 2-D images because traders read charts as pictures. Here the features are already a **tabular cross-section**, and convolution's inductive bias — translation invariance over adjacent pixels — is not merely unhelpful but *wrong*: the adjacency between `rank_mom_21` and `rank_vol_21` is an artifact of column order. This project has also already paid twice for the "add capacity" lesson (N-BEATS, Vol-LSTM). The interesting variable is the **pooling and the split**, so the architecture is held boring on purpose and swapping it later is a controlled experiment rather than a confound.

**The calibration step is the part that matters most.** A classifier's raw `predict_proba` is a score that happens to lie in [0, 1], and gradient boosting is systematically overconfident. The model is fit on a proper-train block and its probabilities mapped through a per-class **isotonic regression** fitted on a separate, temporally-split calibration block (temporal, not random — names on the same day share the market move, so a random split would not be independent of the fit). Isotonic rather than Platt because it is non-parametric and can correct an arbitrary monotone distortion. ECE is reported before *and* after, so the effect is measured rather than asserted.

---

## The app: from a price line to honest uncertainty

The Streamlit app (`UI.py`) was reworked so the output is honest about what the models know. Pick a company (NSE/BSE only), interval (daily/hourly), horizon **in trading days** (hourly maps it to ~7 session bars/day), and **which models to run**, then Submit.

**The Model Comparison table** lists every selected model with:

| Column | Meaning |
|---|---|
| Predicted Price | the model's median forecast at the horizon |
| Change (₹) | rupee change from the last actual price |
| Signal Score (%) | forecast % change — the value the bull/bear call is made on |
| Conviction | the move ÷ half the model's own 95% band (|Conviction| ≥ 1 ⇒ move beyond its uncertainty) |
| Confidence | walk-forward reliability bucket: High / Medium / Low / No edge |
| Basis | plain-language reason for the verdict, tied to the DM p-value / coverage / data-quality (e.g. "no edge vs random walk (DM p=0.42)", "withheld — data quality") |
| Sentiment | Bullish / Bearish — or **"No edge"** when the gate found no edge (directional call withheld) |
| Direction | ▲ / ▼ — or **"–"** when withheld |

Above it sit **consensus cards** (median forecast, models bullish/bearish, and how many abstained), the **abstention banner**, and the **Risk & Probability panel** (P(up), P(gain/loss > threshold), VaR-style downside, 95% range, plus the **downside reads** — expected shortfall, downside/upside vol, and vol skew — all read off the empirical fat-tailed distribution; see [§13](#13-confidence-abstention-and-risk-outputs) and [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)). Each model's chart overlays history, the 95% band, the forecast, and the **naive random-walk baseline**. (Concepts behind these: [§13](#13-confidence-abstention-and-risk-outputs).)

**Performance & infrastructure:**
- **Model selection** — run any subset; the slow neural nets are opt-out for a fast run.
- **Per-model caching + parameter snapshot** — results are cached per (ticker, interval, horizon, model), and the run parameters are frozen at Submit, so interacting with a control doesn't silently recompute the suite.
- **GPU/CPU auto-detection** (`model_utils.configure_compute`) — TensorFlow models and Chronos use a GPU when present (with memory-growth enabled) and fall back to CPU; the active device is shown in the sidebar. The gradient-boosted trees stay on CPU on purpose (GPU tree training is slower on these small windows).
- **Reproducibility + resilient fetch** — every run pins all RNGs and shows an auditable **Run details** manifest (seed, versions, params); data is fetched with retries and a **last-known-good cache fallback** that downgrades to risk-cone-only when live data is unavailable (see [§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)).

> **New to the screen?** [Reading the screen: which numbers support a decision](#reading-the-screen-which-numbers-support-a-decision) walks the panels in the order they gate each other, gives the threshold for every number, and says which decision each one can actually support.

### 30. Testing the abstention claim: class weighting, and a t-statistic that was wrong

[§29](#29-cross-sectional-classification-pooling-the-universe) reported that the classifier called "do nothing" for **99.6%** of validation rows and read that as *emergent abstention* — a model volunteering that it had no view. That reading had an obvious duller rival that had not been ruled out: the neutral class is the largest by construction (**42.3%**), the classifier was fitted with `class_weight=None`, and an unweighted multiclass objective has a standing incentive to drift toward the majority class. "Concluded it had no view" and "took the cheapest route to a good log-loss" produce *identical* accuracy columns.

`tests/validation/run_class_weight_ab.py` settles it: same panel, same split, same seed, same hyperparameters, one variable changed.

| Arm | Abstention | Macro F1 | Val ECE | Rank IC (FM *t*) |
|---|---|---|---|---|
| **A** — `class_weight=None` (shipped) | **0.9970** | 0.2021 | 0.0116 | +0.0203 (*t* = 1.10) |
| **B** — `class_weight='balanced'` | **0.9895** | 0.2073 | 0.0091 | +0.0194 (*t* = 1.01) |

*Mean of three seeds (42 / 7 / 2024), 39 NSE names, 74,704 labelled rows, 12 unseen validation tickers, 574 validation dates.*

**The abstention survives.** Balanced weighting raises the payoff for calling short or buy by roughly 1.4× relative to neutral, and the model still declines on **98.95%** of rows — a shift of 0.74 percentage points. It abstains *even when the objective actively pays it to call*. That makes the original reading stronger rather than weaker, and it is now a measured claim instead of an inference. **Skill remains null in both arms** (no seed reaches |*t*| > 2), so this is abstention without hidden signal, exactly as reported.

`class_weight` is now a parameter of `build_classifier`, defaulting to `None` so every previously published figure remains the shipped configuration.

#### Two bugs the experiment exposed

**1. The IC t-statistic assumed independent observations.** `ic_t_stat(ic, n)` is the ordinary correlation t-test, valid for a single ticker's time series and *wrong* for a pooled panel: names on the same date share the market move, so 6,884 rows across 574 dates carry nothing like 6,884 independent observations.

The fix is the factor-research standard (Fama-MacBeth): compute the IC **within each date's cross-section**, then t-test that series across dates, with a **Newey-West** correction because a 5-day forward return sampled daily makes consecutive dates' ICs overlap by four days. `strategy_metrics.ic_by_date`, `newey_west_se` and `fama_macbeth_ic` implement it, and `evaluate` now reports the Fama-MacBeth figure as the headline with the pooled one labelled as overstated.

Honesty about magnitude: **on this data the two mostly agree.** The labels are already market-neutral and dispersion-scaled, so much of the date effect is removed before the IC is computed — which is why the originally reported *t* = 0.92 was not badly wrong. But the correction changed one verdict in three: at seed 2024 the pooled statistic gives ***t* = 2.43**, over the conventional threshold and reportable as a finding, while the honest one gives ***t* = 1.69**, which is noise. One false positive in three seeds is the whole argument for the correction. `test_pooled_t_stat_is_inflated_by_a_shared_market_effect` builds a panel with a pure daily shock and zero cross-sectional signal, where the pooled read returns IC > 0.5 at *t* > 20 and the Fama-MacBeth read correctly returns nothing.

**2. The classifier was not reproducible.** Two runs of the *same seed* gave abstention 0.9461 and 0.9552. LightGBM's multi-threaded histogram construction is not bit-reproducible by default — float addition order varies with thread scheduling. A project that ships a seed-pinned reproducibility manifest was quietly failing to reproduce this model, and an A/B is unreadable when an arm does not reproduce *itself*. Fixed with `deterministic=True, force_col_wise=True, n_jobs=1`, pinned by `test_classifier_is_bit_reproducible_across_fits`. It costs fit time; that is the correct trade for a research model.

Both bugs came out of the same exercise, and neither was the thing being tested — which is the argument for running the counterfactual rather than defending the original reading.
### 31. Architecture as configuration, and the hole it closed in the manifest

This project ships an auditable per-run manifest ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)) recording the seed, package versions and request parameters — and it did **not** record the network shape. That is a reproducibility claim with a hole in it: pinning the seed reproduces a fit only if the architecture is also fixed, and the layer stacks lived as literals inside `DL_model.py`, `CNN_LSTM_model.py` and `vol_lstm_model.py`. Change a hidden size and every earlier manifest silently describes a model that no longer exists, while still presenting itself as complete.

`architectures.py` closes it, with two mechanisms doing deliberately different jobs.

**Declared specs drive the build.** `SPECS` holds each network as a JSON-serialisable object — recurrent units, dropout schedule, filters, kernel and pool sizes — and the builders read from it. Override with an `architectures.json` (or `STOCKAPP_ARCH_FILE`) to change a network without touching model code. The defaults reproduce the previous hardcoded stacks *exactly*, and `test_defaults_match_the_previously_hardcoded_stacks` pins that: introducing the module had to change no forecast, or every published figure would silently refer to a different model.

**The manifest records the realised architecture, not the declared one.** `describe()` reads layer types, output shapes, parameter counts, optimizer and loss back off the *compiled Keras object*. This is the load-bearing choice. A spec merely stored beside a run is decoration — the same "configuration theatre" `config.py`'s tests exist to prevent — whereas introspection cannot drift from the fit it describes, and it covers models whose builders are not spec-driven. Each run now carries a compact block per model:

```json
"CNN-LSTM": {
  "n_layers": 14, "n_params": 36677, "optimizer": "Adam",
  "loss": "huber", "fingerprint": "6d57343ffa8b", "spec_driven": true
}
```

The **fingerprint** is a stable 12-character hash of the realised layer stack, so "was this the same network?" is answerable in one token instead of a nested diff. `manifest_block` deliberately stores only the summary: a six-model layer dump would bury the seed and versions sitting beside it in the Run-details expander.

**Honest scope, reported rather than glossed.** Spec-driven today: **DL (LSTM/GRU)**, **CNN-LSTM**, **Vol-LSTM** — the three whose builders take their sizes as arguments. **N-BEATS, TCN and Transformer are introspection-only**: their shapes are recorded faithfully but not yet controlled from here. `spec_driven` says which is which on every record, and `test_spec_driven_flag_is_honest_about_coverage` fails if a model claims control it does not have.

**A bug this caught in its own wiring.** The first version passed `forecast_nn_direct`'s `desc` string ("CNN-LSTM forecasts") where the registry key ("CNN-LSTM") was expected, so the lookup missed and the manifest reported `spec_driven: false` for a model that *is* spec-driven. Under-claiming is still misreporting, and it was invisible until a real end-to-end run was inspected. Every deep model now passes its key explicitly, checked statically by `test_every_deep_model_passes_its_registry_key_not_its_display_string` so the guard costs no training time.

Architecture overrides are surfaced in the console banner alongside feature-flag overrides ([§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) neighbours), because a run on a non-default network is not the shipped configuration and its numbers need reading that way. `python architectures.py` dumps every spec with its fingerprint.
### 32. Fundamentals: the right experiment, blocked by data — the seventh negative result

Every model here transforms the same OHLCV series, and six negative results point at the **information**, not the architecture, as the binding constraint. Fundamentals are the cheapest second axis available — unlike news/NLP they need no licensed feed — so the obvious next experiment was to add valuation, margin and leverage features to the pooled panel ([§29](#29-cross-sectional-classification-pooling-the-universe)) and re-run the classifier at a horizon where such signals plausibly act: a year, not five days.

`fundamentals.py` implements the machinery. `run_fundamentals_audit.py` establishes that **the experiment cannot currently be run**, and that finding — not a model result — is the deliverable.

**Feasibility first, deliberately.** Building the panel and discovering the coverage problem afterwards would have meant reporting a null that was really a data artefact. That is exactly the confusion [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) had to disentangle for the abstention result, and having paid for that lesson once, the audit came first.

| Measure | Result (12 NSE names, quarterly statements) |
|---|---|
| Tickers with any data | 12 / 12 |
| Median reporting periods per ticker | **5** (max 6) |
| Median first *knowable* date | **2025-05-15** |
| Covered span | 1.28 years of a **7.99-year** panel — **16%** |
| Independent 1-year label dates | **~1** |

For scale: §30's null result had **574** validation dates and still only reached *t* = 0.45. One label date cannot detect an effect of any size. `yfinance` returns a handful of recent filings, not a decade of restated history, so any cross-sectional fundamental result built on it would measure coverage rather than signal.

**The trap this module is built around.** `Ticker.info` returns *today's* trailing P/E, margins and book value, and it is available for every ticker over any date range — which makes it the single most inviting mistake in the field. Joining it onto a 2019 panel row gives that row information that did not exist for another six years, and the resulting classifier looks excellent while measuring nothing. Two structural defences, neither of them advisory:

- **The join refuses.** `current_snapshot` tags its output `point_in_time=False`, and `as_of_join` raises on such a frame rather than warning. Being *unable* to make the mistake beats being told not to.
- **Features are stamped by publication, not by period end.** A quarter ending 31 March is not public on 31 March — SEBI LODR allows 45 days. Dating features by period end leaks up to a quarter of forward information, so `available_from` adds the lag and the merge is a backward as-of on that date. Where the true availability date is uncertain, the module errs late: assuming publication *earlier* than reality leaks, assuming it later merely delays a feature.

`test_as_of_join_never_shows_a_row_a_future_statement` and `test_as_of_join_refuses_a_non_point_in_time_frame` pin both. Ratios are derived from raw line items rather than read off `info`, for the same reason.

**What would change the answer.** A point-in-time vendor with restated history (Compustat, CapitalIQ, Refinitiv) — or, at no cost but time, an archive built forward from today. `prediction_log.py` ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)) already demonstrates that pattern: record now, evaluate when the sample matures. Recording quarterly statements from this point on would make the experiment runnable in a few years, which is unsatisfying and is the honest timescale.

**Note that this stacks with the power problem, it does not replace it.** §30 showed 39 names are too few to detect a cross-sectional IC even when one exists; roughly 55–60 validation names are needed for *t* = 2. Fundamentals would have to clear *both* bars. Running them on the current universe, even with perfect history, would produce another underpowered null.

The module ships complete and tested so that the day a data source appears, the experiment is a configuration change rather than a rewrite. That is the useful form of a negative result: the reason is recorded, the machinery is ready, and nobody has to rediscover the coverage limit by building the panel first.
### 33. Epistemic uncertainty and psychological tolerance (Klaas) — the eighth negative result

Two ideas taken from *Machine Learning for Finance* (Klaas). One works and ships; one **failed its own test and is documented as a failure**.

#### The diagnostic that came free

Ch. 8 offers a rule of thumb: *"You should have 10 times as many samples as there are features."* Applied to the five deep models on ~1000 daily bars:

| Model | look-back | input dim | samples | ratio | |
|---|---|---|---|---|---|
| DL (LSTM/GRU) | 90 | 9 | 910 | 101 : 1 | OK |
| CNN-LSTM | 90 | 9 | 910 | 101 : 1 | OK |
| TCN | 90 | 9 | 910 | 101 : 1 | OK |
| Transformer | 90 | 9 | 910 | 101 : 1 | OK |
| **N-BEATS** | 60 | **540** | 940 | **1.7 : 1** | **under-determined** |

N-BEATS uses `flatten=True`, so its window becomes 540 independent inputs against 940 samples — about **one sixth** of the threshold. The recurrent and convolutional models share weights across time and see 9 inputs per step. This project had already documented N-BEATS underperforming and filed it as a behavioural lesson ("the add-capacity lesson"); it has a **structural** explanation, and one that was measurable all along.

#### Time under water (Ch. 4) — shipped

The book lists four backtest biases. Three — look-ahead, survivorship, overfitting — this project already guards against. The fourth it did not measure:

> *"Consider an algorithm that loses money for four months in a row before making it all back in a backtest... if the algorithm loses money for four months in a row in real life and we don't know whether it will make that amount back, then will we sit tight or pull the plug?"*

`max_drawdown` answers *how deep*. Depth is what you lose; **duration** is what makes someone abandon a strategy before it recovers — and a backtest reader knows the recovery happened, which is exactly the knowledge a live operator lacks. `strategy_metrics.time_under_water` adds `longest_underwater`, `currently_underwater`, `fraction_underwater` and `longest_losing_streak`, in years when a period count is supplied.

`currently_underwater` is reported separately on purpose: **a backtest that ends mid-drawdown looks calmer than it was**, and the run still open at the end is the one an investor would actually be sitting in.

#### MC-dropout epistemic uncertainty (Ch. 4) — built, tested, FAILED

Every interval this project ships is **aleatoric**: the conformal cone measures how wrong the fitted model has *been* and takes the model as given. It cannot say *how much would this forecast move under a different plausible fit* — **epistemic** uncertainty, which is large exactly when data is scarce. Since [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) established sample size as the binding constraint, that silence is on the one axis that matters most.

`epistemic.py` implements the book's method — activate dropout at prediction time, run *n* passes, take the spread. Cheap: no retraining, and every deep model already carries dropout.

Adding an uncertainty number is easy; showing it means something is not. So the module shipped with a prediction that could fail: **if this measures parameter uncertainty, N-BEATS — the 1.7:1 model — should be the most uncertain.**

| Model | dropout | epistemic share | data/input |
|---|---|---|---|
| DL (LSTM) | 0.30 | 0.104 | 101 |
| CNN-LSTM | 0.20 | 0.294 | 101 |
| **TCN** | **0.15** | **0.539** | 101 |
| N-BEATS | 0.20 | 0.331 | **1.7** |

**It failed.** Rank correlation between data-per-input and uncertainty: **−0.26** — the predicted sign, but weak — and the most uncertain model is **TCN**, not N-BEATS.

The check also caught a genuine bug on the way. The first version normalised the spread by the mean prediction; since the target is a **cumulative log return centred near zero**, that denominator was arbitrary (implied values spanned 0.0015 to 0.0147 across four models) and produced a rank correlation of **+0.77** — confidently backwards. Dividing by the model's own conformal sigma is the right comparison and was determinable in advance: both are in log-return units, and the ratio asks *what share of this model's uncertainty is parameter uncertainty rather than residual noise?* Correcting a broken denominator is legitimate; tuning further until the test passed would be the data-snooping this project exists to avoid, so the corrected result stands as the answer.

**Why it fails is identifiable, and it is not the data.** The lowest-dropout model (TCN, 0.15) has the *highest* spread and the highest-dropout model (DL, 0.30) the *lowest*, so the rate isn't driving it either. What drives it is **topology**: TCN puts dropout inside every dilated residual block, so variance compounds across many stochastic layers, while DL's dropout sits between recurrent layers whose 90-step state averages the noise away. MC-dropout spread is not comparable across architectures unless the dropout rate is itself calibrated per model — the known limitation that motivated Concrete Dropout.

**So it ships off** (`USE_EPISTEMIC`), documented as a failed cross-model comparison rather than quietly presented with a plausible story. It may still be meaningful *within* one model across dates or regimes — but that has not been tested, so it is not claimed. It is reported separately from the 95% band and never folded into it: trading a measured coverage guarantee for an unvalidated one would be a bad exchange.

Two implementation details worth keeping. Sampling uses the per-call `training=True` argument rather than the book's TF 1.x `set_learning_phase(1)`, because the global flag **stays set** and silently makes every later `predict` stochastic — `test_sampling_does_not_leave_inference_stochastic` pins that. And a model without dropout reports `available=False` rather than a spread of zero, since every pass through a deterministic network is identical and zero would read as supreme confidence rather than the absence of a measurement.

#### What the book confirms rather than adds

Ch. 4 endorses the forward log directly — *"deploy models silently and test them in the future... executes only virtual trades"* — which is [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio). Ch. 8's "Unit testing data" is `data_quality.py`. Both predate reading it.

Deliberately not taken: NLP (Ch. 5) needs the licensed feed already parked in [§26](#26-book-coverage-what-was-taken-what-was-left-and-why); RL (Ch. 7) hits the power wall §30 measured; computer vision (Ch. 3) is the wrong inductive bias for a tabular cross-section ([§29](#29-cross-sectional-classification-pooling-the-universe)). **Kalman filters** (Ch. 4) were the one item left genuinely open by that review, and have since been built — see [§34](#34-the-kalman-filter-the-model-class-that-was-missing).
### 34. The Kalman filter: the model class that was missing

The nineteen models here all did the same thing structurally: fit **fixed parameters** over a training window, freeze them, forecast. A Kalman filter carries a *state* re-estimated at every bar, so the level and slope it extrapolates from are the ones implied by the most recent data, continuously reweighted against their own uncertainty. That is a different answer to non-stationarity than refitting on a rolling window, and it was the one gap `Machine Learning for Finance` left genuinely open ([§33](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result)).

`kalman_model.py` implements a **damped local linear trend** on log prices:

```
level_t = level_{t-1} + φ · slope_{t-1} + w_level
slope_t =               φ · slope_{t-1} + w_slope
y_t     = level_t                       + v
```

φ ∈ [0, 1] damps the trend, so the *h*-step forecast adds `slope · (φ + φ² + … + φʰ)` — a geometric sum that **converges** rather than extrapolating a straight line. That matters more here than usual: an undamped slope fitted to a recent run-up would project it indefinitely, which is precisely the failure the evaluation layer exists to catch.

**The model is allowed to conclude it is a random walk**, and the fitted parameters are surfaced so it is visible when it does.

#### The result, on 7,696 real RELIANCE bars over 40 walk-forward origins

| | Coverage (target 0.95) | 95% CI | Mean width |
|---|---|---|---|
| **Native** (Kalman Gaussian) | **0.985** | [0.968, 1.002] | 46.60 |
| **Conformal** (shipped default) | **0.975** | [0.953, 0.997] | 43.70 |

Both **over-cover** — conservative rather than broken — and at 200 observations the two are **not distinguishable**; their confidence intervals overlap heavily. Conformal is about 6% narrower, which is why it stays the default, but this should not be reported as a win.

The genuinely interesting finding is the one the book advertised: **the native interval reaches near-nominal coverage with no calibration set at all.** No held-out residuals, no quantile, nothing tuned — it falls straight out of the state covariance. Not one of the other nineteen models can do that. On this evidence the Gaussian assumption survives contact with fat-tailed equity data better than expected, though 200 observations is not enough to say it survives the tails specifically.

Point forecast: RMSE 11.33 against the random walk's 11.15 — **1.6% worse**, i.e. parity. That is the *expected* result, not a disappointment: **70% of origins fitted a degenerate slope**, mean φ = 0.32. On a near-efficient price series a local-level Kalman fit *is* an adaptive random walk, and it says so instead of manufacturing a trend.

So its value here is the interval and the fitted structure, not the point forecast — the same honest position HAR-RV occupies.

#### A bug the tests caught, which would otherwise have been invisible

The first implementation fixed `r = 1` and scored the **raw** Gaussian likelihood over the noise ratios. On log-price data of scale ~0.02 that rewards whichever ratio pushes the innovation variance towards 1, so it drove `q → 0` regardless of the truth: a simulated process with a known q/r of **4.0 was fitted as 0.000**, and the likelihood fell monotonically across the whole grid.

Nothing downstream looked wrong. The model produced a flat forecast with a widening cone and plausible prices — exactly what a correct fit on a random walk produces. Only `test_fit_recovers_a_known_signal_to_noise_ratio`, run against a *simulated process with known parameters*, exposed it.

The fix is the **concentrated (profile) likelihood**: σ² is profiled out analytically, leaving a likelihood in the ratios alone. Recovery afterwards, on simulated data:

| True q/r | Fitted |
|---|---|
| 4.00 | 5.00 |
| 0.25 | 0.20 |
| 100.00 | 160.00 |

Within grid resolution in every case. `test_likelihood_is_not_monotone_in_q` now guards the specific failure directly.

The lesson generalises past this model: **a state-space fit that cannot recover known parameters from simulated data is not fitting anything**, and no amount of plausible-looking output on real data will reveal that. It is the same shape as the silent bugs found across the sample repos — a no-op normaliser, a leaky interpolator, a callback that could never fire.

#### Implementation notes

Estimation is a coarse grid over `(q_level/r, q_slope/r, φ)` with a local refinement — grid rather than an optimiser because state-space likelihoods are notoriously multi-modal and flat in places, and three parameters are cheap. Pure NumPy, no SciPy, consistent with `var_models.py`. The 2×2 covariance algebra is written out rather than delegated to `numpy.linalg`, which keeps the scalar Kalman gain visible to a reader checking it.

`use_conformal=True` is the shipped default and the native half-width is recorded alongside in `attrs` either way, so the comparison above can be re-run at any time. The model appears in the app as **Kalman (local trend)** — the suite is now **20 models**.
### 35. Feature drift and attribution — the ninth negative result, arriving from a new direction

Two more items from Klaas Ch. 8, both answering questions this project could not previously answer. Neither improves accuracy; one improves *operations*, the other improves *diagnosis*. The second produced a genuine finding.

#### Feature-distribution drift: the leading indicator

`prediction_log.drift_report` monitors **outcome** drift — live interval coverage against nominal 95%, binomial-CI-gated ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)). That is the right headline, but it is a **lagging** indicator: at a 5-day horizon it needs weeks of matured forecasts before it can say anything. If the *inputs* have moved away from what a model was fitted on, its forecasts are extrapolations regardless of how the last few intervals happened to land.

`feature_drift.py` measures that directly. The design choice worth explaining is why it **does not use the conventional PSI thresholds**.

Those bands — 0.10 "moderate", 0.25 "significant" — are folklore, and PSI is **biased upward on small samples**: two halves of the *same* distribution show non-zero PSI purely from binning noise, and the smaller the sample, the larger that floor. Measured:

| n | PSI between two samples of the **same** distribution | Folklore verdict |
|---|---|---|
| 50 | **0.3044** | "significant drift" |
| 100 | 0.1465 | "moderate drift" |
| 300 | 0.0713 | stable |
| 1,000 | 0.0077 | stable |
| 5,000 | 0.0038 | stable |

At n = 50 the folklore declares significant drift on **identical distributions**. Applying a fixed cut-off to short windows fires constantly, which is how monitoring gets switched off.

So significance is established by **permutation**: pool both samples, reshuffle the labels, recompute PSI many times. That gives the PSI attributable to binning noise *at these exact sample sizes and this exact binning*, and a feature is flagged only when it exceeds it. Same discipline as the binomial-CI gate — an alert that fires on noise teaches people to ignore alerts. The conventional bands are still reported, because a risk function will ask for them; they simply never decide.

The aggregate verdict also corrects for **multiple testing**: 40 features at α = 0.05 yields ~2 false positives by construction, so "some feature drifted" is not news.

**On real data** (RELIANCE, 750-bar reference vs 250-bar current, 26 features): **10 features flagged — WIDESPREAD DRIFT**, against 1.3 expected by chance. And they are coherently themed: `volatility_50`, `volatility_20`, `volatility_10`, `atr_norm`, plus `macd_norm`, `ma_ratio_50`, `rsi_14`. The **volatility and trend-regime family has moved; the raw return distribution, volume and calendar features have not.**

One honest note: at 750/250 the permutation test and the folklore bands happened to agree (both flagged 10). The calibration matters at *small* samples, which is exactly where a monitor gets run in practice — not at this one.

#### A blind spot in decile PSI, closed with Wasserstein

*(Added later, prompted by Jeyaraman, LLM Ops for Finance, Ch. 7, which lists Wasserstein distance beside KS for data-drift detection.)* PSI bins on **deciles of the reference**, which gives it an exact blind spot. If values move further out *within* the outer deciles, every bin keeps its count, and PSI does not move. KS has a softer version of the same problem. That's the shape of a volatility expansion: the bulk stays put and the tails widen.

| Constructed: outer deciles stretched 2.5×, bulk untouched | PSI p | KS p | W1 p |
|---|---|---|---|
| unchanged | 0.420 | 0.223 | 0.475 |
| tails stretched | **0.420** | **0.223** | **0.010** |

PSI and KS don't move *at all*. On real NSE daily returns (421 rolling pairs: a 250-day reference against the next 60 days, 43 names, 2018–2024), Wasserstein-1 flags drift that **both** PSI and KS miss in **8.1%** of pairs. Those pairs are volatility expansions: the newer window's 95th-percentile move is **1.52×** the reference's, against 0.88 for pairs Wasserstein calls stable. The detectors are complementary rather than nested: PSI alone catches 7.8% that Wasserstein misses.

So `drift_table` now runs both permutation tests, and a feature is DRIFT if **either** rejects at **α/2**. The Bonferroni split matters. Under no drift (300 trials), the previous PSI-only verdict false-alarmed at 0.060 and the new one at **0.067**, the same within sampling error (±0.013). A naive "either test at α" rule would run at **0.113**. Keeping the per-feature rate at α also keeps `summarise`'s "expected false positives = α × n" honest. Each row records `flagged_by` (`psi`, `w1` or `psi+w1`) so the *kind* of drift is visible.

Re-running this RELIANCE split on today's data: **12 features flagged** (WIDESPREAD DRIFT, 1.3 expected by chance): 9 by both tests and 3 by Wasserstein alone (`ma_ratio_20`, `bb_position`, `price_zscore`). Those three are modest location shifts PSI under-detected, not tail drift, and the raw return distribution doesn't drift on this window. So the tail-drift case rests on the panel evidence above, not on this ticker. Six tests pin the change, including the false-alarm rate.

> **Correction from the full audit ([§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)): most of "WIDESPREAD DRIFT" was the test, not the data.** Both permutation nulls shuffled single observations, which treats them as exchangeable — and rolling-window features are not: `volatility_50` today and tomorrow share 49 of 50 returns. Two windows of a *stationary* persistent series differ far more than an i.i.d. shuffle allows. Measured on i.i.d. returns with **no drift at all**, the old test flagged `vol_10` in 97% of trials and `vol_50` and `ma_ratio_50` in 100%, against a nominal 5%. The false-alarm test above used i.i.d. data, which is exactly the case where the flaw is invisible.
>
> The null now shuffles contiguous **blocks** twice as long as each feature's decorrelation lag (`block_length`), which keeps the i.i.d.-driven features at **0.02–0.05** and still catches a volatility doubling every time (`run_drift_false_alarm.py`). A strongly persistent GARCH path is still flagged 0.12–0.17, because its volatility genuinely wanders between windows and a thousand bars cannot tell that from a regime change. On this section's split, re-run on bhavcopy data to 2024-06-30, the old null flags **18 / 12 / 13** features on RELIANCE / TCS / INFY and the block null **6 / 0 / 1** — none of them volatility features. The "volatility and trend-regime family has moved" reading does not survive.

#### Attribution: exact TreeSHAP, and what it says about the project

Klaas Ch. 8 asks *"why did your model make the prediction it made?"* and reaches for LIME. For tree ensembles there is something strictly better: **TreeSHAP is exact** rather than a local surrogate, and both LightGBM and XGBoost implement it natively via `pred_contrib` / `pred_contribs`. So `explain.py` needs **no new dependency** — not `shap`, not `lime`.

Exactness matters more than usual here. A surrogate's disagreement with the model is indistinguishable from a genuine attribution, so an approximate explainer applied to a near-noise model produces confident-looking nonsense. Unsupported models return `None` rather than falling back to an approximation.

**But the reason to run it is sharper than interpretability.** This project's central claim is that most apparent edge is noise. Attribution checks that from the inside: a model driven by a few economically sensible features is making a structured claim; attribution spread thinly across dozens is what fitting noise looks like. The **Herfindahl index** makes it concrete — near `1/n` is uniform, near 1 is one feature explaining everything.

The method demonstrably detects concentration when it exists. On a synthetic model where only two of six features matter, those two took **95.6%** of attribution, Herfindahl **3.8×** uniform.

**On the real models:**

| Model | Top feature | Features for 50% | Herfindahl vs uniform |
|---|---|---|---|
| Single-ticker GBM (26 features) | `volatility_10` — **9.0%** | 8 | 0.0525 vs 0.04 — **1.3×** |
| Cross-sectional classifier (30 features) | `atr_norm` — **6.9%** | 11 | 0.039 vs 0.0333 — **1.2×** |

**Attribution is nearly uniform in both.** No feature carries the prediction. It takes 8 and 11 features respectively to reach half the attribution, and the top feature carries under 10%.

This is the ninth documented negative result, and the one that arrives from the most independent direction. *(Superseded in part: [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) re-ran this measurement on 400 names and attribution **does** concentrate there — top feature 14.8% against ~3% uniform. The near-uniform result below is a property of the 39-name universe, not of the problem.)* Every previous null came from *measuring outcomes* — RMSE against a random walk, SPA p-values, rank IC t-statistics. This one comes from **looking inside the model** and finding no driver to look at. It could easily have come out the other way: a concentrated attribution on economically sensible features would have been a genuine lead, and the synthetic control proves the method would have found it.

Additivity is verified rather than assumed (`base_value + Σ SHAP == prediction`, error 4.3 × 10⁻¹⁷ on real data), because a silently mis-parsed contribution layout would still produce plausible-looking attributions.

**One caveat stated in the driver itself:** attribution explains what the model *did*, not whether it was right. A confidently-attributed forecast from a model with no measured edge is still a forecast with no measured edge.
### 36. Fractional differentiation: measuring a choice made by convention — the tenth negative result

From Kaabar, *Deep Learning for Finance* (López de Prado's method). The one item in that book touching something this project does **by convention rather than by measurement**.

> **Which edition, and a citation corrected.** Earlier drafts cited this as "Ch. 9". The copy in `Books/` is the **Early Release** — 229 pages ending at Ch. 6 — which introduces fractional differentiation in a single paragraph in **Ch. 3** (§ "The Concept of Stationarity", p. 95) and forward-references a chapter it does not contain. The quotation in `fracdiff.py` and the S&P 500 figures (ADF p = 0.842 raw, 0.039 at d = 0.48) are from the *final* edition and are **not findable in that file**. The attribution is kept — it is almost certainly right for the final edition — but the edition is now named, because a reader checking "Ch. 9" against the only Kaabar PDF on disk would find no Ch. 9. What the Early Release *does* cover in full is the ADF/KPSS testing this module also implements, and every number below is measured here rather than quoted.
>
> Nothing else in that book is implementable: Ch. 1 is a data-science introduction, Ch. 2 a probability and information-theory primer, Ch. 4 linear algebra and calculus, Ch. 5's indicators (moving averages, RSI) are already in `ML_model.py` with Wilder smoothing and train/serve parity, and Ch. 6 is a Python tutorial.

#### The choice that was never tested

Every model here sees **d = 1** data. `prepare_log_returns` computes `log(price / price.shift(1))`; the features are `log_return_1…10`; the target is a cumulative log return. That guarantees stationarity — and it is *maximally destructive*, removing not just the trend but every trace of long-range dependence in the level. If prices carry persistent structure, d = 1 discards it before any model sees the data, and no architecture downstream can recover it.

Fractional differencing expands `(1 − B)^d` for non-integer *d* into an infinite binomial series: `w₀ = 1`, `wₖ = −wₖ₋₁ · (d − k + 1) / k`. At d = 1 the weights terminate at `[1, −1]` — an ordinary difference. At 0 < d < 1 they decay slowly and never terminate, and **that non-termination is the retained memory**.

`fracdiff.py` implements it. The book uses `pip install fracdiff`; the weights are a four-line recurrence, so this is a **no-new-dependency** implementation — ADF/KPSS come from `statsmodels`, already pinned.

#### What d = 1 actually costs, on real data

Minimum-*d* scan on **RELIANCE, 7,697 bars** (tol = 1e-4):

| d | ADF *p* | corr with level | window | stationary |
|---|---|---|---|---|
| 0.00 | 0.5816 | 1.0000 | 1 | no |
| 0.30 | 0.3577 | 0.9779 | 388 | no |
| 0.40 | 0.1580 | 0.9464 | 282 | no |
| **0.50** | **0.0292** | **0.8823** | 200 | **yes** |
| 0.70 | 0.0001 | 0.5848 | 97 | yes |
| **1.00** | 0.0000 | **0.0039** | 2 | yes |

**At the minimum stationary order d = 0.50, the series still correlates 0.88 with the price level. At d = 1 — what this project uses — the correlation is 0.004.** Stationarity is achieved either way; the difference is roughly all the memory.

That is the sharpest available statement of what the pipeline throws away.

#### Does the retained memory forecast anything? No.

`run_fracdiff_eval.py` runs the A/B: identical models, identical walk-forward origins, one arm with the existing feature set and one with frac-diff log-price columns at d = 0.50. 40 origins on 7,325 usable rows.

| Arm | RMSE | vs random walk |
|---|---|---|
| random walk | 0.048694 | — |
| baseline (d = 1) | 0.048897 | **−0.42%** |
| **frac-diff (d = 0.50)** | 0.046358 | **+4.80%** |

Frac-diff is 5.19% better than baseline in point estimate — and **Diebold-Mariano gives *p* = 0.436 on 40 origins**. Not significant. The honest reading is **no difference**.

This is the **tenth documented negative result**, and a cleaner one than most: frac-diff adds **no parameters**, so unlike N-BEATS and Vol-LSTM this null cannot be blamed on capacity. It changes the *representation*, and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) established the constraint is *information*. A representation change cannot create signal that is not there.

**One practical constraint worth recording:** the window length is a function of *d*. At tol = 1e-5, d = 0.4 needs **1,458 bars** — longer than the 1,000-bar cap the single-ticker models use, which would produce an all-NaN column. Loosening to tol = 1e-4 gives 282 bars, which is workable. That tension is real: a looser tolerance truncates the memory sooner, partially defeating the purpose.

#### Two bugs found — one mine, one pre-existing

**Mine, and it mattered.** The first version of the A/B trained on rows up to `o − 1` while evaluating `y[o]`. Row `o − 1`'s target spans `[o−1, o−1+h]`, which **overlaps** the evaluation target — the overlapping-label leak our own `embargo` exists to prevent. It reported the baseline at **+20.20% vs the random walk**.

That number is what gave it away: a 20% RMSE improvement over a naive baseline is flatly inconsistent with every other result in this project. With the embargo applied, the same arm scores **−0.42%** — parity, as expected. The leak was worth roughly **20 percentage points of imaginary skill**, and the only thing that caught it was the result disagreeing with the rest of the evidence.

**Pre-existing, in `get_data.py`.** Running the scan surfaced `Error processing data: 'charmap' codec can't encode character '✅'`. Seven status messages in the currency-conversion path contain emoji, and an unguarded `print` of them raises `UnicodeEncodeError` on a legacy Windows code page — *inside* a `try/except`, so it was caught and re-reported as a generic data error that masked what actually happened. This is exactly the exposure flagged when `console.py` was built ([§34's neighbour](#the-same-story-in-the-terminal)) and deferred as out of scope; it has now fired for real. All seven now route through `console._write`, which degrades instead of raising.

#### One inconsistency noted, deliberately not fixed

The DM test on baseline-vs-random-walk returned `NaN`. That is `diebold_mariano`'s own guard firing correctly: it computes the Newey-West long-run variance with **unweighted** autocovariances, which can come out negative, and it returns NaN rather than a bogus p-value.

Worth recording that `strategy_metrics.newey_west_se` — added in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) — *does* apply a Bartlett kernel, which cannot go negative. The two are inconsistent. Adding the kernel to `diebold_mariano` would be a genuine improvement, and it would **change every DM p-value published in this document**. That is not a change to make silently as a side effect of a frac-diff experiment, so it is recorded here as a known issue rather than applied.

#### What else was in the book

Nothing else worth taking. **Forecasting threshold** (p270) is the `Conviction` column and the abstention gate. **Multiperiod forecasting** (p277) is direct multi-horizon. **Time-series cross-validation** (p275) is walk-forward with embargo. **Continuous retraining** (p272) is train-on-demand. **COT data** (p307) is US futures positioning and does not exist for NSE equities. Chapters 1–6 are foundations; Ch. 7–8 the model zoo already built; Ch. 10 deep RL, blocked by the power wall §30 measured.
### 37. The Diebold-Mariano kernel fix, and the Windows race it uncovered

[§36](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result) recorded an inconsistency rather than fixing it: `diebold_mariano` computed its Newey-West long-run variance with **unweighted** autocovariances, while `strategy_metrics.newey_west_se` (added in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong)) applied a **Bartlett** kernel. Fixing it would move every published DM p-value, so it was flagged rather than changed silently. This section is that fix, done properly — with the before/after measured.

#### The bug

An unweighted sum of autocovariances is a *truncated* (rectangular) kernel, and it is **not positive semi-definite**. On short samples the estimated variance can come out **negative**, and the function then returns `NaN` rather than a p-value. That guard is correct — a p-value from a negative variance would be nonsense — but it is a silent loss of power: **a test that declines to run is a test that never rejects.**

Bartlett weights `1 − k/h` are PSD by construction, so the variance cannot go negative.

#### How often it actually fired

Simulated, 400 comparisons per cell:

| h | n | NaN (old) | NaN (new) | mean \|Δp\| | verdicts flipped @0.05 |
|---|---|---|---|---|---|
| 1 | 20–120 | 0 | 0 | **0.0000** | **0** |
| 3 | 20 | 25 | 0 | 0.0492 | 27 |
| 5 | 20 | **81** | 0 | 0.0691 | 24 |
| 5 | 40 | 28 | 0 | 0.0567 | 30 |
| 10 | 20 | **190** | 2 | 0.0945 | 15 |

Two things stand out. **At h = 1 the change is exactly zero** — the lag loop never executes — which bounds the blast radius: every single-step DM figure ever published here is bit-identical. And at h = 5, n = 20 the old version **refused to produce a p-value in 20% of cases**; at h = 10, n = 20, in **48%**.

That regime is not hypothetical. The serve-time confidence gate runs **3 origins** at `h = horizon`, so a 5-day forecast gives ~15 error points — squarely inside it.

**The failure was conservative, which is why it was never noticed.** `confidence_bucket` treats a NaN p-value as "not significant", so an affected model could never reach **High** or **Medium** — it capped at **Low**. The app was under-rating models, not over-rating them. That is the safe direction, and still wrong.

#### What changed in the published figures

Measured on **identical real error series**, captured from `walk_forward_backtest` and scored under both kernels (6 splits, h = 5, n = 30):

| Ticker | Model | old *p* | new *p* | Δ |
|---|---|---|---|---|
| TCS.NS | ARIMA+GARCH | 0.1920 | 0.2155 | +0.0235 |
| TCS.NS | Ensemble-Stack | 0.8679 | 0.8451 | −0.0228 |
| TCS.NS | XGBoost | 0.7761 | 0.7829 | +0.0068 |
| RELIANCE.NS | ARIMA+GARCH | 0.3836 | 0.3637 | −0.0199 |
| RELIANCE.NS | Ensemble-Stack | 0.4233 | 0.4029 | −0.0204 |
| RELIANCE.NS | XGBoost | 0.8379 | 0.8126 | −0.0253 |

**Maximum movement: 0.025.** No verdict changes at the 0.05 or 0.10 thresholds. **One** changes at 0.20 — TCS ARIMA+GARCH crosses from 0.1920 to 0.2155, dropping that configuration from **Medium** to **Low**, again in the conservative direction.

So: the fix is correct and necessary, and **no conclusion in this document changes**. The empirical findings, the SPA verdict and the "no confirmed winner" framing all stand.

#### The Windows race the fix uncovered

Re-running the suite after the change produced an intermittent failure — and, tellingly, in a **different test each time**: three separate drift-report tests failed across runs, each passing in isolation. That pattern says shared non-determinism, not a broken assertion.

The tests already used isolated temp directories, so it was not file contamination. The cause was found only after **hardening the test harness**: `log_forecast` swallows every exception on purpose (a logging failure must never break a forecast), which in a test converts a transient write failure into a *short log*, surfacing several assertions later as an unexplained coverage number. Asserting that every write succeeded turned the puzzle into a named failure, and the named failure pointed at `_rewrite`:

```
PermissionError: [WinError 5] Access is denied:
  '...\predictions.jsonl.tmp' -> '...\predictions.jsonl'
```

`os.replace` is atomic on POSIX. On Windows it raises whenever another process holds even a momentary handle on the destination — an antivirus scanner or the search indexer touching a just-written file is enough. It is a race, failing roughly one run in ten.

**This is a production bug, not a test artefact.** `resolve_outcomes` is what `run_drift_report.py --resolve` calls on the real log; hitting this would crash the resolve and leave a stray `.tmp` beside the log. Fixed with retry-and-exponential-backoff — the standard Windows-safe pattern — and the temporary file is removed if every attempt fails, so a failed resolve cannot leave litter a later run mistakes for data.

The general lesson is the one this project keeps rediscovering: **the deliberate swallow that makes a system robust in production is the same swallow that makes it undiagnosable in testing.** The fix is not to remove it, but to make the test harness refuse to tolerate it.

### 38. Universe expansion: point-in-time data, and the first positive result

Ten negative results in this project point at the same suspect. The cross-sectional null in [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) — rank IC +0.0111 at **t = 0.92** — was read at the time as a *power* result rather than evidence against the approach: real cross-sectional ICs are 0.02–0.05, and detecting one needs roughly **55–60 validation names** where 39 were available. [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) deferred to the same wall.

Breadth was the one lever never pulled. This section pulls it — and most of the work turned out to be in the **data source**, not the experiment.

#### The obvious source is a trap

NSE publishes `EQUITY_L.csv`, and `get_data.get_bse_nse_data` already fetches it: 2,565 listings, 2,302 with `SERIES == EQ`, and **1,154** listed early enough to have full history. Ample to draw 400 names from.

It is also **a list of companies that still exist**. Measured against Wayback Machine snapshots of the identical URL — the current `archives.nseindia.com` domain has only two, but the pre-2020 `nseindia.com` URL has **33 going back to 2006**:

| Snapshot | EQ names then | Absent from today's list |
|---|---|---|
| 2017-07 | 1,465 | **392 (26.8%)** |
| 2018-12 | 1,456 | 306 (21.0%) |
| 2021-05 | 1,563 | 209 (13.4%) |

**A quarter of the 2017 universe is gone.** Drawing a 2018–2026 panel from today's roster selects companies *on the basis of having survived the window*, then asks a model to predict their returns over it. A larger biased sample is worse than a small honest one, because it produces a confident answer.

The gap cannot be patched from the existing feed: of 30 randomly sampled vanished symbols fetched from yfinance, **23 returned no data at all**, 6 partial, 1 usable. yfinance discards delisted history.

This is not hypothetical for this project. **`TATAMOTORS.NS` — one of the 40 names in `DEFAULT_UNIVERSE` — now returns zero bars from yfinance** after the 2025 demerger, while bhavcopy still carries all 490 of its 2018–2019 sessions. That is precisely why the published cross-sectional work ran on *39* usable names rather than 40. The bias had already started eating the universe.

#### Bhavcopy: point-in-time by construction

NSE publishes a **daily bhavcopy** — one file per trading day listing every instrument that traded. There is no membership list to get wrong and no survivorship correction to apply: whatever traded on 2 January 2018 is in the 2 January 2018 file. `3IINFOTECH`, `ADANITRANS`, `ADLABS` and `ADHUNIK` are all there with full OHLCV.

`bhavcopy.py` is that loader. Two formats, found by probing rather than assumed:

* **legacy** zipped CSV — serves 2017-01 through **2024-07-01**, 404 from 2024-07-08
* **UDiFF** via `nselib` — serves **2024-01** onward

`fetch_day` tries legacy and falls back, so the cutover is absorbed rather than hardcoded. The six-month overlap is a **free cross-validation**, and `test_readers_agree_on_the_normalised_schema` pins that downstream code cannot tell which source produced a row. The cache is one gzipped file per day — 2,500 days, ~105 MB, ~33 minutes once. A missing day is stored as an *empty* file, because a weekend and an exchange holiday are indistinguishable from date arithmetic and must be discovered, never interpolated.

#### The harder half: raw prices

Bhavcopy carries **raw traded prices**. yfinance was silently handling splits and bonuses; bhavcopy does not, and an unadjusted 1:10 split reads as a **−90% return** that would poison every momentum feature in the panel. `PREVCLOSE` is no help — checked on seven 2019 split/bonus ex-dates it equals the prior day's raw close exactly (ratio 1.000). NSE does not adjust it either.

So the adjustment is ours, parsed from `nselib`'s corporate-action feed (coverage verified back to **January 2017**):

| Subject | Adjustment |
|---|---|
| `Bonus 1:4` | ×1.25 |
| `Face Value Split From Rs 10/- ... To Rs 2/- ...` | ×5 |
| `Bonus 1:2/Face Value Split ... Rs 2/- To Re 1/-` | ×3 (compound) |
| `Interim Dividend Rs 2/- Per Share` | Rs 2 cash |
| `Rights 19:67 @ Premium Rs 215 Per Share` | via TERP |

Dividends are included because the pipeline models log returns off **`adj_close`** (`get_data` ~line 352), yfinance's *fully* back-adjusted series. Adjusting only for splits would make the new panel incomparable with every figure already published here.

**A bug caught during validation.** GPIL filed a 10→5 split **and** a 1:1 bonus as two separate records on 2021-10-26 — true factor 4.0. An early version deduplicated by `(symbol, ex_date)` and parsed 2.0, an **82% error**. Same-day actions must *compound*; `test_same_day_actions_compound` exists so it cannot return. Every correction is expressed as the ratio of theoretical post-event price to cum price, so compounding is correct by construction rather than by patch.

#### Validated against yfinance, which found the one thing left out

A per-event check (does the price drop by the parsed factor?) is confounded by the stock's genuine move that day — which is why one of 18 hand-checked events came in 13% off with a perfectly correct factor. The stronger test compares the **whole return series** against an independent adjusted source. `run_bhavcopy_audit.py` does that over 2018–2019:

| | |
|---|---|
| Median return correlation | **1.00000** |
| Names above 0.999 | **24 / 24** |
| Names bit-identical | 14 |
| Worst single-day gap | 0.83% |

It did not start there. The first run gave **22/24**, with BHARTIARTL (0.98507) and TATASTEEL (0.99537) failing — and both turned out to be **rights issues**, which the parser did not handle. Adding theoretical-ex-rights-price adjustment moved them to 0.99986 and 0.99999. Worth recording: NSE quotes the **premium over face value**, not the subscription price, so Bharti's `Rs 215` is really Rs 220 against a Rs 5 face value, and the face value has to come from the feed's `faceVal` column. Tata Steel's subject carries a fully-paid *and* a partly-paid tranche; only the first is taken, because a partly-paid share is a separate instrument and folding it in would be wrong in a worse way than ignoring it.

`adjust_prices(as_of=...)` applies **only actions known by that date**, which closes the back-adjustment look-ahead `tests/audit_price_adjustment.py` documented and yfinance cannot avoid.

#### The experiment

`run_universe_expansion.py` runs the **identical** experiment at four universe sizes — same features, labels, split rule, model and horizon. Only breadth varies.

The integration is one function, deliberately: `cross_sectional_panel.build_panel` already accepted an injected `fetch_fn` so its tests could run offline, and `bhavcopy.bhav_fetcher` slots into that seam. **Not one line of `cross_sectional_panel.py`, `cross_sectional_model.py` or the feature code changed.** Had the pipeline been rebuilt alongside the data source, no comparison with the published 39-name result would have meant anything.

Window 2018-01-01 → 2024-06-30, horizon 5 days, `mode='combined'` (unseen names **and** unseen dates), seed 42:

| Requested | Usable | Val names | IC dates | Rank IC | **FM *t*** | Abstain |
|---|---|---|---|---|---|---|
| 39 | 39 | 12 | 464 | +0.0283 | 1.31 | 0.968 |
| 100 | 100 | 30 | 464 | +0.0048 | 0.24 | 0.956 |
| 200 | 197 | 59 | 464 | +0.0375 | **2.37** | 0.937 |
| 400 | 332 | 100 | 464 | **+0.0396** | **2.24** | 0.922 |

The 39-name row reproduces the project's own history — *t* = 1.31 against the published 0.92 — on a different window and a differently-selected universe. That is the control.

> **Re-measured in the full audit ([§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)).** The table above was produced with the 30-feature set. [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code) removed `bb_position` (an exact duplicate of `price_zscore / 2`), which changes LightGBM's column sampling, and this table was never re-run. With the shipped 29 features and seed 42:
>
> | Requested | Usable | Val names | IC dates | Rank IC | **FM *t*** | Abstain |
> |---|---|---|---|---|---|---|
> | 39 | 39 | 12 | 464 | +0.0068 | 0.34 | 0.975 |
> | 100 | 100 | 30 | 464 | −0.0063 | −0.29 | 0.948 |
> | 200 | 197 | 59 | 464 | +0.0378 | **2.30** | 0.933 |
> | 400 | 332 | 100 | 464 | **+0.0373** | **2.12** | 0.921 |
>
> Restoring `bb_position` reproduces the 39-, 100- and 200-name rows above **exactly**, so the feature set is the cause. The 400-name row also moved for a second reason: `build_panel` re-fetches NSE's corporate-action feed on every run, and revisions there shift the adjusted prices of the largest panel most (with `bb_position` restored it reads +0.0415, t = 2.38). The single-seed headline is therefore a draw, which is what the seed study below exists to absorb — and the seed study reproduces: median IC **+0.0372**, median *t* **+2.40**, 7 of 8 seeds above 2, none negative (published +0.0367, +2.42, 7/8, 0/8). The finding stands on the robust measure. Re-run on a frozen copy of the feed ([§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it)), with renamed companies' corporate actions now included ([§74](#74-renamed-companies-lost-their-corporate-actions)), it reads median IC +0.0392, median *t* +2.58, 7 of 8 above 2, none negative. The feed is no longer fetched afresh on every run.

#### It was not reported until it survived being attacked

**The table is not monotonic.** Under a pure power story *t* should climb roughly with the square root of the validation count; instead 1.31 → **0.24** → 2.37 → 2.24. The dip at 100 is larger than sampling noise should comfortably allow, and every row is **one seed**. §30 already recorded a case where one seed gave a reportable *t* = 2.43 where the honest read gave 1.69.

`run_universe_seeds.py` builds the panel once (it does not depend on the seed) and re-splits, re-fits and re-evaluates, then repeats the whole thing on two **disjoint periods**:

| Window | IC dates | Rank IC median | FM *t* median | *t* > 2 | Negative IC |
|---|---|---|---|---|---|
| Full 2018-01 → 2024-06 | 464 | +0.0367 | +2.42 | 7 / 8 | **0 / 8** |
| A: 2018-01 → 2021-06 | ~230 | +0.0336 | +1.92 | 2 / 6 | **0 / 6** |
| B: 2021-07 → 2024-12 | 240 | +0.0328 | +2.70 | 6 / 6 | **0 / 6** |

**Twenty of twenty seed-runs are positive**, and the effect *size* is near-identical across two non-overlapping periods: 0.0367 / 0.0336 / 0.0328. Period A's weaker *t* is not a weaker effect — its IC is the same size, measured over half the dates with more than double the dispersion (sd 0.0145 vs 0.0065), which is what a window containing the COVID crash should look like.

So the n = 100 dip was a single-draw artefact, and **the cross-sectional null in §30 was a power result exactly as claimed.** This is the project's **first positive result** after ten negatives.

#### What this result is not

Four caveats, none decorative:

**1. The long-short spread is not usable; the rank IC is.** The spread looks large (+0.017 to +0.061 of 5-day excess log return) and rests on almost nothing:

| Universe | Long calls | Short calls | of |
|---|---|---|---|
| 39 | **0** | 143 | 4,405 |
| 100 | 26 | 499 | 11,813 |
| 200 | 18 | 1,573 | 25,085 |
| 400 | 148 | 2,978 | 39,844 |

148 longs out of 39,844 is 0.37%, against 20× as many shorts. That is not a balanced portfolio, the mean of 148 observations is dominated by a handful of moves, and no transaction costs appear anywhere in it. At n = 39 there were **zero** long calls, which is why that spread is undefined. **Quote the IC, not the spread.**

**2. The classifier still barely classifies.** Accuracy 0.510 against a 0.501 majority baseline; macro F1 0.288. The rank IC carries the entire result — the model *orders* names better than chance while its discrete calls stay close to worthless. Abstention holds at **92%** even at 400 names, so §30's emergent-abstention behaviour is not a small-sample artefact. Calibration is genuinely good, though: ECE 0.0204 → **0.0026**.

**3. A residual survivorship filter remains, smaller but real.** `build_panel` requires **300 rows** per name, so companies trading for under ~14 months inside the window are dropped — 68 of 400 at the largest size. And a company that fails simply stops appearing; its final observed return is not −100%, so genuine wipeouts are under-represented. Both push optimistic. Far weaker than "must still exist in 2026", and not zero.

**4. One market, one model family, gross of costs.** No capacity analysis, and no borrow cost on a book that is 95% short by count.

#### What the signal is made of — and why the model is not the finding

A statistical result whose mechanism is unknown is one step away from an artefact nobody has found yet. `run_universe_attribution.py` asks what the 400-name model is actually keying on, with the decisive measurement being the **univariate IC**: for every raw feature, the Fama-MacBeth IC of that feature *alone* against forward excess return — same rows, same 464 dates, same machinery as the model.

| Feature | Univariate IC | FM *t* | Hit rate | SHAP share |
|---|---|---|---|---|
| `log_return_5` | **−0.0524** | **−4.34** | 0.388 | 1.6% |
| `rank_rev_5` | −0.0524 | −4.34 | 0.388 | 4.2% |
| `ma_ratio_10` | −0.0491 | −4.01 | 0.386 | 1.6% |
| `macd_hist_norm` | −0.0470 | −3.68 | 0.373 | 3.1% |
| `log_return_3` | −0.0442 | −4.08 | 0.397 | 0.9% |
| `rank_mom_63` | **+0.0276** | **+2.24** | 0.595 | 7.1% |
| *the model* | *+0.0396* | *+2.24* | *0.565* | — |

**A single raw feature beats the model — 1.32× the IC and nearly double the *t*** (1.41× against the shipped 29-feature model's +0.0373, t = 2.12; the univariate rows above reproduce exactly, [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)). And the sign is unambiguous: a negative IC on recent returns means recent winners underperform, which is **short-term reversal**, one of the most documented effects in equities. The hit rate of 0.388 says the IC is negative on 61% of dates, so it is consistent rather than carried by a handful of them. The whole top of the table is the same effect wearing different names.

**A second textbook effect appears with the correct opposite sign.** `rank_mom_63` scores +0.0276 at *t* = +2.24 — positive IC at a 63-day lookback. Short-horizon reversal *and* medium-horizon momentum, both present, both correctly signed, in a survivorship-free panel built from scratch. That is a strong independent check on the entire data pipeline: if the bhavcopy loader or the corporate-action adjustment were subtly wrong, these two effects would not both emerge at their textbook signs and horizons.

**The SHAP explains why the model underperforms.** Its top three features by attribution are `volatility_50` (14.8%), `atr_norm` (9.0%) and `rank_vol_21` (7.3%) — all volatility. `rank_rev_5`, which carries the actual edge, ranks **seventh at 4.2%**. The model spends its capacity deciding *when to stay out* rather than *which way to lean*, which is coherent with the 92% abstention and is exactly what it was punished for.

This also reverses [§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)'s reading. Attribution there was near-uniform (Herfindahl 1.3× uniform) and was recorded as "no driver to look at". At 400 names it concentrates: the top feature takes 14.8% where uniform would be ~3%. **There was a driver; the 39-name universe was hiding it**, in the same way and for the same reason it hid the IC.

#### The honest summary

There is a **real, replicable cross-sectional ordering signal** in liquid NSE equities at a 5-day horizon, invisible at 39 names and detectable at 200+. That part of §30's prediction is confirmed.

But **the model is not the finding — the factor is.** This section is a known effect *rediscovered*, not learned cross-sectional skill, and a naive 5-day reversal sort is the benchmark any model here has to beat. This one does not beat it. Anyone reporting the +0.0396 without the −0.0524 beside it would be overstating what the machine learning contributed, which is: nothing yet.

That is a better outcome than an unexplained edge. An edge you cannot explain is one you cannot reason about when it stops working — and short-term reversal has a known mechanism (liquidity provision, bid-ask bounce, over-reaction), known decay, and known capacity limits. Whether it survives costs is answered in [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc): **it does not.** Breakeven is 5.0 bp round trip against an STT of 20 bp, and no holding period or tail width in the sweep clears even 25 bp.

---

### 39. Costing the reversal signal — the eleventh negative result, and the end of the arc

[§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) closed with an open question: the cross-sectional signal is real, replicable and identified as short-term reversal, but *"whether it survives costs is a different question this project has not asked."* This asks it, and the answer closes the arc.

`run_reversal_costs.py` builds the tradeable version: long the bottom decile of 5-day past return (recent losers), short the top decile (recent winners), equal-weighted, dollar-neutral, rebalanced every 5 trading days so holding periods do not overlap. 339 names, 1,601 dates, **319 rebalances**.

The signal is a cross-sectional sort on a raw feature with **no free parameters** — nothing is fitted — so the whole 2018–2024 panel is fair game and there is no train/test split to respect.

#### It was already thin before costs

| | |
|---|---|
| Gross annual return | +4.40% |
| Gross annual volatility | 22.49% |
| **Gross Sharpe** | **+0.20** |
| Periods positive | 0.511 |

**An IC of −0.052 sounds respectable and converts to a Sharpe of 0.20.** The decile spread carries 22% annualised volatility, so the risk-adjusted edge was small before a single rupee of cost. §38's statistical significance came from having 464 dates, not from a large effect — which is exactly the distinction the Fama-MacBeth machinery exists to expose, and it cuts both ways.

#### Costs remove it several times over

The book turns over **3.47 of a possible 4.00 notional per rebalance — an 87% refresh, every five days.**

| Round-trip cost | Annual return | Sharpe | Scenario |
|---|---|---|---|
| 10 bp | −4.34% | −0.19 | institutional, futures, top liquidity |
| 25 bp | −17.46% | −0.78 | liquid cash equity, modest size |
| 50 bp | −39.32% | −1.75 | realistic incl. mid-cap impact |
| 100 bp | −83.05% | −3.70 | retail delivery, STT both sides |

**Breakeven: 5.0 bp round trip.** That is the number to argue with, because it assumes nothing — it is simply where gross return equals cost drag. For scale, **STT alone is 20 bp round trip** on Indian delivery, before brokerage, exchange fees, stamp duty or market impact.

> **Later correction: this book is the luckiest of five equally valid versions.** A 5-day book rebalanced every 5 sessions can start on any of 5 days, and the choice isn't innocent. Measured on this exact panel ([§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)), gross per rebalance is **+0.087%, +0.016%, −0.100%, −0.053% and +0.070%** across the five starting days. The +0.087% reported here (Sharpe 0.20) is the **best of the five**, because the loop happened to start on row 5, not because it was selected. Averaged over all five, gross is **+0.004%**, and no starting day reaches |t| = 1. The verdict only gets stronger: the raw reversal book doesn't merely die on costs, it is indistinguishable from zero **before** them. §38's IC is unaffected, because it is computed every day rather than on one starting day.

#### The obvious rescue does not work, and the reason is interesting

A turnover-driven null invites one objection: *rebalance more slowly*. Tested across holding periods and tail widths:

| Hold | Tail | Notional traded | Gross annual | Sharpe | Breakeven |
|---|---|---|---|---|---|
| 5d | 1/10 | 3.470 | **+4.40%** | +0.20 | **5.0 bp** |
| 5d | 1/5 | 3.159 | +3.57% | +0.22 | 4.5 bp |
| 10d | 1/10 | 3.472 | −1.60% | −0.08 | −3.7 bp |
| 21d | 1/10 | 3.485 | −2.42% | −0.14 | −11.6 bp |
| 42d | 1/10 | 3.456 | −9.15% | −0.55 | −88.3 bp |

*(Re-run in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found). The headline 5-day row reproduces exactly; the longer holds move in the second decimal because `build_panel` re-fetches NSE's corporate-action feed live, and revisions to it shift adjusted prices slightly. Later: the feed is now frozen ([§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it)), and every row was re-run after [§74](#74-renamed-companies-lost-their-corporate-actions)'s fix, which is where the 5.0 bp now comes from.)*

**Only the 5-day book has a positive gross return at all.** At 10 days and beyond the effect is gone and the sign flips — consistent with the reversal literature, where the effect lives at days-to-weeks and decays fast.

The unexpected part is the middle column: **turnover barely moves.** Holding for 42 days instead of 5 still trades ~3.46 of 4.00. That is because the signal has *no persistence* — a 5-day return is close to uncorrelated with the 5-day return measured 42 days later, so decile membership is redrawn essentially from scratch at every rebalance regardless of spacing. Slowing down therefore buys **no** turnover reduction while forfeiting all of the return.

That is the mechanism, and it is why this particular null cannot be engineered around: the horizon at which the signal exists and the horizon at which it would be cheap to trade are disjoint.

#### A second, independent blocker

**Indian cash equity has no overnight short selling.** A 5-day short leg needs single-stock futures, and those exist for only **131 of the 339 universe names (39%)** — on *today's* F&O list, which is an upper bound since the list was narrower historically. *(Later correction, [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code): the point-in-time list was wider for most of the window, 129–210 names with a median of 147, so today's list understated eligibility rather than bounding it.)*

So the short side — where §38's model made 95% of its calls — is unimplementable for nearly two-thirds of the universe. Restricting to F&O names would cut breadth by that much, and breadth is precisely what generated the IC in the first place.

Two independent reasons for failure is a sturdier conclusion than one.

#### The arc, complete

| Stage | Finding |
|---|---|
| §30 | No cross-sectional skill at 39 names (*t* = 0.92) — diagnosed as **underpowered**, not absent |
| §38 | At 400 survivorship-free names the signal **is** there: IC +0.0396, *t* = 2.24, 20/20 seeds |
| §38 attribution | It is **short-term reversal** — and one raw feature beats the model |
| §39 | It is **not tradeable**: breakeven 5.0 bp, no configuration clears 25 bp |

**The eleventh negative result, and the one that completes the story rather than deferring it.** The honest summary of this project's central question is now a single sentence: *there is a small, real, statistically solid cross-sectional signal in liquid NSE equities, it is a long-known effect rather than anything learned, and it is worth less than the cost of trading it.*

That is a more useful place to stop than an unresolved positive. A statistically significant result left uncosted would have been the most misleading thing this repository could ship.

---

### 40. Range-based volatility (Sharma & Mehta Ch. 18) — the twelfth negative result

*Deep Learning Tools for Predicting Stock Market Movements* (Sharma & Mehta, eds., 2024) is mostly surveys, bibliometrics and questionnaire-based behavioural studies — Ch. 4, 7, 8, 10–15 and 17 contain nothing implementable, Ch. 2 and 5 are quantum computing, and Ch. 1's LSTM+ARIMA+sentiment stack is already here minus the sentiment feed [§26](#26-book-coverage-what-was-taken-what-was-left-and-why) rejected as licensed.

**Ch. 18** (Kaur & Chaudhary, "Volatility Transmission Role of Indian Equity and Commodity Markets") is the exception, and its useful contribution is not the Diebold-Yilmaz spillover model in the title. It is one line of methodology:

> σ²ᵢₜ = 0.361 · [ln(Pʰⁱᵍʰᵢₜ) − ln(Pˡᵒʷᵢₜ)]²

with the note that "literature has proven the advantage of using a range-based volatility estimator as compared to the traditional method". That constant is **1/(4 ln 2) = 0.3607** — the **Parkinson (1980)** estimator.

#### The gap it pointed at

`HAR_RV_model` builds its variance series as `RV_t = r_t²`, and its own docstring calls that *"the standard proxy **when sub-bar data is unavailable**"*. Sub-bar data is not unavailable: every bar the app fetches carries **open, high and low**, used for features and never for the variance estimate that drives the uncertainty cone — which this README names as the actual product.

The motivating case is stark. A bar that opens at 100, runs to 108, falls to 94 and closes at 100 has `r_t = 0` and therefore **zero** estimated variance. The range saw all of it.

`range_volatility.py` implements Parkinson, Garman-Klass, Rogers-Satchell and Yang-Zhang. Against a synthetic process with known variance the efficiency gains land on theory: **Parkinson 5.07×** (theory 5.2), **Garman-Klass 6.77×** (7.4).

**On real NSE bars the gain is 1.7–2.4×, not 5×** — real bars trade discretely, so the observed high and low understate the true extremes. The measured number is the one reported. *(First published as 1.6–2.5×. `efficiency()` compared the range estimators against squared returns on the **raw** close, so a split in the window added a fake −50% return to the baseline's noise and flattered every range estimator: TATASTEEL's Parkinson gain read 2.34× against 1.94× on adjusted closes, HDFCBANK's 2.22× against 2.01×. The baseline now uses `adj_close` — the very trap the next subsection describes, one function over. [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found).)*

#### A trap, hit and then pinned

Range estimators are **within-bar ratios**, so they are invariant to any rescaling of a bar's prices and therefore immune to split and dividend adjustment. Close-to-close returns are not.

`scale_to_total` compares the two, to restore the overnight variance an intraday estimator misses. Measured with **raw** closes, TATASTEEL's scale factor came out at **8.32** (level ratio 0.120); with adjusted closes, **1.26** (0.794). Four of six names were corrupted this way — only the two without splits in the window were unaffected. The function now flags implausible factors, and `test_scale_to_total_flags_an_unadjusted_close` exists so it cannot recur.

The honest level ratios: the intraday range captures **64–85%** of close-to-close variance. The rest happens overnight, when earnings and news land — which is why a naive substitution would have understated the cone and caused under-coverage.

#### The A/B, and two corrections to my own analysis

12 names, 24 walk-forward origins, horizon 5, measuring **coverage and width together** — width alone is meaningless because the conformal layer rescales the cone to target and would absorb a constant bias in the variance estimate.

| Estimator | Mean width Δ | sd | **Paired *t*** | Wins |
|---|---|---|---|---|
| parkinson | +0.48% | 5.51% | **0.30** | 6/12 |
| garman_klass | −0.17% | 5.44% | **−0.11** | 6/12 |
| rogers_satchell | −1.11% | 5.87% | **−0.65** | 7/12 |

Every |*t*| < 1, win rates are coin flips, and the per-ticker spread runs −8.5% to +10%. **No estimator changes the cone.**

*(Re-run in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found). The original 12 names were never recorded, so the driver's default is now an explicit list — RELIANCE, TCS, INFY, HDFCBANK, SBIN, TATASTEEL, ICICIBANK, ITC, LT, AXISBANK, MARUTI, WIPRO — at 24 origins. On it: parkinson +0.54% (paired t +0.37, 6/12 wins), garman_klass −0.05% (−0.03, 6/12), rogers_satchell −1.13% (−0.71, 7/12); coverage ~0.921 for every arm. Same verdict. The driver also had a reporting bug: it only checked for a significantly **tighter** cone, so a significantly **wider** one — which its old 6-name, 8-origin default produced, t = +2.3 — printed "every paired t is inside ±2". It now reports both directions.)*

Getting there required correcting the work twice, and both corrections are the point:

**1. The first run was underpowered and said the opposite.** At 8 origins the range estimators looked **8–12% worse**; at 24 origins the sign flipped to 1.4% *better*. A result that reverses when power is added was never a result. [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) published an underpowered null that [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) later overturned; applying that lesson to *this* measurement rather than only to the older ones is what caught it.

**2. The verdict logic was over-claiming.** It declared "rogers_satchell wins at −1.4% width" from a paired *t* of −0.65 — precisely the error the rest of this project exists to prevent, written into the new driver. Replaced with a **paired** test that compares each ticker against itself, so the large between-name variation is differenced out instead of averaged into a decisive-looking mean, and that requires |*t*| > 2 before naming a winner.

#### Why it fails — a more precise measurement of the wrong quantity

`scale_to_total` restores the missing overnight variance with a **constant** factor, but the intraday/overnight split is not constant — it moves with the news and earnings cycle. The range estimators therefore trade *sampling noise* for a *time-varying bias*.

They are genuinely better at measuring the **last** bar's variance (2× more precise, measured) and no better at forecasting the **next** one, which is the only thing the cone needs. That distinction is the finding, and it generalises: an estimator's efficiency at describing history is not the same property as its usefulness in a forecast.

`range_volatility.py` ships complete, tested (18 tests) and wired into `run_har_rv_prediction(rv_estimator=...)`. **The shipped default stays `'squared'`**, per this project's standing rule that an unvalidated change does not ship.

*(A note on the coverage column: every arm, baseline included, covers ~0.919 against a 0.95 target in this walk-forward configuration. That is a property of the configuration, not of the estimator choice, and it does not affect the comparison — but it is worth not glossing.)*

---

### 41. Open interest, and a look-ahead worth 2.9 sigma — the thirteenth negative result

Every negative result before this one was measured on a **transformation of OHLCV**: more models, more architectures, fractional differencing, range volatility, cross-sectional ranks. [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) was the single attempt at a second data axis and it died on *coverage*, not on evidence.

**Open interest is the first genuinely orthogonal, obtainable data source this project has found.** It measures *positioning* — how many contracts are open — and is not derived from price at all. `nselib.derivatives.future_price_volume_data` serves it historically and free. So the question is different in kind from "does another function of price help", which has now been answered twelve times.

#### The claim, reduced

Ch. 3 (Bakshi, "Analyzing Open Interest") gives a 2×2 interpretation table with **no backtest, no statistics and no validation anywhere in the chapter**:

| Price | OI | The chapter's claim |
|---|---|---|
| Rising | Rising | Strongly bullish; trend continues |
| Rising | Falling | Short-covering rally; downtrend next |
| Falling | Rising | Aggressive short-selling; bearish continues |
| Falling | Falling | Forced liquidation; upward move may start |

Read as a predicted sign, that table is exactly

```
signal = sign(Δprice) × sign(ΔOI)
```

**+1 when the two agree, −1 when they diverge.** The whole chapter collapses to one product of two signs, which is convenient — it turns four rules into a single testable signal.

Tested on 60 liquid F&O names over 2023–2024 (479 dates), with ΔOI from the **near-month** contract and both Δprice and the forward return from the survivorship-free, corporate-action-adjusted [`bhavcopy`](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) panel.

#### It looked real

| Horizon | Mean IC | **FM *t*** |
|---|---|---|
| 1 day | +0.0198 | **+2.88** |
| 5 day | +0.0078 | +1.12 |

At one day that clears the conventional threshold, on a genuinely orthogonal data source, with all four quadrants leaning the direction the chapter predicts. It would have been the project's second positive finding.

#### It was a publication-timing look-ahead

**NSE publishes the F&O bhavcopy — and therefore open interest for date *t* — after the close of *t*.** You cannot trade at the close of *t* on a number that does not exist until afterwards. The earliest possible entry is the close of *t+1*, so the honest forward return runs from *t+1*.

| Variant | Mean IC | **FM *t*** |
|---|---|---|
| 1d, trade at close *t* — **not tradeable** | +0.0198 | **+2.88** |
| 1d, **tradeable** (one-day lag) | −0.0018 | **−0.27** |
| 5d, trade at close *t* | +0.0078 | +1.12 |
| 5d, **tradeable** | +0.0004 | +0.05 |

**The effect does not decay under the lag — it vanishes**, and flips sign. Out of period it is nothing in both halves: 2023 *t* = **+0.11**, 2024 *t* = **−0.50**.

The entire 2.9-sigma result was one day of hindsight.

#### Why this one is worth a section

Nothing here was a modelling choice. The features, the horizon, the universe and the statistic were all fixed before the number appeared; the only thing that changed was **whether the data existed when the trade would have been placed**. A one-day misalignment on a daily signal manufactured an IC of +0.02 at *t* = 2.88 out of an effect of exactly zero.

*(Later note, [§68](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period): with the ten trading days recovered in [§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one) the panel has 489 dates; naive IC +0.0181 (t 2.65), honest −0.0000 (t −0.01). Same conclusion.)*

That is a useful calibration on every "significant" daily-frequency result in this literature, and on the chapter itself — which asserts its table confidently and never tests it at all. The driver now prints **both** rows, labelled, so the gap is visible rather than reconstructible:

```
naive  (trade at close t -- NOT tradeable) IC +0.0198  t +2.88  SIGNIFICANT
HONEST (trade at close t+1)                IC -0.0018  t -0.27  not significant
```

Two further reasons the tradeable version was never going to survive even if it had held: only **39% of a liquid NSE universe is F&O-eligible** ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)), so breadth is cut by two-thirds; and a **one-day** signal implies ~100% daily turnover against the ~20 bp of STT alone that §39 measured, where a 5-day signal at 5.0 bp breakeven already failed.

**The thirteenth negative result, and the first to rule out an orthogonal data source rather than another feature of the same one.** The book's only empirically testable claim does not survive contact with its own publication schedule.

---

### 42. Microstructural features (López de Prado, AFML Ch. 19) — a usable feature, an unusable measurement

*Advances in Financial Machine Learning* is a different proposition from the survey volumes in [§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result) and [§41](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result). Almost everything in it is implementable. The constraint is that most of it needs data this project does not have:

| Chapter | Status here |
|---|---|
| **5** Fractional differentiation | **Already done** — [§36](#36-fractional-differentiation-measuring-a-choice-made-by-convention--the-tenth-negative-result), null |
| **6**, **9** Ensembles, hyper-parameter tuning | Already done — [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat) |
| **2** Tick / volume / dollar bars | Needs tick data — unavailable |
| **16** Hierarchical Risk Parity | A portfolio product, not this one |
| **20–22** HPC recipes | Not needed |
| **3 + 4** Triple-barrier + sample weights | Absent — see the note below |
| **7 / 12** Purged K-fold, CPCV | Project has embargo, not the CV classes |
| **14** Deflated Sharpe | Absent — project uses SPA instead |
| **17 / 18** Structural breaks, entropy | Absent, untested |
| **19** Microstructural features | **This section** |

**A note on Ch. 3 + 4, because it is a trap worth naming.** AFML's sample weights by average uniqueness are **effectively — though not exactly — a no-op for this project as it stands**, and the distinction is worth getting right rather than asserting the stronger claim.

Running AFML's own Snippets 4.1/4.2 on this project's label structure (fixed 5-day horizon, sampled every bar) against a variable-lifespan alternative:

| | Fixed 5-day horizon | Triple-barrier (variable) |
|---|---|---|
| Concurrency | 1 → 6 | 0 → 17 |
| Uniqueness sd | 0.0219 | 0.0259 |
| Max/min weight ratio | **2.45** | **6.11** |

The 2.45× ratio looks like a real effect and is **entirely a boundary artefact**. Across the interior, uniqueness is *exactly* 1/6 with a standard deviation of **0.00e+00**; it rises only in the first and last ~5 bars, where fewer labels overlap:

```
first 8 values : [0.4083, 0.2694, 0.2139, 0.1861, 0.1722, 0.1667, 0.1667, 0.1667]
labels differing from the interior value: 10 of 295 (3.4%)
```

On the real cross-sectional panel that is roughly **3,400 of 495,000 rows — 0.68%**, all of it at sample edges.

So the weighting only *bites* when label **lifespans vary**, which requires the triple-barrier labels of Ch. 3 first — and triple-barrier more than doubles the weight dispersion (6.11× against 2.45×). They are a package, not two independent techniques, and implementing Ch. 4 alone would have produced an elaborate almost-no-op that looked like rigour.

#### Why Ch. 19 was the pick

[§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) concluded that short-term reversal does not survive transaction costs — breakeven **5.0 bp** round trip. That conclusion rests on **assumed** cost scenarios (10 / 25 / 50 / 100 bp). The assumption is reasonable and it was the weakest link in an otherwise measured argument.

Corwin & Schultz (2012), via AFML Ch. 19.3.4, estimate the **bid-ask spread from high and low prices alone** — data already in hand. If it works, §39's central assumption becomes a measurement. `microstructure.py` implements it, along with Roll (1984), Becker-Parkinson volatility, and the Amihud and Kyle impact measures. The rest of Ch. 19 — VPIN, order-flow imbalance, the sequential-trade models — needs tick-level **signed volume** and is deliberately not approximated.

#### It does not work as a measurement, for two compounding reasons

**1. The estimator is biased upward, in proportion to volatility.** Simulated bars with a true spread of *exactly zero*:

| σ (daily) | CS reports | bias / σ |
|---|---|---|
| 0.5% | 12.2 bp | 0.244 |
| 1.0% | 24.4 bp | 0.244 |
| 2.0% | 48.7 bp | 0.244 |
| 4.0% | 97.5 bp | 0.244 |

*(Corrected in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found); first published as 13.1 / 26.1 / 52.3 / 104.5 bp, 0.26σ, which the driver does not reproduce. The ratio is identical down the column because one simulated path is rescaled, so the column carries one draw, not four: across simulation seeds the bias runs **0.24σ–0.32σ**. Volatility-proportional either way.)*

It attributes part of the price range to a spread that is not there. The slope against a *genuine* spread is ~0.93, so the estimator does track real spread almost one-for-one and adds a volatility-sized offset on top. Quoting the raw figure as a transaction cost would **overstate** costs — which would have made §39's negative conclusion look stronger than the evidence supports, the most tempting direction to get something wrong.

**2. Correcting the bias against a simulated null fails, because real bars are not GBM.** `spread_null` calibrates the estimator on zero-spread bars at the series' own volatility — the same permutation-null discipline `feature_drift.psi_null` uses. On synthetic data it works, recovering a known 50 bp spread to within 12 bp and returning zero when the true spread is zero, erring **conservative** (it understates by ~20%, because the volatility used to calibrate the null is itself inflated by the spread).

On real NSE bars it collapses. **The raw estimate (10–38 bp) is below the GBM null (31–48 bp) for 9 of the 10 large caps tested**, so nine floor at a zero spread and the tenth (ITC) reads 4 bp. *(First published as raw 20–37 bp against a 39–59 bp null for every name. The driver no longer reproduces those: a later change measured the null's volatility on the same gap-adjusted bars the estimator sees, which lowered the null. Corrected in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found); the conclusion is unchanged.)* Real daily bars differ from a random walk in ways — fat-tailed ranges, intraday mean reversion, discrete trading — that change the estimator's behaviour more than the spread does.

#### An omission in AFML's snippet, found by chasing the discrepancy

Investigating the shortfall surfaced a real gap. The estimator contrasts a **two-bar** range (γ) against the sum of two **one-bar** ranges (β). An overnight gap sits inside the two-bar range and inside neither one-bar range, so it inflates γ alone — pushing α down and the spread with it. Measured on NSE bars, `γ/β` runs **1.08 to 2.62** against **1.015** for a gapless random walk.

**AFML's Snippet 19.1 omits the correction; the original paper specifies it** (Corwin & Schultz 2012, p. 727): slide a gapped bar to meet the previous close, preserving its height. `overnight_adjust` implements it and it is on by default.

Honest accounting: it moved the estimates by only a few basis points (INFY 16.3 → 22.3, TATASTEEL 20.7 → 28.8, most names unchanged) and did **not** rescue the null correction. It is correct, it is required by the source, and it was not the explanation.

#### What it *is* good for

The weaker claim survives. Across **1,392 NSE names**:

| Turnover quintile | Median CS spread |
|---|---|
| Q1 (thinnest) | 106.9 bp |
| Q2 | 88.4 bp |
| Q3 | 79.1 bp |
| Q4 | 66.8 bp |
| Q5 (most liquid) | 44.3 bp |

**Spearman(CS, log turnover) = −0.63**, correctly signed and monotone across every quintile. The estimator ranks liquidity well while getting the level wrong by an order of magnitude — actual quoted spreads on RELIANCE or TCS are ~1–3 bp, not 44.

So Corwin-Schultz is a **relative liquidity feature**, not a cost estimate. That is a real if modest result, and it is the opposite of what the section set out to produce.

#### Where this leaves §39

§39's assumed costs **cannot** be replaced by a measured spread through this route, and the section's caveat stands as written.

The conclusion is nonetheless *supported*, by a cruder argument than intended: even the most liquid quintile of the entire NSE reads **44 bp** on an estimator that is biased upward and still an order of magnitude above a 5.0 bp breakeven. There is no reading of this data — biased, corrected, or raw — under which spreads approach breakeven.

**The fourteenth negative result, and the second where a technique that failed its intended purpose turned out to be usable for a smaller one.** ([§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result) was the first: range estimators measure the last bar well and forecast the next one no better.) `microstructure.py` ships with 22 tests, and the shipped cost scenarios in §39 stay as they are.

---

### 43. The Deflated Sharpe Ratio (AFML §14.7) — and what it says about §39

[§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement) closed with two AFML techniques worth taking. This is the first, and unlike everything since [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) it is not a search for signal — it is a **sharper instrument for judging results already in hand**. That is the right category for a project carrying fourteen negative results: the marginal value is in being more certain about what has been measured, not in measuring more things.

#### What a Sharpe ratio hides

Two inflations are invisible in the number itself:

1. **How many strategies were tried.** The maximum of N draws is not the mean of one.
2. **The shape of the returns.** Negative skew and fat tails both flatter a Sharpe.

`sharpe_standard_error` already handles sampling error, but it assumes i.i.d. **Gaussian** returns and knows nothing about the trial count. PSR and DSR close both gaps.

**Probabilistic Sharpe Ratio** (Bailey & López de Prado 2012) — the probability the *true* Sharpe exceeds a benchmark:

```
PSR(SR*) = Z[ (SR - SR*)·√(T-1) / √(1 - γ₃·SR + (γ₄-1)/4·SR²) ]
```

Note the sign on γ₃: **negative** skew enlarges the denominator and shrinks the probability. That is the point — the short-volatility profile that earns steadily and loses catastrophically is precisely what a bare Sharpe rewards.

**Deflated Sharpe Ratio** (2014) is a PSR whose benchmark is not chosen but *derived from the number of trials*:

```
SR*₀ = √(V[SRₙ]) · [ (1-γ)·Z⁻¹(1 - 1/N) + γ·Z⁻¹(1 - 1/(N·e)) ]
```

with γ the Euler-Mascheroni constant. It answers the question a Sharpe cannot: *is this better than the best thing noise would have handed me?*

**No new dependency.** The normal CDF comes from `math.erf`; its inverse is Acklam's rational approximation with one Halley refinement, accurate to **<5e-10** against published quantiles. This project has **zero SciPy imports** and keeps it that way — the same reason `feature_drift` carries a closed-form Kolmogorov distribution.

#### The statistic proving itself

N strategies with *exactly zero* true skill, keep the best, then judge it:

| N tried | Best SR/yr | PSR vs 0 | SR\* (noise) | **DSR** |
|---|---|---|---|---|
| 5 | 0.21 | 0.640 | 0.037 | **0.253** |
| 20 | 0.96 | 0.952 | 0.055 | **0.564** |
| 100 | 1.36 | **0.990** | 0.099 | **0.363** |
| 500 | 1.89 | **0.999** | 0.114 | **0.557** |

*(The first two rows are corrected in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found): the driver, which draws all four rows from one seeded generator, reproduces the 100 and 500 rows and every figure below exactly, but not the 5 and 20 rows first published (0.96 / 0.952 / 0.058 / 0.529 and 0.88 / 0.937 / 0.051 / 0.550). At N = 5 neither statistic is fooled; PSR is fooled from N = 20 on.)*

At N = 500 the best of five hundred **worthless** strategies posts an annualised Sharpe of **1.89** and a PSR of **0.999** — a textbook false discovery, and a number most backtests would ship. DSR says **0.557**. It is not fooled because its threshold rises with N in step with the winner.

#### Applied to §39, it says something §39 did not

The reversal book is the one place in this project with both a return series and a **countable, non-negotiable** trial count: `run_reversal_costs.py` swept exactly eight hold × tail configurations and the 5-day decile book is the one that got reported. That is textbook selection, and DSR prices it.

| | Gross | Net @ 25 bp |
|---|---|---|
| Observed SR (per period) | +0.0276 | −0.1094 |
| Skew | −0.765 | −0.749 |
| Kurtosis (3 = Gaussian) | **13.14** | 13.07 |
| PSR vs 0 (naive) | 0.6865 | 0.0229 |
| **SR\* from 8 trials** | **+0.0660** | +0.0660 |
| **Deflated Sharpe** | **0.2492** | **0.0007** |

**The gross Sharpe is below the best-of-8-trials noise threshold** — +0.0276 observed against +0.0660 expected from noise alone. §39 concluded that reversal dies on transaction costs. DSR says it **fails multiple-testing deflation before a single basis point of cost is applied.** That is a strictly stronger statement, and it was not available from the Sharpe, the breakeven, or the SPA test.

> **Later note: the trial count here was understated, which strengthens this result.** The 8 configurations each had **5** equally valid rebalance starting days, and the +0.0276 being deflated is the best of those five for the reported configuration ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)'s correction; [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)). A larger effective trial count can only raise SR\*, so the book fails deflation by a wider margin than shown. The verdict is unchanged.

The shape statistics add a second layer §39 missed entirely: **kurtosis 13.1** against 3 for a Gaussian, and skew **−0.77**. §39 described the gross Sharpe of 0.20 as "thin". It is worse than thin — it is thin, fat-tailed, negatively skewed, and below what chance would have produced from the same search.

#### Why this does not duplicate the SPA work

[§22](#22-economic-evaluation-does-the-forecast-make-money)'s SPA / Reality Check already corrects for selection bias across a model set, and the two are complementary rather than redundant on two counts. DSR uses the **trial count and the dispersion of their Sharpes** explicitly, where SPA works from the loss series. And DSR carries the **skew and kurtosis** correction, which SPA does not — a strategy can clear SPA and still fail DSR if its returns are badly shaped or its peer trials were tightly clustered. On this data both reach the same verdict, which is itself worth knowing: two different corrections for the same disease agreeing is stronger evidence than either alone.

**No conclusion in this document changes.** §39 already said the reversal signal is not tradeable; DSR says it was never distinguishable from the best of eight lucky draws either. `probabilistic_sharpe_ratio`, `expected_max_sharpe` and `deflated_sharpe_ratio` ship in `strategy_metrics.py` with **32 tests**, and are available to any future result before it gets reported.

---

### 44. Directional Change (Tsang, *AI for Finance*, Ch. 6) — the fifteenth negative result, and a null that survived three controls

Tsang's *AI for Finance* (CRC Press, 2023) is a 126-page survey. Six of its seven chapters are commentary — AI–finance synergy, AlphaGo, Markowitz, blockchain, sentiment, "finance as a hard science". **Chapter 6 is the only one containing an algorithm**, and it is a good one.

#### The representation

A time series records a price every fixed interval whether or not anything happened. **Directional Change** inverts that: fix a threshold `theta`, and record nothing until the price reverses by `theta` from the last extreme. At that moment a DC event confirms and the trend flips. The market becomes alternating up- and down-trends, each split into a **DC leg** (extreme → confirmation, a move of `theta` by construction) and an **overshoot leg** (confirmation → next extreme, a move of whatever the market felt like — and therefore the only part carrying information).

This is the motivation behind López de Prado's information-driven bars ([§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement) noted AFML Ch. 2 was unreachable here) with one decisive difference: **tick bars need tick data, DC needs only a price path.** It runs on the daily closes already in the panel. That is why this chapter was worth implementing and AFML Ch. 2 was not.

#### The lookahead trap the book waves away

Tsang notes DC events are "recognized in hindsight" and argues this "changes nothing". For describing the past, true. For **building features, it is the most dangerous property of the representation**, because the natural implementation is also the wrong one.

The extreme starting a trend sits at `t_ext`, but nobody knows it is an extreme until `t_confirm`. Label the bars between them with the new trend's direction — which is exactly what a groupby over the event table gives you — and every one of those bars carries a fact from its own future. The model learns to buy the exact bottom.

So `directional_change.py` ships **two** views rather than trusting the caller to remember:

| | purpose | safe for |
|---|---|---|
| `dc_events` | hindsight event table | scaling laws, volatility measurement, anything backward-looking |
| `dc_state` | per-bar causal features | **feeding a model** |

`dc_state` flips direction at the *confirmation* bar. The guarantee is tested, not asserted: `test_dc_state_is_invariant_to_future_bars` recomputes on truncated prefixes and requires the overlap to match at `abs=0.0`. [§41](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result) is this project's standing reminder of the cost — an open-interest signal at t = +2.88 became **t = −0.27** once its publication lag was honoured.

The module also reproduces the book's own Figure 6.1 exactly (trends of +7 and −22 as the text states), including the part the book does not say: the third trend is still running at the end of the data and must **not** be reported as though its end were known.

#### The "striking discoveries" are theorems about Brownian motion

Chapter 6.5 presents two empirical laws from Olsen's FX work, "across all major currency pairs", for which "no explanation is available":

1. a trend ends on average at **twice** the threshold — i.e. `mean(|OS|) / theta = 1`;
2. the overshoot leg takes **twice as long** as the leg that confirmed it.

There is an explanation. For driftless Brownian motion, the running maximum reached before a `theta` drawdown is **Exponential with mean `theta`**. Law 1 is that distribution's mean. Simulating a driftless random walk at increasing resolution:

| steps per θ | events | DC/θ | OS/θ | OS/DC | median OS/θ | t_OS/t_DC |
|---|---|---|---|---|---|---|
| 1 | 63,201 | 1.599 | 1.622 | 1.014 | 0.848 | 1.609 |
| 5 | 39,343 | 1.118 | 1.122 | 1.004 | 0.726 | 1.940 |
| 25 | 10,914 | **1.023** | **1.026** | 1.003 | **0.712** | **2.008** |
| *predicted* | | *1.000* | *1.000* | *1.000* | *0.693* | *2.000* |

Both laws converge to their predicted values **on pure noise**. The median converges to ln 2 = 0.693 — and Tsang's own caveat, that "the majority of trends ended far sooner than reaching twice the threshold", is precisely the exponential's mean-median gap. The book reads that asymmetry as an unexplained curiosity; it is the distribution's signature.

**A market obeying these laws is telling you it is a random walk.** The interesting question is therefore not whether NSE obeys them, but whether it *deviates*.

The table also shows why the first row matters: at daily resolution a single session jumps well past `theta`, so the DC leg is **not** `theta` and `OS/θ` inflates with it. `OS/DC` sits at 1.00 at every resolution, which is why it is the statistic used below.

#### The drift trap, and then the crash trap

**338 names**, **2018-01-01 → 2024-06-30** — the same window as [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result), [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) and [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed). Each name is compared against a **sign-flipped** version of itself: its own log returns with randomised signs, so volatility clustering and fat tails are not merely matched but *identical*, and only direction is destroyed.

| θ | events/name | OS/DC real | demeaned | flip null | t raw | **t demeaned** |
|---|---|---|---|---|---|---|
| 2% | 295.0 | 1.143 | 1.133 | 1.002 | +10.56 | **+9.45** |
| 3% | 208.9 | 1.145 | 1.133 | 1.006 | +10.35 | **+8.71** |
| 5% | 122.1 | 1.133 | 1.115 | 1.006 | +9.48 | **+7.26** |
| 10% | 50.0 | 1.175 | 1.127 | 1.013 | +9.11 | **+4.47** |

**Two traps, and the first one nearly caught me.** Both nulls are driftless, so a trending market shows a deviation for reasons unconnected to Directional Change. That is why `scaling_law_test` defaults to `demean=True`, and it is a large effect: on the 2022–2024 sub-window these names drifted at **+16.7%/yr**, the raw test read **t = +6.22**, and demeaning collapsed it to **+0.15**. Over the full window the drift is only **+1.3%/yr**, so demeaning barely moves the number — and a deviation of t ≈ 4.5–9.4 survives at every threshold.

That looks like a finding. It is a **crash**:

| period (θ = 5%) | names | real | flip null | **t** |
|---|---|---|---|---|
| full 2018–2024 | 338 | 1.115 | 1.022 | **+5.95** |
| pre 2018–2019 | 338 | 1.053 | 1.015 | **+1.79** |
| **2020 only** | 317 | **1.226** | 1.005 | **+7.50** |
| post 2021–2024 | 308 | 1.038 | 1.002 | +2.17 |

In the two non-COVID sub-periods the deviation is **t = 1.79 and t = 2.17**. In 2020 alone it is **+7.50**. The mechanism is plain once seen: in a crash every name trends hard in one direction for weeks, and long runs of same-sign returns are exactly what a sign flip destroys. The null is doing its job; there is simply no standing regularity for it to find.

**The fifteenth negative result, and the most instructive one, because the deviation survived three controls before failing the fourth.** The iid-Gaussian and sign-flip nulls agree to within 0.02 at every threshold, so fat tails and volatility clustering genuinely were not the explanation. Demeaning handled the drift. What remained was one year. [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)'s lesson was that an underpowered test finds nothing; this one's is that a **well-powered test against good nulls can still be measuring a single episode**, and the only defence is to cut the sample and look.

The **time** law needs none of this care: `t_OS/t_DC` matches the flip null at the two wider thresholds (t = +0.57 and −1.60) with no consistent sign. It carries no market content whatsoever.

**Both traps ship as code, not as narrative.** A finding that exists only in a document is one someone re-derives the hard way, and this project's rule is that a trap it has paid for becomes a guard:

- `DRIFTLESS_THEORY` carries the Brownian limits (1.0, ln 2, 2.0), so every scaling statistic has its reference point attached instead of being a bare number that reads like a finding.
- `scaling_law_test(prices, theta, demean=True)` runs the sign-flip null and returns a `z` per statistic. **`demean` defaults to `True`** — getting the undemeaned answer now requires explicitly passing `demean=False`, the same way `corwin_schultz(gap_adjust=True)` in [§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement) makes the correct behaviour the default one.
- `test_drift_alone_manufactures_a_deviation_unless_demeaned` reproduces the drift artefact on demand: a random walk plus +26%/yr, containing **no directional structure by construction**, reports `OS/DC = 1.510` against a null of `1.001` — **z = +5.18**, plus a second spurious "finding" at `time_ratio z = +2.07`. Demeaned, the same series gives `1.072` and **z = +0.71**.
- The sub-period split is step 2b of the driver rather than a note, because the crash trap has no closed form to guard against — the only defence is to cut the sample and look, every time.

`sign_flip_path` is shared between the module's single-series test and the panel test in the driver, so the two cannot diverge.

#### What survives: Chapter 6.3

Not everything here is negative. Chapter 6.3's two DC volatility measures — event frequency and mean trend magnitude — are claimed to be "independent of the volatility measures under Time Series" and orthogonal to each other. Over **19,667 name-months** at θ = 5%:

| | Spearman ρ |
|---|---|
| DC event count vs realised vol | **+0.53** |
| mean trend magnitude vs realised vol | **+0.39** |
| DC event count vs mean trend magnitude | **−0.11** |

"Independent" overstates it — a more volatile month does change direction more often. But neither is a restatement of realised volatility, and the two are close to orthogonal to each other exactly as claimed. **Chapter 6.3 holds up.** These are genuinely distinct measurements of a quantity this project already measures two other ways ([§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result)'s range estimators, and the realised volatility feeding HAR-RV).

#### And what that distinctness is worth

Chapter 6.4 promises that "practitioners equipped with more variables will have a better chance to beat their competitors". Fama-MacBeth rank IC of the causal `dc_state` features against 5-day forward excess returns, **488,096 rows, 334 names, 1,594 dates**, Newey-West at the horizon:

| feature | mean IC | t | hit rate |
|---|---|---|---|
| **`bars_in_trend`** | **+0.0253** | **+4.24** | 0.58 |
| `retrace` | +0.0104 | +3.52 | 0.56 |
| `bars_since_confirm` | +0.0162 | +3.48 | 0.57 |
| `overshoot` | −0.0099 | −2.51 | 0.46 |
| `move_from_ext` | −0.0127 | −2.33 | 0.47 |
| `direction` | −0.0053 | −1.27 | 0.49 |
| *trailing 5-day return* | *−0.0267* | *−4.58* | *0.43* |

Five features clear |t| > 2, and the best — `bars_in_trend`, at **t = +4.24** — is **ρ = +0.001** with the trailing return. It is genuinely *not* the reversal signal. On the shorter window the best feature had been `move_from_ext` at ρ = +0.62 with the trailing return, an obvious reversal proxy; this one is not, which is a much more interesting claim.

It is also a proxy for something else. `bars_in_trend` counts how long the current trend has run, and **a quiet stock takes longer to travel θ**:

| | |
|---|---|
| ρ(`bars_in_trend`, 20-day realised vol) | **−0.593** |
| IC of realised volatility itself | **−0.0453 (t −5.05)** |
| IC of `bars_in_trend` **neutralised within volatility quintiles** | **+0.0044 (t +1.39)** |

Low volatility is a documented cross-sectional effect, realised volatility scores it **more strongly** than the DC feature proxying it, and rank `bars_in_trend` within volatility quintiles and **83% of the IC disappears along with its significance**.

So the verdict is the same as on the short window, reached by a different route and with better evidence: whichever window you pick, DC's apparent signal turns out to be a **known factor in event-based clothing** — reversal on 2022–2024, the low-volatility effect on 2018–2024 — and measured more weakly than the factor itself.

#### Verdict

DC is a real idea and the implementation is worth keeping: it is the one information-driven bar scheme reachable from daily data, its volatility measures are genuinely distinct, and `dc_state` is a lookahead-safe way to use it. What it is not is a source of edge on this panel. `directional_change.py` ships with **42 tests**, including the prefix-invariance proof, the Figure 6.1 reproduction, two that pin the random-walk scaling laws at 1.0 and ln 2 so nobody can later quote "OS/θ ≈ 1 on NSE data" as evidence of anything, and one that reproduces the drift artefact on demand so nobody re-derives it the way I did.

---

### 45. Event-based backtesting (Hilpisch, *AI in Finance*, Ch. 11) — what §39's number never showed

Hilpisch's *Artificial Intelligence in Finance* (O'Reilly, 2020) is a serious book, and most of it is already here: Ch. 7–8's dense and recurrent networks are the existing model zoo, Ch. 9's RL was triaged out in [§26](#26-book-coverage-what-was-taken-what-was-left-and-why) for the reasons given there, Ch. 3's portfolio theory is a different product, and Ch. 10's vectorized backtesting is [§22](#22-economic-evaluation-does-the-forecast-make-money). **Chapter 11 is the gap**, and it is a real one.

#### The objection

Every backtest in this project is **vectorized**: multiply a signal by the realised return from entry to horizon. [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) is literally `fwd = log(px.shift(-hold) / px)` — anchor to horizon, one step. Correct arithmetic, and **blind to the path**. Four of the five days of every hold are never looked at.

That is not a theoretical complaint here. [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) measured this exact book at kurtosis 13.14. Fat tails are made of intra-period paths that a close-to-close return cannot see.

#### What the path actually looked like

19,664 positions, 319 rebalances, 2018-01-01 → 2024-06-30 — the same window and the same selection rule as §39, reconstructed to carry every position's daily bars. The rebuild correlates **0.9871** with §39's stored return series, so it is the same book.

**Maximum adverse excursion** needs no strategy assumption. It is simply how far underwater a position went before its horizon:

| | |
|---|---|
| Mean MAE | **−5.59%** |
| Median | −3.70% |
| 10th percentile | −12.94% |
| 1st percentile | **−29.77%** |
| Share past −5% | **38.4%** |
| Share past −10% | **15.3%** |
| **Book's mean return per rebalance** | **+0.1293%** |

The book earns **thirteen basis points** per rebalance. The average position inside it goes **5.6% against itself** on the way there, and one in seven goes past −10%. §39 shows none of this, because a vectorized backtest structurally cannot.

This is the section's durable result: it is assumption-free, it is large, and it reframes what §39's thin positive number meant. A book is not only its endpoint returns — it is also what you have to sit through to collect them, and nothing in this project had ever measured that.

#### Do stops help? A prediction, written before running it

Recorded in the driver's docstring beforehand: **they should hurt.** §38 identified this signal as short-term reversal, and stopping out of a reversal trade sells exactly when the mean-reversion is strongest.

| rule | mean/reb | ann. SR | vs base | **t paired** | stopped |
|---|---|---|---|---|---|
| none | +0.1293% | +0.292 | — | — | 0% |
| stop 3% | +0.1421% | +0.409 | +0.117 | +0.08 | 57.4% |
| stop 5% | +0.1763% | +0.466 | +0.174 | +0.33 | 38.4% |
| **stop 8%** | +0.2649% | **+0.702** | **+0.411** | **+1.23** | 21.7% |
| stop 10% | +0.2232% | +0.588 | +0.297 | +1.06 | 15.3% |
| trail 3% | +0.0168% | +0.071 | −0.221 | −0.67 | 91.1% |
| trail 5% | +0.1301% | +0.426 | +0.134 | +0.00 | 68.4% |
| stop 5% + tp 5% | −0.0550% | −0.245 | −0.537 | −1.20 | 35.3% |

**The prediction was wrong in sign, and the opposite is not established either.** The Sharpe column invites a story — stop 8% "improves" the book by +0.41 — that the paired difference series does not support: **not one rule reaches |t| = 2**, and the best is t = +1.23. Because the rules share dates and selection, the paired difference isolates the rule's effect; comparing two Sharpe ratios by eye does not.

This is also an **8-configuration sweep with the best one being quoted**, which is precisely what §43 built the instrument for. Applying it here rather than to someone else's result:

| | |
|---|---|
| Observed SR (per period) | +0.0989 |
| SR\* from 8 trials | +0.0620 |
| PSR vs 0 (naive) | 0.9673 |
| **Deflated Sharpe** | **0.7538** |

It clears the noise floor, unlike §39's book, but 0.75 is not a result. **Recorded as predicted-and-refuted rather than quietly dropped** — the pre-registration discipline is worthless if the prediction only gets reported when it lands.

What a stop demonstrably *does* deliver is the **distributional** change it promises:

| | skew | kurtosis |
|---|---|---|
| no rules | +0.234 | 9.54 |
| stop 8% | **+1.001** | **7.54** |

Truncating the left tail is what a stop is for, and it does it. That is a distributional fact, not a risk-adjusted return, and the two are routinely conflated.

*(A note on §43: its skew of −0.781 is roughly half a **convention** effect — the same series expressed in simple returns is −0.269, and this rebuild gives +0.234. Log returns are the right choice for compounding and simple returns for "what filled at what price", so both are correct for what they measure. §43's conclusion is unaffected: its SR\* threshold comes from the trial Sharpes' dispersion and does not use skew at all.)*

#### Where a stop-loss backtest lies

Getting this right is most of the module. A stop is **not a guaranteed fill** — if the bar opens through the level you get the open, not the stop:

| stop | honest (gap fill) | assumes fill at stop | overstated by |
|---|---|---|---|
| 3% | +0.1421% | +0.4141% | +0.2721% |
| 5% | +0.1763% | +0.4506% | **+0.2744%** |
| 8% | +0.2649% | +0.3923% | +0.1273% |

At a 5% stop the naive assumption is worth **+13.8% a year of pure fiction**, and on the 2022–2024 sub-window it flips the sign of the result outright. With kurtosis 13, gapping through a stop is not an edge case — it is the case.

Two more, both defaults in `event_backtest.py`:

- **Intrabar ordering.** If one bar's low hits the stop *and* its high hits the target, daily data cannot say which came first. `adverse_first=True` assumes the stop, because the alternative is free money.
- **Trailing ratchets.** Raising the trail on bar *i*'s high and then testing bar *i*'s low against the new level assumes the high came first. The trail is computed from bars strictly before *i*; `test_the_trail_cannot_ratchet_and_fire_on_the_same_bar` pins ~26% of fictional profit on one constructed bar.

#### Later check: all five rebalance starting days

[§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39) found that a 5-day book rebalanced every 5 sessions has five equally valid starting days, and that §39's, which this driver copies, is the best of them. So the whole driver was re-run on each (`--phase 0..4`):

| | phase 0 (above) | 1 | 2 | 3 | 4 |
|---|---|---|---|---|---|
| Book's mean per rebalance | +0.1293% | +0.0286% | −0.0756% | −0.0450% | +0.0956% |
| Mean MAE | −5.59% | −5.62% | −5.62% | −5.64% | −5.65% |
| Share past −10% | 15.3% | 15.6% | 15.4% | 15.8% | 15.3% |
| stop 8%, t paired | **+1.23** | +0.57 | −0.27 | −0.65 | −0.77 |
| Best rule of the sweep | stop 8% | trail 5% | trail 3% | stop 5% | stop 10% |
| Its deflated Sharpe | 0.75 | 0.65 | 0.41 | 0.08 | 0.24 |
| stop 5% + tp 5%, t paired | −1.20 | −0.57 | −0.67 | −1.23 | −1.79 |
| Gap-fill overstatement, 5% stop | +0.274% | +0.257% | +0.254% | +0.286% | +0.294% |

**The two durable results survive unchanged.** The drawdown inside the hold (mean MAE −5.6%, about one position in seven past −10%) and the gap-fill overstatement (+0.25% to +0.29% per rebalance at a 5% stop) barely move between starting days. Both are properties of the positions and of how stops fill, not of which days the book trades on.

**The stop-loss point estimate does not survive.** Stop 8%'s "improvement" was a phase-0 result: across the five starting days its paired t runs from +1.23 to −0.77, and the average change in Sharpe is +0.008. The best rule is a different one on every starting day, and its deflated Sharpe falls from 0.75 to as low as 0.08. So the honest reading of "do stops help?" is now *no measurable effect in either direction*, not "the prediction was wrong in sign". The original prediction (stops should hurt) is not supported either. The one rule with the same sign on every starting day is the **take-profit**: stop 5% + tp 5% is negative on all five (t −0.57 to −1.79). Capping a reversal trade's upside cuts off the mean reversion it is paid for, which is the mechanism the prediction named, just applied to the other exit. No single starting day clears |t| = 2, and the five share most of their positions' days, so this is a consistent sign, not a finding.

§43's kurtosis of 13.14, quoted above, is also the phase-0 figure. In simple returns phase 0 gives 9.54 and the other four give 3.7–5.8. That is still fat-tailed, but well below 13, and the gap-fill result doesn't depend on it.

#### The rest of the book

Chapter 11 was the gap. The full triage, since a partial reading presented as a complete one is the failure mode [§26](#26-book-coverage-what-was-taken-what-was-left-and-why) exists to avoid:

| Ch. | Topic | Status here |
|---|---|---|
| 1–2 | AI basics; superintelligence | Nothing implementable — Ch. 2 is Bostrom-style philosophy |
| 3 | Normative finance: EUT, mean-variance, CAPM, APT | A different product, and moot without a directional edge to allocate |
| 4 | **Debunking central assumptions** (normality, linearity) | True, already known, already **acted on** — see below |
| 5 | ML fundamentals: capacity, bias/variance, cross-validation | This project's walk-forward with purging and embargo ([§6](#6-avoiding-data-leakage-look-ahead-bias)) is stricter than plain CV |
| 6 | **AI-first finance / efficient markets** | **The book reaches this project's conclusion** — see below |
| 7 | Dense nets: normalization, dropout, regularization, bagging, optimizers | All present except **bagging** — see below |
| 8 | Recurrent nets | The existing model zoo (LSTM, GRU, Transformer, TCN, N-BEATS) |
| 9 | Reinforcement learning (DQL/FQL, finance gym) | Triaged out in [§26](#26-book-coverage-what-was-taken-what-was-left-and-why); RL optimises a *directional* policy, which [§15](#15-data-snooping-robust-model-selection-reality-check--spa) says has no edge to find |
| 10 | Vectorized backtesting | [§22](#22-economic-evaluation-does-the-forecast-make-money) |
| **11** | **Risk management, event-based backtesting** | **Implemented — this section** |
| 12 | Execution and deployment (Oanda) | Broker integration for FX; this is an NSE project and does not place orders |
| 13–14 | AI-based competition; financial singularity | Outlook, not method |

**Chapter 4** argues that normally distributed returns and linear relationships are false, via D'Agostino-Pearson skew/kurtosis tests and Q-Q plots. Both claims are correct and neither is news here: [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) measures the skew and kurtosis directly and feeds them into PSR, [§24](#24-value-at-risk-estimation-and-var-backtesting) does not merely *assume* non-normality but **tests it where it has consequences** — five VaR estimators, Gaussian among them, scored by Kupiec and Christoffersen — and the entire conformal layer ([§9](#9-conformal-prediction-distribution-free-intervals)) is distribution-free precisely because the assumption fails. Adding a formal normality test would confirm a premise the codebase is already built on, and would mean hand-rolling D'Agostino to preserve the project's zero-SciPy discipline.

**Chapter 6** is the book's central empirical claim, and it is worth recording what it actually concludes. Hilpisch lags log returns, fits OLS and an `MLPRegressor`, and reports in-sample direction accuracy "significantly above 50% throughout and above 60% in a few cases". He then states plainly that this was fit and predicted on the same rows, repeats it with an 80/20 split, and finds the neural network "much worse when compared to the in-sample numbers and **similar to the OLS regression results**" — that is, ~50%.

So a book explicitly looking for AI-discoverable inefficiency in price history reports the same answer this project reached across fifteen negative results, on a single 80/20 split where this one uses walk-forward validation, purging, embargo, SPA/Reality Check and a deflated Sharpe. **Independent corroboration from a source motivated to find the opposite is worth more than another confirming experiment would be.**

**Chapter 7's bagging** is the one genuine absence: this project stacks tree learners and takes a cross-family median (`meta_ensemble.py`), but never bootstrap-aggregates. It is deliberately left. Bagging reduces *variance*, not bias — averaging many draws of a predictor with no edge yields a lower-variance predictor with no edge — and `epistemic.py` already asks the neighbouring question ("how much would this forecast change if the model had been fitted differently?") by Monte-Carlo dropout, recorded as the eighth negative result in [§33](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result). Building it would add a sixteenth trial against fifteen nulls with a strongly predictable outcome, which is the behaviour [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39)'s deflation exists to penalise.

#### The window, and an error worth recording

The first run of this driver defaulted to **2022-01-01** rather than §39's **2018-01-01**, copied without thinking from the §44 driver. On that sub-window the same book posts an annualised Sharpe of **1.01** against **0.24** over the full period, stops appeared to *hurt* exactly as predicted, and every conclusion would have been a sample-period artefact that happened to confirm the hypothesis.

It was caught by reconciling the rebuild against §39's stored CSV, which is now **step 0 of the driver** and prints the correlation before anything else. A driver that reconstructs another section's result should prove it reconstructed it.

`event_backtest.py` ships with **24 tests**, most of which fail toward optimism rather than crashing — the gap-fill test, the intrabar-ordering test and the ratchet test each pin a number that the naive implementation would silently improve.

---

### 46. Price precision (Buzzelli, *Data Quality Engineering*, Ch. 3) — the dimension that was missing, and a falsification of §38

Buzzelli's *Data Quality Engineering in Financial Services* (O'Reilly) borrows its frame from manufacturing: a bottling plant does not inspect water by looking at it, it writes a **specification with tolerances** for each quality dimension and alarms on breach. Chapters 3–5 name eight such dimensions for data. Chapters 7–10 are governance — councils, operating models, maturity assessments — which is organisational process, not technique, and not applicable to a single-developer research codebase.

The eight dimensions, against what `data_quality.py` already checked:

| Dimension | Status before |
|---|---|
| Completeness | ✅ `nan_price_frac`, `min_rows_required`, `max_gap_days`, `zero_volume_frac` |
| Timeliness | ✅ `last_bar_age_days` |
| Accuracy | ✅ `bad_ohlc_frac`, `nonpositive_prices`, `recent_max_jump` |
| Conformity | ✅ numeric coercion, `fx_conversion`, `unconverted` |
| Collection | ✅ `duplicate_timestamps`, `sessions` |
| Cohesion | ✅ (partly) OHLC internal consistency |
| **Precision** | ❌ **nothing** |
| **Congruence** | ❌ nothing — see the end |

Seven of eight were already covered, which is a reasonable score for a gate written without the framework. **Precision was the genuine gap, and it is the one that fails quietly**: a coarse price grid produces no missing value, no bad OHLC row and no gap. It produces a return series that looks perfectly well-formed and is partly made of the tick.

#### Measuring it in the units that matter

Not the tick in rupees, and not the tick as a fraction of price. NSE quotes almost everything on a **₹0.05 grid**, which is 0.002% of a ₹3,000 share and 2% of a ₹2.40 one — but a 2% grid is irrelevant to a stock that moves 8% a day and crippling to one that moves 3%. The quantity that separates them is the tick as a share of **one daily standard deviation**.

Over the 400-name panel, 2018-01-01 → 2024-06-30:

| percentile | tick as share of a daily move |
|---|---|
| 50th | **0.6%** |
| 90th | 3.5% |
| 99th | 25.7% |
| max | 108.7% |

For the typical name this is a non-issue and the check will never fire. **11 of 335 names exceed 10%**, and they are all distressed penny stocks:

| symbol | price | tick (bp) | grid share | **repeated returns** |
|---|---|---|---|---|
| `LIQUIDBEES` | ₹1,000 | 0.1 | **108.7%** | **99.4%** |
| `MERCATOR` | ₹2.4 | 208 | 41.7% | 45.7% |
| `UNITECH` | ₹3.0 | 164 | 30.9% | 46.9% |
| `RCOM` | ₹3.0 | 167 | 28.9% | 49.5% |
| `KWALITY` | ₹6.2 | 81 | 19.6% | 36.2% |

A "repeated return" is a day whose log return *exactly* equals another day's — the fingerprint of a grid rather than a market. For `UNITECH` and `RCOM`, roughly **half** of all daily returns are exact duplicates. A volatility model fitted to that is measuring the tick.

`LIQUIDBEES` at 99.4% is the money-market ETF that [`tools/panel.py`](tools/README.md)'s instrument-type audit independently flagged for near-zero volatility. Two unrelated measurements — a volatility floor and a precision ceiling — pointing at the same instrument is a good sign that both are working.

**`COARSE_PRICE_GRID` now ships in `data_quality.py`**, at `INFO` above 5% and `WARN` above 15%. It deliberately does **not** force abstention: a penny stock is still forecastable, just noisily, and a data-quality check that silently takes the app offline is a behaviour change wearing a diagnostic's clothes. `test_a_coarse_grid_alone_does_not_force_abstention` pins that.

#### The question worth asking: is §38's signal made of the grid?

This is where a data-quality chapter turns into a research result. Roll (1984) showed that **bid-ask bounce induces negative serial correlation** in transaction prices, and price discreteness compounds it. Negative short-horizon autocorrelation is *precisely* the shape of the short-term reversal signal that [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) identified as this project's one positive result.

If that signal lived in the coarse-grid names, it would be microstructure rather than predictability — and it would explain mechanically why [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) found it costs more to trade than it earns. So the panel is split into precision quintiles and the reversal IC measured inside each:

| quintile | names | grid share | median price | **lag-1 AC** | **reversal IC** | t |
|---|---|---|---|---|---|---|
| 1 (finest) | 67 | 0.1% | ₹1,697 | +0.0072 | **−0.0267** | −2.66 |
| 2 | 67 | 0.3% | ₹637 | +0.0214 | −0.0323 | −3.44 |
| 3 | 67 | 0.6% | ₹290 | +0.0285 | −0.0363 | −3.68 |
| 4 | 67 | 1.4% | ₹119 | +0.0327 | −0.0486 | −4.75 |
| 5 (coarsest) | 67 | 3.5% | ₹43 | +0.0632 | −0.0439 | −3.84 |

**Two things, and both cut against the microstructure explanation.**

First, lag-1 autocorrelation goes the **wrong way for Roll**: it *rises* from +0.0072 on the finest grid to +0.0632 on the coarsest, where bid-ask bounce predicts it should fall and turn negative. There is a clean reason — NSE's official close is a **call-auction price** (volume-weighted over the last half hour), not a random buy or sell print, so the bounce Roll's model assumes is largely averaged away before the close is struck. Roll's mechanism is about *transaction* prices; this panel is built from auction prices.

Second, **reversal is present at every precision level**, including the finest quintile at a median price of ₹1,697 where the tick is one part in ten thousand of a daily move (IC −0.0267, t −2.66). There is a mild tilt toward the coarser names, but it is not monotone — quintile 5 is weaker than quintile 4 — and the quintiles differ in far more than precision, since cheap stocks are also smaller and more volatile.

**§38's result survives a falsification attempt it had not previously faced.** That is the honest value of this section: not a new signal, but one fewer way for an existing one to be wrong. The project has fifteen negative results; the one positive result deserves the same adversarial treatment, and this is the first time its *measurement substrate* rather than its statistics was attacked.

#### Congruence, considered and declined

The eighth uncovered dimension is **congruence** — do independent sources agree? The hook exists: `get_data.py` reads both yfinance and nselib/bhavcopy, and `safe_fetch` falls back between them. [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) validated the two against each other once, at **return correlation 1.00000 across 24/24 names**.

A *continuous* check is not built, and the reason is architectural rather than theoretical: comparing sources on every fetch means fetching both every time, doubling network cost and latency for a check that has so far always passed. The one-off validation is recorded, and the day the fetch layer maintains two live sources anyway, the check becomes free and worth adding. Noted rather than silently skipped.

---
### 47. The identifier is not the ticker (Khraisha, *Financial Data Engineering*, Ch. 3) — a hole in the survivorship-free panel

Khraisha's *Financial Data Engineering* is 507 pages of **infrastructure**: ingestion protocols, storage models, data lakes, message brokers, Postgres, Mage, Netflix Conductor, microservice workflows. Almost all of it describes an enterprise data platform, and this project is a single-user app with a research harness — building a data lake here would be a different product, not an improvement. Chapter 5's nine data-quality dimensions substantially duplicate [§46](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38)'s Buzzelli mapping, and Chapter 10's observability layer is covered by `prediction_log.py` and `feature_drift.py`.

**Chapter 3 is the exception**, and it found something real.

#### The property that matters

Among the properties Khraisha requires of a financial identifier, two are decisive:

> **Permanence** — identifiers and their associated data must be durable over time.
>
> **Immutability** — "an identifier associated with a specific entity should neither change nor be reassigned to another entity. If the identified entity ceases to exist, its identifier should never be reused."

Ticker symbols satisfy neither, and [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)'s survivorship-free panel is keyed on the NSE symbol. So I went looking for symbol *reuse* — two companies spliced into one price series, which would be the mirror image of the survivorship bias §38 exists to remove.

**That is not what is there.** What is there is worse, in the sense that it is structural rather than incidental.

#### NSE's key is (SYMBOL, SERIES), and the panel uses half of it

`bhavcopy.read_legacy` keeps `SERIES == 'EQ'`. That is correct and deliberate — the file also carries government securities (`GS`), treasury bills (`TB`) and the trade-for-trade segments (`BE`, `BZ`), none of which belong in an equity cross-section, and the docstring said so.

What the docstring did not say is the **consequence**. A company is not fixed in one series. NSE moves it to `BE` under the **Additional Surveillance Measure** and back to `EQ` when released. A live, trading company therefore *disappears from the panel* for the length of its surveillance period and reappears afterwards.

Verified against the raw NSE archive for 2018-08-01 rather than inferred:

| symbol | series that day | in panel? |
|---|---|---|
| `RELIANCE` | `EQ` | yes |
| `RAIN` | **`BE`** | **no** |
| `BOMDYEING` | **`BE`** | **no** |

Both vanish for 78 sessions and return. I found them because two large caps shared an *identical* gap start, length and coverage — which looked like a download hole. It is not: the local cache is **100% complete** for every business day 2018–2024, and those names are genuinely absent from the `EQ` rows.

#### How big is it

| | |
|---|---|
| Name-days missing *inside* each name's own listed span | **1.33%** |
| Names with any interior gap | **58 of 339** |
| Names losing **>10%** of their own history | **21** |

| symbol | missing | of span | share |
|---|---|---|---|
| `SHILPI` | 72 | 131 | **55%** |
| `ARCOTECH` | 367 | 730 | **50%** |
| `MERCATOR` | 385 | 1,084 | 36% |
| `SINTEX` | 319 | 1,041 | 31% |
| `RCOM` | 247 | 1,084 | 23% |
| `UNITECH` | 105 | 462 | 23% |
| `ABAN` | 314 | 1,507 | 21% |
| `KWALITY` | 154 | 777 | 20% |

Small in aggregate, **concentrated and non-random** in distribution. The exchange applies surveillance precisely when a name is volatile, illiquid or suspected of manipulation — so the panel is missing these names exactly during their most unusual periods. It is a *conditional* survivorship hole inside a panel built to be survivorship-free.

Note the overlap: `MERCATOR`, `UNITECH`, `RCOM` and `KWALITY` appear here, in [§46](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38)'s coarse-price-grid list, and in `tools/panel.py`'s flat-instrument audit. **Three unrelated data-quality lenses converging on the same small cluster** is evidence all three are measuring something real.

#### The rest of the book

Chapter 3 was the whole of it. The triage, verified against the code rather than read off the contents page:

| Ch. | Topic | Status here |
|---|---|---|
| 1 | The financial-data-engineer role, skills, responsibilities | Career description, not method |
| 2 | Data ecosystem: sources, structures, types, benchmark datasets (CRSP, Compustat, TAQ, IBES) | A reference catalogue of feeds this project cannot license — the same wall [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) hit |
| **3** | **Identifier permanence and immutability** | **Implemented — this section** |
| 4 | Financial NER and entity resolution | Needed to join datasets keyed by name against datasets keyed by ticker. This project joins nothing that way; `fundamentals.py` keys on ticker throughout |
| 5 | Nine data-quality dimensions; data integrity; security | Mostly duplicates [§46](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38)'s Buzzelli mapping — see below |
| 6 | Lifecycle: open-source vs commercial, cloud vs on-prem, multi-cloud, monolith vs modular | Procurement and deployment architecture |
| 7–9 | Ingestion protocols, storage models (data lake / relational / document / time series / message broker / graph / warehouse / blockchain), transformation and delivery | An enterprise data platform. Building one here would be a different product |
| 10 | Monitoring: metrics, events, logs, traces, data observability | Covered — `data_quality.py` (freshness, volume, schema), `feature_drift.py` (distribution, permutation-calibrated), `prediction_log.py` (forward outcomes, coverage drift), `run_manifest` (pin drift) |
| 11 | ETL, stream, microservice and ML workflows | Workflow orchestration for a multi-service platform |
| 12 | Hands-on projects: PostgreSQL, Mage, Netflix Conductor, OpenFIGI/PermID/GLEIF | Infrastructure tutorials |

**Chapter 5's ninth dimension list** adds one category Buzzelli's eight did not: **data biases**. Khraisha names five, and they are the reason to check rather than assume:

| bias | here |
|---|---|
| Self-selection (voluntary reporting) | N/A — exchange bhavcopy is mandatory, not self-reported |
| Survivorship | [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) closed a **26.8%** gap; §47 above found the second-order version |
| Backfilling / instant history | Measured: **1 name** in 339 first traded after the window opened, and the liquidity screen selects on a *pre-window* lookback, so a later-listed name is never backfilled in |
| Look-ahead | [§6](#6-avoiding-data-leakage-look-ahead-bias) purging/embargo, `adjust_prices(as_of=)`, [§41](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result)'s publication lag — see below |
| Data snooping (Kothari/Shanken/Sloan) | [§15](#15-data-snooping-robust-model-selection-reality-check--spa) SPA / Reality Check, [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) deflated Sharpe |

Khraisha's headline look-ahead example is a **fundamentals publication lag** — an annual report for 2019 released in March 2020 must not be visible on 2019-12-31. That is the same error class that cost [§41](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result) a signal, so it was worth checking rather than assuming. `fundamentals.py` already carries `PUBLICATION_LAG_DAYS = 45` and `ANNUAL_PUBLICATION_LAG_DAYS = 60`, computes `available_from(period_end)`, and joins with a **backward as-of merge on the lagged date**. Better than that: `as_of_join` **refuses** a frame that is not marked point-in-time rather than warning about it — the same make-the-safe-thing-mandatory pattern as `scaling_law_test(demean=True)` and `corwin_schultz(gap_adjust=True)`. Nothing to add.

**Chapter 5's integrity principles** — standards, backups, archiving, aggregation, lineage, catalogs, ownership, contracts, reconciliation — are organisational except two. **Lineage** in Khraisha's sense is a regulatory *audit trail* (OATS, CAT, order-level traceability for spoofing investigations); this project places no orders, and the reproducibility form of lineage is `run_manifest` plus `get_data.py`'s `attrs["price_adjustment"]`. **Reconciliation** against an independent source is the congruence dimension [§46](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38) declined, for the same architectural reason: it means fetching both sources on every call.
#### The filter stays, and the reason is about trading

The fix is *not* to include `BE`. A trade-for-trade line settles with **no intraday netting and full margin** — you cannot buy and sell it the same day. A backtest that traded a `BE` name as though it were a normal `EQ` line would be assuming an execution that was not available, which is the same class of error as [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)'s cost assumptions and [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed)'s gap-fill.

So the exclusion is right. **Silently excluding was not.** Two things changed:

- `bhavcopy.read_legacy`'s docstring now states the consequence, the verification and the measured size — not just the rule.
- `tools/panel.py` reports interior gaps alongside its ETF and precision audits, so the hole is visible on the research path, which never calls the app's quality gate.

No published figure moves: at 1.33% of name-days, and with the affected names absent rather than wrong, nothing in §38–§46 is recomputed. What changes is that the next person reading a 55% coverage figure for `SHILPI` will know why.

**The general lesson is Khraisha's.** A compound key collapsed to one of its components will lose rows silently, and the loss will correlate with whatever the dropped component encodes — here, distress. The project had already paid for the *survivorship* version of this mistake in §38; this is the same mistake one level down.

---
### 48. Risk-neutral is not physical (Hilpisch, *Financial Theory with Python*, Ch. 5) — a calibration error in shipped code

Hilpisch's *Financial Theory with Python* is a discrete-state mathematical finance textbook: two-state and three-state economies, replication, Arrow-Debreu securities, martingale pricing, both Fundamental Theorems of Asset Pricing, utility maximisation and equilibrium, then Black-Scholes-Merton, Merton jump-diffusion, binomial trees and Longstaff-Schwartz.

Nearly all of it prices **derivatives** or allocates a **portfolio**, and this project does neither — it has no option chain, and portfolio optimisation has been declined three times already ([§26](#26-book-coverage-what-was-taken-what-was-left-and-why), AFML Ch. 16, Tsang Ch. 5) for the same reason: allocating capital needs a directional edge, and [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) and [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) say there isn't one.

But Chapter 5's central distinction — that option-implied quantities live under the **risk-neutral** measure while realised quantities live under the **physical** one — lands on something this project ships.

#### The bug

[§19](#19-forward-looking-volatility-from-india-vix) tilts the HAR-RV cone by an India VIX signal:

```
F = (VIX-implied market daily vol) / (NIFTY recently-realised daily vol)
w = R² of the stock against NIFTY
m = clip(1 + w·(F − 1), [0.85, 1.30])
```

and §19 describes `F > 1` as "the market prices in *more* forward vol than recently realised (widen the cone)". That reading **assumes F = 1 is neutral** — that implied and realised are two estimates of the same thing.

They are not. Implied volatility is a risk-neutral expectation and carries the **variance risk premium**: the compensation sellers of options demand for bearing variance risk. It sits above realised volatility structurally, not occasionally. Measured on **2,428 days** of `^INDIAVIX` against NIFTY:

| | F = implied / realised |
|---|---|
| 5th percentile | 0.859 |
| median | **1.270** |
| 95th percentile | 1.814 |
| **share of days with F > 1** | **83.7%** |

So on a typical day `F ≈ 1.27` and the multiplier is `1 + w(0.27)` — between **1.05 and 1.16** for realistic linkage. Averaged over the whole history at `w = 0.4`, the mean multiplier was **1.1097**.

**That is a constant 11% widening of the cone, presented as a forward-looking signal.** It is not information about what the market expects; it is the price of a measure change, and it would have been applied on 84% of days regardless of conditions.

#### Why the original A/B did not catch it

§19 records that the feature "ships **off** after an A/B showed it coverage-neutral on calm data". That result is *exactly what a constant widening looks like* when coverage is already at or above target — the extra width eats headroom that was already there. The A/B compared "on" against "off" and measured coverage; it could not distinguish **forward-looking information** from **a multiplier of 1.11**, because on calm data both produce the same slightly-wider, slightly-over-covering cone.

A null result is not evidence that a component is correct. It is evidence that the test could not tell the difference — which is a different statement, and the one worth recording.

#### The fix

Divide `F` by its own **trailing median**, so the factor responds to how the premium compares with its normal level rather than to the premium itself. The baseline uses 504 trailing sessions with a 252-session minimum, computed strictly `<= asof`, so it stays leak-free in a walk-forward backtest for the same reason every other lookup in the module does.

Re-measured on the real series with a strictly trailing baseline:

| | median F | share > 1 | mean multiplier (w = 0.4) |
|---|---|---|---|
| raw (before) | 1.270 | 83.7% | **1.1097** |
| centred (after) | 0.996 | **49.5%** | **1.0044** |

The factor is now genuinely two-sided — it widens and tightens about equally often — and its *average* effect on the cone is +0.4% rather than +11%, while still responding to a VIX that is high or low **for itself**.

With too little history to form a baseline the factor returns a **no-op rather than the uncentred ratio**. Falling back to the raw value would reintroduce the premium silently, and a miscalibrated signal is worse than no signal; `test_too_little_history_falls_back_to_a_noop_not_to_the_raw_ratio` pins that.

The regression test is `test_the_factor_is_invariant_to_the_level_of_the_premium`. It is deliberately not "the multiplier equals 1" — today's realised vol still differs from its median and that difference is real signal. It asserts the property the centring actually guarantees: **the same market path at VIX 8, 15 and 60 must give the same factor**, because the level of the premium is a property of the measure change, not of the forecast. The raw ratio varies by more than 5× across those levels; the centred one by less than 0.02.

#### What this changes

Nothing that ships. `iv_adjust` remains **off by default**, so no forecast anyone has seen was affected — the feature was already disabled on the strength of an A/B that, it turns out, was measuring the wrong thing. What changes is that the opt-in path is now calibrated, and if the A/B is ever re-run it will compare against a signal rather than against a constant.

**This is the first thing a book has found that was an outright error in shipped code**, rather than a technique to add or a null to record. It is also the smallest: one division, once the distinction is seen. Chapter 5 spends thirty pages on the measure change and this project had carefully implemented a ratio across it without noticing — which is a fair summary of why the theory chapters are worth reading even when the pricing ones are not.

---
### 49. Residual reversal (Tatsat et al., *Blueprints*, Ch. 7) — and a rebalance-phase artefact in §39

*Machine Learning and Data Science Blueprints for Finance* (Tatsat, Puri & Lookabaugh) is a book of worked case studies. Most of them fall outside this project: fraud detection, loan default, robo-advisor risk tolerance, yield curves, derivative pricing, chatbots and document summarisation. Others were declined earlier for the same reasons: reinforcement-learning trading ([§26](#26-book-coverage-what-was-taken-what-was-left-and-why)), hierarchical risk parity (AFML Ch. 16), and NLP sentiment (no text feed). Its stock-prediction case study (Ch. 5) builds its features cleanly — every input is a trailing return, the target is the forward one, and weeks don't overlap. But it concludes that "simple models… are promising" from comparing models against *each other*, with no random-walk or zero-forecast baseline, which is the comparison [§14](#14-validating-the-uncertainty-calibration)–[§15](#15-data-snooping-robust-model-selection-reality-check--spa) exist for. Its bitcoin case study (Ch. 6, reused in Ch. 7) is a cautionary one: the target is *today's* 10-versus-60-day moving-average crossover rather than any future move, one feature (`MA21`, which is in fact a 10-day average) is the crossover's own input, and the split is a shuffled `train_test_split`. It measures how well a classifier recovers a formula from its ingredients, not whether anything can be forecast. Its pairs-trading case study (Ch. 8) is a new strategy family rather than a check on an existing one. It would face [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)'s cost wall, and it picks pairs by clustering over the whole sample, which is look-ahead.

**Chapter 7's PCA is the useful part, with its eigen-portfolios swapped for the risk-model use of the same factors.** [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)'s reversal signal ranks stocks on their *raw* trailing 5-day return. Part of that return is the stock moving with common factors (sector, size, style) and snapping back with them. Strip out the top principal components first and rank on what's left — the *residual* return — and you're asking whether the project's one positive result is the stock's own reversal or a factor bouncing back.

#### The setup, fixed in advance

PCA on a trailing 252-day window of daily returns at every date. Residual 5-day returns after removing the top **k ∈ {1, 3, 5}** components (chosen beforehand, all reported). Decile long-short, 5-day hold, 2018-01-01 → 2024-06-30, which stops before the reserved final test period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)). The top 1, 3 and 5 factors explain 27%, 33% and 37% of daily variance on average.

#### The reconciliation failed first, and found something

Step 0 rebuilt §39's raw book to check the driver. It disagreed badly: a mean of **−0.12%** per rebalance against §39's **+0.105%**, and a correlation of 0.256. The cause wasn't a bug. The driver's first rebalance landed two sessions later than §39's. A 5-day book rebalanced every 5 sessions has **five equally valid starting days**, and §39's result depends on which one you pick:

| Rebalance starting day | Mean gross per rebalance | Annual Sharpe | t |
|---|---|---|---|
| **0 (§39's)** | **+0.0873%** | **+0.196** | +0.49 |
| 1 | +0.0164% | +0.041 | +0.10 |
| 2 | −0.1004% | −0.268 | −0.67 |
| 3 | −0.0531% | −0.145 | −0.36 |
| 4 | +0.0704% | +0.184 | +0.46 |

§39 published the **best of the five**, not by choice: its loop started on row 5, and that turned out to be the top. Averaged over all five, gross is **+0.004%**, and no starting day reaches |t| = 1. This strengthens §39 and [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39): the raw reversal book is indistinguishable from zero *before* costs, not just after them. Both sections now carry a note. §38's IC is unaffected, because it is computed every day.

So the driver computes signals **every day**. IC uses every day, with a Newey-West correction because the 5-day forward windows overlap, and the book is **averaged over all five starting days**. Re-reconciled on that basis: **correlation 0.967** with §39 on the 269 shared dates. The remaining gap is this build's requirement of a full 252-day window, which the diagnostic measured separately.

#### The result

| Signal | Rank IC | t | Gross per rebalance (5-day average) | Range across starting days | Turnover | Breakeven |
|---|---|---|---|---|---|---|
| raw (§38/§39) | −0.0266 | −4.16 | +0.025% | −0.12% … +0.15% | 3.47 | **1.4 bp** |
| residual, k = 1 | −0.0315 | −5.97 | +0.127% | −0.03% … +0.27% | 3.46 | 7.3 bp |
| residual, k = 3 | −0.0306 | −6.80 | +0.191% | +0.04% … +0.29% | 3.46 | 11.0 bp |
| residual, k = 5 | −0.0335 | **−8.08** | **+0.263%** | **+0.17% … +0.33%** | 3.47 | **15.1 bp** |

**Most of the reversal that survives is the stock's own, not a factor's.** Removing common factors nearly doubles the t-statistic (−4.16 → −8.08), and the k = 5 book is positive on **every** starting day, where the raw book's sign depended on the day. All three pre-specified k values beat the raw signal, so this isn't a best-of-three pick. And the improvement comes at the **same turnover**, so it flows straight into breakeven: 1.4 bp → 15.1 bp.

**It is still not tradeable.** 15.1 bp (15.2 bp in simple returns, see [§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)) is below STT's 20 bp round trip, before brokerage, fees, stamp duty or impact. And §39's other constraint still applies: only 39% of a liquid NSE universe is shortable. So the verdict on trading reversal stands. What changes is the description of the signal. It is real, mostly idiosyncratic, and much steadier once factor moves are removed. Its gross edge per unit of turnover is about **11×** what the raw version suggested.

*(Later note, [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code): traded through stock futures on point-in-time F&O names, the signal's breakeven falls to 5.2 bp. It lives mostly in names without futures, so futures don't rescue it.)*

*(Later note, [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces): confirmed out of sample on July–December 2024, after every panel study and before the reserved period: k = 5 IC −0.0245, t −2.21, 73% of the size above. The cost verdict is unchanged.)*

That makes residual reversal at k = 5 the natural candidate for the one-shot test of the reserved 2025–2026 period, if that is ever spent. It's specified here before anyone has looked at that data, which is what a final test needs. `run_residual_reversal.py` reproduces everything above; the results are in `tests/validation/residual_reversal.csv` (re-run after the renamed-company fix, [§74](#74-renamed-companies-lost-their-corporate-actions)).

---
### 50. Jensen's inequality in expected shortfall (Sadr, *Mathematical Techniques in Finance*, A.2.4) — a units error in shipped code

Sadr's *Mathematical Techniques in Finance* is a quantitative-finance primer, and most of it prices instruments this project doesn't have:
- bond math and yield curves (Ch. 2);
- forwards and futures (Ch. 4);
- binomial and Black-Scholes-Merton option pricing, Greeks and implied volatility (Ch. 5–6), whose risk-neutral side [§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code) already covers;
- interest-rate derivatives (Ch. 7).

Chapter 3 and Appendix A are general, and one line of the appendix lands on shipped code.

#### The error

Expected shortfall is the **average** return in the worst 5% tail. Every estimator in `var_models.py` and the app's `risk_metrics.empirical_risk` (the "Expected shortfall (worst 5%)" tile, [§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)) computed it as

```
es = expm1(mean(log_tail))      # geometric mean of the tail's gross returns
```

By Jensen's inequality, `exp(E[X]) ≤ E[exp(X)]` (Sadr A.2.4, and the Ch. 3 exercise showing the arithmetic average dominates the geometric). So this is always **more negative than the average loss** it is labelled as. The ES backtest made it a units mismatch as well: `backtest_es` scores the forecast against **simple** realised returns, `expm1(sum of logs)`, so a geometric ES was being compared with arithmetic outcomes. A tail of −10% and −30% log returns averages a 17.7% loss, not the 18.1% the old formula reported.

VaR was never affected. A quantile commutes with `exp`, so `expm1(quantile(log r))` is exactly the quantile of the simple return. The error is specific to taking a **mean** across the change of scale.

#### How large

`run_es_jensen.py`, 2018–2024, 5% tail:

| | h = 1 | h = 5 | h = 20 | h = 60 |
|---|---|---|---|---|
| RELIANCE, old → new | −3.99% → −3.97% | −8.97% → −8.91% | −15.25% → −14.88% | −19.88% → −19.42% |
| TCS, gap / ES | 0.3% | 0.6% | 1.0% | 0.7% |
| TATASTEEL, gap / ES | 0.3% | 0.4% | 1.4% | 0.6% |
| YESBANK, gap / ES | **3.5%** | 2.8% | 1.1% | 0.4% |

**Small, always conservative, and largest where the tail is most dispersed** (YESBANK's 1-day tail, RELIANCE's 20-day tail). Nobody was misled into under-reserving. But the tile overstated the average bad outcome by up to a few percent of itself, and the number wasn't the quantity on its label.

#### The fix

- **Sample-based ES** (historical simulation, FHS, the generative sampler, and the app's `empirical_risk`) is now `mean(expm1(tail))`, through one helper, `var_models._tail_es`.
- **Gaussian ES** uses the lognormal tail mean, `E[e^X | X ≤ q] = exp(μ + σ²/2) · Φ(z − σ) / α`, instead of transforming the log-space closed form.
- **Cornish-Fisher** has no closed-form ES; its documented approximation now carries the same log-to-simple correction as the Gaussian of the same σ.

Re-running §24's ES backtest on its fat-tailed test series: the Gaussian model is still rejected (severity ratio **1.88**, p = 0.0015, unchanged to the digits shown). Historical simulation still passes, at 1.02 / p = 0.125 instead of 1.01 / p = 0.16. Its ES moved slightly less negative, so realised tails look marginally worse against it, which is the honest direction.

Two tests pin it:
- `test_es_is_the_mean_of_simple_tail_returns_not_a_geometric_mean` (`test_var_models.py`) checks every sample-based estimator against the definition.
- `test_expected_shortfall_averages_simple_returns` (`test_har_downside.py`) checks the app's tile, and that its VaR is unchanged.

The closed-form Gaussian test added in [§24](#24-value-at-risk-estimation-and-var-backtesting) now checks the simple-return ES against 4 million draws, and still checks that the log-space ratio is the textbook 1.254.

#### What was checked and left alone

- **The point forecast is a median, and labelled one.** Under a lognormal, `exp(mean log)` is the **median** price, not the mean, and `simulate_price_paths` reports the median of its paths. The UI calls it "median forecast", and `risk_from_interval` reads `μ = log(median / last)`, so this is consistent. Here Jensen's inequality is respected by the labels.
- **The rest of the code was searched for the same pattern**, a mean taken on one scale and converted to the other. `strategy_metrics.evaluate_strategy` converts log returns to simple before compounding, and HAR-RV's log-variance back-transform already carries a bias correction, pinned by a test.
- **The long-short books in §39 and [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39) average each leg's log returns.** An equal-weighted leg actually earns the mean of its simple returns, and costs are paid on simple notional, so a log book understates a reversal book: its long leg (recent losers) is the more volatile. `run_residual_reversal.py` now reports both:

  | Signal | Gross, log | Gross, simple | Breakeven, log | Breakeven, simple |
  |---|---|---|---|---|
  | raw | +0.025% | +0.037% | 1.4 bp | 2.1 bp |
  | residual, k = 5 | +0.263% | +0.263% | 15.1 bp | **15.2 bp** |

  The gap is small and moves no verdict: 15.2 bp is still below STT's 20 bp round trip. §39's own 5.0 bp becomes about 7.5 bp on [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed)'s simple-return rebuild of the same book, still far below. The headline figures stay in log returns for continuity, with the simple ones alongside.
- **Kelly's ratio and gambler's ruin (Ch. 3.6.5)** are declined, because the inputs say there's nothing to size. Sadr's binary-bet Kelly fraction is `f* = 2p − 1`. With directional hit rates statistically indistinguishable from 50% ([§15](#15-data-snooping-robust-model-selection-reality-check--spa), [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39)), it sizes every bet at zero. The gambler's-ruin formula is §39's conclusion in closed form: with p = 18/38 the book's example goes from a 90% to a 0.003% chance of success. The sizing the app does support (its decision guide lists *abstain / size / set a stop*) scales by **risk**, which needs no edge, not by expected return, which would.
- **Performance measures (3.6.2)**: Sharpe, Sortino, information ratio, Calmar and drawdown are in `strategy_metrics.py`. Treynor and Jensen's alpha need a market beta, which a market-neutral book doesn't have.
- **Z-scores, mean reversion, pairs trading (3.6.3–3.6.4)** are covered by [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) and [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39); pairs trading was declined there.
- **PCA and factors (3.4)** are [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39).
- **CAPM, Markowitz and the efficient frontier (3.2–3.3)** are portfolio allocation, declined before for want of an edge to allocate.
- **Random walk and GBM (6.1)** are the baseline every model here is tested against.
- **Root search, numerical derivatives and Taylor expansion (Ch. 2)** have no use here: nothing in this project solves for a yield or prices a bond.

**The second error a book has found in shipped code**, after [§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code). Like that one, it was a change of scale applied without noticing what it does to the quantity on the other side.

---
### 51. A p-value is not the probability of no edge (Kanungo, *Probabilistic Machine Learning for Finance and Investing*, Ch. 4)

Kanungo's *Probabilistic Machine Learning for Finance and Investing* argues that finance should model with probability distributions rather than point estimates: Bayesian inference, generative ensembles, and decisions taken against a full predictive distribution. Most of that argument is already how this product works. Its forecasts are distributions, its intervals are checked for coverage, and its headline output is uncertainty rather than direction. One chapter lands on something the app shows on every row.

#### The inverse fallacy, on the confidence badge

The Basis column justifies each model's confidence badge with its Diebold-Mariano p-value, for example `weak edge (DM p=0.14)`. A p-value is *P(a result this good | no edge)*. It is not *P(no edge | this result)*. Ch. 4 calls reading one as the other the **prosecutor's fallacy**, and it is the natural reading of "p = 0.14": "86% sure there's an edge".

Sellke, Bayarri & Berger (2001) bound how far the two can differ. Over a broad class of alternatives, the Bayes factor in favour of the null is **at least −e·p·ln p** (for p < 1/e). Starting from even odds, that gives a floor on the probability of no edge:

| DM p | Naive misreading, P(no edge) = p | **Floor on P(no edge)** |
|---|---|---|
| 0.01 | 1% | 11.1% |
| 0.05 | 5% | 28.9% |
| **0.10**, the 'High' threshold | 10% | **38.5%** |
| 0.14 | 14% | 42.8% |
| **0.20**, the 'Medium' threshold | 20% | **46.7%** |

The floor is the alternative's **best case**, so the true probability can only be higher. It also ignores that several models were tried, which is [§15](#15-data-snooping-robust-model-selection-reality-check--spa)'s job. So a 'High' badge at the edge of its threshold still leaves, at the very least, better than a one-in-three chance that the model has no edge.

#### What changed

- `backtest.min_bayes_factor(p)` and `backtest.null_probability_floor(p, prior_null=0.5)` are new pure functions, next to `diebold_mariano`.
- `gating.confidence_reason` appends the floor wherever the badge **claims** an edge: `beats random walk (DM p=0.05, cov 94%; P(no edge) ≥ 29%)` and `weak edge (DM p=0.14; P(no edge) ≥ 43%)`. 'Low' and 'No edge' rows claim nothing, so there's nothing to deflate and they're unchanged.
- The badge rule itself (`confidence_bucket`) is **not** changed. The gate is validated live against realised skill ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)), and changing its thresholds to match a prior would be a new, unvalidated rule. What changes is that the evidence behind it can no longer be read as stronger than it is.
- Three tests in `test_gates.py`:
  - known values of the bound;
  - the floors at the two bucket thresholds, and that the floor always exceeds the naive reading;
  - the exact Basis strings.

#### The rest of the book

| Ch. | Topic | Status here |
|---|---|---|
| 1–2 | Model error, the three kinds of uncertainty, no-free-lunch, induction | Background. Aleatory uncertainty is the cone. Epistemic uncertainty was tested by MC dropout in [§33](#33-epistemic-uncertainty-and-psychological-tolerance-klaas--the-eighth-negative-result) (negative). Ontological uncertainty, a regime the model has never seen, is the novelty gate of [§25](#25-regime-novelty-from-a-denoising-autoencoder) |
| 3 | Monte Carlo simulation; why volatility understates risk | Forecasts are simulated paths. The tail is reported as VaR, ES and semideviation ([§24](#24-value-at-risk-estimation-and-var-backtesting), [§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)) |
| 4 | NHST and confidence-interval fallacies | **This section.** The README and UI text were also checked for the interval fallacies: the 95% band is described throughout as covering ~95% of outcomes, checked empirically, never as a 95% probability for one interval |
| 5–6 | Inverse probability, MCMC, an earnings-expectations model | Needs earnings data. MCMC for parameter uncertainty asks §33's question |
| 7 | Bayesian "probabilistic linear ensemble" of the market model (PyMC) | Declined, see below |
| 8 | Loss-based decisions, ergodicity, generative VaR/ES, Kelly, ruin | Generative VaR/ES is `var_models`. The paper portfolio already reports compounded, time-average growth (CAGR) rather than an arithmetic mean, which is the ergodicity point. Kelly sizes every bet at zero without an edge ([§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)) |

**Chapter 7 is declined, and its evaluation is worth recording.** The ensemble predicts Apple's daily excess return from the **same day's** S&P 500 excess return. That is a contemporaneous market model: using it requires the day's market return, which isn't known in advance. Its out-of-sample "69% R²" on 10 test days measures co-movement (beta), not forecasting. The setup also mixes units twice:
- `^TNX` quotes the 10-year yield in percent, so `(1 + 3.8)^(1/360) − 1` treats a 3.8% yield as 380% a year.
- That fraction is subtracted from returns already multiplied by 100.

The concern behind the chapter is real: point estimates from short samples ignore parameter uncertainty. This project answers it with [conformal intervals](#9-conformal-prediction-distribution-free-intervals), which carry a finite-sample coverage guarantee under exchangeability and are checked live. A Bayesian posterior on 21 days, with a chosen prior, carries no such guarantee.

---
### 52. Hilpisch's technical rules, optimised and tested (*Python for Algorithmic Trading*, Ch. 4) — the Probability of Backtest Overfitting

Hilpisch's *Python for Algorithmic Trading* is mostly about the machinery of trading:
- conda, Docker and cloud set-up (Ch. 2);
- data storage (Ch. 3);
- sockets and streaming (Ch. 7);
- the Oanda and FXCM broker APIs (Ch. 8–9);
- deployment (Ch. 10).

Its method chapter is Ch. 4. It backtests three classic rules and optimises each by brute force for in-sample gross performance. For the SMA crossover that means 500 pairs (SMA1 in `range(30, 50, 2)` × SMA2 in `range(200, 300, 2)`), with the best one reported.

The chapter is candid about the problem with that. Its own "Data Snooping and Overfitting" section (pp. 111–113) says the examples are chosen "to make a certain point". It cites Bailey et al. (2015) on backtest overfitting and leaves the validation to the reader. This project had used SMA ratios as ML **features**, but had never tested the rules as **strategies**. So this section does the validation the book leaves out, on NSE, with the tool its own citation proposes.

#### New: the Probability of Backtest Overfitting

`strategy_metrics.probability_of_backtest_overfitting` implements Bailey, Borwein, López de Prado & Zhu's **CSCV**, combinatorially symmetric cross-validation:

1. Cut the history into 16 contiguous blocks.
2. For each of the 12,870 ways to use half of them as in-sample, pick the configuration with the best in-sample Sharpe.
3. See where that winner ranks among all configurations on the other half.

PBO is the share of splits where the in-sample winner lands at or below the out-of-sample median. It is about 0.5 when nothing has skill, near 0 for a genuine edge, and above 0.5 when selection picks noise that then reverses. Five tests pin those three regimes, the split count and input validation.

It complements the project's other two selection tools:
- the deflated Sharpe ([§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39)) asks whether the best result beats the best of N lucky draws;
- SPA ([§15](#15-data-snooping-robust-model-selection-reality-check--spa)) asks whether any model beats a benchmark;
- PBO asks whether **the act of selecting** carries information at all.

**One output from the paper is deliberately left out.** The paper also regresses the winner's out-of-sample Sharpe on its in-sample Sharpe. The halves are complementary, so when the same configuration wins every split, a better in-sample half mechanically means a worse out-of-sample half. The slope is therefore negative even for a genuine edge: the first draft of the test, with one truly better configuration, measured −0.94. It can't tell skill from overfitting, so it isn't returned.

#### The test

`run_technical_rules.py`: 47 of the 50 most liquid names, survivorship-free, 2018-01-01 → 2024-06-30. That is before the reserved test period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)), with trading starting after a 300-session warm-up so every configuration shares one window.

| Rule family | Grid |
|---|---|
| SMA crossover | The book's 500 pairs |
| Momentum | Sign of the mean of the last m log returns, m ∈ {1, 2, 3, 4, 5, 10, 20, 60, 120, 250} |
| Mean reversion | SMA ∈ {20, 25, 30, 43, 50} × threshold ∈ {2.5, 5, 7.5, 10}% of the SMA |

- **Mean reversion's threshold is relative here.** The book uses price units (3.5 on GDX, 7.5 on GLD), which don't transfer across stocks.
- **Each rule is run long-short, as in the book, and long-only**, because overnight single-stock shorting isn't available in Indian cash equities.
- **Costs and timing:** positions earn the next day's simple return, net of 10 bp one way per unit of position change.

**1. The book's method looks fine before costs.** Medians across names, full period:

| Rule | Best in-sample, gross | Same, net | Buy & hold | Best beats buy & hold (net) |
|---|---|---|---|---|
| SMA, long-short | +153% | +55% | +131% | 21% of names |
| SMA, long-only | +131% | +130% | +131% | 40% |
| Momentum, long-short | **+306%** | +109% | +131% | 34% |
| Momentum, long-only | +225% | +163% | +131% | 51% |
| Mean reversion, long-short | +6% | −20% | +131% | 13% |
| Mean reversion, long-only | +37% | +28% | +131% | 17% |

This is the book's own reporting standard: the best of the grid, in-sample, gross. On it, momentum long-short more than doubles buy & hold. The same configuration, net of costs, falls below buy & hold, and **even in-sample** the cost-adjusted winner beats buy & hold on a minority of names in every family but one. The winning SMA pair differs from stock to stock: no pair is best on more than 3 of 47 names.

**2. Selecting from the grid is close to a coin flip.** Median PBO per name is **0.42–0.52** in all six families, and 30–51% of names exceed 0.5. Pooled (each configuration applied to every name, equal weight):

| Rule | Pooled PBO | P(in-sample winner loses out of sample) |
|---|---|---|
| SMA, long-short | 0.42 | 27% |
| SMA, long-only | 0.36 | 6% |
| Momentum, long-short | **0.65** | 38% |
| Momentum, long-only | 0.38 | 3% |
| Mean reversion, long-short | 0.25 | **94%** |
| Mean reversion, long-only | 0.35 | 50% |

Read the two columns together. PBO says whether the in-sample winner ranks well **among the configurations**; it doesn't say whether any of them makes money. Mean reversion long-short has the lowest PBO and loses money out of sample in 94% of splits: selection reliably finds the least bad of a losing family. The long-only families' low loss rates are mostly market exposure in a rising market, which point 3 separates from skill.

**3. Optimise on the first half, trade the second.** Medians of annualised net Sharpe:

| Rule | Pick, in-sample | Pick, out of sample | Grid median, out of sample | Buy & hold, out of sample | Pick beats buy & hold |
|---|---|---|---|---|---|
| SMA, long-short | +0.53 | +0.46 | +0.28 | +0.91 | 19% of names |
| SMA, long-only | +0.69 | +0.57 | +0.55 | +0.91 | 26% |
| Momentum, long-short | +0.68 | **+0.03** | −0.12 | +0.91 | 11% |
| Momentum, long-only | +0.83 | +0.63 | +0.49 | +0.91 | 21% |
| Mean reversion, long-short | +0.08 | −0.02 | −0.05 | +0.91 | 21% |
| Mean reversion, long-only | +0.30 | +0.44 | +0.51 | +0.91 | 15% |

In every family the optimised pick trails buy & hold out of sample, and it beats buy & hold on at most a quarter of names. Momentum long-short loses almost all of its in-sample Sharpe (+0.68 → +0.03), which is the pooled PBO of 0.65 seen from the other side.

**4. The book's own defaults, with no selection at all** (SMA 42/252, momentum 3), over the full period: net Sharpe +0.15 / +0.51 (SMA long-short / long-only) and −0.27 / +0.25 (momentum), against buy & hold's +0.65. They beat buy & hold on 11–34% of names.

**None of the three rule families beats buy & hold on NSE large caps out of sample, net of costs, by either method of choosing parameters.** The comparison runs over a strong bull market (buy & hold's out-of-sample Sharpe is 0.91), which is a hard benchmark for any rule that spends time flat or short. But the in-sample results were measured over the same market and looked good, which is exactly the gap the book warns about. Its own "make a certain point" caveat was the right one.

#### The rest of the book

| Ch. | Topic | Status here |
|---|---|---|
| 1–2 | Python, conda, Docker, cloud instances | Pins and a run manifest record the environment ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)). A local Streamlit app doesn't need a container |
| 3 | CSV / Excel / JSON / HDF5 / TsTables / SQLite; Eikon | The bhavcopy cache (compressed daily CSVs) already serves 2,521 sessions; no gain from another store |
| 4 | Vectorized SMA, momentum, mean-reversion backtests; data snooping | **This section** |
| 5 | Linear and logistic regression, DNNs on lagged returns for direction | The existing model zoo, scored by Diebold-Mariano, SPA and the deflated Sharpe |
| 6 | Event-based backtesting classes | [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed), from the same author's *AI in Finance* |
| 7 | Sockets, streaming, real-time plots | The app forecasts from daily and hourly bars; no tick feed |
| 8–9 | Oanda CFDs, FXCM FX | Broker APIs; this project doesn't place orders |
| 10 | Kelly for stocks, optimal leverage | Kelly needs an edge, and points 1–4 add three more families without one ([§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)) |
| 10 | Risk analysis of the leveraged strategy | `var_models` ([§24](#24-value-at-risk-estimation-and-var-backtesting)) |
| 10 | Persisting models, online algorithm, logging and monitoring | Every forecast is a full refit. Monitoring is the prediction log's drift and gate reports ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)) |

**Two evaluations in the book worth knowing before reusing them:**

- **Ch. 5's logistic regression always predicts "up".** Its "53.3% hit ratio" is fitted and scored in-sample, and `value_counts()` on the predictions shows a single class, `1.0`, on all 1,983 days. The accuracy is the share of up days, and the "strategy" is buy & hold. The book does go on to recommend a train/test split.
- **Ch. 10's "optimal leverage" uses the test period twice, and leaves out the variance drag.** The Kelly leverage (half Kelly above 50) is computed from the **test** period's own mean and variance, then applied to that same period. The leveraged equity curve is then built as `strategy_tc * lev` on **log** returns. A leveraged log return is `log(1 + l·(eʳ − 1))`, which grows at about `l·μ − l²σ²/2`. That second term is exactly what the Kelly formula balances, so scaling log returns linearly makes every extra unit of leverage look better. This project's leverage path (`position_from_signal`'s `max_leverage`) multiplies positions into **simple** returns (`pos * real_simple` in `evaluate_strategy`), which is correct.

**One small correctness note.** The book's maximum drawdown (p. 96) is `cummax − cumret` in gross-performance points ("about 18 percentage points"), not a fraction of the peak. That understates a drawdown after gains and overstates one after losses. `strategy_metrics.max_drawdown` is already relative (`curve / running_max − 1`).

---
### 53. The 52-week high (Yan, *Python for Finance*, Ch. 8) — the book has the sign backwards, and the data cannot settle it

Yan's *Python for Finance* is an introduction to Python:
- installation, the language, modules, NumPy, SciPy and matplotlib (Ch. 1–7);
- option pricing (Ch. 9–11);
- volatility (Ch. 12).

Its applied material is a list in Ch. 8, "Many useful applications". One item on it had never been tested here: the **52-week-high trading strategy**.

#### Two hypotheses with opposite signs, written down first

Yan states the rule as **contrarian** (p. 196): go long when today's price is close to its 52-week low and short when it is close to its 52-week high. George & Hwang (2004, *Journal of Finance*) found the **opposite** in US equities. Stocks near their 52-week high outperform, distinctly from momentum, because investors anchor on the high and under-react to news that pushes a price toward it. Both are recorded in the driver's docstring before running, so the sign of the result decides between them.

It was worth testing for a reason specific to this project. [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)'s reversal signal died on cost ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)) because it turns over 3.5× every five days. A year-long high moves slowly, so a monthly book should trade far less. And its long side, stocks near their highs, can be bought without shorting.

#### The test

`run_52week_high.py`, on the same survivorship-free universe as §38: 400 names, 2018-01-01 → 2024-06-30, which stops before the reserved test period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)). That gives 1,328 signal days from 2019, with a median of 286 names per day.

- **Signal:** price / 52-week high (George & Hwang), with Yan's position in the 52-week range alongside.
- **Horizon:** 21 sessions.
- **IC:** daily rank IC, Fama-MacBeth with Newey-West at 21 lags. The partial version controls for 12-1-month momentum (George & Hwang's control) and the last 21-day return.
- **Books:** decile books rebalanced every 21 sessions and averaged over all 21 starting days ([§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)).
- **Bucketing:** deciles are value thresholds **with ties included**. In a rising market more than a tenth of names can sit exactly at their high, and the first version of the driver, using averaged ranks, produced an empty top decile.

| Signal | Rank IC | t |
|---|---|---|
| Price / 52-week high | **+0.0388** | +1.85 |
| Position in the 52-week range (Yan) | +0.0329 | +1.83 |
| 12-1 month momentum (control) | +0.0552 | +2.82 |
| Price / 52-week high, beyond momentum and the 21-day return | +0.0380 | +1.70 |

| Book (per month, gross) | Mean | Across 21 starting days | t per starting day | Turnover | Breakeven |
|---|---|---|---|---|---|
| Long-short decile | **+1.07%** | +0.41% … +1.71% | median +0.91, max **+1.56** | 1.80 | 118 bp |
| Long side: top decile vs universe | +0.17% | −0.39% … +0.70% | median +0.36 | 1.30 | 26 bp |
| Short side: universe vs bottom decile | +0.90% | +0.66% … +1.22% | median +1.17, max +1.79 | 0.56 | 323 bp |

#### Reading it

- **The sign is George & Hwang's, not Yan's.** That holds on both measures, beyond momentum, and on every one of 21 starting days for the long-short book. Nothing here supports the contrarian rule as the book states it.
- **But it isn't established.** The IC's t is 1.85, short of 1.96, and 1.70 after controls. The long-short book's 1.07% a month comes with roughly 9% monthly volatility over 63 non-overlapping months. Its t-statistic is at most **1.56** on any starting day, so the gross return itself is not distinguishable from zero. The 118 bp breakeven therefore says nothing: a breakeven is only meaningful once the gross is.
- **The consistent part is the short side.** Stocks far below their highs keep lagging: positive on all 21 starting days, t up to 1.79. That is exactly the side this market won't let you trade. Only 39% of a liquid NSE universe is shortable (§39), and the names furthest below their highs are the least likely to be. The long side, the one a long-only investor could use, is +0.17% a month with a sign that changes with the starting day.

**Not adopted, and not discarded either.** A t of 1.6–1.9 over five and a half years is what a modest real effect *and* noise both look like; the window is too short to separate them. It is the second natural candidate for a one-shot test of the reserved 2025–2026 period, after §49's residual reversal at k = 5, and it is written down here before anyone has seen that data. Testing both would need a Bonferroni α/2.

#### Two errors in the book's Ch. 8

- **The 52-week rule's direction**, above.
- **Its January-effect test uses the wrong test.** It runs `scipy.stats.bartlett` on January against other months, then reads the result as a **T-value** and concludes "no January effect". Bartlett's test compares **variances**. The January effect is a claim about **mean** returns.

A mean test isn't worth running here either: the window holds six Januaries. With a monthly standard deviation around 6%, a January mean has a standard error near 2.4%, so nothing a calendar effect could plausibly be would be detectable.

#### The rest of the book

| Ch. | Topic | Status here |
|---|---|---|
| 1–7 | Python, modules, NumPy, SciPy, matplotlib; NPV, IRR, annuities | Tooling the project already uses; corporate-finance calculators don't apply |
| 8 | Roll spread, Amihud illiquidity | `microstructure.py` ([§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement)) |
| 8 | Pástor–Stambaugh liquidity | A market-wide factor; per stock the regression is too noisy, which is why its authors average it across the market |
| 8 | Fama-French three-factor; Fama-MacBeth | No Indian factor data in the project; Fama-MacBeth is `strategy_metrics.fama_macbeth_ic` |
| 8 | Rolling beta; efficient frontier; VaR | The beta-weighted market link is §19's R²; portfolio optimisation was declined before; VaR is [§24](#24-value-at-risk-estimation-and-var-backtesting) |
| 9–10 | Black-Scholes-Merton, Greeks, CRR trees, implied volatility, put-call ratio | No option chain ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)) |
| 11 | Monte Carlo, bootstrap, geometric vs arithmetic mean | The simulated cones, `var_models`' block bootstrap, and [§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code) |
| 12 | Normality and fat-tail tests, lower partial SD, Breusch–Pagan, ARCH, GARCH, GJR | Semideviation in the risk panel; `run_vol_comparison.py` compares the GARCH family |

---
### 54. Monte Carlo noise in the cone (Hilpisch, *Python for Finance*, Ch. 12) — variance reduction is for means, not tails

*Python for Finance* is the fourth Hilpisch book reviewed here, and most of it has been covered already:

| Chapters | Covered by |
|---|---|
| Ch. 15–16: SMA strategies, ML strategies, Kelly and leverage | *Python for Algorithmic Trading* Ch. 4, 5 and 10, which became [§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting) |
| Ch. 14: the FXCM API | §52's triage |
| Ch. 17–20: the DX derivatives library (risk-neutral valuation, jump diffusion, least-squares Monte Carlo) | Needs an option chain ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)) |
| Ch. 1–9: Python, NumPy, pandas, plotting, I/O | Tooling the project already uses |

The material that is new is in Ch. 10, 12, 13 and 15.

#### The cone's Monte Carlo noise, measured

The ARIMA/ARIMAX + GARCH models build their 95% cone from the 2.5th and 97.5th percentiles of `model_utils.simulate_price_paths`, at `N_SIMS = 5,000` paths. Ch. 12 shows two standard variance-reduction tricks on the **mean** of a simulated sample:
- **antithetic variates:** use z and −z;
- **moment matching:** rescale the draws to mean 0, sd 1 exactly.

The cone reads **quantiles**, so `run_mc_variance_reduction.py` measures what actually matters: how far the 2.5% edge moves between seeds, as a share of the band's half-width, over 2,000 seeds per cell.

| Draws | Paths | Plain | Antithetic | Moment-matched |
|---|---|---|---|---|
| Normal | 1,000 | 4.22% | 4.18% | 3.25% |
| Normal | **5,000** | **1.96%** | 1.87% | 1.44% |
| Normal | 20,000 | 0.94% | 0.95% | 0.75% |
| Student-t(4) | 1,000 | 7.04% | 6.85% | 6.31% |
| Student-t(4) | **5,000** | **3.05%** | 3.08% | **3.21%** |
| Student-t(4) | 20,000 | 1.58% | 1.54% | **1.88%** |

- **At the app's 5,000 paths the edge moves by 2–3% of the half-width.** That's an order of magnitude below what decides coverage, which is the model (the confidence badge accepts coverage anywhere in 0.85–0.99). And the seed is fixed (42), so any one forecast is reproducible. *(True only since [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found). `np.random.seed(42)` never reached `arch`: it draws simulation shocks from the fitted distribution's own generator, so two identical ARIMA/ARIMAX runs gave different bands. `simulate_price_paths` now reseeds that generator; `test_garch_cone_is_reproducible_across_runs`.)*
- **Antithetic variates do nothing for a tail quantile.** Mirroring z to −z doesn't change how many draws land in the 2.5% tail. It's a tool for means.
- **Moment matching makes fat-tailed quantiles worse.** It helps with normal draws, but with t(4) draws it raises the noise (3.05% → 3.21% at 5,000; 1.58% → 1.88% at 20,000). Rescaling by the sample standard deviation injects that estimate's own noise, which is large when tails are heavy. Equity returns are fat-tailed, so the trick that improves the book's example would make the cone noisier.
- **One fix.** `simulate_price_paths`' last-resort fallback simulated only **1,000** paths, which has twice the edge noise. It now uses `N_SIMS`, like the main branch.

#### Ch. 15's narrative contradicts its own output

The sequential and randomized train/test split comparison (pp. 509–511) is worth recording, because the text and the printed numbers disagree twice:

| | Text says | Output shows |
|---|---|---|
| Sequential split | "only the GNB and LR algorithms achieve a positive absolute performance" | LR **0.963**, GNB **0.941**: both losses. The only strategy above 1.0 is SVM at 1.049 |
| Randomized split | "the SVM algorithm shows again the best performance out-of-sample" | SVM **0.695**, the **worst** row: below buy & hold (0.878) and both other models |

A result read off a chart rather than off its numbers is how a narrative drifts from the evidence. It's also why every driver in this project prints the numbers its conclusions quote. The randomized split itself is the shuffled-split leakage [§6](#6-avoiding-data-leakage-look-ahead-bias)'s purged walk-forward exists to prevent.

#### The rest of the new material

| Ch. | Topic | Status here |
|---|---|---|
| 10 | Numba, Cython, multiprocessing | Run time here is spent fitting models (TensorFlow, gradient boosting, `arch`), not in Python loops, so compiling loops wouldn't move it |
| 12 | VaR by simulation, credit valuation adjustment | VaR is [§24](#24-value-at-risk-estimation-and-var-backtesting); there are no counterparties to adjust for |
| 13 | Normality tests | Declined in [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed) for the same reason: the project is built on non-normality rather than assuming it |
| 13 | Portfolio optimisation | Declined before, for want of an edge to allocate |
| 13 | Bayesian regression updated over time (GLD on GDX) | A pairs relationship; pairs trading was declined. The Bayesian-reading point is [§51](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4) |
| 13 | k-means; supervised classifiers | The model zoo |
| 15 | Random-walk hypothesis (regress price on its lags) | The baseline every model here is tested against |

---
### 55. Cost of trade (Kanwar & Gupta, *Python for Trading on Technical*) — futures don't rescue reversal, and a train/serve skew in shipped code

Kanwar & Gupta's *Python for Trading on Technical* is a short TA-Lib cookbook. A quarter of its 135 pages are images (code screenshots, charts and results tables); the ones that matter (the setup and results on pp. 122–125 and 131) were rendered and read, not just text-extracted. It covers:
- indicator recipes;
- candlestick pattern recognition;
- one SMA × RSI trading setup;
- a page on the cost of trading in India.

That last page is the useful one. Following it up also turned up an error in shipped code that had nothing to do with the book.

#### An itemised cost schedule

Every cost verdict here ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39), [§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting), [§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it)) rested on one assumed figure, "~20 bp of STT". `strategy_metrics.india_round_trip_bps(segment, as_of=None)` now itemises the statutory charges by segment, from a **dated** schedule (`INDIA_CHARGES_HISTORY`), so a backtest is charged the rate in force at the time. Today's schedule:

| Round trip, bp | STT | Stamp | Exchange | SEBI | GST | **Total** |
|---|---|---|---|---|---|---|
| Cash delivery | 20.00 | 1.50 | 0.59 | 0.02 | 0.11 | **22.22** |
| Intraday | 2.50 | 0.30 | 0.59 | 0.02 | 0.11 | **3.53** |
| Stock futures | 5.00 | 0.20 | 0.35 | 0.02 | 0.07 | **5.63** |

Futures STT, the term that moves, by date:

| From | Futures STT (sell side) | Futures round trip |
|---|---|---|
| before 1 Apr 2023 | 0.01% | 1.67 bp |
| 1 Apr 2023 | 0.0125% | 1.92 bp |
| 1 Oct 2024 | 0.02% | 2.63 bp |
| **1 Apr 2026** (Budget 2026) | **0.05%** | **5.63 bp** |

Brokerage is a separate argument (GST applies to it). Spread, impact and depository charges aren't included. NSE's transaction fees also changed on 1 October 2024 (cash 0.00322% → 0.00297%, futures 0.00188% → 0.00173%). Stamp duty has been uniform since July 2020; earlier dates use the uniform rates.

**The rates were verified, after a first version got one wrong.** The first version of this schedule was written from memory as "the schedule in force from 1 October 2024". Checked against exchange and broker notices in October 2026, it had missed Budget 2026's rise in futures STT from 0.02% to 0.05% on 1 April 2026, so it understated a futures round trip by more than half. Sources: [Zerodha, revision in transaction charges from 1 Oct 2024](https://zerodha.com/marketintel/bulletin/391488/revision-in-transactions-charges-from-1st-october-2024), [Business Standard on the October 2024 STT change](https://www.business-standard.com/markets/news/higher-stt-and-transaction-charges-on-nse-bse-mcx-effective-today-124100100146_1.html), [Outlook Money on the April 2026 STT rise](https://www.outlookmoney.com/invest/stt-hike-from-april-1-2026-budget-what-it-means-for-futures-and-options-traders), and [Zerodha on uniform stamp duty from July 2020](https://zerodha.com/marketintel/bulletin/259741/uniform-stamp-duty-applicable-from-july-1-2020). The rates are statutory and change with budgets, so re-verify after the next one.

The book's "10 times more costly" was right when it was written: delivery cost about **13×** a futures round trip at the 2019–2023 rates. The 2026 futures STT rise has narrowed that to about **4×**. The 20 bp the earlier sections used for delivery is the right floor.

**The book's own arithmetic is off by two orders of magnitude.** It itemises futures charges per crore: STT ₹500 each side, stamp ₹100 each side, exchange ₹200, SEBI ₹15, GST on the exchange fee. That sums to ~₹1,700, i.e. **0.017%**, or 1.7 bp. The text calls it "approx .0002%" and charges "0.0001% on each side", while its code multiplies by `0.0001`, which is 0.01% per side. Text and code disagree with each other, and the text disagrees with its own sum. `test_india_costs_reproduce_the_books_futures_arithmetic` pins the 1.7 bp.

#### Does trading through futures rescue reversal?

The book's point was never tested here: through single-stock futures the same position costs a fraction of delivery, and a future is also the only way to be short overnight, which was §39's other constraint. §49's residual reversal (k = 5) breaks even at 15.2 bp. That's below delivery's 22.2 bp, but far above futures' statutory cost (1.7–2.6 bp during the backtest window, 5.6 bp today).

First, the right universe. §39 used **today's** F&O list and called it an upper bound, "since the list was narrower historically". That was untested and is wrong. `bhavcopy.fno_members` now reads the exchange's own F&O bhavcopy on the first trading day of every month (legacy archive, cached, holdout-guarded), so the list is the one that existed then. It includes names since removed, such as `ALBK`, merged away in 2020:

| | Jan 2018 | Jan 2019 | Jan 2020 | Jan 2021 | Jan 2022 | Jan 2024 |
|---|---|---|---|---|---|---|
| Stocks with futures | 211 | 200 | 144 | 140 | 197 | 183 |

The segment **shrank** after SEBI tightened eligibility in 2018–19, and then grew back. Of the 339-name panel, 129–210 names had futures in any given month, median 147; today's list gives 131. So today's list understated eligibility rather than bounding it.

`run_futures_reversal.py` re-runs the **pre-registered** k = 5 signal, unchanged:
- factors are estimated on the full panel;
- the book ranks and trades only that month's F&O names;
- it is averaged over all five starting days.

| | Full universe (§49) | **F&O names, point-in-time** |
|---|---|---|
| Rank IC | −0.0335 (t −8.08) | **−0.0144** (t −2.57) |
| Gross per rebalance | +0.263% | **+0.091%** (−0.07% … +0.21%) |
| Turnover | 3.47 | 3.51 |
| Breakeven, round trip | 15.2 bp | **5.2 bp** |
| Net t, futures at the rate in force (1.7–2.6 bp) | — | median +0.21 |
| Same, + 2 bp spread | — | median −0.01 |
| Net t, futures at today's rate (5.6 bp) | — | median −0.21 |
| Same, + 2 bp spread | — | median −0.42 |
| Net t, cash delivery (22.2 bp) | — | median −1.98 |

**Futures don't rescue it, and the reason sharpens §39.** The signal lives mostly in the names **without** futures, the smaller and less liquid ones. On the names you can short and trade cheaply it's less than half as strong, and it breaks even at 5.2 bp. At the rates in force during 2018–2024 that cleared the statutory charges by about 3 bp, which a realistic spread on a stock future all but wipes out. At today's rate the statutory charges alone (5.6 bp) exceed the breakeven. The anomaly sits where trading is hard, which is the usual pattern for short-horizon reversal. §49 and §39 now carry a note.

#### A train/serve skew in shipped code

Checking how the models read their features turned up a real error. `direct_forecast.compute_origin_row` builds the forecast-origin row with `ML_model._features_from_buffers`, which saw only prices and volumes. So at the origin:
- `atr_norm` and `range_pct` were close-to-close proxies;
- every training row (`create_features`) used high/low true range.

This affects XGBoost/LightGBM, the Ensemble and the Quantile model. Measured on 200 NSE daily origins for each of RELIANCE, TCS and INFY:

| Feature | Training (median) | Served at the origin, before | After the fix |
|---|---|---|---|
| `atr_norm` | 0.0218 | **0.0118 (−46%)** | 0.0218 |
| `range_pct` | 0.0193 | 0.0231 (+20%; up to 5.5 points off on a day) | exact |

Every forecast handed the tree models an ATR near the bottom of their training range: the present always looked unusually calm. The intraday parity test, whose docstring calls train/serve skew "the project's highest silent-bug risk", checked six intraday columns and nothing else, so this sat outside it.

- **Fix:** `_features_from_buffers` accepts `highs`, `lows` and `closes` and computes true range exactly as training does, and `compute_origin_row` passes them. The close-to-close proxy remains only for frames with no OHLC, matching `create_features`' own fallback.
- **New tests:** `test_every_feature_matches_between_training_and_serving` pins **all** feature columns, not six. EWM-based features carry a stated tolerance for the 80-bar warm-up (RSI differs by at most 0.18 points). It also fails if a feature is ever computed in training but not at serve time.
- **What it was worth:** `run_origin_skew.py` trains the 5-day XGBoost model at 20 origins per name and predicts from both rows. The forecasts moved by **1%, 3% and 9%** of their own size (RELIANCE, TCS, INFY), with **no sign flips in 60**. The models lean little on ATR at the origin, so this is a correctness fix rather than a performance one. The published backtests and verdicts stand.

**A duplicate feature, removed.** `bb_position` was `(p − MA20) / (2σ20)` and `price_zscore` was `(p − MA20) / σ20`: exactly one half of the other, correlation 1.0. Any Bollinger position is a linear function of the z-score, so no version adds information. With `colsample_bytree=0.8`, the duplicate doubled that signal's share of each tree's column draws and split its attribution across two names. It's gone from both paths.

**What removing it did, measured** (`run_bb_position_removal.py`). The 5-day model was trained at 60 origins (3 names × 20) three ways: as shipped now, with `bb_position` put back, and as shipped now with a different random seed, which is the control.

| Engine | Mean forecast | Change from removal | Change from re-seeding only | RMSE now / before | Direction flips |
|---|---|---|---|---|---|
| LightGBM | 0.552% | 0.180% | 0.167% | 3.495% / 3.521% | 2 of 60 |
| XGBoost | 0.605% | 0.144% | 0.174% | 3.625% / 3.559% | 1 of 60 |

**The removal moved forecasts no more than changing the random seed does,** and accuracy moved by noise in both directions. It's a cleanliness change, not an accuracy one. Nothing else reads the column: no other module, no test, and no persisted model, since every forecast refits. [§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction)'s drift and attribution figures were measured on the 26-feature set and stay as recorded.

#### The book's indicators and its setup

`run_kanwar_setup.py`. The indicators the book adds, against the existing features (largest |Spearman| with any of them, median over 8 names):

| Indicator | Overlap | Nearest existing feature |
|---|---|---|
| CCI (14) | **0.93** | `price_zscore` |
| Slow Stochastic (5, 3, 3) | 0.87 | `log_return_5` |
| Stochastic RSI (14, 5, 3) | 0.87 | `ma_ratio_5` |
| Balance of Power, 9-day SMA | 0.72 | `log_return_10` |
| OBV, 20-day change | 0.72 | `macd_norm` |
| Chaikin A/D oscillator (6, 20) | **0.63** | `rsi_14` |

*(Corrected. The first version of this table used hand-written indicators with other periods: CCI 20, fast %K 14, ADOSC 3/10, unsmoothed BOP. It reported 0.72–0.98. These figures use the book's own TA-Lib calls and periods, pp. 87–108.)*

None is added. CCI and both Stochastics are near-copies of existing features. Balance of Power, OBV and especially Chaikin (0.63) are only partly redundant, so for them the reason not to add is the other one: a new feature is another trial against a model zoo with no edge ([§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39)). OBV is a running level whose value depends on the start date, so only its change is defined as a feature at all. Candlestick patterns were tested separately, below.

The setup (pp. 128–130) goes long when the close is above SMA(a) and RSI(b) > 50, with a ∈ {20, 40, …, 200} × b ∈ {14, 21}. It runs on the book's NSE names and reads off the best. NESTLEIND isn't in the liquidity-screened panel, so 7 of its 8 names were tested. Charged at **cash delivery**, because the setup is long-only:

| | Result |
|---|---|
| The book's method: best of 20, full period, net | +149%, against buy & hold's **+192%**. It loses even in-sample |
| Pooled PBO | **0.79**: the in-sample winner usually ranks below the median out of sample |
| Optimise on the first half, trade the second | Net Sharpe +1.23 → **+0.45**, against buy & hold's +1.00. Beats it on 14% of names |
| Picks | Seven names, seven different (SMA, RSI) pairs |

#### The indicator chapters' own trading rules

The indicator chapters each end with a small trading rule shown on INFY 2018–20. These were missed on the first pass: two of them sit on image pages (95 and 100), which the text extractor can't read.

| Rule | As the book states it |
|---|---|
| MACD (pp. 92–95) | Long while MACD(12, 26, 9) is above its signal line. Book: "26 trades … return from each trade approximately −5% to 20%" |
| Balance of Power (pp. 96–97) | Buy when BOP crosses above zero, sell below. Taken on the 9-day-smoothed line the book computes and plots |
| Stochastic (pp. 98–100) | Buy when slowk crosses above slowd with slowd < 20; sell on the reverse cross with slowd > 80 |

`run_kanwar_indicator_rules.py` first reproduces the book's own number: the MACD rule gives **24 trades on INFY over 2018–2020, against the book's 26**. The book used Yahoo's unadjusted file over a slightly different range; this uses adjusted exchange bars. So it's the same rule, not a byte-for-byte replication.

Each rule then runs unchanged (no parameters searched, so no PBO) on the 50 most liquid names, survivorship-free, 2018–2024, long-only as in the book, at cash-delivery cost. A rule that sits out part of the time trails buy & hold in a rising market for that reason alone. So the column that matters is the **timing return**: the rule's net return minus buy & hold held for the same share of days.

| Rule | In market | Trades / yr | Net total | Buy & hold | Net Sharpe | B&H Sharpe | Beats B&H | Timing / yr (t) | Timing / yr without Feb–Jun 2020 (t) |
|---|---|---|---|---|---|---|---|---|---|
| MACD | 51% | 9.5 | +66% | +116% | +0.48 | +0.59 | 44% | **+2.3% (+2.41)** | **−0.9% (+0.77)** |
| BOP | 40% | 18.8 | +19% | +116% | +0.24 | +0.59 | 17% | −2.5% (+0.09) | −3.8% (−0.58) |
| Stochastic | 46% | 4.1 | +32% | +116% | +0.31 | +0.59 | 23% | −0.4% (−0.91) | +0.8% (+0.31) |

**MACD's timing edge is one episode.** As a trend-exit rule it was out of the market for much of the COVID crash. Remove February–June 2020 and its timing return turns negative. Balance of Power and the Stochastic rule pick their days no better than chance. None of the three beats buy & hold on more than 44% of names. (Names are correlated, so the cross-name t overstates whatever evidence it shows.)

#### Candlestick patterns, tested

Section 5 of the book computes five TA-Lib patterns (Marubozu, Morning Star, Evening Star, Hammer, Inverted Hammer) and plots where they fire on INFY 2018–20. It never asks whether a signal is followed by the move it names.

`run_candlesticks.py` is that event study:
- **Data:** the 400-name survivorship-free panel, 2018–2024, using the book's own TA-Lib functions on corporate-action-adjusted OHLC.
- **Direction:** each pattern's own sign (+100 bullish, −100 bearish).
- **Outcome:** the next 5 sessions' excess return over the equal-weighted universe.
- **Statistic:** Newey-West t on the per-date mean, against a Bonferroni bar of |t| > 2.58 for five patterns.

TA-Lib is a **validation-only** dependency (`pip install TA-Lib`); the driver says so and exits if it's missing, and the app doesn't import it.

| Pattern | Events | 5-day signed excess | t | 1-day | t |
|---|---|---|---|---|---|
| Marubozu (72% bearish) | 11,156 | +0.54% | **+6.51** | +0.33% | +9.97 |
| Morning Star | 2,132 | +0.08% | +0.48 | +0.02% | +0.27 |
| Evening Star | 3,865 | +0.35% | +2.66 | +0.21% | +3.86 |
| Hammer | 6,833 | +0.08% | +0.62 | +0.08% | +1.08 |
| Inverted Hammer | 4,854 | **−0.48%** (wrong way) | −3.10 | −0.39% | −7.33 |

A daily-bar pattern with a 1-day t of 10 is far more likely to be microstructure than an edge. A Marubozu opens at one extreme and closes at the other, which is exactly what an NSE **price-band (circuit) lock** looks like, and a locked close has no counterparty. So three diagnostics were added **after** seeing the table:
1. enter at the next day's **open**;
2. drop bars that closed at an extreme **and** moved by a price-band amount (2/5/10/20%);
3. keep only the more liquid half.

| Pattern | Locked bars | Next-open entry | No locked bars | Liquid half |
|---|---|---|---|---|
| Marubozu | 8% | +0.25% (t 3.08) | +0.33% (t 4.23) | +0.17% (t 1.90) |
| Evening Star | 1% | +0.24% (t 1.78) | +0.28% (t 2.12) | +0.27% (t 1.65) |
| Inverted Hammer | 6% | **−0.04% (t −0.29)** | −0.24% (t −1.68) | −0.38% (t −1.78) |

- **Inverted Hammer's "wrong-way" result is a closing-price artefact.** It disappears entirely once the trade starts at the next open.
- **Evening Star** falls below the bar.
- **Marubozu is the one robust effect:** continuation after a bar that closes at its extreme. Half of it happens overnight, before anyone could act on the signal, and it's concentrated in illiquid names. Entered at the next open it's +0.25% per 5-day trade, about **+2 bp** after cash delivery's 22.2 bp. In the liquid half it's +0.17% gross even with the untradeable close entry, which is below the delivery cost.

**No pattern is a usable signal.** The book shows them firing and leaves the impression that they work; the one that measurably does is mostly a move you can't reach.

**The text states a different rule from the one the code runs.** The book's rules list (p. 123, an image page) says "Buy when 21 days RSI is above 70% and cover your long position if RSI goes below 50%": an entry/exit band. Its code uses RSI > 50 both ways, which is what the grid above includes (SMA200/RSI21). Tested as a single rule, the stated version does worse: **+37%** over the full period against buy & hold's +192%, in the market 21% of days, and a second-half net Sharpe of +0.09 against +1.00. It beats holding on **none** of the 7 names.

**The book's results table can't show the strategy works.** `Percent_Return` (p. 125) is price points earned divided by the **final** price, which isn't a return on any capital. The table has no buy-and-hold row: by the same metric, holding RELIANCE from 2010 to 2021 earned more than the strategy's 62%.

It's the same result as §52's rules, with a higher PBO. The book's code charges futures-like costs (0.01% a side, ~2 bp a round trip) on a long-only stock strategy; at the delivery cost that strategy actually pays, it doesn't beat holding.

---
### 56. Long memory and wavelets (Mariani & Florescu, *Quantitative Finance*, Ch. 5, 12–13) — persistence that is the estimator's, and a forecast that is the future

Mariani & Florescu's *Quantitative Finance* is mostly derivatives pricing:
- Black-Scholes, Heston, SABR and CIR;
- PDE methods, trees and finite differences;
- Monte Carlo for American options;
- bond markets, ETFs, CDS and CDOs.

None of that applies to a project with no option chain ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)). Its empirical, data-facing chapters are three: rescaled-range and detrended fluctuation analysis (Ch. 12–13), wavelets (Ch. 5), and factor and copula models (Ch. 16). The first two make claims this project can measure.

#### The claims

- **Persistence enables prediction.** Ch. 12.5 estimates a Hurst exponent H by rescaled-range (R/S) analysis. It reads H between 0.5 and 1 as persistence that "enables prediction of any time series as it shows a trend" (p. 334).
- **Distance from 0.5 warns of a crash.** Ch. 13.4 adds a DFA exponent α and states (p. 357): "we compare with 0.5. The further these parameters are from 0.5, the stronger the evidence of a crash event waiting to happen." Its tables report H of 0.56–0.70 and α of 0.57–0.83 on tick data around crash weeks.

#### New: `long_memory.py`

The book's two procedures as written, and the corrections the literature added:

| Function | What it does |
|---|---|
| `rs_hurst(x, corrected=False)` | The book's R/S slope (pp. 332–334). `corrected=True` regresses on the excess over the **Anis–Lloyd–Peters** expected R/S, so independent data reads 0.5 |
| `lo_modified_rs(x)` | **Lo's (1991)** modified R/S: a Newey-West standard deviation absorbs short-range dependence, so only long memory moves it. 95% band [0.809, 1.862] under the null |
| `dfa(x, abs_input=False)` | Order-1 DFA. `abs_input=True` integrates \|returns\| as the book does (p. 334), which measures memory in **volatility**; the default integrates the demeaned series |
| `fgn(n, H)` | Exact fractional Gaussian noise (Davies–Harte), so the estimators can be checked on a series whose H is known |

Calibrated on synthetic series before touching data:

| Series | Book R/S | Corrected R/S | DFA | Lo rejects |
|---|---|---|---|---|
| Independent noise, N = 1,000 | **0.567** | 0.482 | 0.501 | 7.0% (size) |
| fGn, H = 0.7 | — | 0.628 | **0.681** | — |
| fGn, H = 0.8 | — | — | — | 74% (power) |
| AR(1), φ = 0.6 (short memory only) | **0.679** | 0.606 | 0.646 | **6.7%** |
| Random-walk levels | — | — | 1.494 (theory 1.5) | — |

Two of these rows matter.
- **Independent noise reads 0.567 on the book's estimator.** That's the same range as its "long memory" tick-data results.
- **A series with only short memory reads 0.679,** and even DFA is fooled at these scales. Lo's test is the one that tells the two apart: it rejects at its nominal rate on the AR(1).

DFA recovers a known H accurately, while the corrected R/S underestimates high H, a known property. Eight tests pin all of this (`test_long_memory.py`), including the book's upward bias on independent data and the AR(1) case.

#### On NSE returns (`run_long_memory.py`, 183 names, 2018–2024)

| Median across names | On returns | On the same returns, **shuffled** |
|---|---|---|
| Book R/S Hurst | **0.566** | **0.561** |
| Corrected H | 0.489 | — |
| Standard DFA of returns | 0.514 | — |
| Book DFA of \|returns\| | **0.713** | 0.502 |

Shuffling keeps each name's return distribution and destroys every kind of memory, so the shuffled column is the real "0.5" to compare with.
- **The "persistence" in returns is the estimator's.** The book's R/S reads 0.566 on the data and 0.561 with all memory destroyed. Corrected, H is 0.489, and Lo's test rejects "no long memory" for 10% of names against 5% by chance. There is no long-memory structure in daily returns to forecast from, which is what the random-walk baseline every model here is tested against assumes.
- **The memory in volatility is real.** DFA of \|returns\| reads 0.713 against 0.502 shuffled. That is the volatility persistence HAR-RV is built on, and it says nothing about direction. The book's "persistence … enables prediction" conflates the two, because its DFA integrates \|returns\|.

#### The crash-warning claim, pre-specified

Every 21 sessions, for each name with a full trailing year, compute the book's \|H − 0.5\| (R/S) and \|α − 0.5\| (DFA of \|returns\|). The outcome is the worst drawdown over the next 21 sessions. Rank IC by date and Fama-MacBeth t over 64 non-overlapping months, then the same controlling for trailing 60-day volatility. The bar, fixed in advance, is positive and Bonferroni |t| > 2.24 beyond volatility.

| Signal | Rank IC | t | Beyond 60-day vol | t | **Beyond all risk controls** (post-hoc) | t |
|---|---|---|---|---|---|---|
| \|H − 0.5\|, book R/S | +0.104 | +5.58 | +0.029 | **+2.41** (pass) | +0.010 | **+0.97** |
| \|α − 0.5\|, book DFA \|r\| | +0.104 | +6.55 | +0.028 | **+3.15** (pass) | +0.021 | **+2.12** |
| Trailing 60-day volatility, for scale | +0.474 | +26.56 | — | — | — | — |

Both signals passed the pre-set bar. A pass against one control isn't a finding, though, because a one-year exponent can be another risk measure in disguise. So, labelled as diagnostics added afterwards, both were re-run beyond 60- and 250-day volatility, volatility of volatility, the past year's return and the past year's drawdown.
- **The R/S signal disappears** (t 0.97): what it knew was volatility and trend.
- **The DFA signal survives, barely** (t 2.12, above 2 but now below the pre-set 2.24), at one twentieth of trailing volatility's predictive strength. That fits volatility persistence: when volatility shocks die out slowly, a rough month tends to be followed by another.

So the book's crash claim holds **weakly, for DFA only**, and as a statement about volatility rather than about crashes "waiting to happen".

**Does the DFA exponent improve the app's volatility forecast? No.** The app's downside numbers come from HAR-RV, which already models volatility persistence at day, week and month scales. So the question that decides whether α belongs in the product is whether it adds anything to HAR-RV's own forecast. `run_har_dfa.py` tests that, pre-specified:
- 97 liquid names, an origin every 21 sessions;
- HAR-RV fitted exactly as the app does (`fit_har` and `forecast_har_variance` on the trailing 1,000 sessions) for the next 21 sessions' variance;
- an expanding-window, out-of-sample recalibration with and without α, both with an intercept and a slope on HAR's forecast;
- scored by QLIKE, the robust loss for variance forecasts, with Diebold-Mariano across origins.

| 40 out-of-sample origins, 4,837 forecasts | Mean QLIKE (lower is better) |
|---|---|
| **HAR-RV's own forecast, as shipped** | **0.2831** |
| HAR-RV recalibrated (pooled, expanding window) | 0.3276 |
| + DFA α | 0.3396: **3.7% worse**, DM t −1.67 |

α makes the forecast slightly worse, and its fitted coefficient swings from −2.46 to +0.42 between fits. It's better on only 40% of origins. The second finding is a small, independent confirmation of the shipped model: HAR-RV's own per-name level correction (`har_level_offset`) beats a pooled re-fit, so there's nothing to recalibrate either. Not adopted, and the question is closed.

#### Wavelet forecasting: the leak, measured

Ch. 5 teaches the discrete wavelet transform (Haar, Daubechies) and cites wavelet forecasting as "a viable alternative to existing methods such as ARIMA" (p. 117), without implementing one. The usual recipe denoises a price series with a wavelet transform and forecasts from the smooth.

A transform of the **whole** series makes every denoised value depend on neighbours on both sides, so the smooth at day t has already seen t+1. `run_wavelet_leak.py` runs one simple rule two ways on the same data: predict tomorrow's direction from the sign of the denoised log price's slope. The denoising is Haar, 4 levels, translation-invariant (cycle-spun), with a soft universal threshold.

| 19 liquid names, 24,436 forecasts | Hit rate | t vs 50% |
|---|---|---|
| Non-causal: denoise the whole series once | **61.8%** | **+36.9** |
| Causal: denoise only the trailing 256 days at each date | **50.1%** | +0.26 |

**All 12 points of "skill" are the future leaking in.** This is the leak [§6](#6-avoiding-data-leakage-look-ahead-bias) exists to prevent, at a size that would survive any significance test you ran on it.

*(A first version of this driver reported hit rates of 2% and 14%. Thresholded Haar reconstructs a staircase that is flat inside each 16-day block, so its slope was exactly zero on most days, and those zeros were scored as misses. Cycle spinning removes the staircase, and only non-zero calls are scored. It was an artefact of the test, caught because no direction rule can be 98% wrong.)*

#### The rest of the book

| Ch. | Topic | Status here |
|---|---|---|
| 1, 9 | Stochastic processes, SDEs, Itô, Euler | Background to the simulated cones |
| 2–4, 6–7 | Black-Scholes, Heston, SABR, CIR, PDEs, trees, finite differences, American options | Need an option chain ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)) |
| 8 | Monte Carlo, variance reduction, importance sampling | Variance reduction for the cone's quantiles was [§54](#54-monte-carlo-noise-in-the-cone-hilpisch-python-for-finance-ch-12--variance-reduction-is-for-means-not-tails) |
| 10–11 | Stochastic volatility; jump diffusion | HAR-RV and GARCH model the volatility; the conformal cone takes its tails from realised errors rather than an assumed jump law |
| 13 | Lévy-flight (truncated Lévy) parameter | A truncated Lévy flight has finite variance by construction, so it doesn't contradict the variance-based tools here, and a single-stock app has no use for its fitted α |
| 14–15 | Integro-differential pricing; transaction costs in option pricing | Derivatives |
| 16 | Factor and copula models | Factors were [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39); copulas model joint tails across assets, a portfolio question this single-stock app doesn't ask |
| 17–18 | Bonds, ETFs, CDS, MBS, CDOs | Different instruments |

---
### 57. Synthetic returns (Hilpisch, *Reinforcement Learning for Finance*, Ch. 5) — a test that a shuffle passes, and what the project's own generators keep

Hilpisch's *Reinforcement Learning for Finance* teaches deep Q-learning and applies it to trading, hedging, asset allocation and execution. Reinforcement learning was triaged out in [§26](#26-book-coverage-what-was-taken-what-was-left-and-why) and declined in every review since, for one reason: an RL agent optimises a **directional** policy, and [§15](#15-data-snooping-robust-model-selection-reality-check--spa) and [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) say there's no directional edge to learn.

The book's own Ch. 3 says much the same in "Where the Analogy Fails". Financial data is limited (one historical path), and an agent's actions have no impact on the market. Its Part II answers the limited-data problem by **generating** more: Monte Carlo simulation (Ch. 4) and GANs (Ch. 5). That part makes a claim this project can test, and it bears on generators the project already ships.

#### The claim, and why the test can't support it

Ch. 5 trains a GAN on log returns and validates it with a Kolmogorov–Smirnov test: all 25 synthetic samples pass at 5%. It concludes that GANs give "synthetic data sets that have all the qualities of the original data set" (p. 80).

KS compares the **marginal** distribution of one-day returns and nothing else. It can't see anything that lives in the **order** of the returns, above all volatility clustering, which is what makes multi-day risk fat-tailed. A shuffled copy of the real series has exactly the real marginal and no time structure, and it passes KS perfectly. KS is also least sensitive in the tails, where its CDF-distance statistic is smallest and where risk lives.

#### New: `synthetic_check.py`

`compare_paths(real, synth)` reports the chapter's KS test, plus four stylized facts it can't see, each as a ratio of synthetic to real:
- volatility clustering: the mean autocorrelation of |r| over lags 1–20;
- the 1% tail;
- the leverage effect;
- the excess kurtosis of 20-period sums.

`stationary_bootstrap_path` produces a path from the same scheme `var_models` uses. `ks_2samp` is pure numpy: D matches SciPy exactly and the p-value matches to 0.01.

A first version returned p = 0 for identical samples, because the alternating Kolmogorov series sums to zero at λ = 0. It now uses the complementary form for small λ. Seven tests pin the module, the central one being that **a shuffle of a clustered series passes KS and is still flagged**.

#### On NSE (`run_synthetic_check.py`, 5 liquid names, 2018–2024)

| Generator (5 seeded paths per name, GAN 1; medians) | Passes KS | Clustering kept | 1% tail | 20-day-sum kurtosis kept | Matches every fact |
|---|---|---|---|---|---|
| Shuffle (the real returns, reordered) | **100%** | **−0.02** | 1.00 | 0.06 | 0% |
| Gaussian | 0% | 0.01 | 0.92 | −0.02 | 0% |
| **GAN** (`var_models`' optional generator, as the chapter's) | 40% | −0.03 | 0.87 | 0.05 | 0% |
| **Block bootstrap** (`var_models`' default, mean block 5) | **96%** | **0.20** | 1.00 | **0.12** | 0% |
| GARCH(1,1)-t, fitted and simulated | 100% | 0.45 | 1.00 | 0.44 | 16% |

*(Corrected after a cross-check. The first published table used one simulated path per name, and its GARCH row came from an **unseeded** simulator: three runs gave GARCH clustering of 0.40, 0.47 and 0.35, and the bootstrap's 0.35 / 0.33 was one lucky draw. The driver now seeds `arch`'s Student-t draws and takes the median of 5 paths per name; two runs are identical. The conclusions didn't change, but the bootstrap's shortfall is larger than first reported.)*

- **The chapter's test is blind exactly where expected.** The shuffle passes KS on every name while keeping none of the volatility clustering.
- **The project's GAN** reproduces none of the time structure, because it maps independent noise to returns one day at a time. Its 1% tail is also 13% too thin. That matches the doubts `var_models` already recorded about it, now measured.
- **The project's default block bootstrap was described wrongly.** Its docstring said it "preserves the local volatility clustering and autocorrelation structure". It keeps about **a fifth** of the clustering (0.20), and less of the fat tails of 20-day sums. A mean block of 5 days is far shorter than the volatility memory DFA measured in [§56](#56-long-memory-and-wavelets-mariani--florescu-quantitative-finance-ch-5-1213--persistence-that-is-the-estimators-and-a-forecast-that-is-the-future).
- **GARCH(1,1) keeps more (0.45), and still under half of the clustering.** Its exponential decay can't follow the slow, near-hyperbolic decay of volatility memory.

The block length controls how much is kept:

| Mean block | 5 | 10 | 20 | 40 | 80 |
|---|---|---|---|---|---|
| Clustering kept | 0.21 | 0.28 | 0.56 | 0.58 | 0.90 |
| 20-day-sum kurtosis kept | 0.26 | 0.38 | 0.52 | **0.85** | 0.76 |

#### Should the default block change? Tested on the job it does, and no

The generator exists to produce multi-day VaR ([§24](#24-value-at-risk-estimation-and-var-backtesting)), so the deciding test is VaR coverage, not a proxy. On 10 names, window 500, non-overlapping evaluations:

| | Block 5 | Block 40 |
|---|---|---|
| 1% VaR, 5-day: exception rate (target 1%) | 1.59% | 1.36% |
| 1% VaR, 10-day | 1.82% | 1.82% |
| 5% VaR, 5- and 10-day | 5.00% | 5.00% |
| Kupiec rejections | 1 of 10 | 0–1 of 10 |

The longer block reproduces the facts better, but the coverage these samples can measure doesn't separate them: a 1% 10-day test has about 1.3 expected breaches per name. **The default stays at 5**, so §24's published numbers stand. The docstring now states what the generator keeps, with these measurements. Filtered historical simulation remains §24's recommended estimator for multi-day VaR: it propagates the EWMA variance recursion, so it gets its clustering from a model rather than from block length.

#### What did the book's trading agent learn? A constant rule, on the same simulator

Ch. 6 trains a deep Q-learning trading agent and reports "a significantly positive average performance … Not once does the trained agent lose money": mean gross performance **1.582**, accuracy about 0.55 (pp. 108–110). Declining RL in general isn't a reason to leave a specific claim unchecked, so this one was traced to its data.

The agent is trained **and** tested on **simulated** prices from the book's `Trading` environment. That's a mean-reverting process, `x_t = x_{t-1} + κ(θ − x_{t-1})dt + x_{t-1}σ√dt·z_t`, with the test parameters x₀ = 100, κ = 2, θ = 50, σ = 0.1 over 504 steps. The book itself calls it "a negatively trending time series": the price is **built to fall** from 100 toward 50, and its noise over two years (≈ 0.14 in log terms) is far smaller than the built-in decline (≈ −0.5).

`run_rl_simulation_check.py` replicates the simulator exactly: the book's Euler–Maruyama scheme and `dt`, its directional accuracy, its multiplicative gross performance at leverage 1, tested from bar 8. It then scores rules that learn nothing over 1,000 episodes. No agent is trained, because the question is what no learning achieves.

| Book's simulator | Accuracy | Mean gross performance | Episodes losing money |
|---|---|---|---|
| **The book's trained agent** | ~0.549 | **1.582** | "not once" |
| **Always short**, one constant action | **0.579** | **1.920** | **0.0%** |
| Short above θ, long below | 0.583 | 1.959 | 0.0% |
| Random | 0.500 | 1.012 | 49.9% |
| *Control: κ = 0, no built-in drift.* Always short | 0.501 | 1.025 | 46.8% |

**A rule that learns nothing beats the trained agent on the book's own simulator.** Remove the drift the simulator builds in, and nothing earns anything. The control's 1.025 is the small −σ²/2 drift in log price that this Euler scheme implies, not skill. The agent's "never loses money" is a property of the simulated price, not something learned about markets. It is also why the limited-data problem can't be solved by simulation alone: an agent trained on a simulator learns the simulator, including any predictability its parameters put there, and a market that is close to a random walk ([§15](#15-data-snooping-robust-model-selection-reality-check--spa)) offers no such drift to learn.

#### The rest of the book

| Ch. | Topic | Status here |
|---|---|---|
| 1 | Bayesian updating (coins, dice) | The p-value-to-posterior point is [§51](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4) |
| 2–3, 6 | Deep Q-learning; the trading agent | Declined ([§26](#26-book-coverage-what-was-taken-what-was-left-and-why)): a directional policy with no edge to learn. The book's own Ch. 3 names the two obstacles, and its Ch. 6 result is reproduced by a constant rule (above) |
| 4 | Noise-augmented and Monte Carlo series for training | Augmenting the training set is a regulariser, and every model here is already regularised and tested against the random walk. Another trial against a zoo with no edge isn't worth its multiple-testing cost. The book's own test runs of its noise-trained agent report accuracies of 0.515–0.561 and 0.449–0.511 (p. 76–77), scattered around a coin flip |
| 7 | Dynamic (delta) hedging | Needs options ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)) |
| 8 | Dynamic asset allocation | Portfolio allocation, declined for want of an edge to allocate |
| 9 | Optimal execution (Almgren–Chriss) | Impact matters once a strategy has an edge to execute. Nothing here survives even the statutory costs ([§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)), so there's no position whose execution to optimise |

---
### 58. Cross-check of §50–§57 — what was re-verified, and five defects it found

Everything added in §50–§57 was cross-checked before being relied on, in four layers.

| Layer | What was done | Result |
|---|---|---|
| Static analysis | `pyflakes` on all 44 new or changed files | No undefined names. Four lint issues in new drivers fixed: an unused import, an unused variable, a placeholder-free f-string, and an import used only as an availability probe, now `importlib.util.find_spec`. Three remaining warnings are in code this work didn't change |
| Tests and consistency | Full suite; `tools/check.py --tests` | 623 passed. The `--tests` mode, which checks the stated test count, isn't part of the default run, so a stale count would never have been caught; it now runs as part of every cross-check |
| End to end | XGBoost, LightGBM, Quantile and HAR-RV forecasts on real NSE bars, offline; all 53 app modules compiled | Every forecast finite, with lower ≤ median ≤ upper; the badge text correct; every module compiles |
| Reproduction | All 19 validation drivers from §45–§57 re-run, each checked against the figures this README quotes for it | 18 of 19 reproduced every quoted figure (141 figures). One didn't (below) |

#### Five defects found, all fixed and pinned by a test

| Where | Defect | Fix |
|---|---|---|
| `ML_model._features_from_buffers` (§55) | Passing the bars to fix the train/serve skew introduced a new edge case: a missing high or low on the forecast bar put **NaN** into `range_pct` at the origin, where the old proxy never did | Each of `atr_norm` and `range_pct` falls back to its close-to-close proxy when the true-range value isn't finite. `test_a_missing_high_or_low_on_the_origin_bar_falls_back_not_nan` |
| `strategy_metrics.india_charges` (§55) | Any date before the first dated entry (2018-01-01) returned an **empty** schedule, and `india_round_trip_bps` raised. The drivers never asked for one, but the function should handle any date | The base schedule always applies; only later revisions are gated by date. `test_india_costs_before_the_first_dated_entry_use_the_base_schedule` |
| `bhavcopy.fno_members` (§55) | A network failure was cached as an empty month, "no F&O names", and **never retried**. Every month has trading days, so an empty month can only be a failed fetch | Only real snapshots are cached. All 78 cached months were checked and are real, so §55's futures result stands. `test_fno_members_does_not_cache_a_failed_month` |
| `console._write` (§51) | The badge's "P(no edge) ≥ 43%" printed as "**? 43%**" on a cp1252 Windows console. It didn't crash, but the output was misleading | The reason-code symbols (≥, —, ·, …) are spelled out in ASCII before the generic fallback. `test_reason_codes_fold_to_ascii_on_a_legacy_console` |
| `run_synthetic_check.py` (§57) | **Not reproducible.** `arch_model(dist="t")` simulates from an unseeded generator, so the GARCH row changed on every run (clustering 0.40, 0.47, 0.35). Worse, every row rested on **one** simulated path per name, so the published bootstrap figure (0.35) was one draw | Seeded `StudentsT` draws and the median of 5 paths per name; two runs are now identical. §57's table and the `var_models` docstring now carry the robust figures. The conclusions held, and the bootstrap's shortfall is larger than first reported (0.20 of the clustering, not 0.35) |

A sweep of every new driver and module for other unseeded randomness found none. `var_models`' GAN uses the global generator, but only after `set_all_seeds(seed)`, which is why its row reproduced exactly.

The first three defects are edge cases that the measured results never hit, so no published figure depended on them. The fifth did, and [§57](#57-synthetic-returns-hilpisch-reinforcement-learning-for-finance-ch-5--a-test-that-a-shuffle-passes-and-what-the-projects-own-generators-keep) has been corrected.

---

### 59. Full audit of §1–§57 — every module read, every offline driver re-run, and what it found

[§58](#58-cross-check-of-5057--what-was-re-verified-and-five-defects-it-found) covered §50–§57. This audit covers the whole project, from the first section, with the books in `Books/Implemented` as the reference for what each technique should do.

| Layer | What was done | Result |
|---|---|---|
| Code read | All 53 app modules and the validation harness (`calibration.py`, `multiple_testing.py`), line by line, against the source each technique came from | **Ten defects in shipped code**, three in validation drivers (below) |
| Static analysis | `pyflakes` over every module, test and tool | No undefined names. The remaining warnings are unused imports and two unused locals (`kalman_model.last_price`, `UI.bullish`), none of them a logic slip |
| Tests | Full suite | **642 passed**: the 623 before, plus 19 that pin the fixes below |
| Reproduction | The 10 offline (bhavcopy) drivers for §38–§46 that §58 did not cover, re-run and compared with every figure this README quotes for them | §41, §44 and §46 reproduce exactly; §38, §39, §40, §42 and §43 had figures that do not (below) |
| Not re-run | The 18 drivers that read live yfinance data (§12–§37) | Their data now runs to October 2026, so a re-run would move every figure *and* read the reserved 2025-onward holdout, which needs your approval. Their code was reviewed instead |

#### Defects in shipped code, all fixed and pinned by a test

| Where | Defect | What it changed | Fix |
|---|---|---|---|
| `ARIMAX_model` (§2, §11) | pmdarima 2.x takes regressors as `X` and **silently ignores** the `exogenous=` keyword the code used. "ARIMAX" fitted **no regressors** — it was plain ARIMA, in the app, the meta-ensemble and every published table | Every ARIMAX figure before this section is ARIMA. Passing the regressors as written would have been worse: momentum, volatility, RSI and range at bar *t* contain *r_t* itself, so a same-bar fit measured **1.217×** the random walk's RMSE at **83%** coverage on five NSE names | Regressors enter `X`, **lagged one bar** (`_lagged_design`); calendar terms stay on the target bar; step 1 uses the actual last bar. Honest ARIMAX: **1.030×** RW, 95.5% coverage, against **0.998×** without regressors — the regressors cost ~3% (`run_arimax_exog.py`). The meta-ensemble keeps the member it was validated with, `run_arimax_prediction(use_exog=False)`, which equals the old fit exactly. `tests/test_arimax.py` (5) |
| `model_utils.simulate_price_paths` (§7, §21, §54) | `arch` draws simulation shocks from the fitted distribution's **own generator**; `np.random.seed(42)` never reached it | Two identical ARIMA/ARIMAX runs gave different cones, against §21's reproducibility claim and §54's "the seed is fixed, so any one forecast is reproducible" | Reseed the distribution's generator before simulating. `test_garch_cone_is_reproducible_across_runs` |
| `market_context` (opt-in) | Index values are daily closes stamped at midnight, so an **hourly** bar at 10:15 on day *D* was given *D*'s 15:30 close | A look-ahead for hourly models whenever `USE_MARKET_CONTEXT` was on | Intraday rows match strictly the previous session. `tests/test_market_context.py` (3) — the module's first tests |
| `iv_data.forward_vol_factor` (opt-in) | The same midnight stamp: an intraday origin read that day's India-VIX close | A look-ahead in the hourly IV tilt | Intraday frames read the prior session. `test_an_intraday_origin_reads_the_prior_sessions_vix` |
| `prediction_log.resolve_outcomes` (§28) | A target was filled with the last bar at or before it. A target whose bar had not printed — a lagging feed, or a daily target looked up during its own session — was resolved at a **stale or partial price**, and resolution never revisits a row | Live coverage and the paper portfolio could carry permanently wrong outcomes | Resolve only once the history runs strictly past the target. `test_a_target_the_feed_has_not_reached_stays_pending` |
| `tuning.nested_search` (§27) | The holdout call handed the objective the whole history, and `qlike_objective_har` placed its five origins over the back half of it: **2 of 5 "holdout" origins were inside the tuned region** | §27's "nested so it cannot cheat" did not hold. On the same data the old harness says tuning generalises on 4 of 5 names, the honest one 1 of 5 | `score_from=cut` on holdout calls; an objective that cannot accept it is refused. Re-measured table under "Does tuning HAR-RV's lags help?". 2 tests |
| `feature_drift.drift_table` (§35) | Both permutation nulls treated observations as exchangeable; rolling-window features are not | On i.i.d. returns with **no drift**, `vol_10` was flagged 97% of the time and `vol_50` / `ma_ratio_50` 100%, against a nominal 5%. §35's "WIDESPREAD DRIFT, the volatility family has moved" was largely this | A **block** permutation, blocks twice each feature's decorrelation lag: 0.02–0.05 on i.i.d.-driven features, full power on a volatility doubling (`run_drift_false_alarm.py`). On §35's split: 18 / 12 / 13 features flagged before, 6 / 0 / 1 after, no volatility feature among them. 3 tests |
| `autoencoder_regime.feature_windows` (§25) | The windows included the raw adjusted close (column 0 of `compute_price_features`), standardised on the earliest 70% of history | A trended stock was scored novel for its **price level**: median "unusual" 21%, "unprecedented" 8% on the recent block; TITAN 43% | Eight scale-free columns: 13% / 5%; TITAN 12% (`run_novelty_price_level.py`). `test_feature_windows_do_not_depend_on_the_price_level` |
| `range_volatility.efficiency` (§40) | Its squared-return baseline used the **raw** close, so a split added a fake −50% return to the baseline's noise | §40's precision gain was overstated on split names (TATASTEEL 2.34× vs 1.94×) | Baseline on `adj_close`: **1.7–2.4×**, not 1.6–2.5×. `test_efficiency_baseline_ignores_a_split_in_the_raw_close` |
| `chronos_model.prepare_timeseries_data` | The series id came from `get_ticker`, which downloads both exchange listings on **every call** — at every walk-forward origin of the confidence gate | A network blip failed a forecast for the sake of a label | The company name is the id. `test_chronos_series_id_needs_no_network` |

#### Defects in validation drivers

| Driver | Defect | Fix |
|---|---|---|
| `run_range_volatility.py` | The verdict only tested for a significantly **tighter** cone, so a significantly **wider** one (its old 6-name, 8-origin default gave paired t = +2.3) printed "every paired t is inside ±2" | Both directions are reported. The default is now the published 12-name, 24-origin configuration, with the names written down (the original list was never recorded) |
| `run_open_interest.py` | Default of 50 names; §41 was measured on 60 | Default 60, which reproduces §41 exactly |
| `test_new_models_smoke.py` | Asserted a "familiar" window's cone multiplier is exactly 1.0; it is √(error ÷ median), which exceeds 1 for any familiar window above the median | Asserts a negligible widening (< 1.1) instead |

#### Published figures that did not reproduce, now corrected in place

| Section | What differed | Why |
|---|---|---|
| [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) | Headline table at 400 names: t 2.01, not 2.24 | §55 removed `bb_position` (30 → 29 features) and the table was never re-run; restoring it reproduces the 39/100/200 rows exactly. The 400-name row also moves with live corporate-action revisions. **The seed study reproduces** (median t 2.40 vs 2.42, 7/8 seeds above 2) — the finding stands |
| [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) | Longer-hold sweep rows, in the second decimal | Live corporate-action feed. Headline row exact |
| [§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result) | Efficiency range; A/B table | The raw-close defect above; the original 12 names were unrecorded. Same verdict (every \|t\| < 1) |
| [§42](#42-microstructural-features-lópez-de-prado-afml-ch-19--a-usable-feature-an-unusable-measurement) | Bias table (0.244σ, not 0.262σ); raw / null levels; one name (ITC) not floored | The table was one draw (seeds give 0.24σ–0.32σ); a later fix lowered the null. Same conclusion |
| [§43](#43-the-deflated-sharpe-ratio-afml-147--and-what-it-says-about-39) | The N = 5 and N = 20 calibration rows | Not produced by this driver; the N = 100 / 500 rows and every reversal-book figure reproduce exactly |
| [§25](#25-regime-novelty-from-a-denoising-autoencoder), [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat), [§35](#35-feature-drift-and-attribution--the-ninth-negative-result-arriving-from-a-new-direction) | The claims the code defects above invalidated | Corrected with the re-measured figures |

#### Known, documented, not changed

- **Dormant excess-return targets.** If `market_context.add_market_index` were ever called, the conformal bands would be calibrated on excess-return residuals but applied to the price, leaving out the market's variance. Nothing calls it; the docstring now says so.
- **Corporate actions are fetched live.** `build_panel` re-downloads NSE's feed on every run, so the offline drivers are not bit-reproducible over time (§38, §39 above). Caching it would trade that for staleness; recorded rather than changed. *(Later: changed. [§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it) freezes each settled chunk, and [§74](#74-renamed-companies-lost-their-corporate-actions) found a larger problem in the same feed.)*
- **Novelty's reference block is adjacent in time to the score block**, so it is not an exchangeable null: 5% "unprecedented" against a 0.5% design rate even after the fix. The gate ships off.
- Smaller, all biasing calibration slightly optimistic: the cross-sectional classifier's calibration block has no embargo from its proper-train block; the stacking ensemble's XGBoost early-stops on the same block that supplies its out-of-fold meta-features; the Kalman band uses the plain 95% quantile without the finite-sample step every other conformal band here takes; Vol-LSTM clips log-RV at percentiles of the whole window; HAR-RV's four coefficients are fitted on the window that includes its calibration block.
- **During this audit**, `run_cross_sectional_clf.py` and `run_class_weight_ab.py` were re-run before it was noticed that their default fetcher is yfinance through today. Their output read 2025–2026 data; it was not used for any decision and is not reported here.

---

### 60. Stops, dividends and factors (Mladjenovic, *Stock Investing For Dummies*, Ch. 6, 15, 17) — a stop is hit twice as often as the panel implied, and the quoted price drops on the ex-date

Mladjenovic's *Stock Investing For Dummies* (7th ed., 2024) is a retail investor's guide: budgeting, brokers, accounting ratios, taxes, AI prompting. Most of it is advice to a person rather than a technique for a model. Three chapters make claims this project can measure on NSE data, and each one changed something in the app.

| Chapter | Claim | Result | What changed |
|---|---|---|---|
| **17** Brokerage orders | "Most investors set a stop-loss amount at about 10 percent below"; 5% if nervous; trailing stops of 8%, 20–25% for volatile stocks; beta tells you the trading range | A fixed stop means very different things on different stocks; the panel's P(loss) understated the stop-out risk by about half | **Risk panel shows P(stop hit) and a volatility-sized stop** |
| **6** Dividend dates | On the ex-date the stock "trades at a slightly lower price to reflect the amount of the dividend" | True: 81–94% of the dividend (band medians) | **Ex-dividend notice in the app; a prediction-log bias fixed** |
| **15** Factor investing | Value, size, quality, low volatility, dividend yield, beta, liquidity | Of the four buildable point-in-time, only dividend yield clears a multiple-testing bar — and it is really "pays a dividend at all" | A lead, recorded; nothing shipped |

#### Ch. 17: where a stop goes, and how often it is hit

`run_stop_loss.py`, 183 NSE names with at least 1,000 sessions, 2018–2024, adjusted OHLC, intraday lows.

**The book's fixed stops** — share of windows in which a stop that far below the close is touched:

| Within 21 sessions | 5% | 8% | 10% | 15% | 20% | 25% |
|---|---|---|---|---|---|---|
| All names (median) | 55% | 34% | 25% | 10% | 4% | 3% |
| Quietest fifth (vol 27%/yr) | 38% | 20% | **11%** | 3% | 1% | 1% |
| Most volatile fifth (vol 54%/yr) | 66% | 50% | **42%** | 25% | 14% | 8% |

The book's default 10% stop, which "gives the stock some room to fluctuate", is hit within a month one time in four on the median NSE name, and **four times as often on the volatile fifth as on the quiet fifth** (63 sessions: 32% vs 68%). One percentage for every stock is the wrong unit. The book's own remedy is to scale by "the beta". On NSE beta and volatility are closely related (Spearman +0.87), so the advice is not wrong in practice, but **volatility ranks names by stop-outs better than beta** (+0.92 against +0.82 at 10% / 21 sessions; +0.78 against +0.67 at 63). Beta is correlation × relative volatility, not volatility: the lowest-beta fifth (median β 0.55) has volatility 27%/yr against 38% for all names, and that, not the beta, is why its stops are hit less.

**The end-point trap.** The panel's `P(loss > x%)` is the chance the price *ends* below −x%. A stop is triggered if the price *touches* −x% at any point. For a driftless random walk the reflection principle makes the touch probability exactly **twice** the end-point one. Three estimates, scored out of sample on ~170,000 name-window-stop cases in two opposite periods (history before each period; non-overlapping windows):

| | Calm, rising 2022-07 → 2024-06 | Crash 2020-01 → 2021-12 |
|---|---|---|
| Observed, 21 sessions, 10% stop | 17.1% | 28.7% |
| End-point probability (what the panel showed) | 11.4% | 16.7% |
| **Reflection, 2 × end-point** | 22.9% | **33.5%** |
| The stock's own volatility-standardised excursion history | 25.9% | 39.1% |
| **Calibration error (ECE), all stops and horizons** | end-point 0.040 · **reflection 0.040** · own history 0.044 | end-point **0.086** · **reflection 0.040** · own history 0.044 |

The end-point probability understates the stop-out rate by about half when it matters most, in a crash. The reflection estimate is on target in the crash and about a third too high in a rising market, where upward drift lowers stop-outs. The own-history estimator (`stops.stop_hit_probability`) is more work and no better, so it is kept for research, not shipped.

**The fill.** When a 10% stop is hit, 9% of the time the price gaps through it at the open; the mean sale is 0.24% below the stop, the worst 5% about 1% below. The book's own "stop at $18 that sells at $17" is real but small on NSE large caps.

**What shipped.** The Risk & Probability panel gains two figures: **P(a −x% stop is hit)** = 2 × the end-point P(loss) already shown (`risk_metrics.stop_hit_probability`), and the **stop with a 1-in-5 chance of being hit** within the horizon — the level the price *ends* below 10% of the time, so that reflection makes the touch chance 20%. That is the book's "size the stop by volatility" advice made quantitative for each stock and horizon.

#### Ch. 6: the ex-date drop, and two consequences

`run_dividend_dates.py`, 2,171 cash dividends on their ex-dates, 339 names (two dividends going ex on the same day count as one event with the summed amount). The drop ratio is (cum close × (1 + market return) − ex close) ÷ dividend; 1.0 means the price fell by exactly the dividend:

| Dividend yield | Events | Median drop ratio |
|---|---|---|
| < 0.5% | 760 | 1.14 (noise: a 0.2% dividend inside a 1.5% daily move) |
| 0.5–1% | 573 | 0.84 |
| 1–2% | 467 | 0.81 |
| 2–5% | 309 | 0.85 |
| ≥ 5% | 62 | 0.94 (1.00 yield-weighted) |

The book is right: the price falls by **81–94%** of the dividend, by band median. *(Corrected in [§68](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period): the ≥ 5% row once showed 1.00, its yield-weighted figure, in the median column, and the range read 81–100%; three same-day dividend pairs are now merged.)* And it matters next to a forecast: **42%** of dividends are at least a tenth of a 5-day 95% cone's half-width, 15% at least a quarter (BPCL's 2021 dividend was 11.8% of the price).

**Consequence 1 — a bias in the forward prediction log.** Every forecast here is on the adjusted (total-return) basis. The log stored the anchor at serve time and, at resolution, the target's `adj_close` from a fetch made later. A provider back-adjusts every bar before each new ex-date, so a dividend going ex between the target and the fetch scaled the stored outcome down by the dividend yield, and the log recorded a 3% dividend as a 3% loss. It now records the total return from origin to target measured in one fetch, `anchor × adj(target) ÷ adj(origin)` (`test_a_later_dividend_does_not_bias_the_realised_outcome`).

**Consequence 2 — the quoted price.** The forecast is a total-return price, so it cannot show the drop the user will see in the quote on the ex-date. `corporate_events.dividend_notice` reads announced ex-dates from NSE's corporate-action feed and, when one falls inside the horizon, the app says so: the dividend, its yield, and the expected quoted drop (0.85 × the dividend), with the reminder that the drop is not a forecast miss. `get_data` now carries the resolved ticker on `attrs['ticker']` for this. NSE symbols only; any failure is silent.

#### Ch. 15: the micro factors this data can build

Most of the book's factors need balance-sheet data, which [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) found unobtainable point-in-time. Four can be built honestly: **dividend yield** (trailing-12-month cash dividends from the corporate-action feed, split-adjusted to each date, over the raw price), **low volatility** (60-day), **low beta** (250-day, to the equal-weighted panel) and **liquidity** (60-day median turnover). Fama-MacBeth rank IC against the next 21 sessions' excess return, sampled every 21 sessions so windows do not overlap, 63 months, Bonferroni bar |t| > 2.50 over the four:

| Factor | Mean IC | t | Hit rate |
|---|---|---|---|
| **Dividend yield** | **+0.0354** | **+2.91** | 0.68 |
| Low volatility | +0.0423 | +1.56 | 0.51 |
| Low beta | +0.0230 | +0.71 | 0.54 |
| Liquidity | +0.0070 | +0.33 | 0.56 |

Dividend yield clears the bar, and survives being ranked within volatility quintiles (t = 2.59), so it is not the low-volatility effect in disguise. Attacked further, it changes character:

| Dividend-yield check | IC | t |
|---|---|---|
| First half (2019–21) | +0.0307 | +2.09 |
| Second half (2021–24) | +0.0400 | +2.09 |
| **Payer vs non-payer only (1 / 0)** | +0.0333 | +2.00 |
| **Yield ranked among payers only** | +0.0162 | +0.92 |

Same sign in both halves, but **most of it is whether a company pays a dividend at all**; among payers a higher yield adds nothing measurable. That contradicts the book's "high dividends compared to the price", and is closer to its *quality* factor: the third of NSE names that pay nothing include the loss-makers. It is a lead, not a finding — one of four factors, on top of everything this project has already tried — and the honest next step is a single pre-registered test on the reserved holdout, alongside the candidates already queued there. Nothing ships.

#### What was not taken

| Book material | Why not |
|---|---|
| Ch. 2, 7, 20 (budgeting, brokers, US tax), App. A, C | Personal finance and US-specific; nothing to model |
| Ch. 9 payout ratio, Ch. 11–12 and App. B ratios, Ch. 21's "rising profits / low liabilities / bargain price" | As **factors**, they need earnings and balance-sheet history; blocked by data ([§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)). As **information** about today's company they are in the UI: [§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see) |
| Ch. 10 trends, channels, RSI | Already tested here: [§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting), [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code) |
| Ch. 6's 52-week high | Already tested: [§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it) |
| Ch. 17 margin and short selling | Short constraints already costed: [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) |
| Ch. 17's stop-loss as a *strategy* | Already tested on the path: [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed) |
| Ch. 5, 13, 14, 18, 19, 22–24 (ETFs, sectors, IPOs, crises, AI prompting, macro risks) | Narrative or product selection; no testable technique on this data |

`stops.py`, `corporate_events.py` and the risk-panel additions ship with **10 tests** (`test_stops.py`, `test_corporate_events.py`, and the prediction-log regression).

### 61. A company check beside the forecast (Mladjenovic, *Stock Investing For Dummies*, Ch. 3, 4, 21, App. B) — the information the price models cannot see

[§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date) took the three claims in this book that NSE data can test. The rest of the book is theory written for an investor, not a model: what a good company looks like, what to call a holding of a given length, and which risks exist. Its value to this project is as **information shown to the user**, and one gap makes it worth showing. Every model here sees prices only. None of them can tell a company that is growing its profits from one whose liabilities exceed its assets, and the forecast looks the same for both. The book's tool for that blind spot is a checklist, so the app now shows one: a collapsed **📘 Company check** expander below the Risk & Probability panel.

**It feeds nothing and is not a tested predictor.** Testing it would need each company's statements as they stood on every past date, and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) measured that yfinance holds about a year of that per NSE name. Showing *today's* statements for *today's* decision is the use `fundamentals.current_snapshot` was always allowed; joining them to a historical panel is the look-ahead `as_of_join` refuses. The expander says so in its caption.

#### Ch. 21: six of the ten hallmarks can be measured

`stock_checklist.py` scores the selected company from yfinance's latest annual statements, its dividend history and NSE's live F&O list. Every threshold is the book's, quoted on screen beside the result:

| Hallmark | Measured as | The book's rule |
|---|---|---|
| Rising profits | Net income, latest year against the one before; years up out of the last three | Rising, and a loss is a red flag |
| Rising sales | Total revenue, the same way | "Reviewing three years of sales gives you a good overall gauge" |
| Low liabilities | Total liabilities ÷ net equity (App. B's debt-to-net-equity) | Above 1 "isn't good" |
| Bargain price | Trailing P/E (or price ÷ latest EPS); P/B as the second route | 15 or less is good value, 10–20 conservative, above 40 a speculation; no earnings, no bargain; at or below book value |
| Growing dividends | Trailing-12-month cash dividend per share against a year earlier | A rising dividend is hard evidence of real profit |
| Optionable | In NSE's F&O segment (the only NSE stocks with listed options) | Options add ways to earn on, or protect, a holding |

The other four (a growing market, a high barrier to entry, a low political profile, favourable megatrends) have no data source, so they are listed as questions for the user, with the company's sector and industry, rather than guessed. The headline is "*k* of *n* measurable hallmarks met", next to the book's own bar: a stock with half of the ten is "a super-solid choice".

#### Appendix B: the ratio tests, grouped as the book groups them

| Group | Ratio | Book's rule |
|---|---|---|
| Profitability | Return on equity (on average equity since §63) | Above 10% is good |
| Profitability | Return on assets | Flags an ROE made with debt (the book's example: 25% ROE on 5% ROA, so a 5× gap) |
| Profitability | Net margin trend (common-size) | Higher than last year (within half a point counts as unchanged) |
| Solvency | Quick ratio | At least 1 |
| Solvency | Debt to net equity | At most 1 |
| Liquidity | Current ratio | 2 or more desirable; under 1 a red flag |
| Operating | Sales ÷ receivables | Receivables outgrowing sales; flagged at a 20% fall in a year, **this project's cut-off**, since the book gives an example rather than a number |
| Valuation | Price ÷ sales | 2 or less very undervalued, up to 4 fine, above 5 be very hesitant |
| Valuation | Price ÷ book | At or below 1 suits a value investor; above that it is context only ("not a showstopper") |

The book says a solid company should at minimum pass the profitability and solvency tests comfortably, so those two tallies are shown as metrics beside the hallmark count.

#### Three cases the book's rules get wrong as written

Running the checklist on live names before shipping it found three cases where applying the rules literally gives a wrong answer:

- **Negative net equity.** Vodafone Idea's liabilities exceed its assets. Its P/B of −3.8 passed "at or below book value" as a *bargain*, its ROE came out as −97%, and its P/E of 3.6 passed as good value. When equity is negative every equity ratio changes sign and stops meaning anything, so all of them now report a red flag saying why.
- **Lenders.** A bank funds itself with deposits, so its liabilities run to several times its equity by design, and it does not report current assets or liabilities at all. For a company in the Financial Services sector, the liability, liquidity, quick-ratio and receivables checks return *n/a* with the reason, following the book's own instruction to judge ratios against industry norms. Without this, every bank would fail the solvency test.
- **A flat margin.** HDFC Bank's net margin went from 36.6% to 36.6%, and it was flagged as falling because of a change in the third decimal. A change of under half a point now counts as unchanged.

#### Live, 18 October 2026 (latest annual report: year ending 31 March 2026)

| Company | Hallmarks met | Profitability | Solvency | What stands out |
|---|---|---|---|---|
| TCS | 4 of 6 | 2 of 3 | 2 of 2 | P/E 17.3 (inside the conservative band, not a bargain); trailing dividend down after a 2025 special |
| HDFC Bank | 3 of 5 | 1 of 2 | n/a (lender) | One hallmark is not applicable to a bank |
| MRPL | 3 of 6 | 3 of 3 | 0 of 2 | P/E 6.9, but liabilities 2.1× equity and a quick ratio of 0.39 |
| Vodafone Idea | 3 of 6 | 1 of 3 | 0 of 2 | Negative net equity: red flags, not a bargain |

**One data caveat is printed on screen.** The ratios are computed from yfinance's annual statement line items, and these can differ from yfinance's own trailing figures and from other sites, which often use standalone or last-four-quarter numbers. HDFC Bank's ROE is 8.9% from its annual statements (8.6% on year-end equity before [§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)'s switch to average balances) against 13.8% in yfinance's `info`. The panel uses one source throughout, the statements, and gives the fiscal year it read.

#### Ch. 3 and 4: the horizon, and the risks the forecast cannot see

The expander opens with what the book calls this holding. Mladjenovic counts anything under a year as short term, and holding a stock that briefly as "trading or short-term speculating", not investing, because short-term prices are driven by what millions of other people do next. That is exactly the horizon every forecast here covers, so the note says plainly that the forecast reads the next few sessions and says nothing about the company.

A second expander, **🧭 Risks this forecast cannot see**, lists Ch. 4's eight kinds of risk against what the app does about each. Only **market risk and volatility** is modelled, by the cone, the risk panel and the stop rows. Financial risk is what the company check is for. Interest-rate, inflation, tax, political, personal and emotional risk are not modelled, and the table says so instead of leaving it implied. The book's advice for those closes the expander: learn before you buy, keep money you will need within a year out of stocks, and diversify.

#### Added: the payout ratio (Ch. 9) and the company's size (Ch. 1, 14)

**Payout ratio.** Dividends ÷ earnings, read under the *Income (Ch. 9)* group. The book: 60% or less is very safe, 50–70% a good range, 80% the maximum acceptable, so ✅ up to 70%, ⚠️ to 80%, ❌ above. It is computed on **totals** (cash dividends paid ÷ net income, same fiscal year) rather than per share, because per-share history can change basis after a bonus issue or a merger: in yfinance's history HDFC Bank's EPS halves between FY2023 and FY2024 while its profit rose 26%. Live: HDFC Bank 31%, MRPL 36% (a year earlier 624%, when its profit nearly vanished), and TCS **80.1%**, a red flag by the book's rule. That is the rule read literally: an IT-services firm needs little capital and pays out most of what it earns. The rule is printed beside the result, and the caption warns that ratios vary by industry.

**Size.** The book's large / small / micro cut-offs are in US dollars. NSE's equivalent is SEBI's rank-based classification (top 100 large, 101–250 mid, the rest small), and NSE's broad indices are built from it, so the band comes from the live Nifty 50 + Next 50 (large), Midcap 150 (mid) and Smallcap 250 (small) member lists, with anything outside them labelled micro cap. The lists are rebalanced twice a year, so a band can lag a recent re-rating by a few months. For a small or micro cap the panel adds **Ch. 14's two rules**: in business at least three years, and "net profits of 10 percent or more over two years or longer", read here as a net margin of at least 10% in each of the last two years (the book does not say 10% of what), together with its warning that buying before there is evidence of growth is speculating.

| Company | Band | Ch. 14 rules |
|---|---|---|
| TCS | Large cap (Nifty 50) | — |
| Vodafone Idea | Large cap (Nifty Next 50) | — |
| MRPL | Small cap (Smallcap 250) | ✅ 31 years listed · ⚠️ net margins 0.1% and 2.2% |
| Rain Industries | Micro cap | ✅ 24 years · ❌ −3.7% and 0.3% |
| ideaForge | Micro cap | ✅ 3 years · ❌ −38.6% and −7.5% |

#### What was not taken

| Book material | Why not |
|---|---|
| Ch. 21's four judgement hallmarks | No data source; shown as questions instead |
| Ch. 16 screening tools | A screener ranks a whole cross-section by fundamentals: a different app, and 200+ statement fetches per screen |
| Ch. 12 company documents | Annual-report reading is not automatable here |
| Ch. 2 personal finances, Ch. 7 brokers, Ch. 20 US tax | Advice to a person, and US-specific |

The fetch is cached for six hours, and any failure (no statements, an unknown ticker, NSE down) leaves a one-line "skipped" note rather than an error. `stock_checklist.py` ships with **9 tests** (`test_stock_checklist.py`): the book's thresholds, negative equity, a loss-maker, a bank, the dividend and F&O checks, the payout and size bands, and the failure paths.

### 62. Trailing stops and targets (Mladjenovic, *Stock Investing For Dummies*, Ch. 17) — the book's 8% trailing stop is hit within a quarter 96% of the time

The book's preferred protection is not the fixed stop [§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date) measured but the **trailing stop**, "an important technique in wealth preservation": a stop that sits a fixed percentage below the highest price since it was set, so it rises with the stock and never falls. It quotes William O'Neill's **8%**, and **20–25%** for very volatile stocks. Its limit orders raise the mirror question: a sell order above the price fills if the price *touches* it, which is the stop question upside down. The panel answered neither. `run_trailing_stops.py` measures both on the same survivorship-free panel as §60 (183 names, 2018 to mid-2024, before the reserved period), with the trailing reference set to the highest adjusted high up to the bar *before* the one being tested, so a low is never compared with a high printed later on the same bar.

#### How often the book's trailing stops are hit

Median share of windows in which the stop is hit; the fixed stop at the same distance in brackets:

| Within 21 sessions | 5% | 8% | 10% | 15% | 20% | 25% |
|---|---|---|---|---|---|---|
| All names | 95% (55%) | **72%** (34%) | 53% (25%) | 21% (10%) | 8% (4%) | 3% (3%) |
| Quietest fifth (27%/yr) | 82% (38%) | 45% (20%) | 25% (11%) | 5% (3%) | 3% (1%) | 1% (1%) |
| Most volatile fifth (54%/yr) | 100% (66%) | 92% (50%) | 82% (42%) | 51% (25%) | **29%** (14%) | **13%** (8%) |

| Within 63 sessions | 5% | 8% | 10% | 15% | 20% | 25% |
|---|---|---|---|---|---|---|
| All names | 100% (71%) | **96%** (56%) | 92% (48%) | 64% (28%) | 36% (16%) | 16% (8%) |
| Quietest fifth | 100% (64%) | 88% (40%) | 68% (32%) | 28% (12%) | 12% (4%) | 4% (4%) |
| Most volatile fifth | 100% (81%) | 100% (72%) | 100% (68%) | 96% (52%) | **76%** (33%) | **48%** (28%) |

A trailing stop is hit about **twice as often** as a fixed stop at the same distance. The book's 8% trails out the median NSE stock within a month 72% of the time and within a quarter **96%** of the time, so on this market it is close to a guaranteed exit within a quarter rather than protection against a rare fall. The book's 20–25% for volatile stocks is the right idea: on the most volatile fifth it brings the one-month exit rate down to 13–29%, but over a quarter it is still close to a coin toss (48–76%).

#### Which estimate is calibrated

For a driftless random walk the fall from the running peak has the law of the walk's absolute value (Lévy's theorem), so a trailing stop at distance *a* (in σ units) is hit when |W| first leaves (−*a*, *a*), which has an exact series (`stops.trailing_probability`). A simulation confirms the formula converges as the steps get finer (0.52 at 252 steps, 0.57 at 4,000, 0.58 continuous, for a 10% trailing stop at σ = 10%). Upside, the reflection principle gives 2 × P(end above +*x*) (`stops.touch_up_probability`). Scored out of sample against the naive alternative, with σ from the EWMA forecast at each window's start, ~170,000 predictions per period:

| Expected calibration error | Calm 2022-07 .. 2024-06 | Crash 2020-01 .. 2021-12 |
|---|---|---|
| Trailing stop: fixed-stop estimate (2 × end-point) | 0.086 | 0.141 |
| **Trailing stop: Lévy drawdown formula** | **0.053** | **0.056** |
| Target touch: end-point P(gain) | 0.111 | 0.124 |
| **Target touch: reflection (2 × P(gain))** | **0.038** | **0.036** |

For example, a 10% trailing stop over 21 sessions was hit 38.6% of the time in the calm period (formula 43.8%, fixed-stop estimate 22.9%) and 62.4% in the crash (61.2%, 33.5%). A +10% target was touched 37.6% and 41.9% of the time (reflection 26.8% and 37.6%, end-point 13.4% and 18.8%). The remaining errors have a direction. The trailing formula runs a little **high** in a rising market and the target estimate a little **low** at a month, both because the formula has no drift and NSE rose over the window. Correcting that would need a drift forecast, and this project has none with demonstrated skill, so the estimates stay driftless and the help text says which way they err.

#### What shipped

Two rows in the Risk & Probability panel, beneath the fixed-stop row, using the threshold the user sets:

- **P(a −x% trailing stop is hit)**: `risk_metrics.trailing_stop_probability`, the Lévy formula with the stop's distance read off the panel's own end-point P(loss), so it uses the same fat-tailed or log-normal distribution as every other number in the panel.
- **P(+x% is touched)**: `risk_metrics.target_touch_probability`, 2 × P(gain), the chance a sell order at +x% fills before the horizon.

`trailing_probability`, `touch_up_probability` and `no_exit_probability` ship in `stops.py` with **2 tests** (the formula's limits and a fine-step simulation; the target and the panel wiring).

### 63. Breadth, break-even and balance-sheet trends (Thomsett, *Stock Market Math*) — weak breadth forecasts a more volatile market, not a falling one

Thomsett's *Stock Market Math* is a formula reference: returns and their annualisation, leverage, balance-sheet and operating-statement tests, market breadth, volume indicators and oscillators, each with its arithmetic and an Excel entry. Most of the price and volume formulas are already here and were tested in [§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting) and [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code): RSI, MACD, stochastics, moving averages, Bollinger bands, OBV and Chaikin's accumulation/distribution. Three parts were new and could be built: **market breadth** (Ch. 8–9), the **break-even return** after tax and inflation (Ch. 1, 4), and the **balance-sheet and operating trend tests** (Ch. 6–7). Building them also turned up two bugs.

#### Market breadth (Ch. 8–9): measured, and it is about volatility

Breadth asks how many stocks take part in a move: advances against declines, new 52-week highs against new lows. No model here had ever seen it, because it needs the **whole market on every day, including names that later delisted**. The survivorship-free bhavcopy cache is exactly that, and `breadth.daily_breadth` builds it point-in-time. An advance is `close > prevclose` (NSE adjusts `prevclose` on an ex-date, so a split is not a crash), and 52-week extremes are taken on the chain of `close / prevclose`, so a split never prints a false new low. Every issue with at least ₹1 crore of turnover counts: a median of 864 a day, 2017 to mid-2024.

`run_market_breadth.py` pre-registered four measures, three targets and a Bonferroni bar of |t| > 2.87 over the 12 tests (Newey-West errors, out-of-sample check fitted to 2021 and scored on 2022 to mid-2024):

| Measure | Next 5-day market return | Next 21-day return | Next-month volatility, beyond HAR |
|---|---|---|---|
| `ad10`: 10-day advance/decline ratio | t +3.07, OOS R² −0.038 | t +1.88 | **t −3.83, OOS R² +0.062** |
| `mcclellan`: McClellan oscillator | t +3.14, OOS R² −0.024 | t +1.98 | **t −4.03, OOS R² +0.093** |
| `hilo10`: net new highs | t +0.99 | t −0.48 | t −1.07 |
| `hl_index`: record-high percent | t +1.63 | t +0.82 | t −0.80 |

**Returns: no.** The two advance/decline measures clear the bar for the next week's return, but only because of 2018–2020 (t +3.16 and +3.04); in 2021–2024 they fall to t +0.84 and +1.36, and out of sample they lose to the plain mean. Short-horizon persistence in an equal-weighted index is also partly mechanical (small stocks react late to market news), so there is nothing here to trade.

**Volatility: yes, and robustly.** Weak breadth predicts a more volatile month ahead, beyond what the market's own recent volatility (a HAR model on 1, 5 and 22 days) says, in both halves (t −2.90 and −3.07 for `ad10`, −3.16 and −3.03 for McClellan), cutting out-of-sample error by 6–9%. Next-month market volatility by breadth quintile: **24.6%** a year in the weakest fifth, then 19.9%, 19.0%, 17.3%, 17.4%. Two simpler explanations were tested and do not account for it:

| Breadth measure | Controls | Breadth t | OOS error cut |
|---|---|---|---|
| `ad10` | HAR + past 10-day return and its downside (the leverage effect) | −3.46 | 5.7% |
| `ad10` | the same + India VIX | −3.44 | 5.5% |
| `mcclellan` | HAR + leverage | −3.35 | 6.8% |
| `mcclellan` | the same + India VIX | −2.87 | 5.2% |

So breadth carries information about the market's next month that neither past volatility, a falling market nor the option market's own forecast (India VIX) already holds.

**For a single stock it is too small to use.** Added to each stock's own HAR forecast (187 names, 283,731 name-days, Driscoll-Kraay errors for the shared dates), breadth is still significant (t −2.37 to −2.95) but improves the out-of-sample forecast by between −0.2% and +0.7%. A stock's volatility is mostly its own. The forecast cones are therefore **not adjusted**; doing so would add a trial and a live dependency for under 1%.

**What shipped** is the market-level fact, as context. Under the Risk & Probability panel a 🌐 caption gives the latest 10-session advance/decline ratio, its fifth on the frozen 2018–2024 cut-points, and the measured next-month market volatility for that fifth, and says that this stock's range is not adjusted for it. `breadth.live_breadth` reads the last ten published NSE bhavcopies; the cut-points (`AD10_EDGES`) and volatilities (`NEXT_MONTH_VOL`) are constants from the study, never refitted on live data. The McClellan oscillator, slightly stronger in the study, needs ~100 sessions of history to settle, against ten for `ad10`, so the app shows `ad10`.

#### The break-even move (Ch. 1, 4)

Thomsett's break-even return is **inflation ÷ (1 − tax rate)**: what an investment must earn to have kept pace with prices after tax. A trade also pays round-trip costs first, and only the gain after costs is taxed, so over *h* sessions (`risk_metrics.breakeven_move`):

> B = cost + inflation × h / 252 ÷ (1 − tax)

Cost is §55's itemised delivery round trip (22.2 bp, almost all STT, before brokerage and spread, so B is a floor). Inflation is RBI's 4% CPI target, and tax the 20% short-term capital-gains rate on listed equity (from 23 July 2024) plus 4% cess, 20.8%. All three are dated constants. Over 5 sessions B is **+0.32%**: 0.22% costs plus 0.10% inflation after tax. Over 1 session it is +0.24%. At these horizons the cost dominates; inflation and tax matter only over months.

The panel now shows **Break-even move** in % and ₹, and **P(the move clears break-even)**, read off the same distribution as every other probability there. On TCS for 5 days (18 October 2026) that was 48% against a P(price up) of 49%: the gap is what costs take. Annualising a short forecast, the other use of Ch. 1's formulas, was not added. Scaling a 5-day move up by 50 also scales its noise by 50, and the result reads like a promise.

#### Thomsett's balance-sheet tests (Ch. 6–7), added to the company check

Thomsett judges these by their **trend**, so they sit in their own *Trends (Thomsett)* group of the company check ([§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)), not counted in the book-threshold tallies:

| Test | Formula | Flag |
|---|---|---|
| Inventory turnover | cost of goods sold ÷ average inventory | down a tenth in a year (this project's cut-off); n/a when inventory is under 2% of assets |
| Debt capitalization | long-term debt ÷ (long-term debt + equity) | "rising over a period of years is a serious warning": rose every year shown, by 2+ points (cut-off ours) |
| Operating margin trend | operating income ÷ revenue (Ch. 7, costs against revenue) | lower than last year by over half a point |
| Tangible book value | net worth − goodwill and intangibles | context: price ÷ tangible book and the intangible share of net worth; negative is flagged |
| Average collection period | 365 ÷ receivables turnover | shown in days on the existing sales-to-receivables row, which is the same ratio |

Live: MRPL's inventory turnover fell from 11.4 to 7.3 and its collection period rose from 14 to 25 days, both flagged. TCS's debt share went 7% → 8% → 8%; that was flagged as "rising every year" until the 2-point floor was added. HDFC Bank's intangibles are 36% of its net worth, the goodwill from the HDFC Ltd merger. Vodafone Idea's tangible book value is negative, and its debt share of capital, 124–185% on negative equity, now reports the negative-equity red flag rather than a number.

#### Two refinements to the company check (Ch. 2, 6)

**Returns on average balances.** Thomsett (Ch. 2) divides a year's profit by the **average** net worth over the year, not the closing figure, because the profit was earned on the capital employed through the year. Year-end alone understates a growing company's return and overstates a shrinking one's. Return on equity and on assets now use the average of the opening and closing balance, falling back to year-end when only one year is reported. Live, nothing changed verdict, but the numbers moved: TCS's ROE from 45.9% to 48.7% (equity grew 13%), MRPL's from 13.6% to 14.2%, HDFC Bank's from 8.6% to 8.9%.

**The payout trend.** Thomsett (Ch. 6): as earnings grow, the share paid out "ideally should remain the same", and "when you see this slipping over several years, it is a negative sign", though buybacks can take the place of dividends. The ratio is erratic from year to year (MRPL's went 5% → 624% → 36% as its profit collapsed and recovered), so the *Income* group flags it only after **two falls in a row by a company that stayed profitable**, and the rule beside it states the buyback caveat. None of the four live names is slipping. One more test.

#### Two bugs found on the way

| Where | Bug | Fix |
|---|---|---|
| `bhavcopy.fetch_day` | A failed download is indistinguishable from a holiday, and it was cached as an empty "market shut" file, permanently. **Ten consecutive trading days, 29 October to 11 November 2024, were in the cache as holidays.** The same defect class as `fno_members` in [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found) | Only real files are cached; a miss is retried next time. The ten placeholders were deleted and re-fetched (1,906–1,924 lines each). No published result is affected: every bhavcopy study ends by mid-2024, and the one driver that covers late 2024, `run_stress_test.py`, reads yfinance. `test_fetch_day_does_not_cache_a_failed_fetch_as_a_holiday` |
| `get_data.get_bse_nse_data` | BSE's listing API answered **403 to every request** on 18 October 2026, whatever the headers. Its failure raised, the company list came back empty, and **the app could not be used** | BSE is now optional: on failure the NSE listing (2,605 names) is used and a warning logged. `test_a_bse_outage_falls_back_to_the_nse_listing` |

#### What was not taken

| Book material | Why not |
|---|---|
| Ch. 8 put/call ratio | Offered and not run. The cache holds one F&O snapshot a month, so a daily series needs ~1,600 full F&O bhavcopy downloads, and India VIX, which the breadth test already controls for, is priced from the same options, so the expected result is a null. The project has no option chain ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)) |
| Ch. 8 short interest ratio, mutual fund cash ratio, large block ratio (Ch. 10) | No historical NSE source |
| Ch. 10 Money Flow Index | A volume-weighted RSI; §55 found OBV, Chaikin and RSI overlap existing features at 0.63–0.93, and the same reason not to add a trial applies |
| Ch. 9, 11 RSI, MACD, stochastic, moving averages, Bollinger bands; the random-walk hypothesis | Already tested ([§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting), [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)); the random walk is this project's baseline everywhere |
| Ch. 5 core earnings, Ch. 12 combined price and fundamental tests | Core earnings needs footnote adjustments not in any feed; combined tests need fundamentals history ([§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)) |
| Ch. 1–4 option returns, leverage, compound interest and deposit formulas | No option chain; personal-finance arithmetic |

`breadth.py`, the break-even move, the trend tests and the two fixes ship with **7 tests** (`test_breadth.py`, `test_get_data_listing.py`, and one each in `test_stops.py`, `test_stock_checklist.py` and `test_bhavcopy.py`), plus one for the two refinements.

### 64. Results days and the options market (Benklifa, *Think Like an Option Trader*) — a 95% band covered only 82% of one-day windows holding a results day

Benklifa's book is about a way of thinking more than a technique. A stock trader looks at a price and asks where it goes next. An options trader looks at the same stock and sees a **distribution of prices that the market has already priced**, and trades the gap between that distribution and their own. This app's forecasts are already distributions (the cone, the Risk & Probability panel), so the idea fits, and two parts of the book could be built. **Ch. 5's "known unknowns"** became a measured accuracy fix, and **the option trader's reading of a chain** (Ch. 2–3, 6) became a live view beside the forecast. The work also found a ticker bug that had been forecasting the wrong company.

#### Results days: a known unknown the cones ignored

Ch. 5 separates risk into *known unknowns* and *unknown unknowns*. A results announcement is the clearest known unknown: its **date** is public (SEBI's listing rules require at least two working days' notice, and most companies give one to three weeks), its **outcome** is not. An option trader sees it in the price, because the expiry spanning it carries extra implied volatility. A forecast cone calibrated on all days treats it as an ordinary day.

`corporate_events.results_calendar` reads NSE's board-meeting calendar, which goes back years: 44,955 results meetings, 2017–2024. `run_results_days.py` measured 175 names on the survivorship-free panel, 2018 to mid-2024, pre-registered as follows. Event days are the session on or after the meeting (*day0*) and the next one (*day1*), since many companies report after the close. Each day's surprise is z = return ÷ the one-step EWMA σ forecast. The widening is fitted on 2018–2021 and scored on 2022 to mid-2024.

| E[z²] (an ordinary day ≈ 1) | day0 | day1 | other days |
|---|---|---|---|
| 2018–2021 | 3.24 | 4.24 | 1.14 |
| 2022–2024 | 2.85 | 4.17 | 1.12 |

Relative to an ordinary day, a results session carries **2.86×** the variance and the one after it **3.74×**, stable across the two periods; 9.2% of results days move more than 3σ, against 1.5% of other days. A 95% band (|R| ≤ q·σ·√h, with q calibrated on all 2018–2021 windows) then covers:

| Horizon | Windows with results: plain | Widened | Without results: plain | Widened | Widening |
|---|---|---|---|---|---|
| 1 session | **81.9%** | 94.8% | 95.2% | 94.8% | ×1.88 |
| 5 sessions | **89.3%** | 94.5% | 96.0% | 95.4% | ×1.33 |
| 10 sessions | **93.0%** | 95.2% | 96.7% | 96.2% | ×1.15 |

The widening adds each results session's excess variance to the window, σ_h² = σ²·(h + n₀(2.86 − 1) + n₁(3.74 − 1)), and restores ~95% coverage out of sample. Windows without results are left slightly over-covered by the plain band, because results windows inflated its calibration. The reverse case, a window starting within five sessions **after** a results day, is only mildly over-covered (95.3–96.8%, E[u²] ≈ 1.0 against 1.13–1.19 elsewhere): the volatility forecast is 5–10% too wide just after a results day, too little to change the models for.

**What shipped.** When NSE's calendar shows a results meeting whose day0 or day1 falls inside the forecast horizon, a 📅 notice names the date. **The Risk & Probability panel is widened** by `risk_metrics.results_widening` = 0.96 × √((h + n₀·1.86 + n₁·2.74)/h). The 0.96 is the measured shrinkage of the 95% quantile once results windows stop inflating it. Every number in the panel (range, VaR, probabilities, stops, break-even) is read off the widened distribution (`build_risk_panel(..., scale=)`). The per-model charts and tables are left as the models produced them, and the notice says so. **Caveat:** the calendar gives meeting dates, not the dates they were announced, so the study treats each event as known from the window's start. With the usual one to three weeks' notice that holds for horizons of up to ten sessions.

#### What the options market prices (live, F&O stocks)

`option_market.py` reads NSE's live option chain (the `option-chain-v3` endpoint, which answers a browser-like session; `iv_data.py` had found the older endpoint unusable). From it, it computes:

- **implied volatility** from the at-the-money straddle, with Black-76 on a forward taken from put-call parity at that strike, so dividends and the interest rate largely cancel;
- **the expected move to expiry**, the straddle as a share of the price (≈ 0.8σ, the option trader's rule of thumb);
- **the 1σ move over the forecast horizon**, against the panel's own;
- **the results-day move the market prices.** With the event inside the first expiry, iv₁²T₁ = (forward vol)²T₁ + v, where the forward volatility between the two expiries has no event in it;
- **defined risk (Ch. 6)**: the cost of a put at the stop level and the most a holder can lose with it through expiry, gaps included, next to the panel's P(stop hit).

Live, 16 October 2026 close:

| | TCS | Infosys | Reliance |
|---|---|---|---|
| ATM implied vol, 27 Oct expiry | 26.6% | 34.9% | 23.9% |
| Expected move to expiry (straddle) | ±3.7% | ±4.8% | ±3.3% |
| 1σ over 5 sessions | ±3.75% | ±4.9% | ±3.4% |
| Protective put at −2% | 2,400 put: 0.90%, loss capped at 3.5% | 1,120 put: 1.07%, capped at 4.6% | 1,180 put: 0.65%, capped at 3.2% |

Infosys reports on 23 October, and the market prices that day as a **±3.0%** move, 2.2× an ordinary session's variance. That is below the panel-wide historical 2.86× and 3.74×, as expected for a large, closely followed company. TCS shows the opposite situation: its results were on 9 October, the stock rose about 20% in the following week, and HAR-RV's 5-day spread (roughly ±7%) is about twice the options market's ±3.75%. The models are still carrying the results-day moves in their history; the options market has priced them as over.

**What it is not.** Option prices are **risk-neutral**: they include what traders pay for protection, so implied volatility runs above what is later realised (India VIX ran a median 27% above NIFTY's realised volatility, `iv_data.py`) and the probabilities read off them are not forecasts ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)). NSE keeps **no option history**, so none of this can be backtested. It sits in a collapsed expander beside the forecast and is never fed into it. Stocks without listed options, and any failure to reach NSE, show nothing.

#### A ticker bug: five Nifty 100 names were forecast from the wrong listing

The app's first lookup takes a company's symbol from NSE's listing and passes it to yfinance **without the exchange suffix**. yfinance resolves a bare symbol to a US listing whenever one exists. "Infosys Limited" therefore fetched the NYSE ADR `INFY` in USD and converted it to rupees, and the data-quality banner passed it, because the series is a real one. TCS escaped only because a bare `TCS` is delisted in the US, so the search fallback found `TCS.NS`. A scan of the Nifty 100 found **5** symbols that resolve bare to a foreign listing: **HAL** (Halliburton, not Hindustan Aeronautics), **IDEA**, **INFY**, **LTM** and **TMCV**. The other 95 resolve to nothing and fall through correctly. The listing now records each symbol's exchange, and the yfinance path uses `get_data.get_yf_ticker`, which returns `INFY.NS` (or `.BO` for a BSE-only listing). The nselib fallback still gets the bare symbol it needs. The prediction log holds only 3M India, which is unaffected. `test_the_yfinance_ticker_carries_the_exchange_suffix`.

#### Other scheduled events: measured, and not shipped

Results days are company-specific. Three other events have public dates and unknown outcomes and hit every stock at once, so `run_market_events.py` ran the same pre-registered test on them (fit 2018–2021, score 2022 to mid-2024). An event qualifies only if a plain 95% band clearly under-covers windows holding it **and** the fitted widening restores ~95% out of sample:

| Event | E[z²] day0 / day1, 2018–21 → 2022–24 (ordinary ≈ 1.2) | 1-session coverage: plain → widened | 5 sessions | Verdict |
|---|---|---|---|---|
| Union Budget (5 + 3 speeches) | 4.36 / 3.98 → **2.20 / 1.11** | 93.2% → 98.9% | 93.7% → 97.1% | **Not stable.** Budget days were large in 2018–21 and have since calmed; with three test events the fitted widening over-corrects |
| RBI policy decisions (22 + 15, scheduled only) | 1.66 / 1.19 → 1.18 / 0.92 | 96.4% → 97.2% | 96.1% → 96.4% | **No effect.** Already covered |
| Monthly F&O expiry (48 + 30) | 1.37 / 1.55 → 1.62 / 1.47 | 92.4% → 94.0% | 94.2% → 94.6% | **A small one-day shortfall** the widening does not fix; nothing at five sessions |

So results days remain the only scheduled event that widens the panel. The RBI dates for 2019–20, 2021–22 and 2023–24 were checked against RBI's published schedules. The unscheduled moves (27 March and 22 May 2020, 4 May 2022) are excluded, because no forecast could have widened for them. NSE's special Saturday session for the 2020 Budget is not in the weekday-only bhavcopy cache, so that move lands in the next session's return.

#### Starting the option-chain history

Nothing option-based here can be backtested, because NSE keeps no option history ([§48](#48-risk-neutral-is-not-physical-hilpisch-financial-theory-with-python-ch-5--a-calibration-error-in-shipped-code)). That rules out testing the most useful question this section raises, whether single-stock implied volatility would make the cones better, and Thomsett's put/call ratio too. The only remedy is to record the history from now on, as the prediction log does for forecasts. `tools/collect_option_chains.py` snapshots every F&O stock once a day: spot, the at-the-money strike, call and put prices, the parity forward, the straddle-implied volatility, and total call and put open interest, for the next two expiries. It appends to `.option_history/option_chains.csv`, and the inputs are kept so a later study can recompute volatility differently. It is idempotent (a second run the same day adds nothing) and retries a throttled session. The logic lives in `option_market.collect_snapshots`, so it is tested like product code.

The first run, for the 16 October 2026 close, recorded **421 rows across all 213 F&O stocks**: median first-expiry ATM implied volatility 27.2%, range 15.8–45.3%. It also found a bug in the live view: **`M&M` and `GVT&D` returned no chain** because the `&` was not URL-encoded, so NSE was asked for the chain of "M". Symbols are now encoded. Run it once a day after the close, for example a Windows Task Scheduler entry running `python tools/collect_option_chains.py` from the project folder. After six to twelve months there is enough to pre-register the implied-volatility test.

#### What was not taken

| Book material | Why not |
|---|---|
| Ch. 1 "why traders fail", trading for the right reasons, duplicating a strategy, correlation versus causation | Trader psychology. "Duplicate a strategy" and "correlation is not causation" are what this project's walk-forward, Diebold-Mariano and SPA layers already enforce ([§15](#15-data-snooping-robust-model-selection-reality-check--spa)) |
| Ch. 3–4 the "builds" (directionless trades, risk reduction, augmented returns), Greeks, synthetic straddles, in/at/out-of-the-money trades, situational and directional trades | Option-strategy construction. With no option history they cannot be backtested, and the app forecasts stocks rather than recommending trades |
| Ch. 6 layering and unlayering, "trades cannot be fixed", portfolio risk | Position management for a book of trades; the app is single-stock |
| Appendix: the price uncertainty principle | An analogy for the claim that a price is a distribution, which is what the cone already shows |

The results calendar, the widening, `option_market.py`, the collector and the two bug fixes ship with **9 tests** (`test_option_market.py`, and one in `test_get_data_listing.py`).

### 65. The O'Neil-disciple signals (Morales & Kacher, *Trade Like an O'Neil Disciple*) — pocket pivots add nothing, and major gap-ups lag the market

Morales and Kacher ran money for William O'Neil, and the book is mostly their trading memoir and psychology (Ch. 1–4, 8–10). Three chapters, though, give rules precise enough to code. **Pocket pivots** and **buying major gap-ups** are their two entry techniques (Ch. 5). **Dr. K's market direction model** (Ch. 7) is a buy/sell switch for the whole market built from O'Neil's distribution days and follow-through days, for which the book reports +33.1% a year, 1974–2009. The same chapter says the follow-through threshold was re-chosen several times "based on perceived volatility" and that the model has undisclosed "fail-safes". Both are how a backtest gets overfitted, so `run_oneil.py` fixes every rule in advance at the book's own published values. The window is the survivorship-free panel (197 liquid names) and NIFTY, 2018 to mid-2024, before the reserved period. Volume is **rupee turnover** throughout, because share volume jumps on a split and turnover does not. For the market's volume it is NSE's total equity turnover, since NIFTY's own volume field is zero on 25 days of the window. The rules live in `oneil.py`.

#### Pocket pivots (Ch. 5): the volume signature adds nothing

The book's definition: an up day whose volume is at least the largest down-day volume of the prior 10 sessions, closing above the 50-day average. A *proper* pivot also starts from the 10-day average, with the day's low at or just above it (we take "just" as within 1%), and does not follow "wedging", price rising over the prior 10 sessions on falling volume. The control is the same stocks' up days above the 50-day average that **lack** the volume signature, so the comparison isolates what the book's volume rule adds. Returns are in excess of the equal-weighted panel; t-statistics average the events within each calendar month first, so a crowded day cannot count as hundreds of independent observations.

| Group | Events | 5-day excess | 21-day excess (t) | 63-day excess | Beat the market at 21 days |
|---|---|---|---|---|---|
| Core pocket pivot | 31,781 | −0.08% | +0.03% (0.20) | +0.33% | 46.5% |
| Proper pocket pivot | 9,254 | −0.02% | +0.23% (1.16) | +0.47% | 46.8% |
| Control: up day above the 50-day, no signature | 56,737 | +0.08% | +0.11% (0.55) | +0.39% | 46.3% |

The core pivot minus the control, month by month, is **−0.07% (t −0.42)**: the volume signature contributes nothing, and after a 0.22% round trip the pivot loses 0.18%. It is also not rare. The core condition fires on about one stock-session in nine, which is hard to square with the book's picture of a discriminating buy point.

#### Major gap-ups (Ch. 5): the wrong sign on NSE

A major gap-up opens at least 0.75× the 40-day average true range above the prior close, on volume at least 1.5× its 50-day average. The book says to buy one in a fundamentally strong leading stock and to sell if the gap day's low breaks. Fundamentals are not available point-in-time ([§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)), so "leading" is proxied by being above the 50-day average and within 15% of the 52-week high. Held 21 sessions from the gap day's close:

| Group | Events | 5-day excess (t) | 21-day excess (t) | 63-day excess (t) |
|---|---|---|---|---|
| All major gap-ups | 2,503 | **−0.98% (−2.85)** | **−1.65% (−2.93)** | −1.46% (−2.37) |
| Leading-stock proxy | 1,228 | −0.16% (−0.58) | −0.72% (−1.16) | −0.25% (−0.22) |
| Leading, with the book's sell rule | 1,228 | | +0.09% (0.26); 78% stopped out | |

A major gap-up on NSE has, on average, **given back ground against the market** over the following month. That is a short-term reversal, the same effect as [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), and the opposite of the book's advice. Restricting to stocks near their highs halves the loss and removes its significance. The book's sell rule (exit at the lower of the open and the gap day's low once that low breaks) brings the trade to about zero by cutting the 78% that fail. The reversal is not a trade either: it would need shorting, which [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) found unavailable or too costly for most of the universe.

#### The market direction model (Ch. 7): timing indistinguishable from luck

A distribution day is the index down at least 0.1% on higher volume, or "churning": up under 0.1%, closing in the bottom quarter of its range, on higher volume. Five in 20 sessions is a sell signal. A follow-through day comes on or after session 4 of a rally attempt that began with the first up close after a new low (the book's usual window is days 4–7, "not an absolute requirement"), with the index up at least a threshold on higher volume. It turns the model back to "uptrend". The trade is long NIFTY in an uptrend and cash in a correction, at 10 bp per switch. The test is against 1,000 circular shifts of the model's own state series, which keep its time in the market and its run lengths but move the timing:

| | Return / yr | Volatility | Sharpe | Worst drawdown | In the market | Shifts at least as good |
|---|---|---|---|---|---|---|
| Model, 1.0% follow-through (O'Neil's original) | 9.4% | 11.2% | 0.84 | −13.1% | 49% | **14.4%** |
| Model, 1.5% follow-through (the book's 2010 value) | 7.0% | 10.4% | 0.67 | −11.5% | 39% | 28.5% |
| Buy and hold NIFTY | 13.0% | 18.2% | 0.72 | −38.4% | 100% | — |

At 1.0% the model has the better Sharpe ratio and a third of the drawdown, but it earns less than holding. One in seven random shifts of the same signal does as well, so the **timing** is not distinguishable from luck on this window. The drawdown is smaller mostly because the model is out of the market half the time. At the book's own 1.5% it trails holding outright. Next-month NIFTY returns were lower in "correction" than in "uptrend" (+0.71% against +1.35%) and volatility a little higher (16.2% against 14.3%), in the book's direction but not significant. Six and a half years hold only a handful of real corrections, so the test has little power. The book's +33.1% is not reproduced. Market breadth ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) remains the market-level signal this project found robust.

#### The moving-average sell guide (Ch. 5): the one rule that worked in its own direction

The book uses the 50-day average (or the 10-day, for a stock that has "obeyed" it) as a sell guide: a close below it on heavy volume says the stock's character has changed. Which average a stock "obeys" is a judgement the book does not pin down, but the core rule can be fixed. A close **crossing** below the 50-day average on volume at least 1.5× its 50-day average is compared with the same crossing on ordinary volume:

| A close crossing below the 50-day | Events | 5-day excess (t) | 21-day excess (t) | 63-day excess (t) |
|---|---|---|---|---|
| On heavy volume | 1,410 | −0.52% (−2.14) | **−0.94% (−2.26)** | −1.14% (−1.66) |
| On ordinary volume (control) | 8,277 | +0.11% (2.01) | +0.08% (0.49) | +0.04% (0.11) |
| Heavy minus ordinary, by month | | **−0.63% (−2.59)** | **−1.02% (−2.55)** | −1.18% (−1.77) |

Stocks that break their 50-day average on heavy volume go on to lag the market, and stocks that break it quietly do not. That is what a working sell rule looks like, and it is the only signal in this book that behaved as the book says. The sign holds in both halves, at both short horizons, though the strength moves between them:

| | Heavy | Ordinary | Difference (t) |
|---|---|---|---|
| 2018–20, 5 days | −1.05% | +0.13% | −1.00% (−2.11) |
| 2018–20, 21 days | −0.34% | +0.26% | −0.70% (−1.19) |
| 2021–24, 5 days | −0.16% | +0.08% | −0.35% (−1.65) |
| 2021–24, 21 days | −1.03% | −0.08% | −1.28% (−2.36) |

**It is a lead, not a finding.** This section has run about twenty tests, and t ≈ −2.6 does not clear a correction for that many (|t| ≈ 3). For a holder the economics are modest: selling avoids about a 1% lag over the next month, and a round trip costs 0.22%. It is the natural fourth candidate, alongside residual reversal, the 52-week high and dividend payer status, for the single pre-registered test of the reserved period, specified here before anyone has looked: a heavy-volume (1.5×) close crossing below the 50-day, against ordinary-volume crossings, 21-session excess return.

#### What the app shows

None of the entry signals improved on its control and the sell guide is only a lead, so nothing changes in the forecast. The book's rules are still a checklist many traders use, so a collapsed **📈 O'Neil-disciple checklist** expander shows, for the selected stock on daily data:

| Row | Shows | Beside it |
|---|---|---|
| Pocket pivot | whether the last session was one, and whether it was *extended* (the day's low too far above the 10-day, which the book itself says not to buy) | the measured no-edge verdict |
| Major gap-up | any in the last 21 sessions, and whether the gap day's low has held (the book's sell rule) | the measured reversal: −1.65% over the next month |
| Moving-average sell guide | the close against the 50-day and 10-day averages, and any heavy-volume break below the 50-day in the last 5 sessions | the measured lead: −1.02% against an ordinary-volume break over 21 sessions (t −2.6) |
| NIFTY distribution days | the count in the last 20 sessions, from NIFTY's bars and NSE's total turnover for the last 21 sessions, and whether the sell condition (5) is met | the model's measured result |

On 16 October 2026, TCS and Infosys both showed a pocket pivot by volume, but an extended one (the day's low 8.2% and 7.0% above the 10-day average), and NIFTY had **8 distribution days** in 20 sessions, past the sell condition. Distribution days were 21% of all sessions in the study, about 4 in a typical 20. `oneil.MEASURED` holds the verdict text, so the app cannot show a signal without its result.

#### What was not taken

| Book material | Why not |
|---|---|
| Ch. 1–4, 8–10 (the O'Neil method's principles, the authors' trading histories, ego and psychology, the "commandments", personal-development teachers) | Memoir and psychology. "Cut losses quickly" was measured as stops ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date), [§62](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time)); "buy expensive, not cheap" is the 52-week-high and momentum work ([§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it), [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)) |
| Ch. 5's choice between the 10-day and 50-day sell guides, "continuation" and "bottom-fishing" pivots, the Seven-Week Rule | Discretionary ("obeys" its 10-day or 50-day, "context") in ways that cannot be fixed in advance without inventing parameters; the 50-day core rule was tested above |
| Ch. 5 chart bases (cup-with-handle, "tight" weekly closes, "constructive" action) | Pattern judgement with no published definition; the book's examples are chosen after the fact |
| Ch. 6 short-sale set-ups | Short constraints on NSE ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)) |
| Ch. 7's volatility-adjusted thresholds and "fail-safes" | Re-chosen with hindsight and undisclosed; testing them would test the hindsight |

`oneil.py` ships with **7 tests** (`test_oneil.py`): the volume signature against its control, an extended pivot, a gap-up and its stop, distribution days and churning, the sell and follow-through state machine, the heavy-volume 50-day break and its control, and the app checklist with its live count.

### 66. UI audit: every screen size, and five bugs — one of them duplicating the prediction log

This section is a check of the app itself rather than a book. It covers two questions: does the page work on every screen size, and what breaks when it is used the way people use it. Two tools did the checking, now kept as `tools/ui_check.py`. **Chrome**, driven by Playwright, loaded the real page, submitted a run, and screenshotted and measured it at five widths: a phone (390 px), a tablet (820), a laptop (1366), a desktop (1920) and a 2560-px monitor. **Streamlit's `AppTest`** ran the interaction scenarios: Reset, an empty Submit, daily and hourly runs, a threshold change after results, a sidebar change without a Submit, and the default path of **all 20 models with the confidence check on** (43 minutes on this CPU-only machine; no exceptions, every section rendered).

#### What did not fit, and the fixes

| Where | What was wrong | Fix |
|---|---|---|
| Every chart | The legend sat inside the top-right of the plot and covered the most recent prices, a third of the plot on a phone; the title was cut off ("…Prediction: 1 da"); a forced 15 date labels turned into vertical text; the forecast's end was clipped at the edge | Legend in a row below the plot; a short title; Plotly spaces the dates by the chart's real width; automatic margins and a 5% right pad |
| Each model's section | Table and chart side by side (2:3). On a laptop the table showed the date and one price; on a tablet both were cramped | Two tabs, **📈 Chart** and **📋 Predicted values**, each full width at every size |
| The predicted-values table | Daily dates carried "00:00:00"; prices to 4 decimals (Chronos's float32 prices showed 1210.739990 even after rounding); raw column names; a 0–4 index | "Tue 20-Oct-2026", ₹ to 2 decimals, "Forecast (₹)", "Lower 95% (₹)", "Upper 95% (₹)", no index |
| The Model Comparison table | On a phone it showed Model, Predicted Price and Change; the columns the guide says to read, **Confidence** and **Basis**, were off-screen | Decision columns first (Model, Confidence, Direction, Predicted Price…), and **Model pinned** so it stays visible while scrolling sideways |
| Phones | The title wrapped to three lines at desktop size | Below 640 px: smaller headings and metric values, tighter gutters |
| The threshold box | Stretched across the full page width, 2,500 px for one number on a large monitor | Kept in a quarter-width column |

After the fixes the page never scrolls sideways at any of the five widths, no chart and no visible table is wider than the screen, and the browser console shows no errors. Every table fits its frame and scrolls inside it, which is how Streamlit's grid works on a narrow screen. One measurement artefact is worth knowing: a table inside a **closed** expander keeps the width it was first laid out at and re-measures when opened, so `ui_check.py` ignores tables in closed expanders.

#### Five bugs

| Bug | Effect | Fix |
|---|---|---|
| **The prediction log was written on every re-run, not every Submit** | Streamlit re-runs the whole page whenever a widget changes. After a Submit, each change to the threshold box (or any sidebar control) appended the entire run to the log again under a new `run_id`. Measured: 2 forecasts logged on Submit, 4 after one threshold change. A forward log that double-counts forecasts would have made the gates look better or worse than they are once outcomes were scored | Each Submit gets a token; the log and the console summary are written once per token. Now 2 → 2. Your existing log held one run and was unaffected |
| **Chronos-2 silently lost its 95% band** | `chronos_model.clean_prediction_output` matched quantile columns only if their names were floats (`0.025`); chronos-forecasting 2.2.2 names them as strings (`'0.025'`). So Chronos had no lower or upper bound, a volatility column of zeros, no band on its chart, "—" for Conviction, and no place in the risk panel's interval path. Found because the new table formatter printed the raw `0.025 / 0.5 / 0.975` columns | Quantile columns are matched by level whatever their type. Chronos now shows its band (₹1,171–1,247 on its first step for Reliance) and a Conviction. `test_quantile_columns_named_as_strings_become_the_band` |
| **The Submit / Reset colours had stopped applying** | The CSS targeted `[data-testid="column"]`, which Streamlit renamed `stColumn`. Submit rendered in the theme's default red (`rgb(255, 75, 75)`), the colour of a destructive action, and Reset plain grey | Matched by widget key (`.st-key-btn_submit`), which Streamlit keeps stable: Submit green `rgb(40, 167, 69)`, Reset red, checked in the browser |
| **Reset printed a stack trace in the terminal** | The model list and the confidence checkbox were created with a `default=` / `value=` and also set through session state by Reset, which Streamlit reports with a warning and a traceback every time | Defaults are put in session state once; the widgets take no default |
| **Reset restored a 3-day horizon; the app starts on 5** | A fresh start and a Reset gave different defaults | Both use 5 days |

Also tidied: the hourly headline read "Median Forecast (2 trading days (14 hourly bars))", now "2 trading days, 14 hourly bars".

#### Running the check again

```bash
python tools/ui_check.py scenarios                          # AppTest; never writes the real log
python tools/ui_check.py browser                             # starts its own app, prediction log off
```

`scenarios` exits non-zero on any exception, error, unexpected warning, duplicated log write, or Reset that does not restore its defaults. `browser` starts its own app with the prediction log off (since [§68](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period)), saves a screenshot at each width to `.ui_check/` and prints the overflow measurements and button colours. One new test, for the Chronos band.

### 67. Stock screens (Hough, *Your Next Great Stock*) — a falling stock's last week tells you nothing, and a mined screen's edge is what chance produces

Hough's book is a guide to stock screening: eleven screen "recipes" (Part Three), each resting on a published US study, a chapter of "guru" screens, and what to do with the handful of stocks that survive a screen (Part Four). Nearly all of it is fundamental, and [§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result) measured that yfinance holds about a year of point-in-time statement history per NSE name, so **none of the screens can be back-tested here**. Two things could be done. The app now scores the selected stock live against every recipe the free data supports, with the rule beside each result. And the book's two claims that need only prices were tested on NSE before the reserved period (`tests/validation/run_hough_screens.py`), with the hypotheses written in its docstring before it ran. The live scoring is in `hough.py`.

#### The falling-knife deal breaker (Ch. 24): last week does not matter, last year does

Hough: *"If the stock has fallen over the past year, was it still moving lower each day over the past week? If so, consider discarding it or at least setting it aside … the odds are better that a falling stock will head lower after you buy it. Better to wait until it has stabilized or even risen a bit and pay the higher price."* This project's one robust cross-sectional finding is short-term **reversal** ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)), which predicts the opposite: last week's losers beat last week's winners. Both predictions were written down first.

The panel is 332 liquid names (400 screened on 2017's turnover, at least 300 sessions each), 2018 to mid-2024. Every stock-day with a negative 252-session return is a 12-month loser. It is "still falling" when its 5-session return is below zero and "stabilised" otherwise. Returns are in excess of the equal-weighted panel, with t-statistics on monthly means:

| Group | Stock-days | 5-day excess (t) | 21-day excess (t) | 63-day excess (t) |
|---|---|---|---|---|
| 12-month loser, still falling | 90,031 | −0.11% (−1.71) | −0.60% (−2.24) | −1.90% (−2.99) |
| 12-month loser, stabilised | 76,471 | −0.18% (−2.33) | −0.70% (−2.39) | −1.72% (−2.57) |
| 12-month winner, falling this week | 106,655 | +0.20% (2.57) | +0.36% (1.30) | +0.92% (1.00) |
| 12-month winner, up this week | 135,138 | +0.09% (0.85) | +0.45% (1.34) | +1.06% (1.15) |

| Test (bar: Bonferroni α/2, \|t\| > 2.24) | Result |
|---|---|
| **A1.** Still falling minus stabilised, 21 sessions, by month | **+0.10% (t 0.57)**; 5 sessions +0.08% (0.94), 63 sessions −0.18% (−0.88); +0.23% and +0.00% in the two halves |
| **A2.** Buy a still-falling loser now, or wait until its 5-session return turns non-negative? Both end at the same place, so the difference is the stock's excess move during the wait | **waiting saved 0.31% (t −2.12)**, after a median wait of 4 sessions |
| A2 net of the average 12-month loser over the same sessions (added after the first run) | −0.08% (t −0.70) |

Neither test clears its bar. Among 12-month losers, a stock still falling this week does **no worse** over the next month than one that has stabilised, so the book's rule has no support. The reversal prediction fails at a month too; it shows only as a small 5-session effect. Waiting does appear to save money, but the decomposition says why: **every 12-month loser lags**, by about 0.6–0.7% a month and 1.7–1.9% a quarter, whatever its last week did. That is momentum, already measured here ([§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it): 12-1-month momentum t 2.82). Waiting four sessions just shortens the time spent holding a stock that lags; net of that lag, the week's direction adds −0.08%. So the useful part of the deal breaker is *"it has fallen over the past year"*. The *"still falling this week"* part adds nothing.

#### Data mining (Ch. 6): the XYZ strategy, on NSE

To show how a backtest can lie, Hough built an "XYZ strategy" in twenty minutes: S&P 500 stocks whose names begin with X, Y or Z, which had beaten the index over one, three and five years. The same experiment on NSE groups the panel by the first letter of the symbol (22 letters with at least five names), picks the three best letters on 2018-01 to 2021-03 and holds them on 2021-04 to 2024-06:

| | In sample | Out of sample |
|---|---|---|
| N (best letter in sample) | +11.4%/yr (t 1.83) | −0.3%/yr (t −0.04) |
| T | +10.3%/yr (**t 2.13**) | +7.4%/yr (t 1.52) |
| B | +8.2%/yr (t 1.78) | −0.2%/yr (t −0.06) |
| **The three together** | **+10.0%/yr** | **+2.3%/yr** |
| The best three of 1,000 random relabellings (same group sizes), median | +12.8%/yr (95th percentile +18.0%) | −1.7%/yr |

Picking the best three of 22 arbitrary groups buys about **+13% a year in sample by chance alone**, and the real letters did a little worse than that (13th percentile of the relabelled null). Two of the 22 letters were "significant" at 5%, about what 22 tries should produce. One letter did hold up out of sample, which makes it a test of Hough's other trap, the **lurking variable**. 'T' holds 24 names, 14 of them Tata group companies, which share an owner and tend to move together, so the group looked like the explanation (that split was added after the first run). The obvious reading turns out wrong: split out of sample, the Tata names earned +2.9%/yr (t 0.46) and the other ten +13.1%/yr (t 2.02). Splitting a winner after the fact until one piece looks significant is the same search again. And the three letters' +2.3%/yr out of sample sits at the 88th percentile of what the random picks did afterwards: better than most, not rare.

For this project the number to remember is the null's 95th percentile. A rule found by searching among 22 options must beat about **+18% a year in sample** before its in-sample figure means anything. That is the selection bias the Reality Check, the SPA test and the Probability of Backtest Overfitting ([§52](#52-hilpischs-technical-rules-optimised-and-tested-python-for-algorithmic-trading-ch-4--the-probability-of-backtest-overfitting)) exist to price, and the reason every test in this README is written down before it runs.

#### Follow the Leaders (Ch. 19): insider buying, the one screen with point-in-time data

This is the one screen in the book NSE data can test honestly. SEBI's insider-trading rules (2015) make promoters, directors, key managerial personnel and designated employees disclose a trade within two trading days, and NSE publishes each disclosure with the time it went out, the mode, the person's category, the value and the holding before and after. Unlike a statement ([§32]({S32})), a disclosure can be dated to the moment the market could see it. `insiders.py` reads and caches them: **199,395 disclosures, January 2018 to June 2024**.

The book's screen, coded before running (`tests/validation/run_insider_buying.py`): in the trailing 90 days, at least two **open-market purchases**, at least $100,000 in total (₹88 lakh) and under 5% of the shares, by executives (key managerial personnel), directors or promoters. An ESOP allotment, a pledge, a gift or a transfer between promoters is not a decision to buy at the market price, and designated employees and relatives are not the book's insiders, so none of those count. An event is the first disclosure that meets the screen, then nothing for that stock for 90 days, entered at the close of the first session after the disclosure's date.

Insiders tend to buy after a fall: in the 63 sessions before entry the median stock was down 3.2%, and 59% were down. This project has measured both momentum (12-month losers lag) and short-term reversal (last month's losers bounce), so the one pre-registered test compares each event with stocks in the **same quintile of 12-month and of 1-month return** on that day, over 63 sessions. The universe is the liquid panel (339 names), with events from 2019, once a 12-month return exists for the match.

| Group | Events | 21 sessions, matched (t) | 63 sessions, matched (t) | 126 sessions, matched (t) |
|---|---|---|---|---|
| **The book's screen** | 252 (100 stocks) | −0.01% (−0.02) | **+1.71% (1.43)** | +3.00% (1.21) |
| Two or more distinct buyers | 113 | −0.62% (−0.68) | +2.70% (1.51) | +4.69% (1.83) |
| One buyer, repeated | 139 | −0.55% (−0.55) | +1.35% (0.89) | +2.76% (0.79) |
| ₹10 crore or more | 105 | −0.59% (−0.59) | +0.13% (0.06) | +1.52% (0.51) |
| First half (to Oct 2021) | 191 | −0.56% (−0.77) | +1.71% (1.16) | +1.05% (0.27) |
| Second half | 61 | +0.66% (0.54) | +1.70% (0.90) | +5.60% (2.54) |
| Open-market **sales**, same recipe | 323 | −0.40% (−0.64) | −0.57% (−0.69) | −2.81% (−1.84) |

**The test is +1.71% over a quarter (t 1.43): almost exactly the book's six points a year (+1.5% a quarter), but not distinguishable from zero.** Its standard error is about 1.2%, so this sample would need roughly twice as many events to separate an effect of the book's size from noise. The exploratory rows lean the book's way too, without any of them being significant: several buyers do better than one, and sales are followed by lagging. The book's "executives beat board members" refinement cannot be tested here: only **4 of 252** events had a key managerial person among the buyers, and 221 were promoters alone. Indian insider buying is mostly promoters adding to their stake, closer to the book's "major shareholders" than to its executives.

So this is a plausible, book-sized effect that six years of liquid NSE stocks cannot confirm. It is a natural fifth candidate for the reserved period, alongside residual reversal, the 52-week high, dividend payer status and the heavy-volume 50-day break, specified here before anyone has looked: the book's screen, 63-session excess over the 12-month and 1-month matched benchmark. The panel also leaves out where the book says the effect is strongest, small companies few analysts follow. Widening the universe would be a second, separate test, not a re-run of this one.

**NSE changed its system during this work.** The endpoint the archive comes from stops on 2 May 2026. Since then NSE lists filings at a new endpoint with only the company and time, and the trades sit in each filing's XBRL file, with percentages as fractions. `insiders.fetch` reads both, so the app's 90-day view works across the switch. The study, which ends in June 2024, uses only the archive.

#### Ch. 6's five signs, applied to the five reserved-period candidates

Hough's Ch. 6 says a strategy worth following has five signs: it **worked in the past**, there is **a reason** it works, **no lurking variable** explains it, it is **practical** after costs, and it can be **screened for**. This project has queued five leads for its one-shot test of the reserved period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)), and the signs are a fair way to rank them. A sixth column asks the question the signs leave out: would the reserved period, about 1.55 usable years so far, even have the **power** to confirm each one? Power assumes the in-sample effect is the true one, which is optimistic, most of all for a lead picked from many tests (`tools/holdout_power.py`).

| Candidate | Worked before 2025 | A reason | No lurking variable | Practical after costs | Screenable | Power in the reserved period |
|---|---|---|---|---|---|---|
| **Residual reversal, k = 5** ([§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)) | ✅ rank IC t −8.08, positive on every starting day | ✅ over-reaction and liquidity provision | ✅ not bid-ask bounce: present at every price-precision level, and NSE's close is an auction ([§46](#46-price-precision-buzzelli-data-quality-engineering-ch-3--the-dimension-that-was-missing-and-a-falsification-of-38)); common factors removed | ❌ breaks even at 15.2 bp against 22 bp for delivery, needs the short side, and lives mostly in names without futures ([§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)) | ✅ prices only | **98%** |
| **52-week high** ([§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it)) | ⚠️ IC t 1.85; the book's return t ≤ 1.56 | ✅ anchoring on the high (George & Hwang) | ✅ survives 12-1 momentum and the 21-day return (t 1.70) | ⚠️ slow (turnover 1.8 a month), but the return is on the short side (+0.90% a month); the long side alone is +0.17% | ✅ | 17% |
| **Dividend payer** ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)) | ⚠️ yield IC t 2.91 as one of four factors; the payer split (t 2.00) was found by attacking it | ⚠️ the reason changed under testing: paying at all (quality), not the yield | ❌ probably profitability in disguise, which cannot be controlled without point-in-time statements ([§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)); not low volatility | ✅ long-only, slow, cheap | ✅ corporate-action feed | 20% |
| **Heavy-volume 50-day break** ([§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market)) | ⚠️ −1.02% against ordinary-volume breaks (t −2.55), same sign in both halves, but one of about 20 tests | ✅ heavy selling through a level many traders watch | ⚠️ the control fixes the price pattern; results days, when volume spikes, are not separated ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)) | ✅ a sell rule for a holder: avoids about 1% for a 0.22% round trip, no shorting | ✅ | 24% |
| **Insider buying** (above) | ❌ +1.71% a quarter, t 1.43, one pre-registered test | ✅ insiders know their company | ✅ matched on 12-month and 1-month return; ⚠️ not on size | ✅ long-only, held a quarter | ✅ point-in-time disclosures | 12% |

The table splits the candidates in two. The **most believable and usable** are the heavy-volume 50-day break and insider buying: each has a reason, survives its obvious lurking variable, and could be acted on without shorting. But they are also the ones the reserved period **cannot** settle. Even if their in-sample effects are real, a test now would clear the bar about one time in four or eight. The one candidate with real power, **residual reversal**, is the one that cannot be traded, so confirming it would strengthen this project's main positive finding without changing anything a user does.

Spending the one-shot test now on a practical candidate would almost certainly return a t near 1: an inconclusive answer, and the reserved period gone. The period gains power every month it stays sealed, but slowly. At the optimistic rates above, the 50-day break reaches even odds after about 3.8 years of reserved data (late 2028) and 80% power after 7.8; insider buying would need a decade. **Opening the reserved period is the owner's decision**, and this section only records the evidence for it. Two things follow from it:

- **The heavy-volume 50-day break is the best use of the reserved period**, but not yet. Specified in [§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market) before anyone looked, it would be worth testing once about four years of reserved data exist.
- **Residual reversal can be confirmed without touching the reserved period.** July to December 2024 lies before it, and no panel study here has used it, since every one stops at June 2024. Half a year gives residual reversal about **63%** power and the other candidates under 10%. So that window is the cheap, free place to check the project's strongest result first.

#### Residual reversal confirmed on July–December 2024

The second recommendation was run (`tests/validation/run_reversal_confirmation.py`), with everything fixed before the data was loaded. The signal is [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)'s, imported unchanged from its driver: k = 5, a 252-day PCA window, a 5-day signal and hold. The universe is 400 names by liquidity, screened on the year before July 2023, with prices from July 2023 so the first PCA window is full by July 2024. The one test is the k = 5 rank IC, needing t < −1.96. The cache also holds 2025–26 days, downloaded on 1 September 2026; `build_panel` refuses to read them, the holdout ledger is still empty, and nothing here asked.

| Signal | Rank IC, Jul–Dec 2024 (t) | Published, 2019–2024H1 (t) | Gross per 5-day rebalance | Breakeven |
|---|---|---|---|---|
| raw | −0.0337 (−2.37) | −0.0266 (−4.16) | +0.47% | 27 bp |
| residual, k = 1 | −0.0178 (−1.28) | −0.0315 (−5.97) | +0.33% | 19 bp |
| residual, k = 3 | −0.0284 (−2.33) | −0.0306 (−6.80) | +0.46% | 27 bp |
| **residual, k = 5 (the test)** | **−0.0245 (−2.21)** | −0.0335 (−8.08) | **+0.40%** (+0.11% … +0.69% across phases) | 23 bp |

**Confirmed out of sample.** Over 112 signal days in 398 stocks the k = 5 IC is −0.0245, 73% of the published size, and clears its bar. The IC is negative on 63% of days. This project's one strong result now holds on data no study here had used.

It does not change the cost verdict. This half-year's gross was about 1.5 times the in-sample +0.26%, which puts its breakeven (23 bp) just above a 22.2 bp delivery round trip. But one half-year is not a cost test: the in-sample average over 5.5 years broke even at 15.1 bp. The book still needs a short side that most of the universe does not offer, and stock futures don't rescue it ([§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)). The reserved period is now free for the candidate that most needs it, the heavy-volume 50-day break ([§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market)), once enough of it has accumulated.


#### What the app shows

A collapsed **🔎 Stock screens** expander follows the company check, with four headline figures: screens passed, the Piotroski F-score, return on invested capital and the net payout yield. It has five tabs:

| Tab | What it holds |
|---|---|
| **Screens (Part 3)** | Each recipe the book gives, with ✅ passes, ❌ fails (and the first two reasons), ⚠️ partly measurable, or ➖ can't be run here, then every criterion with this company's figure. Buy High Sell Higher (Ch. 12), Impatient Value (Ch. 13), Accrual to Be Kind (Ch. 20), Sales on Sale (O'Shaughnessy's Cornerstone Growth, Ch. 21, against NIFTY 50's 3- and 6-month change), Combination Platter (Piotroski, Ch. 22), Follow the Leaders (Ch. 19, from the live SEBI disclosures, with market value under $10 billion and six or fewer analysts) and Buffett-, Lynch- and Zweig-style screens (Ch. 23) are scored. Surprise Surprise, Bold Is Beautiful and Rising Expectations need analyst estimates, revisions and ratings; New Dogs needs a whole index ranked by net payout yield; Tomorrow's Breakthrough needs R&D, which most NSE filers do not report separately. Those are listed as can't-run, with the reason |
| **Survivor checks (Ch. 24)** | Deal breakers: a sudden two-session plunge (check the news), the falling knife with its measured verdict, a buyout chart (a jump, then a flat line), debt against half a year's income, ownership concentration, and value traded per day. Then "talk yourself out of it": earnings growing at least as fast as sales and EPS at least as fast as earnings, loss or sharp-fall years, the PEG, operating plus investing cash flow against profit, persistently positive financing cash flow, the F-score, Hough's ROIC (tax floored at 25%), Sloan's accruals and the net payout yield |
| **When to sell (Ch. 25)** | Recurring "one-time" charges, regular share issuance by a management that owns little, the cash share of assets, and the book's growth-versus-value selling rules |
| **F-score (Ch. 22)** | Piotroski's nine signals one by one, latest fiscal year against the one before |
| **Insider trades (Ch. 19)** | The last 90 days of open-market purchases and sales by the stock's executives, directors and promoters, whether the book's screen is met, the filings not counted (ESOP, pledges, transfers) and the measured verdict. On 19 October 2026 NCL Industries showed 45 purchases by 5 promoters and directors (₹6.5 crore), meeting it; TCS and Reliance had no filings in 90 days |

Adapting a 2008 US book to NSE took five decisions, all stated on screen:

- **The latest fiscal year** stands in for trailing twelve months. That is the book's own "easy method" (Ch. 16); yfinance's quarterly history is too short for a TTM sum.
- **Dollar cut-offs are converted at ₹88/$**, not inflation-adjusted, since the book calls them rough ("say, sales of $100 million").
- **Insiders.** yfinance's "insiders" on NSE are mostly promoters, and SEBI's minimum public shareholding caps promoters at 75%. So Ch. 24's "pitch stocks more than three-quarters owned by insiders and institutions" would discard most of the NIFTY, and is shown as context instead.
- **Industry comparisons** are reported as not measurable rather than guessed.
- **Lenders** get no F-score, ROIC, accruals or cash-flow tests. Piotroski excluded them, and a bank's operating cash flow is its deposits and loans.

On 19 October 2026 the three stocks it was tried on read very differently. **Asian Paints** scored 8 of 9 on the F-score with a 16.4% ROIC and passed no screen (a P/E of about 47 on 1.8% a year of EPS growth, a PEG near 27). **TCS** scored 4 of 9 with a 43% ROIC and a 4.4% net payout yield. For **HDFC Bank** it scored no F-score (a lender), and EPS growth was 1.0% a year against 12.5% for profit, the dilution of its 2023 merger.

#### Three data defects found on the way

| Defect | Effect | Fix |
|---|---|---|
| **Statements filed in US dollars** | Infosys reports to yfinance in USD while its market value is in rupees. The company check's "price × tangible book" ([§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)) divided rupees by dollars and read **563×** instead of 6.4×; its P/E fallback had the same flaw | `stock_checklist.statement_fx` converts statement money before it meets the market value, and returns NaN for a currency pair it does not know, so the ratio shows as unavailable rather than wrong |
| **Yahoo's own price/sales is wrong for a USD filer** | Infosys's `priceToSalesTrailing12Months` reads 227.9 | Computed from market value and converted sales whenever the currencies differ, in both modules |
| **Reported EPS is not consistently restated for bonus issues** | HDFC Bank's diluted EPS reads 88.68, 44.16, 44.82, 45.75 across its 2025 1:1 bonus, and its basic EPS swaps between 44 and 88. Taken at face value its EPS fell 20% a year | EPS here is net income per year-end share (the balance sheet's count is restated consistently). Per-share growth is refused across any year whose share count moved by 40% or more, a bonus, split or merger, with the reason shown |

#### What was not taken

| Book material | Why not |
|---|---|
| Part One and Ch. 7–10 (why to own stocks, efficient markets, behavioural finance, reviews of 2008 US screening websites, where statement numbers come from) | Background. Ch. 10's glossary of clues is what the screens above are built from |
| Back-testing any fundamental screen | No point-in-time statement history ([§32](#32-fundamentals-the-right-experiment-blocked-by-data--the-seventh-negative-result)) |
| Surprise Surprise (Ch. 14), Bold Is Beautiful (Ch. 17), Rising Expectations (Ch. 18) | Analyst estimates, individual revisions and rating changes; no free feed carries their history for NSE |
| Follow the Leaders (Ch. 19) | Insider purchases. NSE publishes SEBI insider-trading disclosures, but they are not wired in; the natural next data source if this is taken further |
| New Dogs (Ch. 16) as a ranking | Ranking the NIFTY 50 by net payout yield needs fifty statement fetches per view. The yield itself is shown |
| Industry-median criteria; Ch. 23's Buffett "retained earnings against market value" test | Need every company in the industry; dividend-adjusted price history makes the second unreliable |
| Ch. 25's tax timing | US tax law |

The Ch. 12 and Ch. 13 momentum leg (within 5% of the 52-week high) was already tested in [§53](#53-the-52-week-high-yan-python-for-finance-ch-8--the-book-has-the-sign-backwards-and-the-data-cannot-settle-it), and the screen shows that verdict beside it. `hough.py` ships with **8 tests** (`test_hough.py`): the F-score and a single point lost, ROIC with the tax floor, debt and accruals, the Lynch PEG with dividends, a bonus issue that must not read as dilution, USD statements (including the company check's fixed ratios), lenders, the chart deal breakers, and screen statuses. `insiders.py` ships with **8 tests** (`test_insiders.py`): normalising and de-duplicating rows, which trades count, the recipe's three conditions and its 90-day window, events that never use a later filing, the monthly cache and its refusal of the reserved period, the new XBRL format, fetching from both endpoints, and the live view with the scored screen. `tools/ui_check.py scenarios` now also fails if a daily run is missing the company check or the stock screens.

### 68. Second end-to-end audit — a polluted prediction log, a mislabelled median, and a runner that cannot read the reserved period

With the last book done, one pass over everything, end to end. That covered static analysis, the test suite and the document checks, every research driver re-run and compared with its stored result, the app's interaction scenarios, the page in a browser at five widths, and the default path of all 20 models.

#### What ran

| Layer | Result |
|---|---|
| Static analysis (ruff: pyflakes, syntax, loop-closure and mutable-default rules) over 63 modules, 49 test files, 66 drivers and the tools | No undefined name or syntax error. 16 loop-closure warnings, every one called within the same iteration; 4 unused variables, all leftovers (Kalman's forecast is centred on the filtered level by design, not on the last price) |
| `pytest tests/` | 710 passed at the start; 715 after the fixes below (five new tests) |
| `tools/check.py --tests`, `run_app.py --check` | clean; every required package installed |
| 62 research drivers under `tools/run_drivers.py` | 42 ran offline, guarded. The 3 Kanwar & Gupta drivers needed TA-Lib (validation-only), installed at the owner's request (0.8.2, a prebuilt wheel; no other package changed). The other 20 read live prices, so the reserved period: run with the owner's approval on 20 October 2026 (below), all 20 clean |
| Their 48 result files | All 48 reproduce exactly or to within 1e-6 in a final sweep after the fixes, with no driver printing a caught error. The 4 that differed in earlier sweeps are explained below |
| `tools/ui_check.py scenarios` | 0 problems |
| `tools/ui_check.py browser`, five widths | no sideways scroll, nothing wider than the screen, Submit green and Reset red, no console errors |
| All 20 models, confidence check on | Reliance, default path, prediction log stubbed: no exception or error. The first run rendered 19 of 20, because Regime Switching failed (the first bug below). After the fixes all 20 render, and every predicted-values table shows only the date, the forecast and the 95% band |

#### A driver runner that cannot read the reserved period

Re-running every driver is only safe if none of them can read the reserved period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)). [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found) re-ran two yfinance drivers by mistake, because some reach yfinance through a module they import and a search for the word misses them. `tools/run_drivers.py` makes the mistake impossible rather than unlikely. Each driver runs in its own process with three routes closed:

- a stand-in `yfinance` that raises on any use;
- `safe_fetch`'s last-known-good cache pointed at an empty folder, since otherwise a blocked download would be answered from stored prices that run past 2025;
- `get_data`'s two live price fetchers, including its nselib fallback, raising too.

A marker file records a driver that touched any of them even if it caught the error, so it is reported **BLOCKED** rather than as a success on no data. Output goes to a file and a timeout kills the whole process tree. The first version read a pipe, and two drivers that had already written their results "ran" for 9.5 hours because their worker processes held it open. Every result CSV is backed up, compared with the fresh output and restored. The 20 drivers it blocked are the ones the project already knew read live prices.

#### Bugs found and fixed

| Bug | Effect | Fix |
|---|---|---|
| **NSE corporate actions dropped silently when a request failed** | `bhavcopy.corporate_actions` fetches in 6-month chunks and skipped any chunk whose request raised. The panel was then adjusted without that window's splits and bonuses (a missed 1:2 split reads as a −50% day), with no warning. It surfaced as results that changed between runs: two LightGBM studies drifted only when two sweeps ran at once and NSE refused requests under load. And `get_data`'s nselib fallback, written to "degrade to raw close and say so" on a failed fetch, reported "adjusted, 0 actions" on unadjusted prices instead | Each chunk is retried three times with a back-off, and a chunk that still fails raises an error naming the window. Run alone after the fix, both studies give identical output twice and match their stored files exactly, so the published evidence stands. Two tests (`test_bhavcopy.py`) |
| **Regime Switching's fit depended on whatever ran before it** | statsmodels draws the random restarts of the Markov-switching search from NumPy's global random state, so the model's forecast changed with the models run before it. On one Reliance series the fit failed outright under 1 of 30 states, and settled on AR(2) or AR(1) depending on the state. It is how Regime Switching dropped out of the 20-model run | Fixed seeds for the search, the caller's state restored, and a specification retried with other seeds and then without random restarts before it is simplified: 0 failures in 30 states, one identical fit. Two tests (`test_regime_switching.py`), both failing on the old code |
| **With market context on, four models crashed** | `direct_forecast.compute_origin_row` filled missing features with an integer 0, and pandas 3 refuses to write the context overlay's floats into the resulting int64 column. With `STOCKAPP_USE_MARKET_CONTEXT=1`, XGBoost, LightGBM, the Stacking Ensemble and Quantile (LGB) all raised "Invalid value … for dtype 'int64'". The default (context off) was unaffected | The origin row is float throughout; `test_a_market_context_column_reaches_the_origin_row` fails on the old line |
| **The predicted-values table mixed units under one heading** | Models also return internals, and `volatility` is a rupee spread in some (Kalman, the ensembles, ML, Chronos) and a return standard deviation in others (HAR-RV, Vol-LSTM, Regime Switching, the ARIMA family). Shown raw, 0.0123 and ₹25.40 sat under the same name; Prophet added a raw `trend`. Nothing downstream reads either column | The table shows Date, Forecast and the 95% band only; `ui_check.py scenarios` now fails on any other column |
| **Test runs in the forward prediction log** | The browser checks of [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)'s panel ran against a real app, so their two quick runs (Asian Paints and NCL Industries, 20 forecasts, 19 October 2026) were logged as real forecasts. `ui_check.py browser` had the same design | Both runs removed (a backup kept); the log holds its one 3M India run again. `ui_check.py browser` now starts its own app with `STOCKAPP_USE_PREDICTION_LOG=0` and stops it afterwards; the log's checksum was unchanged across a full browser run |
| **A mislabelled median** ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)) | The ≥ 5% dividend band's 1.00 was its yield-weighted figure in the median column; the median is 0.94. So "the price falls by 81–100% of the dividend" in the README, the docx and the app's ex-dividend notice | 81–94% everywhere; `corporate_events.DROP_RANGE` = (0.81, 0.94) |
| **Same-day dividends counted twice** | A final and a special dividend going ex on one day (L&T 2023, ₹6 + ₹24; Nestlé 2021; RCF 2022; three more) were two events, each set against the whole drop (L&T's ₹6 read as a 57% drop ratio), in arbitrary order, which is why the file did not reproduce | One event with the summed amount: 2,072 → 2,066 events, every band median unchanged. The app's notice already summed them |
| **Two drivers reported success on no data** | `run_cross_sectional_clf.py` and `run_class_weight_ab.py` printed "cannot continue" and exited 0 | Exit 1 |
| **`.gitignore` named the wrong cache** | It listed `.cache/`; `safe_fetch` writes `.data_cache/`, whose pickles were ignored only by the `*.pkl` rule | `.data_cache/` |
| **A late crash without TA-Lib** | `run_kanwar_setup.py` built its panel and then failed with a traceback; the other two Kanwar drivers check first | The same check up front |
| **Small things in [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)'s insider code** | `insiders.py` kept its own copy of ₹88/$; the 90-day insider fetch (about 20 seconds for an active stock) showed no spinner; a missing share count printed "nan" | One shared rate; a spinner; "—" |
| **The driver runner's own two mistakes** | The first version of `tools/run_drivers.py` restored "new" CSVs by deleting them, and so deleted the holdout ledger it had just written; and it kept each driver's output in a temporary folder, so errors a driver caught and printed while still exiting 0 could not be read | The ledger is never touched (it was recreated with its original timestamp); every driver's output is kept in `.driver_logs/` (gitignored) and scanned for caught errors |
| **A "nan%" in the insider study** | Its 4-event "executive among the buyers" row printed nan, since a monthly t needs 10 events | "too few" |

#### Results that did not reproduce, and why

| File | Difference | Cause | Verdict |
|---|---|---|---|
| `open_interest.csv` | 540 more rows | The ten trading days (29 October – 11 November 2024) recovered by [§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)'s bhavcopy fix, × 54 names; all before the reserved period | [§41](#41-open-interest-and-a-look-ahead-worth-29-sigma--the-thirteenth-negative-result) re-measured: 489 dates, naive IC +0.0181 (t 2.65), honest −0.0000 (t −0.01), against the published +0.0198 (2.88) and −0.0018 (−0.27). Same conclusion; file updated |
| `universe_expansion.csv`, `universe_seeds_n400_201801_202406.csv` | IC and t differ | Never refreshed after [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code) removed `bb_position`. [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found) re-measured and published the 29-feature numbers, and the fresh runs reproduce those exactly (+0.0352, t 2.01 at 400 names; seed median IC +0.0372, t +2.40) | Stale evidence files, updated. Run twice, the driver gives identical output |
| `dividend_dates.csv` | 6 rows | Same-day dividends in arbitrary order | The bug above; file updated |

#### The 20 drivers that read the reserved period

These 20 fetch live yfinance prices up to today, so running them reads the reserved period ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)), which the owner approved on 20 October 2026 for a bug check. `run_drivers.py --allow-live` ran them without the guard. It wrote one row per driver that reads past 2024 to `tests/validation/holdout_ledger.csv` before starting, and restored every result CSV afterwards, so no published figure takes in 2025–26 data. The forward prediction log's checksum was unchanged. (Three of the 20, `run_market_breadth.py`, `run_oneil.py` and `run_bhavcopy_audit.py`, ask for data only to 2024 and have no row.)

All 20 exited cleanly, in 1 hour 33 minutes. They were run a second time to keep and scan their output (the first run's was not kept), and every line the scan flagged was a statistical verdict the drivers print by design ("FAILS joint test" from the VaR backtest, for one). The ledger therefore holds **34 rows: 17 drivers, twice**. None of them computes a queued candidate's pre-registered statistic ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)). Their output was read for errors only, never for results, and the logs of the live runs were deleted once scanned. The one-shot test of the five candidates is unaffected.

#### Not covered

One known limitation, already in the caveats, was confirmed rather than fixed: **Hybrid ARIMA+LSTM** is the one model that returns no 95% band, so its table has none, its Conviction is "—" and the risk panel leaves it out. A band for it would need walk-forward refits of its LSTM, a model change rather than a fix. *(Since fixed: [§69](#69-a-95-band-for-hybrid-arimalstm--the-last-model-without-one-and-two-slow-paths-found-on-the-way) gives it a split-conformal band, 95.4% coverage out of sample.)*

The 20 blocked drivers read live yfinance prices up to today, and so the reserved period; they re-run only with the owner's approval. And no check can cover a live source changing under the app on a given day, as NSE's insider feed did on 2 May 2026 ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)).

```bash
python tools/run_drivers.py                         # every driver, offline-guarded, CSVs compared and restored
python tools/run_drivers.py run_oneil --keep        # one driver, keeping its fresh CSV
python tools/ui_check.py scenarios
python tools/ui_check.py browser                    # starts its own app with the log off
```

### 69. A 95% band for Hybrid ARIMA+LSTM — the last model without one, and two slow paths found on the way

[§68](#68-second-end-to-end-audit--a-polluted-prediction-log-a-mislabelled-median-and-a-runner-that-cannot-read-the-reserved-period) left one known limitation: **Hybrid ARIMA+LSTM** was the only one of the 20 models with no 95% band. The cost showed across the app: no range on its chart or table, "—" for Conviction (the forecast move against the model's own band), and no part in the Risk & Probability panel. It was never a hard problem. The other recursive models (LSTM, GRU, Transformer, TCN, N-BEATS) already get their bands from `model_utils.forecast_nn_conformal` with a single fit, and Hybrid had simply not been moved onto it.

#### How the band is built

Horizon-wise **split conformal**, as for the other recursive models:

1. ARIMA and the residual LSTM are fitted on the earlier 80% of the 750-session window only.
2. From up to 80 origins in the recent 20%, the ARIMA is brought up to date with the actual returns before the origin, and the hybrid's own recursive 5-step path is run. The absolute log error at each step is recorded.
3. The finite-sample 95% quantile of those errors is the half-width at that step, so the band widens with the horizon and carries the model's real multi-step error.
4. The forecast comes from the same models updated with every return, wrapped in `price × exp(±half-width)`.

As with the other recursive models, the networks train on about 80% of the window. That is the textbook trade, and it keeps the calibration honest.

#### Two slow paths found on the way

The first working version took **282–351 seconds** per forecast instead of about 45. Two separate causes:

| Cause | Fix | Effect |
|---|---|---|
| The recursive path called pmdarima's `update()` with each of its own predictions, and every call re-estimates the ARIMA's parameters, about 300 calls per calibration | Fed its own predictions with fixed parameters, an ARIMA's path is exactly its multi-step forecast: statsmodels' `append(..., refit=False)` then `forecast(h)` | 75× faster. On an AR(2) the forecasts differ by at most 0.00009 in log return, under 1% of a day's move; the old drift came from re-fitting on the model's own output |
| Calling the Keras LSTM directly, once per origin and step, runs eagerly, and with `recurrent_dropout` that means a step-by-step loop in Python on each of 365 calls | All origins move one step per batched, compiled `predict`: 5 calls instead of 365 | Calibration now takes about 6 seconds |

A forecast now takes **54 seconds**: the LSTM's training (45 s, unchanged), ARIMA (under 1 s) and calibration (about 6 s). In the app, with the confidence check's walk-forward runs, Hybrid alone took 222 seconds for Reliance.

#### Does it hold 95%?

`tests/validation/run_hybrid_coverage.py`, written down before running: six names drawn with a fixed seed from the 40 most liquid NSE stocks, 8 forecast origins each from July 2021 to June 2024, before the reserved period. Each forecast sees only prices up to its origin and is scored on the next 5. The test was pooled coverage of at least 90%.

| Step | Coverage | Mean band width |
|---|---|---|
| 1 | 95.8% | 8.8% of the price |
| 2 | 97.9% | 12.1% |
| 3 | 97.9% | 15.5% |
| 4 | 93.8% | 17.2% |
| 5 | 91.7% | 19.6% |
| **All 240** | **95.4%** (Wilson 92.0–97.4%) | |

**It passes, with the 95% target inside the interval.** By name it ranges from 90% (ICICIBANK) to 100% (BANKBARODA, SUNPHARMA), and the 48 origins' interval is 85.4–98.7%. Steps share an origin, so the honest sample is 48, not 240.

#### What changes in the app

In a run with Hybrid alone (Reliance, confidence check on), its predicted-values table shows the 95% band. Its Conviction reads −0.05 instead of "—", and the Risk & Probability panel now reads it ("approximate read across 1 model"). Its Confidence verdict is unchanged, since that comes from the separate walk-forward test of the point forecast. All 20 models now return a band. Four tests (`test_hybrid.py`): the path's arithmetic with a stand-in network, a batch of origins against one at a time, a widening band end to end, and the ARIMA-only fallback for a very short history.

### 70. The charts — a cone from the last close, trading days side by side, and every model on one chart

Each model's chart was a line through the last 50 closes, with a dot on each, and the forecast and its 95% band after it. Plotly calls every line trace `Scatter`, which is why it looked like a scatter plot. A line was the right base, since the closing price is what every model forecasts, but six things in the drawing worked against it. The charts now come from a separate module, `charts.py`, made of plain functions of DataFrames. Unlike `UI.py`, which runs the whole page when imported, it can be tested directly.

| What was wrong | Fix |
|---|---|
| **The cone did not start at the last close.** The band began at the first forecast day already at full width (₹2,320–2,620 for TCS), so its widening, the whole message, was lost | The band starts at the last close with zero width and fans out step by step |
| **Weekends and holidays took space on the axis.** The five forecast sessions sat unevenly (three, a gap, two), and history had a stretched segment over every weekend | Days with no bar are removed from the axis, and on hourly charts the overnight gap as well, so trading sessions sit side by side |
| **A dot on each of 50 closes**, and no mark between history and forecast | A plain history line with values on hover; a dashed "last close" line; the band named "95% range" (a forecast range, not a confidence interval) |
| **Only a line of closes** | A **Line / Candles** switch above the charts. Candles show each session's open, high, low and close, scaled by `adj_close / close` so they sit on the same dividend- and split-adjusted basis as the forecast; without that, they would not meet the forecast after a dividend |
| **Up to 20 separate charts, each on its own scale**, to see whether the models agree | **All models together**, above the per-model charts: each model's median path from the last close, the median of their paths (black) and the median of their 95% ranges (grey), against the random walk. 30 sessions of history give the forecast room on a phone, and the model lines share one legend entry, with hover naming each, since one entry per model made a 24-row legend on a phone |
| **Bands that narrowed with the horizon** (below) | `model_utils.widen_to_monotone` |

In a six-model TCS run the comparison chart showed five models on the random walk and one forecasting about ₹2,250 against ₹2,515. That is the kind of disagreement the per-model charts did not show at a glance.

#### Bands that narrowed with the horizon

A 3-day range narrower than a 2-day one has no meaning for a cumulative price, but most models produced one. Each of the 20 models was run to 10 days ahead on Reliance and TCS, and each side of its band measured as a distance from the forecast:

| | Reliance | TCS |
|---|---|---|
| Models whose band narrowed at some step | 15 of 20 | 7 of 20 |
| Worst single narrowing | 1.2 points of the price (N-BEATS) | 5.4 points (N-BEATS: 19.6%, 15.3%, 35.1% wide at days 1–3); HAR-RV 4.8 points |
| Never narrowed | ARIMA-GARCH, ARIMAX, Regime Switching, Kalman, Chronos | the same, and 8 more |

The pattern points at the cause. The bands that never narrow come from whole simulated price paths. The ones that do are calibrated separately at each step (conformal per-step quantiles, HAR-RV's per-step multipliers, Prophet's), so each step's width carries its own sampling noise.

`widen_to_monotone` replaces each side's distance from the forecast by its running maximum over the steps, so a band can only widen or hold. It runs inside HAR-RV, where it was first seen, and once on every model where the app runs it (`UI._run_one_model`). It only widens, so coverage cannot fall. The cost is that a single noisy spike carries forward: HAR-RV's 39.5% at day 4 for TCS now holds until day 8. Smoothing that pulls spikes down as well (isotonic regression) would give tighter bands but could drop coverage below 95% at some steps, and for a risk tool the wide side is the safe side. Research drivers that evaluate a model directly are unaffected; this changes only what the app shows.

Checked in Chrome at phone and laptop widths, in both styles: nothing wider than the screen, no console errors. Six tests (`test_charts.py`): the cone's start, trading-day gaps including a holiday and the hourly overnight break, candles on the adjusted basis (and the fallback to a line without OHLC), the comparison chart's lines and median, missing columns, and a band that may not narrow.

### 71. Adaptive conformal for every model, and the novelty gate in a real crash — neither earns its place

Two follow-ups chosen after the last book, both about whether the 95% range holds when the market changes, and both run on data before the reserved period. Both failed their pre-registered tests, so neither changes what the app shows. The second run is the stress test §25 had left open.

#### Adaptive conformal for the eleven conformal models: not shipped

Eleven models (LSTM, GRU, Transformer, TCN, N-BEATS, CNN-LSTM, XGBoost, LightGBM, Stacking, Hybrid, Kalman) set their 95% band from a block of recent calibration errors, about 190 of them for daily data, and take a fixed quantile. A fixed quantile of the last nine months is right on average and could be wrong exactly when volatility has just changed. HAR-RV and Vol-LSTM already adapt with ACI ([§12](#12-volatility-forecasting-with-har-rv); Gibbs & Candès 2021), and the same procedure, batched, is now `model_utils.aci_quantile`, identical to HAR-RV's to 1e-16.

`run_aci_bands.py` replaced the fixed quantile by ACI on 200 names of the survivorship-free panel, at every session from July 2018 to December 2024: about 290,000 windows per horizon. The errors were measured on the naive forecast. The models sit on the random walk ([§70](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)), so this isolates the quantile rule; a model whose forecast moves off the random walk has somewhat different errors. The learning rate gamma was chosen on 2018–2021 and scored once on 2022–2024. CC is the mean, over five quintiles of a volatility-shift measure (the last 20 sessions' sd over the calibration block's), of |coverage − 95%|: a band right on average and wrong whenever volatility moves has a large CC.

| h = 5 sessions | Static (shipped) | ACI, γ = 0.01 (chosen) | ACI, γ = 0.05 (HAR-RV's) |
|---|---|---|---|
| Coverage, 2022–24 | 95.0% | 94.6% | 92.1% |
| Mean width | 20.6% | 20.0% | 18.3% |
| CC | 0.009 | 0.007 | 0.030 |
| Coverage in the top shift quintile | 93.9% | 94.6% | 94.4% |
| 2020 crash (origins 15 Feb – 31 May) | 80.9% | 83.1% | 82.6% |
| Windows holding a results day (to mid-2024) | 89.2% | 88.2% | 84.2% |

The rule required the CC improvement's 95% interval (calendar months resampled) to exclude zero. It was [−0.0050, +0.0008], so ACI is not shipped. Three things the run showed:

1. **One session ahead, ACI works.** CC fell from 0.011 to 0.007, with an interval of [−0.0056, −0.0030]; top-quintile coverage went from 93.6% to 94.3% with bands 3% narrower. It is not shipped on that alone, because the decision was registered at five sessions and a band that adapts on day 1 only would be an odd object.
2. **At five and ten sessions it does not, and a fast gamma under-covers** (92.1% and 90.3%). Windows from consecutive origins overlap, so one shock becomes h misses in a row in the stream, and the level reacts h times.
3. **The failures that matter are elsewhere.** In the 2020 crash every rule covered about 81% at five sessions and 76% at ten. A rule that learns from past errors can only react after a crash. Results days are already widened in the Risk panel ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)).

#### HAR-RV's own ACI, at scale: kept

The overlap finding raised a question about shipped code, since HAR-RV runs ACI with γ = 0.05 by default. §12's A/B was three names and 18 origins. `run_har_aci_scale.py` ran HAR-RV both ways on 57 names, at an origin every 10 sessions from 2019 to 2024, about 4,000 origins per period:

| 2022–24 | ACI (shipped) | Static |
|---|---|---|
| Coverage, h = 1 / 5 / 10 | 95.0% / 94.8% / 95.7% | 96.7% / 95.7% / 97.1% |
| Width, h = 5 | 19.4% | 20.7% |
| CC, h = 5 | 0.009 | 0.007 (static − ACI: [−0.0106, +0.0083]) |

ACI stays the default. Static over-covers at every horizon and is 5–13% wider, and CC cannot tell the two apart. HAR-RV's scores are standardised by its own variance forecast, which absorbs the volatility shifts that make raw-error ACI over-react. In 2019–21 the ACI cone ran slightly under (93.4–94.6%), and static ran 95.7–96.2%. Only histories of up to about seven years could be tested, because the bhavcopy cache starts in 2017. In the app a large cap has decades of history, and HAR-RV's calibration origins then sit about 27 sessions apart, so they do not overlap at all.

#### The novelty gate in a real crash: stays off

§25's autoencoder flags a 20-session window as "unprecedented" when its reconstruction error exceeds the 99.5th percentile of a held-out reference block; the app would then withhold every directional call. It ships off because its value could not be shown on calm data. `run_novelty_stress.py` refitted it as the app does, on all history to date, at 22 quarter ends from mid-2019 to late 2024 on the 20 most liquid names, and scored every session (about 24,700). The control was a plain 20-day volatility reading, measured with the same percentile rule against the same reference block.

| Period | AE "unusual" / "unprecedented" | 20-day vol, same rule | Static band miss, h = 5 |
|---|---|---|---|
| 2019-07 – 2020-01 | 25.4% / 20.6% | 21.8% / 18.9% | 5.3% |
| Crash, 15 Feb – 31 May 2020 | 68.6% / 65.9% | 60.5% / 58.0% | 20.0% |
| 2020-06 – 2021 | 5.9% / 3.5% | 3.8% / 2.2% | 2.7% |
| 2022 | 7.1% / 4.4% | 7.1% / 4.6% | 4.8% |
| 2023–2024 | 7.0% / 3.7% | 5.9% / 3.4% | 5.0% |

- **It catches the crash, but late.** 95% of names were flagged "unprecedented" at some point in the crash window. Week by week, though, the share reached 58% only in the week to 13 March, with the panel already 28% down. The volatility reading got there in the same week (63%), and was ahead the week before (26% against 16%).
- **It fires far too often when nothing has changed.** Across the calm periods, 5.9% of sessions were "unprecedented", against 0.5% by design. With at least three years of history behind the fit the rate is 2.7–3.3%; with less, 17.8%. That is why 2019 looks so bad. The "99.5th percentile" of a few hundred overlapping windows from one stretch of time is close to their maximum, and a later quarter that differs from that stretch exceeds it.
- **It knows nothing the volatility reading does not.** With the volatility reading quiet, an AE flag left the band's miss rate where it was: 4.8% against 4.6%, over 851 sessions. With the volatility reading flagged, misses roughly doubled whether or not the AE agreed (9.3% with it, 9.0% without).

The pre-registered rule passed on the crash (95% ≥ 50%) and failed on calm data (5.9% > 1.5%). It said a failure would need a fix. None is built, because the third result rules out the only kind there is. A recalibrated threshold would make the gate quieter, but it could still carry only information the volatility reading already has. The app already uses that information, in HAR-RV's cone and in every conformal band. So the gate stays off, and `config.py` now gives the measured reason.

Four tests cover `aci_quantile` (`test_aci.py`): its agreement with HAR-RV, batching, a late shock widening the band while an early one does not, and the clipping bounds. A fifth checks that empty and non-finite input are handled. The novelty driver also checks that a window scored from the full series equals the app's score from a series cut at that session.

### 72. Third audit — a withheld row that blamed the model, a failed forecast that voted Bearish, and a banner ahead of its gate

A third pass on 31 October 2026, aimed at the serving layer: what the user is *told*, rather than what any model computes. It found three bugs there, in `gating.py` and `UI.py`, two more in the fetch layer underneath (`safe_fetch.py`, `get_data.py`), and three passages of this README that had drifted from the code.

#### What ran

| Layer | Result |
|---|---|
| Static analysis (ruff: pyflakes, syntax, bugbear) over the app, tests, drivers and tools | No undefined name or syntax error in the app. 21 loop-closure warnings in the drivers, each closure called within its own iteration; the rest unused imports and variables |
| `pytest tests/` | 730 passed at the start; 735 after the fixes (five new tests) |
| `tools/check.py --tests` | clean |
| `tools/ui_check.py scenarios` | 0 problems, before and after the fixes |
| Read by hand: `gating.py`; the summary table, consensus and risk panel in `UI.py`; `risk_metrics.empirical_risk`; `backtest.confidence_bucket` | The risk math is right: VaR and the range map log quantiles through `exp`, and expected shortfall is averaged as simple returns ([§50](#50-jensens-inequality-in-expected-shortfall-sadr-mathematical-techniques-in-finance-a24--a-units-error-in-shipped-code)). The three bugs below |
| Read by hand: `get_data.py` (ticker resolution, INR conversion, nselib fallback, source selection) and `safe_fetch.py` | The nselib fallback is sound (its four earlier defects stay fixed, [§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close)). The two fetch-layer bugs below |

Not run this time: the browser check at five widths, and the research drivers (no code they use changed).

#### A withheld row blamed the model

When the data-quality gate ([§17](#17-input-data-quality-gating)) or the novelty gate ([§25](#25-regime-novelty-from-a-denoising-autoencoder)) withholds a row, its Basis should read *withheld — data quality* or *withheld — unseen market regime*. In the app it read **no edge vs random walk (DM p=0.03)**: the reason a model that may have rated High was withheld was put down to the model.

The gates wrote their reason with `setdefault("note", ...)`, which writes only when the key is absent. `UI._model_confidence` always sets `'note': ''` (and `'assessment failed: …'` on error), so the key was always present and the reason was never written. The unit tests passed because their entries had no `note` key at all. `gating._withhold` now writes the reason unless an earlier gate already withheld the row, so a row withheld for its data keeps that reason when the novelty gate also fires. Three tests in `test_gates.py` build entries the way the UI does; two of them fail on the old code.

#### A failed forecast voted Bearish

A model whose final price came back `NaN` or infinite (a diverged network, an overflowing `exp`) was kept in the run. In the comparison table it read **Bearish**, because `NaN >= 0` is false, and it was counted in the consensus. In the risk panel's log-normal fallback (no HAR-RV in the run), one `NaN` made the median range and VaR `NaN`. It was also written to the prediction log ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)). `run_selected_models` now treats a non-finite final price as a failed model: it warns and leaves the model out, the same way an exception is handled.

#### The skill banner was drawn before the novelty gate

The abstention banner was built from the confidence buckets before the novelty gate ran. With `USE_REGIME_NOVELTY` on and an "unprecedented" window, the page could show *k of n models showed a measurable edge* above a table in which every call had just been withheld, and nothing on the page said why. The banner is now drawn after both gates. An "unprecedented" verdict replaces it with an *Unseen market regime* notice ([Step 2](#step-2--the-abstention-banner-is-the-honest-headline)). The flag ships off, so the default page is unchanged.

Neither UI fix has an automated test. Both live in the Streamlit script, which the unit tests do not import, and the scenarios never reach either path (no model returns `NaN`, and the novelty flag is off).

#### A short fetch replaced the last-known-good copy

`safe_fetch` ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)) flags a live result under half the cached length as `partial`, and then saved it over the cache anyway. The short frame became the baseline: the same truncated answer on the next run passed as `live`, and if the fetch then failed outright the fallback served the truncated history, not the last good one. The cache is now written only from a full `live` result. The trade-off: if a stock's history genuinely shrinks for good, every fetch stays flagged `partial` (a warning, not abstention) until `.data_cache/` is cleared. `test_partial_result_does_not_replace_last_known_good` fails on the old code.

#### INR conversion dropped the ticker

`_convert_to_inr` ([§16](#16-currency-conversion-to-inr-and-its-audit-trail)) joins the FX history with `merge`, and pandas 3 does not carry `attrs` through a merge, so a converted stock lost the `ticker` the UI reads for its NSE lookups (the ex-dividend notice, the results-day widening, the company check and the Hough screen). The attrs are now restored after the merge. The conversion runs only for a foreign-currency ticker, which the NSE/BSE dropdown cannot select, so this was close to unreachable. It is the first test of the conversion at all: `test_inr_conversion_keeps_the_ticker_and_uses_each_dates_rate` also checks that each bar takes its own day's rate.

#### Documentation that had drifted

- The [Dependencies](#dependencies) table still listed the versions from before the pins were moved ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)): streamlit 1.54.0, yfinance 1.0, xgboost 3.1.2, scikit-learn 1.8.0 and tensorflow 2.20.0. It now matches `requirements.txt`, and lists `pandas_market_calendars`, which was missing.
- A [caveat](#caveats-and-limitations) still described the forward prediction log as deferred, though `prediction_log.py` has implemented it since §28. It now states the log's real limits: one local file, with outcomes joined only when `resolve_outcomes` is run.

### 73. The label-horizon paradox on the NSE panel — a shorter label scores better, and nothing can pick it

Song, Liu & Chen (ICML 2026, arXiv 2602.03395) argue that the best training label for a horizon-T forecast is often a return over a shorter horizon h < T: a shorter label carries less accumulated noise, and that gain can outweigh the signal it gives up. It was the one paper in a review of Papers with Code's finance tasks that applies to the project's only real signal, the cross-sectional ranking of [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result), and could be run on data the project already holds. Their evidence is one test year on Chinese indices, five seeds and no significance test. The test here uses data before the reserved period only (2018-01 to 2024-06); nothing from 2025 on was read.

#### Design, registered in the driver before the first run

`tests/validation/run_label_horizon.py` takes §38's panel exactly: 400 names from the survivorship-free bhavcopy, 29 features, the combined name-and-date split with its embargo, and the calibrated LightGBM classifier. It retrains on h-day labels for h = 1 to 5 and scores every arm on the same validation rows against the same 5-day target, so the arms differ only in the training label. The eight seeds are those of `universe_seeds_n400_201801_202406.csv`; the split and the model seed are shared by every arm within a seed, so split noise cancels in the paired difference. The horizon used, h\*, is picked by an inner name-and-date split of each seed's training block, never by the validation block: picking the best of five there would be a best-of-five trial.

0. **Harness:** the h = 5 arm must reproduce the stored per-seed IC to four decimals, or nothing below is read.
1. **Adopt** label-horizon selection only if the paired gain IC(h\*) − IC(5) is positive in at least 6 of 8 seeds *and* its median Newey-West t (daily IC difference, 4 lags) is at least 2.
2. The full grid on the validation block is descriptive only.

#### The harness failed on the first run, and what fixed it

On the first run the h = 5 arm did not reproduce the stored file: median IC +0.0380 against +0.0372, with single seeds up to 0.005 apart (seed 114: +0.0398 against +0.0438). The driver was not the cause. `run_universe_seeds.py`'s own code path, run the same day, gave the same figures; the validation row counts matched the stored file; and the panel, model and metric modules and the in-window day cache were unchanged since the file was written on 20 October 2026. The classifier is bit-reproducible ([§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong)). What was left was the corporate-action feed, which `build_panel` fetched live from NSE on every run. Two things about that feed came to light:

- **NSE revises it.** §38 had already recorded revisions moving the 400-name panel.
- **NSE returns its rows in a different order from one request to the next.** Two live fetches 30 seconds apart held the same 9,497 actions, but GLOBE's bonus and split, both on 2021-08-03, swapped places, because the table was sorted on symbol and ex-date only. The adjusted price is the same either way except in the last bits of a float, and that is enough to change the trees: with nothing else changed, the tie-break alone moved seed 121 from +0.0338 to +0.0320 and seed 100 from +0.0361 to +0.0368.

Either could explain the 20 October file. Which one did cannot be told now, because no copy of that day's feed was kept. Both are now closed in `bhavcopy.corporate_actions`:

1. **A snapshot.** A live fetch writes each chunk once under `.bhav_cache/actions/` and reads it from there afterwards, so a research run sees the same inputs every time. A chunk ending within 90 days of today is never frozen, because NSE may still be recording it. To take a fresh snapshot, delete the folder. The app's two callers (`get_data`'s nselib fallback and the ex-dividend notice) pass `snapshot=False`, because they want NSE's latest records.
2. **A tie-break.** The subject now breaks ties on symbol and ex-date, so two identical fetches give identical tables.

Checked on the real feed: two live fetches and the snapshot read-back give identical tables for 2016-11 to 2024-06. Three tests (`test_bhavcopy.py`) check that a snapshotted chunk is read back without refetching (including a symbol `NA`, which a careless reader would turn into a missing value), that a recent chunk is never frozen, and that an injected feed is not snapshotted. The seed file was then refreshed with `run_universe_seeds.py`. The label-horizon driver, run afterwards as a separate process, reproduces it to four decimals on all eight seeds, so this time the harness passed. Both were run once more after the renamed-company fix ([§74](#74-renamed-companies-lost-their-corporate-actions)), and the harness passed again; the figures below are from that run.

#### Result: not adopted

| Training label | IC on the 5-day target (mean of 8 seeds) | sd across seeds | Score rank correlation, 5 sessions apart |
|---|---|---|---|
| h = 1 | +0.0380 | 0.0049 | 0.41 |
| h = 2 | **+0.0441** | 0.0061 | 0.45 |
| h = 3 | +0.0427 | 0.0069 | 0.51 |
| h = 4 | +0.0397 | 0.0041 | 0.57 |
| h = 5 (shipped) | +0.0386 | 0.0061 | 0.59 |
| Raw 5-day reversal, same rows | +0.0352 | | |
| What a book clearing ~22 bp of cost would need | ≈ 0.23 | | |

The inner split picked h\* = 3, 2, 5, 1, 3, 1, 5, 5 across the eight seeds. The paired gain IC(h\*) − IC(5) averaged +0.0022 and was positive in 4 of 8 seeds; one was negative (−0.0042, where the pick was h = 1). The median t was +1.16 (+0.24 if the three seeds where h\* = 5, with no difference to test, count as zero). That fails the bar of 2, so the 5-day label stays. The two earlier runs failed the same way: median t +0.49 on the unfrozen feed, and +0.95 on the frozen feed before the renamed-company fix.

1. **The direction the paper reports is there, at h = 2 to 4.** Those labels beat h = 5 on average (h = 1 does not: +0.0380 against +0.0386), and h = 2 beats it in 7 of 8 seeds, by +0.0055 on average (from −0.0026 to +0.0096). This is the best of five read off the block that was registered to decide nothing, and the seeds share most of their data, so it is a hypothesis for a fresh period, not a result.
2. **The inner split cannot find it.** On average the training block agrees that h = 3 is best (+0.0594 there, against +0.0556 for h = 5). Within any one seed, though, the horizons sit 0.005–0.015 apart in IC on the inner block, about as much as the gain being sought or more, so the pick is close to a draw. A gain that has to be known in advance to be collected is not one the pipeline can use.
3. **A shorter label buys IC with turnover.** The score's persistence falls from 0.59 at h = 5 to 0.45 at h = 2 and 0.41 at h = 1, so the book changes more often, and turnover is the cost that already sinks this signal ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc)).
4. **It does not move the economics.** §39's raw sort broke even at 5.0 bp with |IC| 0.052. At that turnover gross return scales roughly with IC, so clearing about 22 bp needs an IC near 0.23. h = 2's +0.0055 covers about 3% of the gap from 0.039, and it comes with more turnover. Nothing in the app changes.
5. Across these eight draws the model edges the raw reversal sort (+0.0386 against +0.0352, higher in 5 of 8 seeds), unlike §38's single split, where the raw feature won. That does not change §38's reading that the model has rediscovered the reversal factor. It does say the gap between the two is within the split noise.

Not run: a fixed h = 2 scored on a period this run has not touched. The only such period is the reserved one from 2025 ([§21](#21-operational-robustness-reproducibility-resilient-fetch-event-risk-gating)). It was deliberately left unread: a gain this small cannot change a decision, and the reserved period can be read only once.

Refreshed: `universe_seeds_n400_201801_202406.csv` (§38's seed study now reads median IC +0.0392, median t +2.58, 7 of 8 seeds above 2, none negative). Every other stored result built on this panel was re-run afterwards ([§74](#74-renamed-companies-lost-their-corporate-actions)). The per-seed label-horizon results are in `tests/validation/label_horizon_n400_201801_202406.csv`.

### 74. Renamed companies lost their corporate actions

After [§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it) froze the corporate-action feed, every stored result built on the bhavcopy panel was re-run on the frozen copy, to see which published figures still held. The first pass turned up a data bug larger than the one it was looking for. `dividend_dates.csv` had lost all eight of ICICIPRULI's dividends since October. NSE renamed ICICIPRULI to ICICILIFE on 23 October 2026, and its feed now files the company's whole history under the new symbol.

#### The bug

The bhavcopy records each day under the symbol the company traded under **that day**. NSE's corporate-action feed records every action under the company's **current** symbol. `adjust_prices` joins the two on symbol, so a company that had since been renamed kept none of its actions from before the rename: no splits, bonuses or dividends. Its adjusted price was its raw price, and a split showed up as a crash.

- **MCDOWELL-N** (now UNITDSPR) split 1:5 on 2018-06-15. The panel recorded that day as a −163% log return. With the split restored, its worst day is −14.3% on 2020-03-23.
- **INFIBEAM** (now CCAVENUE) had three splits and bonuses unadjusted. Two of them showed up as −85% and −73% days (2021-03-18, 2022-03-14). Its 2018-09-28 drop of −123% (log) is real.
- **MOTHERSUMI** (now MOTHERSON) lost two bonuses. Its worst day was −34.6% and is now −26.2%.

Over the window the panel reads (2016-11 to 2024-06), the fix restores **639 actions on 137 symbols**, 29 of them splits or bonuses and 598 dividends. In §38's 400-name panel, **25 of the 339 names** were affected, with 153 actions, 6 of them splits or bonuses: AMARAJABAT, CADILAHC, CENTURYTEX, GATI, HEG, IBULHSGFIN, IBVENTURES, ICICIPRULI, IDFCBANK, INFIBEAM, INFRATEL, JUBILANT, KPIT, L&TFH, MCDOWELL-N, MOTHERSUMI, NIITTECH, PVR, SRTRANSFIN, STRTECH, TATAGLOBAL, TATAMOTORS, TATASPONGE, TWL and WELSPUNIND.

**Why §38's check missed it.** §38 validated the adjustment against yfinance on 25 large caps. Only one of them, TATAMOTORS, has been renamed, and its only action in the check's window was a ₹2 dividend in July 2023. A return correlation cannot see that.

#### The fix

- `bhavcopy.symbol_changes()` reads NSE's symbol-change list (`symbolchange.csv`: old symbol, new symbol, effective date). It is frozen beside the action chunks, so a research run sees the same list every time.
- `bhavcopy.add_former_symbols()` copies each action to the symbol the company traded under on its ex-date. It follows chains of renames (AAA → BBB → CCC) and stops on a cycle.
- `corporate_actions` applies both by default whenever it uses the snapshot. The app's two live callers pass `snapshot=False` and work on current symbols, so they are unchanged. A feed passed in by a test is left as it is unless `renames` is given.

Four tests in `test_bhavcopy.py` cover this:
- a renamed company's actions reach the symbol of the day, through a chain of two renames;
- the symbol-change list is frozen with the actions;
- `renames=` applies a given list;
- a feed passed in by a test is not snapshotted by default.

The full suite is 741 tests.

#### Every stored panel result, re-run

`tools/run_drivers.py` re-ran all 46 drivers that build on the panel, offline and with live prices blocked. 43 ran. Three need live yfinance prices and stay blocked by design: `run_bhavcopy_audit`, `run_market_breadth` and `run_oneil`.

39 of the 65 stored result files changed. Three drivers had run alongside the one that rewrites `reversal_costs_h5.csv`, which they read, so they were run again in sequence: `run_residual_reversal`, `run_event_backtest` and `run_deflated_sharpe`. The four extra starting days of [§45](#45-event-based-backtesting-hilpisch-ai-in-finance-ch-11--what-39s-number-never-showed) were re-run too. Every figure that moved at the precision printed has been updated in its own section and in this document's mirror. The ones worth knowing:

| Section | Before | After |
|---|---|---|
| [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result), 400 names, 29 features | IC +0.0352, t 2.01 | IC +0.0373, t 2.12 |
| §38 seed study (median of 8) | IC +0.0383, t +2.54, 7 of 8 above 2 | IC +0.0392, t +2.58, 7 of 8 above 2 |
| [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), raw reversal breakeven | 6.1 bp | 5.0 bp |
| [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39), k = 5 residual reversal | t −7.75, breakeven 12.7 bp | t −8.08, breakeven 15.1 bp |
| [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code), reversal through futures | breakeven 4.4 bp | 5.2 bp |
| [§56](#56-long-memory-and-wavelets-mariani--florescu-quantitative-finance-ch-5-1213--persistence-that-is-the-estimators-and-a-forecast-that-is-the-future), DFA beyond all risk controls | t 2.26 | t 2.12 |
| [§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date), cash dividends measured | 2,066 | 2,171 |
| [§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces), reversal out of sample, Jul–Dec 2024 | IC −0.0276 (t −2.33), breakeven 31 bp | IC −0.0245 (t −2.21), breakeven 23 bp |
| §73, label-horizon gain | median t +0.95 | median t +1.16 |

**No verdict changed.** Every pass is still a pass and every failure still a failure, but three results are now weaker:
- §56's DFA crash warning is now below 2.24, the bar used for its pre-registered test (it was a post-hoc diagnostic, and still clears 2).
- §67's out-of-sample half-year now only just clears a delivery round trip.
- §73's h = 1 label no longer beats h = 5.

The reversal books moved both ways (§39's raw sort down, §49's residual book up), and the cost verdict of §39, §49 and §55 is unchanged.

**One systematic shift is not from this fix.** [§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result)'s range-volatility A/B now gives bands about 2% wider (median; 0.3–5.0%), and coverage held or rose on all 48 rows. None of its 12 names was renamed. The stored file predates [§70](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)'s `widen_to_monotone`, which can only widen a band, so that change is the likely cause. Its verdict is unchanged.

**Not re-run:**
- the three blocked drivers;
- sub-window figures that no current driver prints (§44's and §45's 2022–2024 runs);
- §67's power estimates;
- the accounts of earlier runs that sections keep as history (for example §49's first reconciliation at −0.12%).

### 75. A no-trade band on the residual reversal — it trims turnover by 29% and still falls 4.6 bp short

A full screen of the 151 papers in Papers with Code's Finance task (the review behind [§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it) had read only the first 20) found one more idea aimed at what actually sinks this project's signal. "Finance-Grounded Optimization for Algorithmic Trading" (arXiv 2509.04541) trains on Sharpe- and P&L-based losses with a turnover penalty. The paper is thin: no code, one citation, no significance test. Its point still applies here. [§49](#49-residual-reversal-tatsat-et-al-blueprints-ch-7--and-a-rebalance-phase-artefact-in-39)'s residual reversal has the strongest IC in the project and loses to cost, and [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) showed that holding longer barely reduces turnover, because the signal has no persistence.

A turnover penalty needs no new model. Its portfolio form is a **no-trade band**: a name enters a leg at the extreme decile but leaves only when its rank drops out of a wider band. A position whose signal is still good is kept rather than sold and bought back.

#### Design, registered in the driver before the run

`tests/validation/run_trade_band.py` uses §49's signals (`run_residual_reversal.signals_at`): the raw and the k = 5 PCA-residual trailing 5-day return, long losers and short winners, equal weight in each leg, on the same 400-name panel, 2018-01 to 2024-06. Nothing from the reserved period was read.

- Entry at the extreme decile; exit bands of 0.10 (no band), 0.15, 0.20, 0.30 and 0.40 of the cross-sectional rank.
- Rebalance every session, or every 5 sessions averaged over the five starting days as in §49.
- Cost: a cash-delivery round trip, 22.22 bp (`strategy_metrics.india_round_trip_bps`, [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)).
- **Rule:** the band rescues the signal only if some configuration breaks even above 22.22 bp in both log and simple returns *and* its return net of that cost has t > 2. Ten configurations per signal are tried, so even a narrow pass would need the reserved period to confirm it.
- **Check first:** the 5-session, no-band k = 5 book must reproduce §49's stored breakeven. It does: 15.15 bp, turnover 3.470, both identical.

#### Result: the band does not rescue it

| k = 5 residual, every 5 sessions | Gross per rebalance | Turnover | Breakeven (log / simple) | Net of 22.2 bp, t (median of 5 starts) |
|---|---|---|---|---|
| Exit 0.10 (no band, = §49) | +0.263% | 3.47 | 15.1 / 15.2 bp | −0.55 |
| Exit 0.15 | +0.272% | 3.29 | 16.5 / 16.6 bp | −0.40 |
| Exit 0.20 | +0.261% | 3.12 | 16.8 / 16.8 bp | −0.41 |
| Exit 0.30 | +0.238% | 2.79 | 17.0 / 16.9 bp | −0.26 |
| Exit 0.40 | +0.217% | 2.46 | **17.6 / 17.4 bp** | −0.46 |

1. **The band works as designed, and not by enough.** At the widest band turnover falls 29% (3.47 → 2.46) while gross falls 17%, so breakeven rises 2.5 bp. That closes about a third of the 7.1 bp gap to a delivery round trip. Every configuration still loses money after cost.
2. **The gain flattens.** Breakeven moves 16.5, 16.8, 17.0, 17.6 bp across the bands: each extra width keeps fewer good positions and more stale ones.
3. **Rebalancing every session is worse in every cell.** It trades 0.83–1.61 a day against 0.49–0.69 a day for the 5-session book, and earns less per unit traded. The best daily book breaks even at 13.6 bp. The raw sort rebalanced daily loses money before any cost (−0.057% a day without a band), so its reversal shows up only over several days.
4. **Nothing changes for the app.** The verdict of §39 and §49 stands: the reversal is real and not tradeable in cash delivery. A band also does nothing about §39's other constraint, that a cash short cannot be held overnight.

Per-configuration results are in `tests/validation/trade_band.csv`.

---
## Reading the screen: which numbers support a decision

The app puts a lot of numbers on one page, and they are **not equally load-bearing**. This section is the user's guide to them: what each one is, what value counts as strong or weak, and — the part that matters — which decision it can actually support.

**The one-sentence version.** This app is built to tell you *how uncertain the next move is* and *whether any model has demonstrable skill on this ticker right now*. It is not built to tell you where the price is going. The decisions it genuinely supports are therefore **abstain / size / set a stop** — not **buy / sell**. Every design choice below follows from that, including the ones that deliberately withhold a number you might want. If your question is simply *"how good is the prediction, and how confident can I be?"*, the answer, with its evidence, is [at the end of this guide](#how-good-is-the-prediction-and-how-confident-can-i-be).

### Read it in this order

The layout is deliberately top-down: each block gates the one below it. Reading it out of order is the single most common way to reach a wrong conclusion from a correct screen.

1. **🩺 Data-quality banner** — is the *input* sound? If this is red, stop here; nothing below it is meaningful.
2. **Abstention banner** — how many of the selected models beat a random walk on this ticker/horizon.
3. **Consensus cards** — median forecast, and the bullish / bearish / abstained split.
4. **Confidence and Basis columns** — the per-model verdict and *why* it got that verdict.
5. **Risk & Probability panel** — the actual deliverable: range, VaR, expected shortfall, probabilities.
6. **Signal Score and Conviction** — worth reading only for rows that cleared step 4.
7. **The charts** — all models together, then each model's 95% cone against the grey dotted random-walk line.

**Row order in the Model Comparison table is not a ranking.** The table is sorted for display, not by merit, and the lowest-error model is not a winner: across the full set, White's Reality Check and Hansen's SPA found no selection-bias-free edge over a random walk (*p* ≈ 0.9). Reading the top row as "the best model" is exactly the data-snooping error the whole evaluation layer exists to prevent.

### Step 1 — the data-quality banner decides whether to continue

| Banner | Mode | What to do |
|---|---|---|
| 🩺 *Data quality OK (score n/100)* | `normal` | Continue. |
| ⚠️ *Data-quality caveats* | `warn` | Continue, but widen your margin — something in the feed is imperfect. |
| ⚠️ *Event risk detected — showing the risk cone* | `risk_cone_only` | **No directional call.** An earnings date or a gap is inside the window; the range is the only output. |
| ⛔ *Forecast withheld — data quality insufficient* | `abstain` | **Stop.** Directional calls are already suppressed. Refetch, or pick another ticker. |

Open **Data-quality details** for the reason codes. This gate runs on the fetched series at request time and catches a broken *input*; it says nothing about whether the model is any good — that is step 2.

### Step 2 — the abstention banner is the honest headline

| Banner | Meaning | Decision |
|---|---|---|
| 🔴 *No model showed a statistically reliable edge* | zero of *n* models reached High or Medium | Treat the **range** as the entire output. Do not act on the point forecast. |
| 🟠 *Only k of n models beat the baseline* | fewer than half | Weight the range heavily; the point line is weak evidence. |
| 🟢 *k of n models showed a measurable edge* | at least half | The strongest state this app produces — and still small-sample (see below). |
| ⚠️ *Unseen market regime — every directional call is withheld* | the regime-novelty gate (off by default) rated the latest window "unprecedented"; replaces the three above | Treat the **range** as the entire output. |

The red banner is the **expected** state for most tickers at short horizons. It is a finding, not a malfunction.

### Step 3 — consensus cards, and why the vote count is not a vote

**Median Forecast** is the median across selected models, with its percentage change. **Models Bullish / Bearish** counts the directional calls that survived gating, and a caption reports how many were withheld.

Two cautions that matter more than the numbers:

- **The models are not independent voters.** They share the same OHLCV history, largely the same engineered features, and in several cases the same family. "14 of 19 bullish" is emphatically *not* fourteen independent opinions — it is closer to one opinion, computed fourteen ways, with correlated errors. Treat agreement as weak corroboration, never as a probability.
- **The median is more robust than any single row**, which is precisely why it is the headline. If the median and your chosen model disagree sharply, the model is the outlier, not the median.

### Step 4 — Confidence and Basis: the only skill claim on the page

**Confidence** comes from a walk-forward backtest run at request time on recent history, and it is the single most decision-relevant column. The rule (`backtest.confidence_bucket`) is fixed and auditable:

| Bucket | Rule | How to read it |
|---|---|---|
| **High** | RMSE improvement > 5% over the best naive baseline, **and** Diebold-Mariano *p* < 0.10, **and** 95% coverage within 0.85–0.99 | A measurable edge with trustworthy bands. |
| **Medium** | improvement > 2% and DM *p* < 0.20 | A modest, weakly significant edge. |
| **Low** | improvement > 0, but not significant | Better than the random walk *within noise*. Not evidence. |
| **No edge** | no improvement | No better than assuming the price stays put. **The directional call is withheld.** |
| **No data** | insufficient history for the check | Unassessed — treat as No edge. |

**The honest caveat, which belongs next to every High you ever see:** this gate runs **3 origins on at most 600 rows** (`_GATE_SPLITS = 3`), because it must return while a user waits. Three origins is enough to catch a model that is clearly broken; it is *not* enough to establish skill. A **High** here means "worth a closer look with `run_full_backtest.py` on more origins", not "proven". Conversely, **No edge** on three origins is quite reliable — it is much easier to fail to beat a random walk convincingly than to beat one by luck three times.

**Basis** is the plain-language reason, so no row shows a bare verdict:

| Basis text | What happened |
|---|---|
| `beats random walk (DM p=…, cov …%; P(no edge) ≥ …%)` | High — with the actual p-value and coverage shown, and the least the probability of no edge can be ([§51](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4)). |
| `weak edge (DM p=…; P(no edge) ≥ …%)` | Medium. A p-value of 0.14 still leaves at least a 43% chance of no edge. |
| `within noise (+…% vs RW, DM p=…)` | Low — note the improvement is stated so you can see how small it is. |
| `no edge vs random walk (DM p=…)` | No edge. |
| `withheld — data quality` | The data-quality gate overrode the skill test. |
| `withheld — unseen market regime` | The novelty gate fired: current conditions are off-manifold, so a backtest-derived bucket would be an extrapolation. (Ships off by default.) |
| `… · unusual regime` | An advisory suffix — conditions are unusual but not unprecedented; the verdict stands, with a caveat. |

**HAR-RV always reads No edge, and that is correct.** It makes no point-forecast claim by design; its entire output is the calibrated risk cone. Do not read its bucket as failure — and do not deselect it, because the fat-tailed risk panel depends on it.

### Step 5 — the Risk & Probability panel is the deliverable

| Metric | What it is | What decision it supports |
|---|---|---|
| **Likely range (95%)** | the calibrated interval at the horizon | **The primary output.** Stop placement, position sizing, whether the trade you had in mind is even distinguishable from noise. |
| **P(price up)** | probability of finishing above today | Direction only if it is far from 50% — see the calibration warning below. |
| **P(gain > +x%) / P(loss > x%)** | probability of a move beyond your threshold (set it yourself) | "Is my target plausible at this horizon?" Often the most useful number on the page. |
| **P(a −x% stop is hit)** | chance the price *touches* −x% at any point before the horizon — about twice P(loss), which only counts where it *ends* | Whether a stop that tight will just get you stopped out ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)) |
| **Stop with a 1-in-5 chance of being hit** | the stop distance sized by this stock's volatility over this horizon | Where to put a stop, instead of one percentage for every stock ([§60](#60-stops-dividends-and-factors-mladjenovic-stock-investing-for-dummies-ch-6-15-17--a-stop-is-hit-twice-as-often-as-the-panel-implied-and-the-quoted-price-drops-on-the-ex-date)) |
| **P(a −x% trailing stop is hit)** | chance a stop x% below the highest price since you set it is hit before the horizon | Whether a trailing stop that tight will last: the book's 8% is hit within a quarter on almost every NSE stock ([§62](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time)) |
| **P(+x% is touched)** | chance the price touches +x% at any point before the horizon — about twice P(gain) | Whether a sell order at your target is likely to fill ([§62](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time)) |
| **Break-even move (costs, tax, inflation)** | the gross move a long trade needs to come out level: round-trip costs plus inflation over the horizon grossed up for tax | The floor any target must clear. About +0.3% at 5 days, almost all of it STT ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) |
| **P(the move clears break-even)** | the chance the price ends above that move | Read next to P(price up): the gap is what costs take ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) |
| **🌐 Market breadth caption** | the last 10 sessions' advance/decline ratio, its fifth since 2018, and the market's measured next-month volatility for that fifth | Context for the whole market's risk; this stock's range is not adjusted for it ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) |
| **📅 Results notice** | NSE's calendar shows results inside the horizon; the panel above is then widened | A results day carries ~3–4× an ordinary day's variance. Every panel number already includes it; the per-model charts do not ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)) |
| **🎯 What the options market prices** | live implied volatility, expected move, the market's results-day move and a protective put's cost (F&O stocks) | A second, risk-neutral opinion on the spread. A ratio well below 1 against the panel usually means a recent spike is still in the models' history ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)) |
| **📈 O'Neil-disciple checklist** | the book's pocket pivot, gap-up, moving-average and NIFTY distribution-day signals for this stock, each beside what it measured on NSE | The book's view, honestly labelled: pocket pivots showed no edge, gap-ups reversed, the market model's timing was luck; only the heavy-volume 50-day break held up, as a lead. Not a buy or sell call ([§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market)) |
| **95% downside (VaR)** | the 5th-percentile price | A worst-case-but-not-extreme reference for sizing. |
| **Expected shortfall** | the *average* outcome in that worst 5% | What a bad day actually costs, not just where it starts. Always worse than VaR. |
| **Downside / upside vol** | dispersion split by direction | Whether the risk is symmetric. |
| **Vol skew (down/up)** | their ratio | **> 1 means the downside is the fatter side.** Size smaller when it is. |

Two things to check before trusting this panel:

- **Read the caption.** *"Probabilities are counted directly off the empirical, fat-tailed return distribution"* means HAR-RV (or Vol-LSTM) was in the run and the tail is real. *"⚠️ Approximate read"* means no fat-tailed model was selected and each 95% band was approximated as log-normal — which **understates tail risk**, the one thing you least want understated. Add **HAR-RV** to the selection and re-run.
- **Treat P(up) as ordinal, not cardinal.** A probability read second-hand off a regression interval is not a calibrated probability, and this project measured that directly: the same construction scored **ECE ≈ 0.31** in the cross-sectional work ([§29](#29-cross-sectional-classification-pooling-the-universe)), i.e. a "60%" could be off by roughly 30 points. Use it to rank ("further from 50% than yesterday"), not as a number to bet proportionally on. The properly calibrated alternative — a classifier asked *directly* for a probability, reaching ECE 0.0139 — exists in `cross_sectional_model.py` but is **not wired into the UI**.

**Below the panel, three collapsed expanders hold information rather than forecasts** ([§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)). **📘 Company check** scores the company against six measurable hallmarks of a great stock and the Appendix B ratio tests, with the book's rule beside each result. Use it to ask whether you would want to own the company at all, which no price model can answer. **🔎 Stock screens** ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)) says which of Hough's screen recipes the stock passes and runs his checks on a screen survivor. **🧭 Risks this forecast cannot see** lists the kinds of risk the models ignore. None of them changes a number above it.

### Step 6 — Signal Score and Conviction, for rows that earned it

**Signal Score (%)** is the model's forecast percentage change to the horizon. It is the value the Bullish/Bearish call is computed from, and on its own it is close to meaningless: a +3% signal from a **No edge** model is a number a random walk would also produce.

**Conviction** = the forecast move ÷ half the model's own 95% band.

| \|Conviction\| | Reading |
|---|---|
| < 0.5 | Within the model's own noise. Ignore the direction. |
| 0.5 – 1.0 | A real move relative to its uncertainty, but inside the band. |
| ≥ 1.0 | The move exceeds the model's 95% band — the current price sits outside it. High conviction. |
| — | The model emits no interval. |

**The trap:** conviction is measured against *the model's own* band, so a model with a badly narrow band manufactures high conviction. That is why the two columns must be read together — a high Conviction on a row whose Basis reports poor coverage is an over-confident model, not a strong signal. Coverage in the 0.85–0.99 window is one of the three conditions for **High**, which is why High + Conviction ≥ 1 is the only combination worth weight.

### Step 7 — the charts

Above the per-model sections, **All models together** draws every selected model's median path from the last close, the median of them, and the median of their 95% ranges, against the random walk ([§70](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)). Use it to see at a glance whether the models agree or one breaks away; agreement is not evidence of skill, so read it with the Confidence column. A **Line / Candles** switch sets how history is drawn on every chart; candles are adjusted for dividends and splits like the forecasts. Each model then has two tabs, **📈 Chart** and **📋 Predicted values**, both full width at any screen size ([§66](#66-ui-audit-every-screen-size-and-five-bugs--one-of-them-duplicating-the-prediction-log)). Each chart shows history, a dashed "last close" line, the forecast, its **95% range as a cone that fans out from the last close**, and a **grey dotted random-walk baseline**, with weekends and holidays removed from the axis so sessions sit evenly. The question the chart answers is not "where does the line go" but **"is the forecast line meaningfully outside the grey line's band?"** Usually it is not. That is the honest picture of short-horizon equity forecasting, and seeing it is the point of drawing the baseline at all.

### Feature flags: one registry, with the evidence attached

Six `USE_*` toggles decide what the app actually does, and they used to be defined wherever they happened to be consumed — five in `UI.py`, one in `ML_model.py`. That is fine until something needs to read **all of them at once**, and the console startup banner does. Building it meant importing a flag out of a model module purely to display it: the UI depending on `ML_model` for a piece of configuration, which is the wrong direction.

`config.py` is now the single source of truth. It imports nothing from this project, so anything may import it.

| Flag | Ships | Owning module |
|---|---|---|
| `USE_MARKET_CONTEXT` | off | `market_context.py` |
| `USE_IV_ADJUST` | off | `iv_data.py` |
| `USE_ASYMMETRIC_CONE` | off | `HAR_RV_model.py` |
| `USE_INTRADAY_FEATURES` | **on** | `ML_model.py` |
| `USE_REGIME_NOVELTY` | off | `autoencoder_regime.py` |
| `USE_PREDICTION_LOG` | **on** | `prediction_log.py` |

Three properties are worth more than the tidiness:

**The rationale lives with the flag.** Each registry entry carries the measured result behind its default, so "why is this off?" is answerable without hunting through a README section. Four of the six are off because an A/B said so. `python config.py` prints the whole set with reasons.

**The banner is generated, not hand-listed.** `active_flags()` derives it from the registry, so a flag added here appears in the console automatically. A flag the operator cannot see is a flag that silently changes results, and a hand-maintained display list is how one goes missing — `test_active_flags_covers_the_whole_registry` pins it.

**Every flag has an environment override.** `STOCKAPP_USE_MARKET_CONTEXT=1` flips one for a single run, and `STOCKAPP_USE_INTRADAY_FEATURES=0` is the A/B that section [§3](#3-feature-engineering) says is still owed. Editing a constant to run an experiment is how experiments end up committed by accident. A malformed value falls back to the default rather than raising: a stray `export` should fail to take effect, not stop the app.

Overrides are **called out in the banner**, because a run with one active is not the shipped configuration and its numbers need reading that way:

```text
  OVERRIDDEN      USE_MARKET_CONTEXT  <- not the shipped default; read results
                  accordingly
```

The serve-time gate constants (`GATE_SPLITS = 3`, `GATE_MIN_TRAIN`, `GATE_MAX_ROWS`) moved here too and are env-tunable. That makes the trade-off visible rather than buried: raise `STOCKAPP_GATE_SPLITS` for a stronger confidence check at the cost of a slower Submit — see [step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page) for why three origins is a filter and not proof.

One deliberate wrinkle: `ML_model` does `from config import USE_INTRADAY_FEATURES` rather than reading it through the module, so `ML_model.USE_INTRADAY_FEATURES` stays monkeypatchable by the existing parity tests.

### The same story in the terminal

Running `streamlit run UI.py` from `cmd` used to print a long, interleaved trace of per-model chatter — *"Fitting Auto-ARIMA..."*, *"Simulating 10000 price paths..."*, *"Prediction Complete."* — and **nothing about what the app concluded**. Nineteen models would announce completion and the terminal could not tell you whether a single one of them had beaten a random walk. The conclusion is the product; it was browser-only.

`console.py` closes that gap. It adds three blocks around the existing trace:

```text
================================================================================
 Stock Prediction  |  seed 42  |  CPU  |  20 models
================================================================================
  optional layers market-context=off   IV-tilt=off
                  asymmetric-cone=off   intraday-features=on
                  regime-novelty=off   prediction-log=on
  prediction log  .prediction_log/predictions.jsonl
  guide           README.md > "Reading the screen: which numbers support a
                  decision" explains every number below.
  quiet mode      set STOCKAPP_QUIET=1 to silence this output.
================================================================================
--------------------------------------------------------------------------------
RUN  RELIANCE.NS  |  1d  |  horizon 5  |  4 model(s)  |  14:23:07
--------------------------------------------------------------------------------
... the existing per-model trace ...
--------------------------------------------------------------------------------
RESULT  RELIANCE.NS  1d  h=5  (37.4s)
  data quality    OK (score 92/100) -> forecasts usable
  regime          novelty gate off (USE_REGIME_NOVELTY = False)
  confidence      HAR-RV         No edge   no edge vs random walk (DM p=0.55)
                  Meta-Ensemble  Medium    weak edge (DM p=0.14; P(no edge) ≥ 43%)
                  Quantile-LGBM  Low       within noise (+1% vs RW, DM p=0.31)
                  Chronos-2      No edge   no edge vs random walk (DM p=0.61)
  consensus       median 1,423.55 (+0.84%)  |  bullish 2  |  bearish 1  |
                  withheld 1
  verdict         Only 1 of 4 models beat the random-walk baseline with any
                  reliability here. Weight the range over the point line.
  logged          4 row(s) -> .prediction_log/predictions.jsonl
--------------------------------------------------------------------------------
```

**The startup banner** answers a question the console previously could not: *which version of the app is this?* Five `USE_*` flags materially change what the models produce, and an operator watching `cmd` had no way to tell which were active. The seed and device are there for the same reason — a reported number is not reproducible unless you know both.

**The `RUN` header** simply frames each Submit, so one run's trace is separable from the next in a long scroll.

**The `RESULT` block is the console mirror of the browser's decision layer**, and it maps line-for-line onto the sections above:

| Console line | UI equivalent |
|---|---|
| `data quality` | the 🩺 banner ([step 1](#step-1--the-data-quality-banner-decides-whether-to-continue)) |
| `regime` | the novelty gate's Basis annotation ([step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page)) |
| `confidence` | the Confidence + Basis columns ([step 4](#step-4--confidence-and-basis-the-only-skill-claim-on-the-page)) |
| `consensus` | the consensus cards ([step 3](#step-3--consensus-cards-and-why-the-vote-count-is-not-a-vote)) |
| `verdict` | the abstention banner ([step 2](#step-2--the-abstention-banner-is-the-honest-headline)) |
| `logged` | (browser-silent) rows appended to the forward prediction log |

**It renders verdicts; it never recomputes them.** The buckets come from the same `conf_map`, the reasons from the same `gating.confidence_reason`, and the verdict sentence from the same `_honesty_banner` the browser renders — passed through `strip_markdown` so the one authored sentence serves both channels. Re-deriving any of it here is precisely how two surfaces start telling a user different things. The one deliberate ordering choice: the honesty banner is re-read **after** the data-quality and novelty gates have been applied, so a degraded run reports the withheld verdict rather than the pre-gate one.

**Two robustness details that are not cosmetic.** Output is plain **ASCII**, and every write is wrapped: a Windows `cmd` session on a legacy code page cannot encode `₹` or `—`, and an unguarded `print` there raises `UnicodeEncodeError` — which would let a log line kill a forecast. `_write` degrades to a replacement character instead, and `test_write_survives_a_legacy_console_encoding` pins that. The banner is also printed **once per process** via a module-level flag rather than `st.session_state`, because Streamlit re-executes `UI.py` top-to-bottom on every widget interaction and a naive banner would reprint on each click.

Set **`STOCKAPP_QUIET=1`** to silence all of it; the per-model model chatter is unaffected either way.

### Putting it together

| Screen state | Supported decision |
|---|---|
| DQ red (`abstain`) | Act on nothing. Fix the data. |
| Event risk / `risk_cone_only` | Size for the range. No direction, whatever the table says. |
| Red abstention banner, all No edge | Range-only. If your thesis needs a direction, this app does not supply one — that is information, and it is worth acting on. |
| Mixed, your model High + Conviction ≥ 1 + agrees with the median | The strongest state available. Still 3 origins — confirm with `run_full_backtest.py` before sizing up. |
| High conviction, but Basis shows poor coverage | An over-confident model. Discount it. |
| P(loss > x%) materially exceeds P(gain > +x%) at the same *x*, vol skew > 1 | Asymmetric downside. Size down or widen the stop. |
| "⚠️ Approximate read" caption | Re-run with HAR-RV before using any tail number. |

### What the screen cannot tell you

Stated plainly, because a guide that only explains the numbers implies they cover more than they do:

- **Whether to buy.** No entry signal is produced anywhere, by design.
- **Anything about fundamentals, news, or announcements.** Inputs are OHLCV and a market proxy. A result that will be obsolete the moment an earnings release lands is not flagged as such beyond the event-risk gate. The **📘 Company check** expander shows today's fundamentals against the book's rules, but as information beside the forecast, not in it ([§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)). Scheduled **results** are the exception: the 📅 notice widens the risk panel when they fall inside the horizon ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)).
- **Which model is best.** SPA and the Reality Check say the data cannot support that claim.
- **Real-world probability.** Every probability is conditional on the model and on the past resembling the future. It is model uncertainty, not certainty.
- **Anything validated at longer horizons.** The evidence base here is short-horizon daily and hourly.

**Before acting, three questions:** Is the data-quality banner green? Does the range — not the point forecast — still make the position worth taking? And is there a single number on the page that would look different if the model had no skill at all? If the answer to the last one is no, the screen is telling you to do nothing, which is a legitimate output and the one it produces most often.

### How good is the prediction, and how confident can I be?

**Short answer: little confidence in the direction or the exact price; reasonable confidence in the range** — how far the price might move.

**The price or direction call.** The project tested this repeatedly and got the same answer each time:

- **Across all models,** none beats the simple guess "tomorrow's price = today's price" once you allow for the fact that many models were tried. White's Reality Check and Hansen's SPA gave *p* = 0.90 and 0.87 ([§15](#15-data-snooping-robust-model-selection-reality-check--spa)): no reliable edge.
- **Per model,** most rows end up as **"No edge"**. When a model does pass its quick check, the Basis column also prints how likely it still is to have none; at the "High" cut-off that is **at least 38%** ([§51](#51-a-p-value-is-not-the-probability-of-no-edge-kanungo-probabilistic-machine-learning-for-finance-and-investing-ch-4)).
- **Across stocks,** a cross-sectional model does pick up a small real pattern — stocks that rose sharply in the last week tend to give some of it back — but it is a long-known effect rather than something the model learned ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)). It breaks even at about **6 bp** per round trip, against at least **22 bp** of statutory cost to buy and sell shares in India, so it cannot be profited from ([§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), [§55](#55-cost-of-trade-kanwar--gupta-python-for-trading-on-technical--futures-dont-rescue-reversal-and-a-trainserve-skew-in-shipped-code)).

So if a model says "Bullish, +1.8%", treat it as a coin flip with a story attached.

**The range.** This is what the project is built to deliver, and it is measured rather than assumed:

- **Coverage.** The 95% bands from the volatility models (HAR-RV, Vol-LSTM) and the corrected ARIMAX hold the actual price **about 92–96% of the time** in walk-forward tests — roughly right, not exact. In the [§40](#40-range-based-volatility-sharma--mehta-ch-18--the-twelfth-negative-result) configuration it was about 92%, a little below target.
- **Risk figures.** The Risk & Probability panel's 5% worst-case loss (VaR), the average loss in that worst 5% (expected shortfall) and the probability of a move larger than X% are read straight off the volatility models' measured past errors. They do not assume a bell curve.

**How to use it.** Check the data-quality banner first; if it withholds the forecast or shows the range only, stop there. Read the **Confidence** column, not the row order — "No edge" means ignore that model's direction. Treat the **Risk & Probability panel and the shaded band** as the actual answer: *the price will most likely land between ₹X and ₹Y*. Use **Conviction** only on rows that earned it; even then, a value above 1 means the predicted move is larger than the model's own uncertainty, not that it will happen.

**Caveats.** The coverage figures come from a handful of stocks and test dates, so they are approximate. Hourly forecasts have not been validated the way the daily ones have. The truest measure will be the forward prediction log ([§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)), which checks every served forecast once its outcome is known — but it needs some weeks of use before its numbers mean anything.

**In plain terms: use the app to size your risk, not to pick a direction.**

---

## Evaluation and backtesting

You cannot trust a forecasting model until it is tested **out-of-sample on a moving window**. `backtest.py` provides this.

### Walk-forward backtesting

`walk_forward_backtest(df, predict_fn, interval, horizon, n_splits, ...)` picks several **origins** spread through history; at each origin it re-fits the model on data up to that point, forecasts the next `horizon` steps, and compares to what actually happened. This mimics real deployment (you only ever know the past).

### Baselines

Every forecast is compared to a ladder of **baselines**, not just one, because "beats the random walk" is a surprisingly weak bar:

- **Naive (random walk)** — the next `horizon` prices all equal the last observed price. The primary benchmark; a model that can't beat it adds no value.
- **Drift** — random walk plus the mean historical log-return. Beats naive whenever there's any trend.
- **AR(1)** — a first-order autoregression on log returns. Beats naive whenever there's short-horizon return autocorrelation.

A model should ideally clear all three. The leaderboards report `naive_rmse`, `drift_rmse`, and `ar1_rmse` side by side.

### Is the edge real? The Diebold-Mariano test

RMSE deltas on near-random-walk returns are often *inside the noise band*, so "model RMSE < naive RMSE" on a handful of origins can be luck. The **Diebold-Mariano (DM) test** (`backtest.diebold_mariano`) asks whether the loss differential between the model and the naive walk is **statistically** different from zero. It uses a HAC (Newey-West) long-run variance with `h−1` **Bartlett-weighted** lags — to account for the autocorrelation that overlapping multi-step forecasts create — plus the Harvey-Leybourne-Newbold small-sample correction. The Bartlett weighting is not cosmetic: an unweighted sum is not positive semi-definite and returned `NaN` on up to 48% of short samples ([§37](#37-the-diebold-mariano-kernel-fix-and-the-windows-race-it-uncovered)). The harness reports the statistic (negative ⇒ model more accurate), a two-sided p-value, and a plain verdict (significantly better / not significant / significantly worse). The leaderboards carry `dm_p` and `dm_sig`.

### Metrics

| Metric | What it measures | Good value |
|---|---|---|
| **RMSE / MAE** | Average price error | lower |
| **SMAPE** | Symmetric percentage error | lower |
| **MASE** | Error **scaled by the naive forecast's error** — directly comparable across tickers | < 1 beats one-step naive |
| **Directional accuracy** | Fraction of steps whose up/down direction is correct | > 0.5 beats chance |
| **Coverage** | Fraction of actual values inside the 95% interval | ≈ 0.95 |

`MASE` and `directional accuracy` are scale-free, so they're the right metrics to compare across stocks; raw RMSE is not (it depends on the price level).

**Economic metrics run alongside them.** `walk_forward_backtest` also returns a `strategy` block (`strategy_metrics.evaluate_strategy`) that turns the same forecasts into a cost-charged return stream and reports **Sharpe, Sortino, information ratio vs buy-and-hold, maximum drawdown, information coefficient, hit rate and turnover** — because a good RMSE and a profitable forecast are separate claims, and only the second one is what a user of a forecast wants. See [§22](#22-economic-evaluation-does-the-forecast-make-money). Pass `strategy=False` to skip it, `cost_bps=` to change the cost assumption, and watch the `overlapping_origins` flag: if the origin spacing is shorter than the horizon the trades overlap and every risk-adjusted figure is optimistic.

### Running the backtests

These manual evaluation drivers live in `tests/validation/` (run from the repo root):

```bash
# Whole suite on one ticker
python tests/validation/run_full_backtest.py AAPL

# Variance-aware ranking across several tickers (mean ± std per model)
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL"
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL" --fast   # exclude the slow neural nets

# Validate the UNCERTAINTY (CRPS / PIT / reliability / coverage quality)
python tests/validation/run_calibration.py RELIANCE.NS              # HAR-RV + XGBoost diagnostics
python tests/validation/run_calibration.py RELIANCE.NS --with-gate  # + nested gate validation (slower)
python tests/validation/run_calibration.py RELIANCE.NS --quick      # fewer origins for a fast smoke run

# Data-snooping-robust selection: does ANY of K models beat the random walk?
python tests/validation/run_spa.py RELIANCE.NS                       # White RC + Hansen SPA (fast subset)
python tests/validation/run_spa.py RELIANCE.NS --full                # include the neural nets

# Stress-period ACI evaluation (cone behaviour across 2020/2022 vs calm)
python tests/validation/run_stress_test.py RELIANCE.NS

# ECONOMIC leaderboard: would acting on each forecast have made money after costs?
python tests/validation/run_strategy_eval.py RELIANCE.NS               # full suite
python tests/validation/run_strategy_eval.py RELIANCE.NS --fast        # statistical + trees only
python tests/validation/run_strategy_eval.py RELIANCE.NS --cost 25     # stress the cost assumption
python tests/validation/run_strategy_eval.py RELIANCE.NS --deadband    # only trade above the cost hurdle

# VaR: compare five estimators, then Kupiec / Christoffersen them
python tests/validation/run_var_backtest.py RELIANCE.NS
python tests/validation/run_var_backtest.py RELIANCE.NS --alpha 0.01   # the 1% tail
python tests/validation/run_var_backtest.py RELIANCE.NS --horizon 5    # 5-day VaR

# Volatility models head-to-head: HAR-RV vs Vol-LSTM vs GARCH vs EWMA
python tests/validation/run_vol_comparison.py RELIANCE.NS
python tests/validation/run_vol_comparison.py RELIANCE.NS --quick      # fewer origins
python tests/validation/run_vol_comparison.py RELIANCE.NS --online     # + Ch.5 online-learning arm

# Directional Change: the scaling laws against a random walk, then against NSE
python tests/validation/run_directional_change.py
python tests/validation/run_directional_change.py --n 200 --horizon 5

# Event-based backtesting: what Section 39's vectorized number never showed
python tests/validation/run_event_backtest.py
python tests/validation/run_event_backtest.py --phase 2   # any of the 5 starting days (Section 49)

# Overlapping volatility targets: how much of an RV forecast's score is copying its input?
python tests/validation/run_rv_overlap.py

# Crash risk (NCSKEW / DUVOL): persistent beyond volatility?
python tests/validation/run_crash_risk.py

# Residual reversal through stock futures, on point-in-time F&O names, against itemised costs
python tests/validation/run_futures_reversal.py

# How much removing the duplicate bb_position moved forecasts, against a re-seeding control
python tests/validation/run_bb_position_removal.py

# How much the forecast-origin ATR/range skew moved the tree models' forecasts
python tests/validation/run_origin_skew.py

# Kanwar & Gupta's MACD / Balance-of-Power / Stochastic rules, with the book's own trade count reproduced
python tests/validation/run_kanwar_indicator_rules.py

# Kanwar & Gupta's candlestick patterns: event study, then tradeability (needs pip install TA-Lib)
python tests/validation/run_candlesticks.py

# Kanwar & Gupta's indicators (redundancy) and SMA x RSI setup (PBO, time split)
python tests/validation/run_kanwar_setup.py

# Long memory on NSE (R/S, Lo, DFA, against shuffled nulls) and the book's crash-warning claim
python tests/validation/run_long_memory.py

# The book's RL trading agent vs rules that learn nothing, on its own simulator and a no-drift control
python tests/validation/run_rl_simulation_check.py

# Synthetic returns: KS vs the stylized facts, for a shuffle, a GAN, the block bootstrap and GARCH
python tests/validation/run_synthetic_check.py

# Does the DFA volatility-memory exponent add to HAR-RV's own 21-day variance forecast? (QLIKE, DM)
python tests/validation/run_har_dfa.py

# Wavelet forecasting: whole-series (leaky) vs causal denoising, same rule
python tests/validation/run_wavelet_leak.py

# §59 audit: ARIMAX with no regressors (what shipped) vs same-bar vs lagged (the fix)
python tests/validation/run_arimax_exog.py

# §59 audit: HAR lag tuning with an untouched holdout, against the old contaminated harness
python tests/validation/run_har_lag_tuning.py

# §59 audit: feature-drift false alarms and power, plain vs block permutation null
python tests/validation/run_drift_false_alarm.py

# §59 audit: regime novelty with vs without the raw price column
python tests/validation/run_novelty_price_level.py

# Mladjenovic Ch. 17: the book's fixed stops, beta vs volatility, and which stop-hit estimate is calibrated
python tests/validation/run_stop_loss.py

# Mladjenovic Ch. 6 and 15: the ex-date drop, its size against the cone, and the buildable micro factors
python tests/validation/run_dividend_dates.py

# Mladjenovic Ch. 17: trailing stops and upside targets, and which touch estimate is calibrated
python tests/validation/run_trailing_stops.py

# Thomsett Ch. 8-9: market breadth against the market's next return and volatility, with controls
python tests/validation/run_market_breadth.py

# Benklifa Ch. 5: results days against the cone's coverage, and the measured widening
python tests/validation/run_results_days.py

# Benklifa Ch. 5: the same test for Budget, RBI-policy and F&O-expiry days
python tests/validation/run_market_events.py

# Morales & Kacher Ch. 5 and 7: pocket pivots, major gap-ups, and the market direction model
python tests/validation/run_oneil.py

# Hough Ch. 24 and 6: the falling-knife deal breaker, and the XYZ data-mining experiment
python tests/validation/run_hough_screens.py

# Hough Ch. 19: insider buying from SEBI disclosures, against a momentum- and reversal-matched benchmark
python tests/validation/run_insider_buying.py

# Section 49's residual reversal, out of sample on July-December 2024 (before the reserved period)
python tests/validation/run_reversal_confirmation.py

# Coverage of the Hybrid ARIMA+LSTM's split-conformal 95% band, NSE 2021-07 .. 2024-06
python tests/validation/run_hybrid_coverage.py

# Adaptive conformal (ACI) vs the fixed conformal quantile, 200 names, 2018-07 .. 2024-12
python tests/validation/run_aci_bands.py

# HAR-RV's shipped ACI cone vs its static cone, 57 names, 2019 .. 2024
python tests/validation/run_har_aci_scale.py

# The regime-novelty gate in the 2020 crash and in calm years, against a 20-day volatility reading (slow: about 2 hours)
python tests/validation/run_novelty_stress.py

# Monte Carlo noise in the cone's edge, and whether variance reduction helps quantiles
python tests/validation/run_mc_variance_reduction.py

# 52-week high: George & Hwang's sign or Yan's contrarian one, and does a slow signal clear costs?
python tests/validation/run_52week_high.py

# Technical rules (SMA / momentum / mean reversion): optimised the book's way, then PBO and a time split
python tests/validation/run_technical_rules.py

# Expected shortfall: how large was the Jensen gap (geometric vs arithmetic tail mean)?
python tests/validation/run_es_jensen.py

# Residual reversal: is Section 38's signal idiosyncratic, or a factor bouncing back?
python tests/validation/run_residual_reversal.py

# Price precision: how coarse is the grid, and is Section 38's signal made of it?
python tests/validation/run_price_precision.py
```

The first two drivers checkpoint results to CSV and are **resumable** if interrupted; `run_calibration.py` prints its calibration tables directly (it validates the probabilistic outputs rather than ranking point forecasts — see [§14](#14-validating-the-uncertainty-calibration)). `run_strategy_eval.py`, `run_var_backtest.py` and `run_vol_comparison.py` answer the three questions the statistical leaderboards do not: *is it profitable*, *is the risk number calibrated*, and *does the deep volatility model beat the four-parameter regression*.

---

## Empirical findings

Numbers below are **indicative, not definitive** — a few tickers and origins, so treat them as directional evidence rather than precise rankings. The point is the *method*: walk-forward + a baseline ladder + the Diebold-Mariano significance test, so claims are grounded.

> **Every "ARIMAX+GARCH" row in this section, and in [§22](#22-economic-evaluation-does-the-forecast-make-money), is ARIMA without regressors.** The regressors never reached the model (pmdarima ignored the keyword they were passed under; [§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)). The rows are kept as published because they are correct for the model that ran, and that model is what the meta-ensemble still uses. The context A/B's "neutral for ARIMAX" is therefore not a finding about market regressors at all: ARIMAX could not see them. With the regressors fitted (lagged, as they must be), ARIMAX measures **~3% worse RMSE** than without, on five NSE names.

**Multi-ticker leaderboard** (RELIANCE.NS / TCS.NS / INFY.NS, 4 splits, 5-day horizon, ranked by mean RMSE):

| Model | RMSE mean | beats-naive rate | DM-significant wins | MASE |
|---|---|---|---|---|
| **Ensemble-Stack** | **28.06** | 3/3 | TCS (p=0.0002) | 1.37 |
| ARIMA+GARCH | 32.11 | 3/3 | TCS (p=0.003) | 1.54 |
| RegimeSwitching | 32.47 | 3/3 | TCS, INFY | 1.55 |
| ARIMAX+GARCH | 32.53 | 1/3 | TCS (sig. *worse* on INFY) | 1.56 |
| Meta-Ensemble | 33.15 | 1/3 | — | 1.59 |
| XGBoost / LightGBM / Quantile-LGBM | 33.4–33.8 | 0–1/3 | — | ~1.6 |
| LSTM | 33.98 | 0/3 | — | 1.57 |
| N-BEATS | 63.78 | 0/3 | sig. *worse* (TCS RMSE 111) | 2.41 |

**What the evidence says:**

- **The Diebold-Mariano test is essential.** Several models "beat naive" on RMSE, but statistically-significant edge is **rare and ticker-specific** (concentrated on TCS; none on RELIANCE). "Beats the random walk" on a handful of origins is often inside the noise band — exactly why the DM test was added.
- **The Ensemble-Stack and the statistical models** (ARIMA / Regime-Switching) are the most consistent performers (beat naive on all three tickers; the only DM-significant *wins*).
- **MASE > 1 almost everywhere** — against the one-step naive, genuine multi-step skill is thin at a 5-day horizon.
- **N-BEATS is still unstable** on these tickers (blew up to RMSE 111 on TCS); the earlier capacity reduction helped on US data but isn't sufficient here. Neural nets remain high-variance — never trust a single run's NN ranking.
- **Prophet over-extrapolates** and was under-covered (~0.7–0.78) on some tickers.

**Did market context help? No (the honest result).** A controlled A/B (context ON vs OFF, same models/splits) on the two large-cap Indian tickers:

| Model | RELIANCE Δ RMSE | TCS Δ RMSE | Effect |
|---|---|---|---|
| XGBoost | +10.3% | +6.4% | worse |
| LightGBM | +5.0% | +10.9% | worse |
| Quantile-LGBM | +2.9% | −0.1% | worse / neutral |
| Ensemble-Stack | +0.2% | +0.3% | neutral |
| ARIMAX+GARCH | −0.2% | +0.7% | neutral |

(Δ = change in RMSE; positive = worse.) Adding the eight context columns **hurt the single tree models** and was **neutral** for the ensemble/ARIMAX — none improved. At a 5-day horizon the *contemporaneous* market state has little power over the *next week's* return (the market is itself a random walk), so the extra columns mainly added overfitting surface.

**And excess-return reframing didn't help either.** Predicting the *excess* return (stock − market) instead of the absolute return — A/B'd the same way:

| Model | RELIANCE Δ RMSE | TCS Δ RMSE |
|---|---|---|
| XGBoost | +12.5% | +5.7% |
| LightGBM | +11.2% | +2.4% |
| Quantile-LGBM | +3.5% | +7.8% |
| Ensemble-Stack | −3.4% | +1.6% |

Same pattern — worse for the tree singles, neutral for the ensemble. This is the expected result: because the expected short-horizon market return is ~0, reconstruction re-injects the unforecastable market move, so absolute-price RMSE can't improve unless de-noising the target makes the alpha much more learnable (it doesn't, on single stocks at this horizon). **Conclusion across both experiments: market data helps cross-sectional/ranking problems ("which stock will beat which"), not single-stock absolute-price forecasting at a 5-day horizon.** Both features ship **off by default**.

**Cross-sectional probe (the ranking fork).** A 20-name NSE universe (`run_cross_sectional.py`) showed **12-1 momentum** with the correct sign (rank-IC ≈ +0.02, long-short hit-rate up to 59%) but **not statistically significant** (t ≈ 1) — expected, since real cross-sectional factors have small ICs that need *hundreds* of names to detect. So a ranking product is plausible but unconfirmed at this scale, and pursuing it is a deliberate product fork (rank a universe), not a tweak to the single-ticker app.

**HAR-RV coverage (where the value actually is).** HAR-RV's point RMSE equals the random walk by construction (it *is* the walk); its deliverable is the cone. With the per-horizon **conformal** multiplier, coverage improved (e.g. RELIANCE ~0.80 → ~full) but still under-covers on some tickers (TCS/INFY ≈ 0.80 vs 0.95 target). The residual gap is **static conformal meeting a volatility regime shift** in the unseen horizon — the known limitation that motivates *adaptive* conformal (ACI) in an online monitoring loop (a deployment feature, not a one-shot tweak). Coverage estimates are also noisy at ~25 points.

**Calibration of the probabilistic outputs (`run_calibration.py`).** Validating the uncertainty rather than the point forecast — illustrative single-ticker run (RELIANCE.NS, 5-day horizon, 6 origins):

| Diagnostic | Result | Read |
|---|---|---|
| HAR-RV CRPS, **empirical vs log-normal** (final horizon) | **24.63 vs 25.35** | The fat-tailed empirical read scores *better* — the §13 risk-panel fix helps the proper score, not just in principle. |
| HAR-RV PIT vs Uniform(0,1) | mean 0.47, KS 0.16, **p ≈ 0.39** | Can't reject calibration — the conformal cone is roughly well-calibrated across quantiles, not just at 95%. |
| Coverage quality (per horizon) | coverage 0.83–1.0; tail-miss balance ≈ 0 to −0.17 | Near target; misses lean slightly *upside* here (cone isn't systematically under-stating downside on this name). |
| XGBoost **P(up) reliability** | **ECE ≈ 0.31** (overconfident in the 0.5–0.6 bin) | Directional probabilities are noisy/miscalibrated — the honest reason the app withholds the call when the gate says "No edge". |

These numbers are small-sample and single-ticker (illustrative, not a verdict); a firmer read uses more origins and several tickers (`--with-gate`, more `--splits`). The point is that the harness now *measures* whether the probabilities are honest.

**Adaptive (ACI) vs static conformal — does the adaptation earn its place?** A/B of HAR-RV's cone with `adaptive=False` vs `True` (3 NSE tickers, 18 origins, 5-day horizon, via `compare_static_vs_aci`):

| Ticker | static \|cov−0.95\| | ACI \|cov−0.95\| | static width | ACI width |
|---|---|---|---|---|
| RELIANCE.NS | **0.032** | 0.050 | 10.79% | 10.25% |
| TCS.NS | 0.041 | **0.032** | 10.75% | **9.81%** |
| INFY.NS | 0.041 | **0.032** | 11.96% | **10.96%** |

**The honest read:** average miscoverage is a **tie** (~0.038 both), but ACI yields consistently **~7% narrower** intervals, and it **improves the two names (TCS/INFY) that were the project's documented coverage problem children** — on both coverage *and* width. It slightly over-tightens RELIANCE, an already-well-calibrated calm name. So ACI ships **on by default** as a coverage-neutral, sharpness-positive change whose real upside is regime response — which this calm 2023–2026 window barely exercised.

**Stress-period test — does ACI's benefit actually concentrate in a crash?** `run_stress_test.py` slices RELIANCE's full history (1996→) into volatility regimes and A/Bs the cone in each:

| Window | realised daily vol | static \|cov−.95\| | ACI \|cov−.95\| | static→ACI width |
|---|---|---|---|---|
| COVID crash 2020 | **3.75%** | 0.050 | **0.067** | 16.31% → **18.15%** |
| 2022 drawdown | 1.67% | 0.050 | 0.047 | 13.15% → 12.82% |
| Calm 2024 | 1.44% | 0.043 | 0.040 | 11.14% → 9.92% |

**The honest (and slightly counter-intuitive) result:** in the COVID extreme ACI did exactly what it should *directionally* — it **widened the cone ~11%** — but its coverage came out marginally *worse* than static, because calibrating a band in the fat tail of a crash is genuinely hard; in the milder regimes it sharpened and slightly improved coverage. So the tidy "ACI wins most in stress" hypothesis is **not** borne out on this name: ACI is best summarised as a sharpness-positive, roughly coverage-neutral change that moves the cone the right way under stress without fully solving tail calibration. (Single ticker, small samples — illustrative.)

**Does forward-looking India-VIX sharpen the cone? Not measurably (the honest result).** A/B of the HAR-RV cone with vs without the India-VIX tilt ([§19](#19-forward-looking-volatility-from-india-vix), via `compare_iv_adjust`, ACI on in both arms, 5-day horizon, 18 origins):

| Window | no-IV \|cov−0.95\| | +IV \|cov−0.95\| | no-IV width | +IV width |
|---|---|---|---|---|
| RELIANCE.NS (calm 2021–26) | **0.046** | 0.054 | 17.19% | 17.46% |
| TCS.NS (calm 2021–26) | 0.050 | 0.050 | 20.16% | 20.19% |
| INFY.NS (calm 2021–26) | 0.050 | 0.050 | 15.86% | 16.08% |
| RELIANCE.NS (2019–20 crash, concentrated) | 0.020 | 0.020 | 14.98% | **16.39%** |

In calm regimes implied ≈ realized, so the multiplier sits near 1 and barely moves the cone (RELIANCE slightly worse, the rest unchanged). In the concentrated COVID-crash window the tilt did the **directionally** right thing — it widened the cone ~1.4 pp as VIX spiked — but with **no coverage payoff** on this sample. So the tilt is principled and forward-looking but **unproven on the available NSE data**, and ships **off by default**. The likely reasons it underwhelms here: India VIX is a *market-level* (NIFTY) signal, so it only carries each stock's *systematic* vol slice (single-name option IV, which it cannot access, would be sharper), and the 2021–26 calm window simply offers little implied/realized divergence to exploit.

**Does the asymmetric cone improve tail-miss balance? Mixed (the honest result).** A/B of the symmetric vs asymmetric cone ([§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone), via `compare_asymmetric`, ACI on in both, 5-day horizon, 18 origins). The decisive metric is **tail-miss imbalance** `mean|lower_miss − upper_miss|` (lower = better-balanced):

| Ticker | sym tail-imbalance | asym tail-imbalance | sym \|cov−.95\| | asym \|cov−.95\| |
|---|---|---|---|---|
| RELIANCE.NS | **0.033** | 0.067 | 0.066 | 0.059 |
| TCS.NS | **0.067** | 0.078 | 0.017 | 0.070 |
| INFY.NS | 0.034 | **0.022** | 0.026 | 0.035 |

Better for INFY, worse for RELIANCE/TCS. The reason is statistical: splitting the calibration into two half-size per-side samples adds estimation noise, and on a *near-symmetric* residual distribution (the calm-regime norm) that noise outweighs the asymmetry it is trying to capture. The asymmetric cone is principled and visibly does the right thing under genuine skew (the single-fit example in §20), but on this data it does not reliably beat the symmetric cone, so it ships **off by default**. (The always-on downside *reporting* — expected shortfall, semideviation, vol skew — needs none of this; it reads the empirical distribution directly.)

**Does *any* model beat the random walk after correcting for trying many? No (the rigorous capstone).** `run_spa.py` ran White's Reality Check and Hansen's SPA over a 40-origin loss panel for the fast 9-model subset on RELIANCE.NS (5-day horizon, squared loss, benchmark = random walk):

| Model (best → worst) | mean loss-diff vs RW | SPA t-stat |
|---|---|---|
| ARIMA+GARCH | +1.02 | +0.33 |
| RegimeSwitching | +0.16 | +0.50 |
| HAR-RV | 0.00 | 0.00 *(it **is** the random walk)* |
| ARIMAX+GARCH | −1.45 | −0.50 |
| Ensemble-Stack | −27.7 | −0.53 |
| Meta-Ensemble | −30.5 | −0.87 |
| Quantile-LGBM | −35.6 | −0.68 |
| XGBoost | −47.0 | −1.09 |
| LightGBM | −47.2 | −1.01 |

**White's Reality Check p = 0.899, Hansen's SPA p = 0.874 → H0 not rejected.** Even the best-looking model (ARIMA+GARCH) is comfortably within what trying 9 models would produce by chance, and the gradient-boosted trees are *materially worse* than the random walk. This is the data-snooping-robust confirmation of the project's central, honest finding: **at this horizon, no model has a selection-bias-free edge over the random walk** — which is exactly why the product's value was relocated to calibrated uncertainty.


### Does tuning HAR-RV's lags help? No — the fifth negative result

`tuning.nested_search` over HAR-RV's memory windows, scored by walk-forward negative QLIKE on the variance forecast, 700 inner rows / 300 untouched holdout rows per ticker, exhaustive grid over five lag sets:

| Ticker | Search winner | Holdout (default) | Holdout (tuned) | Δ | Generalises? |
|---|---|---|---|---|---|
| RELIANCE.NS | (1, 3, 10) | 7.81632 | 7.82239 | **+0.00607** | ✅ |
| TCS.NS | (1, 10, 22) | 8.15977 | 8.15899 | −0.00078 | ❌ |
| INFY.NS | (1, 5, 22) | 6.75660 | 6.75660 | 0.00000 | ❌ (picked the default) |
| HDFCBANK.NS | (1, 3, 10) | 8.02523 | 7.93134 | **−0.09388** | ❌ |
| ITC.NS | (1, 3, 10) | 8.01704 | 7.97924 | −0.03780 | ❌ |

**One ticker in five improved, by 0.08% relative — and two got materially worse.** The winning lag set is **ticker-specific** ((1,3,10) three times, (1,10,22) once, and on INFY the search independently re-selected Corsi's canonical (1,5,22)). There is no consistent alternative to ship.

**Verdict: keep the canonical (1, 5, 22).** The inner search reliably found a better *fit* — every ticker's best inner score beat its default — and that fit did not survive contact with held-out data. This is the fifth documented negative result in this project, alongside market context, excess-return reframing, the India-VIX tilt and the asymmetric cone.

**The nesting is what makes this readable.** A conventional non-nested search — pick the best inner score, report it — would have produced "(1, 3, 10) beats the default on 3 of 5 tickers, ship it", and shipped a change that is *worse* on HDFCBANK by 20× the margin it wins on RELIANCE. The structural guard in [§27](#27-hyperparameter-search-nested-so-it-cannot-cheat) is the entire reason the right answer is visible, and it is the reason `nested_search` is the only entry point that returns a reportable number.

> **Correction ([§59](#59-full-audit-of-157--every-module-read-every-offline-driver-re-run-and-what-it-found)): the table above was not measured on an untouched holdout.** `nested_search` scored the holdout by handing the objective the *whole* history, and `qlike_objective_har` spread its five origins over the back half of whatever it was given, so 2 of the 5 "holdout" origins sat inside the 70% the search had been tuned on. The holdout calls now pass `score_from=cut` and the objective scores only after it. Re-measured on NSE bhavcopy (the last 1,000 sessions to 2024-06-30, same 700/300 split; `run_har_lag_tuning.py`):
>
> | Ticker | Search winner | Holdout (default) | Holdout (tuned) | Δ | Old harness Δ |
> |---|---|---|---|---|---|
> | RELIANCE | (1, 5, 15) | 7.67015 | 7.64116 | −0.02899 | −0.01690 |
> | TCS | (1, 3, 10) | 7.82765 | 7.80225 | −0.02540 | +0.04642 |
> | INFY | (1, 3, 10) | 5.68828 | 5.90990 | **+0.22162** | +0.00243 |
> | HDFCBANK | (1, 10, 22) | 8.18644 | 8.17630 | −0.01014 | +0.00712 |
> | ITC | (1, 7, 30) | 8.15913 | 8.11716 | −0.04197 | +0.02171 |
>
> The honest holdout generalises on **1 of 5** names; the old harness, on the same data, would have said **4 of 5** and recommended a change. The verdict above stands, but it is the fixed harness that supports it.

### Is the economic leaderboard itself data-snooped? Now checked

The Sharpe table in [§22](#22-economic-evaluation-does-the-forecast-make-money) ranked seven models and named a winner — which is precisely the data-snooping mistake `run_spa.py` was built to correct for RMSE, left unapplied to the economic table. `strategy_metrics.strategy_return_panel` now assembles the aligned (T, K) panel of `net strategy return − buy-and-hold` differentials, and `run_strategy_eval.py` runs White's Reality Check and Hansen's SPA over it before printing any conclusion.

The panel is intersected on **common origins** across models: the stationary bootstrap resamples rows, so it can only preserve the cross-model dependence if every column refers to the same origin — the same discipline `collect_loss_panel` applies to the loss panel. A model that failed at an origin drops that origin for everyone.

Validated against eight pure-noise "models" on a shared realised-return series: best mean differential +0.0018, **Reality Check *p* = 0.916, SPA *p* = 0.871** — correctly refusing to crown a winner. The driver now prints this **above** the Sharpe leaderboard, with the note that the leaderboard's top row is the best of *K* tries and these p-values say whether that is more than *K* tries would produce by chance.

### Cross-sectional classifier: the probability problem solved, the skill problem not

`run_cross_sectional_clf.py` on **39 NSE names** (TATAMOTORS.NS came back delisted and was dropped with a recorded reason — the survivorship audit working), **77,135 panel rows**, 2018-08 → 2026-08, 5-day horizon, `combined` split (27 training names before 2024-04-18, **12 entirely unseen names after it**):

| | Result |
|---|---|
| Panel | 77,135 rows × 39 tickers → 74,749 labelled |
| Class balance | short 0.30 / nothing 0.42 / buy 0.28 |
| Train / calib / val | 27,046 / 9,045 / 6,887 rows |
| **Calibration ECE** | **0.0647 → 0.0026** (calib block) · **0.0139** (held-out val) |
| Accuracy vs majority | 0.4302 vs **0.4311** |
| Macro F1 | 0.203 |
| Long-short spread | +0.00008 |
| **Rank IC (t)** | **+0.0111 (t = 0.92)** |

**The win: honest probabilities.** The project's derived P(up) — read second-hand off a regression interval — measured **ECE ≈ 0.31**, meaning a forecast saying "60% likely" was off by about 31 percentage points. A model asked *directly* for a probability and then isotonically calibrated scores **ECE 0.0139 on unseen names in unseen dates** — roughly a **22× improvement**. That is a genuine, separable win: the probabilities are now honest *even though* the signal is absent. Those are two different problems and this fixes exactly one of them.

**The null: no cross-sectional skill at 40 names.** Rank IC +0.0111 at **t = 0.92** — right sign, comfortably inside noise, and almost identical to the earlier signal probe's *t* ≈ 1. Accuracy (0.4302) is *below* the majority-class baseline (0.4311); macro F1 is 0.203. Exactly the predicted outcome: real cross-sectional ICs are 0.02–0.05 and need **hundreds** of names to detect. 39 is not hundreds, so this is a **power** result, not evidence against the approach.

**That prediction has since been tested and confirmed — see [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result).** On survivorship-free bhavcopy data at 400 names (100 unseen validation names, 464 dates) the same experiment gives rank IC **+0.0396 at Fama-MacBeth t = 2.24**, replicating across 20 of 20 seed-runs and two disjoint periods at a stable effect size of 0.033–0.037. The null above was a power result exactly as claimed. But attribution shows **the model is not the finding — the factor is**: `log_return_5` *alone* scores IC −0.0524 at *t* = −4.34, beating the model by 1.32× on IC and nearly 2× on *t*. The signal is **short-term reversal**, a long-documented effect, rediscovered rather than learned. Costed in [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc), it **does not survive**: breakeven 6.1 bp round trip, and no holding period from 5 to 42 days clears 25 bp. Real, small, long-known, and worth less than the cost of trading it. Read that section's four caveats before acting on this sentence — in particular, the long-short spread is *not* usable and the classifier's discrete calls remain near-worthless; the ordering is what carries the result.

**The detail worth pausing on: the model abstains.** Of 6,887 validation predictions it called **"do nothing" 6,857 times** — 99.6%. Only 11 longs and 19 shorts. Given an explicit neutral class and a calibrated objective, the classifier independently concluded it had no view, on names it had never seen.

That is the project's central thesis arriving from a completely different direction. Every earlier abstention was **imposed** — a confidence bucket computed from a walk-forward test, a data-quality gate, a novelty check. This one is **emergent**: nothing told the model to abstain, and the 3-class framing simply let "no view" be a first-class answer rather than a threshold applied after the fact. It is the sixth documented negative result, and the first one a model volunteered about itself. That reading is no longer an inference: [§30](#30-testing-the-abstention-claim-class-weighting-and-a-t-statistic-that-was-wrong) tests it against a balanced-weighting counterfactual, and the abstention survives.

*(One caveat on the reliability table: the `[0.0, 0.1)` bin holds 17 of 6,887 rows and shows a −0.29 gap. With that few points the bin is noise; the populated bins that carry the mass — `[0.2, 0.3)` with n = 6,227 — show a gap of −0.007.)*

### The §22–§25 additions: predictions written first, then checked

The economic evaluation, VaR backtesting, Vol-LSTM, CNN-LSTM and the regime-novelty gate were **built and unit-tested before being measured on real data**. Their tests are correctness tests (known-answer arithmetic, synthetic series with a known volatility, engineered exception sequences with a known verdict) — not skill claims. So the predictions below were written *before* the drivers were run, then marked with the outcome; two have been run so far.

| Addition | What to run | Prediction, and what would falsify it |
|---|---|---|
| Economic metrics ([§22](#22-economic-evaluation-does-the-forecast-make-money)) | `run_strategy_eval.py` | **Run — prediction held.** 6 of 7 models lost money net of 10 bps, and no model's Sharpe cleared 2 SE. See the table in §22. |
| VaR backtests ([§24](#24-value-at-risk-estimation-and-var-backtesting)) | `run_var_backtest.py` | **Run — partly held, one surprise.** Every method's breaches were flagged as clustered (expected: with 7,440 evaluations across 1996–2026 the independence test has overwhelming power). The surprise was **Cornish-Fisher**, which *under*-reserved badly at α = 5% — traced to the sign of its kurtosis term inside `|z| < √3` and now documented in §24 and pinned by a test. |
| Vol-LSTM ([§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)) | `run_vol_comparison.py` | **Run — prediction held, but only after a bug fix.** The first run said Vol-LSTM beat HAR-RV; chasing that down found HAR-RV over-stating volatility by ~1.9× (a Jensen correction applied to a log-χ² residual). With that **fixed**, HAR-RV moves from last to second and the deep model loses to HAR-RV, GARCH and EWMA alike — the originally predicted outcome. See the table below. |
| CNN-LSTM ([§23](#23-deep-volatility-forecasting-vol-lstm-and-cnn-lstm)) | `run_full_backtest.py` / `run_multi_backtest.py` | *Not yet run.* Middle of the pack, like the other sequence models; high run-to-run variance. As with N-BEATS, never trust a single run's NN ranking. |
| Regime novelty ([§25](#25-regime-novelty-from-a-denoising-autoencoder)) | `run_novelty_stress.py` | Run ([§71](#71-adaptive-conformal-for-every-model-and-the-novelty-gate-in-a-real-crash--neither-earns-its-place)): 20 names, 2019–2024. It flags 95% of names in the 2020 crash, but in the same week as a plain 20-day volatility reading. It calls 2.7–5.9% of calm sessions "unprecedented" (design 0.5%), and its flag says nothing about the band missing once the volatility reading is known. It stays off. |

Writing the predictions down *before* running the drivers is the same discipline that produced the four documented negative results above (market context, excess returns, IV tilt, asymmetric cone): a stated expectation cannot be retro-fitted to whatever the numbers turn out to be. It earned its keep twice over immediately — both the Cornish-Fisher and the volatility-comparison results were *unexpected*, and in both cases the surprise is what forced an investigation instead of a number quietly filed under "close enough".

### Volatility model comparison — and the latent HAR-RV bias it exposed (now fixed)

`run_vol_comparison.py RELIANCE.NS --quick` (4 origins, 5-day horizon, 1000 bars). Part 1 scores each model's **per-step variance forecast** against the realised `r²`, ranked by QLIKE (the loss robust to the noise in that proxy). The first run produced a result that contradicted the stated prediction, and chasing it down found a real defect:

| Model | QLIKE | forecast vol % | realised vol % | **bias ratio** | cum. sq. error |
|---|---|---|---|---|---|
| **EWMA** (λ=0.94) | **−7.860** | 1.280 | 1.209 | 1.06 | 2.0e−6 |
| GARCH (BIC-selected, Student-t) | −7.794 | 1.259 | 1.209 | 1.04 | 2.0e−6 |
| Vol-LSTM | −7.665 | 1.510 | 1.209 | 1.25 | 2.0e−6 |
| HAR-RV *(before the fix)* | −7.263 | 2.322 | 1.209 | **1.92** | 5.0e−6 |

`bias_ratio` = forecast vol ÷ realised vol. HAR-RV was **over-stating volatility by ~1.9×**, with 2.5× the cumulative squared error of every other model — a defect in the shipped model, not a property of the data. So Vol-LSTM's apparent win over HAR-RV was not the network learning anything clever; it was simply the only one of the two with a correct level transform.

**The cause.** `forecast_har_variance` converted its log-variance forecast to a level with the log-normal Jensen correction `exp(μ + σ²_resid/2)`. That is right for a **Gaussian** residual — but the residual of a regression on `log(r²)` is **log-χ²(1)**, whose variance is `π²/2 ≈ 4.93`. The correction therefore multiplied variance by `e^2.46 ≈ 11.7` where the correct factor is `e^1.27 ≈ 3.6`, netting ~1.9× in volatility terms.

**Why it survived this long.** The **conformal layer silently absorbs it**: the per-horizon multiplier is fitted to the *realised* dispersion, so an inflated σ is cancelled by a deflated `k` and coverage stays correct. The tell-tale was sitting in HAR-RV's own log output the whole time — `k(h) ≈ 1.0–1.3` against a Gaussian 1.96, i.e. calibration working *against* the variance forecast rather than with it. Only a direct level check (this driver's `bias_ratio` column) catches it, which is a good argument for scoring the raw variance and not just the interval.

**The fix.** `forecast_har_variance` now uses `har_level_offset` — the data-estimated constant `c = log(mean RV) − mean(log RV)` — which reproduces the theoretical 1.27 on Gaussian returns and self-adjusts for the percentile clipping and for genuinely fat tails (on RELIANCE it lands at ≈1.45–1.55, correctly higher than Gaussian). It is computed from whatever history slice the caller passes, so each walk-forward calibration origin derives its own offset from past bars only. Re-running the identical comparison:

| Model | QLIKE | forecast vol % | **bias ratio** | cum. sq. error |
|---|---|---|---|---|
| EWMA | **−7.860** | 1.280 | 1.06 | 2.0e−6 |
| **Vol-LSTM** *(offset now model-calibrated)* | **−7.803** | 1.242 | **1.03** | 2.0e−6 |
| **HAR-RV** *(after the fix)* | **−7.796** | 1.273 | 1.05 | 2.0e−6 |
| GARCH | −7.794 | 1.259 | 1.04 | 2.0e−6 |

HAR-RV moves from **last to second-from-last → third**, near-unbiased, with its cumulative squared error down to the field average and `k(h)` now averaging ≈2.4 (straddling 1.96 as it should).

**A second bias, in my own model.** Auditing the above exposed that Vol-LSTM had the *same class* of problem one level down. Its offset was **unconditional** — `c = log(mean RV) − mean(log RV)` on the training block — which corrects the log-χ² transform but leaves the *network's own* conditional bias untouched (measured `bias_ratio` 1.25). Switching to a **model-calibrated** offset — `c = log(mean RV_cal) − mean(predicted log RV_cal)` on the held-out calibration block, i.e. "what constant makes *this model's* forecasts land on the realised level?" — absorbs both in one scalar. Result: `bias_ratio` **1.249 → 1.027** (now the best of the four) and QLIKE **−7.665 → −7.803**, moving it from 4th to 2nd. Fitting one scalar on the calibration block is the same thing the conformal layer already does with its per-horizon multiplier, and the block is held out of training either way, so it adds no lookahead.

**The original prediction was right after all.** With the bug removed, the deep model does **not** beat the four-parameter OLS regression — nor does it beat plain EWMA or GARCH. That is the expected shape of result for a network on ~1000 daily bars, and it is exactly what §"predictions written first" said to expect. The earlier reversal was entirely an artefact of the defect.

**The fix is cone-neutral, as predicted.** Re-running the cone diagnostics at the *identical* settings before and after:

| | coverage (per step) | mean width | final-horizon CRPS (empirical) |
|---|---|---|---|
| Before | 1.00 at every step | 9.22% | 19.71 |
| After | 1.00 at every step | **9.10%** | 19.81 |

Coverage is unchanged, width is marginally *narrower*, and the CRPS difference is well inside noise on 20 step-records — so **every cone A/B published in this document remains valid**. What the fix corrects is the `volatility` column HAR-RV reports (surfaced in the UI and consumed by `iv_data`'s tilt) and its ranking against any unbiased volatility model. Pinned by two regression tests in `test_har_downside.py`, one of which asserts the *old* transform would have failed, so the check cannot pass vacuously.

**Part 2 — cone calibration (the deliverable).** At 10 origins post-fix, HAR-RV's cone covers 0.90–1.00 per step (mean |coverage − 0.95| = 0.050) at a mean width of 9.83%, with empirical CRPS beating the log-normal read (18.69 vs 19.22) and PIT not rejecting calibration (KS = 0.149, *p* = 0.198) though flagged "hump-shaped → intervals too wide". Against Vol-LSTM on the 4-origin quick run, both cones over-covered at 1.00, so coverage is uninformative; Vol-LSTM's cone was ~9% narrower (8.40% vs 9.22%) while HAR-RV won CRPS (19.71 vs 20.36). Four origins on one ticker separates nothing — the honest read is "no separation yet; run more origins across several tickers".

---

## Shared modules reference

| Module | Key functions | Purpose |
|---|---|---|
| `model_utils.py` | `normalize_interval`, `coerce_numeric_columns`, `prepare_log_returns`, `winsorize`/`winsorize_bounds`, `wilder_rsi`, `compute_price_features`, `generate_future_dates` (NSE-calendar-aware), `aci_quantile` (batched adaptive conformal, HAR-RV's procedure; [§71](#71-adaptive-conformal-for-every-model-and-the-novelty-gate-in-a-real-crash--neither-earns-its-place)), `widen_to_monotone` (a band may not narrow with the horizon; [§70](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)), `select_best_garch`, `simulate_price_paths`, `reset_keras_seeds`, `temporal_train_val_split` (embargoed), `default_keras_callbacks`, `forecast_nn_direct`, `configure_compute`/`gpu_available`/`compute_device_label` | All cross-model shared logic: preprocessing, features, **NSE exchange-calendar** future-date generation (holiday/session-aware, 7 hourly bars/session), GARCH selection, Monte Carlo (5,000 paths on every branch, including the fallback that used 1,000 before §54), the direct multi-horizon NN engine with conformal intervals, and GPU/CPU detection. |
| `direct_forecast.py` | `horizon_feature_cols`, `make_horizon_targets`, `training_frame`, `compute_origin_row`, `conformal_halfwidth` (embargoed) | Direct multi-horizon engine and split-conformal calibration for the tree/ML models. The origin row is built from the raw bars, so ATR and range are true range exactly as in training (§55; they were served as close-to-close proxies before, `atr_norm` 46% low). |
| `market_context.py` | `add_market_context`, `add_market_index`, `context_matrix`, `fetch_close_series`, `MARKET_CONTEXT_COLS` | Fetches market/volatility indices; derives causal context features (`add_market_context`) and the `mkt_index` column for excess-return reframing (`add_market_index`). Both **off by default** after A/B testing showed no benefit. |
| `HAR_RV_model.py` | `run_har_rv_prediction` (`adaptive=`/`aci_gamma=`), `fit_har`, `har_level_offset`, `forecast_har_variance`, `_conformal_band_multipliers`, `_aci_multipliers` | HAR realized-volatility model: forecasts the variance cone, converts log→level with a **data-estimated offset** (`har_level_offset` — the Jensen correction it replaced over-stated volatility ~1.9×), conformalizes per horizon, and (default) applies **adaptive conformal (ACI)** so the cone responds to recent regime shifts. Flat random-walk point forecast. |
| `backtest.py` | `walk_forward_backtest` (now also returns `signals` + a `strategy` block), `evaluate_forecast`, `naive_forecast`/`drift_forecast`/`ar1_forecast`, `diebold_mariano`, `min_bayes_factor`/`null_probability_floor`, `confidence_bucket`, `rmse`/`mae`/`smape`/`mase`/`directional_accuracy`/`interval_coverage`, `print_backtest_summary` | Model-agnostic walk-forward evaluation, baseline ladder, DM significance test, the shared skill→label rule (`confidence_bucket`, used by both the UI gate and the calibration harness), skill metrics, **and** the cost-charged economic evaluation of the same forecasts. |
| `cross_sectional_panel.py` | `build_panel`, `add_ticker_features`, `add_cross_sectional_ranks`, `add_labels`, `split_panel`, `feature_columns`, `DEFAULT_UNIVERSE` | Pooled multi-ticker panel — book Ch. 6. Fetches a universe, reuses the existing per-ticker features, adds within-date cross-sectional ranks, builds the 3-class market-neutral label, and splits by **asset**, time, or both. Built against survivorship, cross-sectional look-ahead, and forward-column leakage. |
| `cross_sectional_model.py` | `fit_calibrated`, `predict_proba`, `evaluate`, `expected_calibration_error`, `reliability_table`, `format_report` | 3-class (buy / do nothing / short) classifier with **isotonic probability calibration** — the direct fix for the derived-P(up) ECE ≈ 0.31 problem. Reports ECE before and after, plus rank IC, long-short spread and macro F1. |
| `prediction_log.py` | `log_forecast`, `resolve_outcomes`, `resolved_frame`, `drift_report`, `gate_validation`, `paper_portfolio`, `summary` | Forward prediction log — book Ch. 3 "Going live". Append-only JSONL written at serve time (with the gate verdicts in force), annotated with realised prices as horizons mature. Powers live calibration-drift alerting (binomial-CI gated), live gate validation, and the paper portfolio. Ships **on**; writing is best-effort and never breaks a forecast. |
| `tuning.py` | `nested_search`, `search`, `grid_configs`, `random_configs`, `_tpe_suggest`, `suggest_spaces`, `qlike_objective_har`, `format_search_report` | Hyperparameter search — book Ch. 3. Grid / random / TPE-Bayesian, with a **mandatory nested** wrapper (search on a training prefix, score once on an untouched tail) and a selection-bias warning attached to every result. Pure numpy/pandas; no `hyperopt` dependency. |
| `strategy_metrics.py` | `evaluate_strategy`, `strategy_return_panel`, `sharpe_ratio`, `sortino_ratio`, `information_ratio`, `max_drawdown`, `calmar_ratio`, `information_coefficient`/`rank_information_coefficient`/`ic_t_stat`, **`ic_by_date`/`newey_west_se`/`fama_macbeth_ic`**, **`time_under_water`/`drawdown_series`**, `position_from_signal`, `cumulative_returns`, `period_return_table`, `format_strategy_report`, `probabilistic_sharpe_ratio`, `expected_max_sharpe`, `deflated_sharpe_ratio`, **`probability_of_backtest_overfitting`**, **`india_round_trip_bps`** | Economic (investment-strategy) evaluation — book Ch. 3's metric set. Turns forecasts into a cost-charged return stream and scores it against buy-and-hold. Pure (numpy/pandas only). |
| `var_models.py` | `var_variance_covariance`, `var_historical_simulation`, `var_cornish_fisher`, `var_filtered_historical_simulation`, `var_generative`/`generative_return_samples`, `kupiec_pof_test`, `christoffersen_independence_test`, `christoffersen_conditional_coverage`, `backtest_var`, `compare_var_methods`, `ewma_volatility` | Value-at-Risk estimation **and validation** — book Ch. 9. Five estimators (each documented with the drawback it answers) plus the rolling out-of-sample harness and the calibration/independence test battery. Expected shortfall is the mean of the tail's **simple** returns (`_tail_es`, lognormal closed form for the Gaussian), not a geometric mean (§50). Pure (no SciPy: closed-form χ² tails for df ∈ {1,2}). The block-bootstrap generator keeps about a fifth of the volatility clustering at its default block of 5 (§57). |
| `vol_lstm_model.py` | `run_vol_lstm_prediction`, `build_rv_channels`, `build_vol_lstm`, `train_vol_lstm`, `cumulative_squared_error`, `qlike_loss` | Vol-LSTM — book Ch. 5's deep volatility model, as the deep counterpart to HAR-RV. Direct multi-horizon log-variance forecast with a data-estimated level debias, reusing HAR-RV's conformal + ACI cone machinery. Flat random-walk point path. |
| `CNN_LSTM_model.py` | `run_cnn_lstm_prediction`, `build_cnn_lstm_model`, `train_cnn_lstm` | CNN-LSTM — book Ch. 7's "LSTM over a CNN". Causal Conv1D pattern extraction → max-pool → stacked LSTM, on the shared `forecast_nn_direct` engine (direct multi-horizon + conformal intervals). |
| `autoencoder_regime.py` | `regime_novelty`, `fit_regime_autoencoder`, `build_autoencoder` (vanilla / denoising / sparse), `feature_windows`, `reconstruction_error`, `latent_codes`, `novelty_series` | Denoising autoencoder — book Ch. 4 — repurposed as a **regime-novelty / distribution-shift detector** for the serving gate. Leak-free (fit → held-out reference → score), scale-free, and never fatal (lazy TF, neutral report on failure). |
| `tests/validation/calibration.py` | `crps_sample`/`crps_gaussian`, `collect_step_records`, `coverage_quality`, `crps_report`, `pit_values`/`pit_summary`, `reliability`, `validate_gate`, `compare_static_vs_aci`, `compare_iv_adjust`, `compare_asymmetric` | Validation-only library (not used by the app): CRPS (empirical vs log-normal), PIT calibration, reliability/ECE of P(up) & P(move), coverage quality, nested gate validation, and the cone A/Bs (static-vs-ACI, IV tilt on/off, symmetric-vs-asymmetric incl. tail-miss balance). |
| `tests/validation/multiple_testing.py` | `whites_reality_check`, `hansens_spa`, `collect_loss_panel`, `auto_block_length`, `stationary_bootstrap_indices`, `summarize` | Validation-only library: White's Reality Check + Hansen's SPA over a stationary bootstrap (auto block length, NW-HAC studentizer) — "does any of K models beat the random walk?" |
| `data_quality.py` | `assess_data_quality`, `gate_action`, `DQReport` | Scores a fetched series for fitness (history, staleness, duplicates, bad OHLC, zero-volume, gaps, abnormal jumps, currency status); returns reason codes + a serving mode (`normal`/`warn`/`risk_cone_only`/`abstain`) that the UI gate consumes. Pure (no Streamlit). |
| `iv_data.py` | `forward_vol_factor`, `clear_cache` | Forward-looking volatility tilt for the HAR-RV cone from **India VIX** (`^INDIAVIX`): the implied/realized ratio scaled by the stock's market R². Leak-free (as-of-last-bar), cached, no-op on missing data. Opt-in (`iv_adjust=`). |
| `option_market.py` | `option_view`, `market_view`, `collect_snapshots`, `snapshot_rows`, `fetch_chains`, `parse_chain`, `expiry_view`, `implied_event_move`, `straddle_vol`, `black_price` | The live options view (Benklifa): ATM-straddle implied volatility on a parity forward (Black-76), the expected move to expiry, the 1σ move over the horizon against the panel's, the results-day move priced by the term structure, and a protective put's cost and capped loss. Risk-neutral and live-only (NSE keeps no history), so it is shown, never fed into a forecast; every failure returns None ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)). `collect_snapshots` records one snapshot a day per F&O stock, the option history NSE does not keep |
| `oneil.py` | `stock_signals`, `market_direction`, `distribution_days`, `checklist`, `live_distribution_count`, `MEASURED` | The O'Neil-disciple signals (Morales & Kacher) coded to the book's published rules, on rupee turnover: pocket pivots (core / proper / control), major gap-ups and the gap-low stop, the heavy-volume 50-day sell guide, distribution days and the follow-through state machine. Measured: no edge for pocket pivots, a reversal after major gap-ups, market timing no better than chance, and the 50-day sell guide a lead ([§65](#65-the-oneil-disciple-signals-morales--kacher-trade-like-an-oneil-disciple--pocket-pivots-add-nothing-and-major-gap-ups-lag-the-market)). The app shows them as a checklist with `MEASURED` beside each |
| `charts.py` | `forecast_chart`, `comparison_chart`, `adjusted_ohlc`, `trading_gaps` | The app's charts as plain functions of DataFrames: one model's history (line or adjusted candles), median path and 95% cone from the last close, and every model on one chart, on an axis with weekends, holidays and the overnight gap removed ([§70](#70-the-charts--a-cone-from-the-last-close-trading-days-side-by-side-and-every-model-on-one-chart)) |
| `hough.py` | `build_screens`, `company_screens`, `piotroski`, `roic_series`, `price_facts`, `market_returns`, `MEASURED` | Hough's screens for the UI: every Part Three recipe and Ch. 23 guru screen the free data supports (passes / fails / partly / can't run, criterion by criterion), Ch. 24's deal breakers and survivor checks (Piotroski F-score, ROIC with a 25% tax floor, Sloan accruals, net payout yield, PEG, debt against income, the chart patterns) and Ch. 25's sell signs. EPS is net income per year-end share, refused across a 40% share-count jump. **Information only** ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)). The falling-knife verdict is in `MEASURED` |
| `insiders.py` | `fetch`, `history`, `normalise`, `parse_filing`, `insider_trades`, `leaders`, `signal_events`, `live_view`, `MEASURED` | SEBI insider-trading disclosures from NSE: the archive endpoint (to 2 May 2026) and the new filing index with its XBRL files, normalised to one frame and de-duplicated across exchanges; `history` caches finished months and refuses the reserved period. Hough's Ch. 19 screen on open-market trades by executives, directors and promoters. Measured: +1.71% matched over a quarter (t 1.4), not confirmable ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)) |
| `risk_metrics.py` | `empirical_risk`, `risk_from_interval`, `stop_hit_probability`, `trailing_stop_probability`, `target_touch_probability`, `breakeven_move`, `results_widening`, `results_sessions`, `widen_log_returns`, `normal_cdf` | Pure (no-Streamlit) risk math for the panel: empirical P(up)/P(move)/VaR plus the downside reads (expected shortfall, averaged as simple returns since §50; up/down semideviation; vol skew); log-normal fallback when no empirical sample exists. |
| `microstructure.py` | `corwin_schultz`, `corwin_schultz_adjusted`, `overnight_adjust`, `spread_null`, `roll_spread`, `amihud_lambda`, `kyle_lambda`, `spread_summary` | Bid-ask spread and price impact from daily OHLCV (AFML Ch. 19). Corwin-Schultz is **biased upward by ~0.26x sigma** — it reports a spread where there is none — so the absolute level is **not** a usable cost input, and §39's assumed costs stand. It *does* rank liquidity: **rho = −0.63** against turnover over 1,392 names, monotone across quintiles. Includes the overnight-gap correction the original paper specifies and AFML's snippet omits. No new dependency. |
| `long_memory.py` | `rs_hurst` (book and Anis–Lloyd–Peters corrected), `expected_rs`, `lo_modified_rs`, `dfa` (standard and the book's \|returns\| variant), `fgn` | Long-memory estimators, validated on series with known H. The textbook R/S reads ~0.57 on independent noise and ~0.68 on a short-memory AR(1); Lo's test separates short memory from long (§56). Pure numpy. |
| `synthetic_check.py` | `ks_2samp`, `stylized_facts`, `compare_paths`, `stationary_bootstrap_path` | Validates synthetic return paths: the KS test (marginal only) next to volatility clustering, the 1% tail, the leverage effect and the kurtosis of 20-period sums. A shuffle passes KS and fails clustering (§57). Pure numpy. |
| `stops.py` | `stop_hit_probability`, `stop_for_probability`, `reflection_probability`, `trailing_probability`, `touch_up_probability`, `no_exit_probability`, `endpoint_probability`, `standardised_excursions`, `adjusted_lows`, `beta` | Stop-loss risk (Mladjenovic Ch. 17). A stop triggers on the path, so the end-point probability understates it; the reflection principle (2 × end-point) is what the app ships, measured as the best-calibrated estimate in a calm market and a crash (§60). Trailing stops use Lévy's drawdown law and upside targets the reflection principle, both measured as calibrated ([§62](#62-trailing-stops-and-targets-mladjenovic-stock-investing-for-dummies-ch-17--the-books-8-trailing-stop-is-hit-within-a-quarter-96-of-the-time)) |
| `corporate_events.py` | `dividend_notice`, `upcoming_dividends`, `results_calendar`, `upcoming_results`, `nse_symbol` | Announced ex-dividend dates inside the forecast horizon, from NSE's corporate-action feed, with the expected quoted-price drop (0.85 × the dividend, measured; §60). Advisory: every failure returns None. `results_calendar` reads NSE's board-meeting calendar for results dates, live and historical ([§64](#64-results-days-and-the-options-market-benklifa-think-like-an-option-trader--a-95-band-covered-only-82-of-one-day-windows-holding-a-results-day)) |
| `stock_checklist.py` | `company_checklist`, `build_checklist`, `fetch_inputs`, `horizon_note`, `RISKS`, `statement_fx` | Mladjenovic's company check for the UI: six measurable great-stock hallmarks (Ch. 21) and the Appendix B ratio tests from yfinance's latest annual statements, dividends and NSE's F&O list, each with the book's rule, plus Ch. 9's payout ratio and the size band from NSE's index lists with Ch. 14's small-cap rules. Thomsett's trend tests (inventory turnover, debt capitalization, operating margin, tangible book value; [§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) sit in their own group. Handles lenders (n/a) and negative equity (red flag). **Information only**: feeds no forecast and is not a tested predictor ([§61](#61-a-company-check-beside-the-forecast-mladjenovic-stock-investing-for-dummies-ch-3-4-21-app-b--the-information-the-price-models-cannot-see)). `statement_fx` converts USD-filed statements before they meet the rupee market value ([§67](#67-stock-screens-hough-your-next-great-stock--a-falling-stocks-last-week-tells-you-nothing-and-a-mined-screens-edge-is-what-chance-produces)). Every failure returns None |
| `breadth.py` | `daily_breadth`, `live_breadth`, `ad10_quintile`, `AD10_EDGES`, `NEXT_MONTH_VOL` | Market breadth (Thomsett Ch. 8–9) from the survivorship-free bhavcopy: advances/declines on NSE's adjusted `prevclose`, new 52-week highs/lows on the adjusted chain, McClellan oscillator. Weak breadth forecasts next-month market volatility beyond HAR, leverage and India VIX, not returns; the app shows the live 10-session reading against frozen 2018–2024 quintiles as context only ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)) |
| `range_volatility.py` | `parkinson`, `garman_klass`, `rogers_satchell`, `yang_zhang`, `estimate`, `scale_to_total`, `efficiency`, `compare` | Range-based realized variance from the **high/low already fetched** (Sharma & Mehta Ch. 18 uses Parkinson's `0.361*ln(H/L)^2`). Measured **1.6-2.5x** more precise than `r_t^2` on real NSE bars against a textbook ~5x. Every per-bar estimator is a within-bar ratio and so **immune to corporate-action adjustment**. Wired into HAR-RV via `rv_estimator=`; the A/B is a documented null (§40) and the default stays `'squared'`. |
| `directional_change.py` | `dc_events`, `dc_state`, `scaling_laws`, **`scaling_law_test`**, **`DRIFTLESS_THEORY`**, `sign_flip_path`, `dc_volatility`, `summary`, `format_report`/`format_law_test` | Event-based sampling (Tsang Ch. 6): record a bar only when price reverses by `theta`. The one information-driven bar scheme reachable **without tick data**, so where AFML Ch. 2 was out of range this is not. Split deliberately into a hindsight view (`dc_events`) and a **causal** view (`dc_state`, direction flips at *confirmation*, not at the extreme it later turns out to have started from) — the obvious single-function implementation leaks the future into every bar between the two. Olsen's two "striking discoveries" are reproduced **by a driftless random walk**, so `DRIFTLESS_THEORY` ships the limits (1.0, ln 2, 2.0) as the reference every scaling statistic is read against. `scaling_law_test` runs a sign-flipped null and **defaults to `demean=True`**, because on a trending market the undemeaned test returns a replicable z ≈ +5 from drift alone (§44). Ch. 6.3's volatility measures are genuinely distinct (ρ = +0.53 / +0.39 vs realised vol), but no DC feature carries forward IC of its own: the best (`bars_in_trend`, t = +4.24) is ρ = −0.59 with realised volatility and falls to t = +1.39 once neutralised within volatility quintiles. No new dependency. |
| `event_backtest.py` | `exit_position`, `excursions`, `compare`, `adjust_ohlc`, `summarize`, `format_report` | Path-aware backtesting (Hilpisch Ch. 11). Every other backtest here is **vectorized** — signal × entry-to-horizon return — and therefore blind to the four unobserved days of a five-day hold. `excursions` needs no strategy assumption and is the headline: §39's book earns **+0.13%/rebalance** while its average position goes **−5.59%** against itself first, 38% past −5% (§45). `exit_position` adds stop-loss / take-profit / trailing stops, which a vectorized backtest cannot express at all. Three defaults exist because the naive version is optimistic exactly where it matters: **gap fills** (a stop is not a guaranteed fill — assuming otherwise is worth +13.8%/yr of fiction at a 5% stop), **`adverse_first`** (when stop and target both trigger in one bar, daily data cannot order them), and a **trail computed from prior bars only**. No new dependency. |
| `data_quality.py` — **precision** | `COARSE_PRICE_GRID` code, `tick_share_of_daily_move`, `implied_tick` | The 8th of Buzzelli's quality dimensions (§46); the other seven were already checked. Measures the tick as a share of **one daily standard deviation**, the only form that separates a cheap stock from a quiet one — NSE's ₹0.05 grid is 0.002% of a ₹3,000 share and 2% of a ₹2.40 one. Median name 0.6% (invisible); **11 of 335 exceed 10%**, all distressed penny stocks where ~half of daily returns are exact duplicates. `INFO` above 5%, `WARN` above 15%, and deliberately **never** forces abstention. |
| `bhavcopy.py` | `fetch_day`, `fetch_range`, `load_cache`, `parse_action`, `corporate_actions`, `adjust_prices`, `liquidity_screen`, `build_panel`, `bhav_fetcher`, **`fno_members`** (point-in-time F&O list) | **Point-in-time** NSE prices from the daily bhavcopy — membership is whatever actually traded, so delisted companies are present for exactly the span they existed. Fixes a **26.8%** survivorship gap that yfinance cannot (23 of 30 vanished names return no data there). Handles both the legacy and UDiFF formats via fallback, and reconstructs `adj_close` from splits, bonuses, dividends and rights: validated against yfinance at **return correlation 1.00000 for 24/24 names**. `adjust_prices(as_of=...)` gives a genuinely point-in-time series, closing the back-adjustment look-ahead `tests/audit_price_adjustment.py` documented. `load_cache`/`build_panel` **refuse** reads reaching `HOLDOUT_START` (2025-01-01), the reserved final test period, unless opened with `allow_holdout=True` and a purpose; every opening is logged to `tests/validation/holdout_ledger.csv` (§21). No new dependency. `fetch_day` caches only real files, so a failed download is retried rather than recorded as a holiday ([§63](#63-breadth-break-even-and-balance-sheet-trends-thomsett-stock-market-math--weak-breadth-forecasts-a-more-volatile-market-not-a-falling-one)). `corporate_actions` freezes each settled chunk under `.bhav_cache/actions/` for research runs, and breaks same-day ties by subject, because NSE revises the feed and returns its rows in a different order on each request ([§73](#73-the-label-horizon-paradox-on-the-nse-panel--a-shorter-label-scores-better-and-nothing-can-pick-it)). `symbol_changes` and `add_former_symbols` carry each action to the symbol a renamed company traded under on its ex-date, because NSE files a company's whole history under its current symbol ([§74](#74-renamed-companies-lost-their-corporate-actions)). |
| `fracdiff.py` | `frac_diff`, `frac_weights`, `min_d`, `adf_pvalue`, `kpss_pvalue`, `add_fracdiff_features`, `format_report` | Fractional differencing (López de Prado, via Kaabar Ch. 3) — stationarity that **preserves memory**, plus the project's first ADF/KPSS stationarity testing. On RELIANCE the minimum stationary order is d = 0.50 (corr with level **0.88**) against the d = 1 the pipeline uses (**0.004**). Adds **no parameters** and no new dependency; the forecasting A/B is a documented null (§36). |
| `feature_drift.py` | `drift_table`, `psi`, `psi_null`, `wasserstein`, `wasserstein_null`, `ks_statistic`, `summarise`, `format_report` | **Leading** drift indicator on the model's *inputs*, complementing `prediction_log`'s lagging coverage drift. Two permutation tests decide: PSI catches mass moving *between* reference deciles, **Wasserstein-1** catches mass moving *further out within* them, a tail-widening that leaves decile PSI exactly unchanged and that W1 alone caught in 8.1% of 421 real NSE window pairs (§35). DRIFT if either rejects at α/2 (Bonferroni), which keeps the false-alarm rate at 0.067 against 0.113 for a naive either-at-α rule. Permutation nulls, not the folklore PSI bands — PSI is biased upward on small samples (identical distributions score 0.30 at n=50). Corrects for multiple testing. Closed-form KS, no SciPy. |
| `explain.py` | `importance`, `shap_values`, `explain_prediction`, `concentration`, `supports`, `format_report` | **Exact TreeSHAP** attribution via LightGBM/XGBoost natively — **no `shap` or `lime` dependency**. Verifies the additivity identity rather than assuming it, and returns `None` for unsupported models rather than degrading to an approximation. The `concentration` measure produced §35's finding. |
| `kalman_model.py` | `run_kalman_prediction`, `kalman_filter`, `fit_kalman`, `forecast_kalman` | Damped local linear trend on log prices - the suite's only **state-space** model, re-estimating its state every bar rather than freezing parameters after a fit. Produces a **native** interval from the state covariance (no calibration set), reported alongside the conformal one. Fitted by concentrated (profile) maximum likelihood on a grid; pure NumPy. Reports honestly when it degenerates to a random walk - 70% of origins on real data (§34). |
| `epistemic.py` | `epistemic_spread`, `mc_dropout_predict`, `has_dropout`, `attach`, `format_report` | Monte-Carlo dropout **model** uncertainty (Klaas Ch. 4) - the axis the conformal cone cannot express, since it takes the fitted model as given. Ships **off**: the cross-model comparison **failed its falsifiable check** (§33), because the spread tracks network topology rather than data scarcity. Reported separately from the 95% band, never folded in. |
| `fundamentals.py` | `fundamental_history`, `as_of_join`, `available_from`, `derive_ratios`, `coverage_report`, `current_snapshot`, `to_float` | Point-in-time fundamental features for the pooled panel. Stamps every feature by **publication date** (period end + SEBI reporting lag), derives ratios from raw line items, and **refuses** to join a non-point-in-time frame — `Ticker.info` holds today's values, so joining it to a historical row is undetectable look-ahead. `coverage_report` measures feasibility; on yfinance it is 16% of the panel, so the experiment is blocked (§32). |
| `architectures.py` | `SPECS`, `spec`, `spec_driven`, `describe`, `attach`, `manifest_block`, `fingerprint`, `describe_specs` | Declarative network architectures (JSON-overridable via `architectures.json` / `STOCKAPP_ARCH_FILE`) **and** the realised-architecture record read back off the compiled Keras model. Closes a hole in the reproducibility manifest, which pinned the seed but not the layer stack. Spec-driven: DL, CNN-LSTM, Vol-LSTM; introspection-only: N-BEATS, TCN, Transformer — reported per record. |
| `dependencies.py` | `check`, `missing`, `install`, `plan`, `read_requirements`, `render_install_page` | Standard-library-only dependency check and installer behind `run_app.py` and the guard at the top of `UI.py`. Installs missing packages in two phases under a constraints file of every pin: everything but Prophet with dependencies, then Prophet with `--no-deps` and its own dependencies minus the NumPy/pandas caps it over-declares. Mismatched versions are reported, never changed |
| `config.py` | `FLAGS`, `active_flags`, `overridden`, `describe`, `env_flag`, `env_int`, `GATE_SPLITS`/`GATE_MIN_TRAIN`/`GATE_MAX_ROWS` | Single source of truth for the six `USE_*` feature flags and the serve-time gate tunables. Imports nothing from this project. Each entry carries the measured evidence for its default; the console banner is **generated** from the registry; every flag takes a `STOCKAPP_*` environment override, and an active override is reported in the banner. `python config.py` dumps the lot. |
| `console.py` | `startup_banner`, `run_header`, `run_summary`, `field`, `note`, `strip_markdown`, `short_path` | Terminal mirror of the UI's decision layer (no Streamlit import). Prints the seed / device / active `USE_*` flags at startup, frames each Submit, and renders the end-of-run verdict — data-quality mode, per-model bucket + Basis, consensus, honesty banner. **Renders, never recomputes**, so the console and browser cannot drift. ASCII-only and encoding-safe for legacy Windows code pages; `STOCKAPP_QUIET=1` silences it. |
| `gating.py` | `gated_direction`, `conviction`, `apply_data_quality_gate`, `apply_novelty_gate`, `confidence_reason` | Pure serving-gate logic (no Streamlit): withhold the directional call on "No edge", force "No edge" on degraded/event/cache-fallback data **or an off-manifold market regime**, compute conviction (move ÷ half-band), and build the per-row Basis reason code, which prints the least the probability of no edge can be wherever a badge claims an edge (§51). The trust layer, unit-tested directly. |
| `reproducibility.py` | `set_all_seeds`, `run_manifest`, `GLOBAL_SEED`, `check_pins`, **`data_fingerprint`**, **`diff_manifests`** | Pin every RNG (random/NumPy/TF/torch) per run and build an auditable manifest (seed, versions, pin drift, params, timestamps, and a **fingerprint of the input price data**). The fingerprint matters because adjusted prices are restated retroactively, by up to 6.7% on NSE large caps (§21). `diff_manifests` says which recorded input explains a rerun that didn't reproduce. Makes experiments reproducible, not markets predictable. |
| `safe_fetch.py` | `fetch_with_fallback` | Resilient fetch wrapper: retries + exponential backoff, empty/partial detection, last-known-good disk cache fallback, and a `source` status tag (live/partial/cached_fallback) the data-quality gate consumes. |
| `tests/validation/cross_sectional.py` | `build_panel`, `add_signals`, `rank_ic`, `long_short_spread` | Validation-only library: cross-sectional ranking probe — rank-IC and long-short quintile spread over a universe (research artifact, not in the app). |
| `meta_ensemble.py` | `run_meta_ensemble_prediction` | Cross-family median meta-ensemble. |
| `tests/validation/run_full_backtest.py`, `run_multi_backtest.py`, `run_cross_sectional.py`, `run_calibration.py`, `run_spa.py`, `run_stress_test.py`, `run_strategy_eval.py`, `run_var_backtest.py`, `run_vol_comparison.py` | `main` | Manual evaluation/research drivers (CLI, network, slow — not used by the app): single-ticker leaderboard / multi-ticker variance-aware ranking / cross-sectional signal probe / calibration & gate validation / SPA & Reality Check / stress-period ACI evaluation / **economic (Sharpe-Sortino-drawdown) leaderboard** / **VaR method comparison & Kupiec-Christoffersen tests** / **HAR-RV vs Vol-LSTM vs GARCH volatility comparison**. |

---

## Getting started

### Prerequisites

- Python 3.10+
- (Optional) GPU-enabled TensorFlow for faster deep-learning training

### Installation and first run: one command

```bash
python run_app.py               # checks the packages, installs what is missing, starts the app
```

On Windows, double-clicking **`run_app.bat`** does the same. The launcher lists the packages from `requirements.txt` that are not installed, asks before downloading (`--yes` skips the question, `--check` only reports), installs them, and starts Streamlit. Anything after `--` is passed to Streamlit, for example `python run_app.py -- --server.port 8600`. Packages already installed at a different version from the pin are **reported, not changed**.

Running `streamlit run UI.py` directly is also safe. If a package is missing, the app opens on a setup page that lists it and offers an **Install missing packages** button, instead of failing with a `ModuleNotFoundError` from inside a model module. Streamlit itself has to be installed for that page to appear; `run_app.py` has no such limit.

**Why this is not `pip install -r requirements.txt`.** That command fails with `ResolutionImpossible`: `prophet==1.2.2` declares `numpy<2.4` and `pandas<3`, which contradicts the tested pins. The declaration is conservative metadata (Prophet runs on this stack through the compat patch in `fb_prophet_model.py`). The previously documented workaround, `pip install --no-deps -r requirements.txt`, has the opposite flaw: on a fresh machine it skips every dependency of every package (SciPy, PyTorch for Chronos, cmdstanpy for Prophet), so the app could not import. `dependencies.py` installs in two phases, both under a constraints file holding every pin, so no dependency can move a tested version:

1. every missing package except Prophet, **with** its dependencies;
2. Prophet with `--no-deps`, then Prophet's own dependencies minus the NumPy and pandas caps it over-declares.

Both phases were resolved with `pip install --dry-run --ignore-installed` against a simulated empty environment: 112 packages for phase 1, 19 for Prophet's dependencies, keeping numpy 2.4.6 and pandas 3.0.3. The Prophet path was then installed for real into a fresh virtual environment, and Prophet fitted and forecast on the pinned versions through the app's patch. pip prints an `ERROR: ... dependency conflicts` line about Prophet during phase 2; that is the over-declared cap, and the launcher says so.

A virtual environment is still the cleanest place to install (`python -m venv venv`, then activate it and run `python run_app.py`). Outside one, the launcher adds `--user` when the system site-packages is not writable. A first install downloads a few GB (TensorFlow and PyTorch dominate) and takes several minutes.

**(Optional — Chronos-2):** update the model path in `chronos_model.py` to your local Chronos-2 weights, or let it download if network access is available.

**Nothing else is needed to run the app.** A fresh clone forecasts immediately — the app fetches live history per ticker from yfinance and holds no local dataset.

### (Optional) The research data cache

Only the cross-sectional research drivers need this; **the app does not**. `.bhav_cache/` is ~121 MB of daily NSE bhavcopy files and is deliberately **not** in the repository — it is derived data, regenerable in one command:

```bash
python tests/validation/fetch_bhav_cache.py           # ~60 min, resumable
python tests/validation/fetch_bhav_cache.py 2018-01-01 2020-12-31   # or a slice
```

Re-running is cheap: cached days are skipped, so an interrupted fetch resumes where it stopped. The drivers that need it ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)) print a pointer to this script rather than failing obscurely if it is absent.

Why it exists at all, given the app fetches live data: the app answers *"what will this stock do?"* for a **currently listed** ticker, where delisted companies are irrelevant. The research layer answers *"do these models have any skill?"*, and that question cannot be answered honestly on survivors alone — 26.8% of the 2017 NSE universe no longer appears in today's listing file, and yfinance cannot return it. Survivorship bias does not corrupt forecasts; it corrupts **evaluations**.

### Running the app

```bash
python run_app.py               # or: streamlit run UI.py, once everything is installed
```

Then open the URL shown (typically `http://localhost:8501`):

1. Select a **company** (searches NSE + BSE).
2. Choose the **interval** — Daily or Hourly.
3. Set the **forecast horizon**.
4. Optionally pick which models to run.
5. Click **Submit** to fetch data and generate forecasts.
6. Browse per-model charts and the comparison table.

### Running a backtest

```bash
python tests/validation/run_full_backtest.py AAPL
python tests/validation/run_multi_backtest.py "AAPL,MSFT,GOOGL"
```

### Running the tests and audits

All test/validation scripts live in `tests/` (each is runnable directly or under pytest):

```bash
# Run the whole suite under pytest (from the repo root)
pytest tests/ -q

# …or run any suite as a plain script (no network needed)
python tests/test_intraday_parity.py    # intraday-feature train/serve parity + leak-freeness
python tests/test_data_quality.py       # data-quality gate reason codes & serving modes
python tests/test_iv_data.py            # India-VIX forward-vol factor: leak-freeness, bounds, fallback
python tests/test_har_downside.py       # semivariance split, asymmetric cone, downside risk metrics
python tests/test_reproducibility.py    # seed determinism + run manifest
python tests/test_gates.py              # confidence bucket / abstention / no-edge / conviction gates
python tests/test_safe_fetch.py         # retries, last-known-good cache fallback, source status
python tests/test_strategy_metrics.py   # Sharpe/Sortino/IR/drawdown/IC + cost-aware strategy bundle
python tests/test_backtest_strategy.py  # economic-evaluation wiring in walk_forward_backtest
python tests/test_var_models.py         # VaR estimators + Kupiec / Christoffersen backtests
python tests/test_novelty_gate.py       # regime-novelty gate + pure autoencoder helpers

# Slow suite: contract tests for the new deep models (needs TensorFlow; ~2-4 min
# on CPU). Self-skips the TF-dependent cases if TensorFlow is unavailable.
python tests/test_new_models_smoke.py   # Vol-LSTM / CNN-LSTM / regime autoencoder

# One-shot data-hygiene audit (needs network; fetches a few NSE names)
python tests/audit_price_adjustment.py                    # default NSE basket
python tests/audit_price_adjustment.py RELIANCE.NS TCS.NS
```

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| pandas | 3.0.3 | Data manipulation |
| numpy | 2.4.6 | Numerical computing |
| streamlit | 1.58.0 | Web UI |
| plotly | 6.5.1 | Interactive charts |
| yfinance | 1.4.1 | Market data |
| nselib | 2.4.2 | NSE fallback data |
| requests | 2.32.5 | HTTP calls |
| pandas_market_calendars | 5.3.0 | NSE trading calendar (holiday-aware future dates) |
| pmdarima | 2.1.1 | Auto-ARIMA |
| arch | 8.0.0 | GARCH models |
| statsmodels | 0.14.6 | Regime switching, statistical tests |
| prophet | 1.2.2 | Facebook Prophet |
| xgboost | 3.2.0 | Gradient boosting |
| lightgbm | 4.6.0 | Gradient boosting |
| scikit-learn | 1.9.0 | Preprocessing, Ridge, metrics |
| tensorflow | 2.21.0 | LSTM, GRU, Transformer, N-BEATS, TCN, CNN-LSTM, Vol-LSTM, regime autoencoder |
| chronos-forecasting | 2.2.2 | Amazon Chronos-2 |

---

## Caveats and limitations

- **Not financial advice.** Educational/research use only.
- **The cross-sectional result is a finding, not a strategy.** [§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result) establishes a replicable rank IC of 0.033–0.037 at 200+ names, and that is *all* it establishes — and a single raw feature (`log_return_5`, IC −0.0524) **beats the model outright**, so the contribution of the machine learning here is currently negative. And [§39](#39-costing-the-reversal-signal--the-eleventh-negative-result-and-the-end-of-the-arc) settles the economics: gross Sharpe 0.20, **breakeven 5.0 bp round trip** against a 20 bp STT, 87% book turnover every five days, and only 39% of the universe shortable overnight. **The signal is real and not tradeable.** The long-short spread rests on 148 long calls out of 39,844 predictions and is not a usable economic number; there are no transaction costs, no borrow costs on a book that is 95% short by count, and no capacity analysis anywhere in it. Discrete classification accuracy (0.510) is barely above the majority baseline (0.501) — the model *orders* names better than chance, it does not *classify* them.
- **A smaller survivorship filter survives in the expanded panel.** `cross_sectional_panel.build_panel` requires 300 rows per name, dropping companies that traded under ~14 months inside the window (68 of 400 at the largest size), and a company that fails simply stops appearing in bhavcopy rather than posting a −100% return, so genuine wipeouts are under-represented. Both biases push optimistic. This is far weaker than the 26.8% gap it replaced, and it is not zero.
- **The bhavcopy day cache is a local artefact, not a committed dataset.** ~2,500 gzipped files / ~105 MB under `.bhav_cache/`, rebuilt by `tests/validation/fetch_bhav_cache.py` in ~33 minutes. Delete it freely; nothing in the live app reads it.
- **Markets are near-efficient.** At short horizons the random walk is hard to beat; the value here is calibrated uncertainty, combining models, and honest evaluation — not magic accuracy.
- **Backtest scope is limited** (a few tickers, a handful of origins). Directional-accuracy and coverage figures are noisy; rankings should be confirmed on more tickers before being trusted.
- **Neural nets are stochastic and high-variance**; consider averaging multiple seeds for production use.
- **Prophet and the raw neural nets can misbehave** on some tickers; the meta-ensemble and the conformal intervals exist partly to contain that risk.
- **Hybrid (ARIMA+LSTM)** is the one base model still using recursive forecasting. It gained split-conformal 95% intervals in [§69](#69-a-95-band-for-hybrid-arimalstm--the-last-model-without-one-and-two-slow-paths-found-on-the-way) (95.4% coverage out of sample).
- **Market context uses an India-default proxy.** The cross-sectional features default to NIFTY 50 / India VIX (the app is INR-centric and prioritises NSE/BSE tickers). For a non-Indian ticker these are only an approximate market proxy — the beta/correlation features will be weak. Mapping a ticker to its true home index (e.g. S&P 500 / VIX for US names) is a known refinement.
- **Intraday features are on but not yet A/B-validated.** The hourly NSE-session features ([§3](#3-feature-engineering)) are leak-free and train/serve-consistent, and intraday seasonality is a more defensible signal than daily alpha — but, consistent with this project's discipline, they have **not** been confirmed to improve hourly forecasts by a controlled A/B (the main backtests are daily). They ship on (`USE_INTRADAY_FEATURES = True`) and apply only to the **tree/ML family**; a dedicated **hourly** backtest with the flag on/off is the right way to confirm their value before trusting them.
- **Hourly history is provider-capped.** yfinance serves only a limited intraday lookback (often ~1–2 years, and it varies by ticker/version), so hourly models train on far less data than daily ones. The app surfaces the actual span and warns when it's short, but a thin hourly window genuinely limits what the models can learn.
- **Currency conversion is a dormant safety net ([§16](#16-currency-conversion-to-inr-and-its-audit-trail)).** The universe is **NSE/BSE-only**, so every selectable stock is INR-native and the conversion never runs in normal use (audit tag `none`). When it *does* fire (a foreign ticker via the search fallback, not selectable from the dropdown), it converts per-date at historical FX, with audited degraded fallbacks (live-uniform rescale / unconverted) surfaced as a UI warning/error. Because Indian hourly prices need no FX, **intraday-FX granularity is moot** for this product. *(Fixed along the way: a `DataFrame.drop(columns=…, axis=1)` call threw before the conversion step, so a foreign-currency stock — if ever reached — was returned **unconverted but labelled ₹**; conversion now runs and is tagged.)*
- **Conformal cones track regime shifts only partially.** HAR-RV's cone now applies **Adaptive Conformal Inference (ACI)** over its own recent calibration residuals, so the live multiplier responds to a recent volatility regime (it widens after a run of misses, tightens after easy covers) — this is ACI applied to the in-sample calibration stream and ships on by default. Two honest limits remain: (1) on a *calm* window it can slightly over-tighten an already-well-calibrated name (see [findings](#empirical-findings)); (2) a **fully online loop that persists `α` across successive live requests** (true cross-session deployment monitoring) is still future work. The tree/NN models' static conformal intervals are unchanged; only HAR-RV is adaptive so far.
- **HAR-RV makes no point-forecast claim by design**, so it will always read "No edge" in the confidence column; its value is the calibrated risk cone, surfaced via the chart band and the risk panel.
- **The fat-tailed risk read needs HAR-RV in the run.** The empirical P(up)/P(move)/VaR come from HAR-RV's conformal residual sample; if HAR-RV is deselected, the risk panel falls back to a **log-normal** approximation of each model's interval and says so in the caption. Extending other models to expose an empirical sample is a clean future step (they currently emit only interval bounds).
- **Calibration figures are illustrative.** `run_calibration.py` numbers in this README are single-ticker, small-sample (a handful of walk-forward origins); they demonstrate the harness and the direction of the result, not a firm verdict. A trustworthy calibration claim needs many origins across several tickers. Gate validation is **offline** (a nested backtest), not wired into the live app.
- **The SPA/Reality-Check verdict is small-sample and subset-by-default.** `run_spa.py` aggregates to one loss per origin (T = number of origins ≈ 40), tests the fast 9-model subset unless `--full`, and is computed on a single ticker. The conservative Reality Check drives the headline; Hansen's SPA can be mildly liberal at small T (a known finite-sample property), so a borderline SPA-only rejection is treated as unconfirmed. The current "no edge" verdict is robust to all of this (both p-values ≈ 0.9), but a *positive* finding would warrant more origins/tickers before being trusted.
- **Data-quality thresholds are heuristic.** The gate in `data_quality.py` ([§17](#17-input-data-quality-gating)) uses documented, deliberately-lenient cut-offs (history floors, staleness windows, zero-volume/bad-OHLC fractions, gap days) tuned to catch genuinely broken inputs without nagging on normal market data (holidays, the odd zero-volume bar). They are sensible defaults, not calibrated against a labelled set of "good/bad" feeds; tune the module constants for a stricter or looser policy. The gate runs at request time on the fetched series.
- **The price-adjustment look-ahead is documented, not eliminated.** Training on yfinance's back-adjusted close embeds future corporate-action sizes into a backtest's past bars, but the audit ([§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close)) shows this is immaterial for this return-based, scale-invariant pipeline (live serving has zero leak; only ~0.4–1.6 % of bars differ, and they cancel in DM/SPA/MASE). A strict point-in-time re-adjustment per origin would close the residual but buy nothing measurable, so it is left as a documented, reproducible finding. **This is now closable, and the machinery exists:** `bhavcopy.adjust_prices(as_of=...)` applies only corporate actions known by a given date, so a backtest origin can see the series exactly as it looked then ([§38](#38-universe-expansion-point-in-time-data-and-the-first-positive-result)). The single-ticker app still fetches from yfinance, so the residual remains there; the cross-sectional work no longer has it. Separately, the **nselib daily fallback** was found to be mapping VWAP to `adj_close` (a −89.5% artefact at splits, return correlation 0.527 against yfinance); it now adjusts properly via `bhavcopy` and scores **0.996** — see [§18](#18-price-adjustment-hygiene-adjusted-vs-raw-close).
- **Forward-looking IV is market-level, opt-in, and unproven on this data.** Single-name NSE option IV is not freely/reliably reachable (NSE's API is bot-protected), so the India-VIX tilt ([§19](#19-forward-looking-volatility-from-india-vix)) injects only the *systematic* (NIFTY-linked) slice of forward vol, not stock-specific implied vol. It is leak-free and directionally sensible (widens when VIX spikes) but an A/B showed no measurable coverage gain on the available calm window, so it ships **off** (`USE_IV_ADJUST = False`). A genuine single-name IV feed (a paid vendor, or an authenticated browser session) would be needed to test the stronger version.
- **Downside reads are always on; the asymmetric cone and HAR-RS are opt-in/future.** The expected-shortfall / semideviation / vol-skew reads ([§20](#20-downside-risk-semivariance-expected-shortfall-and-the-asymmetric-cone)) are pure reporting of HAR-RV's empirical distribution and need a fat-tailed model (HAR-RV) in the run. The **asymmetric cone** is principled but A/B-mixed on calm data (per-side calibration is noisier when residuals are near-symmetric), so it ships **off** (`USE_ASYMMETRIC_CONE = False`). A full **HAR-RS** (semivariance-in-the-regression) forecast is deliberately *not* built: it needs recursive component forecasting, and the IV/asymmetric A/Bs both indicate changes to the central variance forecast barely move the empirically-conformalized cone — so it stays documented future work.
- **GPU is used only where it helps.** Deep models and Chronos auto-use a GPU when present; the gradient-boosted trees stay on CPU intentionally (GPU tree training is slower on these small windows).
- **Prophet ↔ pandas 3.0 compatibility.** Prophet 1.2.2's `regressor_column_matrix` builds its component frame with a duplicate-labelled index, which **pandas 3.0**'s stricter `crosstab` rejects (`"cannot reindex on an axis with duplicate labels"`), breaking every Prophet fit. `fb_prophet_model.py` applies a small, idempotent monkey-patch (`add_group_component` → clean `RangeIndex`) so Prophet works on pandas 2.x **and** 3.x. `requirements.txt` now pins **pandas 3.0.3 / numpy 2.4.6** to match the installed, tested environment (the two move together — pandas 3.0 requires numpy 2.x); the patch is retained so the code still runs on pandas 2.x if you downgrade.
- **The app trains on demand** (no model registry). Each Submit fetches data and trains/serves; results are cached per parameter set within a session, but there is no scheduled retraining, drift monitoring, or persisted model store — those are deferred production-grade additions.
- **The resilient-fetch cache is best-effort, and the prediction log is local and single-user.** `safe_fetch` keeps a local last-known-good copy under `.data_cache/` (pickle) and serves it cone-only when a live fetch fails; it is not a versioned store and is safe to delete. The forward **prediction log** with realized-outcome tracking and **calibration-drift monitoring** now exists (`prediction_log.py`, [§28](#28-going-live-the-forward-prediction-log-and-paper-portfolio)), but it is an append-only file under `.prediction_log/` on one machine: there is no shared store, and outcomes are joined only when `resolve_outcomes` is run, not on a schedule. Its numbers need some weeks of served forecasts before they mean anything.

## License

For personal learning and experimentation.
