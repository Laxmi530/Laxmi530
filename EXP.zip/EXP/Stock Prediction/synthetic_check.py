"""
Does synthetic return data have the properties of the real data it imitates?

Hilpisch, *Reinforcement Learning for Finance*, Ch. 5, trains a GAN on log
returns and validates it with a Kolmogorov-Smirnov test: all 25 synthetic
samples pass at 5%, and the chapter concludes the GAN provides "synthetic
data sets that have all the qualities of the original data set" (p. 80).

KS cannot support that conclusion. It compares the MARGINAL distribution of
one-period returns and nothing else, so it is blind to every property that
lives in the ORDER of the returns -- above all volatility clustering, which
is what makes multi-day risk fat-tailed. A shuffled copy of the real series
has exactly the real marginal distribution and no clustering at all, and it
passes KS perfectly. KS is also least sensitive in the tails, where its
CDF-distance statistic is smallest and where risk lives.

``compare_paths`` reports KS alongside the stylized facts it cannot see:

- volatility clustering: mean autocorrelation of |r| over lags 1-20,
  as a ratio synthetic / real;
- the left tail: the 1% quantile, as a ratio;
- the leverage effect: corr(r_t, |r_{t+1}|), which is negative in equities;
- aggregation: excess kurtosis of 20-period sums, as a ratio. Clustering is
  what keeps multi-day sums fat-tailed; independent draws thin out fast.

Pure numpy; the KS p-value uses the asymptotic Kolmogorov distribution.
"""

import math

import numpy as np

_EPS = 1e-12


def ks_2samp(a, b):
    """
    Two-sample Kolmogorov-Smirnov statistic and asymptotic p-value.

    D is the largest gap between the two empirical CDFs. The p-value uses the
    Kolmogorov distribution with Stephens' small-sample correction, which is
    what ``scipy.stats.ks_2samp`` reports for large samples (method='asymp').
    """
    a = np.sort(np.asarray(a, dtype=np.float64)[np.isfinite(a)])
    b = np.sort(np.asarray(b, dtype=np.float64)[np.isfinite(b)])
    n, m = len(a), len(b)
    if n < 2 or m < 2:
        return {"D": float("nan"), "p": float("nan")}
    allv = np.concatenate([a, b])
    cdf_a = np.searchsorted(a, allv, side="right") / n
    cdf_b = np.searchsorted(b, allv, side="right") / m
    d = float(np.max(np.abs(cdf_a - cdf_b)))
    en = math.sqrt(n * m / (n + m))
    lam = (en + 0.12 + 0.11 / en) * d
    if lam < 1e-8:
        return {"D": d, "p": 1.0}
    if lam < 1.18:
        # Small lambda: the alternating series converges badly (it sums to
        # 0 at lambda = 0), so use the complementary theta-function form.
        cdf = (math.sqrt(2.0 * math.pi) / lam) * sum(
            math.exp(-((2 * k - 1) ** 2) * math.pi ** 2 / (8.0 * lam * lam)) for k in range(1, 50))
        p = 1.0 - cdf
    else:
        p = 2.0 * sum((-1) ** (k - 1) * math.exp(-2.0 * k * k * lam * lam) for k in range(1, 101))
    return {"D": d, "p": float(min(max(p, 0.0), 1.0))}


def _acf(x, lag):
    x = x - x.mean()
    den = float(x @ x)
    return float(x[lag:] @ x[:-lag]) / den if den > _EPS else float("nan")


def stylized_facts(x, max_lag=20, agg=20):
    """The properties of a return path that KS cannot see, plus its moments."""
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    z = (x - x.mean()) / max(x.std(), _EPS)
    s = np.convolve(x, np.ones(agg), mode="valid")
    zs = (s - s.mean()) / max(s.std(), _EPS)
    return {
        "sd": float(x.std()),
        "skew": float(np.mean(z ** 3)),
        "excess_kurtosis": float(np.mean(z ** 4) - 3.0),
        "q01": float(np.quantile(x, 0.01)),
        "acf_r_lag1": _acf(x, 1),
        "acf_abs_mean": float(np.nanmean([_acf(np.abs(x), k) for k in range(1, max_lag + 1)])),
        "leverage": float(np.corrcoef(x[:-1], np.abs(x[1:]))[0, 1]),
        f"kurtosis_sum{agg}": float(np.mean(zs ** 4) - 3.0),
    }


def compare_paths(real, synth, max_lag=20, agg=20):
    """
    Compare a synthetic return path with the real one it imitates.

    Returns
    -------
    dict
        {'ks_D', 'ks_p', 'passes_ks', 'clustering_ratio', 'tail_ratio',
        'leverage_real', 'leverage_synth', 'agg_kurtosis_ratio', 'real',
        'synth', 'verdict'}. The verdict lists every stylized fact the
        synthetic path misses by more than half, even when KS passes.
    """
    fr, fs = stylized_facts(real, max_lag, agg), stylized_facts(synth, max_lag, agg)
    ks = ks_2samp(real, synth)
    ratio = lambda k: fs[k] / fr[k] if abs(fr[k]) > _EPS else float("nan")
    out = {"ks_D": ks["D"], "ks_p": ks["p"], "passes_ks": bool(ks["p"] > 0.05),
           "clustering_ratio": ratio("acf_abs_mean"), "tail_ratio": ratio("q01"),
           "leverage_real": fr["leverage"], "leverage_synth": fs["leverage"],
           "agg_kurtosis_ratio": ratio(f"kurtosis_sum{agg}"), "real": fr, "synth": fs}
    misses = []
    if not (0.5 <= out["clustering_ratio"] <= 2.0):
        misses.append("volatility clustering")
    if not (0.8 <= out["tail_ratio"] <= 1.25):
        misses.append("1% tail")
    if fr["leverage"] < -0.02 and fs["leverage"] > fr["leverage"] / 2:
        misses.append("leverage effect")
    if np.isfinite(out["agg_kurtosis_ratio"]) and not (0.5 <= out["agg_kurtosis_ratio"] <= 2.0):
        misses.append(f"fat tails of {agg}-period sums")
    out["verdict"] = ("matches every checked fact" if not misses
                      else "misses: " + ", ".join(misses))
    return out


def stationary_bootstrap_path(x, n, block_mean=5, seed=0):
    """
    One path of length n from the stationary block bootstrap (Politis &
    Romano 1994) -- the same scheme as ``var_models.generative_return_samples``,
    but returning the PATH rather than a horizon sum, so its time structure
    can be checked.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    rng = np.random.default_rng(seed)
    p = 1.0 / max(block_mean, 1)
    out = np.empty(n)
    i = int(rng.integers(0, len(x)))
    for t in range(n):
        out[t] = x[i]
        i = int(rng.integers(0, len(x))) if rng.random() < p else (i + 1) % len(x)
    return out
