"""
A company check from Mladjenovic, *Stock Investing For Dummies* (7th ed.):
Ch. 21's "Ten Indicators of a Great Stock" and Appendix B's ratio rules of
thumb, scored live for the selected stock.

What this is, and what it is not
--------------------------------
**Information for the user, not a forecast input.** Every model in this project
sees prices only; none of them can tell a company that is losing money from one
that is not. The book's answer to that blind spot is a fundamentals checklist,
so the app shows one beside the forecast.

It is **not** a validated return predictor. Testing it would need the
statements as they stood on each past date, and README section 32 measured that
yfinance holds about a year of point-in-time history per NSE name, so the test
cannot be run. Showing *today's* statements for *today's* decision is the use
``fundamentals.current_snapshot`` was always fine for; joining them to a
historical panel is the look-ahead it refuses.

Scoring
-------
Six of the ten hallmarks can be measured from statements, dividends and NSE's
F&O list; the other four (a growing market, a high barrier to entry, a low
political profile, favourable megatrends) are judgement calls and are listed as
such rather than guessed. The book's own bar: a stock with half of the ten is
"a super-solid choice". Appendix B adds the ratio tests, grouped as the book
groups them; it says a solid company should at minimum pass the profitability
and solvency ones.

Every threshold below is the book's, quoted in ``rule``, except one: the
sales-to-receivables flag (a 20% fall in a year) is this project's, because the
book gives a worked example (the ratio halving) rather than a cut-off.

Banks and other lenders fund themselves with deposits, so liabilities dwarf
equity by design and current/quick ratios are not reported; those checks return
``n/a`` with the reason, following the book's own warning to judge ratios
against industry norms.
"""

import math

import pandas as pd

GOOD, WATCH, BAD, NA, INFO = "good", "watch", "red_flag", "n/a", "info"
ICON = {GOOD: "✅", WATCH: "⚠️", BAD: "❌", NA: "➖", INFO: "ℹ️"}

# Book thresholds (Ch. 21 and Appendix B).
PE_BARGAIN = 15.0            # "a P/E ratio of 15 or less is a good value"
PE_CONSERVATIVE = 20.0       # "10 to 20 times earnings is a conservative strategy"
PE_SPECULATIVE = 40.0        # "higher than 40 should be considered a speculation"
LIAB_TO_EQUITY_MAX = 1.0     # debt-to-net-equity "exceeds 1 ... that isn't good"
CURRENT_RATIO_GOOD = 2.0     # "a current ratio of 2 or more is desirable"
CURRENT_RATIO_FLOOR = 1.0    # "less than 1 is a red flag"
QUICK_RATIO_FLOOR = 1.0      # quick assets at least equal current liabilities
ROE_GOOD = 0.10              # "an ROE that exceeds 10 percent ... is good"
ROE_TO_ROA_LEVERAGE = 5.0    # the book's problem case: ROE 25% on ROA 5%
PS_VERY_CHEAP = 2.0          # "a PSR of 2 or lower are considered very undervalued"
PS_FINE = 4.0                # "typically look for under 3 or 4"
PS_HESITANT = 5.0            # "be very hesitant ... greater than 5"
PAYOUT_GOOD = 0.70           # Ch. 9: "a good range is 50 to 70 percent" (60 or less "very safe")
PAYOUT_MAX = 0.80            # Ch. 9: "the maximum acceptable payout ratio should be 80 percent"
SMALL_CAP_YEARS = 3          # Ch. 14: "in business for at least three years is a good minimum"
SMALL_CAP_MARGIN = 0.10      # Ch. 14: "net profits of 10 percent or more over two years or longer"
# Thomsett, *Stock Market Math*, Ch. 6-7, judges these by their TREND, not a
# level; the two cut-offs below are this project's, to keep a rounding-sized
# move from reading as a deterioration.
TURNOVER_FALL_FLAG = 0.10    # inventory turnover down by a tenth in a year
INVENTORY_MATERIAL = 0.02    # below 2% of assets, inventory turnover is noise
DCR_RISE_PP = 0.02           # debt share of capital up 2+ points over the years shown
SR_FALL_FLAG = 0.20          # this project's cut-off (see module docstring)
MARGIN_FLAT_PP = 0.005       # margins within half a point count as unchanged

FINANCIAL_SECTORS = ("Financial Services",)

# Size bands (Ch. 1, Ch. 14). The book's are US-dollar cut-offs; on NSE the
# equivalent is SEBI's rank-based classification (top 100 large, 101-250 mid,
# the rest small), which NSE's broad indices are built from.
CAP_BANDS = (("Large cap", ("NIFTY 50", "NIFTY NEXT 50"), "top 100 by market value"),
             ("Mid cap", ("NIFTY MIDCAP 150",), "ranks 101-250"),
             ("Small cap", ("NIFTY SMALLCAP 250",), "ranks 251-500"))

JUDGEMENT_HALLMARKS = (
    ("The market is growing",
     "Are more customers buying what this company sells each year?"),
    ("A high barrier to entry",
     "Brand, patents, licences, scale: how hard is it for a rival to copy?"),
    ("A low political profile",
     "Could one regulation or policy change hurt this industry?"),
    ("Favourable megatrends",
     "Is a large, lasting trend pushing demand its way?"),
)

# Ch. 4's kinds of risk, and where (if anywhere) this app accounts for them.
RISKS = (
    ("Market risk and volatility",
     "Prices swing on supply and demand, even for sound companies.",
     "Modelled: the forecast cone, the Risk & Probability panel and the stop rows."),
    ("Financial risk",
     "The company loses money or fails.",
     "Not in the forecast. The company check is the book's tool for it."),
    ("Interest-rate risk",
     "Rate changes move borrowing costs, bond yields and share prices.",
     "Not modelled."),
    ("Inflation risk",
     "Gains that trail inflation lose purchasing power.",
     "Not modelled: prices and returns are nominal rupees."),
    ("Tax risk",
     "Tax decides how much of a gain you keep.",
     "Not modelled: returns are before tax and trading costs."),
    ("Political and governmental risk",
     "One law or regulation can make or break a company.",
     "Not modelled: nothing in past prices anticipates it."),
    ("Personal risk",
     "Needing the money at a bad time forces a sale at a loss.",
     "Not modelled: match the money's purpose to the horizon."),
    ("Emotional risk",
     "Greed, fear and attachment to a stock override discipline.",
     "The Confidence column and the honesty banner exist so a forecast is not "
     "read as a certainty."),
)


def horizon_note(horizon, interval="1d"):
    """The book's name for a holding of this length (Ch. 3)."""
    days = horizon if interval == "1d" else horizon / 6.0
    span = (f"{horizon} trading day{'s' if horizon != 1 else ''}"
            if interval == "1d" else f"{horizon} hourly bars (about {days:.1f} sessions)")
    return (f"This forecast covers {span}. Mladjenovic (Ch. 3) calls holding a "
            "stock for less than a year trading or short-term speculation, not "
            "investing, because short-term prices are driven by what millions of "
            "people do next. It is a read of the next few sessions, not a verdict "
            "on the company; the company check below is the book's tool for that.")


# ---------------------------------------------------------------------------
# Statement helpers
# ---------------------------------------------------------------------------

def _finite(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return float("nan")
    return x if math.isfinite(x) else float("nan")


def _ok(x):
    return isinstance(x, float) and math.isfinite(x)


def _row(frame, *names):
    """One statement line, oldest period first, missing periods dropped."""
    if not isinstance(frame, pd.DataFrame) or frame.empty:
        return pd.Series(dtype=float)
    for name in names:
        if name in frame.index:
            s = pd.to_numeric(frame.loc[name], errors="coerce")
            s.index = pd.to_datetime(s.index)
            s = s[s.apply(lambda v: math.isfinite(v))]
            if len(s):
                return s.sort_index()
    return pd.Series(dtype=float)


def _div(a, b):
    a, b = _finite(a), _finite(b)
    if not (_ok(a) and _ok(b)) or abs(b) < 1e-12:
        return float("nan")
    return a / b


def _ratio_series(num, den):
    """Ratio of two statement lines on their common periods."""
    common = num.index.intersection(den.index)
    out = pd.Series({p: _div(num[p], den[p]) for p in common}, dtype=float)
    return out[out.apply(_ok)].sort_index() if len(out) else out


def _money(x, currency):
    if not _ok(x):
        return "—"
    sign = "−" if x < 0 else ""
    if currency == "INR":
        return f"{sign}₹{abs(x) / 1e7:,.0f} cr"
    return f"{sign}{currency} {abs(x) / 1e6:,.0f}m"


#: Approximate rupees per US dollar, for statements filed in dollars (Infosys,
#: for one, reports to yfinance in USD while its share price is in rupees).
USD_INR = 88.0


def statement_fx(info):
    """
    Rupees per unit of the statements' currency, so a statement figure can be
    set against the rupee market value. NaN for a pair this module does not
    know, which makes every such ratio "not available" rather than wrong.
    """
    info = info or {}
    fin = str(info.get("financialCurrency") or "INR").upper()
    quote = str(info.get("currency") or "INR").upper()
    if fin == quote:
        return 1.0
    if fin == "USD" and quote == "INR":
        return USD_INR
    return float("nan")


def _check(label, value, verdict, rule):
    return {"label": label, "value": value, "verdict": verdict,
            "icon": ICON[verdict], "rule": rule}


def _rising(series, currency, what):
    """Rising profits / rising sales: latest year against the year before."""
    rule = (f"Rising {what} (Ch. 21): compare each year with the one before; "
            "three years gives a good gauge.")
    if len(series) < 2:
        return _check(f"Rising {what}", "fewer than two annual reports", NA, rule)
    vals = series.values
    ups = sum(1 for a, b in zip(vals[:-1], vals[1:]) if b > a)
    latest, prior = vals[-1], vals[-2]
    change = _div(latest - prior, abs(prior))
    text = (f"{_money(prior, currency)} → {_money(latest, currency)} "
            f"(FY{series.index[-1].year}, {change * 100:+.1f}%); "
            f"up in {ups} of the last {len(vals) - 1} years")
    if what == "profits" and latest <= 0:
        return _check(f"Rising {what}", text + "; a loss", BAD, rule)
    return _check(f"Rising {what}", text, GOOD if latest > prior else WATCH, rule)


def _ttm_dividends(dividends, today):
    """Trailing-12-month cash dividends now, a year ago and two years ago."""
    if dividends is None or len(dividends) == 0:
        return [0.0, 0.0, 0.0]
    d = dividends.copy()
    idx = pd.to_datetime(d.index)
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_localize(None)
    d.index = idx
    today = pd.Timestamp(today).tz_localize(None) if pd.Timestamp(today).tz else pd.Timestamp(today)
    out = []
    for k in range(3):
        end = today - pd.Timedelta(days=365 * k)
        start = end - pd.Timedelta(days=365)
        out.append(float(d[(d.index > start) & (d.index <= end)].sum()))
    return out


# ---------------------------------------------------------------------------
# The checklist
# ---------------------------------------------------------------------------

def build_checklist(inputs, last_price=None, today=None):
    """
    Score one company against Ch. 21's measurable hallmarks and Appendix B.

    Parameters
    ----------
    inputs : dict
        ``income`` and ``balance`` (yfinance annual statements: line items by
        period), ``info`` (yfinance ``Ticker.info``), ``dividends`` (a dated
        Series of cash dividends per share), ``symbol`` (NSE symbol or None) and
        ``fno_symbols`` (a set, or None when the F&O list could not be read).
    last_price : float, optional
        The last close, for the P/E and yield fallbacks.
    today : date-like, optional
        "Now" for the trailing-dividend windows (injectable for tests).

    Returns
    -------
    dict or None
        ``hallmarks``, ``judgement``, ``ratios`` (list of (group, checks)),
        ``met``, ``measured``, ``minimum`` (profitability / solvency tallies),
        ``fiscal_year_end``, ``sector``, ``industry``, ``is_financial`` and
        ``summary``. None when there are no statements at all.
    """
    income, balance = inputs.get("income"), inputs.get("balance")
    info = inputs.get("info") or {}
    revenue = _row(income, "Total Revenue", "Operating Revenue")
    net = _row(income, "Net Income", "Net Income Common Stockholders")
    if revenue.empty and net.empty:
        return None
    equity = _row(balance, "Stockholders Equity", "Common Stock Equity")
    liabilities = _row(balance, "Total Liabilities Net Minority Interest",
                       "Total Liabilities")
    assets = _row(balance, "Total Assets")
    cur_assets = _row(balance, "Current Assets")
    cur_liab = _row(balance, "Current Liabilities")
    inventory = _row(balance, "Inventory")
    receivables = _row(balance, "Accounts Receivable", "Receivables")

    currency = info.get("financialCurrency") or info.get("currency") or "INR"
    sector, industry = info.get("sector"), info.get("industry")
    is_fin = sector in FINANCIAL_SECTORS
    fin_why = ("not meaningful for a lender: deposits are liabilities by design "
               "(Appendix B: judge ratios against industry norms)")
    price = _finite(last_price if last_price is not None else info.get("currentPrice"))
    # Liabilities above assets: every ratio with equity in it changes sign and
    # stops meaning anything, and a negative P/B would otherwise read as cheap.
    neg_equity = bool(len(equity)) and equity.iloc[-1] <= 0
    neg_why = "negative net equity: liabilities exceed assets"
    today = pd.Timestamp(today) if today is not None else pd.Timestamp.now()

    hallmarks = [_rising(net, currency, "profits"),
                 _rising(revenue, currency, "sales")]

    # Low liabilities: the book's debt-to-net-equity uses TOTAL liabilities.
    le = _ratio_series(liabilities, equity)
    rule = ("Low liabilities (Ch. 21; App. B debt-to-net-equity = total "
            "liabilities ÷ net equity): above 1 isn't good, and higher is worse.")
    if is_fin:
        hallmarks.append(_check("Low liabilities", fin_why, NA, rule))
    elif neg_equity:
        hallmarks.append(_check("Low liabilities", neg_why, BAD, rule))
    elif le.empty:
        latest_eq = equity.iloc[-1] if len(equity) else float("nan")
        hallmarks.append(_check(
            "Low liabilities",
            "negative net equity" if _ok(_finite(latest_eq)) and latest_eq <= 0
            else "not reported", BAD if _ok(_finite(latest_eq)) and latest_eq <= 0 else NA,
            rule))
    else:
        v = le.iloc[-1]
        trend = ""
        if len(le) >= 2:
            trend = "; lower than a year earlier" if v < le.iloc[-2] else "; higher than a year earlier"
        verdict = BAD if equity.iloc[-1] <= 0 else (GOOD if v <= LIAB_TO_EQUITY_MAX else WATCH)
        hallmarks.append(_check("Low liabilities",
                                f"liabilities {v:.2f}× net equity{trend}", verdict, rule))

    # Bargain price: P/E first, P/B at or below 1 as the book's second route.
    pe = _finite(info.get("trailingPE"))
    eps = _row(income, "Diluted EPS", "Basic EPS")
    if not _ok(pe) and len(eps) and _ok(price) and eps.iloc[-1] > 0:
        pe = _div(price, eps.iloc[-1] * statement_fx(info))
    pb = _finite(info.get("priceToBook"))
    rule = ("Bargain price (Ch. 21, App. B): P/E 15 or less is good value; 10-20 "
            "is the conservative range; above 40 is speculation; no earnings, no "
            "bargain. A price at or below book value can also be a bargain.")
    losing = len(net) and net.iloc[-1] <= 0
    if losing or (len(eps) and eps.iloc[-1] <= 0 and not _ok(pe)):
        hallmarks.append(_check("Bargain price", "no earnings (no P/E): a speculation, "
                                "not an investment", BAD, rule))
    elif not _ok(pe):
        hallmarks.append(_check("Bargain price", "P/E not available", NA, rule))
    else:
        if neg_equity:
            verdict, why = BAD, "a low P/E, but " + neg_why
        elif pe <= PE_BARGAIN or (_ok(pb) and 0 < pb <= 1.0):
            verdict, why = GOOD, "good value"
        elif pe <= PE_CONSERVATIVE:
            verdict, why = WATCH, "inside the conservative 10-20 band, above the bargain line"
        elif pe <= PE_SPECULATIVE:
            verdict, why = WATCH, "not a bargain"
        else:
            verdict, why = BAD, "above 40: priced as a speculation"
        pb_txt = f", P/B {pb:.2f}" if _ok(pb) else ""
        hallmarks.append(_check("Bargain price", f"P/E {pe:.1f}{pb_txt}: {why}", verdict, rule))

    # Growing dividends: trailing-12-month cash per share, against a year ago.
    ttm = _ttm_dividends(inputs.get("dividends"), today)
    rule = ("Growing dividends (Ch. 21): a dividend is paid from real profit, and a "
            "rising one is hard evidence the company is doing well.")
    if ttm[0] <= 0 and ttm[1] <= 0:
        hallmarks.append(_check("Growing dividends", "no cash dividend in the last two years",
                                WATCH, rule))
    else:
        yld = _div(ttm[0], price)
        y_txt = f" (yield {yld * 100:.1f}%)" if _ok(yld) else ""
        text = (f"last 12 months {ttm[0]:,.2f}/share{y_txt}, against {ttm[1]:,.2f} and "
                f"{ttm[2]:,.2f} in the two years before; special dividends make this noisy")
        hallmarks.append(_check("Growing dividends", text,
                                GOOD if ttm[0] > ttm[1] else WATCH, rule))

    # Optionable: on NSE, options trade only on F&O-segment stocks.
    rule = ("Optionable (Ch. 21): listed options give ways to add return or limit "
            "losses. On NSE that means the F&O segment.")
    fno, sym = inputs.get("fno_symbols"), inputs.get("symbol")
    if fno is None or not sym:
        hallmarks.append(_check("Optionable", "F&O list unavailable", NA, rule))
    elif sym in fno:
        hallmarks.append(_check("Optionable", "in NSE's F&O segment", GOOD, rule))
    else:
        hallmarks.append(_check("Optionable", "not in NSE's F&O segment", WATCH, rule))

    # ---- Appendix B ------------------------------------------------------
    # Thomsett, Ch. 2: a year's profit is earned on the capital employed
    # THROUGH the year, so divide by the average of the opening and closing
    # balance; year-end alone understates a growing company's return and
    # overstates a shrinking one's. One reported year falls back to year-end.
    roe_s, roa_s = _ratio_series(net, _average_balance(equity)), _ratio_series(net, _average_balance(assets))
    margin = _ratio_series(net, revenue)
    roe = roe_s.iloc[-1] if len(roe_s) else float("nan")
    roa = roa_s.iloc[-1] if len(roa_s) else float("nan")

    profitability = []
    rule = ("Return on equity = net income ÷ net equity (averaged over the year, Thomsett "
            "Ch. 2); above 10% is good.")
    if neg_equity:
        profitability.append(_check("Return on equity", neg_why + ", so ROE is meaningless", BAD, rule))
    elif not _ok(roe):
        profitability.append(_check("Return on equity", "not reported", NA, rule))
    else:
        profitability.append(_check("Return on equity", f"{roe * 100:.1f}%",
                                    GOOD if roe > ROE_GOOD else (WATCH if roe >= 0 else BAD), rule))
    rule = ("Return on assets = net income ÷ total assets (averaged over the year). An ROA far below the ROE "
            "(the book's case: 25% against 5%) means the ROE is being made with debt.")
    if not _ok(roa):
        profitability.append(_check("Return on assets", "not reported", NA, rule))
    elif is_fin:
        profitability.append(_check("Return on assets", f"{roa * 100:.2f}% ({fin_why})", NA, rule))
    elif roa < 0:
        profitability.append(_check("Return on assets", f"{roa * 100:.1f}%", BAD, rule))
    elif neg_equity:
        profitability.append(_check("Return on assets", f"{roa * 100:.1f}% ({neg_why})", WATCH, rule))
    else:
        lev = _div(roe, roa)
        lean = _ok(lev) and lev >= ROE_TO_ROA_LEVERAGE
        profitability.append(_check(
            "Return on assets",
            f"{roa * 100:.1f}% (ROE is {lev:.1f}× ROA{': leans on debt' if lean else ''})",
            WATCH if lean else GOOD, rule))
    rule = "Net profit as % of sales (common-size): is it higher than last year?"
    if len(margin) < 2:
        profitability.append(_check("Net margin trend", "fewer than two years", NA, rule))
    else:
        m0, m1 = margin.iloc[-2], margin.iloc[-1]
        flat = abs(m1 - m0) < MARGIN_FLAT_PP
        profitability.append(_check(
            "Net margin trend",
            f"{m0 * 100:.1f}% → {m1 * 100:.1f}%" + (" (unchanged)" if flat else ""),
            BAD if m1 < 0 else (GOOD if (m1 >= m0 or flat) else WATCH), rule))

    solvency, liquidity = [], []
    rule = ("Quick ratio = (current assets − inventory) ÷ current liabilities: can "
            "it pay its bills without selling stock? At least 1 is adequate.")
    quick = _div(cur_assets.iloc[-1] - (inventory.iloc[-1] if len(inventory) else 0.0),
                 cur_liab.iloc[-1]) if len(cur_assets) and len(cur_liab) else float("nan")
    if is_fin:
        solvency.append(_check("Quick ratio", fin_why, NA, rule))
    elif not _ok(quick):
        solvency.append(_check("Quick ratio", "not reported", NA, rule))
    else:
        solvency.append(_check("Quick ratio", f"{quick:.2f}",
                               GOOD if quick >= QUICK_RATIO_FLOOR else WATCH, rule))
    solvency.append(dict(hallmarks[2], label="Debt to net equity",
                         rule="Total liabilities ÷ net equity; above 1 isn't good."))

    rule = ("Current ratio = current assets ÷ current liabilities: 2 or more is "
            "desirable, under 1 is a red flag.")
    cr = _div(cur_assets.iloc[-1], cur_liab.iloc[-1]) if len(cur_assets) and len(cur_liab) else float("nan")
    if is_fin:
        liquidity.append(_check("Current ratio", fin_why, NA, rule))
    elif not _ok(cr):
        liquidity.append(_check("Current ratio", "not reported", NA, rule))
    else:
        liquidity.append(_check("Current ratio", f"{cr:.2f}",
                                GOOD if cr >= CURRENT_RATIO_GOOD else
                                (WATCH if cr >= CURRENT_RATIO_FLOOR else BAD), rule))

    operating = []
    rule = ("Sales ÷ receivables: if receivables grow faster than sales, customers "
            "are slower to pay. Flagged here at a 20% fall in a year (the book "
            "gives an example, not a cut-off).")
    sr = _ratio_series(revenue, receivables)
    if is_fin:
        operating.append(_check("Sales to receivables", fin_why, NA, rule))
    elif len(sr) < 2:
        operating.append(_check("Sales to receivables", "fewer than two years", NA, rule))
    else:
        fall = 1.0 - sr.iloc[-1] / sr.iloc[-2]
        # Thomsett's average collection period is the same ratio in days.
        days = f" (collection period {365 / sr.iloc[-2]:.0f} → {365 / sr.iloc[-1]:.0f} days)"
        operating.append(_check("Sales to receivables",
                                f"{sr.iloc[-2]:.1f} → {sr.iloc[-1]:.1f}{days}",
                                WATCH if fall > SR_FALL_FLAG else GOOD, rule))

    valuation = []
    rule = ("Price ÷ sales: 2 or less is very undervalued, under 3-4 is good "
            "enough, above 5 be very hesitant.")
    ps = _finite(info.get("priceToSalesTrailing12Months"))
    # Yahoo divides a rupee market value by dollar sales for a USD filer
    # (Infosys reads 228), so compute it whenever the currencies differ.
    if statement_fx(info) != 1.0:
        ps = float("nan")
    if not _ok(ps) and len(revenue):
        ps = _div(info.get("marketCap"), revenue.iloc[-1] * statement_fx(info))
    if not _ok(ps):
        valuation.append(_check("Price to sales", "not available", NA, rule))
    else:
        valuation.append(_check("Price to sales", f"{ps:.2f}",
                                GOOD if ps <= PS_FINE else (WATCH if ps <= PS_HESITANT else BAD),
                                rule))
    rule = ("Price ÷ book value: at or below 1 suits a value investor, but many "
            "excellent companies trade at 5 or more, so it confirms rather than decides.")
    if neg_equity or (_ok(pb) and pb <= 0):
        valuation.append(_check("Price to book", "negative book value", BAD, rule))
    elif not _ok(pb):
        valuation.append(_check("Price to book", "not available", NA, rule))
    else:
        valuation.append(_check("Price to book", f"{pb:.2f}",
                                GOOD if pb <= 1.0 else INFO, rule))

    trends = _thomsett_trends(income, balance, info, is_fin, fin_why, equity, revenue,
                              neg_equity, neg_why)

    # ---- Ch. 9: payout ratio, on totals so a bonus issue cannot distort it --
    income_checks = []
    rule = ("Payout ratio = dividends ÷ earnings (Ch. 9): 60% or less is very safe, "
            "50-70% a good range, 80% the maximum acceptable.")
    paid = -_row(inputs.get("cashflow"), "Cash Dividends Paid", "Common Stock Dividend Paid")
    payout = _ratio_series(paid, net)
    if not len(paid) or paid.iloc[-1] <= 0:
        income_checks.append(_check("Payout ratio", "pays no dividend", NA, rule))
    elif len(net) and net.reindex(paid.index).iloc[-1] <= 0:
        income_checks.append(_check("Payout ratio", "dividend paid out of a loss", BAD, rule))
    elif not len(payout):
        income_checks.append(_check("Payout ratio", "not reported", NA, rule))
    else:
        v = payout.iloc[-1]
        prev = f" (a year earlier {payout.iloc[-2] * 100:.0f}%)" if len(payout) >= 2 else ""
        income_checks.append(_check(
            "Payout ratio", f"{v * 100:.1f}% of FY{payout.index[-1].year} profit{prev}",
            GOOD if v <= PAYOUT_GOOD else (WATCH if v <= PAYOUT_MAX else BAD), rule))

    # Thomsett, Ch. 6: as earnings grow the payout share "ideally should remain
    # the same"; slipping over several years is a negative sign, unless buybacks
    # are taking the place of dividends. Erratic year to year, so it takes two
    # falls in a row from a company that stayed profitable.
    rule = ("Payout trend (Thomsett Ch. 6): the share of profit paid out should hold "
            "steady as earnings grow; slipping over several years is a negative sign, "
            "though buybacks can take the place of dividends.")
    if len(payout) < 3 or not len(paid) or paid.iloc[-1] <= 0:
        income_checks.append(_check("Payout trend", "fewer than three years of dividends", NA, rule))
    else:
        last3 = payout.iloc[-3:]
        profitable = bool((net.reindex(last3.index) > 0).all())
        slipping = profitable and bool((last3.diff().dropna() < 0).all())
        path = " → ".join(f"{x * 100:.0f}%" for x in last3)
        income_checks.append(_check("Payout trend", path + (" (slipping)" if slipping else ""),
                                    WATCH if slipping else GOOD, rule))

    # ---- Ch. 1 and 14: size, and the small-cap rules -----------------------
    size = _size(inputs.get("symbol"), inputs.get("cap_lists"), info, margin, net,
                 inputs.get("years_listed"))

    measured = [h for h in hallmarks if h["verdict"] != NA]
    met = sum(1 for h in hallmarks if h["verdict"] == GOOD)

    def tally(checks):
        scored = [c for c in checks if c["verdict"] != NA]
        return sum(1 for c in scored if c["verdict"] == GOOD), len(scored)

    minimum = {"profitability": tally(profitability), "solvency": tally(solvency)}
    fy = None
    for s in (net, revenue, equity):
        if len(s):
            fy = s.index[-1]
            break
    summary = (f"{met} of {len(measured)} measurable hallmarks met; the other four of "
               "the book's ten are judgement calls. Mladjenovic: a stock with half of "
               "the ten is a super-solid choice.")
    return {
        "hallmarks": hallmarks,
        "judgement": list(JUDGEMENT_HALLMARKS),
        "ratios": [("Profitability", profitability), ("Solvency", solvency),
                   ("Liquidity", liquidity), ("Operating", operating),
                   ("Valuation", valuation), ("Income (Ch. 9)", income_checks),
                   ("Trends (Thomsett)", trends)],
        "size": size,
        "met": met, "measured": len(measured), "minimum": minimum,
        "fiscal_year_end": str(fy.date()) if fy is not None else None,
        "sector": sector, "industry": industry, "is_financial": is_fin,
        "currency": currency, "summary": summary,
    }


def _average_balance(series):
    """Average of each year's opening and closing balance (Thomsett Ch. 2)."""
    if len(series) < 2:
        return series
    avg = ((series + series.shift(1)) / 2.0).dropna()
    return avg if len(avg) else series


def _thomsett_trends(income, balance, info, is_fin, fin_why, equity, revenue,
                     neg_equity=False, neg_why=""):
    """
    Thomsett, *Stock Market Math*, Ch. 6-7: balance-sheet and operating tests
    read as trends. Inventory turnover, the debt capitalization ratio, the
    operating margin, and tangible book value.
    """
    out = []
    # Inventory turnover = cost of goods sold / average inventory.
    rule = ("Inventory turnover = cost of goods sold ÷ average inventory (Thomsett "
            "Ch. 6): a decline means money tied up in stock. Flagged here at a fall "
            "of a tenth in a year (this project's cut-off).")
    cogs = _row(income, "Cost Of Revenue")
    inv = _row(balance, "Inventory")
    assets = _row(balance, "Total Assets")
    avg_inv = ((inv + inv.shift(1)) / 2.0).dropna() if len(inv) else inv
    turn = _ratio_series(cogs, avg_inv) if len(avg_inv) else pd.Series(dtype=float)
    material = bool(len(inv) and len(assets)
                    and _div(inv.iloc[-1], assets.reindex(inv.index).iloc[-1]) >= INVENTORY_MATERIAL)
    if is_fin or not len(cogs):
        out.append(_check("Inventory turnover", fin_why if is_fin else "not reported", NA, rule))
    elif not material:
        out.append(_check("Inventory turnover", "inventory is under 2% of assets: not material",
                          NA, rule))
    elif len(turn) < 2:
        out.append(_check("Inventory turnover", "fewer than two years", NA, rule))
    else:
        fell = 1.0 - turn.iloc[-1] / turn.iloc[-2]
        out.append(_check("Inventory turnover", f"{turn.iloc[-2]:.1f} → {turn.iloc[-1]:.1f} turns",
                          WATCH if fell > TURNOVER_FALL_FLAG else GOOD, rule))

    # Debt capitalization ratio = long-term debt / (long-term debt + equity).
    rule = ("Debt capitalization = long-term debt ÷ total capital (Thomsett Ch. 6): "
            "rising over a period of years is a serious warning. Flagged here when it "
            "rose every year and by 2+ points (this project's cut-off).")
    ltd = _row(balance, "Long Term Debt And Capital Lease Obligation", "Long Term Debt")
    common = ltd.index.intersection(equity.index)
    dcr = pd.Series({q: _div(ltd[q], ltd[q] + equity[q]) for q in common}, dtype=float).sort_index()
    dcr = dcr[dcr.apply(_ok)] if len(dcr) else dcr
    if is_fin:
        out.append(_check("Debt capitalization", fin_why, NA, rule))
    elif neg_equity:
        out.append(_check("Debt capitalization", neg_why, BAD, rule))
    elif len(dcr) < 2:
        out.append(_check("Debt capitalization", "fewer than two years", NA, rule))
    else:
        path = " → ".join(f"{v * 100:.0f}%" for v in dcr.iloc[-3:])
        span = dcr.iloc[-3:]
        rising = (bool((span.diff().dropna() > 0).all())
                  and span.iloc[-1] - span.iloc[0] >= DCR_RISE_PP)
        out.append(_check("Debt capitalization", path + (" (rising every year)" if rising else ""),
                          WATCH if rising else GOOD, rule))

    # Operating margin: revenue against direct costs and expenses (Ch. 7).
    rule = ("Operating margin = operating income ÷ revenue (Thomsett Ch. 7): costs "
            "and expenses should not grow faster than revenue.")
    om = _ratio_series(_row(income, "Operating Income"), revenue)
    if len(om) < 2:
        out.append(_check("Operating margin trend", fin_why if is_fin else "fewer than two years",
                          NA, rule))
    else:
        o0, o1 = om.iloc[-2], om.iloc[-1]
        flat = abs(o1 - o0) < MARGIN_FLAT_PP
        out.append(_check("Operating margin trend",
                          f"{o0 * 100:.1f}% → {o1 * 100:.1f}%" + (" (unchanged)" if flat else ""),
                          BAD if o1 < 0 else (GOOD if (o1 >= o0 or flat) else WATCH), rule))

    # Tangible book value: net worth without goodwill and intangibles.
    rule = ("Tangible book value = net worth − intangible assets (Thomsett Ch. 6): "
            "the part of book value a buyer could sell. Context, not a pass mark.")
    tbv = _row(balance, "Tangible Book Value")
    if not len(tbv) and len(equity):
        intang = _row(balance, "Goodwill And Other Intangible Assets")
        tbv = (equity - intang.reindex(equity.index).fillna(0.0)).dropna()
    mcap = _finite(info.get("marketCap"))
    if not len(tbv) or not len(equity):
        out.append(_check("Tangible book value", "not reported", NA, rule))
    elif tbv.iloc[-1] <= 0:
        out.append(_check("Tangible book value", "negative: intangibles exceed net worth",
                          WATCH, rule))
    else:
        share = 1.0 - tbv.iloc[-1] / equity.reindex(tbv.index).iloc[-1]
        # Market value is in rupees; the statements may not be (Infosys files in USD).
        ptbv = _div(mcap, tbv.iloc[-1] * statement_fx(info))
        out.append(_check("Tangible book value",
                          (f"price {ptbv:.2f}× tangible book; " if _ok(ptbv) else "")
                          + f"intangibles {share * 100:.0f}% of net worth", INFO, rule))
    return out


def _size(symbol, cap_lists, info, margin, net, years_listed):
    """Large / mid / small cap from NSE's index lists, plus Ch. 14's small-cap rules."""
    mcap = _finite(info.get("marketCap"))
    out = {"band": None, "basis": None, "market_cap": mcap, "checks": []}
    if cap_lists is None or not symbol:
        return out
    for band, indices, basis in CAP_BANDS:
        hit = [i for i in indices if symbol in cap_lists.get(i, set())]
        if hit:
            out["band"], out["basis"] = band, f"in the {hit[0].title()}: {basis}"
            break
    else:
        out["band"], out["basis"] = "Micro cap", "outside NSE's top 500 indices"
    if out["band"] in ("Small cap", "Micro cap"):
        rule = "Ch. 14: in business for at least three years is a good minimum."
        if _ok(_finite(years_listed)):
            out["checks"].append(_check(
                "Established", f"{years_listed:.0f} years of trading history",
                GOOD if years_listed >= SMALL_CAP_YEARS else WATCH, rule))
        else:
            out["checks"].append(_check("Established", "listing date unknown", NA, rule))
        rule = ("Ch. 14: net profits of 10% or more over two years or longer "
                "(read here as net margin, both of the last two years).")
        if len(margin) >= 2:
            last2 = margin.iloc[-2:]
            out["checks"].append(_check(
                "Profitable", " and ".join(f"{m * 100:.1f}%" for m in last2) + " net margin",
                GOOD if (last2 >= SMALL_CAP_MARGIN).all() else
                (BAD if (net.iloc[-2:] <= 0).any() else WATCH), rule))
        else:
            out["checks"].append(_check("Profitable", "fewer than two years", NA, rule))
    return out


def _cap_lists():
    try:
        from nselib import capital_market as cm
        fns = {"NIFTY 50": cm.nifty50_equity_list, "NIFTY NEXT 50": cm.niftynext50_equity_list,
               "NIFTY MIDCAP 150": cm.niftymidcap150_equity_list,
               "NIFTY SMALLCAP 250": cm.niftysmallcap250_equity_list}
        return {k: set(f()["Symbol"].astype(str).str.upper()) for k, f in fns.items()}
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Live inputs (network; every failure degrades to a missing piece)
# ---------------------------------------------------------------------------

def _fno_symbols():
    try:
        from nselib import capital_market
        df = capital_market.fno_equity_list()
        return set(df["symbol"].astype(str).str.upper())
    except Exception:
        return None


def fetch_inputs(ticker, fno_fn=_fno_symbols, cap_fn=_cap_lists):
    """Annual statements, info and dividends from yfinance; F&O and index lists from NSE."""
    import yfinance as yf
    from corporate_events import nse_symbol
    t = yf.Ticker(ticker)

    def grab(attr, default):
        try:
            v = getattr(t, attr)
            return v if v is not None else default
        except Exception:
            return default

    symbol = nse_symbol(ticker)
    info = grab("info", {})
    first = _finite(info.get("firstTradeDateMilliseconds"))
    years = ((pd.Timestamp.now() - pd.Timestamp(first, unit="ms")).days / 365.25
             if _ok(first) else float("nan"))
    return {
        "income": grab("income_stmt", pd.DataFrame()),
        "balance": grab("balance_sheet", pd.DataFrame()),
        "cashflow": grab("cashflow", pd.DataFrame()),
        "info": info,
        "dividends": grab("dividends", pd.Series(dtype=float)),
        "symbol": symbol,
        "fno_symbols": fno_fn() if symbol else None,
        "cap_lists": cap_fn() if symbol else None,
        "years_listed": years,
    }


def company_checklist(ticker, last_price=None, fetch_fn=fetch_inputs):
    """The live checklist for one ticker, or None on any failure (advisory)."""
    try:
        return build_checklist(fetch_fn(ticker), last_price=last_price)
    except Exception:
        return None
