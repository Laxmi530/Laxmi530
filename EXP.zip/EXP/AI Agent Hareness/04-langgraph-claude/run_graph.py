"""Command-line entry point for the LangGraph + Claude Agent SDK workflow. For the UI, see app.py.

Examples:
    python run_graph.py --reset
    python run_graph.py --example calculator --reset --effort-coder medium
    python run_graph.py --draw          # print the graph as Mermaid and exit
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

from harness.agents import DEFAULT_MODEL, AgentSettings, ClaudeAgentRunner
from harness.display import describe_event
from harness.graph import build_graph, run_graph
from harness.prompts import format_plan
from harness.sandbox import SandboxError
from harness.workspace_setup import (
    DEFAULT_EXAMPLE, EXAMPLES, default_workspace, load_env, prepare_workspace,
)

EFFORTS = ["low", "medium", "high", "xhigh", "max"]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run the LangGraph + Claude Agent SDK coding workflow.")
    p.add_argument("task", nargs="?", default=None,
                   help="What to do (default: the example's standard task).")
    p.add_argument("--example", choices=list(EXAMPLES), default=DEFAULT_EXAMPLE)
    p.add_argument("--workspace", default=None, help="Default: ./workspace/<example>.")
    p.add_argument("--reset", action="store_true", help="Copy the broken example in first.")
    p.add_argument("--model", default=None, help=f"Default: $CLAUDE_MODEL or {DEFAULT_MODEL}.")
    p.add_argument("--effort-planner", choices=EFFORTS, default="high")
    p.add_argument("--effort-coder", choices=EFFORTS, default="high")
    p.add_argument("--effort-reviewer", choices=EFFORTS, default="medium")
    p.add_argument("--max-rounds", type=int, default=2, help="Review rounds (default 2).")
    p.add_argument("--max-attempts", type=int, default=3,
                   help="Coder attempts per round inside the subgraph (default 3).")
    p.add_argument("--max-agent-turns", type=int, default=25, help="Claude Code turns per agent call.")
    p.add_argument("--budget", type=float, default=2.0, help="Max USD per agent call (default 2.0).")
    p.add_argument("--draw", action="store_true", help="Print the graph as Mermaid and exit.")
    return p.parse_args()


def print_event(event: dict) -> None:
    line = describe_event(event)
    if line:
        print(line)


def print_report(state: dict) -> None:
    print("\n" + "=" * 60)
    print(f"Stop reason: {state.get('stop_reason')}")
    print(f"Tests:       {state.get('test_summary')}")
    print(f"Rounds:      {state.get('round')}  |  Cost: ${state.get('cost_usd', 0):.4f}")
    for run in state.get("agent_runs", []):
        print(f"  {run}")
    if state.get("plan"):
        print(f"\nPlan:\n{format_plan(state['plan'])}")
    for i, review in enumerate(state.get("reviews", []), start=1):
        print(f"\nReview {i}: {'APPROVED' if review['approved'] else 'CHANGES REQUESTED'}: "
              f"{review['summary']}")
        for issue in review["issues"]:
            print(f"  - {issue}")


def main() -> int:
    load_env()
    args = parse_args()
    if args.draw:
        print(build_graph(runner=None).get_graph(xray=True).draw_mermaid())
        return 0
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key.")
        return 2

    settings = AgentSettings(
        model=args.model or os.getenv("CLAUDE_MODEL", DEFAULT_MODEL),
        effort={"Planner": args.effort_planner, "Coder": args.effort_coder,
                "Reviewer": args.effort_reviewer},
        max_turns=args.max_agent_turns, max_budget_usd=args.budget,
    )
    task = args.task or EXAMPLES[args.example]
    try:
        workspace = prepare_workspace(args.workspace or default_workspace(args.example),
                                      example=args.example, reset=args.reset)
    except SandboxError as exc:
        print(exc)
        return 2
    print(f"Workspace: {workspace.root}\nModel: {settings.model}\nTask: {task}\n")

    state, _ = asyncio.run(run_graph(task, workspace, ClaudeAgentRunner(settings),
                                     max_rounds=args.max_rounds, max_attempts=args.max_attempts,
                                     on_event=print_event))
    print_report(state)
    return 0 if state.get("stop_reason") == "approved" else 1


if __name__ == "__main__":
    sys.exit(main())
