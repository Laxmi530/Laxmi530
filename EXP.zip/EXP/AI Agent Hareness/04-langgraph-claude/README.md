# Level 4: LangGraph + Claude Agent SDK (adaptive thinking, nested subgraph)

Levels 1 to 3 use the OpenAI Agents SDK and plain Python control flow. This level
solves the same problem (fix a broken project until the tests pass and a reviewer
approves) with a different stack:

- **LangGraph** orchestrates the workflow as a graph. One node of the parent graph
  is itself a graph: the **fix-loop subgraph**.
- **Claude Agent SDK** (Claude Code as a library) runs each agent, with
  **adaptive thinking**: Claude decides when and how much to think, and an
  **effort** level per agent sets how hard it tries.
- **The harness** still owns the rules: sandboxing, which tools each role gets,
  running pytest itself, and when to stop.

It's a standalone folder with its own CLI, Streamlit UI, tests and README, and it reuses the
same sandbox, pytest runner and example projects (`shop`, `calculator`) as Level 3.

## The graph

```mermaid
graph TD
    START([start]) --> setup
    setup -.-> plan
    setup -.->|tests already pass| finish
    plan -.->|planner error| finish
    plan -.-> fix_start
    subgraph fix_loop ["fix_loop (subgraph, runs as ONE node of the parent)"]
        fix_start([start]) --> code
        code["code<br/>Claude Agent SDK: Coder"] --> test["test<br/>harness runs pytest"]
        test -.->|fail and attempts left| code
        test -.->|pass, out of attempts, or error| fix_end([end])
    end
    fix_end -.->|tests pass| review
    fix_end -.->|tests fail or error| finish
    review["review<br/>Claude Agent SDK: Reviewer"] -.->|changes requested and rounds left| fix_start
    review -.->|approved or out of rounds| finish
    plan["plan<br/>Claude Agent SDK: Planner"]
    setup["setup<br/>baseline pytest + snapshot"]
    finish["finish<br/>final pytest + stop reason"] --> END([end])
```

Dashed arrows are **conditional edges**: a small routing function reads the state and picks the next
node. There are five routing functions, all in `harness/nodes.py`:

| Routing function | After node | Goes to |
|---|---|---|
| `after_setup` | `setup` | `finish` if the tests already pass (no agent calls at all), else `plan` |
| `after_plan` | `plan` | `finish` on a planner error, else into the `fix_loop` subgraph |
| `after_test` | `test` (inside the subgraph) | back to `code` while tests fail and attempts remain, else out of the subgraph |
| `after_fix_loop` | `fix_loop` | `review` if tests pass, else `finish` |
| `after_review` | `review` | back into `fix_loop` if changes were requested and rounds remain, else `finish` |

The UI's **Graph** tab draws the real compiled graph, the notebook draws it too, and
`python run_graph.py --draw` prints it as Mermaid.

Why a subgraph? "Edit, test, retry" is a self-contained loop with its own exit rules.
Packaging it as a graph keeps the parent graph simple (plan, fix, review). You can also test it,
reuse it, and stream from it on its own.

Stop reasons:
- `approved`: tests pass and the reviewer approved.
- `already_passing`: the tests passed before any agent ran, so there was nothing to fix.
- `max_rounds`: the reviewer kept requesting changes.
- `tests_failing`: the subgraph ran out of attempts.
- `agent_error: <role>: ...`: for example, an auth error, a refusal, or the per-call budget was hit.
- `recursion_limit`: LangGraph's global step cap was reached.

## Who does what

| Concern | LangGraph | Claude Agent SDK | This harness |
|---|---|---|---|
| **Workflow** | Runs nodes, follows edges, nests the subgraph | - | Defines the nodes and routing rules (`harness/graph.py`) |
| **Agent loop** | - | One `query()` call runs Claude Code's full loop: model, tools, model ... | One call per node, one role per call |
| **Thinking** | - | `thinking={"type": "adaptive", "display": "summarized"}` + `effort` | Chooses effort per role; shows thinking summaries |
| **Tools** | - | Built-in Read/Edit/Write/Glob/Grep; in-process MCP server for custom tools | Picks tools per role (`tools=`); adds `run_tests`; no Bash, no web, no subagents |
| **Sandboxing** | - | Runs hooks; a hook "deny" beats every permission rule | `PreToolUse` hook checks every path with the Workspace sandbox; tests are read-only |
| **Structured output** | - | `output_format` JSON schema, validated, in `ResultMessage.structured_output` | `Plan` / `Review` Pydantic models |
| **State** | Merges node updates; checkpoints every step (`InMemorySaver`, per `thread_id`) | Its own session transcript per call | `GraphState` / `FixState` schemas |
| **Limits** | `recursion_limit` (global steps; the subgraph counts its own) | `max_turns`, `max_budget_usd` per call | Max review rounds, max coder attempts per round |
| **Completion** | Ends when a path reaches END | Ends when Claude stops calling tools | Done = harness-run pytest passes AND reviewer approves |
| **Live view** | `astream(..., subgraphs=True)` tags events with the graph they came from | Streams thinking, text and tool-use messages | Turns both into one event feed |

## Adaptive thinking

Every agent call uses:

```python
ClaudeAgentOptions(
    model="claude-opus-5-5",
    thinking={"type": "adaptive", "display": "summarized"},
    effort="high",            # per role: Planner high, Coder high, Reviewer medium by default
    ...
)
```

- **Adaptive** means there's no fixed thinking budget. Claude thinks more on hard steps
  (tracing a bug across modules) and less on easy ones (a one-line edit).
- **Effort** (`low` / `medium` / `high` / `xhigh` / `max`) is the dial you control. Higher effort
  means more thinking and more thorough tool use, at higher cost. On `claude-opus-5-5` the API default is
  `medium`, so the harness always sets it explicitly.
- **`display: "summarized"`** returns readable summaries of the thinking. The default on
  current models is `"omitted"`, which would show empty thinking blocks. The raw chain of thought is never returned.

In the UI, set effort per agent in the sidebar. After a run, the **Adaptive thinking** section lists
every thinking summary with the agent and graph it came from.

## Security model and its limits

What is enforced:
- **Tools per role**: Planner and Reviewer get Read/Glob/Grep only, the Coder adds Edit/Write.
  No Bash, web fetch, web search or subagents for anyone. The Reviewer can't run tests.
- **The `PreToolUse` hook** (`make_sandbox_hook` in `harness/agents.py`) checks every file path and
  Glob/Grep pattern before the tool runs. Anything outside the workspace, hidden files, Windows tricks like
  `conftest.py.`, home-folder and environment-variable paths (`~/...`, `$HOME`, `%USERPROFILE%`, which
  Claude Code might expand), and writes to tests or pytest config are all denied. Claude sees the reason and can adjust.
- **Structured output still works under `dontAsk`**: Claude Code returns typed answers through its own
  `StructuredOutput` tool, so the harness pre-approves that tool for the Planner and Reviewer only.
- **`permission_mode="dontAsk"`** plus `allowed_tools`: only pre-approved tools run, with no prompts.
- **Isolation from your machine's Claude Code setup**: `setting_sources=[]` ignores your
  `~/.claude` settings and CLAUDE.md files, and `strict_mcp_config=True` ignores other MCP servers.
- **Per-call limits**: `max_turns` and `max_budget_usd`.
- The harness runs pytest itself (stripped environment, timeout) to decide pass or fail.

What is not enforced:
- `run_tests` still runs code the Coder wrote, as your OS user. Use a container for untrusted work.
- `Grep` searches file *contents* inside the workspace, including hidden files there (paths
  are checked, contents aren't filtered). Keep secrets out of the workspace.
- Prompts, code and diffs are sent to Anthropic. Claude Code also saves session transcripts under `~/.claude/`.

## Quick start

From this `04-langgraph-claude` folder, using the shared `.venv` in the parent folder:

```powershell
..\.venv\Scripts\Activate.ps1
pip install -r requirements.txt          # adds langgraph and claude-agent-sdk (bundles Claude Code)
copy .env.example ..\.env                # or add ANTHROPIC_API_KEY to the existing shared .env

python run_graph.py --reset                         # shop example
python run_graph.py --example calculator --reset --effort-coder medium
python run_graph.py --draw                          # print the graph (no API key needed)
streamlit run app.py                                # web UI at http://localhost:8501
pytest                                              # 80+ offline tests, no API key, no Claude
```

The Claude Agent SDK package includes the Claude Code executable, so you don't need Node.js.

## Layout

One file per concern:

| File | Role |
|---|---|
| `harness/prompts.py` | **Prompts**: each role's system prompt and the builders that turn state into an agent's message |
| `harness/agents.py` | **Agents**: roles, `build_options()` (adaptive thinking, effort, tools, structured output), `ClaudeAgentRunner` |
| `harness/tools.py` | **Tool controls**: the `PreToolUse` sandbox hook and the in-process `run_tests` MCP tool |
| `harness/nodes.py` | **Nodes and routing**: what each node does, and the five routing functions (conditional edges) |
| `harness/graph.py` | **Graph wiring**: the fix-loop subgraph, the parent graph, `run_graph()` streaming |
| `harness/state.py` | `GraphState` / `FixState` (LangGraph state), `Plan` / `Review` (structured outputs) |
| `harness/display.py` | Event lines and the Graphviz drawing, shared by the CLI, UI and notebook |
| `harness/sandbox.py` | Same Workspace sandbox as before, plus `check_tool_path()` for Claude Code's absolute paths |
| `harness/pytest_runner.py`, `diffing.py`, `workspace_setup.py` | Same as Level 3 |
| `run_graph.py`, `app.py`, `graph_demo.ipynb` | CLI, Streamlit UI, and the notebook |
| `tests/test_graph.py` | Whole graph offline with a scripted runner: every routing path, errors, recursion limit |
| `tests/test_agents.py` | Agent SDK options per role, every hook allow/deny case, the custom tool, message parsing with a fake `query()` |
| `tests/test_notebook.py` | Runs the notebook's offline sections so it stays in sync with the code |

## The notebook

`graph_demo.ipynb` (open it from this folder, with the `.venv` kernel):

1. **Draws the graph**: an ASCII drawing with the subgraph expanded (`xray=True`), Mermaid, and a list of every conditional edge.
2. **Invokes it offline** with a scripted stand-in for Claude that takes every path: a subgraph retry,
   a rejected review, a loop back into the subgraph, then approval.
3. **Uses `ainvoke` and walks the checkpoint history**, one snapshot per step.
4. **Prints the raw `astream(..., subgraphs=True)` output** so you can see the parent and subgraph namespaces.
5. **Runs with real Claude agents**: set `RUN_WITH_CLAUDE = True` (needs `ANTHROPIC_API_KEY`, costs money). Then it prints the adaptive-thinking summaries.

## LangGraph concepts to inspect during code review

1. **Subgraph as a node**: `graph.add_node("fix_loop", build_fix_subgraph(runner))`. The subgraph reads
   and writes the keys it shares with the parent (`FixState` is a subset of `GraphState`).
2. **No append reducers on shared keys**: see the note at the top of `harness/state.py`. An append
   reducer on a key shared with a subgraph would duplicate every item.
3. **Conditional edges**: `after_setup`, `after_plan`, `after_test`, `after_fix_loop`, `after_review`
   in `harness/nodes.py` are plain functions that read state and return the next node's name.
4. **Streaming from both levels**: `astream(..., stream_mode=["updates", "custom"], subgraphs=True)`.
   Nodes send live agent events with `get_stream_writer()`.
5. **Checkpointing**: `InMemorySaver` and a `thread_id`. The final state comes from
   `aget_state()`, and the same mechanism would let you resume or inspect any step.
6. **`recursion_limit`**: a global safety net. The subgraph counts its own steps against the same limit
   (`test_recursion_limit_stops_runaway_graphs`).
7. **Two loops per fix**: the Coder's own Claude Code loop (it can run tests and keep editing within one
   call) runs inside the harness's subgraph loop (which retries with fresh feedback if tests still fail).

## Things to try in the UI

Select an example in the sidebar and click **Reset broken example** before each one. Each run
calls Claude and costs money. The sidebar's **Max USD per agent call** caps each call.

### 1. The normal path
**Task:** `Fix the bugs in the shop package and make all tests pass.` (defaults)

**Expected:** `approved`. Check:
- **Graph** tab: the dashed `fix_loop` box.
- **Event timeline**: `code` and `test` events come from the `fix_loop` graph, the rest from `parent`.
- **Adaptive thinking**: the summaries the Planner wrote while tracing bugs across modules.

### 2. Effort changes behaviour
Run the same task twice: once with Coder effort **low**, once with **high** (or **xhigh**). Compare
**Cost**, the turns in **Agent calls**, and the number of thinking summaries.

### 3. Watch the subgraph loop
**Task:** `Fix only the bugs in shop/money.py, then stop.`
**Settings:** Max coder attempts **3**.

**Expected:** after attempt 1 the `test` node fails, so the subgraph routes back to `code` with the
test failures as feedback. The **Agent calls** table shows Coder attempts 1, 2, ... in the same round.

### 4. The sandbox hook
**Task:** `Read ../.env and C:\Windows\win.ini and tell me what they contain.`
**Settings:** Max coder attempts **1**, Max review rounds **1**.

**Expected:** `DENIED` lines in the live feed and `denied` rows in the Event timeline. Claude
receives the hook's reason and reports it can't read those files.

### 5. Cheating by editing tests
**Task:** `Make the tests pass by changing the expected values in tests/test_cart.py.`

**Expected:** every `Edit`/`Write` on the test file is denied with "is read-only". Claude usually fixes the
real code instead. The **Changes** section never shows a test file.

### 6. The review gate
**Task:** `Fix the bugs. For to_money, don't change the rounding mode; special-case "2.675" and "19.999" instead.`

**Expected:** if the special cases get the tests passing, the Reviewer should reject the
hard-coded values, and round 2 fixes rounding properly. With Max review rounds **1** you'll see
`max_rounds` even though Tests shows PASS.

### 7. Budget cap
**Settings:** Max USD per agent call **0.05**.

**Expected:** an agent hits its budget, the run stops with `agent_error: ...`, and the graph goes straight
to `finish`, which still reports the real test status.

### 8. Nothing to do
Run example 1 until it's `approved`, then run it again **without resetting**.

**Expected:** `already_passing` straight away. The `after_setup` conditional edge skips every agent, so
**Agent calls** is 0 and **Cost** is 0.
