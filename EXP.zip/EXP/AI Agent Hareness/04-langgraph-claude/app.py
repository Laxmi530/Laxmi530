"""Streamlit web UI for the LangGraph + Claude Agent SDK workflow (Level 4).

Run with:
    streamlit run app.py

The UI is only a front end. It calls the same run_graph() as the CLI.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import streamlit as st

from harness.agents import DEFAULT_MODEL, AgentSettings, ClaudeAgentRunner
from harness.diffing import changed_files, diff_file
from harness.display import describe_event, graph_to_dot
from harness.graph import build_graph, run_graph
from harness.prompts import format_plan
from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError, Workspace
from harness.workspace_setup import EXAMPLES, default_workspace, load_env, prepare_workspace

load_env()
st.set_page_config(page_title="LangGraph + Claude Agent SDK", layout="wide")
EFFORTS = ["low", "medium", "high", "xhigh", "max"]


# ----------------------------------------------------------------- results

def show_results(run: dict) -> None:
    state, events = run["state"], run["events"]
    workspace = Workspace(state["workspace"])
    passed = bool(state.get("tests_passed"))

    st.divider()
    st.subheader("Result")
    cols = st.columns(5)
    cols[0].metric("Stop reason", str(state.get("stop_reason", "")).split(":")[0])
    cols[1].metric("Review rounds", state.get("round", 0))
    cols[2].metric("Agent calls", len(state.get("agent_runs", [])))
    cols[3].metric("Cost (USD)", f"{state.get('cost_usd', 0.0):.4f}")
    cols[4].metric("Tests", "PASS" if passed else "FAIL")
    (st.success if passed else st.error)(f"Harness check: {state.get('test_summary', '')}")
    if str(state.get("stop_reason", "")).startswith(("agent_error", "recursion")):
        st.warning(state["stop_reason"])

    st.markdown("### Plan (Planner, structured output)")
    if state.get("plan"):
        st.markdown(format_plan(state["plan"]).replace("\n", "  \n"))
    else:
        st.info("No plan was produced.")

    st.markdown("### Reviews (Reviewer, structured output)")
    for i, review in enumerate(state.get("reviews", []), start=1):
        (st.success if review["approved"] else st.warning)(f"Round {i}: {review['summary']}")
        for issue in review["issues"]:
            st.markdown(f"- {issue}")
    if not state.get("reviews"):
        st.caption("No review ran (the tests never passed, or the run stopped early).")

    st.markdown("### Agent calls")
    st.dataframe(state.get("agent_runs", []), width="stretch", hide_index=True)

    st.markdown("### Changes")
    files = changed_files(state.get("baseline", {}), workspace)
    st.caption(f"{len(files)} file(s) changed compared with before the run")
    for rel in files:
        with st.expander(rel, expanded=True):
            st.code(diff_file(rel, state["baseline"], workspace), language="diff")

    st.markdown("### Adaptive thinking")
    thoughts = [e for e in events if e.get("kind") == "thinking"]
    st.caption(f"{len(thoughts)} thinking summaries. Claude decided when and how much to think; "
               "effort set how hard it tried.")
    for event in thoughts:
        with st.expander(f"{event['agent']} ({event['graph']})"):
            st.markdown(event["text"])

    with st.expander("Event timeline (both graphs)"):
        st.dataframe([{"graph": e.get("graph"), "agent": e.get("agent", ""), "kind": e.get("kind"),
                       "detail": e.get("node") or e.get("tool") or str(e.get("text", ""))[:120]}
                      for e in events if e.get("kind") != "cli_stderr"],
                     width="stretch", hide_index=True)
    with st.expander("Final pytest output"):
        st.code(state.get("test_output", ""), language=None)


# ----------------------------------------------------------------- sidebar

with st.sidebar:
    st.header("Settings")
    env_key = os.getenv("ANTHROPIC_API_KEY", "")
    typed_key = st.text_input(
        "Anthropic API key", type="password", key="api_key",
        placeholder="Loaded from .env" if env_key else "sk-ant-...",
        help="Kept in memory for this session only. Leave empty to use .env.",
    )
    api_key = typed_key or env_key
    model = st.text_input("Model", os.getenv("CLAUDE_MODEL", DEFAULT_MODEL))
    st.caption("Adaptive thinking is always on. Effort per agent:")
    effort = {role: st.select_slider(role, EFFORTS, value=default, key=f"effort_{role}")
              for role, default in (("Planner", "high"), ("Coder", "high"), ("Reviewer", "medium"))}
    max_rounds = int(st.number_input("Max review rounds", 1, 5, 2))
    max_attempts = int(st.number_input("Max coder attempts per round (subgraph)", 1, 6, 3))
    max_agent_turns = int(st.number_input("Max turns per agent call", 1, 100, 25))
    budget = float(st.number_input("Max USD per agent call", 0.1, 20.0, 2.0, step=0.5))
    example = st.selectbox("Example project", list(EXAMPLES), key="example")
    workspace_path = st.text_input("Workspace folder", str(default_workspace(example)),
                                   key=f"workspace_{example}")
    reset = st.button("Reset broken example", key="reset",
                      help=f"Copies examples/{example} into the workspace (overwrites those files).")

ws_path = Path(workspace_path)
if not reset and not ws_path.exists() and ws_path.resolve() != default_workspace(example):
    st.info(f"`{ws_path}` does not exist. Click **Reset broken example** "
            "to create it with the example files.")
    st.stop()

try:
    workspace = prepare_workspace(ws_path, example=example, reset=reset)
except SandboxError as exc:
    st.error(str(exc))
    st.stop()

if reset:
    st.session_state.pop("last_run", None)
    st.sidebar.success("Example restored.")


# -------------------------------------------------------------------- main

st.title("Level 4: LangGraph + Claude Agent SDK")
st.caption(f"Parent graph with a fix-loop subgraph | Example: `{example}` | Workspace: `{workspace.root}`")

tab_run, tab_graph, tab_files = st.tabs(["Run graph", "Graph", "Workspace files"])

with tab_graph:
    compiled = build_graph(runner=None)  # structure only; no agent runs
    st.graphviz_chart(graph_to_dot(compiled))
    st.caption("Dashed arrows are conditional edges (a routing function picks the next node). "
               "The dashed box is the fix_loop subgraph, which runs as a single node of the parent graph.")
    with st.expander("Mermaid source"):
        st.code(compiled.get_graph(xray=True).draw_mermaid(), language=None)

with tab_run:
    task = st.text_area("Task", EXAMPLES[example], height=80, key=f"task_{example}")
    col_run, col_tests, _ = st.columns([1, 1, 4])
    run_clicked = col_run.button("Run graph", type="primary", disabled=not api_key, key="run")
    tests_clicked = col_tests.button("Run tests only", key="run_tests")
    if not api_key:
        st.info("Add an Anthropic API key in the sidebar (or in .env) to run the graph.")

    if tests_clicked:
        result = run_pytest(workspace)
        (st.success if result.passed else st.error)(result.summary)
        st.code(result.output, language=None)

    if run_clicked:
        settings = AgentSettings(model=model, effort=effort, max_turns=max_agent_turns,
                                 max_budget_usd=budget, api_key=typed_key or None)
        lines: list[str] = []
        with st.status("Graph running... (interacting with the page will stop it)",
                       expanded=True) as status:
            live = st.empty()

            def on_event(event: dict) -> None:
                line = describe_event(event)
                if line:
                    lines.append(line)
                    live.code("\n".join(lines[-40:]), language=None)

            try:
                state, events = asyncio.run(run_graph(
                    task, workspace, ClaudeAgentRunner(settings), max_rounds=max_rounds,
                    max_attempts=max_attempts, on_event=on_event))
            except Exception as exc:  # missing CLI, auth, network, ...
                status.update(label=f"Run failed: {type(exc).__name__}", state="error")
                st.exception(exc)
                st.session_state.pop("last_run", None)
            else:
                ok = state.get("stop_reason") == "approved"
                status.update(label=f"Finished: {state.get('stop_reason')}",
                              state="complete" if ok else "error", expanded=False)
                st.session_state["last_run"] = {"state": state, "events": events}

    if "last_run" in st.session_state:
        show_results(st.session_state["last_run"])

with tab_files:
    listing = workspace.list_files()
    files = [f for f in listing if not f.startswith("... (truncated")]
    if not files:
        st.info("The workspace is empty.")
    else:
        rel = st.selectbox("File", files)
        try:
            if workspace.is_read_only(workspace.resolve(rel)):
                st.caption("Read-only for the agents")
            st.code(workspace.read_file(rel), language="python" if rel.endswith(".py") else None,
                    line_numbers=True)
        except SandboxError as exc:
            st.warning(str(exc))
