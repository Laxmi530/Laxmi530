"""End-to-end tests of the parent graph and its fix-loop subgraph (offline, no Claude)."""

import asyncio

import pytest

from harness.display import graph_to_dot
from harness.graph import build_graph, run_graph
from harness.workspace_setup import prepare_workspace
from tests.helpers import ScriptedRunner, edit, fail, noop, plan, review, write
from tests.test_pytest_runner import FIXED_CALCULATOR

ONE_BUG_FIX = edit("calculator.py", "return b - a", "return a - b")


@pytest.fixture
def calc_ws(tmp_path):
    return prepare_workspace(tmp_path / "ws", example="calculator")


def run(ws, runner, **kwargs):
    return asyncio.run(run_graph("Fix calculator.py", ws, runner, on_event=lambda e: None, **kwargs))


def test_full_flow_through_subgraph_and_review_rounds(calc_ws):
    runner = ScriptedRunner({
        "Planner": [plan()],
        "Coder": [ONE_BUG_FIX,                                   # round 1, attempt 1: tests fail
                  write("calculator.py", FIXED_CALCULATOR),      # round 1, attempt 2: tests pass
                  edit("calculator.py", "Cannot average an empty list",   # round 2, attempt 1
                       "average() needs at least one number")],
        "Reviewer": [review(False, issues=["Use a clearer ValueError message in average()."]),
                     review(True)],
    })

    state, events = run(calc_ws, runner, max_rounds=2, max_attempts=3)

    assert state["stop_reason"] == "approved"
    assert state["tests_passed"]
    assert state["round"] == 2
    assert [r["approved"] for r in state["reviews"]] == [False, True]
    assert [r["role"] for r in state["agent_runs"]] == [
        "Planner", "Coder", "Coder", "Reviewer", "Coder", "Reviewer"]
    assert [r["attempt"] for r in state["agent_runs"] if r["role"] == "Coder"] == [1, 2, 1]
    assert state["cost_usd"] == pytest.approx(0.01 + 3 * 0.02 + 2 * 0.01)

    # The coder's prompts carry the harness's feedback: test failures, then the review.
    assert "NOT passing" in runner.prompts["Coder"][1]
    assert "clearer ValueError" in runner.prompts["Coder"][2]

    # Streaming with subgraphs=True: events come from inside the subgraph too.
    subgraph_nodes = [e["node"] for e in events if e["graph"] == "fix_loop" and e["kind"] == "node"]
    assert subgraph_nodes == ["code", "test", "code", "test", "code", "test"]
    parent_nodes = [e["node"] for e in events if e["graph"] == "parent" and e["kind"] == "node"]
    assert parent_nodes == ["setup", "plan", "fix_loop", "review", "fix_loop", "review", "finish"]
    assert any(e["kind"] == "thinking" and e["graph"] == "fix_loop" and e["agent"] == "Coder"
               for e in events)


def test_subgraph_stops_after_max_attempts(calc_ws):
    runner = ScriptedRunner({"Planner": [plan()], "Coder": [ONE_BUG_FIX, noop()]})

    state, _ = run(calc_ws, runner, max_attempts=2)

    assert state["stop_reason"] == "tests_failing"
    assert len(runner.prompts["Coder"]) == 2
    assert "Reviewer" not in runner.prompts  # no review while tests fail
    assert state["reviews"] == []


def test_already_passing_tests_skip_every_agent(calc_ws):
    calc_ws.write_file("calculator.py", FIXED_CALCULATOR)
    runner = ScriptedRunner({})  # any agent call would fail: no steps scripted

    state, events = run(calc_ws, runner)

    assert state["stop_reason"] == "already_passing"
    assert state["agent_runs"] == []
    assert [e["node"] for e in events if e["kind"] == "node"] == ["setup", "finish"]


def test_planner_error_skips_the_rest(calc_ws):
    runner = ScriptedRunner({"Planner": [fail("Planner", "authentication_failed")]})

    state, _ = run(calc_ws, runner)

    assert state["stop_reason"] == "agent_error: Planner: authentication_failed"
    assert "Coder" not in runner.prompts
    assert not state["tests_passed"]  # finish re-ran pytest for the real final state


def test_coder_error_leaves_the_subgraph(calc_ws):
    runner = ScriptedRunner({"Planner": [plan()], "Coder": [fail("Coder", "rate_limit")]})

    state, _ = run(calc_ws, runner, max_attempts=3)

    assert state["stop_reason"] == "agent_error: Coder: rate_limit"
    assert len(runner.prompts["Coder"]) == 1  # no retry after an agent error


def test_review_rounds_are_limited(calc_ws):
    runner = ScriptedRunner({"Planner": [plan()],
                             "Coder": [write("calculator.py", FIXED_CALCULATOR)],
                             "Reviewer": [review(False, issues=["Try again."])]})

    state, _ = run(calc_ws, runner, max_rounds=1)

    assert state["stop_reason"] == "max_rounds"
    assert state["tests_passed"]  # tests pass, but no approval means not done


def test_recursion_limit_stops_runaway_graphs(calc_ws):
    # The subgraph counts its own steps against the same limit:
    # code, test, code, test, then the 5th step exceeds recursion_limit=4.
    runner = ScriptedRunner({"Planner": [plan()], "Coder": [noop()] * 20})

    state, events = run(calc_ws, runner, max_attempts=20, recursion_limit=4)

    assert state["stop_reason"] == "recursion_limit"
    assert events[-1]["kind"] == "stopped"


def test_graph_structure_contains_the_subgraph():
    app = build_graph(runner=None)
    nodes = set(app.get_graph(xray=True).nodes)
    assert {"setup", "plan", "review", "finish", "fix_loop:code", "fix_loop:test"} <= nodes
    conditional = {(e.source, e.target) for e in app.get_graph(xray=True).edges if e.conditional}
    assert {("setup", "plan"), ("setup", "finish"), ("plan", "finish"), ("review", "finish"),
            ("fix_loop:test", "fix_loop:code"), ("fix_loop:__end__", "review")} <= conditional
    dot = graph_to_dot(app)
    assert 'subgraph "cluster_fix_loop"' in dot
    assert '"fix_loop:test" -> "fix_loop:code" [style=dashed]' in dot
