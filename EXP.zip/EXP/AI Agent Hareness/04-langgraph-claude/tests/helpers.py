"""A scripted stand-in for Claude so the whole graph can be tested offline.

Each role gets a queue of steps. A step is a function (workspace, prompt) ->
AgentResult that may change files, just like a real agent would.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Callable

from harness.agents import AgentResult, Role
from harness.sandbox import Workspace

Step = Callable[[Workspace, str], AgentResult]

PLAN = {"root_causes": "subtract, divide and average are wrong in calculator.py.",
        "steps": ["Fix subtract", "Fix divide", "Fix average"],
        "files_to_change": ["calculator.py"]}


class ScriptedRunner:
    def __init__(self, steps: dict[str, list[Step]]) -> None:
        self.steps = {role: list(queue) for role, queue in steps.items()}
        self.prompts: dict[str, list[str]] = defaultdict(list)

    async def run(self, role: Role, prompt: str, workspace: Workspace, emit) -> AgentResult:
        self.prompts[role.name].append(prompt)
        emit({"kind": "thinking", "text": f"{role.name} is thinking about the task."})
        return self.steps[role.name].pop(0)(workspace, prompt)


def plan(structured: dict = PLAN) -> Step:
    return lambda ws, prompt: AgentResult("Planner", structured=structured, cost_usd=0.01, num_turns=2)


def edit(path: str, old: str, new: str) -> Step:
    def step(ws: Workspace, prompt: str) -> AgentResult:
        ws.edit_file(path, old, new)
        return AgentResult("Coder", text="Edited.", cost_usd=0.02, num_turns=3, tool_calls=["Edit"])
    return step


def edits(changes: list[tuple[str, str, str]]) -> Step:
    def step(ws: Workspace, prompt: str) -> AgentResult:
        for path, old, new in changes:
            ws.edit_file(path, old, new)
        return AgentResult("Coder", text="Edited.", cost_usd=0.02, num_turns=3,
                           tool_calls=["Edit"] * len(changes))
    return step


def write(path: str, content: str) -> Step:
    def step(ws: Workspace, prompt: str) -> AgentResult:
        ws.write_file(path, content)
        return AgentResult("Coder", text="Rewrote the file.", cost_usd=0.02, num_turns=3,
                           tool_calls=["Write"])
    return step


def review(approved: bool, summary: str = "", issues: list[str] | None = None) -> Step:
    verdict = {"approved": approved, "summary": summary or ("Looks right." if approved else "Not yet."),
               "issues": issues or []}
    return lambda ws, prompt: AgentResult("Reviewer", structured=verdict, cost_usd=0.01, num_turns=1)


def noop() -> Step:
    """A coder turn that changes nothing."""
    return lambda ws, prompt: AgentResult("Coder", text="No changes.", cost_usd=0.02, num_turns=1)


def fail(role: str, message: str) -> Step:
    return lambda ws, prompt: AgentResult(role, error=message)
