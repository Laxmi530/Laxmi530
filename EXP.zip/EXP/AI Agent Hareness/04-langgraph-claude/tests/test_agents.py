"""Claude Agent SDK layer: options per role, the sandbox hook, the custom tool, message parsing.

All offline: no Claude Code process is started.
"""

import asyncio

import pytest
from claude_agent_sdk import (
    AssistantMessage, CLINotFoundError, ResultMessage, TextBlock, ThinkingBlock, ToolUseBlock,
)

from harness.agents import CODER, PLANNER, REVIEWER, AgentSettings, ClaudeAgentRunner, build_options
from harness.tools import RUN_TESTS, STRUCTURED_OUTPUT, make_run_tests_tool, make_sandbox_hook
from harness.workspace_setup import prepare_workspace
from tests.helpers import PLAN


@pytest.fixture
def ws(tmp_path):
    return prepare_workspace(tmp_path / "ws", example="calculator")


def options(role, ws, **settings):
    return build_options(role, ws, AgentSettings(**settings), emit=lambda e: None)


# ------------------------------------------------------------------ options

def test_every_role_uses_adaptive_thinking_and_is_isolated(ws):
    for role in (PLANNER, CODER, REVIEWER):
        opts = options(role, ws)
        assert opts.thinking == {"type": "adaptive", "display": "summarized"}
        assert opts.permission_mode == "dontAsk"
        assert opts.setting_sources == []
        assert opts.strict_mcp_config is True
        assert opts.cwd == str(ws.root)
        assert opts.model == "claude-opus-5-5"
        assert "Bash" not in opts.tools and "WebFetch" not in opts.tools
        assert "PreToolUse" in opts.hooks


def test_only_the_coder_can_edit(ws):
    assert {"Edit", "Write"} <= set(options(CODER, ws).tools)
    assert not {"Edit", "Write"} & set(options(PLANNER, ws).tools)
    assert not {"Edit", "Write"} & set(options(REVIEWER, ws).tools)


def test_reviewer_cannot_run_tests(ws):
    assert RUN_TESTS in options(PLANNER, ws).allowed_tools
    assert RUN_TESTS in options(CODER, ws).allowed_tools
    reviewer = options(REVIEWER, ws)
    assert RUN_TESTS not in reviewer.allowed_tools
    assert reviewer.mcp_servers == {}


def test_effort_and_structured_output_per_role(ws):
    planner, coder, reviewer = options(PLANNER, ws), options(CODER, ws), options(REVIEWER, ws)
    assert (planner.effort, coder.effort, reviewer.effort) == ("high", "high", "medium")
    assert "root_causes" in planner.output_format["schema"]["properties"]
    assert "approved" in reviewer.output_format["schema"]["properties"]
    assert coder.output_format is None


def test_structured_output_tool_is_pre_approved_only_where_needed(ws):
    # With permission_mode="dontAsk", Claude Code's StructuredOutput tool must be
    # allowed explicitly, or the planner's and reviewer's answers would be denied.
    assert STRUCTURED_OUTPUT in options(PLANNER, ws).allowed_tools
    assert STRUCTURED_OUTPUT in options(REVIEWER, ws).allowed_tools
    assert STRUCTURED_OUTPUT not in options(CODER, ws).allowed_tools


def test_output_schemas_forbid_extra_fields(ws):
    assert options(PLANNER, ws).output_format["schema"]["additionalProperties"] is False


def test_typed_api_key_is_passed_only_to_the_claude_process(ws):
    assert options(CODER, ws, api_key="sk-ant-test").env == {"ANTHROPIC_API_KEY": "sk-ant-test"}
    assert options(CODER, ws).env == {}


# ------------------------------------------------------------- sandbox hook

def call_hook(ws, tool_name, tool_input):
    events = []
    hook = make_sandbox_hook(ws, events.append)
    out = asyncio.run(hook({"tool_name": tool_name, "tool_input": tool_input}, "id-1", None))
    return out.get("hookSpecificOutput", {}).get("permissionDecision", "allow"), events


@pytest.mark.parametrize("tool_name, tool_input", [
    ("Read", {"file_path": "OUTSIDE/secret.txt"}),
    ("Edit", {"file_path": "WS/tests/test_calculator.py", "old_string": "a", "new_string": "b"}),
    ("Write", {"file_path": "WS/conftest.py.", "content": "x"}),
    ("Write", {"file_path": "WS/pytest.ini", "content": "x"}),
    ("Read", {"file_path": "WS/.env"}),
    ("Glob", {"pattern": "../**/*.py"}),
    ("Glob", {"pattern": "C:/Users/**"}),
    ("Grep", {"pattern": "def", "path": "OUTSIDE"}),
    ("Grep", {"pattern": "def", "glob": "../*.py"}),
    ("Read", {"file_path": "~/notes.txt"}),
    ("Read", {"file_path": "$HOME/notes.txt"}),
    ("Read", {"file_path": "%USERPROFILE%\\notes.txt"}),
    ("Glob", {"pattern": "~/**"}),
])
def test_hook_denies_unsafe_calls(ws, tmp_path, tool_name, tool_input):
    tool_input = {k: v.replace("WS", str(ws.root)).replace("OUTSIDE", str(tmp_path / "outside"))
                  for k, v in tool_input.items()}
    decision, events = call_hook(ws, tool_name, tool_input)
    assert decision == "deny"
    assert events and events[0]["kind"] == "denied"


@pytest.mark.parametrize("tool_name, tool_input", [
    ("Read", {"file_path": "WS/calculator.py"}),
    ("Read", {"file_path": "WS/tests/test_calculator.py"}),  # tests are readable, just not writable
    ("Edit", {"file_path": "WS/calculator.py", "old_string": "a", "new_string": "b"}),
    ("Glob", {"pattern": "**/*.py"}),
    ("Grep", {"pattern": "def .*\\(", "path": "WS"}),  # a regex, not a path
    ("mcp__harness__run_tests", {"test_path": ""}),
])
def test_hook_allows_safe_calls(ws, tool_name, tool_input):
    tool_input = {k: v.replace("WS", str(ws.root)) for k, v in tool_input.items()}
    assert call_hook(ws, tool_name, tool_input)[0] == "allow"


# --------------------------------------------------------------- custom tool

def test_run_tests_tool(ws):
    run_tests = make_run_tests_tool(ws)
    out = asyncio.run(run_tests.handler({"test_path": ""}))
    assert out["content"][0]["text"].startswith("FAILED: 5 failed, 2 passed")


def test_run_tests_tool_stays_in_the_workspace(ws):
    out = asyncio.run(make_run_tests_tool(ws).handler({"test_path": "../elsewhere"}))
    assert out["content"][0]["text"].startswith("ERROR:")


# -------------------------------------------------------- message handling

def fake_query(messages):
    captured = {}

    async def query(prompt, options):
        captured["prompt"], captured["options"] = prompt, options
        for message in messages:
            yield message

    return query, captured


def result_message(**kwargs):
    defaults = dict(subtype="success", duration_ms=10, duration_api_ms=8, is_error=False,
                    num_turns=3, session_id="s1", total_cost_usd=0.05, result="Done.")
    return ResultMessage(**{**defaults, **kwargs})


def test_runner_turns_sdk_messages_into_events_and_a_result(ws):
    query, captured = fake_query([
        AssistantMessage(content=[ThinkingBlock("The bug is probably in subtract.", "sig"),
                                  ToolUseBlock("t1", "Read", {"file_path": "calculator.py"}),
                                  TextBlock("Here is my plan.")], model="claude-opus-5-5"),
        result_message(structured_output=PLAN),
    ])
    events = []

    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=query)
                         .run(PLANNER, "Plan it", ws, events.append))

    assert result.error == ""
    assert result.structured == PLAN
    assert (result.num_turns, result.cost_usd, result.tool_calls) == (3, 0.05, ["Read"])
    assert [e["kind"] for e in events] == ["thinking", "tool", "text"]
    assert captured["prompt"] == "Plan it"
    assert captured["options"].effort == "high"


def test_structured_output_tool_call_is_not_shown_as_a_step(ws):
    query, _ = fake_query([
        AssistantMessage(content=[ToolUseBlock("t1", "StructuredOutput", PLAN)], model="m"),
        result_message(structured_output=PLAN),
    ])
    events = []
    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=query)
                         .run(PLANNER, "x", ws, events.append))
    assert result.tool_calls == [] and events == []
    assert result.structured == PLAN


def test_sdk_exceptions_become_agent_errors(ws):
    async def broken_query(prompt, options):
        raise CLINotFoundError("Claude Code not found")
        yield  # makes this an async generator

    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=broken_query)
                         .run(CODER, "x", ws, lambda e: None))
    assert result.error.startswith("CLINotFoundError")


def test_malformed_structured_output_becomes_an_error(ws):
    query, _ = fake_query([result_message(structured_output={"approved": "maybe"})])
    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=query)
                         .run(REVIEWER, "x", ws, lambda e: None))
    assert "didn't match Review" in result.error


def test_runner_reports_refusals(ws):
    query, _ = fake_query([result_message(stop_reason="refusal", is_error=True, result="")])
    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=query)
                         .run(CODER, "x", ws, lambda e: None))
    assert "refusal" in result.error


def test_runner_requires_structured_output_from_planner_and_reviewer(ws):
    query, _ = fake_query([result_message(structured_output=None)])
    result = asyncio.run(ClaudeAgentRunner(AgentSettings(), query_fn=query)
                         .run(REVIEWER, "x", ws, lambda e: None))
    assert result.error == "No structured output was returned."
