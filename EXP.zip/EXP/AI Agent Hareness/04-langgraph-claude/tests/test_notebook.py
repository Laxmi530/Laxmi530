"""Runs graph_demo.ipynb top to bottom (offline sections only) so it can't silently go stale."""

from pathlib import Path

import pytest

nbformat = pytest.importorskip("nbformat")
nbclient = pytest.importorskip("nbclient")
pytest.importorskip("ipykernel")

LEVEL_DIR = Path(__file__).resolve().parents[1]


def test_notebook_runs_and_the_graph_is_approved():
    nb = nbformat.read(LEVEL_DIR / "graph_demo.ipynb", as_version=4)
    nbclient.NotebookClient(nb, timeout=600, kernel_name="python3",
                            resources={"metadata": {"path": str(LEVEL_DIR)}}).execute()

    outputs = "\n".join(out.get("text", "") for cell in nb.cells if cell.cell_type == "code"
                        for out in cell.get("outputs", []))
    assert "ainvoke returned stop_reason = approved" in outputs
    assert "fix_loop:test  ->  fix_loop:code" in outputs  # a conditional edge inside the subgraph
    assert "Skipped. Set RUN_WITH_CLAUDE = True" in outputs  # real Claude is off by default
