"""Tests for the workspace sandbox. These run offline, no API key needed."""

import os

import pytest

from harness.sandbox import SandboxError, Workspace


@pytest.fixture
def ws(tmp_path):
    (tmp_path / "app.py").write_text("x = 1\ny = 2\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_app.py").write_text("def test(): pass\n", encoding="utf-8")
    (tmp_path / ".env").write_text("SECRET=1\n", encoding="utf-8")
    return Workspace(tmp_path)


@pytest.mark.parametrize(
    "bad_path",
    [
        "../outside.txt",
        "sub/../../outside.txt",
        "..\\outside.txt",
        "/etc/passwd",
        "C:\\Windows\\win.ini",
        "C:relative.txt",
        "app.py:hidden_stream",
        "",
        ".env",
        "sub/.git/config",
        "conftest.py.",
        "conftest.py ",
        "tests./test_app.py",
    ],
)
def test_rejects_unsafe_paths(ws, bad_path):
    with pytest.raises(SandboxError):
        ws.resolve(bad_path)


def test_rejects_symlink_escape(ws, tmp_path_factory):
    outside = tmp_path_factory.mktemp("outside") / "secret.txt"
    outside.write_text("secret", encoding="utf-8")
    try:
        os.symlink(outside, ws.root / "link.txt")
    except (OSError, NotImplementedError):
        pytest.skip("Creating symlinks is not permitted on this machine")
    with pytest.raises(SandboxError, match="escapes"):
        ws.read_file("link.txt")
    assert "link.txt" not in ws.list_files()


def test_list_files_hides_hidden_files_and_folders(ws):
    (ws.root / ".venv" / "lib").mkdir(parents=True)
    (ws.root / ".venv" / "lib" / "big.py").write_text("", encoding="utf-8")
    (ws.root / "__pycache__").mkdir()
    (ws.root / "__pycache__" / "app.cpython-312.pyc").write_bytes(b"")
    assert ws.list_files() == ["app.py", "tests/test_app.py"]


def test_read_file(ws):
    assert ws.read_file("app.py") == "x = 1\ny = 2\n"


@pytest.mark.parametrize("path", ["tests/test_app.py", "Tests/test_app.py", "conftest.py", "pytest.ini"])
def test_tests_and_config_are_read_only(ws, path):
    with pytest.raises(SandboxError, match="read-only"):
        ws.write_file(path, "def test(): assert True\n")


def test_write_creates_file_in_subfolder(ws):
    assert ws.write_file("pkg/new.py", "z = 3\n") == "pkg/new.py"
    assert ws.read_file("pkg/new.py") == "z = 3\n"


def test_edit_replaces_unique_match(ws):
    ws.edit_file("app.py", "y = 2", "y = 20")
    assert ws.read_file("app.py") == "x = 1\ny = 20\n"


def test_edit_rejects_missing_match(ws):
    with pytest.raises(SandboxError, match="not found"):
        ws.edit_file("app.py", "nope", "x")


def test_search_is_case_insensitive_and_reports_line_numbers(ws):
    assert ws.search("Y = 2") == ["app.py:2: y = 2"]


def test_search_skips_hidden_files(ws):
    assert ws.search("SECRET") == []


def test_search_can_be_limited_to_a_folder(ws):
    assert ws.search("def", "tests") == ["tests/test_app.py:1: def test(): pass"]


def test_search_rejects_empty_query(ws):
    with pytest.raises(SandboxError):
        ws.search("  ")


def test_read_lines_whole_file_has_line_numbers(ws):
    assert ws.read_lines("app.py") == "app.py (lines 1-2 of 2)\n1| x = 1\n2| y = 2"


def test_read_lines_range(ws):
    assert ws.read_lines("app.py", 2, 2).splitlines()[1] == "2| y = 2"


def test_read_lines_rejects_out_of_range_start(ws):
    with pytest.raises(SandboxError, match="between 1 and 2"):
        ws.read_lines("app.py", 5, 0)


def test_line_numbers_ignore_form_feeds(ws):
    ws.write_file("ff.py", "a = 1\x0c\nb = 2\n")
    assert ws.read_lines("ff.py").splitlines()[0] == "ff.py (lines 1-2 of 2)"
    assert ws.search("b = 2") == ["ff.py:2: b = 2"]


def test_read_lines_caps_long_reads(ws):
    ws.write_file("big.py", "".join(f"line{i}\n" for i in range(1, 501)))
    text = ws.read_lines("big.py")
    assert "lines 1-400 of 500" in text
    assert "start_line=401" in text
    assert text.splitlines()[-1].endswith("line400")


def test_tool_path_accepts_absolute_paths_inside(ws):
    assert ws.check_tool_path(str(ws.root / "app.py")) == ws.root / "app.py"
    assert ws.check_tool_path(str(ws.root)) == ws.root  # e.g. Glob/Grep on the whole workspace


def test_tool_path_rejects_absolute_paths_outside(ws, tmp_path_factory):
    with pytest.raises(SandboxError, match="outside the workspace"):
        ws.check_tool_path(str(tmp_path_factory.mktemp("elsewhere") / "x.py"))


def test_tool_path_write_rules(ws):
    with pytest.raises(SandboxError, match="read-only"):
        ws.check_tool_path(str(ws.root / "tests" / "test_app.py"), write=True)
    with pytest.raises(SandboxError, match="read-only"):
        ws.check_tool_path(str(ws.root), write=True)
    ws.check_tool_path(str(ws.root / "tests" / "test_app.py"))  # reading tests is fine


def test_edit_rejects_ambiguous_match(ws):
    with pytest.raises(SandboxError, match="2 times"):
        ws.edit_file("app.py", " = ", " == ")
