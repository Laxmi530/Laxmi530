"""Headless smoke tests of the Streamlit UI (no browser, no API key, no Claude)."""

from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

from harness.workspace_setup import prepare_workspace  # noqa: E402

APP = str(Path(__file__).resolve().parents[1] / "app.py")


@pytest.fixture
def app(tmp_path):
    ws = prepare_workspace(tmp_path / "ws", example="shop")
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    at.text_input(key="workspace_shop").set_value(str(ws.root)).run()
    return at


def test_app_renders_with_the_graph_diagram(app):
    assert not app.exception
    assert app.title[0].value == "Level 4: LangGraph + Claude Agent SDK"
    assert app.get("graphviz_chart")  # the Graph tab
    assert any("fix_loop" in c.value for c in app.code)  # Mermaid source mentions the subgraph


def test_run_tests_button_shows_failing_shop_example(app):
    app.button(key="run_tests").click().run()
    assert not app.exception
    assert any("13 failed" in e.value for e in app.error)


def test_run_button_executes_the_graph_and_shows_results(app, monkeypatch):
    """Clicks "Run graph" with the real LangGraph workflow; only Claude is scripted."""
    import harness.graph

    from tests.helpers import ScriptedRunner, edits, plan, review
    from tests.test_shop_example import FIXES

    real_run_graph = harness.graph.run_graph
    shop_plan = {"root_causes": "Rounding in money.py and four other bugs.",
                 "steps": ["Fix money", "Fix catalog", "Fix discounts", "Fix cart"],
                 "files_to_change": ["shop/money.py"]}
    scripted = ScriptedRunner({"Planner": [plan(shop_plan)], "Coder": [edits(FIXES)],
                               "Reviewer": [review(True, "Correct and minimal.")]})

    async def scripted_run_graph(task, workspace, runner, **kwargs):
        return await real_run_graph(task, workspace, scripted, **kwargs)

    monkeypatch.setattr(harness.graph, "run_graph", scripted_run_graph)
    app.text_input(key="api_key").set_value("sk-ant-test-not-used").run()
    app.button(key="run").click().run()

    assert not app.exception
    assert "approved" in [m.value for m in app.metric]
    assert any("23 passed" in s.value for s in app.success)
    assert any("Correct and minimal." in s.value for s in app.success)  # the review
    assert any("Rounding in money.py" in m.value for m in app.markdown)  # the plan
    assert any("ROUND_HALF_UP" in c.value for c in app.code)  # the diff
    assert any("thinking summaries" in c.value for c in app.caption)


def test_workspace_containing_the_harness_is_refused(app):
    app.text_input(key="workspace_shop").set_value(str(Path(APP).parent)).run()
    assert any("must not contain the harness" in e.value for e in app.error)
