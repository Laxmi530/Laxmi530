"""Tool-level controls for the Claude agents: the sandbox hook and our custom tool.

The Claude Agent SDK provides Claude Code's built-in tools (Read, Edit, Write,
Glob, Grep). They accept any path, so the harness adds:

- A PreToolUse HOOK: Claude Code calls it before every tool use. It checks
  each path against the Workspace sandbox and returns "deny" for anything
  unsafe. Hooks run before Claude Code's own permission rules, so a deny here
  always wins, even for tools listed in allowed_tools.
- A custom `run_tests` tool, served by an in-process MCP server (it runs inside
  this Python process, no separate server to start).
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable

from claude_agent_sdk import create_sdk_mcp_server, tool

from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError, Workspace

Emit = Callable[[dict], None]  # sends a live event to the UI / CLI

RUN_TESTS = "mcp__harness__run_tests"  # MCP tools are named mcp__<server>__<tool>
STRUCTURED_OUTPUT = "StructuredOutput"  # added by Claude Code when output_format is set
FILE_TOOLS = {"Read", "Edit", "Write", "Glob", "Grep"}
WRITE_TOOLS = {"Edit", "Write"}


# ------------------------------------------------------------ sandbox hook

def check_tool_call(workspace: Workspace, tool_name: str, args: dict[str, Any]) -> None:
    """Raise SandboxError if a built-in tool call would leave the sandbox."""
    if tool_name not in FILE_TOOLS:
        return  # e.g. run_tests, which sandboxes itself
    for key in ("file_path", "path"):
        if args.get(key):
            workspace.check_tool_path(str(args[key]), write=tool_name in WRITE_TOOLS)
    # Path-like patterns: Glob's "pattern" and Grep's "glob" file filter.
    # (Grep's own "pattern" is a regex over file contents, not a path.)
    pattern = args.get("pattern") if tool_name == "Glob" else args.get("glob") if tool_name == "Grep" else None
    if pattern and (".." in pattern or ":" in pattern or pattern.startswith(("/", "\\", "~"))):
        raise SandboxError(f"Patterns must be relative and stay inside the workspace: {pattern!r}")


def make_sandbox_hook(workspace: Workspace, emit: Emit):
    async def sandbox_hook(input_data: dict[str, Any], tool_use_id: str | None,
                           context: Any) -> dict[str, Any]:
        tool_name = input_data.get("tool_name", "")
        try:
            check_tool_call(workspace, tool_name, input_data.get("tool_input") or {})
        except SandboxError as exc:
            emit({"kind": "denied", "tool": tool_name, "text": str(exc)})
            return {"hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": str(exc),  # shown to Claude so it can adjust
            }}
        return {}  # no objection; normal permission rules apply

    return sandbox_hook


# ------------------------------------------------------- custom MCP tool

def make_run_tests_tool(workspace: Workspace):
    @tool("run_tests", "Run pytest in the workspace. test_path: a test file or folder "
          "relative to the workspace, or an empty string for all tests.", {"test_path": str})
    async def run_tests(args: dict[str, Any]) -> dict[str, Any]:
        try:
            # pytest is a blocking subprocess; run it off the event loop.
            result = await asyncio.to_thread(run_pytest, workspace, args.get("test_path") or None)
        except SandboxError as exc:
            return {"content": [{"type": "text", "text": f"ERROR: {exc}"}]}
        status = "PASSED" if result.passed else "FAILED"
        return {"content": [{"type": "text",
                             "text": f"{status}: {result.summary}\n\n{result.output}"}]}

    return run_tests


def make_tools_server(workspace: Workspace):
    return create_sdk_mcp_server(name="harness", tools=[make_run_tests_tool(workspace)])
