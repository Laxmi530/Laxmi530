"""Workspace sandbox: every file operation the agent performs goes through here.

This is a HARNESS responsibility. The OpenAI Agents SDK will happily call any
Python function you give it; it has no idea which paths are safe. So the rule
"the agent may only touch files inside the workspace" must be enforced by us.

Rules enforced:
1. Paths must be relative. Absolute paths, drive letters and ':' are rejected
   (':' also blocks Windows alternate data streams like "file.py:hidden").
   Trailing dots/spaces are rejected because Windows silently strips them.
2. After resolving '..' and symlinks, the real path must still be inside the
   workspace root. This is the core path-traversal defence.
3. Hidden files/dirs (".env", ".git", ...) are off limits.
4. Some paths are read-only so the agent cannot "fix" failing tests by
   editing the tests or the pytest configuration.
5. Reads and writes are size-limited to keep the context window and disk sane.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

MAX_READ_BYTES = 100_000
MAX_WRITE_BYTES = 100_000
MAX_LIST_ENTRIES = 200
MAX_SEARCH_RESULTS = 100
MAX_READ_LINES = 400

# Compared case-insensitively because Windows paths are case-insensitive
# ("Tests/test_x.py" is the same file as "tests/test_x.py").
READ_ONLY_DIRS = {"tests"}
READ_ONLY_FILES = {"conftest.py", "pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini"}
SKIP_WHEN_LISTING = {"__pycache__", ".pytest_cache"}


def _split_lines(text: str) -> list[str]:
    """Split on "\\n" only, so line numbers match what editors show.

    str.splitlines() also splits on form feeds, "\\u2028" and other characters
    that editors don't treat as line breaks, which would shift every later line number.
    """
    lines = text.split("\n")
    return lines[:-1] if lines and lines[-1] == "" else lines


class SandboxError(Exception):
    """Raised when the agent asks for something the sandbox does not allow.

    The message is shown to the model, so it should explain what went wrong.
    """


class Workspace:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise SandboxError(f"Workspace folder does not exist: {self.root}")

    # ------------------------------------------------------------------ paths

    def resolve(self, rel_path: str) -> Path:
        """Turn an agent-supplied relative path into a safe absolute path."""
        if not rel_path or not rel_path.strip():
            raise SandboxError("Path must not be empty.")
        if "\x00" in rel_path or ":" in rel_path:
            raise SandboxError(f"Invalid characters in path: {rel_path!r}")

        candidate = Path(rel_path)
        if candidate.is_absolute() or candidate.anchor:
            raise SandboxError(f"Use a path relative to the workspace, got: {rel_path!r}")
        # Windows silently strips trailing dots and spaces, so "conftest.py." would
        # pass the read-only check below but still create a real conftest.py.
        if any(part != ".." and part.endswith((".", " ")) for part in candidate.parts):
            raise SandboxError(f"Path parts must not end with '.' or a space: {rel_path!r}")

        # resolve() collapses '..' and follows symlinks, so a symlink that
        # points outside the workspace is caught by the check below.
        full = (self.root / candidate).resolve()
        if not full.is_relative_to(self.root):
            raise SandboxError(f"Path escapes the workspace: {rel_path!r}")

        rel_parts = full.relative_to(self.root).parts
        if any(part.startswith(".") for part in rel_parts):
            raise SandboxError(f"Hidden files and folders are not accessible: {rel_path!r}")
        return full

    def check_tool_path(self, raw_path: str, write: bool = False) -> Path:
        """Check a path from a Claude Code built-in tool (Read, Edit, Write, Glob, Grep).

        Those tools normally pass absolute paths, so we turn an absolute path
        inside the workspace back into a relative one and then apply exactly
        the same rules as resolve(). Anything outside the workspace is refused.
        """
        # Claude Code may expand "~" (and environment variables) itself, so a path
        # that looks relative here could really point at your home folder.
        if raw_path.startswith("~") or "$" in raw_path or "%" in raw_path:
            raise SandboxError(f"Home-folder and environment-variable paths are not allowed: {raw_path!r}")
        candidate = Path(raw_path)
        if candidate.is_absolute():
            full = candidate.resolve()
            if not full.is_relative_to(self.root):
                raise SandboxError(f"Path is outside the workspace: {raw_path!r}")
            rel = full.relative_to(self.root).as_posix()
        else:
            rel = raw_path
        full = self.root if rel in ("", ".") else self.resolve(rel)
        if write and (full == self.root or self.is_read_only(full)):
            raise SandboxError(
                f"{raw_path!r} is read-only. Fix the source code, not the tests or test config."
            )
        return full

    def relative(self, full: Path) -> str:
        return full.relative_to(self.root).as_posix()

    def is_read_only(self, full: Path) -> bool:
        parts = [p.lower() for p in full.relative_to(self.root).parts]
        return bool(parts) and (parts[0] in READ_ONLY_DIRS or parts[-1] in READ_ONLY_FILES)

    # ------------------------------------------------------------- operations

    def _walk_files(self, directory: str) -> Iterator[Path]:
        """Yield every visible file under `directory`, in a stable order."""
        base = self.root if directory in ("", ".") else self.resolve(directory)
        if not base.is_dir():
            raise SandboxError(f"Not a directory: {directory!r}")
        # os.walk does not follow directory symlinks, and pruning `dirnames` in
        # place means hidden/cache folders (.git, .venv, ...) are never scanned.
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames
                                 if not d.startswith(".") and d not in SKIP_WHEN_LISTING)
            for name in sorted(filenames):
                path = Path(dirpath) / name
                # Skip hidden files and file symlinks that point outside the workspace.
                if not name.startswith(".") and path.resolve().is_relative_to(self.root):
                    yield path

    def list_files(self, directory: str = ".") -> list[str]:
        results: list[str] = []
        for path in self._walk_files(directory):
            results.append(self.relative(path))
            if len(results) >= MAX_LIST_ENTRIES:
                results.append(f"... (truncated at {MAX_LIST_ENTRIES} files)")
                break
        return results

    def search(self, query: str, directory: str = ".") -> list[str]:
        """Case-insensitive plain-text search. Returns "path:line: text" matches.

        Plain text rather than regex on purpose: a badly written regex can hang
        the harness (catastrophic backtracking), and models rarely need regex here.
        """
        if not query.strip():
            raise SandboxError("query must not be empty.")
        needle = query.lower()
        results: list[str] = []
        for path in self._walk_files(directory):
            try:
                text = self.read_file(self.relative(path))
            except SandboxError:
                continue  # binary or too large to search
            for number, line in enumerate(_split_lines(text), start=1):
                if needle in line.lower():
                    results.append(f"{self.relative(path)}:{number}: {line.strip()[:200]}")
                    if len(results) >= MAX_SEARCH_RESULTS:
                        results.append(f"... (truncated at {MAX_SEARCH_RESULTS} matches)")
                        return results
        return results

    def read_lines(self, rel_path: str, start_line: int = 1, end_line: int = 0) -> str:
        """Return lines start_line..end_line (1-based, inclusive) with line numbers.

        end_line 0 means "to the end of the file". At most MAX_READ_LINES lines
        are returned per call, so a huge file can't flood the model's context.
        """
        lines = _split_lines(self.read_file(rel_path))
        total = len(lines)
        if total == 0:
            return f"{rel_path} is empty."
        if start_line < 1 or start_line > total:
            raise SandboxError(f"start_line must be between 1 and {total} for {rel_path!r}.")
        end = total if end_line <= 0 else min(end_line, total)
        if end < start_line:
            raise SandboxError("end_line must be 0 or at least start_line.")
        end = min(end, start_line + MAX_READ_LINES - 1)

        width = len(str(end))
        body = "\n".join(f"{n:>{width}}| {lines[n - 1]}" for n in range(start_line, end + 1))
        header = f"{rel_path} (lines {start_line}-{end} of {total})"
        if end < total:
            header += f" - call again with start_line={end + 1} to read more"
        return f"{header}\n{body}"

    def read_file(self, rel_path: str) -> str:
        full = self.resolve(rel_path)
        if not full.is_file():
            raise SandboxError(f"File not found: {rel_path!r}")
        if full.stat().st_size > MAX_READ_BYTES:
            raise SandboxError(f"File is larger than {MAX_READ_BYTES} bytes: {rel_path!r}")
        try:
            return full.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise SandboxError(f"File is not UTF-8 text: {rel_path!r}") from None

    def write_file(self, rel_path: str, content: str) -> str:
        """Create or overwrite a file. Returns the normalised relative path."""
        full = self._check_writable(rel_path)
        if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
            raise SandboxError(f"Content is larger than {MAX_WRITE_BYTES} bytes.")
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8", newline="\n")
        return self.relative(full)

    def edit_file(self, rel_path: str, old_text: str, new_text: str) -> str:
        """Replace exactly one occurrence of old_text with new_text.

        Requiring a unique match is a deliberate safety rule: the model must
        quote enough surrounding code that the edit is unambiguous, so it can't
        accidentally change the wrong line.
        """
        self._check_writable(rel_path)
        if not old_text:
            raise SandboxError("old_text must not be empty. Use write_file to create files.")
        content = self.read_file(rel_path)
        count = content.count(old_text)
        if count == 0:
            raise SandboxError(
                "old_text was not found. Re-read the file and copy the exact text, "
                "including indentation but WITHOUT the 'NN| ' line-number prefixes."
            )
        if count > 1:
            raise SandboxError(
                f"old_text appears {count} times. Include more surrounding lines so it is unique."
            )
        return self.write_file(rel_path, content.replace(old_text, new_text, 1))

    def _check_writable(self, rel_path: str) -> Path:
        full = self.resolve(rel_path)
        if self.is_read_only(full):
            raise SandboxError(
                f"{rel_path!r} is read-only. Fix the source code, not the tests or test config."
            )
        if full.is_dir():
            raise SandboxError(f"{rel_path!r} is a directory.")
        return full
