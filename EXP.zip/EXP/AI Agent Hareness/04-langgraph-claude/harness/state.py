"""Graph state and the structured messages the agents produce.

LangGraph state is a TypedDict. Every node receives the current state and
returns a dict of keys to update. Two schemas:

- FixState: the keys the fix-loop SUBGRAPH works with.
- GraphState: the parent graph's keys. It extends FixState, so when the
  compiled subgraph runs as a node it reads and writes the shared keys directly.

Why there are no reducers (like Annotated[list, operator.add]) here: when a
subgraph shares a key that has an "append" reducer, the subgraph returns the
whole list (old items plus new), and the parent appends it again, so every
item appears twice. To avoid that, nodes always return the complete new value.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict

from pydantic import BaseModel, ConfigDict, Field


# ------------------------------------------------- structured agent outputs

class Plan(BaseModel):
    """What the planner hands to the coder (Claude structured output)."""
    model_config = ConfigDict(extra="forbid")  # schema says additionalProperties: false
    root_causes: str = Field(description="What is wrong and why, citing functions and files.")
    steps: list[str] = Field(description="Ordered, concrete steps for the coder.")
    files_to_change: list[str] = Field(description="Workspace-relative paths the coder should edit.")


class Review(BaseModel):
    """The reviewer's verdict on the diff (Claude structured output)."""
    model_config = ConfigDict(extra="forbid")
    approved: bool = Field(description="True only if the change is correct and ready to merge.")
    summary: str = Field(description="One or two sentences explaining the verdict.")
    issues: list[str] = Field(description="Concrete problems to fix. Empty when approved.")


# ------------------------------------------------------------- pytest result

@dataclass
class TestResult:
    passed: bool
    exit_code: int | None  # None means pytest did not finish (e.g. timeout)
    summary: str  # e.g. "2 failed, 4 passed in 0.03s"
    output: str  # pytest output, truncated so it fits in the model's context

    __test__ = False  # stop pytest from trying to collect this class


# --------------------------------------------------------------- graph state
# Only plain JSON-like values (str, int, bool, list, dict) are stored, so the
# checkpointer can save every step.

class FixState(TypedDict, total=False):
    task: str
    workspace: str  # absolute path; nodes rebuild a Workspace from it
    plan: dict  # Plan.model_dump()
    feedback: str  # test failures or reviewer issues for the coder
    attempt: int  # coder attempts in the current round
    max_attempts: int
    tests_passed: bool
    test_summary: str
    test_output: str
    agent_runs: list[dict]  # one entry per Claude Agent SDK call
    cost_usd: float
    stop_reason: str  # set when the run must end early


class GraphState(FixState, total=False):
    round: int
    max_rounds: int
    baseline: dict[str, str]  # file contents before the run, for the diff
    reviews: list[dict]  # Review.model_dump() per round
