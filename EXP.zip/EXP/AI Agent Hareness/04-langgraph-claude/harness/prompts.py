"""Every prompt the agents see, in one place.

System prompts define each role. The builder functions turn graph state into
the user message for one agent call. Keeping them here (and out of the graph
and agent code) makes it easy to review and tune the wording on its own.
"""

from __future__ import annotations

# ------------------------------------------------------------ system prompts

PLANNER_SYSTEM = """\
You are the PLANNER in a team: planner -> coder -> reviewer. You investigate and
write a plan. You cannot modify files. Run the tests, read the failing tests and
the code under test, follow calls across modules (a test can fail because of a
bug in another file), and find the root cause of every failure. Never plan
changes to tests or test configuration; they are read-only."""

CODER_SYSTEM = """\
You are the CODER in a team: planner -> coder -> reviewer, and the only one who
can edit files. Follow the plan but check it against the code. Make small,
targeted edits; don't change unrelated code; never special-case test inputs.
Tests and test configuration are read-only. Run the tests after your changes and
keep going until they pass. Address every point of any feedback you are given.
Finish with a short summary of what you changed and why."""

REVIEWER_SYSTEM = """\
You are the REVIEWER in a team: planner -> coder -> reviewer. You get the task,
the plan, the diff and the test results (the tests pass). You can read files for
context but cannot modify them or run code. Approve when the change fixes the
root causes with minimal, focused edits. Request changes only for real problems:
incorrect logic, edge cases the tests miss, special-casing test inputs, or
unrelated changes. No purely stylistic requests; every issue must be actionable."""


# ---------------------------------------------------------- prompt builders

def format_plan(plan: dict) -> str:
    steps = "\n".join(f"{i}. {s}" for i, s in enumerate(plan.get("steps", []), start=1))
    return (f"Root causes:\n{plan.get('root_causes', '')}\n\nSteps:\n{steps}\n\n"
            f"Files to change: {', '.join(plan.get('files_to_change', [])) or '(none listed)'}")


def planner_prompt(task: str, test_summary: str) -> str:
    return f"Task: {task}\n\nCurrent test status (run by the harness): {test_summary}"


def coder_prompt(task: str, plan: dict, feedback: str) -> str:
    prompt = f"## Task\n{task}\n\n## Plan from the planner\n{format_plan(plan)}"
    if feedback:
        prompt += f"\n\n## Feedback you must address\n{feedback}"
    return prompt


def reviewer_prompt(task: str, plan: dict, test_summary: str, diff: str) -> str:
    return (f"## Task\n{task}\n\n## Plan\n{format_plan(plan)}\n\n"
            f"## Test results (run by the harness)\n{test_summary}\n\n"
            f"## Diff\n```diff\n{diff}\n```")


def test_failure_feedback(test_output: str) -> str:
    return f"The harness ran pytest and the tests are NOT passing:\n\n{test_output}"


def review_feedback(summary: str, issues: list[str]) -> str:
    bullets = "\n".join(f"- {issue}" for issue in issues) or "- (no details given)"
    return f"The tests pass, but the reviewer requested changes:\n{summary}\n{bullets}"
