"""The agents: roles, Claude Agent SDK options, and the runner.

The Claude Agent SDK is Claude Code packaged as a library. One `query()` call
runs a full agent loop with Claude Code's built-in tools. Each LangGraph node
that needs an LLM makes one `query()` call through ClaudeAgentRunner.

What the Claude Agent SDK handles:
- The agent loop (model -> tools -> model ...), context management, retries.
- The built-in tools, and the in-process MCP server for our custom tool.
- Adaptive thinking: `thinking={"type": "adaptive"}` lets Claude decide when
  and how much to think; `effort` sets how hard it tries.
- Structured output: `output_format` with a JSON schema; the validated result
  arrives as `ResultMessage.structured_output`.

What the harness handles (here and in tools.py):
- Which tools each role gets (`tools=`): no Bash, no web, no subagents.
- The sandbox hook on every tool call, and auto-approval of only safe tools.
- Isolation from your personal Claude Code setup, and per-call turn/dollar limits.
- Turning SDK messages into live events and a plain AgentResult.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from claude_agent_sdk import (
    AssistantMessage, ClaudeAgentOptions, ClaudeSDKError, HookMatcher, ResultMessage,
    TextBlock, ThinkingBlock, ToolUseBlock, query,
)
from pydantic import BaseModel, ValidationError

from harness.prompts import CODER_SYSTEM, PLANNER_SYSTEM, REVIEWER_SYSTEM
from harness.sandbox import Workspace
from harness.state import Plan, Review
from harness.tools import RUN_TESTS, STRUCTURED_OUTPUT, Emit, make_sandbox_hook, make_tools_server

DEFAULT_MODEL = "claude-opus-5-5"


# --------------------------------------------------------------------- roles

@dataclass(frozen=True)
class Role:
    name: str
    system_prompt: str
    builtin_tools: tuple[str, ...]  # Claude Code tools this role may use at all
    can_run_tests: bool
    output_model: type[BaseModel] | None = None  # Pydantic model for structured output


PLANNER = Role("Planner", PLANNER_SYSTEM, ("Read", "Glob", "Grep"), can_run_tests=True, output_model=Plan)
CODER = Role("Coder", CODER_SYSTEM, ("Read", "Glob", "Grep", "Edit", "Write"), can_run_tests=True)
REVIEWER = Role("Reviewer", REVIEWER_SYSTEM, ("Read", "Glob", "Grep"), can_run_tests=False,
                output_model=Review)


@dataclass
class AgentSettings:
    model: str = DEFAULT_MODEL
    effort: dict[str, str] = field(
        default_factory=lambda: {"Planner": "high", "Coder": "high", "Reviewer": "medium"})
    max_turns: int = 25  # Claude Code turns per agent call
    max_budget_usd: float = 2.0  # hard stop per agent call
    api_key: str | None = None  # None: use ANTHROPIC_API_KEY from the environment


@dataclass
class AgentResult:
    role: str
    text: str = ""
    structured: dict | None = None  # already validated against the role's output model
    cost_usd: float = 0.0
    num_turns: int = 0
    tool_calls: list[str] = field(default_factory=list)
    error: str = ""  # empty means success


class AgentRunner(Protocol):
    """Anything that can run a role. Tests pass a scripted runner instead of Claude."""
    async def run(self, role: Role, prompt: str, workspace: Workspace, emit: Emit) -> AgentResult: ...


# ------------------------------------------------------------------ options

def build_options(role: Role, workspace: Workspace, settings: AgentSettings,
                  emit: Emit) -> ClaudeAgentOptions:
    tools = list(role.builtin_tools)
    allowed = list(tools)
    if role.can_run_tests:
        allowed.append(RUN_TESTS)
    if role.output_model:
        # Claude Code returns structured output by calling this tool; with
        # "dontAsk" it must be pre-approved or the answer would be denied.
        allowed.append(STRUCTURED_OUTPUT)
    return ClaudeAgentOptions(
        model=settings.model,
        system_prompt=role.system_prompt,
        cwd=str(workspace.root),
        tools=tools,  # the only built-in tools that exist for this role
        allowed_tools=allowed,  # auto-approve these (no human to click "allow")
        permission_mode="dontAsk",  # deny anything not pre-approved instead of prompting
        mcp_servers={"harness": make_tools_server(workspace)} if role.can_run_tests else {},
        strict_mcp_config=True,  # ignore any MCP servers configured on this machine
        hooks={"PreToolUse": [HookMatcher(hooks=[make_sandbox_hook(workspace, emit)])]},
        setting_sources=[],  # don't load your ~/.claude settings or CLAUDE.md files
        thinking={"type": "adaptive", "display": "summarized"},  # show thinking summaries
        effort=settings.effort.get(role.name, "high"),
        output_format=({"type": "json_schema", "schema": role.output_model.model_json_schema()}
                       if role.output_model else None),
        max_turns=settings.max_turns,
        max_budget_usd=settings.max_budget_usd,
        env={"ANTHROPIC_API_KEY": settings.api_key} if settings.api_key else {},
        stderr=lambda line: emit({"kind": "cli_stderr", "text": line}),
    )


# ------------------------------------------------------------------- runner

class ClaudeAgentRunner:
    """Runs a role with the Claude Agent SDK and turns its messages into events."""

    def __init__(self, settings: AgentSettings, query_fn=query) -> None:
        self.settings = settings
        self.query_fn = query_fn  # tests can pass a fake query()

    async def run(self, role: Role, prompt: str, workspace: Workspace, emit: Emit) -> AgentResult:
        result = AgentResult(role=role.name)
        options = build_options(role, workspace, self.settings, emit)
        try:
            async for message in self.query_fn(prompt=prompt, options=options):
                if isinstance(message, AssistantMessage):
                    self._handle_assistant(message, result, emit)
                elif isinstance(message, ResultMessage):
                    self._handle_result(message, result)
        except ClaudeSDKError as exc:  # CLI not found, process crashed, bad output, ...
            result.error = f"{type(exc).__name__}: {exc}"
            return result

        if role.output_model and not result.error:
            if result.structured is None:
                result.error = "No structured output was returned."
                return result
            try:
                result.structured = role.output_model.model_validate(result.structured).model_dump()
            except ValidationError as exc:
                result.error = f"Structured output didn't match {role.output_model.__name__}: {exc}"
        return result

    @staticmethod
    def _handle_assistant(message: AssistantMessage, result: AgentResult, emit: Emit) -> None:
        if message.error:
            result.error = f"API error: {message.error}"
        for block in message.content:
            if isinstance(block, ThinkingBlock) and block.thinking.strip():
                emit({"kind": "thinking", "text": block.thinking})
            elif isinstance(block, TextBlock) and block.text.strip():
                emit({"kind": "text", "text": block.text})
            elif isinstance(block, ToolUseBlock) and block.name != STRUCTURED_OUTPUT:
                # StructuredOutput is how Claude Code delivers the answer, not a step
                # the agent chose, so it isn't shown as a tool call.
                result.tool_calls.append(block.name)
                emit({"kind": "tool", "tool": block.name, "text": _short(block.input)})

    @staticmethod
    def _handle_result(message: ResultMessage, result: AgentResult) -> None:
        result.cost_usd = message.total_cost_usd or 0.0
        result.num_turns = message.num_turns
        result.text = message.result or ""
        result.structured = message.structured_output
        if message.stop_reason == "refusal":
            result.error = "Claude declined the request (refusal)."
        elif message.is_error:
            result.error = "; ".join(message.errors or []) or message.subtype


def _short(value: Any, limit: int = 160) -> str:
    text = str(value)
    return text if len(text) <= limit else text[:limit] + "..."
