"""Graph nodes and routing functions (the conditional edges).

A NODE is a function that gets the current state and returns a dict of keys to
update. A ROUTING FUNCTION gets the state and returns the name of the next node;
graph.py attaches it with add_conditional_edges(). All of the harness's
decisions (retry? review? stop?) live in the routing functions below.

Nodes that need an LLM call one agent through the runner; nodes like `test` and
`finish` are pure harness code (pytest), so their result can't be faked by a model.
"""

from __future__ import annotations

from langgraph.config import get_stream_writer
from langgraph.graph import END

from harness.agents import CODER, PLANNER, REVIEWER, AgentResult, AgentRunner, Role
from harness.diffing import full_diff, snapshot
from harness.prompts import (
    coder_prompt, planner_prompt, review_feedback, reviewer_prompt, test_failure_feedback,
)
from harness.pytest_runner import run_pytest
from harness.sandbox import Workspace
from harness.state import FixState, GraphState

SUBGRAPH = "fix_loop"


def _test_fields(workspace: Workspace) -> dict:
    result = run_pytest(workspace)
    return {"tests_passed": result.passed, "test_summary": result.summary,
            "test_output": result.output}


class GraphNodes:
    """All nodes share one runner (real Claude, or a scripted one in tests)."""

    def __init__(self, runner: AgentRunner) -> None:
        self.runner = runner

    async def _run_agent(self, role: Role, prompt: str, state: FixState,
                         **labels) -> tuple[AgentResult, dict]:
        """Run one agent, stream its events, and return bookkeeping state updates."""
        writer = get_stream_writer()  # LangGraph "custom" stream: live events for the UI

        def emit(event: dict) -> None:
            writer({"agent": role.name, **event})

        result = await self.runner.run(role, prompt, Workspace(state["workspace"]), emit)
        record = {"role": role.name, **labels, "turns": result.num_turns,
                  "cost_usd": round(result.cost_usd, 4), "tools": len(result.tool_calls),
                  "error": result.error}
        updates = {"agent_runs": [*state.get("agent_runs", []), record],
                   "cost_usd": state.get("cost_usd", 0.0) + result.cost_usd}
        if result.error:
            updates["stop_reason"] = f"agent_error: {role.name}: {result.error}"
        return result, updates

    # ------------------------------------------------------ parent graph nodes

    def setup(self, state: GraphState) -> dict:
        workspace = Workspace(state["workspace"])
        fields = _test_fields(workspace)
        return {"baseline": snapshot(workspace), **fields,
                "round": 1, "attempt": 0, "feedback": "", "agent_runs": [],
                "cost_usd": 0.0, "reviews": [],
                "stop_reason": "already_passing" if fields["tests_passed"] else ""}

    async def plan(self, state: GraphState) -> dict:
        result, updates = await self._run_agent(
            PLANNER, planner_prompt(state["task"], state["test_summary"]), state)
        if not result.error:
            updates["plan"] = result.structured
        return updates

    async def review(self, state: GraphState) -> dict:
        diff = full_diff(state["baseline"], Workspace(state["workspace"]))
        prompt = reviewer_prompt(state["task"], state["plan"], state["test_summary"], diff)
        result, updates = await self._run_agent(REVIEWER, prompt, state, round=state["round"])
        if result.error:
            return updates
        verdict = result.structured
        updates["reviews"] = [*state.get("reviews", []), verdict]
        if verdict["approved"]:
            return {**updates, "stop_reason": "approved"}
        if state["round"] >= state["max_rounds"]:
            return {**updates, "stop_reason": "max_rounds"}
        return {**updates, "round": state["round"] + 1, "attempt": 0,
                "feedback": review_feedback(verdict["summary"], verdict["issues"])}

    def finish(self, state: GraphState) -> dict:
        fields = _test_fields(Workspace(state["workspace"]))  # the real final state
        reason = state.get("stop_reason") or "tests_failing"
        return {**fields, "stop_reason": reason}

    # ---------------------------------------------------------- subgraph nodes

    async def code(self, state: FixState) -> dict:
        attempt = state.get("attempt", 0) + 1
        prompt = coder_prompt(state["task"], state["plan"], state.get("feedback", ""))
        _, updates = await self._run_agent(CODER, prompt, state, attempt=attempt)
        return {**updates, "attempt": attempt}

    def test(self, state: FixState) -> dict:
        fields = _test_fields(Workspace(state["workspace"]))
        if not fields["tests_passed"]:
            fields["feedback"] = test_failure_feedback(fields["test_output"])
        return fields

    # ------------------------------------------------- routing (conditional edges)

    @staticmethod
    def after_setup(state: GraphState) -> str:
        """Tests already pass: nothing to fix, skip every agent call."""
        return "finish" if state.get("stop_reason") else "plan"

    @staticmethod
    def after_plan(state: GraphState) -> str:
        return "finish" if state.get("stop_reason") else SUBGRAPH

    @staticmethod
    def after_test(state: FixState) -> str:
        """Inside the subgraph: loop back to `code` while tests fail and attempts remain."""
        if state.get("stop_reason") or state.get("tests_passed"):
            return END
        return "code" if state["attempt"] < state["max_attempts"] else END

    @staticmethod
    def after_fix_loop(state: GraphState) -> str:
        if state.get("stop_reason") or not state.get("tests_passed"):
            return "finish"
        return "review"

    @staticmethod
    def after_review(state: GraphState) -> str:
        return "finish" if state.get("stop_reason") else SUBGRAPH
