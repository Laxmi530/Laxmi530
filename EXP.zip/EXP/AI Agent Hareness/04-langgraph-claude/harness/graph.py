"""The LangGraph wiring: a parent graph with a subgraph inside one of its nodes.

PARENT GRAPH                                    FIX-LOOP SUBGRAPH (node "fix_loop")

  START                                           START
    |                                               |
  setup     baseline pytest + file snapshot        code   <-- Claude Agent SDK (Coder)
    |  (tests already pass) ------> finish          |        ^
  plan      Claude Agent SDK (Planner)             test   --+ tests fail and attempts left
    |  (error) ------------------> finish           |
  fix_loop  <== the whole subgraph runs here       END    tests pass, or out of attempts
    |  (tests fail / error) -----> finish
  review    Claude Agent SDK (Reviewer)
    |  changes requested and rounds left --> back to fix_loop
  finish    final pytest + stop reason
    |
   END

Every "(...) -->" above is a CONDITIONAL EDGE: a routing function in nodes.py
reads the state and returns the next node's name.

What LangGraph handles:
- Running nodes in order and following edges; nesting a compiled graph as a node.
- Merging each node's returned dict into the shared state.
- Checkpointing (InMemorySaver): a snapshot after every step, per thread_id.
- Streaming: `astream(..., subgraphs=True)` reports events from both graphs.
- A global step limit (`recursion_limit`) so a buggy loop can't run forever.

What the harness handles: the nodes and routing rules (nodes.py), the prompts
(prompts.py), the agents and their sandbox (agents.py, tools.py).
"""

from __future__ import annotations

import uuid
from typing import Callable

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.errors import GraphRecursionError
from langgraph.graph import END, START, StateGraph

from harness.agents import AgentRunner
from harness.nodes import SUBGRAPH, GraphNodes
from harness.sandbox import Workspace
from harness.state import FixState, GraphState


def build_fix_subgraph(nodes: GraphNodes):
    """code -> test -> (code again | END). Compiled, then used as one parent node."""
    graph = StateGraph(FixState)
    graph.add_node("code", nodes.code)
    graph.add_node("test", nodes.test)
    graph.add_edge(START, "code")
    graph.add_edge("code", "test")
    graph.add_conditional_edges("test", nodes.after_test, ["code", END])
    return graph.compile()


def build_graph(runner: AgentRunner | None, checkpointer=None):
    """The parent graph. `runner=None` builds the structure only (for drawing)."""
    nodes = GraphNodes(runner)
    graph = StateGraph(GraphState)
    graph.add_node("setup", nodes.setup)
    graph.add_node("plan", nodes.plan)
    graph.add_node(SUBGRAPH, build_fix_subgraph(nodes))  # <- a whole graph as one node
    graph.add_node("review", nodes.review)
    graph.add_node("finish", nodes.finish)

    graph.add_edge(START, "setup")
    graph.add_conditional_edges("setup", nodes.after_setup, ["plan", "finish"])
    graph.add_conditional_edges("plan", nodes.after_plan, [SUBGRAPH, "finish"])
    graph.add_conditional_edges(SUBGRAPH, nodes.after_fix_loop, ["review", "finish"])
    graph.add_conditional_edges("review", nodes.after_review, [SUBGRAPH, "finish"])
    graph.add_edge("finish", END)
    return graph.compile(checkpointer=checkpointer)


def initial_state(task: str, workspace: Workspace, max_rounds: int, max_attempts: int) -> dict:
    return {"task": task, "workspace": str(workspace.root),
            "max_rounds": max_rounds, "max_attempts": max_attempts}


async def run_graph(task: str, workspace: Workspace, runner: AgentRunner,
                    max_rounds: int = 2, max_attempts: int = 3, recursion_limit: int = 60,
                    on_event: Callable[[dict], None] = print) -> tuple[dict, list[dict]]:
    """Run the whole graph, streaming events. Returns (final state, events)."""
    app = build_graph(runner, checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": str(uuid.uuid4())}, "recursion_limit": recursion_limit}
    events: list[dict] = []

    def record(event: dict) -> None:
        events.append(event)
        on_event(event)

    try:
        # subgraphs=True: also stream from inside fix_loop. Each item is
        # (namespace, mode, data); namespace is () for the parent graph and
        # ("fix_loop:<task id>",) for the subgraph.
        async for namespace, mode, data in app.astream(
                initial_state(task, workspace, max_rounds, max_attempts), config,
                stream_mode=["updates", "custom"], subgraphs=True):
            where = namespace[-1].split(":")[0] if namespace else "parent"
            if mode == "custom":
                record({"graph": where, **data})
            else:
                for node in data:
                    record({"graph": where, "kind": "node", "node": node})
    except GraphRecursionError:
        record({"graph": "parent", "kind": "stopped",
                "text": f"recursion_limit of {recursion_limit} steps reached"})
        state = (await app.aget_state(config)).values
        return {**state, "stop_reason": "recursion_limit"}, events

    return (await app.aget_state(config)).values, events
