"""Presentation helpers shared by the CLI, the UI and the notebook."""

from __future__ import annotations


def describe_event(event: dict) -> str | None:
    """One readable line per streamed event."""
    where = f"[{event.get('graph', '?')}]"
    agent = event.get("agent", "")
    text = str(event.get("text", ""))
    match event.get("kind"):
        case "node":
            return f"{where} node finished: {event['node']}"
        case "thinking":
            return f"{where} {agent} thinking: {text[:300]}"
        case "tool":
            return f"{where} {agent} -> {event['tool']} {text}"
        case "denied":
            return f"{where} {agent} DENIED {event['tool']}: {text}"
        case "text":
            return f"{where} {agent}: {text[:300]}"
        case "stopped":
            return f"{where} STOPPED: {text}"
    return None  # e.g. cli_stderr: kept in the event list, not printed


def graph_to_dot(app) -> str:
    """Graphviz DOT for a compiled graph, with each subgraph drawn as a box around its nodes."""
    drawable = app.get_graph(xray=True)  # xray: expand subgraphs into their nodes
    clusters: dict[str, list[str]] = {}
    lines = ["digraph G {", '  rankdir=TB; node [shape=box, style="rounded,filled", fillcolor="#eef"];']

    for name in drawable.nodes:
        label = name.split(":")[-1]
        shape = ', shape=oval, fillcolor="#ddd"' if label in ("__start__", "__end__") else ""
        decl = f'  "{name}" [label="{label.strip("_")}"{shape}];'
        if ":" in name:
            clusters.setdefault(name.split(":")[0], []).append(decl)
        else:
            lines.append(decl)
    for prefix, decls in clusters.items():
        lines.append(f'  subgraph "cluster_{prefix}" {{ label="subgraph: {prefix}"; '
                     'style="rounded,dashed"; color="#888";')
        lines.extend("  " + d for d in decls)
        lines.append("  }")
    for edge in drawable.edges:
        style = " [style=dashed]" if edge.conditional else ""  # dashed = conditional edge
        lines.append(f'  "{edge.source}" -> "{edge.target}"{style};')
    lines.append("}")
    return "\n".join(lines)
