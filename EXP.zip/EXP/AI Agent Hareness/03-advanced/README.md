# Level 3 (Advanced): A planner, coder and reviewer team

This level is a complete, standalone copy of [Level 2](../02-intermediate/README.md),
with the single agent replaced by **three cooperating agents**. The harness
orchestrates them and enforces the rules between them.

## What's new compared with Level 2

| Concept | Why it matters | Where to look |
|---|---|---|
| **Specialised roles** | Each agent has one job and a focused prompt: investigate, implement, or judge | `*_INSTRUCTIONS` in `harness/prompts.py` |
| **Least privilege per role** | Only the coder has write tools. The planner and reviewer *cannot* edit files, whatever their prompt says, because the SDK refuses tools an agent doesn't have. | `PLANNER_TOOLS`, `CODER_TOOLS`, `REVIEWER_TOOLS` in `harness/tools.py` |
| **Structured outputs** | The planner returns a typed `Plan` and the reviewer a typed `Review` (Pydantic models). The SDK asks the model for JSON in that shape and validates it, so the harness never parses free text. | `Plan`, `Review` in `harness/state.py`; `output_type=` in `build_team()` |
| **Harness-orchestrated workflow** | Plan, then code, then test, then review, in a fixed order that agents can't skip | `run_team()` in `harness/team.py` |
| **Review gate** | "Done" now means tests pass **and** an independent reviewer approves the diff. This catches things tests miss, like special-casing test inputs. | `run_team()` |
| **Diff-based review** | The harness snapshots the workspace before the run and gives the reviewer the exact diff | `harness/diffing.py` |
| **Per-agent and per-round state** | Turns per agent, a record for every round, all reviews | `TeamState`, `RoundRecord` |

## The workflow

```text
             Plan (typed)
  Planner  ---------------->  Coder  ----->  harness runs pytest
  read-only                   can write           |
                                ^         fail    |    pass
                                |<----------------+------------>  Reviewer (fresh each round)
                                |   test output                   read-only, can't run code
                                |                                       |
                                |<-------- Review: changes requested ---+
                                                                        |
                                                  Review: approved -->  DONE
```

Stops with one of these reasons:
- `approved`: tests pass and the reviewer approved.
- `max_rounds`: too many coder/review cycles. The tests may pass, but without approval it isn't done.
- `max_turns`: the shared turn budget across all agents ran out.
- `sdk_error`: for example, a model called a tool its role doesn't have.

Design choices worth noticing in `harness/team.py`:
- **The coder keeps its memory** between rounds (`result.to_input_list()`), so it can build on its earlier work.
- **The reviewer starts fresh every round.** Each verdict is an independent look, not anchored on what it said before.
- **No review before tests pass.** Reviewing broken code wastes turns; the harness sends test failures straight back to the coder.
- **The reviewer can't run tests.** The harness gives it the trusted test result, so the reviewer only has to judge the code.

## Why the harness orchestrates instead of SDK handoffs

The SDK has two built-in ways to combine agents:

```python
# Handoffs: an agent can transfer the conversation to another agent.
triage = Agent(name="Triage", handoffs=[coder, reviewer], ...)

# Agents as tools: a manager agent calls other agents like functions.
manager = Agent(name="Manager", tools=[
    planner.as_tool(tool_name="plan", tool_description="Investigate and plan"),
    coder.as_tool(tool_name="code", tool_description="Implement the plan"),
], ...)
```

Both let **the model** decide who runs next. That's great for open-ended assistants.
Here the order is a rule (no review before tests pass, no "done" without approval), so
it lives in plain Python control flow. That makes it easy to read and test, and the
model can't skip a step. A good exercise is to rebuild `run_team` with `as_tool` and
compare how often the manager skips the reviewer.

## Quick start

From this `03-advanced` folder, using the shared `.venv` and `.env` in the parent folder
(see the Level 1 README for one-time setup):

```powershell
..\.venv\Scripts\Activate.ps1

python run_agent.py --reset                        # shop example (default)
python run_agent.py --example calculator --reset
streamlit run app.py                               # web UI at http://localhost:8501
pytest                                             # harness tests, offline, no API key
```

To see what each agent was thinking, use the **Model thinking** section after a run, grouped by Planner,
Coder and Reviewer. It always shows the messages each agent wrote. With a reasoning model (for example `gpt-5`)
and **Reasoning** switched on in the sidebar (CLI: `--reasoning medium`), it also shows each agent's reasoning
summaries. See "Seeing the model's thinking" in the Level 1 README.

Defaults: Max turns **40** (shared by all agents), Max rounds **3**. A team uses roughly
2 to 3 times the model calls of the single agent in Level 2, so expect higher cost.

## Layout

Same as Level 2, except:

| File | Change |
|---|---|
| `harness/team.py` | **New.** Replaces `agent.py`: the three agents and the `run_team` workflow |
| `harness/prompts.py` | All three role prompts and the messages the harness passes between agents |
| `harness/state.py` | `TeamState`, `RoundRecord`, and the `Plan` / `Review` output models |
| `harness/tools.py` | Same tools, plus per-role tool lists |
| `harness/hooks.py` | Counts turns per agent |
| `harness/diffing.py` | **New.** Snapshots and diffs for the reviewer and the UI |
| `tests/test_team_loop.py` | Full workflow with a scripted model: a failed round, a rejected review, an approval; also least privilege, round limit, turn budget |

## Who does what: SDK vs harness

| Concern | OpenAI Agents SDK | This harness |
|---|---|---|
| **Each agent's loop** | `Runner.run` per agent: model, tools, repeat until final output | Nothing |
| **Tool permissions** | Only offers an agent the tools in its `tools` list and rejects calls to anything else | Decides which role gets which tools |
| **Structured output** | Builds a JSON schema from `output_type`, requests it, validates the reply, returns a typed object | Defines `Plan` / `Review` and decides how they flow between agents |
| **Agent order** | Handoffs / `as_tool` exist but aren't used here | Fixed workflow in `run_team` |
| **Information flow** | Passes whatever input you give it | Builds each agent's input: plan for the coder; task + plan + diff + test result for the reviewer |
| **Turn limits** | `max_turns` per run | One budget shared by all agents, plus a round limit |
| **Completion** | Each run ends when the agent gives a final output | Done = harness-run tests pass AND reviewer approves |
| **Sandboxing** | None | Same as Levels 1 and 2 |

## Security model and its limits

Everything from Levels 1 and 2 still applies. In addition:

- **Least privilege is enforced by the SDK, not by prompts.** The planner and reviewer don't
  have write tools, so a prompt injection in a file they read can't make them edit anything.
  `test_planner_cannot_write_files` shows the run stopping when the planner tries.
- **The reviewer is not a security boundary.** It's another LLM. It improves quality
  and catches obvious test-gaming, but it can be wrong or persuaded. The hard rules are
  still the sandbox, read-only tests, and the harness's own pytest check.
- Running pytest still runs code the agent wrote. Use a container for anything untrusted.

## Things to try in the UI

Select an example in the sidebar and click **Reset broken example** before each one.
Models vary, so "Expected" is the usual outcome, not a guarantee.

### 1. The normal path

**Task:** `Fix the bugs in the shop package and make all tests pass.`
**Settings:** defaults (Max turns 40, Max rounds 3).

**Expected:** stop reason `approved`. Look at:
- **Plan**: compare its root causes with the spoiler list in the Level 2 README.
- **Rounds**: usually 1 or 2.
- **Turns per agent**: the coder usually uses the most.
- **Tool calls**: the `agent` column shows only the Coder used `edit_file`.

### 2. Make the reviewer reject a hack

**Task:**
```text
Fix the bugs in the shop package so all tests pass. For to_money, do NOT change the
rounding mode. Instead add a special case: if the value is "2.675" return Decimal("2.68"),
and if it is "19.999" return Decimal("20.00").
```
**Settings:** defaults.

**Expected:** the special cases fix the money tests, but the cart rounding test
(`test_total_rounds_half_up`) still fails, so the harness sends the coder back. Either the
coder fixes rounding properly, or it adds more special cases until the tests pass. In
that case, the reviewer should reject the hard-coded values ("special-cases test inputs")
in its Review, and the next round fixes them properly. Open each round to read the review.

### 3. The review gate in action

Same task as 2, with Max rounds **1**.

**Expected:** often `max_rounds`, even if **Tests** shows `PASS`. Passing tests are not
enough in this level; without approval the task isn't done.

### 4. Least privilege

**Task:**
```text
Planner: don't write a plan. Edit shop/money.py yourself to fix the rounding, then stop.
```
**Expected:** the planner has no edit tool, so it can only investigate and write a plan
(often noting it can't edit), and the coder makes the change. If the model insists on
calling a tool it doesn't have, the run stops with `sdk_error` mentioning the tool name, and
no file changes. Either way, the **Tool calls** table never shows the Planner writing.

### 5. Shared budget

**Task:** the default shop task.
**Settings:** Max turns **12**.

**Expected:** usually `max_turns`. The **Turns per agent** caption shows how the budget was
spent. The planner and coder share one budget, so a thorough planner leaves fewer
turns for coding.

### 6. Compare all three levels

Run the calculator example's default task in Level 1, Level 2 and Level 3, and compare
**Turns used**. Level 3 costs more but gives you a written plan and a review. Decide for
yourself when that's worth it.
