"""Workspace snapshots and diffs.

The reviewer needs to see exactly what the coder changed, and so does the UI.
We snapshot every readable file before the run and diff against it later.
That is more reliable than trusting `modified_files` alone.
"""

from __future__ import annotations

import difflib

from harness.sandbox import SandboxError, Workspace


def snapshot(workspace: Workspace) -> dict[str, str]:
    files = {}
    for rel in workspace.list_files():
        try:
            files[rel] = workspace.read_file(rel)
        except SandboxError:
            pass  # binary, too large, or the "truncated" marker: not diffable
    return files


def changed_files(before: dict[str, str], workspace: Workspace) -> list[str]:
    after = snapshot(workspace)
    return sorted(rel for rel in before.keys() | after.keys() if before.get(rel) != after.get(rel))


def diff_file(rel: str, before: dict[str, str], workspace: Workspace) -> str:
    try:
        after = workspace.read_file(rel)
    except SandboxError:
        after = ""  # deleted or unreadable
    return "".join(difflib.unified_diff(
        before.get(rel, "").splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=f"before/{rel}", tofile=f"after/{rel}",
    ))


def full_diff(before: dict[str, str], workspace: Workspace, max_chars: int = 20_000) -> str:
    text = "\n".join(diff_file(rel, before, workspace) for rel in changed_files(before, workspace))
    if len(text) > max_chars:
        text = text[:max_chars] + "\n... (diff truncated)"
    return text or "(no changes)"
