"""Run state tracked by the harness, plus the structured messages agents exchange.

As in Levels 1 and 2, the SDK just hands this object to every tool and hook via
RunContextWrapper.context. It's never sent to the model.

New in Level 3:
- Plan and Review are Pydantic models used as the planner's and reviewer's
  `output_type`. The SDK turns them into a JSON schema, asks the model for
  structured output, and validates the reply, so the harness gets typed
  objects instead of free text it would have to parse.
- State is tracked per agent and per round.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from harness.sandbox import Workspace


# ------------------------------------------------- structured agent outputs

class Plan(BaseModel):
    """What the planner hands to the coder."""
    root_causes: str = Field(description="What is wrong and why, citing functions and files.")
    steps: list[str] = Field(description="Ordered, concrete steps for the coder.")
    files_to_change: list[str] = Field(description="Workspace-relative paths the coder should edit.")


class Review(BaseModel):
    """The reviewer's verdict on the coder's diff."""
    approved: bool = Field(description="True only if the change is correct and ready to merge.")
    summary: str = Field(description="One or two sentences explaining the verdict.")
    issues: list[str] = Field(description="Concrete problems to fix. Empty when approved.")


# ------------------------------------------------------------- harness state

@dataclass
class TestResult:
    passed: bool
    exit_code: int | None  # None means pytest did not finish (e.g. timeout)
    summary: str  # e.g. "2 failed, 4 passed in 0.03s"
    output: str  # pytest output, truncated so it fits in the model's context

    __test__ = False  # stop pytest from trying to collect this class


@dataclass
class ToolCallRecord:
    turn: int
    agent: str
    name: str
    args: dict
    ok: bool
    note: str = ""


@dataclass
class ThoughtRecord:
    turn: int
    agent: str
    kind: str  # "reasoning" (summary from a reasoning model) or "message" (text the model wrote)
    text: str


@dataclass
class RoundRecord:
    """One coder -> tests -> (reviewer) cycle."""
    number: int
    coder_summary: str = ""
    tests: TestResult | None = None
    review: Review | None = None  # None when tests failed, so no review happened


@dataclass
class TeamState:
    workspace: Workspace
    baseline: dict[str, str] = field(default_factory=dict)  # file contents before the run
    phase: str = ""  # name of the agent currently running
    turns: int = 0  # total model calls across all agents
    turns_by_agent: Counter = field(default_factory=Counter)
    tool_calls: list[ToolCallRecord] = field(default_factory=list)
    thoughts: list[ThoughtRecord] = field(default_factory=list)
    modified_files: set[str] = field(default_factory=set)
    latest_test_result: TestResult | None = None
    plan: Plan | None = None
    rounds: list[RoundRecord] = field(default_factory=list)
    stop_reason: str = "not_started"

    @property
    def reviews(self) -> list[Review]:
        return [r.review for r in self.rounds if r.review is not None]

    def record_tool(self, name: str, args: dict, ok: bool, note: str = "") -> None:
        self.tool_calls.append(ToolCallRecord(self.turns, self.phase, name, args, ok, note))
