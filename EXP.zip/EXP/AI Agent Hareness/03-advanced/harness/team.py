"""A three-agent team (planner, coder, reviewer) orchestrated by the harness.

Same nested loops as before, with more agents:

INNER LOOPS (owned by the SDK): each agent runs inside its own Runner.run(),
calling tools until it produces a final output. For the planner and reviewer
that output is a typed Plan / Review object (structured output); for the
coder it's a text summary.

OUTER WORKFLOW (owned by us, in run_team):

    planner ---Plan---> coder ---> harness runs pytest
                          ^            |
                          |   fail     v   pass
                          +-- test failures       reviewer ---Review--->  approved? -> done
                          +-- reviewer's issues <------------------------ not approved

    Done = tests pass AND the reviewer approves. The workflow stops early if
    the shared turn budget or the maximum number of rounds runs out.

Why the harness orchestrates instead of letting agents hand off to each other:
the SDK also supports handoffs (one agent passes control to another) and
agents-as-tools (a manager agent calls others like functions). Those let the
model choose the order. Here the order is fixed and must be enforced (no review
before tests pass, no "done" without review), so plain Python control flow is
simpler to read, test and trust. The README shows the handoff alternative.
"""

from __future__ import annotations

from typing import Callable

from agents import (
    Agent, AgentsException, MaxTurnsExceeded, Model, ModelSettings, RunResult, Runner,
)
from openai.types.shared import Reasoning

from harness.diffing import full_diff, snapshot
from harness.hooks import HarnessHooks
from harness.prompts import (
    CODER_INSTRUCTIONS, PLANNER_INSTRUCTIONS, REVIEWER_INSTRUCTIONS, coder_task, review_feedback,
    review_request, tests_failing_feedback,
)
from harness.pytest_runner import run_pytest
from harness.sandbox import Workspace
from harness.state import Plan, Review, RoundRecord, TeamState, TestResult
from harness.tools import CODER_TOOLS, PLANNER_TOOLS, REVIEWER_TOOLS

PLANNER = "Planner"
CODER = "Coder"
REVIEWER = "Reviewer"


def build_team(model: str | Model,
               reasoning_effort: str | None = None) -> tuple[Agent, Agent, Agent]:
    """`model` is a model name like "gpt-4.1", or a Model object (tests use a fake one).

    `reasoning_effort` ("low" / "medium" / "high") turns on reasoning with
    readable summaries for all three agents. Only reasoning models (e.g. gpt-5,
    o4-mini) accept it; gpt-4.1 rejects the request, so it's off by default.
    """
    reasoning = Reasoning(effort=reasoning_effort, summary="auto") if reasoning_effort else None
    settings = ModelSettings(parallel_tool_calls=False, reasoning=reasoning)
    planner = Agent[TeamState](name=PLANNER, instructions=PLANNER_INSTRUCTIONS,
                               tools=PLANNER_TOOLS, output_type=Plan,
                               model=model, model_settings=settings)
    coder = Agent[TeamState](name=CODER, instructions=CODER_INSTRUCTIONS,
                             tools=CODER_TOOLS, model=model, model_settings=settings)
    reviewer = Agent[TeamState](name=REVIEWER, instructions=REVIEWER_INSTRUCTIONS,
                                tools=REVIEWER_TOOLS, output_type=Review,
                                model=model, model_settings=settings)
    return planner, coder, reviewer


def verify(state: TeamState) -> TestResult:
    """Completion check run by the harness, independent of any agent."""
    result = run_pytest(state.workspace)
    state.latest_test_result = result
    return result


async def run_team(task: str, workspace: Workspace, model: str | Model,
                   max_turns: int = 40, max_rounds: int = 3,
                   log: Callable[[str], None] = print,
                   reasoning_effort: str | None = None) -> TeamState:
    state = TeamState(workspace=workspace, baseline=snapshot(workspace))
    planner, coder, reviewer = build_team(model, reasoning_effort)
    hooks = HarnessHooks(log)

    async def run(agent: Agent, agent_input: str | list) -> RunResult:
        """Run one agent within whatever is left of the shared turn budget."""
        turns_left = max_turns - state.turns
        if turns_left <= 0:
            raise MaxTurnsExceeded("Shared turn budget used up")
        state.phase = agent.name
        log(f"===== {agent.name} ({turns_left} turns left) =====")
        return await Runner.run(agent, agent_input, context=state,
                                max_turns=turns_left, hooks=hooks)

    try:
        # 1. PLAN: read-only investigation, typed Plan output.
        state.plan = (await run(planner, f"Task: {task}")).final_output

        coder_input: str | list = coder_task(task, state.plan)
        for number in range(1, max_rounds + 1):
            round_ = RoundRecord(number)
            state.rounds.append(round_)

            # 2. CODE: the only agent with write access. Its conversation
            #    history carries over between rounds, so it remembers its work.
            result = await run(coder, coder_input)
            round_.coder_summary = str(result.final_output)

            # 3. TEST: the harness checks; no agent's claim is trusted.
            round_.tests = verify(state)
            if not round_.tests.passed:
                log(f"[harness] round {number}: tests fail ({round_.tests.summary})")
                feedback = tests_failing_feedback(round_.tests.output)
            else:
                # 4. REVIEW: a fresh reviewer every round (no memory of earlier
                #    rounds), so each verdict is an independent look at the diff.
                request = review_request(task, state.plan, round_.tests.summary,
                                         full_diff(state.baseline, state.workspace))
                review: Review = (await run(reviewer, request)).final_output
                round_.review = review
                verdict = "approved" if review.approved else "changes requested"
                log(f"[harness] round {number}: reviewer {verdict}")
                if review.approved:
                    state.stop_reason = "approved"
                    return state
                feedback = review_feedback(review.summary, review.issues)

            coder_input = result.to_input_list() + [{"role": "user", "content": feedback}]

        state.stop_reason = "max_rounds"
    except MaxTurnsExceeded:
        state.stop_reason = "max_turns"
    except AgentsException as exc:
        # e.g. a model called a tool its role doesn't have, or returned output
        # that doesn't match the Plan/Review schema.
        state.stop_reason = f"sdk_error: {exc}"

    # Stopped without approval: record the real final state of the tests.
    verify(state)
    return state
