"""Lifecycle hooks: the SDK calls these as each agent's loop runs.

New in Level 3: the hook receives the agent, so we can count turns and
collect thinking per agent as well as in total.
"""

from __future__ import annotations

from typing import Any, Callable

from agents import Agent, ModelResponse, RunContextWrapper, RunHooks

from harness.state import TeamState, ThoughtRecord


def _preview(text: str, limit: int = 120) -> str:
    first_line = str(text).strip().splitlines()[0] if str(text).strip() else ""
    return first_line if len(first_line) <= limit else first_line[:limit] + "..."


def extract_thoughts(output_items: list[Any]) -> list[tuple[str, str]]:
    """(kind, text) pairs from one model response.

    - "reasoning": summaries from a reasoning model (e.g. gpt-5, o4-mini), only
      when reasoning summaries are switched on. Non-reasoning models like
      gpt-4.1 never produce these.
    - "message": text the model wrote, such as "Let me check calculator.py"
      before a tool call, or its final answer (for the planner and reviewer,
      that's the JSON of their Plan / Review).
    """
    thoughts = []
    for item in output_items:
        kind = getattr(item, "type", None)
        if kind == "reasoning":
            text = "\n\n".join(part.text for part in item.summary if part.text)
        elif kind == "message":
            text = "".join(getattr(part, "text", "") for part in item.content)
        else:
            continue
        if text.strip():
            thoughts.append((kind, text.strip()))
    return thoughts


class HarnessHooks(RunHooks[TeamState]):
    def __init__(self, log: Callable[[str], None] = print) -> None:
        self.log = log

    async def on_llm_start(self, context: RunContextWrapper[TeamState], agent: Agent,
                           system_prompt: str | None, input_items: list[Any]) -> None:
        state = context.context
        state.turns += 1
        state.turns_by_agent[agent.name] += 1
        self.log(f"--- turn {state.turns} ({agent.name}) ---")

    async def on_llm_end(self, context: RunContextWrapper[TeamState], agent: Agent,
                         response: ModelResponse) -> None:
        state = context.context
        for kind, text in extract_thoughts(response.output):
            state.thoughts.append(ThoughtRecord(state.turns, agent.name, kind, text))
            self.log(f"  [{kind}] {_preview(text, 200)}")

    async def on_tool_start(self, context: RunContextWrapper[TeamState], agent: Agent,
                            tool: Any) -> None:
        self.log(f"  -> {tool.name}")

    async def on_tool_end(self, context: RunContextWrapper[TeamState], agent: Agent,
                          tool: Any, result: object) -> None:
        self.log(f"  <- {_preview(str(result))}")
