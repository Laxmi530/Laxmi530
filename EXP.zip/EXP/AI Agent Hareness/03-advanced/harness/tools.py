"""The tools the model can call: thin SDK adapters over the harness logic.

What the SDK does for us here (via @function_tool):
- Builds the JSON schema the model sees from the type hints and docstring.
- Parses and validates the model's JSON arguments.
- Calls our function and sends the returned string back to the model.
- Leaves the RunContextWrapper parameter out of the schema and fills it in
  itself; it's how we reach our TeamState.

What WE do here:
- Decide which capabilities exist at all (no shell, no network, no delete),
  and which agent role gets which tools (see the lists at the bottom).
- Route every path through the Workspace sandbox.
- Record every call, the agent that made it, and modified files in TeamState.
- Turn sandbox and file-system errors into readable "ERROR: ..." strings so
  the model can correct itself instead of the run crashing.
"""

from __future__ import annotations

from typing import Callable

from agents import RunContextWrapper, function_tool

from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError
from harness.state import TeamState

Ctx = RunContextWrapper[TeamState]


def _call(ctx: Ctx, name: str, args: dict, action: Callable[[], str]) -> str:
    """Run one tool action, record it in state, and report errors to the model."""
    state = ctx.context
    try:
        result = action()
    except (SandboxError, OSError) as exc:
        state.record_tool(name, args, ok=False, note=str(exc))
        return f"ERROR: {exc}"
    state.record_tool(name, args, ok=True)
    return result


@function_tool
def list_files(ctx: Ctx, directory: str) -> str:
    """List all files in the workspace, recursively.

    Args:
        directory: Folder relative to the workspace root. Use "." for the whole workspace.
    """
    def action() -> str:
        files = ctx.context.workspace.list_files(directory)
        return "\n".join(files) if files else "(no files)"

    return _call(ctx, "list_files", {"directory": directory}, action)


@function_tool
def read_file(ctx: Ctx, path: str, start_line: int, end_line: int) -> str:
    """Read lines from a UTF-8 text file. Each line is prefixed with "NN| " (not part of the file).

    Args:
        path: File path relative to the workspace root, e.g. "shop/cart.py".
        start_line: First line to read, starting at 1. Use 1 to read from the top.
        end_line: Last line to read (inclusive). Use 0 to read to the end of the file.
    """
    return _call(ctx, "read_file", {"path": path, "start_line": start_line, "end_line": end_line},
                 lambda: ctx.context.workspace.read_lines(path, start_line, end_line))


@function_tool
def search_code(ctx: Ctx, query: str, directory: str) -> str:
    """Find lines containing some text (plain text, case-insensitive) across files.

    Use it to find where a function is defined or used, e.g. query "def to_money" or "to_money(".

    Args:
        query: Text to look for. Not a regex.
        directory: Folder to search, relative to the workspace root. Use "." for everything.
    """
    def action() -> str:
        matches = ctx.context.workspace.search(query, directory)
        return "\n".join(matches) if matches else f"No matches for {query!r}."

    return _call(ctx, "search_code", {"query": query, "directory": directory}, action)


@function_tool
def edit_file(ctx: Ctx, path: str, old_text: str, new_text: str) -> str:
    """Replace one exact, unique snippet of text in an existing file.

    Args:
        path: File path relative to the workspace root.
        old_text: Exact text to replace, including indentation but without the "NN| "
            line-number prefixes from read_file. Must appear exactly once.
        new_text: Replacement text.
    """
    def action() -> str:
        rel = ctx.context.workspace.edit_file(path, old_text, new_text)
        ctx.context.modified_files.add(rel)
        return f"Edited {rel}."

    return _call(ctx, "edit_file", {"path": path, "old_text": old_text, "new_text": new_text}, action)


@function_tool
def write_file(ctx: Ctx, path: str, content: str) -> str:
    """Create a new file or completely overwrite an existing one. Prefer edit_file for small changes.

    Args:
        path: File path relative to the workspace root.
        content: The full new file content.
    """
    def action() -> str:
        rel = ctx.context.workspace.write_file(path, content)
        ctx.context.modified_files.add(rel)
        return f"Wrote {len(content)} characters to {rel}."

    return _call(ctx, "write_file", {"path": path, "chars": len(content)}, action)


@function_tool
def run_tests(ctx: Ctx, test_path: str) -> str:
    """Run pytest in the workspace and return the results.

    Args:
        test_path: A test file or folder relative to the workspace root, or "" to run all tests.
    """
    def action() -> str:
        result = run_pytest(ctx.context.workspace, test_path or None)
        ctx.context.latest_test_result = result
        status = "PASSED" if result.passed else "FAILED"
        return f"{status} (exit code {result.exit_code}): {result.summary}\n\n{result.output}"

    return _call(ctx, "run_tests", {"test_path": test_path}, action)


# Least privilege per role. An agent can only call tools in its own list. If a
# model asks for any other tool, the SDK refuses, so the planner and reviewer
# physically cannot change files, whatever their prompt says.
PLANNER_TOOLS = [list_files, search_code, read_file, run_tests]
CODER_TOOLS = [list_files, search_code, read_file, edit_file, write_file, run_tests]
REVIEWER_TOOLS = [list_files, search_code, read_file]
