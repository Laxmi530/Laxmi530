"""Streamlit web UI for the planner/coder/reviewer team (Level 3: Advanced).

Run with:
    streamlit run app.py

The UI is only a front end. It calls the same run_team() as the CLI, so the
sandbox, turn budget, roles and completion rule are exactly the same.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import streamlit as st
from agents import set_default_openai_key

from harness.diffing import changed_files, diff_file
from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError
from harness.state import TeamState
from harness.team import CODER, PLANNER, REVIEWER, run_team
from harness.workspace_setup import EXAMPLES, default_workspace, load_env, prepare_workspace

load_env()
st.set_page_config(page_title="Mini Coding Agent Team", layout="wide")


# ----------------------------------------------------------------- results

def show_results(run: dict) -> None:
    state: TeamState = run["state"]
    workspace = state.workspace  # the one this run used, even if the sidebar changed since
    tests = state.latest_test_result
    passed = bool(tests and tests.passed)

    st.divider()
    st.subheader("Result")
    cols = st.columns(6)
    cols[0].metric("Stop reason", state.stop_reason.split(":")[0])
    cols[1].metric("Rounds", len(state.rounds))
    cols[2].metric("Turns used", state.turns)
    cols[3].metric("Tool calls", len(state.tool_calls))
    cols[4].metric("Rejected by sandbox", sum(not c.ok for c in state.tool_calls))
    cols[5].metric("Tests", "PASS" if passed else "FAIL")
    st.caption("Turns per agent: " + " | ".join(
        f"{name}: {state.turns_by_agent.get(name, 0)}" for name in (PLANNER, CODER, REVIEWER)))
    if tests:
        (st.success if passed else st.error)(f"Harness check: {tests.summary}")
    if state.stop_reason == "approved":
        st.success("The reviewer approved the change.")
    elif state.stop_reason.startswith("sdk_error"):
        st.warning(state.stop_reason)

    # Plan: the planner's typed output, shown field by field.
    st.markdown("### 1. Plan")
    if state.plan:
        st.markdown(f"**Root causes:** {state.plan.root_causes}")
        st.markdown("\n".join(f"{i}. {s}" for i, s in enumerate(state.plan.steps, start=1)))
        st.caption("Files to change: " + (", ".join(state.plan.files_to_change) or "(none listed)"))
    else:
        st.info("The planner did not produce a plan.")

    # Rounds: coder -> tests -> reviewer.
    st.markdown("### 2. Rounds")
    for r in state.rounds:
        test_label = r.tests.summary if r.tests else "not run"
        verdict = ("approved" if r.review and r.review.approved
                   else "changes requested" if r.review else "no review (tests failed)")
        with st.expander(f"Round {r.number}: tests {test_label}, {verdict}",
                         expanded=r is state.rounds[-1]):
            st.markdown("**Coder's summary**")
            st.markdown(r.coder_summary or "_(none)_")
            if r.review:
                show = st.success if r.review.approved else st.warning
                show(f"Reviewer: {r.review.summary}")
                for issue in r.review.issues:
                    st.markdown(f"- {issue}")

    st.markdown("### Model thinking")
    reasoning = [t for t in state.thoughts if t.kind == "reasoning"]
    note = ("" if reasoning else " No reasoning summaries: they need a reasoning model (e.g. gpt-5, "
            "o4-mini) and **Reasoning** switched on in the sidebar.")
    st.caption(f"{len(reasoning)} reasoning summaries, {len(state.thoughts) - len(reasoning)} "
               f"messages the agents wrote.{note}")
    for agent in (PLANNER, CODER, REVIEWER):
        mine = [t for t in state.thoughts if t.agent == agent]
        if not mine:
            continue
        st.markdown(f"**{agent}**")
        for t in mine:
            label = "Reasoning summary" if t.kind == "reasoning" else "Message"
            with st.expander(f"{agent}, turn {t.turn}: {label}", expanded=t.kind == "reasoning"):
                st.markdown(t.text)

    st.markdown("### 3. Changes")
    files = changed_files(state.baseline, workspace)
    st.caption(f"{len(files)} file(s) changed compared with before the run")
    for rel in files:
        with st.expander(rel, expanded=True):
            st.code(diff_file(rel, state.baseline, workspace), language="diff")

    st.markdown("### 4. Tool calls")
    st.dataframe(
        [{"turn": c.turn, "agent": c.agent, "tool": c.name, "ok": c.ok,
          "args": ", ".join(f"{k}={str(v)[:60]!r}" for k, v in c.args.items()),
          "error": c.note} for c in state.tool_calls],
        width="stretch", hide_index=True,
    )

    with st.expander("Trace"):
        st.code("\n".join(run["log"]) or "(empty)", language=None)
    if tests:
        with st.expander("Final pytest output"):
            st.code(tests.output, language=None)


# ----------------------------------------------------------------- sidebar

with st.sidebar:
    st.header("Settings")
    env_key = os.getenv("OPENAI_API_KEY", "")
    typed_key = st.text_input(
        "OpenAI API key", type="password", key="api_key",
        placeholder="Loaded from .env" if env_key else "sk-...",
        help="Kept in memory for this session only. Leave empty to use .env.",
    )
    api_key = typed_key or env_key
    model = st.text_input("Model", os.getenv("OPENAI_MODEL", "gpt-4.1"))
    reasoning_choice = st.selectbox(
        "Reasoning", ["off", "low", "medium", "high"], key="reasoning",
        help="Shows each agent's reasoning summaries. Only for reasoning models such as gpt-5 "
             "or o4-mini; gpt-4.1 returns an error when this is on.")
    max_turns = int(st.number_input("Max turns (shared by all agents)", 1, 200, 40))
    max_rounds = int(st.number_input("Max rounds", 1, 10, 3,
                                     help="Coder -> tests -> reviewer cycles before giving up."))
    example = st.selectbox("Example project", list(EXAMPLES), key="example",
                           help="shop: 4 modules, 5 bugs, 23 tests. calculator: the Level 1 example.")
    # Widget keys include the example, so switching examples switches the
    # workspace and task defaults too (Streamlit keeps one value per key).
    workspace_path = st.text_input("Workspace folder", str(default_workspace(example)),
                                   key=f"workspace_{example}")
    reset = st.button("Reset broken example", key="reset",
                      help=f"Copies examples/{example} into the workspace (overwrites those files).")

ws_path = Path(workspace_path)
if not reset and not ws_path.exists() and ws_path.resolve() != default_workspace(example):
    # Don't create folders as a side effect of typing a path.
    st.info(f"`{ws_path}` does not exist. Click **Reset broken example** "
            "to create it with the example files.")
    st.stop()

try:
    workspace = prepare_workspace(ws_path, example=example, reset=reset)
except SandboxError as exc:
    st.error(str(exc))
    st.stop()

if reset:
    st.session_state.pop("last_run", None)
    st.sidebar.success("Example restored.")


# -------------------------------------------------------------------- main

st.title("Mini Coding Agent Harness: Level 3 (Advanced)")
st.caption(f"Planner -> Coder -> Reviewer | Example: `{example}` | Workspace: `{workspace.root}`")

tab_run, tab_files = st.tabs(["Run team", "Workspace files"])

with tab_run:
    task = st.text_area("Task", EXAMPLES[example], height=80, key=f"task_{example}")
    col_run, col_tests, _ = st.columns([1, 1, 4])
    run_clicked = col_run.button("Run team", type="primary", disabled=not api_key, key="run")
    tests_clicked = col_tests.button("Run tests only", key="run_tests",
                                     help="Run pytest in the workspace without the agents.")
    if not api_key:
        st.info("Add an OpenAI API key in the sidebar (or in .env) to run the team.")

    if tests_clicked:
        result = run_pytest(workspace)
        (st.success if result.passed else st.error)(result.summary)
        st.code(result.output, language=None)

    if run_clicked:
        set_default_openai_key(api_key)  # in memory only, never written to disk
        lines: list[str] = []
        with st.status("Team running... (interacting with the page will stop it)",
                       expanded=True) as status:
            live = st.empty()

            def log(line: str) -> None:
                lines.append(line)
                live.code("\n".join(lines), language=None)

            try:
                state = asyncio.run(run_team(
                    task, workspace, model, max_turns=max_turns, max_rounds=max_rounds, log=log,
                    reasoning_effort=None if reasoning_choice == "off" else reasoning_choice))
            except Exception as exc:  # API key, network, model-name errors, ...
                status.update(label=f"Run failed: {type(exc).__name__}", state="error")
                st.exception(exc)
                st.session_state.pop("last_run", None)
            else:
                ok = state.stop_reason == "approved"
                status.update(label=f"Finished: {state.stop_reason}",
                              state="complete" if ok else "error", expanded=False)
                st.session_state["last_run"] = {"state": state, "log": lines}

    if "last_run" in st.session_state:
        show_results(st.session_state["last_run"])

with tab_files:
    listing = workspace.list_files()
    files = [f for f in listing if not f.startswith("... (truncated")]
    if not files:
        st.info("The workspace is empty.")
    else:
        if len(files) < len(listing):
            st.caption(f"Showing the first {len(files)} files.")
        rel = st.selectbox("File", files)
        try:
            if workspace.is_read_only(workspace.resolve(rel)):
                st.caption("Read-only for the agents")
            st.code(workspace.read_file(rel), language="python" if rel.endswith(".py") else None,
                    line_numbers=True)
        except SandboxError as exc:
            st.warning(str(exc))
