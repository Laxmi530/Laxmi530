"""End-to-end tests of the planner -> coder -> reviewer workflow with a scripted fake model.

The real SDK Runner drives every agent and runs our real tools and hooks; only
the LLM is replaced. One script serves all three agents because they run one
after another.
"""

import asyncio
import itertools
import json

import pytest
from agents import Model, ModelResponse, Usage, set_tracing_disabled
from openai.types.responses import (
    ResponseFunctionToolCall, ResponseOutputMessage, ResponseOutputText, ResponseReasoningItem,
)
from openai.types.responses.response_reasoning_item import Summary

from harness.team import run_team
from harness.workspace_setup import prepare_workspace
from tests.test_pytest_runner import FIXED_CALCULATOR

PLAN = {"root_causes": "subtract, divide and average are wrong in calculator.py.",
        "steps": ["Fix subtract", "Fix divide", "Fix average"],
        "files_to_change": ["calculator.py"]}


class ScriptedModel(Model):
    """Returns one pre-written response per model call, in order."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = 0

    async def get_response(self, *args, **kwargs):
        self.calls += 1
        step = self.script.pop(0) if self.script else tool_call("run_tests", test_path="")
        output = step if isinstance(step, list) else [step]  # a list = several items in one response
        return ModelResponse(output=output, usage=Usage(), response_id=None)

    def stream_response(self, *args, **kwargs):
        raise NotImplementedError


_call_ids = itertools.count(1)


def tool_call(name, **args):
    return ResponseFunctionToolCall(type="function_call", name=name, arguments=json.dumps(args),
                                    call_id=f"call_{next(_call_ids)}", status="completed")


def say(text):
    if not isinstance(text, str):
        text = json.dumps(text)  # structured output (Plan / Review) arrives as JSON text
    return ResponseOutputMessage(
        type="message", id="msg", role="assistant", status="completed",
        content=[ResponseOutputText(type="output_text", text=text, annotations=[])],
    )


def reason(text):
    """A reasoning item with a summary, as a reasoning model returns it."""
    return ResponseReasoningItem(id="rs", type="reasoning",
                                 summary=[Summary(type="summary_text", text=text)])


@pytest.fixture(autouse=True)
def no_tracing():
    set_tracing_disabled(True)


@pytest.fixture
def calc_ws(tmp_path):
    return prepare_workspace(tmp_path / "ws", example="calculator")


def test_full_workflow_with_test_failure_and_rejected_review(calc_ws):
    model = ScriptedModel([
        # Planner: investigates, then returns a typed Plan.
        tool_call("run_tests", test_path=""),
        say(PLAN),
        # Round 1, coder: fixes one bug only and claims success.
        tool_call("edit_file", path="calculator.py", old_text="return b - a", new_text="return a - b"),
        say("Fixed subtract."),
        # (harness: tests still fail, so no review; feedback goes back to the coder)
        # Round 2, coder: fixes everything.
        tool_call("write_file", path="calculator.py", content=FIXED_CALCULATOR),
        say("Fixed all three functions."),
        # (harness: tests pass, so the reviewer runs)
        tool_call("read_file", path="calculator.py", start_line=1, end_line=0),
        say({"approved": False, "summary": "average needs a clearer error message.",
             "issues": ["Use a more descriptive ValueError message in average()."]}),
        # Round 3, coder: addresses the review.
        tool_call("edit_file", path="calculator.py",
                  old_text="Cannot average an empty list", new_text="average() needs at least one number"),
        say("Improved the error message."),
        # Reviewer (fresh): approves.
        say({"approved": True, "summary": "Correct and minimal.", "issues": []}),
    ])

    state = asyncio.run(run_team("Fix calculator.py", calc_ws, model, max_turns=40, max_rounds=3))

    assert state.stop_reason == "approved"
    assert state.plan.files_to_change == ["calculator.py"]  # typed object, not text
    assert len(state.rounds) == 3
    assert state.rounds[0].review is None and not state.rounds[0].tests.passed
    assert [r.approved for r in state.reviews] == [False, True]
    assert state.turns == model.calls == 11
    assert dict(state.turns_by_agent) == {"Planner": 2, "Coder": 6, "Reviewer": 3}
    assert {c.agent for c in state.tool_calls if c.name in ("edit_file", "write_file")} == {"Coder"}
    assert state.latest_test_result.passed
    assert "average() needs at least one number" in calc_ws.read_file("calculator.py")


def test_thinking_is_recorded_per_agent(calc_ws):
    model = ScriptedModel([
        [reason("Check which tests fail before planning."), tool_call("run_tests", test_path="")],
        say(PLAN),
        [reason("The plan says rewrite all three functions."),
         tool_call("write_file", path="calculator.py", content=FIXED_CALCULATOR)],
        say("Fixed all three functions."),
        [reason("The diff is minimal and correct."),
         say({"approved": True, "summary": "Correct.", "issues": []})],
    ])

    state = asyncio.run(run_team("Fix calculator.py", calc_ws, model, max_rounds=1))

    assert state.stop_reason == "approved"
    reasoning = [(t.agent, t.text) for t in state.thoughts if t.kind == "reasoning"]
    assert reasoning == [("Planner", "Check which tests fail before planning."),
                         ("Coder", "The plan says rewrite all three functions."),
                         ("Reviewer", "The diff is minimal and correct.")]
    assert ("Coder", "Fixed all three functions.") in [
        (t.agent, t.text) for t in state.thoughts if t.kind == "message"]


def test_planner_cannot_write_files(calc_ws):
    original = calc_ws.read_file("calculator.py")
    model = ScriptedModel([
        tool_call("write_file", path="calculator.py", content="hacked = True\n"),
    ])

    state = asyncio.run(run_team("Fix calculator.py", calc_ws, model))

    assert state.stop_reason.startswith("sdk_error")
    assert "write_file" in state.stop_reason
    assert calc_ws.read_file("calculator.py") == original


def test_rounds_limit_stops_endless_review_cycles(calc_ws):
    reject = say({"approved": False, "summary": "Not convinced.", "issues": ["Try again."]})
    model = ScriptedModel(
        [say(PLAN), tool_call("write_file", path="calculator.py", content=FIXED_CALCULATOR),
         say("Done."), reject, say("Done again."), reject]
    )

    state = asyncio.run(run_team("Fix calculator.py", calc_ws, model, max_rounds=2))

    assert state.stop_reason == "max_rounds"
    assert len(state.reviews) == 2
    assert state.latest_test_result.passed  # tests pass, but no approval means not done


def test_shared_turn_budget_is_enforced(calc_ws):
    model = ScriptedModel([])  # planner never finishes: keeps calling run_tests

    state = asyncio.run(run_team("Fix calculator.py", calc_ws, model, max_turns=3))

    assert state.stop_reason == "max_turns"
    assert state.turns == 3
    assert state.plan is None
