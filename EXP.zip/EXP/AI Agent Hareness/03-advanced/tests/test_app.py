"""Headless smoke test of the Streamlit UI (no browser, no API key)."""

from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

from harness.workspace_setup import prepare_workspace  # noqa: E402

APP = str(Path(__file__).resolve().parents[1] / "app.py")


@pytest.fixture
def app(tmp_path):
    ws = prepare_workspace(tmp_path / "ws", example="shop")
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    at.text_input(key="workspace_shop").set_value(str(ws.root)).run()
    return at


def test_app_renders_without_errors(app):
    assert not app.exception
    assert app.title[0].value == "Mini Coding Agent Harness: Level 3 (Advanced)"


def test_run_tests_button_shows_failing_shop_example(app):
    app.button(key="run_tests").click().run()
    assert not app.exception
    assert any("13 failed" in e.value for e in app.error)


def test_run_button_executes_the_team_and_shows_results(app, monkeypatch):
    """Clicks "Run team" with the real workflow, only the LLM is scripted."""
    import harness.team
    from agents import set_tracing_disabled

    from tests.test_shop_example import FIXES
    from tests.test_team_loop import ScriptedModel, reason, say, tool_call

    set_tracing_disabled(True)
    real_run_team = harness.team.run_team
    plan = {"root_causes": "Rounding in money.py and four other bugs.",
            "steps": ["Fix money", "Fix catalog", "Fix discounts", "Fix cart"],
            "files_to_change": ["shop/money.py"]}
    script = ([[reason("Money rounding looks wrong."), say(plan)]]
              + [tool_call("edit_file", path=p, old_text=old, new_text=new) for p, old, new in FIXES]
              + [say("Fixed 5 bugs."), say({"approved": True, "summary": "Looks right.", "issues": []})])

    async def scripted_run_team(task, workspace, model, **kwargs):
        return await real_run_team(task, workspace, ScriptedModel(script), **kwargs)

    monkeypatch.setattr(harness.team, "run_team", scripted_run_team)
    app.text_input(key="api_key").set_value("sk-test-not-used").run()
    app.button(key="run").click().run()

    assert not app.exception
    assert "approved" in [m.value for m in app.metric]
    assert any("Rounding in money.py" in m.value for m in app.markdown)  # the plan
    assert any("Looks right." in s.value for s in app.success)  # the review
    assert any("ROUND_HALF_UP" in c.value for c in app.code)  # the diff
    assert len(app.dataframe) == 1  # the tool-call table
    assert "Planner, turn 1: Reasoning summary" in [e.label for e in app.expander]  # thinking


def test_switching_example_switches_task_and_workspace(app):
    app.selectbox(key="example").select("calculator").run()
    assert not app.exception
    assert "calculator.py" in app.text_area(key="task_calculator").value
    assert app.text_input(key="workspace_calculator").value.endswith("calculator")


def test_typing_a_missing_folder_does_not_create_it(app, tmp_path):
    missing = tmp_path / "typo"
    app.text_input(key="workspace_shop").set_value(str(missing)).run()
    assert not app.exception
    assert not missing.exists()


def test_workspace_containing_the_harness_is_refused(app):
    project_root = str(Path(APP).parent)
    app.text_input(key="workspace_shop").set_value(project_root).run()
    assert any("must not contain the harness" in e.value for e in app.error)
