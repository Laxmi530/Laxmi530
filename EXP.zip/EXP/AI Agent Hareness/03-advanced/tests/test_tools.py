"""Check what each agent will actually see: tools, argument schemas and output types."""

from harness.state import Plan, Review
from harness.team import build_team

WRITE_TOOLS = {"edit_file", "write_file"}


def tool_names(agent):
    return {t.name for t in agent.tools}


def test_only_the_coder_can_write():
    planner, coder, reviewer = build_team("gpt-4.1")
    assert WRITE_TOOLS <= tool_names(coder)
    assert not WRITE_TOOLS & tool_names(planner)
    assert not WRITE_TOOLS & tool_names(reviewer)


def test_reviewer_cannot_run_code():
    _, _, reviewer = build_team("gpt-4.1")
    assert tool_names(reviewer) == {"list_files", "search_code", "read_file"}


def test_planner_and_reviewer_return_typed_outputs():
    planner, coder, reviewer = build_team("gpt-4.1")
    assert planner.output_type is Plan
    assert reviewer.output_type is Review
    assert coder.output_type is None  # free-text summary


def test_reasoning_is_off_by_default_and_applies_to_every_agent_when_on():
    assert all(a.model_settings.reasoning is None for a in build_team("gpt-4.1"))
    for agent in build_team("gpt-5", reasoning_effort="high"):
        assert (agent.model_settings.reasoning.effort, agent.model_settings.reasoning.summary) == (
            "high", "auto")


def test_context_parameter_is_hidden_from_the_model():
    for agent in build_team("gpt-4.1"):
        for tool in agent.tools:
            assert "ctx" not in tool.params_json_schema["properties"]
            assert tool.params_json_schema.get("additionalProperties") is False
