from harness.diffing import changed_files, full_diff, snapshot
from harness.sandbox import Workspace


def test_diff_reports_edited_and_new_files(tmp_path):
    (tmp_path / "a.py").write_text("x = 1\n", encoding="utf-8")
    ws = Workspace(tmp_path)
    before = snapshot(ws)

    ws.write_file("a.py", "x = 2\n")
    ws.write_file("b.py", "y = 1\n")

    assert changed_files(before, ws) == ["a.py", "b.py"]
    diff = full_diff(before, ws)
    assert "-x = 1" in diff and "+x = 2" in diff and "+y = 1" in diff


def test_no_changes(tmp_path):
    (tmp_path / "a.py").write_text("x = 1\n", encoding="utf-8")
    ws = Workspace(tmp_path)
    assert full_diff(snapshot(ws), ws) == "(no changes)"
