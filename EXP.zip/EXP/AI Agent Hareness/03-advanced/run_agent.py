"""Command-line entry point for the planner/coder/reviewer team. For the web UI, see app.py.

Examples:
    python run_agent.py --reset
    python run_agent.py --example calculator --reset
    python run_agent.py --reset --max-rounds 2 "Fix the bugs in the shop package."
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

from harness.sandbox import SandboxError
from harness.state import TeamState
from harness.prompts import format_plan
from harness.team import run_team
from harness.workspace_setup import (
    DEFAULT_EXAMPLE, EXAMPLES, default_workspace, load_env, prepare_workspace,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run the planner/coder/reviewer team on a workspace.")
    p.add_argument("task", nargs="?", default=None,
                   help="What the team should do (default: the example's standard task).")
    p.add_argument("--example", choices=list(EXAMPLES), default=DEFAULT_EXAMPLE,
                   help="Which broken example project to use (default: shop).")
    p.add_argument("--workspace", default=None,
                   help="Folder the agents are confined to (default: ./workspace/<example>).")
    p.add_argument("--reset", action="store_true",
                   help="Copy the broken example into the workspace first.")
    p.add_argument("--model", default=None, help="Model name (default: $OPENAI_MODEL or gpt-4.1).")
    p.add_argument("--max-turns", type=int, default=40,
                   help="Total model calls allowed, shared by all three agents.")
    p.add_argument("--max-rounds", type=int, default=3,
                   help="Coder -> tests -> reviewer cycles before giving up.")
    p.add_argument("--reasoning", choices=["low", "medium", "high"], default=None,
                   help="Show reasoning summaries. Needs a reasoning model, e.g. --model gpt-5.")
    return p.parse_args()


def print_report(state: TeamState) -> None:
    print("\n" + "=" * 60)
    print(f"Stop reason:    {state.stop_reason}")
    print(f"Rounds:         {len(state.rounds)}")
    per_agent = ", ".join(f"{name} {n}" for name, n in state.turns_by_agent.items())
    print(f"Turns used:     {state.turns} ({per_agent})")
    print(f"Tool calls:     {len(state.tool_calls)} "
          f"({sum(not c.ok for c in state.tool_calls)} rejected by the sandbox)")
    print(f"Modified files: {', '.join(sorted(state.modified_files)) or '(none)'}")
    if state.latest_test_result:
        print(f"Tests:          {state.latest_test_result.summary}")
    reasoning = sum(t.kind == "reasoning" for t in state.thoughts)
    print(f"Thinking:       {reasoning} reasoning summaries, {len(state.thoughts) - reasoning} messages")
    if state.plan:
        print(f"\nPlan:\n{format_plan(state.plan)}")
    for r in state.rounds:
        print(f"\nRound {r.number}: tests {r.tests.summary if r.tests else '(not run)'}")
        if r.review:
            print(f"  Reviewer: {'APPROVED' if r.review.approved else 'CHANGES REQUESTED'}: "
                  f"{r.review.summary}")
            for issue in r.review.issues:
                print(f"    - {issue}")


def main() -> int:
    load_env()
    args = parse_args()
    if not os.getenv("OPENAI_API_KEY"):
        print("OPENAI_API_KEY is not set. Copy .env.example to .env and add your key.")
        return 2

    model = args.model or os.getenv("OPENAI_MODEL", "gpt-4.1")
    task = args.task or EXAMPLES[args.example]
    try:
        workspace = prepare_workspace(args.workspace or default_workspace(args.example),
                                      example=args.example, reset=args.reset)
    except SandboxError as exc:
        print(exc)
        return 2
    print(f"Workspace: {workspace.root}\nModel: {model}\nTask: {task}")

    state = asyncio.run(run_team(task, workspace, model,
                                 max_turns=args.max_turns, max_rounds=args.max_rounds,
                                 reasoning_effort=args.reasoning))
    print_report(state)
    return 0 if state.stop_reason == "approved" else 1


if __name__ == "__main__":
    sys.exit(main())
