"""Tests for the workspace sandbox. These run offline, no API key needed."""

import os

import pytest

from harness.sandbox import SandboxError, Workspace


@pytest.fixture
def ws(tmp_path):
    (tmp_path / "app.py").write_text("x = 1\ny = 2\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_app.py").write_text("def test(): pass\n", encoding="utf-8")
    (tmp_path / ".env").write_text("SECRET=1\n", encoding="utf-8")
    return Workspace(tmp_path)


@pytest.mark.parametrize(
    "bad_path",
    [
        "../outside.txt",
        "sub/../../outside.txt",
        "..\\outside.txt",
        "/etc/passwd",
        "C:\\Windows\\win.ini",
        "C:relative.txt",
        "app.py:hidden_stream",
        "",
        ".env",
        "sub/.git/config",
        "conftest.py.",
        "conftest.py ",
        "tests./test_app.py",
    ],
)
def test_rejects_unsafe_paths(ws, bad_path):
    with pytest.raises(SandboxError):
        ws.resolve(bad_path)


def test_rejects_symlink_escape(ws, tmp_path_factory):
    outside = tmp_path_factory.mktemp("outside") / "secret.txt"
    outside.write_text("secret", encoding="utf-8")
    try:
        os.symlink(outside, ws.root / "link.txt")
    except (OSError, NotImplementedError):
        pytest.skip("Creating symlinks is not permitted on this machine")
    with pytest.raises(SandboxError, match="escapes"):
        ws.read_file("link.txt")
    assert "link.txt" not in ws.list_files()


def test_list_files_hides_hidden_files_and_folders(ws):
    (ws.root / ".venv" / "lib").mkdir(parents=True)
    (ws.root / ".venv" / "lib" / "big.py").write_text("", encoding="utf-8")
    (ws.root / "__pycache__").mkdir()
    (ws.root / "__pycache__" / "app.cpython-312.pyc").write_bytes(b"")
    assert ws.list_files() == ["app.py", "tests/test_app.py"]


def test_read_file(ws):
    assert ws.read_file("app.py") == "x = 1\ny = 2\n"


@pytest.mark.parametrize("path", ["tests/test_app.py", "Tests/test_app.py", "conftest.py", "pytest.ini"])
def test_tests_and_config_are_read_only(ws, path):
    with pytest.raises(SandboxError, match="read-only"):
        ws.write_file(path, "def test(): assert True\n")


def test_write_creates_file_in_subfolder(ws):
    assert ws.write_file("pkg/new.py", "z = 3\n") == "pkg/new.py"
    assert ws.read_file("pkg/new.py") == "z = 3\n"


def test_edit_replaces_unique_match(ws):
    ws.edit_file("app.py", "y = 2", "y = 20")
    assert ws.read_file("app.py") == "x = 1\ny = 20\n"


def test_edit_rejects_missing_match(ws):
    with pytest.raises(SandboxError, match="not found"):
        ws.edit_file("app.py", "nope", "x")


def test_edit_rejects_ambiguous_match(ws):
    with pytest.raises(SandboxError, match="2 times"):
        ws.edit_file("app.py", " = ", " == ")
