"""Check what the model will actually see: tool names and argument schemas."""

from harness.agent import build_agent


def test_agent_exposes_only_the_expected_tools():
    agent = build_agent("gpt-4.1")
    assert sorted(t.name for t in agent.tools) == [
        "edit_file", "list_files", "read_file", "run_tests", "write_file",
    ]


def test_reasoning_is_off_by_default_and_requests_summaries_when_on():
    assert build_agent("gpt-4.1").model_settings.reasoning is None
    reasoning = build_agent("gpt-5", reasoning_effort="medium").model_settings.reasoning
    assert (reasoning.effort, reasoning.summary) == ("medium", "auto")


def test_context_parameter_is_hidden_from_the_model():
    agent = build_agent("gpt-4.1")
    for tool in agent.tools:
        props = tool.params_json_schema["properties"]
        assert "ctx" not in props
        assert tool.params_json_schema.get("additionalProperties") is False
