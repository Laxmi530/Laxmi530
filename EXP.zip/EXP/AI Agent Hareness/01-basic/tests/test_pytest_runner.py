"""Tests for the restricted pytest runner. These run offline, no API key needed."""

import shutil
from pathlib import Path

import pytest

from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError, Workspace

EXAMPLE = Path(__file__).resolve().parents[1] / "examples" / "calculator"

FIXED_CALCULATOR = '''
def add(a, b): return a + b
def subtract(a, b): return a - b
def multiply(a, b): return a * b
def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
def average(numbers):
    if not numbers:
        raise ValueError("Cannot average an empty list")
    return sum(numbers) / len(numbers)
'''


@pytest.fixture
def calc_ws(tmp_path):
    shutil.copytree(EXAMPLE, tmp_path, dirs_exist_ok=True)
    return Workspace(tmp_path)


def test_broken_example_fails(calc_ws):
    result = run_pytest(calc_ws)
    assert not result.passed
    assert result.exit_code == 1
    assert "failed" in result.summary


def test_fixed_example_passes(calc_ws):
    calc_ws.write_file("calculator.py", FIXED_CALCULATOR)
    result = run_pytest(calc_ws)
    assert result.passed, result.output
    assert "7 passed" in result.summary


def test_secrets_are_not_visible_to_tests(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-should-not-leak")
    (tmp_path / "test_env.py").write_text(
        "import os\n"
        "def test_no_key():\n"
        "    assert 'OPENAI_API_KEY' not in os.environ\n",
        encoding="utf-8",
    )
    result = run_pytest(Workspace(tmp_path))
    assert result.passed, result.output


def test_fake_pytest_module_in_workspace_is_ignored(calc_ws):
    calc_ws.write_file("pytest.py", "print('7 passed in 0.01s')\n")
    assert not run_pytest(calc_ws).passed


def test_exiting_early_with_code_zero_is_not_a_pass(calc_ws):
    calc_ws.write_file("calculator.py", "import os\nos._exit(0)\n")
    result = run_pytest(calc_ws)
    assert result.exit_code == 0
    assert not result.passed


def test_test_path_must_stay_in_workspace(calc_ws):
    with pytest.raises(SandboxError):
        run_pytest(calc_ws, "../somewhere")
