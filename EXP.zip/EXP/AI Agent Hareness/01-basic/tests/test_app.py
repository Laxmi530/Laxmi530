"""Headless smoke test of the Streamlit UI (no browser, no API key)."""

from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

from harness.workspace_setup import prepare_workspace  # noqa: E402

APP = str(Path(__file__).resolve().parents[1] / "app.py")


@pytest.fixture
def app(tmp_path):
    ws = prepare_workspace(tmp_path / "ws")
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    at.text_input(key="workspace").set_value(str(ws.root)).run()
    return at


def test_app_renders_without_errors(app):
    assert not app.exception
    assert app.title[0].value == "Mini Coding Agent Harness: Level 1 (Basic)"


def test_run_tests_button_shows_failing_example(app):
    app.button(key="run_tests").click().run()
    assert not app.exception
    assert any("5 failed" in e.value for e in app.error)


def test_run_button_executes_the_loop_and_shows_results(app, monkeypatch):
    """Clicks "Run agent" with the real harness loop, only the LLM is scripted."""
    import harness.agent
    from agents import set_tracing_disabled

    from tests.test_agent_loop import ScriptedModel, reason, say, tool_call
    from tests.test_pytest_runner import FIXED_CALCULATOR

    set_tracing_disabled(True)
    real_run_task = harness.agent.run_task
    script = [[reason("Run the tests to see which functions fail."), tool_call("run_tests", test_path="")],
              tool_call("write_file", path="calculator.py", content=FIXED_CALCULATOR),
              say("Fixed all three bugs.")]

    async def scripted_run_task(task, workspace, model, **kwargs):
        return await real_run_task(task, workspace, ScriptedModel(script), **kwargs)

    monkeypatch.setattr(harness.agent, "run_task", scripted_run_task)
    app.text_input(key="api_key").set_value("sk-test-not-used").run()
    app.button(key="run").click().run()

    assert not app.exception
    assert "tests_passed" in [m.value for m in app.metric]
    assert any("7 passed" in s.value for s in app.success)
    assert any("return a - b" in c.value for c in app.code)  # the diff
    assert len(app.dataframe) == 1  # the tool-call table
    labels = [e.label for e in app.expander]
    assert "Turn 1: Reasoning summary" in labels  # the model's thinking
    assert "Turn 3: Message" in labels


def test_typing_a_missing_folder_does_not_create_it(app, tmp_path):
    missing = tmp_path / "typo"
    app.text_input(key="workspace").set_value(str(missing)).run()
    assert not app.exception
    assert not missing.exists()
    assert any("does not exist" in i.value for i in app.info)


def test_workspace_containing_the_harness_is_refused(app):
    project_root = str(Path(APP).parent)
    app.text_input(key="workspace").set_value(project_root).run()
    assert any("must not contain the harness" in e.value for e in app.error)
