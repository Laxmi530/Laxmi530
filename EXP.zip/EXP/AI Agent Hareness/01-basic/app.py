"""Streamlit web UI for the mini coding agent.

Run with:
    streamlit run app.py

The UI is only a front end. It calls the same run_task() as the CLI, so the
sandbox, turn budget and completion rule are exactly the same.
"""

from __future__ import annotations

import asyncio
import difflib
import os
from pathlib import Path

import streamlit as st
from agents import set_default_openai_key
from harness.agent import run_task
from harness.pytest_runner import run_pytest
from harness.sandbox import SandboxError, Workspace
from harness.state import HarnessState
from harness.workspace_setup import DEFAULT_TASK, DEFAULT_WORKSPACE, load_env, prepare_workspace

load_env()
st.set_page_config(page_title="Mini Coding Agent", layout="wide")


# ----------------------------------------------------------------- helpers

def snapshot(workspace: Workspace) -> dict[str, str]:
    """Contents of every readable file, so we can diff after the run."""
    files = {}
    for rel in workspace.list_files():
        try:
            files[rel] = workspace.read_file(rel)
        except SandboxError:
            pass  # e.g. binary or too large; just not diffable
    return files


def diff_file(rel: str, before: dict[str, str], workspace: Workspace) -> str:
    try:
        after = workspace.read_file(rel)
    except SandboxError:
        after = ""
    return "".join(difflib.unified_diff(
        before.get(rel, "").splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=f"before/{rel}", tofile=f"after/{rel}",
    )) or "(no textual changes)"


def show_thinking(thoughts: list) -> None:
    reasoning = [t for t in thoughts if t.kind == "reasoning"]
    st.markdown("**Model thinking**")
    note = ("" if reasoning else " No reasoning summaries: they need a reasoning model (e.g. gpt-5, "
            "o4-mini) and **Reasoning** switched on in the sidebar.")
    st.caption(f"{len(reasoning)} reasoning summaries, {len(thoughts) - len(reasoning)} messages "
               f"the model wrote between tool calls.{note}")
    for t in thoughts:
        label = "Reasoning summary" if t.kind == "reasoning" else "Message"
        with st.expander(f"Turn {t.turn}: {label}", expanded=t.kind == "reasoning"):
            st.markdown(t.text)


def show_results(run: dict) -> None:
    state: HarnessState = run["state"]
    workspace = state.workspace  # the one this run used, even if the sidebar changed since
    tests = state.latest_test_result
    passed = bool(tests and tests.passed)

    st.divider()
    st.subheader("Result")
    cols = st.columns(5)
    cols[0].metric("Stop reason", state.stop_reason.split(":")[0])
    cols[1].metric("Turns used", state.turns)
    cols[2].metric("Tool calls", len(state.tool_calls))
    cols[3].metric("Rejected by sandbox", sum(not c.ok for c in state.tool_calls))
    cols[4].metric("Tests", "PASS" if passed else "FAIL")
    if tests:
        (st.success if passed else st.error)(f"Harness check: {tests.summary}")
    if state.stop_reason.startswith("sdk_error"):
        st.warning(state.stop_reason)

    st.markdown("**Agent's final message**")
    st.markdown(state.final_message or "_(no final message)_")

    show_thinking(state.thoughts)

    st.markdown(f"**Changes** ({len(state.modified_files)} file(s) modified)")
    for rel in sorted(state.modified_files):
        with st.expander(rel, expanded=True):
            st.code(diff_file(rel, run["before"], workspace), language="diff")

    st.markdown("**Tool calls**")
    st.dataframe(
        [{"turn": c.turn, "tool": c.name, "ok": c.ok,
          "args": ", ".join(f"{k}={str(v)[:60]!r}" for k, v in c.args.items()),
          "error": c.note} for c in state.tool_calls],
        width="stretch", hide_index=True,
    )

    with st.expander("Trace"):
        st.code("\n".join(run["log"]) or "(empty)", language=None)
    if tests:
        with st.expander("Final pytest output"):
            st.code(tests.output, language=None)


# ----------------------------------------------------------------- sidebar

with st.sidebar:
    st.header("Settings")
    env_key = os.getenv("OPENAI_API_KEY", "")
    typed_key = st.text_input(
        "OpenAI API key", type="password", key="api_key",
        placeholder="Loaded from .env" if env_key else "sk-...",
        help="Kept in memory for this session only. Leave empty to use .env.",
    )
    api_key = typed_key or env_key
    model = st.text_input("Model", os.getenv("OPENAI_MODEL", "gpt-4.1"))
    reasoning = st.selectbox(
        "Reasoning", ["off", "low", "medium", "high"], key="reasoning",
        help="Shows the model's reasoning summaries. Only for reasoning models such as gpt-5 "
             "or o4-mini; gpt-4.1 returns an error when this is on.")
    max_turns = int(st.number_input("Max turns (total model calls)", 1, 100, 20))
    max_attempts = int(st.number_input("Max attempts", 1, 10, 3,
                                       help="Retries after the model says it's done but tests fail."))
    workspace_path = st.text_input("Workspace folder", str(DEFAULT_WORKSPACE), key="workspace")
    reset = st.button("Reset broken calculator example", key="reset",
                      help="Copies examples/calculator into the workspace (overwrites those files).")

ws_path = Path(workspace_path)
if not reset and not ws_path.exists() and ws_path.resolve() != DEFAULT_WORKSPACE:
    # Don't create folders as a side effect of typing a path.
    st.info(f"`{ws_path}` does not exist. Click **Reset broken calculator example** "
            "to create it with the example files.")
    st.stop()

try:
    workspace = prepare_workspace(ws_path, reset=reset)
except SandboxError as exc:
    st.error(str(exc))
    st.stop()

if reset:
    st.session_state.pop("last_run", None)
    st.sidebar.success("Example restored.")


# -------------------------------------------------------------------- main

st.title("Mini Coding Agent Harness: Level 1 (Basic)")
st.caption(f"Workspace: `{workspace.root}`")

tab_run, tab_files = st.tabs(["Run agent", "Workspace files"])

with tab_run:
    task = st.text_area("Task", DEFAULT_TASK, height=80)
    col_run, col_tests, _ = st.columns([1, 1, 4])
    run_clicked = col_run.button("Run agent", type="primary", disabled=not api_key, key="run")
    tests_clicked = col_tests.button("Run tests only", key="run_tests",
                                     help="Run pytest in the workspace without the agent.")
    if not api_key:
        st.info("Add an OpenAI API key in the sidebar (or in .env) to run the agent.")

    if tests_clicked:
        result = run_pytest(workspace)
        (st.success if result.passed else st.error)(result.summary)
        st.code(result.output, language=None)

    if run_clicked:
        set_default_openai_key(api_key)  # in memory only, never written to disk
        before = snapshot(workspace)
        lines: list[str] = []
        with st.status("Agent running... (interacting with the page will stop it)",
                       expanded=True) as status:
            live = st.empty()

            def log(line: str) -> None:
                lines.append(line)
                live.code("\n".join(lines), language=None)

            try:
                state = asyncio.run(run_task(
                    task, workspace, model, max_turns=max_turns, max_attempts=max_attempts, log=log,
                    reasoning_effort=None if reasoning == "off" else reasoning))
            except Exception as exc:  # API key, network, model-name errors, ...
                status.update(label=f"Run failed: {type(exc).__name__}", state="error")
                st.exception(exc)
                st.session_state.pop("last_run", None)
            else:
                ok = state.stop_reason == "tests_passed"
                status.update(label=f"Finished: {state.stop_reason}",
                              state="complete" if ok else "error", expanded=False)
                st.session_state["last_run"] = {"state": state, "log": lines, "before": before}

    if "last_run" in st.session_state:
        show_results(st.session_state["last_run"])

with tab_files:
    listing = workspace.list_files()
    files = [f for f in listing if not f.startswith("... (truncated")]
    if not files:
        st.info("The workspace is empty.")
    else:
        if len(files) < len(listing):
            st.caption(f"Showing the first {len(files)} files.")
        rel = st.selectbox("File", files)
        try:
            if workspace.is_read_only(workspace.resolve(rel)):
                st.caption("Read-only for the agent")
            st.code(workspace.read_file(rel), language="python" if rel.endswith(".py") else None,
                    line_numbers=True)
        except SandboxError as exc:
            st.warning(str(exc))
