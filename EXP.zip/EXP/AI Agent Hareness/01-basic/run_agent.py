"""Command-line entry point. For the web UI, see app.py.

Example:
    python run_agent.py --reset "Fix the bug in calculator.py and make all tests pass."
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

from harness.agent import run_task
from harness.sandbox import SandboxError
from harness.state import HarnessState
from harness.workspace_setup import DEFAULT_TASK, DEFAULT_WORKSPACE, load_env, prepare_workspace


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run the mini coding agent on a workspace.")
    p.add_argument("task", nargs="?", default=DEFAULT_TASK, help="What the agent should do.")
    p.add_argument("--workspace", default=str(DEFAULT_WORKSPACE),
                   help="Folder the agent is confined to (default: ./workspace).")
    p.add_argument("--reset", action="store_true",
                   help="Copy the broken calculator example into the workspace first.")
    p.add_argument("--model", default=None, help="Model name (default: $OPENAI_MODEL or gpt-4.1).")
    p.add_argument("--max-turns", type=int, default=20, help="Total model calls allowed.")
    p.add_argument("--max-attempts", type=int, default=3,
                   help="How many times the harness lets the model try again after a failed check.")
    p.add_argument("--reasoning", choices=["low", "medium", "high"], default=None,
                   help="Show reasoning summaries. Needs a reasoning model, e.g. --model gpt-5.")
    return p.parse_args()


def print_report(state: HarnessState) -> None:
    print("\n" + "=" * 60)
    print(f"Stop reason:    {state.stop_reason}")
    print(f"Turns used:     {state.turns}")
    print(f"Tool calls:     {len(state.tool_calls)} "
          f"({sum(not c.ok for c in state.tool_calls)} rejected by the sandbox)")
    print(f"Modified files: {', '.join(sorted(state.modified_files)) or '(none)'}")
    if state.latest_test_result:
        print(f"Tests:          {state.latest_test_result.summary}")
    reasoning = sum(t.kind == "reasoning" for t in state.thoughts)
    print(f"Thinking:       {reasoning} reasoning summaries, {len(state.thoughts) - reasoning} messages")
    if state.final_message:
        print(f"\nAgent's final message:\n{state.final_message}")


def main() -> int:
    load_env()
    args = parse_args()
    if not os.getenv("OPENAI_API_KEY"):
        print("OPENAI_API_KEY is not set. Copy .env.example to .env and add your key.")
        return 2

    model = args.model or os.getenv("OPENAI_MODEL", "gpt-4.1")
    try:
        workspace = prepare_workspace(args.workspace, args.reset)
    except SandboxError as exc:
        print(exc)
        return 2
    print(f"Workspace: {workspace.root}\nModel: {model}\nTask: {args.task}")

    state = asyncio.run(run_task(args.task, workspace, model,
                                 max_turns=args.max_turns, max_attempts=args.max_attempts,
                                 reasoning_effort=args.reasoning))
    print_report(state)
    return 0 if state.stop_reason == "tests_passed" else 1


if __name__ == "__main__":
    sys.exit(main())
