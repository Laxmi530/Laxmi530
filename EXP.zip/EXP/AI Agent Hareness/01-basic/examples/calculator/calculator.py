"""A tiny calculator with a few deliberate bugs for the agent to fix."""


def add(a: float, b: float) -> float:
    return a + b


def subtract(a: float, b: float) -> float:
    return b - a


def multiply(a: float, b: float) -> float:
    return a * b


def divide(a: float, b: float) -> float:
    """Divide a by b. Raises ValueError when b is zero."""
    return a // b


def average(numbers: list[float]) -> float:
    """Return the mean of a non-empty list. Raises ValueError when empty."""
    return sum(numbers) / (len(numbers) - 1)
