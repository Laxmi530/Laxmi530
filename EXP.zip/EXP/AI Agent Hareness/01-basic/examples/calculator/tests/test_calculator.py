import pytest

from calculator import add, average, divide, multiply, subtract


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(10, 4) == 6


def test_multiply():
    assert multiply(3, 4) == 12


def test_divide():
    assert divide(7, 2) == 3.5


def test_divide_by_zero_raises_value_error():
    with pytest.raises(ValueError):
        divide(1, 0)


def test_average():
    assert average([2, 4, 6]) == 4


def test_average_of_empty_list_raises_value_error():
    with pytest.raises(ValueError):
        average([])
