"""Lifecycle hooks: the SDK calls these as the agent loop runs.

The SDK owns the loop; hooks are how the harness watches it without
reimplementing it. We use them to count turns, collect what the model was
thinking, and emit a live trace.
"""

from __future__ import annotations

from typing import Any, Callable

from agents import Agent, ModelResponse, RunContextWrapper, RunHooks

from harness.state import HarnessState, ThoughtRecord


def _preview(text: str, limit: int = 120) -> str:
    first_line = str(text).strip().splitlines()[0] if str(text).strip() else ""
    return first_line if len(first_line) <= limit else first_line[:limit] + "..."


def extract_thoughts(output_items: list[Any]) -> list[tuple[str, str]]:
    """(kind, text) pairs from one model response.

    - "reasoning": summaries from a reasoning model (e.g. gpt-5, o4-mini), only
      when reasoning summaries are switched on. Non-reasoning models like
      gpt-4.1 never produce these.
    - "message": text the model wrote, such as "Let me check calculator.py"
      before a tool call, or its final answer.
    """
    thoughts = []
    for item in output_items:
        kind = getattr(item, "type", None)
        if kind == "reasoning":
            text = "\n\n".join(part.text for part in item.summary if part.text)
        elif kind == "message":
            text = "".join(getattr(part, "text", "") for part in item.content)
        else:
            continue
        if text.strip():
            thoughts.append((kind, text.strip()))
    return thoughts


class HarnessHooks(RunHooks[HarnessState]):
    def __init__(self, log: Callable[[str], None] = print) -> None:
        # The CLI prints the trace; the web UI passes a function that shows it on the page.
        self.log = log

    async def on_llm_start(self, context: RunContextWrapper[HarnessState], agent: Agent,
                           system_prompt: str | None, input_items: list[Any]) -> None:
        # One model call = one "turn". The SDK enforces max_turns per
        # Runner.run(); we count turns across all runs to enforce a total budget.
        context.context.turns += 1
        self.log(f"--- turn {context.context.turns} ---")

    async def on_llm_end(self, context: RunContextWrapper[HarnessState], agent: Agent,
                         response: ModelResponse) -> None:
        state = context.context
        for kind, text in extract_thoughts(response.output):
            state.thoughts.append(ThoughtRecord(state.turns, kind, text))
            self.log(f"  [{kind}] {_preview(text, 200)}")

    async def on_tool_start(self, context: RunContextWrapper[HarnessState], agent: Agent,
                            tool: Any) -> None:
        self.log(f"  -> {tool.name}")

    async def on_tool_end(self, context: RunContextWrapper[HarnessState], agent: Agent,
                          tool: Any, result: object) -> None:
        self.log(f"  <- {_preview(str(result))}")
