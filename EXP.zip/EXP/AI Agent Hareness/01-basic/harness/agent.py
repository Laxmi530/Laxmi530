"""The agent definition and the harness's outer loop.

Two loops are nested here; telling them apart is the main lesson:

INNER LOOP (owned by the SDK, inside Runner.run):
    call model -> model asks for tools -> SDK runs tools -> results go back
    to the model -> repeat, until the model replies with plain text and no
    tool calls ("final output"), or max_turns is hit (MaxTurnsExceeded).

OUTER LOOP (owned by us, in run_task):
    The SDK considers the run "done" as soon as the model stops calling tools.
    That is not our definition of done. Ours is: pytest passes, checked by the
    harness itself and not by trusting what the model says. If tests still
    fail, we send the failure back as a new user message and run again, within
    a total turn budget and a maximum number of attempts.
"""

from __future__ import annotations

from typing import Callable

from agents import Agent, AgentsException, MaxTurnsExceeded, Model, ModelSettings, Runner
from openai.types.shared import Reasoning

from harness.hooks import HarnessHooks
from harness.prompts import INSTRUCTIONS, tests_failing_feedback
from harness.pytest_runner import run_pytest
from harness.sandbox import Workspace
from harness.state import HarnessState, TestResult
from harness.tools import ALL_TOOLS


def build_agent(model: str | Model, reasoning_effort: str | None = None) -> Agent[HarnessState]:
    """`model` is a model name like "gpt-4.1", or a Model object (tests use a fake one).

    `reasoning_effort` ("low" / "medium" / "high") turns on reasoning with
    readable summaries. Only reasoning models (e.g. gpt-5, o4-mini) accept it;
    other models such as gpt-4.1 reject the request, so it's off by default.
    """
    reasoning = Reasoning(effort=reasoning_effort, summary="auto") if reasoning_effort else None
    return Agent[HarnessState](
        name="Coding agent",
        instructions=INSTRUCTIONS,
        tools=ALL_TOOLS,
        model=model,
        # One tool call at a time keeps the trace easy to follow and avoids two
        # edits to the same file racing each other.
        model_settings=ModelSettings(parallel_tool_calls=False, reasoning=reasoning),
    )


def verify(state: HarnessState) -> TestResult:
    """Completion check run by the harness, independent of the model."""
    result = run_pytest(state.workspace)
    state.latest_test_result = result
    return result


async def run_task(task: str, workspace: Workspace, model: str | Model,
                   max_turns: int = 20, max_attempts: int = 3,
                   log: Callable[[str], None] = print,
                   reasoning_effort: str | None = None) -> HarnessState:
    state = HarnessState(workspace=workspace)
    agent = build_agent(model, reasoning_effort)
    hooks = HarnessHooks(log)
    conversation: str | list = task

    for attempt in range(1, max_attempts + 1):
        turns_left = max_turns - state.turns
        if turns_left <= 0:
            state.stop_reason = "max_turns"
            break

        log(f"===== attempt {attempt}/{max_attempts} ({turns_left} turns left) =====")
        try:
            result = await Runner.run(agent, conversation, context=state,
                                      max_turns=turns_left, hooks=hooks)
        except MaxTurnsExceeded:
            state.stop_reason = "max_turns"
            break
        except AgentsException as exc:
            # e.g. the model produced malformed tool calls. API/network errors
            # come from the openai package and are deliberately not caught.
            state.stop_reason = f"sdk_error: {exc}"
            break

        state.final_message = str(result.final_output)
        check = verify(state)
        if check.passed:
            state.stop_reason = "tests_passed"
            return state

        # The model said it was done, but the tests disagree. Continue the same
        # conversation (full history) plus the harness's feedback.
        log(f"[harness] model finished but tests fail: {check.summary}")
        conversation = result.to_input_list() + [
            {"role": "user", "content": tests_failing_feedback(check.output)}]
    else:
        state.stop_reason = "max_attempts"

    # Stopped without success: record the real final state of the tests.
    verify(state)
    return state
