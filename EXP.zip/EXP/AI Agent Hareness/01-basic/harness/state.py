"""Run state tracked by the harness.

The OpenAI Agents SDK lets you pass any object as the run "context". It does
NOT read or modify that object itself; it just hands it to every tool and hook
via RunContextWrapper.context. That makes it the natural place for harness
state. Note that the context is local Python state only: it is never sent to
the model.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from harness.sandbox import Workspace


@dataclass
class TestResult:
    passed: bool
    exit_code: int | None  # None means pytest did not finish (e.g. timeout)
    summary: str  # e.g. "2 failed, 4 passed in 0.03s"
    output: str  # pytest output, truncated so it fits in the model's context

    __test__ = False  # stop pytest from trying to collect this class


@dataclass
class ToolCallRecord:
    turn: int
    name: str
    args: dict
    ok: bool
    note: str = ""


@dataclass
class ThoughtRecord:
    turn: int
    kind: str  # "reasoning" (summary from a reasoning model) or "message" (text the model wrote)
    text: str


@dataclass
class HarnessState:
    workspace: Workspace
    turns: int = 0  # model calls (LLM round trips), counted by our hooks
    tool_calls: list[ToolCallRecord] = field(default_factory=list)
    thoughts: list[ThoughtRecord] = field(default_factory=list)
    modified_files: set[str] = field(default_factory=set)
    latest_test_result: TestResult | None = None
    stop_reason: str = "not_started"
    final_message: str = ""

    def record_tool(self, name: str, args: dict, ok: bool, note: str = "") -> None:
        self.tool_calls.append(ToolCallRecord(self.turns, name, args, ok, note))
