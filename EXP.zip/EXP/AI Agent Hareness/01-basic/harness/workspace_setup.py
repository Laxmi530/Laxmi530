"""Shared setup used by both the CLI (run_agent.py) and the web UI (app.py)."""

from __future__ import annotations

import shutil
from pathlib import Path

from dotenv import load_dotenv

from harness.sandbox import SandboxError, Workspace

PROJECT_ROOT = Path(__file__).resolve().parents[1]
EXAMPLE_DIR = PROJECT_ROOT / "examples" / "calculator"
DEFAULT_WORKSPACE = PROJECT_ROOT / "workspace"
DEFAULT_TASK = "Fix the bug in calculator.py and make all tests pass."


def load_env() -> None:
    """Load .env from this level's folder, then the shared one in the parent folder.

    load_dotenv never overrides a variable that is already set, so the first
    file wins and real environment variables win over both.
    """
    load_dotenv(PROJECT_ROOT / ".env")
    load_dotenv(PROJECT_ROOT.parent / ".env")


def prepare_workspace(path: str | Path, reset: bool = False) -> Workspace:
    path = Path(path)
    if PROJECT_ROOT.is_relative_to(path.resolve()):
        # Otherwise the agent could edit the harness that is supposed to restrict it.
        raise SandboxError(f"Refusing to use {path}: the workspace must not contain the harness itself.")
    if reset or not path.exists():
        # Copy over the example files only. We never delete anything, so a
        # wrong workspace path cannot wipe out a real folder.
        shutil.copytree(EXAMPLE_DIR, path, dirs_exist_ok=True)
    return Workspace(path)
