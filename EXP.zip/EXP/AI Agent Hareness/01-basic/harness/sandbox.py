"""Workspace sandbox: every file operation the agent performs goes through here.

This is a HARNESS responsibility. The OpenAI Agents SDK will happily call any
Python function you give it; it has no idea which paths are safe. So the rule
"the agent may only touch files inside the workspace" must be enforced by us.

Rules enforced:
1. Paths must be relative. Absolute paths, drive letters and ':' are rejected
   (':' also blocks Windows alternate data streams like "file.py:hidden").
   Trailing dots/spaces are rejected because Windows silently strips them.
2. After resolving '..' and symlinks, the real path must still be inside the
   workspace root. This is the core path-traversal defence.
3. Hidden files/dirs (".env", ".git", ...) are off limits.
4. Some paths are read-only so the agent cannot "fix" failing tests by
   editing the tests or the pytest configuration.
5. Reads and writes are size-limited to keep the context window and disk sane.
"""

from __future__ import annotations

import os
from pathlib import Path

MAX_READ_BYTES = 100_000
MAX_WRITE_BYTES = 100_000
MAX_LIST_ENTRIES = 200

# Compared case-insensitively because Windows paths are case-insensitive
# ("Tests/test_x.py" is the same file as "tests/test_x.py").
READ_ONLY_DIRS = {"tests"}
READ_ONLY_FILES = {"conftest.py", "pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini"}
SKIP_WHEN_LISTING = {"__pycache__", ".pytest_cache"}


class SandboxError(Exception):
    """Raised when the agent asks for something the sandbox does not allow.

    The message is shown to the model, so it should explain what went wrong.
    """


class Workspace:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise SandboxError(f"Workspace folder does not exist: {self.root}")

    # ------------------------------------------------------------------ paths

    def resolve(self, rel_path: str) -> Path:
        """Turn an agent-supplied relative path into a safe absolute path."""
        if not rel_path or not rel_path.strip():
            raise SandboxError("Path must not be empty.")
        if "\x00" in rel_path or ":" in rel_path:
            raise SandboxError(f"Invalid characters in path: {rel_path!r}")

        candidate = Path(rel_path)
        if candidate.is_absolute() or candidate.anchor:
            raise SandboxError(f"Use a path relative to the workspace, got: {rel_path!r}")
        # Windows silently strips trailing dots and spaces, so "conftest.py." would
        # pass the read-only check below but still create a real conftest.py.
        if any(part != ".." and part.endswith((".", " ")) for part in candidate.parts):
            raise SandboxError(f"Path parts must not end with '.' or a space: {rel_path!r}")

        # resolve() collapses '..' and follows symlinks, so a symlink that
        # points outside the workspace is caught by the check below.
        full = (self.root / candidate).resolve()
        if not full.is_relative_to(self.root):
            raise SandboxError(f"Path escapes the workspace: {rel_path!r}")

        rel_parts = full.relative_to(self.root).parts
        if any(part.startswith(".") for part in rel_parts):
            raise SandboxError(f"Hidden files and folders are not accessible: {rel_path!r}")
        return full

    def relative(self, full: Path) -> str:
        return full.relative_to(self.root).as_posix()

    def is_read_only(self, full: Path) -> bool:
        parts = [p.lower() for p in full.relative_to(self.root).parts]
        return bool(parts) and (parts[0] in READ_ONLY_DIRS or parts[-1] in READ_ONLY_FILES)

    # ------------------------------------------------------------- operations

    def list_files(self, directory: str = ".") -> list[str]:
        base = self.root if directory in ("", ".") else self.resolve(directory)
        if not base.is_dir():
            raise SandboxError(f"Not a directory: {directory!r}")

        results: list[str] = []
        # os.walk does not follow directory symlinks, and pruning `dirnames` in
        # place means hidden/cache folders (.git, .venv, ...) are never scanned.
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames
                                 if not d.startswith(".") and d not in SKIP_WHEN_LISTING)
            for name in sorted(filenames):
                path = Path(dirpath) / name
                # Skip hidden files and file symlinks that point outside the workspace.
                if name.startswith(".") or not path.resolve().is_relative_to(self.root):
                    continue
                results.append(self.relative(path))
                if len(results) >= MAX_LIST_ENTRIES:
                    results.append(f"... (truncated at {MAX_LIST_ENTRIES} files)")
                    return results
        return results

    def read_file(self, rel_path: str) -> str:
        full = self.resolve(rel_path)
        if not full.is_file():
            raise SandboxError(f"File not found: {rel_path!r}")
        if full.stat().st_size > MAX_READ_BYTES:
            raise SandboxError(f"File is larger than {MAX_READ_BYTES} bytes: {rel_path!r}")
        try:
            return full.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise SandboxError(f"File is not UTF-8 text: {rel_path!r}") from None

    def write_file(self, rel_path: str, content: str) -> str:
        """Create or overwrite a file. Returns the normalised relative path."""
        full = self._check_writable(rel_path)
        if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
            raise SandboxError(f"Content is larger than {MAX_WRITE_BYTES} bytes.")
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8", newline="\n")
        return self.relative(full)

    def edit_file(self, rel_path: str, old_text: str, new_text: str) -> str:
        """Replace exactly one occurrence of old_text with new_text.

        Requiring a unique match is a deliberate safety rule: the model must
        quote enough surrounding code that the edit is unambiguous, so it can't
        accidentally change the wrong line.
        """
        self._check_writable(rel_path)
        if not old_text:
            raise SandboxError("old_text must not be empty. Use write_file to create files.")
        content = self.read_file(rel_path)
        count = content.count(old_text)
        if count == 0:
            raise SandboxError(
                "old_text was not found. Re-read the file and copy the exact text, "
                "including indentation."
            )
        if count > 1:
            raise SandboxError(
                f"old_text appears {count} times. Include more surrounding lines so it is unique."
            )
        return self.write_file(rel_path, content.replace(old_text, new_text, 1))

    def _check_writable(self, rel_path: str) -> Path:
        full = self.resolve(rel_path)
        if self.is_read_only(full):
            raise SandboxError(
                f"{rel_path!r} is read-only. Fix the source code, not the tests or test config."
            )
        if full.is_dir():
            raise SandboxError(f"{rel_path!r} is a directory.")
        return full
