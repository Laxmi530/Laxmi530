"""A minimal coding-agent harness built on the OpenAI Agents SDK."""
