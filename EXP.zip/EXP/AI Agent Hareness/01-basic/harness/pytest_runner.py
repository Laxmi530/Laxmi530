"""Run pytest inside the workspace, the only process the agent can start.

Instead of an unrestricted shell, the agent gets exactly one fixed command:
    <this python> -m pytest [optional test path inside the workspace]

Important limitation: pytest imports and runs the code in the workspace, and
the agent can edit that code. So "run tests" is effectively "run code the
agent wrote". We reduce the blast radius (no shell, fixed argv, timeout,
stripped environment so secrets like OPENAI_API_KEY are not visible), but this
is NOT an OS-level sandbox. For untrusted tasks, run the whole harness inside
a container or VM.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys

from harness.sandbox import Workspace
from harness.state import TestResult

TIMEOUT_SECONDS = 60
MAX_OUTPUT_CHARS = 6_000

# Only these environment variables are passed to the test process. Everything
# else (API keys, tokens, cloud credentials) is dropped.
SAFE_ENV_VARS = {
    "PATH", "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "COMSPEC", "PATHEXT",  # Windows essentials
    "TEMP", "TMP", "TMPDIR", "HOME", "USERPROFILE", "LANG", "LC_ALL",
}

# pytest exit codes: 0 all passed, 1 some failed, 2 interrupted,
# 3 internal error, 4 usage error, 5 no tests collected.
EXIT_CODE_MEANING = {0: "all tests passed", 1: "some tests failed", 2: "interrupted",
                     3: "internal error", 4: "usage error", 5: "no tests collected"}


def run_pytest(workspace: Workspace, test_path: str | None = None) -> TestResult:
    cmd = [
        # -P: don't put the cwd on sys.path at startup, otherwise an agent-written
        # "pytest.py" in the workspace would be run instead of the real pytest.
        sys.executable, "-P", "-m", "pytest",
        "-q", "--tb=short", "--color=no",
        "-p", "no:cacheprovider",  # don't write .pytest_cache into the workspace
        f"--rootdir={workspace.root}",
    ]
    if test_path:
        # Goes through the sandbox, and becomes an absolute path, so it can
        # never be interpreted as a pytest option like "--something".
        target = workspace.resolve(test_path)
        cmd.append(str(target))

    env = {k: v for k, v in os.environ.items() if k.upper() in SAFE_ENV_VARS}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    try:
        proc = subprocess.run(
            cmd,
            cwd=workspace.root,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=TIMEOUT_SECONDS,
            shell=False,  # argv list, never a shell string
        )
    except subprocess.TimeoutExpired:
        return TestResult(False, None, f"pytest timed out after {TIMEOUT_SECONDS}s",
                          "Timed out. Look for infinite loops or very slow code.")

    output = (proc.stdout + proc.stderr).strip()
    # pytest prints its summary as the last stdout line; stray stderr output
    # (e.g. warnings) must not be mistaken for it.
    stdout_lines = [line for line in proc.stdout.splitlines() if line.strip()]
    stderr_lines = [line for line in proc.stderr.splitlines() if line.strip()]
    fallback = [EXIT_CODE_MEANING.get(proc.returncode, "unknown")]
    summary = (stdout_lines or stderr_lines or fallback)[-1]
    # Exit code 0 alone isn't enough: code under test could call os._exit(0).
    # Also require pytest's own "N passed" summary line.
    passed = proc.returncode == 0 and re.search(r"\b\d+ passed\b", summary) is not None
    return TestResult(
        passed=passed,
        exit_code=proc.returncode,
        summary=summary,
        output=_truncate(output),
    )


def _truncate(text: str) -> str:
    """Keep the end of the output: pytest prints the failure summary last."""
    if len(text) <= MAX_OUTPUT_CHARS:
        return text
    return "... (output truncated) ...\n" + text[-MAX_OUTPUT_CHARS:]
