# AI Agent Harness: learn it in four levels

A hands-on course in how a coding-agent **harness** works. Each level is a complete,
standalone project with its own CLI, Streamlit UI, tests and README.

Levels 1 to 3 use the [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/) with
plain Python control flow (no LangChain or LangGraph), each building on the one before, so you can
compare two folders side by side and see exactly what was added. Level 4 solves the same problem
with a different stack: [LangGraph](https://langchain-ai.github.io/langgraph/) for orchestration and the
[Claude Agent SDK](https://code.claude.com/docs/en/agent-sdk) for the agents.

| Level | Folder | Stack | What you learn |
|---|---|---|---|
| 1. Basic | [`01-basic/`](01-basic/README.md) | OpenAI Agents SDK | The core loop: tools, a path sandbox, turn limits, state, and a harness-owned completion rule ("done" = pytest passes). Example: a 1-file calculator with 3 bugs. |
| 2. Intermediate | [`02-intermediate/`](02-intermediate/README.md) | OpenAI Agents SDK | Working on multi-file projects: a code-search tool, line-range reads, and tool design for models. Example: a 4-module shop with 5 bugs spread across files. |
| 3. Advanced | [`03-advanced/`](03-advanced/README.md) | OpenAI Agents SDK | Several agents: planner, coder and reviewer, with least-privilege tools per role, structured (typed) outputs, a harness-run workflow, and a review gate. |
| 4. LangGraph + Claude | [`04-langgraph-claude/`](04-langgraph-claude/README.md) | LangGraph + Claude Agent SDK | The Level 3 workflow as a graph with a **subgraph inside a node** (the fix loop); Claude Code agents with **adaptive thinking** and effort per role; sandboxing built-in tools with a `PreToolUse` hook; a notebook (`graph_demo.ipynb`) to draw and invoke the graph. |

## One-time setup

All levels share one virtual environment and one `.env` in this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r 01-basic\requirements.txt              # levels 1-3
pip install -r 04-langgraph-claude\requirements.txt   # level 4 (adds langgraph, claude-agent-sdk)
copy 01-basic\.env.example .env   # OPENAI_API_KEY for levels 1-3
                                  # add ANTHROPIC_API_KEY to the same file for level 4
```

A level's own `.env` (if you create one) takes priority over the shared one.

## Running a level

```powershell
cd 01-basic          # or 02-intermediate, 03-advanced
python run_agent.py --reset

cd 04-langgraph-claude
python run_graph.py --reset

streamlit run app.py # any level: http://localhost:8501
pytest               # any level: offline tests, no API key needed
```

Run each level from inside its own folder. To run two UIs at once, give one a
different port: `streamlit run app.py --server.port 8502`.

## Suggested path

1. Read `01-basic/README.md`, especially the "Who does what: SDK vs harness" table. Try its UI examples.
2. Compare `01-basic/harness/` with `02-intermediate/harness/` (`sandbox.py`, `tools.py`), then try the shop example.
3. Read `03-advanced/harness/team.py` top to bottom; it's the whole multi-agent workflow in one file.
4. Read `04-langgraph-claude/harness/graph.py` next to `03-advanced/harness/team.py`: the same workflow
   as plain Python versus as a LangGraph graph with a subgraph. Then read `harness/agents.py` for how
   Claude Code's built-in tools are sandboxed with a hook.
5. In each level, read the loop tests (`test_agent_loop.py`, `test_team_loop.py`, `test_graph.py`). A scripted
   fake model or runner walks through the workflow step by step without spending any tokens.
