"""Checks the multi-file shop example is broken in exactly the intended ways."""

import pytest

from harness.pytest_runner import run_pytest
from harness.workspace_setup import prepare_workspace

# (file, buggy text, fixed text): the 5 intended bugs.
FIXES = [
    ("shop/money.py", "rounding=ROUND_DOWN", "rounding=ROUND_HALF_UP"),
    ("shop/money.py", "from decimal import ROUND_DOWN, Decimal",
     "from decimal import ROUND_HALF_UP, Decimal"),
    ("shop/catalog.py", "        return self._by_sku[sku]",
     "        try:\n            return self._by_sku[sku]\n"
     "        except KeyError:\n            raise ProductNotFound(sku) from None"),
    ("shop/discounts.py", "price * Decimal(percent) / 100", "price * (100 - Decimal(percent)) / 100"),
    ("shop/discounts.py", "if quantity > 10:", "if quantity >= 10:"),
    ("shop/cart.py", "        self.items[sku] = current - quantity",
     "        if quantity == current:\n            del self.items[sku]\n"
     "        else:\n            self.items[sku] = current - quantity"),
]


@pytest.fixture
def shop_ws(tmp_path):
    return prepare_workspace(tmp_path / "shop", example="shop")


def test_broken_shop_fails(shop_ws):
    result = run_pytest(shop_ws)
    assert not result.passed
    assert "13 failed, 10 passed" in result.summary


def test_intended_fixes_make_every_test_pass(shop_ws):
    for path, old, new in FIXES:
        shop_ws.edit_file(path, old, new)
    result = run_pytest(shop_ws)
    assert result.passed, result.output
    assert "23 passed" in result.summary
