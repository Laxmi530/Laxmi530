"""End-to-end test of the whole loop with a scripted fake model (no API key).

The real SDK Runner drives the loop and runs our real tools and hooks; only
the LLM is replaced by a script of canned responses. This is the best way to
see the loop's mechanics without spending tokens.
"""

import asyncio
import itertools
import json
import shutil
from pathlib import Path

import pytest
from agents import Model, ModelResponse, Usage, set_tracing_disabled
from openai.types.responses import (
    ResponseFunctionToolCall, ResponseOutputMessage, ResponseOutputText, ResponseReasoningItem,
)
from openai.types.responses.response_reasoning_item import Summary

from harness.agent import run_task
from harness.sandbox import Workspace
from harness.workspace_setup import prepare_workspace
from tests.test_pytest_runner import FIXED_CALCULATOR
from tests.test_shop_example import FIXES

EXAMPLE = Path(__file__).resolve().parents[1] / "examples" / "calculator"


class ScriptedModel(Model):
    """Returns one pre-written response per model call, in order."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = 0

    async def get_response(self, *args, **kwargs):
        self.calls += 1
        step = self.script.pop(0) if self.script else self.default_step()
        output = step if isinstance(step, list) else [step]  # a list = several items in one response
        return ModelResponse(output=output, usage=Usage(), response_id=None)

    def default_step(self):
        return tool_call("run_tests", test_path="")

    def stream_response(self, *args, **kwargs):
        raise NotImplementedError


_call_ids = itertools.count(1)


def tool_call(name, **args):
    return ResponseFunctionToolCall(type="function_call", name=name, arguments=json.dumps(args),
                                    call_id=f"call_{next(_call_ids)}", status="completed")


def say(text):
    return ResponseOutputMessage(
        type="message", id="msg", role="assistant", status="completed",
        content=[ResponseOutputText(type="output_text", text=text, annotations=[])],
    )


def reason(text):
    """A reasoning item with a summary, as a reasoning model returns it."""
    return ResponseReasoningItem(id="rs", type="reasoning",
                                 summary=[Summary(type="summary_text", text=text)])


@pytest.fixture(autouse=True)
def no_tracing():
    set_tracing_disabled(True)


@pytest.fixture
def calc_ws(tmp_path):
    shutil.copytree(EXAMPLE, tmp_path / "ws")
    return Workspace(tmp_path / "ws")


def test_harness_rejects_premature_done_and_continues_until_tests_pass(calc_ws):
    model = ScriptedModel([
        tool_call("read_file", path="../secrets.txt",           # turn 1: sandbox rejects
                  start_line=1, end_line=0),
        tool_call("run_tests", test_path=""),                   # turn 2: sees failures
        tool_call("edit_file", path="calculator.py",            # turn 3: fixes one bug
                  old_text="return b - a", new_text="return a - b"),
        say("Done!"),                                           # turn 4: claims done (wrong)
        tool_call("write_file", path="calculator.py",           # turn 5: after harness feedback
                  content=FIXED_CALCULATOR),
        say("All tests pass now."),                             # turn 6: really done
    ])

    state = asyncio.run(run_task("Fix calculator.py", calc_ws, model, max_turns=20))

    assert state.stop_reason == "tests_passed"
    assert state.turns == 6 == model.calls
    assert [c.name for c in state.tool_calls] == ["read_file", "run_tests", "edit_file", "write_file"]
    assert [c.ok for c in state.tool_calls] == [False, True, True, True]
    assert state.modified_files == {"calculator.py"}
    assert state.latest_test_result.passed
    assert state.final_message == "All tests pass now."


def test_multi_file_fix_using_search_and_line_ranges(tmp_path):
    shop_ws = prepare_workspace(tmp_path / "shop", example="shop")
    model = ScriptedModel(
        [tool_call("search_code", query="def to_money", directory="."),
         tool_call("read_file", path="shop/money.py", start_line=1, end_line=12)]
        + [tool_call("edit_file", path=p, old_text=old, new_text=new) for p, old, new in FIXES]
        + [say("Fixed 5 bugs across 4 files.")]
    )

    state = asyncio.run(run_task("Fix the shop", shop_ws, model, max_turns=20))

    assert state.stop_reason == "tests_passed"
    assert [c.name for c in state.tool_calls[:2]] == ["search_code", "read_file"]
    assert all(c.ok for c in state.tool_calls)
    assert state.modified_files == {"shop/money.py", "shop/catalog.py",
                                    "shop/discounts.py", "shop/cart.py"}


def test_reasoning_summaries_and_messages_are_recorded(tmp_path):
    shop_ws = prepare_workspace(tmp_path / "shop", example="shop")
    model = ScriptedModel(
        [[reason("Cart totals depend on money and discounts; find to_money first."),
          say("Searching for to_money."),
          tool_call("search_code", query="def to_money", directory=".")]]
        + [tool_call("edit_file", path=p, old_text=old, new_text=new) for p, old, new in FIXES]
        + [say("Fixed 5 bugs across 4 files.")]
    )

    state = asyncio.run(run_task("Fix the shop", shop_ws, model, max_turns=20))

    assert state.stop_reason == "tests_passed"
    assert [(t.turn, t.kind) for t in state.thoughts][:2] == [(1, "reasoning"), (1, "message")]
    assert state.thoughts[0].text.startswith("Cart totals depend on money")
    assert state.thoughts[-1].text == "Fixed 5 bugs across 4 files."


def test_total_turn_budget_is_enforced(calc_ws):
    model = ScriptedModel([])  # never finishes: keeps calling run_tests forever

    state = asyncio.run(run_task("Fix calculator.py", calc_ws, model, max_turns=3))

    assert state.stop_reason == "max_turns"
    assert state.turns == 3
    assert not state.latest_test_result.passed
