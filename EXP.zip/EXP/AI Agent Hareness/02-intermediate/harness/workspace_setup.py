"""Shared setup used by both the CLI (run_agent.py) and the web UI (app.py)."""

from __future__ import annotations

import shutil
from pathlib import Path

from dotenv import load_dotenv

from harness.sandbox import SandboxError, Workspace

PROJECT_ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = PROJECT_ROOT / "examples"
WORKSPACES_DIR = PROJECT_ROOT / "workspace"

# Example name -> default task. Each example is a folder in examples/.
EXAMPLES = {
    "shop": "Fix the bugs in the shop package and make all tests pass.",
    "calculator": "Fix the bug in calculator.py and make all tests pass.",
}
DEFAULT_EXAMPLE = "shop"


def default_workspace(example: str) -> Path:
    """Each example gets its own workspace so their files never mix."""
    return WORKSPACES_DIR / example


def load_env() -> None:
    """Load .env from this level's folder, then the shared one in the parent folder.

    load_dotenv never overrides a variable that is already set, so the first
    file wins and real environment variables win over both.
    """
    load_dotenv(PROJECT_ROOT / ".env")
    load_dotenv(PROJECT_ROOT.parent / ".env")


def prepare_workspace(path: str | Path, example: str = DEFAULT_EXAMPLE,
                      reset: bool = False) -> Workspace:
    path = Path(path)
    if example not in EXAMPLES:
        raise SandboxError(f"Unknown example {example!r}. Choose from: {', '.join(EXAMPLES)}")
    if PROJECT_ROOT.is_relative_to(path.resolve()):
        # Otherwise the agent could edit the harness that is supposed to restrict it.
        raise SandboxError(f"Refusing to use {path}: the workspace must not contain the harness itself.")
    if reset or not path.exists():
        # Copy over the example files only. We never delete anything, so a
        # wrong workspace path cannot wipe out a real folder.
        shutil.copytree(EXAMPLES_DIR / example, path, dirs_exist_ok=True)
    return Workspace(path)
