from decimal import Decimal

import pytest

from shop.catalog import Catalog, Product, ProductNotFound

MUG = Product("MUG", "Coffee Mug", Decimal("12.50"))
PEN = Product("PEN", "Gel Pen", Decimal("1.99"))


def test_get_existing_product():
    assert Catalog([MUG, PEN]).get("PEN") == PEN


def test_get_missing_product_raises_product_not_found():
    with pytest.raises(ProductNotFound):
        Catalog([MUG]).get("NOPE")


def test_duplicate_sku_is_rejected():
    with pytest.raises(ValueError):
        Catalog([MUG, MUG])


def test_search_is_case_insensitive():
    assert Catalog([MUG, PEN]).search("mug") == [MUG]
