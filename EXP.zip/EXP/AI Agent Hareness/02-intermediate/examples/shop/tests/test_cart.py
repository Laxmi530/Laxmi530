from decimal import Decimal

import pytest

from shop.cart import Cart
from shop.catalog import Catalog, Product, ProductNotFound


@pytest.fixture
def cart():
    catalog = Catalog([
        Product("MUG", "Coffee Mug", Decimal("12.50")),
        Product("PEN", "Gel Pen", Decimal("1.99")),
    ])
    return Cart(catalog)


def test_adding_unknown_sku_raises_product_not_found(cart):
    with pytest.raises(ProductNotFound):
        cart.add("NOPE")


def test_removing_everything_empties_the_cart(cart):
    cart.add("MUG", 2)
    cart.remove("MUG", 2)
    assert cart.items == {}


def test_subtotal_without_discount(cart):
    cart.add("MUG", 2)
    assert cart.subtotal() == Decimal("25.00")


def test_subtotal_with_bulk_discount(cart):
    cart.add("PEN", 10)
    assert cart.subtotal() == Decimal("17.91")


def test_subtotal_with_mixed_lines(cart):
    cart.add("MUG", 2)
    cart.add("PEN", 5)
    assert cart.subtotal() == Decimal("34.45")


def test_total_adds_tax(cart):
    cart.add("MUG", 1)
    assert cart.total() == Decimal("13.50")


def test_total_rounds_half_up(cart):
    cart.add("PEN", 3)
    assert cart.total() == Decimal("6.45")
