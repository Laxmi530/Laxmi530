from decimal import Decimal

from shop.money import format_money, to_money


def test_to_money_pads_whole_numbers():
    assert to_money(3) == Decimal("3.00")


def test_to_money_rounds_half_up():
    assert to_money("2.675") == Decimal("2.68")


def test_to_money_rounds_up_to_next_dollar():
    assert to_money("19.999") == Decimal("20.00")


def test_format_money():
    assert format_money(Decimal("1234.5")) == "$1,234.50"
