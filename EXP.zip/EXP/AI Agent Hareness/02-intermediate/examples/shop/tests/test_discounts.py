from decimal import Decimal

import pytest

from shop.discounts import bulk_discount_percent, percent_off


def test_percent_off_returns_discounted_price():
    assert percent_off(Decimal("50.00"), 20) == Decimal("40.00")


def test_zero_percent_off_keeps_price():
    assert percent_off(Decimal("19.99"), 0) == Decimal("19.99")


def test_percent_off_rejects_invalid_percent():
    with pytest.raises(ValueError):
        percent_off(Decimal("10.00"), 150)


@pytest.mark.parametrize("quantity, expected", [(4, 0), (5, 5), (9, 5), (10, 10), (25, 10)])
def test_bulk_discount_percent(quantity, expected):
    assert bulk_discount_percent(quantity) == expected
