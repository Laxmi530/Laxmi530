"""A tiny shop: catalog, discounts, money handling and a shopping cart."""
