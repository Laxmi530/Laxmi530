"""Shopping cart."""

from decimal import Decimal

from shop.catalog import Catalog
from shop.discounts import bulk_discount_percent, percent_off
from shop.money import to_money

TAX_RATE = Decimal("0.08")


class Cart:
    def __init__(self, catalog: Catalog) -> None:
        self.catalog = catalog
        self.items: dict[str, int] = {}  # sku -> quantity

    def add(self, sku: str, quantity: int = 1) -> None:
        """Add items. Raises ProductNotFound for unknown SKUs."""
        if quantity <= 0:
            raise ValueError("quantity must be positive")
        self.catalog.get(sku)
        self.items[sku] = self.items.get(sku, 0) + quantity

    def remove(self, sku: str, quantity: int = 1) -> None:
        """Remove items. A SKU whose quantity reaches zero disappears from the cart."""
        current = self.items.get(sku, 0)
        if quantity <= 0 or quantity > current:
            raise ValueError("cannot remove more than is in the cart")
        self.items[sku] = current - quantity

    def subtotal(self) -> Decimal:
        """Sum of all lines after bulk discounts, before tax."""
        total = Decimal("0")
        for sku, quantity in self.items.items():
            product = self.catalog.get(sku)
            total += percent_off(product.price * quantity, bulk_discount_percent(quantity))
        return to_money(total)

    def total(self) -> Decimal:
        """Subtotal plus tax, rounded to cents."""
        subtotal = self.subtotal()
        return to_money(subtotal + subtotal * TAX_RATE)
