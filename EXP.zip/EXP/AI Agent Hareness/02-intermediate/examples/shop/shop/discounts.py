"""Discount rules."""

from decimal import Decimal

from shop.money import to_money


def percent_off(price: Decimal, percent: int) -> Decimal:
    """Return the price after taking `percent`% off, rounded to cents."""
    if not 0 <= percent <= 100:
        raise ValueError("percent must be between 0 and 100")
    return to_money(price * Decimal(percent) / 100)


def bulk_discount_percent(quantity: int) -> int:
    """Bulk discount for one line: 10% for 10 or more items, 5% for 5 or more."""
    if quantity > 10:
        return 10
    if quantity >= 5:
        return 5
    return 0
