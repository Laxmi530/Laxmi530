"""Product catalog."""

from dataclasses import dataclass
from decimal import Decimal


class ProductNotFound(Exception):
    """Raised when a SKU is not in the catalog."""


@dataclass(frozen=True)
class Product:
    sku: str
    name: str
    price: Decimal


class Catalog:
    def __init__(self, products: list[Product] | None = None) -> None:
        self._by_sku: dict[str, Product] = {}
        for product in products or []:
            self.add(product)

    def add(self, product: Product) -> None:
        if product.sku in self._by_sku:
            raise ValueError(f"Duplicate SKU: {product.sku}")
        self._by_sku[product.sku] = product

    def get(self, sku: str) -> Product:
        """Return the product with this SKU. Raises ProductNotFound if missing."""
        return self._by_sku[sku]

    def search(self, text: str) -> list[Product]:
        """Products whose name contains `text`, case-insensitive."""
        needle = text.lower()
        return [p for p in self._by_sku.values() if needle in p.name.lower()]
