"""Money helpers. All amounts are Decimals rounded to whole cents."""

from decimal import ROUND_DOWN, Decimal

CENT = Decimal("0.01")


def to_money(value: int | str | Decimal) -> Decimal:
    """Convert a value to a Decimal rounded to cents, rounding half up (2.675 -> 2.68)."""
    return Decimal(str(value)).quantize(CENT, rounding=ROUND_DOWN)


def format_money(amount: Decimal) -> str:
    """Format an amount like $1,234.50."""
    return f"${amount:,.2f}"
