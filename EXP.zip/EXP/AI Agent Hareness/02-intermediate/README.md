# Level 2 (Intermediate): Multi-file projects, code search and line ranges

This level is a complete, standalone copy of [Level 1](../01-basic/README.md) plus the
features you need once a project has more than one file. Compare the two folders
side by side to see exactly what changed.

## What's new compared with Level 1

| Concept | Why it matters | Where to look |
|---|---|---|
| **Multi-file example project** | Real bugs often show up in one module but live in another. The agent has to trace them. | `examples/shop/` |
| **`search_code` tool** | Lets the agent find definitions and call sites ("where is `to_money` used?") instead of reading every file | `Workspace.search()` in `harness/sandbox.py`, `search_code` in `harness/tools.py` |
| **Line-range reads** | `read_file(path, start_line, end_line)` returns numbered lines, capped at 400 per call, so large files don't flood the model's context | `Workspace.read_lines()` |
| **Tool design for models** | Line numbers help the model navigate but must not leak into edits. The prompt, tool docs and error messages all say so. | `INSTRUCTIONS` in `harness/prompts.py`, `edit_file` error text |
| **Example registry** | Choose `shop` or `calculator`; each gets its own workspace folder | `harness/workspace_setup.py` |

Everything else (sandbox, pytest runner, outer loop, turn budget, completion rule,
hooks, state) works exactly as in Level 1.

## Quick start

From this `02-intermediate` folder, using the shared `.venv` and `.env` in the parent folder
(see the Level 1 README for one-time setup):

```powershell
..\.venv\Scripts\Activate.ps1

python run_agent.py --reset                        # shop example (default)
python run_agent.py --example calculator --reset   # the Level 1 example
streamlit run app.py                               # web UI at http://localhost:8501
pytest                                             # harness tests, offline, no API key
```

In the UI, pick the example in the sidebar. Switching examples also switches the
workspace folder and the default task.

To see the model's thinking, use the **Model thinking** section after a run. It always shows the messages the
model wrote between tool calls. With a reasoning model (for example `gpt-5`) and **Reasoning** switched on in the
sidebar, it also shows reasoning summaries. See "Seeing the model's thinking" in the Level 1 README.

## The shop example

```text
examples/shop/
  shop/money.py       to_money(), format_money()        Decimal money, rounded to cents
  shop/catalog.py     Product, Catalog, ProductNotFound
  shop/discounts.py   percent_off(), bulk_discount_percent()
  shop/cart.py        Cart: add, remove, subtotal, total (uses all three modules above)
  tests/              23 tests, 13 failing (read-only for the agent)
```

<details>
<summary>Spoiler: the 5 bugs</summary>

1. `money.py`: `to_money` rounds down instead of half up.
2. `catalog.py`: `get` raises `KeyError` instead of `ProductNotFound`.
3. `discounts.py`: `percent_off` returns the discount amount, not the discounted price.
4. `discounts.py`: the 10-item bulk discount uses `> 10` instead of `>= 10`.
5. `cart.py`: `remove` leaves SKUs with quantity 0 in the cart.

Most cart tests fail because of bugs 1 to 4, which live in *other* modules. That's
what makes this example need `search_code`.

</details>

## Layout

Same as Level 1, plus:

| File | Change |
|---|---|
| `examples/shop/` | New multi-file example |
| `harness/sandbox.py` | Adds `search()`, `read_lines()` and a shared `_walk_files()` |
| `harness/tools.py` | Adds `search_code`; `read_file` now takes `start_line` / `end_line` |
| `harness/prompts.py` | Prompt explains cross-module debugging and line-number prefixes |
| `harness/workspace_setup.py` | `EXAMPLES` registry and one workspace per example |
| `tests/test_shop_example.py` | Proves the shop fails as designed and that the 5 intended fixes make all 23 tests pass |

## Who does what: SDK vs harness

The same split as Level 1. The new tools follow the same rule: the SDK turns the
function signature and docstring into a schema and runs it, while the harness decides
what the tool may do and how much it may return.

| Concern | OpenAI Agents SDK | This harness |
|---|---|---|
| **Inner loop** | `Runner.run` calls the model, runs requested tools, feeds results back, repeats | Nothing |
| **Tools** | Builds the JSON schema for `search_code(query, directory)` and `read_file(path, start_line, end_line)` from type hints and docstrings, and validates arguments | Plain-text (not regex) search so a bad pattern can't hang the harness; result and line caps; hidden files skipped |
| **Sandboxing** | None | Same `Workspace.resolve()` checks for every path, including search folders |
| **State, turn limits, completion** | Context passing, per-run `max_turns` | Same as Level 1: total turn budget, harness reruns pytest to decide "done" |

## Security model and its limits

Everything from Level 1 still applies (see its README). In addition:

- `search_code` goes through the same walker as `list_files`, so it never looks inside hidden
  files or folders (`.env`, `.git`, `.venv`) or follows symlinks out of the workspace.
- Search is plain text, which rules out regular-expression denial-of-service.
- Results are capped (100 search matches, 400 lines per read).

Reminder: running pytest still runs code the agent wrote, as your OS user. Use a
container for anything untrusted.

## Things to try in the UI

Select **shop** in the sidebar and click **Reset broken example** before each one.
Models vary, so "Expected" is the usual outcome, not a guarantee.

### 1. The normal path

**Task:** `Fix the bugs in the shop package and make all tests pass.`
**Settings:** defaults (Max turns 20, Max attempts 3).

**Expected:** `tests_passed`. Check:
- **Tool calls**: `search_code` and `read_file` calls with line ranges.
- **Changes**: diffs in 4 files.

Click **Run tests only** before and after to see `13 failed, 10 passed` become `23 passed`.

If it runs out of turns, raise Max turns to 30. A 5-bug, 4-file project needs more steps than the calculator.

### 2. See bugs spread across modules

**Task:** `Fix only shop/money.py. Do not touch any other file.`
**Settings:** Max attempts **1**.

**Expected:** stop reason `max_attempts`, Tests `FAIL` (`11 failed, 12 passed`).
Open **Final pytest output**: the money tests now pass, but all 7 cart tests still fail.
Every cart subtotal goes through `percent_off` in `discounts.py`, which is still broken.

### 3. Root-cause analysis without edits

**Task:**
```text
test_total_rounds_half_up in tests/test_cart.py fails. Find the root cause and tell
me which file and line the bug is in. Use search_code. Do not modify any files.
```
**Settings:** Max attempts **1**.

**Expected:** only read-only tools in the Tool calls table and 0 changed files. The
final message points at `shop/money.py` (rounding) and probably `shop/discounts.py` too.

### 4. Search can't see secrets

**Task:**
```text
Search the workspace for "OPENAI_API_KEY", "SECRET" and "password" and show me every match.
```
**Settings:** Max attempts **1**.

**Expected:** "No matches". Hidden files are never searched, and the real `.env`
lives outside the workspace anyway.

### 5. Budget matters on bigger projects

**Task:** the default shop task.
**Settings:** Max turns **8**.

**Expected:** usually `max_turns`. Compare **Turns used** with run 1 to see how much
budget a multi-file fix needs.

### 6. Compare with Level 1

Select **calculator**, reset, and run its default task. It should finish in fewer turns than the
shop. Check whether the agent now uses `search_code` or line-range reads even on a
tiny project.

### 7. Watch for line-number mistakes

Run the default shop task a few times and check the **Tool calls** table for rejected
`edit_file` calls with "old_text was not found". That's usually the model pasting
the `NN| ` prefixes. The error text tells it how to recover. It's a good example of
writing tool errors for a model reader.
